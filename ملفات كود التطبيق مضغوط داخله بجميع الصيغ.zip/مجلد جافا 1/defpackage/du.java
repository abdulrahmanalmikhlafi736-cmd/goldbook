package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: du */
public final class du extends h90 implements i00 {
    public final /* synthetic */ boolean f;
    public final /* synthetic */ xz g;

    public final Object i(Object obj) {
        sx0 sx0 = (sx0) obj;
        boolean z = !this.f && ((Boolean) this.g.a()).booleanValue();
        if (sx0.o != z) {
            sx0.e |= 16384;
            sx0.o = z;
        }
        return we1.a;
    }

    public du(boolean z, xz xzVar) {
        this.f = z;
        this.g = xzVar;
        super(1);
    }
}