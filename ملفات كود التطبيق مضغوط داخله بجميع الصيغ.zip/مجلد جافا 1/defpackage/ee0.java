package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ee0 */
public final class ee0 {
    public static final float b = 0.5f;
    public static final float c = -1.0f;
    public static final float d = 1.0f;
    public final float a;

    public static String b(float f) {
        if (f == 0.0f) {
            return "LineHeightStyle.Alignment.Top";
        }
        if (f == b) {
            return "LineHeightStyle.Alignment.Center";
        }
        if (f == c) {
            return "LineHeightStyle.Alignment.Proportional";
        }
        if (f == d) {
            return "LineHeightStyle.Alignment.Bottom";
        }
        StringBuilder dl1 = new dl1("LineHeightStyle.Alignment(topPercentage = ");
        dl1.append(f);
        dl1.append(')');
        return dl1.toString();
    }

    static {
        ee0.a(0.0f);
        ee0.a(0.5f);
        ee0.a(-1.0f);
        ee0.a(1.0f);
    }

    public static void a(float f) {
        if (0.0f > f || f > 1.0f) {
            if (f != -1.0f) {
                a5.b("topRatio should be in [0..1] range or -1");
            }
        }
    }

    public final boolean equals(Object obj) {
        if (obj instanceof ee0) {
            if (Float.compare(this.a, ((ee0) obj).a) == 0) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return Float.floatToIntBits(this.a);
    }

    public final String toString() {
        return ee0.b(this.a);
    }

    public /* synthetic */ ee0(float f) {
        this.a = f;
    }
}