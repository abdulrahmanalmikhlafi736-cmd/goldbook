package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dl */
public final class dl {
    public final tc a;
    public final ne b;

    public final String toString() {
        ne neVar = this.b;
        if (neVar.i.k(xl.f) == null) {
            StringBuilder dl1 = new dl1("Request@");
            int hashCode = hashCode();
            a5.l(16);
            String num = Integer.toString(hashCode, 16);
            num.getClass();
            dl1.append(num);
            dl1.append("(currentBounds()=");
            dl1.append(this.a.a());
            dl1.append(", continuation=");
            dl1.append(neVar);
            dl1.append(')');
            return dl1.toString();
        }
        od.d();
        return null;
    }

    public dl(tc tcVar, ne neVar) {
        this.a = tcVar;
        this.b = neVar;
    }
}