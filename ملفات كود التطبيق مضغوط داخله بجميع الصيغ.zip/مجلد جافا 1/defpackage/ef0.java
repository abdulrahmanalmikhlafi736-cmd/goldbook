package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ef0 */
public abstract class ef0 {
    public static final k81 a = new ad0(new h90(22));
}