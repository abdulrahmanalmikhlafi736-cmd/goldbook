package defpackage;

import android.os.Build.VERSION;
import android.view.View;
import android.view.WindowInsets.Type;
import android.view.WindowInsetsController;
import android.view.inputmethod.InputMethodManager;
import java.util.concurrent.atomic.AtomicBoolean;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: e71 */
public final class e71 extends x50 {
    public View b;

    public final void a() {
        View view = this.b;
        WindowInsetsController k = view != null ? view.getWindowInsetsController() : null;
        if (k != null) {
            AtomicBoolean h80 = new h80(false);
            d71 d71 = new d71(h80);
            k.addOnControllableInsetsChangedListener(d71);
            if (!(h80.get() || view == null)) {
                ((InputMethodManager) view.getContext().getSystemService("input_method")).hideSoftInputFromWindow(view.getWindowToken(), 0);
            }
            k.removeOnControllableInsetsChangedListener(d71);
            k.hide(Type.ime());
            return;
        }
        super.a();
    }

    public final void b() {
        View view = this.b;
        if (view != null && VERSION.SDK_INT < 33) {
            ((InputMethodManager) view.getContext().getSystemService("input_method")).isActive();
        }
        WindowInsetsController k = view != null ? view.getWindowInsetsController() : null;
        if (k != null) {
            k.show(Type.ime());
        }
        super.b();
    }
}