package defpackage;

import android.view.autofill.AutofillManager;
import java.util.Collection;
import java.util.Iterator;
import java.util.Set;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dk0 */
public final class dk0 implements y80, Set, w80 {
    public final bk0 e;
    public final bk0 f;

    public final boolean removeAll(Collection collection) {
        collection.getClass();
        Iterable iterable = collection;
        bk0 bk0 = this.f;
        bk0.getClass();
        int i = bk0.g;
        Iterator it = iterable.iterator();
        while (true) {
            int i2 = 1;
            int i3 = 0;
            if (!it.hasNext()) {
                break;
            }
            int numberOfTrailingZeros;
            Object next = it.next();
            int hashCode = (next != null ? next.hashCode() : 0) * -862048943;
            hashCode ^= hashCode << 16;
            int i4 = hashCode & 127;
            int i5 = bk0.f;
            hashCode = (hashCode >>> 7) & i5;
            while (true) {
                int i6;
                long[] jArr = bk0.a;
                int i7 = hashCode >> 3;
                int i8 = (hashCode & 7) << 3;
                long j = ((jArr[i7 + i2] << (64 - i8)) & ((-((long) i8)) >> 63)) | (jArr[i7] >>> i8);
                long j2 = (((long) i4) * 72340172838076673L) ^ j;
                j2 = ((~j2) & (j2 - 72340172838076673L)) & -9187201950435737472L;
                while (j2 != 0) {
                    numberOfTrailingZeros = ((Long.numberOfTrailingZeros(j2) >> 3) + hashCode) & i5;
                    i6 = i2;
                    if (k70.p(bk0.b[numberOfTrailingZeros], next)) {
                        break;
                    }
                    j2 &= j2 - 1;
                    i2 = i6;
                }
                i6 = i2;
                if (((j & ((~j) << 6)) & -9187201950435737472L) != 0) {
                    numberOfTrailingZeros = -1;
                    break;
                }
                i3 += 8;
                hashCode = (hashCode + i3) & i5;
                i2 = i6;
            }
            if (numberOfTrailingZeros >= 0) {
                bk0.h(numberOfTrailingZeros);
            }
        }
        return i != bk0.g;
    }

    public final boolean addAll(Collection collection) {
        collection.getClass();
        Iterable iterable = collection;
        bk0 bk0 = this.f;
        bk0.getClass();
        int i = bk0.g;
        for (Object next : iterable) {
            int d = bk0.d(next);
            bk0.b[d] = next;
            long[] jArr = bk0.c;
            int i2 = bk0.d;
            jArr[d] = (((long) i2) & 2147483647L) | 4611686016279904256L;
            if (i2 != Integer.MAX_VALUE) {
                jArr[i2] = ((2147483647L & ((long) d)) << 31) | (jArr[i2] & -4611686016279904257L);
            }
            bk0.d = d;
            if (bk0.e == Integer.MAX_VALUE) {
                bk0.e = d;
            }
        }
        return i != bk0.g;
    }

    public final boolean containsAll(Collection collection) {
        collection.getClass();
        for (Object c : collection) {
            if (this.e.c(c) == null) {
                return false;
            }
        }
        return true;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null) {
            if (dk0.class == obj.getClass()) {
                return k70.p(this.e, ((dk0) obj).e);
            }
        }
        return false;
    }

    public dk0(bk0 bk0) {
        bk0.getClass();
        this.e = bk0;
        this.f = bk0;
    }

    public final boolean isEmpty() {
        return this.e.g == 0;
    }

    public final boolean retainAll(Collection collection) {
        collection.getClass();
        return this.f.i(collection);
    }

    public final Object[] toArray(Object[] objArr) {
        objArr.getClass();
        return vd1.H(this, objArr);
    }

    public final boolean add(Object obj) {
        return this.f.a(obj);
    }

    public final boolean contains(Object obj) {
        return this.e.c(obj);
    }

    public final int hashCode() {
        return this.e.hashCode();
    }

    public final boolean remove(Object obj) {
        return ((AutofillManager) this.f);
    }

    public final String toString() {
        return this.e.toString();
    }

    public final void clear() {
        this.f.b();
    }

    public final Iterator iterator() {
        return new m10(this);
    }

    public final int size() {
        return this.e.g;
    }

    public final Object[] toArray() {
        return vd1.G(this);
    }
}