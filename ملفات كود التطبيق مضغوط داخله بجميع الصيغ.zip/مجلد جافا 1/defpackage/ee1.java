package defpackage;

import android.graphics.Typeface;
import android.graphics.fonts.Font;
import android.graphics.fonts.FontFamily.Builder;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;
import java.io.IOException;
import java.util.Objects;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ee1 */
public final class ee1 extends de1 {
    public final Font D(rz rzVar) {
        Uri uri = rzVar.a;
        boolean equals = Objects.equals(uri.getScheme(), "systemfont");
        String str = rzVar.e;
        String authority = equals ? uri.getAuthority() : null;
        if (authority != null) {
            Typeface create = Typeface.create(authority, 0);
            Typeface create2 = Typeface.create(Typeface.DEFAULT, 0);
            if (create == null || create.equals(create2)) {
                create = null;
            }
            if (create != null) {
                Font a = yd1.a(create);
                if (a != null) {
                    if (TextUtils.isEmpty(str)) {
                        return a;
                    }
                    try {
                        return new Builder(a).setFontVariationSettings(str).build();
                    } catch (IOException unused) {
                        Log.e("TypefaceCompatApi31Impl", "Failed to clone Font instance. Fall back to provider font.");
                        return null;
                    }
                }
            }
        }
        return null;
    }
}