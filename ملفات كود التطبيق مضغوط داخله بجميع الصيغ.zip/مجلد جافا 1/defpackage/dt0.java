package defpackage;

import java.util.ArrayList;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dt0 */
public final class dt0 {
    public final long a;
    public final long b;
    public final long c;
    public final boolean d;
    public final float e;
    public final long f;
    public final long g;
    public final boolean h;
    public final int i;
    public final long j;
    public final float k;
    public final long l;
    public final ArrayList m;
    public final long n;
    public boolean o;
    public boolean p;
    public dt0 q;

    public final String toString() {
        StringBuilder dl1 = new dl1("PointerInputChange(id=");
        dl1.append(sb0.u(this.a));
        dl1.append(", uptimeMillis=");
        dl1.append(this.b);
        dl1.append(", position=");
        dl1.append(xm0.h(this.c));
        dl1.append(", pressed=");
        dl1.append(this.d);
        dl1.append(", pressure=");
        dl1.append(this.e);
        dl1.append(", previousUptimeMillis=");
        dl1.append(this.f);
        dl1.append(", previousPosition=");
        dl1.append(xm0.h(this.g));
        dl1.append(", previousPressed=");
        dl1.append(this.h);
        dl1.append(", isConsumed=");
        dl1.append(b());
        dl1.append(", type=");
        dl1.append(lt0.a(this.i));
        dl1.append(", historical=");
        Object obj = this.m;
        if (obj == null) {
            obj = ut.e;
        }
        dl1.append(obj);
        dl1.append(", scrollDelta=");
        dl1.append(xm0.h(this.j));
        dl1.append(", scaleGestureFactor=");
        dl1.append(this.k);
        dl1.append(", panGestureOffset=");
        dl1.append(xm0.h(this.l));
        dl1.append(')');
        return dl1.toString();
    }

    public dt0(long j, long j2, long j3, boolean z, float f, long j4, long j5, boolean z2, boolean z3, int i, long j6, float f2, long j7) {
        this.a = j;
        this.b = j2;
        this.c = j3;
        this.d = z;
        this.e = f;
        this.f = j4;
        this.g = j5;
        this.h = z2;
        this.i = i;
        this.j = j6;
        this.k = f2;
        this.l = j7;
        this.n = 0;
        this.o = z3;
        this.p = z3;
    }

    public final boolean b() {
        dt0 dt0 = this.q;
        if (dt0 != null) {
            return dt0.b();
        }
        if (!this.o) {
            if (!this.p) {
                return false;
            }
        }
        return true;
    }

    public final void a() {
        dt0 dt0 = this.q;
        if (dt0 == null) {
            this.o = true;
            this.p = true;
            return;
        }
        if (dt0 != null) {
            dt0.a();
        }
    }

    public dt0(long j, long j2, long j3, boolean z, float f, long j4, long j5, boolean z2, int i, ArrayList arrayList, long j6, float f2, long j7, long j8) {
        this(j, j2, j3, z, f, j4, j5, z2, false, i, j6, f2, j7);
        this.m = arrayList;
        this.n = j8;
    }
}