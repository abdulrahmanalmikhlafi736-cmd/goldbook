package defpackage;

import java.lang.reflect.AccessibleObject;
import java.security.PrivilegedExceptionAction;
import sun.misc.Unsafe;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ef1 */
public final class ef1 implements PrivilegedExceptionAction {
    public static Unsafe a() {
        Class cls = Unsafe.class;
        for (AccessibleObject accessibleObject : cls.getDeclaredFields()) {
            accessibleObject.setAccessible(true);
            Object obj = accessibleObject.get(null);
            if (cls.isInstance(obj)) {
                return (Unsafe) cls.cast(obj);
            }
        }
        return null;
    }

    public final /* bridge */ /* synthetic */ Object run() {
        return ef1.a();
    }
}