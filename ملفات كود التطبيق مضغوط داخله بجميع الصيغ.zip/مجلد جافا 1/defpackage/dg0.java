package defpackage;

import java.util.LinkedHashMap;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dg0 */
public abstract class dg0 extends bg0 implements hh0 {
    public final gm0 s;
    public long t = 0;
    public LinkedHashMap u;
    public final eg0 v = new eg0(this);
    public nh0 w;
    public final zj0 x;

    public static final void n0(dg0 dg0, nh0 nh0) {
        if (nh0 != null) {
            long b = ((long) nh0.b()) & 4294967295L;
            dg0.S(b | (((long) nh0.e()) << 32));
        } else {
            dg0.S(0);
        }
        if (!(k70.p(dg0.w, nh0) || nh0 == null)) {
            LinkedHashMap linkedHashMap = dg0.u;
            if (!(((linkedHashMap == null || linkedHashMap.isEmpty()) && nh0.c().isEmpty()) || k70.p(nh0.c(), dg0.u))) {
                hg0 hg0 = dg0.s.s.K.q;
                hg0.getClass();
                hg0.u.f();
                a91 a91 = dg0.u;
                if (a91 == null) {
                    a91 = new LinkedHashMap();
                    dg0.u = a91;
                }
                a91.clear();
                a91.putAll(nh0.c());
            }
        }
        dg0.w = nh0;
    }

    public final void p0(long j) {
        if (!d90.a(this.t, j)) {
            this.t = j;
            gm0 gm0 = this.s;
            hg0 hg0 = gm0.s.K.q;
            if (hg0 != null) {
                hg0.Y();
            }
            bg0.k0(gm0);
        }
        if (!this.o) {
            Y(g0());
        }
    }

    public final long q0(dg0 dg0, boolean z) {
        long j = 0;
        a40 thisR;
        while (!thisR.equals(dg0)) {
            if (!thisR.m || !z) {
                j = n60.c(j, thisR.t);
            }
            gm0 gm0 = thisR.s.u;
            gm0.getClass();
            thisR = gm0.w0();
            thisR.getClass();
        }
        return j;
    }

    public dg0(gm0 gm0) {
        this.s = gm0;
        zj0 zj0 = sm0.a;
        this.x = new zj0();
    }

    public final bg0 a0() {
        gm0 gm0 = this.s.t;
        return gm0 != null ? gm0.w0() : null;
    }

    public final bg0 h0() {
        gm0 gm0 = this.s.u;
        return gm0 != null ? gm0.w0() : null;
    }

    public final void R(long j, float f, i00 i00) {
        p0(j);
        if (!this.n) {
            o0();
        }
    }

    public final nh0 g0() {
        nh0 nh0 = this.w;
        if (nh0 != null) {
            return nh0;
        }
        throw fu0.C("LookaheadDelegate has not been measured yet when measureResult is requested.");
    }

    public final boolean e0() {
        return this.w != null;
    }

    public final void m0() {
        R(this.t, 0.0f, null);
    }

    public void o0() {
        g0().a();
    }

    public final float a() {
        return this.s.a();
    }

    public final float g() {
        return this.s.g();
    }

    public final o90 getLayoutDirection() {
        return this.s.s.D;
    }

    public final Object i() {
        return this.s.i();
    }

    public final ba0 f0() {
        return this.s.s;
    }

    public final n90 d0() {
        return this.v;
    }

    public final long i0() {
        return this.t;
    }

    public final boolean n() {
        return true;
    }
}