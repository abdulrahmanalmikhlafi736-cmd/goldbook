package defpackage;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ek0 */
public final class ek0 {
    public final LinkedHashMap a;
    public final pg0 b;

    public final Map a() {
        Iterable<Entry> entrySet = this.a.entrySet();
        int y = ch0.y(ug.M(entrySet, 10));
        if (y < 16) {
            y = 16;
        }
        LinkedHashMap h90 = new h90(y);
        for (Entry entry : entrySet) {
            zp0 ad1;
            Object value = entry.getValue();
            if (value instanceof byte[]) {
                byte[] bArr = (byte[]) value;
                ad1 = new ad1(entry.getKey(), Arrays.copyOf(bArr, bArr.length));
            } else {
                ad1 = new ad1(entry.getKey(), entry.getValue());
            }
            h90.put(ad1.e, ad1.f);
        }
        Map unmodifiableMap = Collections.unmodifiableMap(h90);
        unmodifiableMap.getClass();
        return unmodifiableMap;
    }

    /* JADX WARNING: Removed duplicated region for block: B:30:0x0060 A:{SYNTHETIC} */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean equals(Object obj) {
        if (obj instanceof ek0) {
            LinkedHashMap linkedHashMap = ((ek0) obj).a;
            LinkedHashMap linkedHashMap2 = this.a;
            if (linkedHashMap != linkedHashMap2) {
                if (linkedHashMap.size() == linkedHashMap2.size()) {
                    if (!linkedHashMap.isEmpty()) {
                        for (Entry entry : linkedHashMap.entrySet()) {
                            boolean p;
                            Object obj2 = linkedHashMap2.get(entry.getKey());
                            if (obj2 != null) {
                                Object value = entry.getValue();
                                if (!(value instanceof byte[])) {
                                    p = k70.p(value, obj2);
                                    continue;
                                } else if ((obj2 instanceof byte[]) && Arrays.equals((byte[]) value, (byte[]) obj2)) {
                                    p = true;
                                    continue;
                                }
                                if (!p) {
                                }
                            }
                            p = false;
                            continue;
                            if (p) {
                            }
                        }
                    }
                }
            }
            return true;
        }
        return false;
    }

    public final void e(wt0 wt0, Object obj) {
        wt0.getClass();
        b();
        LinkedHashMap linkedHashMap = this.a;
        if (obj == null) {
            b();
            linkedHashMap.remove(wt0);
        } else if (obj instanceof Set) {
            Set unmodifiableSet = Collections.unmodifiableSet(tg.d0((Set) obj));
            unmodifiableSet.getClass();
            linkedHashMap.put(wt0, unmodifiableSet);
        } else if (obj instanceof byte[]) {
            byte[] bArr = (byte[]) obj;
            linkedHashMap.put(wt0, Arrays.copyOf(bArr, bArr.length));
        } else {
            linkedHashMap.put(wt0, obj);
        }
    }

    public final int hashCode() {
        int i = 0;
        for (Entry value : this.a.entrySet()) {
            Object value2 = value.getValue();
            i += value2 instanceof byte[] ? Arrays.hashCode((byte[]) value2) : value2.hashCode();
        }
        return i;
    }

    public final String toString() {
        return tg.V(this.a.entrySet(), ",\n", "{\n", "\n}", new h90(17), 24);
    }

    public final Object c(wt0 wt0) {
        wt0.getClass();
        Object obj = this.a.get(wt0);
        if (!(obj instanceof byte[])) {
            return obj;
        }
        byte[] bArr = (byte[]) obj;
        return Arrays.copyOf(bArr, bArr.length);
    }

    public final void b() {
        if (((AtomicBoolean) this.b.f).get()) {
            od.p("Do mutate preferences once returned to DataStore.");
        }
    }

    public ek0(LinkedHashMap linkedHashMap, boolean z) {
        this.a = linkedHashMap;
        this.b = new h80(z);
    }

    public final void d(wt0 wt0, Object obj) {
        wt0.getClass();
        e(wt0, obj);
    }

    public /* synthetic */ ek0(boolean z) {
        this(new LinkedHashMap(), z);
    }
}