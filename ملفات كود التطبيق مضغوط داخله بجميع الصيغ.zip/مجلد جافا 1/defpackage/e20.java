package defpackage;

import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;
import android.widget.Toast;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: e20 */
public final /* synthetic */ class e20 implements xz {
    public final /* synthetic */ int e;
    public final /* synthetic */ Context f;
    public final /* synthetic */ mk0 g;

    public final Object a() {
        int i = this.e;
        String str = ".LauncherAlias";
        we1 we1 = we1.a;
        mk0 mk0 = this.g;
        Context context = this.f;
        PackageManager packageManager;
        String packageName;
        StringBuilder stringBuilder;
        Boolean bool;
        Boolean bool2;
        switch (i) {
            case 0:
                Toast.makeText(context, context.getResources().getString(2131361939), 0).show();
                mk0.setValue("messages");
                return we1;
            case 1:
                mk0.setValue(Boolean.FALSE);
                try {
                    packageManager = context.getPackageManager();
                    packageName = context.getPackageName();
                    stringBuilder = new StringBuilder();
                    stringBuilder.append(packageName);
                    stringBuilder.append(str);
                    packageManager.setComponentEnabledSetting(new ComponentName(context, stringBuilder.toString()), 2, 1);
                    bool = Boolean.TRUE;
                } catch (Throwable th) {
                    bool = new px0(th);
                }
                bool2 = Boolean.FALSE;
                if (bool instanceof px0) {
                    bool = bool2;
                }
                bool = bool;
                return we1;
            default:
                if (mc0.q(context)) {
                    try {
                        packageManager = context.getPackageManager();
                        packageName = context.getPackageName();
                        stringBuilder = new StringBuilder();
                        stringBuilder.append(packageName);
                        stringBuilder.append(str);
                        packageManager.setComponentEnabledSetting(new ComponentName(context, stringBuilder.toString()), 1, 1);
                        bool = Boolean.TRUE;
                    } catch (Throwable th2) {
                        bool = new px0(th2);
                    }
                    bool2 = Boolean.FALSE;
                    if (bool instanceof px0) {
                        bool = bool2;
                    }
                    bool = bool;
                } else {
                    mk0.setValue(Boolean.TRUE);
                }
                return we1;
        }
    }

    public /* synthetic */ e20(Context context, mk0 mk0, int i) {
        this.e = i;
        this.f = context;
        this.g = mk0;
    }
}