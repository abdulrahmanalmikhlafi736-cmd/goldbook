package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: e80 */
public final class e80 extends ne {
    public final uh m;

    public final Throwable r(h80 h80) {
        uh uhVar = this.m;
        uhVar.getClass();
        Object obj = h80.e.get(uhVar);
        if (obj instanceof g80) {
            Throwable c = ((g80) obj).c();
            if (c != null) {
                return c;
            }
        }
        return obj instanceof xh ? ((xh) obj).a : h80.o();
    }

    public e80(ml mlVar, uh uhVar) {
        super(1, mlVar);
        this.m = uhVar;
    }

    public final String A() {
        return "AwaitContinuation";
    }
}