package defpackage;

import android.app.Activity;
import android.content.ContextWrapper;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Point;
import android.graphics.Rect;
import android.util.Log;
import android.view.Display;
import android.view.DisplayCutout;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import org.chromium.support_lib_boundary.StaticsBoundaryInterface;
import org.chromium.support_lib_boundary.WebkitToCompatConverterBoundaryInterface;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: e3 */
public final class e3 implements dc, rl, kp, vb0, nd, rx0, vi1, t61, i91 {
    public static final i5 A = new h90(2);
    public static final /* synthetic */ e3 B = new h90(8);
    public static final /* synthetic */ e3 C = new h90(9);
    public static final e3 D = new h90(10);
    public static final e3 E = new h90(11);
    public static final e3 F = new h90(12);
    public static final e3 G = new h90(13);
    public static final e3 H = new h90(14);
    public static final o90 I = o90.e;
    public static final mp J = new aj1(1.0f, 1.0f);
    public static final e3 K = new h90(15);
    public static final e3 L = new h90(16);
    public static final e3 M = new h90(17);
    public static final gw0 N = new gw0(Float.NaN, Float.NaN, Float.NaN, Float.NaN);
    public static final e3 O = new h90(19);
    public static final /* synthetic */ e3 P = new h90(20);
    public static final String[] Q = new String[0];
    public static final /* synthetic */ e3 R = new h90(22);
    public static final /* synthetic */ e3 S = new h90(23);
    public static final e3 T = new h90(24);
    public static final /* synthetic */ e3 U = new h90(25);
    public static final /* synthetic */ e3 V = new h90(26);
    public static final e3 W = new h90(27);
    public static final e3 X = new h90(28);
    public static final e3 Y = new h90(29);
    public static final nb f = new aj1(-1.0f, -1.0f);
    public static final nb g = new aj1(0.0f, -1.0f);
    public static final nb h = new aj1(1.0f, -1.0f);
    public static final nb i = new aj1(-1.0f, 0.0f);
    public static final nb j = new aj1(0.0f, 0.0f);
    public static final nb k = new aj1(1.0f, 0.0f);
    public static final nb l = new aj1(-1.0f, 1.0f);
    public static final nb m = new aj1(0.0f, 1.0f);
    public static final nb n = new aj1(1.0f, 1.0f);
    public static final mb o = new br0(-1.0f);
    public static final mb p = new br0(0.0f);
    public static final lb q = new br0(-1.0f);
    public static final lb r = new br0(0.0f);
    public static final lb s = new br0(1.0f);
    public static final e3 t = new h90(1);
    public static final e3 u = new h90(2);
    public static final e3 v = new h90(3);
    public static final e3 w = new h90(4);
    public static final e3 x = new h90(5);
    public static final od y = new h90(1);
    public static final i5 z = new h90(1);
    public final /* synthetic */ int e;

    public Rect g(Activity activity) {
        int i = this.e;
        String str = "android";
        String str2 = "dimen";
        String str3 = "navigation_bar_height";
        cc ccVar = dc.a;
        String str4 = "getBounds";
        String str5 = "windowConfiguration";
        Class cls = Configuration.class;
        DisplayCutout displayCutout = null;
        int i2 = 0;
        int i3;
        int i4;
        Rect rect;
        int identifier;
        Field declaredField;
        switch (i) {
            case 1:
                Display defaultDisplay = activity.getWindowManager().getDefaultDisplay();
                defaultDisplay.getClass();
                Point point = new Point();
                defaultDisplay.getRealSize(point);
                Rect rect2 = new Rect();
                i3 = point.x;
                if (i3 != 0) {
                    i4 = point.y;
                    if (i4 != 0) {
                        rect2.right = i3;
                        rect2.bottom = i4;
                        return rect2;
                    }
                }
                defaultDisplay.getRectSize(rect2);
                return rect2;
            case 2:
                rect = new Rect();
                Display defaultDisplay2 = activity.getWindowManager().getDefaultDisplay();
                defaultDisplay2.getRectSize(rect);
                if (!activity.isInMultiWindowMode()) {
                    Point point2 = new Point();
                    defaultDisplay2.getRealSize(point2);
                    Resources resources = activity.getResources();
                    identifier = resources.getIdentifier(str3, str2, str);
                    if (identifier > 0) {
                        i2 = resources.getDimensionPixelSize(identifier);
                    }
                    i4 = rect.bottom + i2;
                    if (i4 == point2.y) {
                        rect.bottom = i4;
                    } else {
                        i4 = rect.right + i2;
                        if (i4 == point2.x) {
                            rect.right = i4;
                        }
                    }
                }
                return rect;
            case 3:
                rect = new Rect();
                Configuration configuration = activity.getResources().getConfiguration();
                try {
                    Field declaredField2 = cls.getDeclaredField(str5);
                    declaredField2.setAccessible(true);
                    Object obj = declaredField2.get(configuration);
                    Object invoke;
                    if (activity.isInMultiWindowMode()) {
                        invoke = obj.getClass().getDeclaredMethod(str4, null).invoke(obj, null);
                        invoke.getClass();
                        rect.set((Rect) invoke);
                    } else {
                        invoke = obj.getClass().getDeclaredMethod("getAppBounds", null).invoke(obj, null);
                        invoke.getClass();
                        rect.set((Rect) invoke);
                    }
                } catch (Exception e) {
                    if (!((e instanceof NoSuchFieldException) || (e instanceof NoSuchMethodException) || (e instanceof IllegalAccessException))) {
                        if (!(e instanceof InvocationTargetException)) {
                            throw e;
                        }
                    }
                    ccVar.getClass();
                    Log.w(cc.b, e);
                    activity.getWindowManager().getDefaultDisplay().getRectSize(rect);
                }
                Display defaultDisplay3 = activity.getWindowManager().getDefaultDisplay();
                Point point3 = new Point();
                defaultDisplay3.getRealSize(point3);
                if (!activity.isInMultiWindowMode()) {
                    Resources resources2 = activity.getResources();
                    identifier = resources2.getIdentifier(str3, str2, str);
                    identifier = identifier > 0 ? resources2.getDimensionPixelSize(identifier) : 0;
                    i3 = rect.bottom + identifier;
                    if (i3 == point3.y) {
                        rect.bottom = i3;
                    } else {
                        i3 = rect.right + identifier;
                        if (i3 == point3.x) {
                            rect.right = i3;
                        } else if (rect.left == identifier) {
                            rect.left = 0;
                        }
                    }
                }
                if ((rect.width() < point3.x || rect.height() < point3.y) && !activity.isInMultiWindowMode()) {
                    try {
                        Constructor constructor = Class.forName("android.view.DisplayInfo").getConstructor(null);
                        constructor.setAccessible(true);
                        Object newInstance = constructor.newInstance(null);
                        Method declaredMethod = defaultDisplay3.getClass().getDeclaredMethod("getDisplayInfo", new Class[]{newInstance.getClass()});
                        declaredMethod.setAccessible(true);
                        declaredMethod.invoke(defaultDisplay3, new Object[]{newInstance});
                        declaredField = newInstance.getClass().getDeclaredField("displayCutout");
                        declaredField.setAccessible(true);
                        newInstance = declaredField.get(newInstance);
                        if ((newInstance instanceof DisplayCutout)) {
                            displayCutout = a01.e(newInstance);
                        }
                    } catch (Exception e2) {
                        if (!((e2 instanceof ClassNotFoundException) || (e2 instanceof NoSuchMethodException) || (e2 instanceof NoSuchFieldException) || (e2 instanceof IllegalAccessException) || (e2 instanceof InvocationTargetException))) {
                            if (!(e2 instanceof InstantiationException)) {
                                throw e2;
                            }
                        }
                        ccVar.getClass();
                        Log.w(cc.b, e2);
                    }
                    if (displayCutout != null) {
                        if (rect.left == displayCutout.getSafeInsetLeft()) {
                            rect.left = 0;
                        }
                        if (point3.x - rect.right == displayCutout.getSafeInsetRight()) {
                            rect.right = displayCutout.getSafeInsetRight() + rect.right;
                        }
                        if (rect.top == displayCutout.getSafeInsetTop()) {
                            rect.top = 0;
                        }
                        if (point3.y - rect.bottom == displayCutout.getSafeInsetBottom()) {
                            rect.bottom = displayCutout.getSafeInsetBottom() + rect.bottom;
                        }
                    }
                }
                return rect;
            default:
                Rect bcVar;
                Configuration configuration2 = activity.getResources().getConfiguration();
                try {
                    declaredField = cls.getDeclaredField(str5);
                    declaredField.setAccessible(true);
                    Object obj2 = declaredField.get(configuration2);
                    obj2 = obj2.getClass().getDeclaredMethod(str4, null).invoke(obj2, null);
                    obj2.getClass();
                    bcVar = new bc((Rect) obj2);
                } catch (Exception e3) {
                    if (!((e3 instanceof NoSuchFieldException) || (e3 instanceof NoSuchMethodException) || (e3 instanceof IllegalAccessException))) {
                        if (!(e3 instanceof InvocationTargetException)) {
                            throw e3;
                        }
                    }
                    ccVar.getClass();
                    Log.w(cc.b, e3);
                    bcVar = v.g(activity);
                }
                return bcVar;
        }
    }

    public String toString() {
        switch (this.e) {
            case 28:
                return "NeverEqualPolicy";
            default:
                return super.toString();
        }
    }

    public float h(ContextWrapper contextWrapper) {
        return contextWrapper.getResources().getDisplayMetrics().density;
    }

    public StaticsBoundaryInterface getStatics() {
        throw new dl1("This should never happen, if this method was called it means we're trying to reach into WebView APK code on an incompatible device. This most likely means the current method is being called too early, or is being called on start-up rather than lazily");
    }

    public WebkitToCompatConverterBoundaryInterface getWebkitToCompatConverter() {
        throw new dl1("This should never happen, if this method was called it means we're trying to reach into WebView APK code on an incompatible device. This most likely means the current method is being called too early, or is being called on start-up rather than lazily");
    }

    public /* synthetic */ e3(int i) {
        this.e = i;
    }

    public long b() {
        return 9205357640488583168L;
    }

    public mi0 j(nb nbVar) {
        return new fc(nbVar);
    }

    public void f(h91 h91) {
        h91.clear();
    }

    public jp a() {
        return J;
    }

    public String[] e() {
        return Q;
    }

    public o90 getLayoutDirection() {
        return I;
    }

    public void c(Object obj, Object obj2) {
    }

    public boolean i(Object obj, Object obj2) {
        return false;
    }

    public void cancel() {
    }

    public void d() {
    }
}