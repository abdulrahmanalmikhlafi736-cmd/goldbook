package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ea0 */
public abstract class ea0 {
    public static final mp a = vd1.b();

    public static final lp0 a(ba0 ba0) {
        lp0 lp0 = ba0.r;
        if (lp0 != null) {
            return lp0;
        }
        throw fu0.C("LayoutNode should be attached to an owner");
    }
}