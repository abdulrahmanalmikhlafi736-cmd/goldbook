package defpackage;

import android.view.GestureDetector.OnGestureListener;
import android.view.MotionEvent;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: e50 */
public final class e50 implements OnGestureListener {
    public final /* synthetic */ f50 a;

    public final boolean onFling(MotionEvent motionEvent, MotionEvent motionEvent2, float f, float f2) {
        f50 f50 = this.a;
        j4 j4Var = f50.a;
        if (!f50.c) {
            int i = f50.b;
            int i2 = 2;
            if (i == 1) {
                if (Math.abs(f) > Math.abs(f2)) {
                    if (f > 0.0f) {
                        i2 = 1;
                    }
                    j4Var.i(new h90(i2));
                    return true;
                }
            } else if (i == 2 && Math.abs(f2) > Math.abs(f)) {
                if (f2 > 0.0f) {
                    i2 = 1;
                }
                j4Var.i(new h90(i2));
            }
        }
        return true;
    }

    public e50(f50 f50) {
        this.a = f50;
    }

    public final boolean onDown(MotionEvent motionEvent) {
        return true;
    }

    public final boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent2, float f, float f2) {
        return true;
    }

    public final boolean onSingleTapUp(MotionEvent motionEvent) {
        return true;
    }

    public final void onLongPress(MotionEvent motionEvent) {
    }

    public final void onShowPress(MotionEvent motionEvent) {
    }
}