package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ep0 */
public final class ep0 extends jb0 {
    public final gw0 b;

    /* JADX WARNING: Missing block: B:6:0x0012, code:
            if (r1.b.equals(((defpackage.ep0) r2).b) == false) goto L_0x0014;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean equals(Object obj) {
        if (this != obj) {
            if (obj instanceof ep0) {
            }
            return false;
        }
        return true;
    }

    public final int hashCode() {
        return this.b.hashCode();
    }

    public ep0(gw0 gw0) {
        this.b = gw0;
    }

    public final gw0 k() {
        return this.b;
    }
}