package defpackage;

import java.util.Random;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dv */
public final class dv extends d0 {
    public final b7 f = new h90(1);

    public final Random a() {
        Object obj = this.f.get();
        obj.getClass();
        return (Random) obj;
    }
}