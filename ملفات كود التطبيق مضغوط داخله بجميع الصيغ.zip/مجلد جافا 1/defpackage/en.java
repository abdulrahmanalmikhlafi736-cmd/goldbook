package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: en */
public final class en extends u91 implements n00 {
    public final /* synthetic */ int i = 1;
    public int j;
    public /* synthetic */ Object k;

    public final Object p(Object obj) {
        int i = this.i;
        String str = "call to 'resume' before 'invoke' with coroutine";
        Object obj2 = cm.e;
        switch (i) {
            case 0:
                i = this.j;
                if (i == 0) {
                    nb0.t(obj);
                    tn tnVar = (tn) this.k;
                    this.j = 1;
                    if (tn.a(tnVar, this) == obj2) {
                        return obj2;
                    }
                } else if (i == 1) {
                    nb0.t(obj);
                } else {
                    od.p(str);
                    obj2 = null;
                    return obj2;
                }
                obj2 = we1.a;
                return obj2;
            default:
                i = this.j;
                if (i == 0) {
                    nb0.t(obj);
                    obj = (mv) this.k;
                    this.j = 1;
                    if (obj.b.get()) {
                        od.p("This scope has already been closed.");
                    } else {
                        obj = vd1.c(obj.a, new ao(obj, null, 1), this);
                        if (obj == obj2) {
                            obj = obj2;
                        }
                        return obj;
                    }
                } else if (i == 1) {
                    nb0.t(obj);
                    return obj;
                } else {
                    od.p(str);
                }
                obj = null;
                return obj;
        }
    }

    public final Object c(Object obj, Object obj2, Object obj3) {
        int i = this.i;
        we1 we1 = we1.a;
        switch (i) {
            case 0:
                uw uwVar = (uw) obj;
                Throwable th = (Throwable) obj2;
                return new en((tn) this.k, (ml) obj3).p(we1);
            default:
                mv mvVar = (mv) obj;
                ((Boolean) obj2).getClass();
                this = new en(3, (ml) obj3);
                this.k = mvVar;
                return this.p(we1);
        }
    }

    public en(tn tnVar, ml mlVar) {
        this.k = tnVar;
        super(3, mlVar);
    }
}