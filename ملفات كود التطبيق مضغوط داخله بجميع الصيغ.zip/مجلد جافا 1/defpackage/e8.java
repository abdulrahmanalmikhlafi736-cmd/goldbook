package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: e8 */
public final class e8 extends h90 implements m00 {
    public final /* synthetic */ ed1 f;
    public final /* synthetic */ i00 g;
    public final /* synthetic */ mi0 h;
    public final /* synthetic */ ju i;
    public final /* synthetic */ wu j;
    public final /* synthetic */ m00 k;
    public final /* synthetic */ pi l;
    public final /* synthetic */ int m;

    public final Object f(Object obj, Object obj2) {
        d10 d10 = (d10) obj;
        ((Number) obj2).intValue();
        gh0.a(this.f, this.g, this.h, this.i, this.j, this.k, this.l, d10, wc0.s(this.m | 1));
        return we1.a;
    }

    public e8(ed1 ed1, i00 i00, mi0 mi0, ju juVar, wu wuVar, m00 m00, pi piVar, int i) {
        this.f = ed1;
        this.g = i00;
        this.h = mi0;
        this.i = juVar;
        this.j = wuVar;
        this.k = m00;
        this.l = piVar;
        this.m = i;
        super(2);
    }
}