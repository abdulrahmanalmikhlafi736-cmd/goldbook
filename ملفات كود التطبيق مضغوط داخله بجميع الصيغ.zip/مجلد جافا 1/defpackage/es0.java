package defpackage;

import androidx.core.content.FileProvider;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.ListIterator;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: es0 */
public final class es0 extends z implements Collection, w80 {
    public c0 e;
    public Object[] f;
    public Object[] g;
    public int h;
    public vj i = new h90(20);
    public Object[] j;
    public Object[] k;
    public int l;

    /* JADX WARNING: Removed duplicated region for block: B:37:0x00d3  */
    /* JADX WARNING: Missing block: B:3:0x0016, code:
            if (y(r1, r8, r5) != r8) goto L_0x0018;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean z(i00 i00) {
        i00 i002 = i00;
        int F = F();
        Object[] objArr = null;
        k1 k1Var = new k1(null);
        boolean z = false;
        if (this.j != null) {
            w k = k(0);
            int i = 32;
            while (i == 32 && k.hasNext()) {
                i = x(i002, (Object[]) k.next(), 32, k1Var);
            }
            if (i == 32) {
                i = y(i002, F, k1Var);
                if (i == 0) {
                    r(this.j, this.l, this.h);
                }
                if (i != F) {
                }
                if (z) {
                    this.modCount++;
                }
                return z;
            }
            int i2 = (k.e - 1) << 5;
            ArrayList arrayList = new ArrayList();
            ArrayList arrayList2 = new ArrayList();
            int i3 = i;
            while (k.hasNext()) {
                i3 = w(i002, (Object[]) k.next(), 32, i3, k1Var, arrayList2, arrayList);
                i002 = i00;
            }
            int w = w(i00, this.k, F, i3, k1Var, arrayList2, arrayList);
            Object obj = k1Var.a;
            obj.getClass();
            Object[] objArr2 = (Object[]) obj;
            Arrays.fill(objArr2, w, 32, null);
            boolean isEmpty = arrayList.isEmpty();
            Object[] objArr3 = this.j;
            if (isEmpty) {
                objArr3.getClass();
            } else {
                objArr3 = s(objArr3, i2, this.h, arrayList.iterator());
            }
            i2 += arrayList.size() << 5;
            if ((i2 & 31) != 0) {
                FileProvider.a("invalid size");
            }
            if (i2 == 0) {
                this.h = 0;
            } else {
                int i4;
                int i5 = i2 - 1;
                while (true) {
                    i4 = this.h;
                    if ((i5 >> i4) != 0) {
                        break;
                    }
                    this.h = i4 - 5;
                    Object obj2 = objArr3[0];
                    obj2.getClass();
                    objArr3 = (Object[]) obj2;
                }
                objArr = p(objArr3, i5, i4);
            }
            this.j = objArr;
            this.k = objArr2;
            this.l = i2 + w;
        }
        z = true;
        if (z) {
        }
        return z;
    }

    public final boolean addAll(int i, Collection collection) {
        kb0.g(i, this.l);
        if (i == this.l) {
            return addAll(collection);
        }
        if (collection.isEmpty()) {
            return false;
        }
        this.modCount++;
        int i2 = (i >> 5) << 5;
        int size = ((collection.size() + (this.l - i2)) - 1) / 32;
        if (size == 0) {
            i2 = i & 31;
            i = ((collection.size() + i) - 1) & 31;
            Object[] objArr = this.k;
            Object[] l = l(objArr);
            ba.Y(objArr, l, i + 1, i2, F());
            es0.e(l, i2, collection.iterator());
            this.k = l;
            this.l = collection.size() + this.l;
            return true;
        }
        Object[] n;
        Collection collection2;
        Object[][] objArr2 = new Object[size][];
        int F = F();
        int size2 = collection.size() + this.l;
        if (size2 > 32) {
            size2 -= (size2 - 1) & -32;
        }
        if (i >= C()) {
            n = n();
            collection2 = collection;
            int i3 = size;
            Object[][] objArr3 = objArr2;
            E(collection2, i, this.k, F, objArr3, i3, n);
            objArr2 = objArr3;
        } else {
            collection2 = collection;
            Object[] objArr4 = this.k;
            int i4;
            if (size2 > F) {
                i4 = size2 - F;
                Object[] m = m(i4, objArr4);
                Object[][] objArr5 = objArr2;
                g(collection2, i, i4, objArr5, size, m);
                objArr2 = objArr5;
                n = m;
            } else {
                n = n();
                int i5 = F - size2;
                ba.Y(objArr4, n, 0, i5, F);
                int i6 = 32 - i5;
                Object[] m2 = m(i6, this.k);
                i4 = size - 1;
                objArr2[i4] = m2;
                Collection collection3 = collection2;
                int i7 = i6;
                g(collection3, i, i7, objArr2, i4, m2);
                collection2 = collection3;
            }
        }
        this.j = t(this.j, i2, objArr2);
        this.k = n;
        this.l = collection2.size() + this.l;
        return true;
    }

    public final void g(Collection collection, int i, int i2, Object[][] objArr, int i3, Object[] objArr2) {
        if (this.j != null) {
            Object[] objArr3;
            int i4 = i >> 5;
            w k = k(C() >> 5);
            int i5 = i3;
            Object[] objArr4 = objArr2;
            while (k.e - 1 != i4) {
                objArr3 = (Object[]) k.previous();
                ba.Y(objArr3, objArr4, 0, 32 - i2, 32);
                objArr4 = m(i2, objArr3);
                i5--;
                objArr[i5] = objArr4;
            }
            objArr3 = (Object[]) k.previous();
            int C = i3 - (((C() >> 5) - 1) - i4);
            if (C < i3) {
                objArr2 = objArr[C];
                objArr2.getClass();
            }
            E(collection, i, objArr3, 32, objArr, C, objArr2);
            return;
        }
        od.p("root is null");
    }

    public final void E(Collection collection, int i, Object[] objArr, int i2, Object[][] objArr2, int i3, Object[] objArr3) {
        int i4 = 1;
        if (i3 < 1) {
            FileProvider.a("requires at least one nullBuffer");
        }
        objArr = l(objArr);
        objArr2[0] = objArr;
        int i5 = i & 31;
        i = ((collection.size() + i) - 1) & 31;
        int i6 = (i2 - i5) + i;
        if (i6 < 32) {
            ba.Y(objArr, objArr3, i + 1, i5, i2);
        } else {
            Object[] objArr4;
            i6 -= 31;
            if (i3 == 1) {
                objArr4 = objArr;
            } else {
                objArr4 = n();
                i3--;
                objArr2[i3] = objArr4;
            }
            i6 = i2 - i6;
            ba.Y(objArr, objArr3, 0, i6, i2);
            ba.Y(objArr, objArr4, i + 1, i5, i6);
            objArr3 = objArr4;
        }
        Iterator it = collection.iterator();
        es0.e(objArr, i5, it);
        while (i4 < i3) {
            Object[] n = n();
            es0.e(n, 0, it);
            objArr2[i4] = n;
            i4++;
        }
        es0.e(objArr3, 0, it);
    }

    public final Object[] A(Object[] objArr, int i, int i2, k1 k1Var) {
        int q = ua0.q(i2, i);
        int i3 = 31;
        if (i == 0) {
            Object obj = objArr[q];
            Object[] l = l(objArr);
            ba.Y(objArr, l, q, q + 1, 32);
            l[31] = k1Var.a;
            k1Var.a = obj;
            return l;
        }
        if (objArr[31] == null) {
            i3 = ua0.q(C() - 1, i);
        }
        objArr = l(objArr);
        i -= 5;
        int i4 = q + 1;
        if (i4 <= i3) {
            while (true) {
                Object obj2 = objArr[i3];
                obj2.getClass();
                objArr[i3] = A((Object[]) obj2, i, 0, k1Var);
                if (i3 == i4) {
                    break;
                }
                i3--;
            }
        }
        Object obj3 = objArr[q];
        obj3.getClass();
        objArr[q] = A((Object[]) obj3, i, i2, k1Var);
        return objArr;
    }

    public final int w(i00 i00, Object[] objArr, int i, int i2, k1 k1Var, ArrayList arrayList, ArrayList arrayList2) {
        if (j(objArr)) {
            arrayList.add(objArr);
        }
        Object obj = k1Var.a;
        obj.getClass();
        obj = (Object[]) obj;
        Object obj2 = obj;
        for (int i3 = 0; i3 < i; i3++) {
            Object obj3 = objArr[i3];
            if (!((Boolean) i00.i(obj3)).booleanValue()) {
                if (i2 == 32) {
                    obj2 = !arrayList.isEmpty() ? (Object[]) arrayList.remove(arrayList.size() - 1) : n();
                    i2 = 0;
                }
                int i4 = i2 + 1;
                obj2[i2] = obj3;
                i2 = i4;
            }
        }
        k1Var.a = obj2;
        if (obj != obj2) {
            arrayList2.add(obj);
        }
        return i2;
    }

    public final Object[] s(Object[] objArr, int i, int i2, Iterator it) {
        if (!it.hasNext()) {
            FileProvider.a("invalid buffersIterator");
        }
        if ((i2 >= 0 ? 1 : 0) == 0) {
            FileProvider.a("negative shift");
        }
        if (i2 == 0) {
            return (Object[]) it.next();
        }
        objArr = l(objArr);
        int q = ua0.q(i, i2);
        i2 -= 5;
        objArr[q] = s((Object[]) objArr[q], i, i2, it);
        while (true) {
            q++;
            if (q >= 32 || !it.hasNext()) {
                return objArr;
            }
            objArr[q] = s((Object[]) objArr[q], 0, i2, it);
        }
        return objArr;
    }

    public final Object[] h(Object[] objArr, int i, int i2, Object obj, k1 k1Var) {
        int q = ua0.q(i2, i);
        if (i == 0) {
            k1Var.a = objArr[31];
            Object[] l = l(objArr);
            ba.Y(objArr, l, q + 1, q, 31);
            l[q] = obj;
            return l;
        }
        objArr = l(objArr);
        int i3 = i - 5;
        Object obj2 = objArr[q];
        obj2.getClass();
        k1 k1Var2 = k1Var;
        objArr[q] = h((Object[]) obj2, i3, i2, obj, k1Var2);
        while (true) {
            q++;
            if (q >= 32) {
                break;
            }
            Object obj3 = objArr[q];
            if (obj3 == null) {
                break;
            }
            objArr[q] = h((Object[]) obj3, i3, 0, k1Var2.a, k1Var2);
        }
        return objArr;
    }

    public final Object[] p(Object[] objArr, int i, int i2) {
        if (i2 < 0) {
            FileProvider.a("shift should be positive");
        }
        if (i2 == 0) {
            return objArr;
        }
        int q = ua0.q(i, i2);
        Object obj = objArr[q];
        obj.getClass();
        Object p = p((Object[]) obj, i, i2 - 5);
        if (q < 31) {
            i2 = q + 1;
            if (objArr[i2] != null) {
                if (j(objArr)) {
                    Arrays.fill(objArr, i2, 32, null);
                }
                Object[] n = n();
                ba.Y(objArr, n, 0, 0, i2);
                objArr = n;
            }
        }
        if (p == objArr[q]) {
            return objArr;
        }
        Object[] l = l(objArr);
        l[q] = p;
        return l;
    }

    public final void r(Object[] objArr, int i, int i2) {
        if (i2 == 0) {
            this.j = null;
            if (objArr == null) {
                objArr = new Object[0];
            }
            this.k = objArr;
            this.l = i;
            this.h = i2;
            return;
        }
        k1 k1Var = new k1(null);
        objArr.getClass();
        objArr = q(objArr, i2, i, k1Var);
        objArr.getClass();
        Object obj = k1Var.a;
        obj.getClass();
        this.k = (Object[]) obj;
        this.l = i;
        if (objArr[1] == null) {
            this.j = (Object[]) objArr[0];
            this.h = i2 - 5;
            return;
        }
        this.j = objArr;
        this.h = i2;
    }

    public final void add(int i, Object obj) {
        kb0.g(i, a());
        if (i == a()) {
            add(obj);
            return;
        }
        this.modCount++;
        int C = C();
        if (i >= C) {
            i(this.j, i - C, obj);
            return;
        }
        k1 k1Var = new k1(null);
        Object[] objArr = this.j;
        objArr.getClass();
        i(h(objArr, this.h, i, obj, k1Var), 0, k1Var.a);
    }

    public final c0 c() {
        c0 c0Var;
        Object[] objArr = this.j;
        if (objArr == this.f && this.k == this.g) {
            c0Var = this.e;
        } else {
            this.i = new h90(20);
            this.f = objArr;
            Object[] objArr2 = this.k;
            this.g = objArr2;
            c0Var = objArr == null ? objArr2.length == 0 ? b61.f : new b61(Arrays.copyOf(objArr2, this.l)) : new ds0(objArr, objArr2, this.l, this.h);
        }
        this.e = c0Var;
        return c0Var;
    }

    public final Object set(int i, Object obj) {
        vd1.f(i, a());
        if (C() <= i) {
            Object[] l = l(this.k);
            if (l != this.k) {
                this.modCount++;
            }
            i &= 31;
            Object obj2 = l[i];
            l[i] = obj;
            this.k = l;
            return obj2;
        }
        k1 k1Var = new k1(null);
        Object[] objArr = this.j;
        objArr.getClass();
        this.j = D(objArr, this.h, i, obj, k1Var);
        return k1Var.a;
    }

    public final void u(Object[] objArr, Object[] objArr2, Object[] objArr3) {
        int i = this.l;
        int i2 = i >> 5;
        int i3 = this.h;
        if (i2 > (1 << i3)) {
            this.j = v(this.h + 5, o(objArr), objArr2);
            this.k = objArr3;
            this.h += 5;
            this.l++;
        } else if (objArr == null) {
            this.j = objArr2;
            this.k = objArr3;
            this.l = i + 1;
        } else {
            this.j = v(i3, objArr, objArr2);
            this.k = objArr3;
            this.l++;
        }
    }

    public final Object b(int i) {
        vd1.f(i, a());
        this.modCount++;
        int C = C();
        if (i >= C) {
            return B(this.j, C, this.h, i - C);
        }
        k1 k1Var = new k1(this.k[0]);
        Object[] objArr = this.j;
        objArr.getClass();
        B(A(objArr, this.h, i, k1Var), C, this.h, 0);
        return k1Var.a;
    }

    public final void i(Object[] objArr, int i, Object obj) {
        int F = F();
        Object[] l = l(this.k);
        Object[] objArr2 = this.k;
        if (F < 32) {
            ba.Y(objArr2, l, i + 1, i, F);
            l[i] = obj;
            this.j = objArr;
            this.k = l;
            this.l++;
            return;
        }
        Object obj2 = objArr2[31];
        ba.Y(objArr2, l, i + 1, i, 31);
        l[i] = obj;
        u(objArr, l, o(obj2));
    }

    public final Object[] t(Object[] objArr, int i, Object[][] objArr2) {
        s sVar = new s((Object[]) objArr2);
        int i2 = i >> 5;
        int i3 = this.h;
        Object s = i2 < (1 << i3) ? s(objArr, i, i3, sVar) : l(objArr);
        while (sVar.hasNext()) {
            this.h += 5;
            s = o(s);
            i = this.h;
            s(s, 1 << i, i, sVar);
        }
        return s;
    }

    public final Object[] D(Object[] objArr, int i, int i2, Object obj, k1 k1Var) {
        int q = ua0.q(i2, i);
        Object[] l = l(objArr);
        if (i == 0) {
            if (l != objArr) {
                this.modCount++;
            }
            k1Var.a = l[q];
            l[q] = obj;
            return l;
        }
        Object obj2 = l[q];
        obj2.getClass();
        l[q] = D((Object[]) obj2, i - 5, i2, obj, k1Var);
        return l;
    }

    public final Object get(int i) {
        Object[] objArr;
        vd1.f(i, a());
        if (C() <= i) {
            objArr = this.k;
        } else {
            Object[] objArr2 = this.j;
            objArr2.getClass();
            for (int i2 = this.h; i2 > 0; i2 -= 5) {
                Object obj = objArr2[ua0.q(i, i2)];
                obj.getClass();
                objArr2 = (Object[]) obj;
            }
            objArr = objArr2;
        }
        return objArr[i & 31];
    }

    public final Object B(Object[] objArr, int i, int i2, int i3) {
        int i4 = this.l - i;
        Object[] objArr2 = this.k;
        if (i4 == 1) {
            Object obj = objArr2[0];
            r(objArr, i, i2);
            return obj;
        }
        Object obj2 = objArr2[i3];
        Object[] l = l(objArr2);
        ba.Y(objArr2, l, i3, i3 + 1, i4);
        l[i4 - 1] = null;
        this.j = objArr;
        this.k = l;
        this.l = (i + i4) - 1;
        this.h = i2;
        return obj2;
    }

    public final int x(i00 i00, Object[] objArr, int i, k1 k1Var) {
        int i2 = 0;
        Object[] objArr2 = objArr;
        int i3 = i;
        int i4 = 0;
        while (i2 < i) {
            Object obj = objArr[i2];
            if (((Boolean) i00.i(obj)).booleanValue()) {
                if (i4 == 0) {
                    objArr2 = l(objArr);
                    i4 = 1;
                    i3 = i2;
                }
            } else if (i4 != 0) {
                int i5 = i3 + 1;
                objArr2[i3] = obj;
                i3 = i5;
            }
            i2++;
        }
        k1Var.a = objArr2;
        return i3;
    }

    public final Object[] q(Object[] objArr, int i, int i2, k1 k1Var) {
        Object[] objArr2;
        int q = ua0.q(i2 - 1, i);
        if (i == 5) {
            k1Var.a = objArr[q];
            objArr2 = null;
        } else {
            Object obj = objArr[q];
            obj.getClass();
            objArr2 = q((Object[]) obj, i - 5, i2, k1Var);
        }
        if (objArr2 == null && q == 0) {
            return null;
        }
        Object[] l = l(objArr);
        l[q] = objArr2;
        return l;
    }

    public final w k(int i) {
        Object[] objArr = this.j;
        if (objArr != null) {
            int C = C() >> 5;
            kb0.g(i, C);
            int i2 = this.h;
            return i2 == 0 ? new fd(i, objArr) : new nd1(objArr, i, C, i2 / 5);
        } else {
            od.p("Invalid root");
            return null;
        }
    }

    public final Object[] v(int i, Object[] objArr, Object[] objArr2) {
        int q = ua0.q(a() - 1, i);
        objArr = l(objArr);
        if (i == 5) {
            objArr[q] = objArr2;
            return objArr;
        }
        objArr[q] = v(i - 5, (Object[]) objArr[q], objArr2);
        return objArr;
    }

    public es0(c0 c0Var, Object[] objArr, Object[] objArr2, int i) {
        this.e = c0Var;
        this.f = objArr;
        this.g = objArr2;
        this.h = i;
        this.j = objArr;
        this.k = objArr2;
        this.l = c0Var.a();
    }

    public final Object[] l(Object[] objArr) {
        if (objArr == null) {
            return n();
        }
        if (j(objArr)) {
            return objArr;
        }
        Object[] n = n();
        int length = objArr.length;
        if (length > 32) {
            length = 32;
        }
        ba.a0(objArr, n, 0, length, 6);
        return n;
    }

    public final int y(i00 i00, int i, k1 k1Var) {
        int x = x(i00, this.k, i, k1Var);
        Object obj = k1Var.a;
        if (x == i) {
            return i;
        }
        obj.getClass();
        Object[] objArr = (Object[]) obj;
        Arrays.fill(objArr, x, i, null);
        this.k = objArr;
        this.l -= i - x;
        return x;
    }

    public final Object[] m(int i, Object[] objArr) {
        if (j(objArr)) {
            ba.Y(objArr, objArr, i, 0, 32 - i);
            return objArr;
        }
        Object[] n = n();
        ba.Y(objArr, n, i, 0, 32 - i);
        return n;
    }

    public static void e(Object[] objArr, int i, Iterator it) {
        while (i < 32 && it.hasNext()) {
            int i2 = i + 1;
            objArr[i] = it.next();
            i = i2;
        }
    }

    public final boolean j(Object[] objArr) {
        return objArr.length == 33 && objArr[32] == this.i;
    }

    public final boolean addAll(Collection collection) {
        if (collection.isEmpty()) {
            return false;
        }
        this.modCount++;
        int F = F();
        Iterator it = collection.iterator();
        if (32 - F >= collection.size()) {
            Object[] l = l(this.k);
            es0.e(l, F, it);
            this.k = l;
            this.l = collection.size() + this.l;
            return true;
        }
        int size = ((collection.size() + F) - 1) / 32;
        Object[][] objArr = new Object[size][];
        Object[] l2 = l(this.k);
        es0.e(l2, F, it);
        objArr[0] = l2;
        for (F = 1; F < size; F++) {
            l2 = n();
            es0.e(l2, 0, it);
            objArr[F] = l2;
        }
        this.j = t(this.j, C(), objArr);
        Object[] n = n();
        es0.e(n, 0, it);
        this.k = n;
        this.l = collection.size() + this.l;
        return true;
    }

    public final Object[] o(Object obj) {
        Object[] objArr = new Object[33];
        objArr[0] = obj;
        objArr[32] = this.i;
        return objArr;
    }

    public final int C() {
        int i = this.l;
        return i <= 32 ? 0 : (i - 1) & -32;
    }

    public final int F() {
        int i = this.l;
        return i <= 32 ? i : i - ((i - 1) & -32);
    }

    public final ListIterator listIterator(int i) {
        kb0.g(i, this.l);
        return new gs0(this, i);
    }

    public final Object[] n() {
        Object[] objArr = new Object[33];
        objArr[32] = this.i;
        return objArr;
    }

    public final boolean removeAll(Collection collection) {
        return z(new b0(1, collection));
    }

    public final boolean add(Object obj) {
        this.modCount++;
        int F = F();
        if (F < 32) {
            Object[] l = l(this.k);
            l[F] = obj;
            this.k = l;
            this.l = a() + 1;
        } else {
            u(this.j, this.k, o(obj));
        }
        return true;
    }

    public final Iterator iterator() {
        return listIterator(0);
    }

    public final int a() {
        return this.l;
    }

    public final int f() {
        return this.modCount;
    }

    public final ListIterator listIterator() {
        return listIterator(0);
    }
}