package defpackage;

import android.graphics.Paint.FontMetricsInt;
import android.text.style.LineHeightSpan;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: de0 */
public final class de0 implements LineHeightSpan {
    public final float e;

    public final void chooseHeight(CharSequence charSequence, int i, int i2, int i3, int i4, FontMetricsInt fontMetricsInt) {
        int i5 = fontMetricsInt.descent - fontMetricsInt.ascent;
        if (i5 > 0) {
            int ceil = (int) ((float) Math.ceil((double) this.e));
            i5 = (int) Math.ceil(((double) fontMetricsInt.descent) * ((double) ((((float) ceil) * 1.0f) / ((float) i5))));
            fontMetricsInt.descent = i5;
            fontMetricsInt.ascent = i5 - ceil;
        }
    }

    public de0(float f) {
        this.e = f;
    }
}