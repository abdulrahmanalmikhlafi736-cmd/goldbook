package defpackage;

import java.io.Serializable;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: df1 */
public final class df1 implements ta0, Serializable {
    public xz e;
    public Object f;

    public final Object getValue() {
        if (this.f == nq0.k) {
            xz xzVar = this.e;
            xzVar.getClass();
            this.f = xzVar.a();
            this.e = null;
        }
        return this.f;
    }

    public final String toString() {
        return this.f != nq0.k ? String.valueOf(getValue()) : "Lazy value not initialized yet.";
    }
}