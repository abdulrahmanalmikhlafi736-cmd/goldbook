package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: eb1 */
public final class eb1 {
    public final i71 a;
    public final i71 b;
    public final i71 c;
    public final i71 d;

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null) {
            if (obj instanceof eb1) {
                eb1 eb1 = (eb1) obj;
                return k70.p(this.a, eb1.a) && k70.p(this.b, eb1.b) && k70.p(this.c, eb1.c) && k70.p(this.d, eb1.d);
            }
        }
        return false;
    }

    public final int hashCode() {
        int i = 0;
        i71 i71 = this.a;
        int hashCode = (i71 != null ? i71.hashCode() : 0) * 31;
        i71 i712 = this.b;
        hashCode = (hashCode + (i712 != null ? i712.hashCode() : 0)) * 31;
        i712 = this.c;
        hashCode = (hashCode + (i712 != null ? i712.hashCode() : 0)) * 31;
        i71 i713 = this.d;
        if (i713 != null) {
            i = i713.hashCode();
        }
        return hashCode + i;
    }

    public eb1(i71 i71, i71 i712, i71 i713, i71 i714) {
        this.a = i71;
        this.b = i712;
        this.c = i713;
        this.d = i714;
    }
}