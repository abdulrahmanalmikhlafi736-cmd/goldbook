package defpackage;

import android.os.Build.VERSION;
import android.os.Handler;
import android.os.Looper;
import androidx.emoji2.text.EmojiCompatInitializer;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: et */
public final class et implements ro {
    public final /* synthetic */ ud0 e;

    public final void e(sd0 sd0) {
        (VERSION.SDK_INT >= 28 ? jk.a(Looper.getMainLooper()) : new Handler(Looper.getMainLooper())).postDelayed(new Object(), 500);
        this.e.f(this);
    }

    public et(EmojiCompatInitializer emojiCompatInitializer, ud0 ud0) {
        this.e = ud0;
    }

    public final void a(sd0 sd0) {
    }

    public final void b(sd0 sd0) {
    }

    public final void c(sd0 sd0) {
    }

    public final void d(sd0 sd0) {
    }

    public final void g(sd0 sd0) {
    }
}