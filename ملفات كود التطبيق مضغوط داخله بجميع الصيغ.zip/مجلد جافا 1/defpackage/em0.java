package defpackage;

import java.util.HashSet;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: em0 */
public final class em0 {
    public final ba0 a;
    public final dm0 b;
    public final v50 c;
    public gm0 d;
    public final ha1 e;
    public li0 f;
    public qk0 g;
    public qk0 h;
    public final qk0 i;
    public cm0 j;

    /* JADX WARNING: Removed duplicated region for block: B:32:0x00f4  */
    /* JADX WARNING: Removed duplicated region for block: B:31:0x00f1  */
    /* JADX WARNING: Removed duplicated region for block: B:35:0x00fb  */
    /* JADX WARNING: Removed duplicated region for block: B:34:0x00f8  */
    /* JADX WARNING: Removed duplicated region for block: B:51:0x013e  */
    /* JADX WARNING: Removed duplicated region for block: B:44:0x011c  */
    /* JADX WARNING: Removed duplicated region for block: B:71:0x018b  */
    /* JADX WARNING: Removed duplicated region for block: B:70:0x0188  */
    /* JADX WARNING: Removed duplicated region for block: B:74:0x0192  */
    /* JADX WARNING: Removed duplicated region for block: B:73:0x018f  */
    /* JADX WARNING: Removed duplicated region for block: B:184:0x01bb A:{SYNTHETIC, EDGE_INSN: B:184:0x01bb->B:82:0x01bb ?: BREAK  , EDGE_INSN: B:184:0x01bb->B:82:0x01bb ?: BREAK  } */
    /* JADX WARNING: Removed duplicated region for block: B:80:0x01b0 A:{LOOP_END, LOOP:5: B:76:0x019e->B:80:0x01b0} */
    /* JADX WARNING: Removed duplicated region for block: B:178:0x0262 A:{SYNTHETIC} */
    /* JADX WARNING: Removed duplicated region for block: B:84:0x01c1  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void f(int i, qk0 qk0, qk0 qk02, li0 li0, boolean z) {
        int i2;
        qk0 qk03;
        qk0 qk04;
        int[] iArr;
        int i3;
        int i4;
        cm0 cm0 = this.j;
        if (cm0 == null) {
            i2 = i;
            qk03 = qk0;
            qk04 = qk02;
            cm0 = new cm0(this, li0, i2, qk03, qk04, z);
            this.j = cm0;
        } else {
            i2 = i;
            qk03 = qk0;
            qk04 = qk02;
            cm0.a = li0;
            cm0.b = i2;
            cm0.c = qk03;
            cm0.d = qk04;
            cm0.e = z;
        }
        em0 em0 = cm0.f;
        int i5 = qk03.g - i2;
        int i6 = qk04.g - i2;
        int i7 = 2;
        i2 = ((i5 + i6) + 1) / 2;
        w60 h90 = new h90(i2 * 3);
        w60 h902 = new h90(i2 * 4);
        int i8 = 0;
        h902.e(0, i5, 0, i6);
        i2 = (i2 * 2) + 1;
        int[] iArr2 = new int[i2];
        int[] iArr3 = new int[i2];
        int[] iArr4 = new int[5];
        while (true) {
            int i9 = h902.b;
            if (i9 == 0) {
                break;
            }
            int[] iArr5;
            int[] iArr6;
            i = i7;
            iArr = h902.a;
            i3 = i8;
            i8 = i9 - 1;
            h902.b = i8;
            i8 = iArr[i8];
            int i10 = i9 - 2;
            h902.b = i10;
            i10 = iArr[i10];
            i4 = i9 - 3;
            h902.b = i4;
            i4 = iArr[i4];
            i9 -= 4;
            h902.b = i9;
            i7 = iArr[i9];
            i9 = i4 - i7;
            int i11 = i2;
            i2 = i8 - i10;
            int[] iArr7 = iArr2;
            if (i9 >= 1) {
                if (i2 >= 1) {
                    int i12 = 1;
                    int i13 = ((i9 + i2) + 1) / 2;
                    int i14 = i11 / 2;
                    int i15 = i14 + 1;
                    iArr7[i15] = i7;
                    iArr3[i15] = i4;
                    i15 = i2;
                    i2 = i3;
                    while (i2 < i13) {
                        int i16;
                        int i17;
                        int i18;
                        int i19;
                        int i20;
                        int i21;
                        int i22;
                        int i23 = i9 - i15;
                        int i24 = i13;
                        iArr5 = iArr3;
                        int i25 = -i2;
                        int i26 = (Math.abs(i23) & 1) == i12 ? 1 : i3;
                        i13 = i25;
                        while (i13 <= i2) {
                            if (i13 != i25) {
                                if (i13 != i2) {
                                    i16 = i13;
                                    iArr6 = iArr4;
                                    if (iArr7[(i13 + 1) + i14] > iArr7[(i16 - 1) + i14]) {
                                    }
                                } else {
                                    i16 = i13;
                                    iArr6 = iArr4;
                                }
                                i13 = iArr7[(i16 - 1) + i14];
                                i17 = i13 + 1;
                                i18 = ((i17 - i7) + i10) - i16;
                                i19 = i18 - ((i2 == 0 ? 1 : i3) & (i17 != i13 ? 1 : i3));
                                i20 = i18;
                                i18 = i13;
                                i13 = i20;
                                while (i17 < i4 && i13 < i8 && cm0.a(i17, i13)) {
                                    i17++;
                                    i13++;
                                }
                                iArr7[i14 + i16] = i17;
                                if (i26 == 0) {
                                    i21 = i13;
                                    i13 = i23 - i16;
                                    i22 = i9;
                                    if (i13 >= i25 + 1 && i13 <= i2 - 1 && iArr5[i14 + i13] <= i17) {
                                        iArr6[i3] = i18;
                                        iArr6[1] = i19;
                                        iArr6[i] = i17;
                                        iArr6[3] = i21;
                                        iArr6[4] = i3;
                                        i13 = 1;
                                        break;
                                    }
                                }
                                i22 = i9;
                                i13 = i16 + 2;
                                iArr4 = iArr6;
                                i9 = i22;
                            } else {
                                i16 = i13;
                                iArr6 = iArr4;
                            }
                            i13 = iArr7[(i16 + 1) + i14];
                            i17 = i13;
                            i18 = ((i17 - i7) + i10) - i16;
                            if (i2 == 0) {
                            }
                            if (i17 != i13) {
                            }
                            i19 = i18 - ((i2 == 0 ? 1 : i3) & (i17 != i13 ? 1 : i3));
                            i20 = i18;
                            i18 = i13;
                            i13 = i20;
                            while (i17 < i4) {
                                i17++;
                                i13++;
                            }
                            iArr7[i14 + i16] = i17;
                            if (i26 == 0) {
                            }
                            i13 = i16 + 2;
                            iArr4 = iArr6;
                            i9 = i22;
                        }
                        iArr6 = iArr4;
                        i22 = i9;
                        i13 = (i23 & 1) == 0 ? 1 : i3;
                        i17 = i25;
                        while (i17 <= i2) {
                            if (i17 != i25) {
                                if (i17 != i2) {
                                    i18 = i13;
                                    if (iArr5[(i17 + 1) + i14] < iArr5[(i17 - 1) + i14]) {
                                    }
                                } else {
                                    i18 = i13;
                                }
                                i13 = iArr5[(i17 - 1) + i14];
                                i9 = i13 - 1;
                                i26 = i8 - ((i4 - i9) - i17);
                                i16 = i26 + ((i2 == 0 ? 1 : i3) & (i9 != i13 ? 1 : i3));
                                i20 = i26;
                                i26 = i13;
                                i13 = i20;
                                while (i9 > i7 && i13 > i10) {
                                    i19 = i13;
                                    i21 = i17;
                                    if (cm0.a(i9 - 1, i19 - 1)) {
                                        break;
                                    }
                                    i9--;
                                    i13 = i19 - 1;
                                    i17 = i21;
                                }
                                i19 = i13;
                                i21 = i17;
                                iArr5[i14 + i21] = i9;
                                if (i18 == 0) {
                                    i13 = i23 - i21;
                                    if (i13 >= i25 && i13 <= i2 && iArr7[i14 + i13] >= i9) {
                                        iArr6[i3] = i9;
                                        i13 = 1;
                                        iArr6[1] = i19;
                                        iArr6[i] = i26;
                                        iArr6[3] = i16;
                                        iArr6[4] = 1;
                                        if (Math.min(iArr6[i] - iArr6[i3], iArr6[3] - iArr6[i13]) > 0) {
                                            i2 = iArr6[i3];
                                            i25 = iArr6[i13];
                                            i13 = iArr6[3] - i25;
                                            i17 = iArr6[i] - i2;
                                            if (i13 != i17) {
                                                i17 = Math.min(i17, i13);
                                                i13 = iArr6[4];
                                                i9 = i13 != 0 ? 1 : i3;
                                                i14 = iArr6[3];
                                                i15 = 1;
                                                i23 = iArr6[1];
                                                i12 = i2;
                                                i2 = i14 - i23;
                                                i24 = iArr6[i];
                                                i26 = iArr6[i3];
                                                i25 += (((i14 - i23 > i24 - i26 ? 1 : i3) ^ 1) | (i13 != 0 ? 1 : i3)) ^ 1;
                                                i2 = i12 + (((i2 > i24 - i26 ? 1 : i3) | i9) ^ 1);
                                            } else {
                                                i12 = i2;
                                                i15 = 1;
                                            }
                                            h90.d(i2, i25, i17);
                                        } else {
                                            i15 = i13;
                                        }
                                        h902.e(i7, iArr6[i3], i10, iArr6[i15]);
                                        h902.e(iArr6[i], i4, iArr6[3], i8);
                                        i7 = i;
                                        i8 = i3;
                                        i2 = i11;
                                        iArr2 = iArr7;
                                        iArr3 = iArr5;
                                        iArr4 = iArr6;
                                    }
                                }
                                i17 = i21 + 2;
                                i13 = i18;
                            } else {
                                i18 = i13;
                            }
                            i13 = iArr5[(i17 + 1) + i14];
                            i9 = i13;
                            i26 = i8 - ((i4 - i9) - i17);
                            if (i2 == 0) {
                            }
                            if (i9 != i13) {
                            }
                            i16 = i26 + ((i2 == 0 ? 1 : i3) & (i9 != i13 ? 1 : i3));
                            i20 = i26;
                            i26 = i13;
                            i13 = i20;
                            while (i9 > i7) {
                                i19 = i13;
                                i21 = i17;
                                if (cm0.a(i9 - 1, i19 - 1)) {
                                }
                            }
                            i19 = i13;
                            i21 = i17;
                            iArr5[i14 + i21] = i9;
                            if (i18 == 0) {
                            }
                            i17 = i21 + 2;
                            i13 = i18;
                        }
                        i2++;
                        iArr3 = iArr5;
                        i13 = i24;
                        iArr4 = iArr6;
                        i9 = i22;
                        i12 = 1;
                    }
                }
            }
            iArr5 = iArr3;
            iArr6 = iArr4;
            i7 = i;
            i8 = i3;
            i2 = i11;
            iArr2 = iArr7;
            iArr3 = iArr5;
            iArr4 = iArr6;
        }
        i = i7;
        i3 = i8;
        i2 = h90.b;
        if (i2 % 3 != 0) {
            a5.b("Array size not a multiple of 3");
        }
        i4 = 3;
        if (i2 > i4) {
            i2 -= i4;
            i4 = i3;
            h90.f(i4, i2);
        } else {
            i4 = i3;
        }
        h90.d(i5, i6, i4);
        i2 = i4;
        i5 = i2;
        i6 = i5;
        while (i2 < h90.b) {
            li0 b;
            iArr = h90.a;
            int i27 = iArr[i2];
            i8 = iArr[i2 + 2];
            i27 -= i8;
            i7 = iArr[i2 + 1] - i8;
            i2 += 3;
            while (i5 < i27) {
                li0 li02 = cm0.a.j;
                li02.getClass();
                if ((li02.g & 2) != 0) {
                    gm0 gm0 = li02.l;
                    gm0.getClass();
                    gm0 gm02 = gm0.u;
                    gm0 = gm0.t;
                    gm0.getClass();
                    if (gm02 != null) {
                        gm02.t = gm0;
                    }
                    gm0.u = gm02;
                    em0.a(em0, cm0.a, gm0);
                }
                cm0.a = em0.c(li02);
                i5++;
            }
            while (i6 < i7) {
                b = em0.b((ki0) cm0.d.e[cm0.b + i6], cm0.a);
                cm0.a = b;
                if (cm0.e) {
                    b = b.j;
                    b.getClass();
                    gm0 gm03 = b.l;
                    gm03.getClass();
                    t90 q = k70.q(cm0.a);
                    if (q != null) {
                        v90 v90 = new v90(em0.a, q);
                        cm0.a.q0(v90);
                        em0.a(em0, cm0.a, v90);
                        v90.u = gm03.u;
                        v90.t = gm03;
                        gm03.u = v90;
                    } else {
                        cm0.a.q0(gm03);
                    }
                    cm0.a.f0();
                    cm0.a.n0();
                    b = cm0.a;
                    zj0 zj0 = hm0.a;
                    if (!b.r) {
                        a5.b("autoInvalidateInsertedNode called on unattached node");
                    }
                    hm0.a(b, -1, 1);
                } else {
                    b.m = true;
                }
                i6++;
            }
            while (true) {
                i7 = i8 - 1;
                if (i8 > 0) {
                    b = cm0.a.j;
                    b.getClass();
                    cm0.a = b;
                    qk0 qk05 = cm0.c;
                    i8 = cm0.b;
                    ki0 ki0 = (ki0) qk05.e[i8 + i5];
                    ki0 ki02 = (ki0) cm0.d.e[i8 + i6];
                    if (!k70.p(ki0, ki02)) {
                        em0.h(ki0, ki02, cm0.a);
                    }
                    i5++;
                    i6++;
                    i8 = i7;
                }
            }
        }
        li0 li03 = this.e.i;
        i8 = i4;
        while (li03 != null && li03 != this.b) {
            i8 |= li03.g;
            li03.h = i8;
            li03 = li03.i;
        }
    }

    public static void h(ki0 ki0, ki0 ki02, li0 li0) {
        if ((ki0 instanceof qi0) && (ki02 instanceof qi0)) {
            qi0 qi0 = (qi0) ki02;
            li0.getClass();
            qi0.f(li0);
            if (li0.r) {
                em0.c(li0);
            } else {
                li0.n = true;
            }
        } else if (li0 instanceof cb) {
            cb cbVar = (cb) li0;
            boolean z = cbVar.r;
            if (z) {
                if (!z) {
                    a5.b("unInitializeModifier called on unattached node");
                }
                if ((cbVar.g & 8) != 0) {
                    ((n4) k70.P(cbVar)).E();
                }
            }
            cbVar.s = ki02;
            cbVar.g = hm0.d(ki02);
            if (cbVar.r) {
                cbVar.r0(false);
            }
            if (li0.r) {
                em0.c(li0);
            } else {
                li0.n = true;
            }
        } else {
            a5.b("Unknown Modifier.Node type");
        }
    }

    public final void g() {
        ba0 ba0;
        Object obj = this.e.i;
        gm0 gm0 = this.c;
        while (true) {
            ba0 = this.a;
            if (obj == null) {
                break;
            }
            t90 q = k70.q(obj);
            if (q != null) {
                gm0 gm02 = obj.l;
                if (gm02 != null) {
                    gm02 = (v90) gm02;
                    t90 t90 = gm02.U;
                    gm02.W0(q);
                    if (t90 != obj) {
                        kp0 kp0 = gm02.P;
                        if (kp0 != null) {
                            ((l20) kp0).c();
                        }
                    }
                } else {
                    gm02 = new v90(ba0, q);
                    obj.q0(gm02);
                }
                gm0.u = gm02;
                gm02.t = gm0;
                gm0 = gm02;
            } else {
                obj.q0(gm0);
            }
            obj = obj.i;
        }
        ba0 v = ba0.v();
        gm0.u = v != null ? v.J.c : null;
        this.d = gm0;
    }

    public static li0 b(ki0 ki0, li0 li0) {
        li0 e;
        li0 li02;
        if (ki0 instanceof qi0) {
            e = ((qi0) ki0).e();
            e.g = hm0.f(e);
        } else {
            li02 = new li0();
            li02.g = hm0.d(ki0);
            li02.s = ki0;
            HashSet hashSet = new HashSet();
            e = li02;
        }
        if (e.r) {
            a5.b("A ModifierNodeElement cannot return an already attached node from create() ");
        }
        e.m = true;
        li02 = li0.j;
        if (li02 != null) {
            li02.i = e;
            e.j = li02;
        }
        li0.j = e;
        e.i = li0;
        return e;
    }

    public final String toString() {
        StringBuilder dl1 = new dl1("[");
        li0 li0 = this.f;
        String str = "]";
        li0 li02 = this.e;
        if (li0 == li02) {
            dl1.append(str);
        } else {
            while (li0 != null && li0 != li02) {
                dl1.append(String.valueOf(li0));
                if (li0.j == li02) {
                    dl1.append(str);
                    break;
                }
                dl1.append(",");
                li0 = li0.j;
            }
        }
        return dl1.toString();
    }

    public static li0 c(li0 li0) {
        boolean z = li0.r;
        if (z) {
            zj0 zj0 = hm0.a;
            if (!z) {
                a5.b("autoInvalidateRemovedNode called on unattached node");
            }
            hm0.a(li0, -1, 2);
            li0.o0();
            li0.g0();
        }
        li0 li02 = li0.j;
        li0 li03 = li0.i;
        if (li02 != null) {
            li02.i = li03;
            li0.j = null;
        }
        if (li03 != null) {
            li03.j = li02;
            li0.i = null;
        }
        li03.getClass();
        return li03;
    }

    public final void e() {
        for (li0 li0 = this.f; li0 != null; li0 = li0.j) {
            li0.n0();
            if (li0.m) {
                zj0 zj0 = hm0.a;
                if (!li0.r) {
                    a5.b("autoInvalidateInsertedNode called on unattached node");
                }
                hm0.a(li0, -1, 1);
            }
            if (li0.n) {
                em0.c(li0);
            }
            li0.m = false;
            li0.n = false;
        }
    }

    public em0(ba0 ba0) {
        this.a = ba0;
        dm0 li0 = new li0();
        this.b = li0;
        v50 v50 = new v50(ba0);
        this.c = v50;
        this.d = v50;
        ha1 ha1 = v50.U;
        this.e = ha1;
        this.f = ha1;
        this.i = new qk0(new mi0[16]);
    }

    public static final void a(em0 em0, li0 li0, gm0 gm0) {
        li0 = li0.i;
        while (li0 != null) {
            if (li0 == em0.b) {
                ba0 v = em0.a.v();
                gm0.u = v != null ? v.J.c : null;
                em0.d = gm0;
                return;
            } else if ((li0.g & 2) != 0) {
                break;
            } else {
                li0.q0(gm0);
                li0 = li0.i;
            }
        }
    }

    public final boolean d(int i) {
        return (this.f.h & i) != 0;
    }
}