package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dp */
public abstract class dp extends li0 {
    public final int s = hm0.e(this);
    public li0 t;

    /* JADX WARNING: Removed duplicated region for block: B:36:0x009e  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final cp r0(cp cpVar) {
        cp cpVar2 = ((li0) cpVar).e;
        if (cpVar2 != cpVar) {
            li0 li0 = cpVar instanceof li0 ? (li0) cpVar : null;
            Object obj = li0 != null ? li0.i : null;
            if (cpVar2 != this.e || !k70.p(obj, this)) {
                od.p("Cannot delegate to an already delegated node");
                return null;
            }
        } else {
            if (cpVar2.r) {
                a5.b("Cannot delegate to an already attached node");
            }
            cpVar2.p0(this.e);
            int i = this.g;
            int f = hm0.f(cpVar2);
            cpVar2.g = f;
            int i2 = this.g;
            int i3 = f & 2;
            if (!(i3 == 0 || (i2 & 2) == 0 || (this instanceof t90))) {
                StringBuilder dl1 = new dl1("Delegating to multiple LayoutModifierNodes without the delegating node implementing LayoutModifierNode itself is not allowed.\nDelegating Node: ");
                dl1.append(this);
                dl1.append("\nDelegate Node: ");
                dl1.append(cpVar2);
                a5.b(dl1.toString());
            }
            cpVar2.j = this.t;
            this.t = cpVar2;
            cpVar2.i = this;
            t0(f | this.g, false);
            if (this.r) {
                if (i3 != 0) {
                    if ((i & 2) == 0) {
                        em0 em0 = k70.O(this).J;
                        this.e.q0(null);
                        em0.g();
                        cpVar2.f0();
                        cpVar2.n0();
                        if (!cpVar2.r) {
                            a5.b("autoInvalidateInsertedNode called on unattached node");
                        }
                        hm0.a(cpVar2, -1, 1);
                    }
                }
                q0(this.l);
                cpVar2.f0();
                cpVar2.n0();
                if (cpVar2.r) {
                }
                hm0.a(cpVar2, -1, 1);
            }
        }
        return cpVar;
    }

    public final void s0(cp cpVar) {
        li0 li0 = null;
        for (cp cpVar2 = this.t; cpVar2 != null; Object cpVar22 = cpVar22.j) {
            if (cpVar22 == cpVar) {
                boolean z = cpVar22.r;
                if (z) {
                    zj0 zj0 = hm0.a;
                    if (!z) {
                        a5.b("autoInvalidateRemovedNode called on unattached node");
                    }
                    hm0.a(cpVar22, -1, 2);
                    cpVar22.o0();
                    cpVar22.g0();
                }
                cpVar22.p0(cpVar22);
                cpVar22.h = 0;
                li0 li02 = cpVar22.j;
                if (li0 == null) {
                    this.t = li02;
                } else {
                    li0.j = li02;
                }
                cpVar22.j = null;
                cpVar22.i = null;
                int i = this.g;
                int f = hm0.f(this);
                t0(f, true);
                if (this.r && (i & 2) != 0) {
                    if ((f & 2) == 0) {
                        em0 em0 = k70.O(this).J;
                        this.e.q0(null);
                        em0.g();
                    }
                }
                return;
            }
            cp li03 = cpVar22;
        }
        od.l(cpVar, "Could not find delegate: ");
    }

    /* JADX WARNING: Removed duplicated region for block: B:21:0x0033 A:{LOOP_END, LOOP:1: B:20:0x0031->B:21:0x0033} */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void t0(int i, boolean z) {
        int i2 = this.g;
        this.g = i;
        if (i2 != i) {
            li0 li0 = this.e;
            if (li0 == this) {
                this.h = i;
            }
            if (this.r) {
                li0 thisR;
                int i3;
                while (thisR != null) {
                    i |= thisR.g;
                    thisR.g = i;
                    if (thisR == li0) {
                        break;
                    }
                    thisR = thisR.i;
                }
                if (z && thisR == li0) {
                    i = hm0.f(li0);
                    li0.g = i;
                }
                if (thisR != null) {
                    li0 li02 = thisR.j;
                    if (li02 != null) {
                        i3 = li02.h;
                        i |= i3;
                        while (thisR != null) {
                            i |= thisR.g;
                            thisR.h = i;
                            thisR = thisR.i;
                        }
                    }
                }
                i3 = 0;
                i |= i3;
                while (thisR != null) {
                }
            }
        }
    }

    public final void f0() {
        super.f0();
        for (li0 li0 = this.t; li0 != null; li0 = li0.j) {
            li0.q0(this.l);
            if (!li0.r) {
                li0.f0();
            }
        }
    }

    public final void g0() {
        for (li0 li0 = this.t; li0 != null; li0 = li0.j) {
            li0.g0();
        }
        super.g0();
    }

    public final void m0() {
        super.m0();
        for (li0 li0 = this.t; li0 != null; li0 = li0.j) {
            li0.m0();
        }
    }

    public final void n0() {
        for (li0 li0 = this.t; li0 != null; li0 = li0.j) {
            li0.n0();
        }
        super.n0();
    }

    public final void o0() {
        super.o0();
        for (li0 li0 = this.t; li0 != null; li0 = li0.j) {
            li0.o0();
        }
    }

    public final void p0(li0 li0) {
        this.e = li0;
        for (li0 li02 = this.t; li02 != null; li02 = li02.j) {
            li02.p0(li0);
        }
    }

    public final void q0(gm0 gm0) {
        this.l = gm0;
        for (li0 li0 = this.t; li0 != null; li0 = li0.j) {
            li0.q0(gm0);
        }
    }
}