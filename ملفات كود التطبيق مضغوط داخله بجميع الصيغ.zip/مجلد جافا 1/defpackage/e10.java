package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: e10 */
public final class e10 implements uj {
    public final rj e;

    public final boolean equals(Object obj) {
        if (obj instanceof e10) {
            if (this.e.equals(((e10) obj).e)) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return this.e.hashCode() * 31;
    }

    public e10(rj rjVar) {
        this.e = rjVar;
    }
}