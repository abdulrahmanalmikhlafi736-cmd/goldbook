package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ei0 */
public abstract class ei0 {
    public static final String a;
    public static final String b;

    static {
        StringBuilder h90;
        String str = "H";
        int length = str.length();
        if (length != 0) {
            int i = 1;
            if (length != 1) {
                h90 = new h90(str.length() * 10);
                while (true) {
                    h90.append(str);
                    if (i == 10) {
                        break;
                    }
                    i++;
                }
                str = h90.toString();
            } else {
                length = 0;
                char charAt = str.charAt(0);
                char[] cArr = new char[10];
                while (length < 10) {
                    cArr[length] = charAt;
                    length++;
                }
                str = new String(cArr);
            }
        } else {
            str = "";
        }
        a = str;
        h90 = new StringBuilder();
        h90.append(str);
        h90.append(10);
        h90.append(str);
        b = h90.toString();
    }
}