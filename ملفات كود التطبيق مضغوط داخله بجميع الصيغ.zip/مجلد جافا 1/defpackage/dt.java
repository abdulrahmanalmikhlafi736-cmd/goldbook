package defpackage;

import android.os.Handler;
import android.os.Looper;
import java.util.ArrayList;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dt */
public final class dt {
    public static final Object j = new Object();
    public static volatile dt k;
    public final ReentrantReadWriteLock a;
    public final aa b;
    public volatile int c = 3;
    public final Handler d;
    public final at e;
    public final ct f;
    public final vj g;
    public final int h;
    public final lo i;

    public dt(jz jzVar) {
        ReentrantReadWriteLock reentrantReadWriteLock = new ReentrantReadWriteLock();
        this.a = reentrantReadWriteLock;
        ct ctVar = jzVar.a;
        this.f = ctVar;
        int i = jzVar.b;
        this.h = i;
        this.i = jzVar.c;
        this.d = new Handler(Looper.getMainLooper());
        this.b = new aa();
        this.g = new h90(8);
        at atVar = new at(this);
        this.e = atVar;
        reentrantReadWriteLock.writeLock().lock();
        if (i == 0) {
            try {
                this.c = 0;
            } catch (Throwable th) {
                this.a.writeLock().unlock();
            }
        }
        reentrantReadWriteLock.writeLock().unlock();
        if (b() == 0) {
            try {
                ctVar.a(new zs(atVar));
            } catch (Throwable th2) {
                d(th2);
            }
        }
    }

    public final void c() {
        if ((this.h == 1 ? 1 : 0) == 0) {
            od.p("Set metadataLoadStrategy to LOAD_STRATEGY_MANUAL to execute manual loading");
        } else if (b() != 1) {
            this.a.writeLock().lock();
            try {
                if (this.c != 0) {
                    this.c = 0;
                    this.a.writeLock().unlock();
                    at atVar = this.e;
                    dt dtVar = atVar.a;
                    try {
                        dtVar.f.a(new zs(atVar));
                    } catch (Throwable th) {
                        dtVar.d(th);
                    }
                }
            } finally {
                this.a.writeLock().unlock();
            }
        }
    }

    public final void d(Throwable th) {
        ArrayList arrayList = new ArrayList();
        this.a.writeLock().lock();
        try {
            this.c = 2;
            arrayList.addAll(this.b);
            this.b.clear();
            this.d.post(new bt(arrayList, this.c, th));
        } finally {
            this = this.a.writeLock();
            this.unlock();
        }
    }

    public final int b() {
        this.a.readLock().lock();
        try {
            int i = this.c;
            return i;
        } finally {
            this.a.readLock().unlock();
        }
    }

    public static dt a() {
        dt dtVar;
        synchronized (j) {
            try {
                dtVar = k;
                Object obj = dtVar != null ? 1 : null;
                String str = "EmojiCompat is not initialized.\n\nYou must initialize EmojiCompat prior to referencing the EmojiCompat instance.\n\nThe most likely cause of this error is disabling the EmojiCompatInitializer\neither explicitly in AndroidManifest.xml, or by including\nandroidx.emoji2:emoji2-bundled.\n\nAutomatic initialization is typically performed by EmojiCompatInitializer. If\nyou are not expecting to initialize EmojiCompat manually in your application,\nplease check to ensure it has not been removed from your APK's manifest. You can\ndo this in Android Studio using Build > Analyze APK.\n\nIn the APK Analyzer, ensure that the startup entry for\nEmojiCompatInitializer and InitializationProvider is present in\n AndroidManifest.xml. If it is missing or contains tools:node=\"remove\", and you\nintend to use automatic configuration, verify:\n\n  1. Your application does not include emoji2-bundled\n  2. All modules do not contain an exclusion manifest rule for\n     EmojiCompatInitializer or InitializationProvider. For more information\n     about manifest exclusions see the documentation for the androidx startup\n     library.\n\nIf you intend to use emoji2-bundled, please call EmojiCompat.init. You can\nlearn more in the documentation for BundledEmojiCompatConfig.\n\nIf you intended to perform manual configuration, it is recommended that you call\nEmojiCompat.init immediately on application startup.\n\nIf you still cannot resolve this issue, please open a bug with your specific\nconfiguration to help improve error message.";
                if (obj != null) {
                } else {
                    throw new dl1(str);
                }
            } finally {
            }
        }
        return dtVar;
    }
}