package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: do0 */
public final class do0 extends xo0 {
    public static final do0 c = new xo0(0, 1, 1);

    public final void a(pg pgVar, m9 m9Var, a61 a61, uw0 uw0, yo0 yo0) {
        y00 y00 = (y00) pgVar.c(0);
        y00.getClass();
        a61.l(a61.c(y00));
    }
}