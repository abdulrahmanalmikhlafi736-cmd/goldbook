package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: eq */
public final class eq implements si0 {
    public static final eq f = new h90(0);
    public final /* synthetic */ int e;

    public final sl i(sl slVar) {
        switch (this.e) {
            case 0:
                return vn.O(this, slVar);
            default:
                return vn.O(this, slVar);
        }
    }

    public final ql k(rl rlVar) {
        switch (this.e) {
            case 0:
                return vn.t(this, rlVar);
            default:
                return vn.t(this, rlVar);
        }
    }

    public final Object p(m00 m00, Object obj) {
        switch (this.e) {
            case 0:
                return m00.f(obj, this);
            default:
                return m00.f(obj, this);
        }
    }

    public final sl t(rl rlVar) {
        switch (this.e) {
            case 0:
                return vn.J(this, rlVar);
            default:
                return vn.J(this, rlVar);
        }
    }

    public final rl getKey() {
        switch (this.e) {
            case 0:
                return e3.V;
            default:
                return e3.V;
        }
    }

    public final float u() {
        switch (this.e) {
            case 0:
                return 0.0f;
            default:
                return 1.0f;
        }
    }

    public /* synthetic */ eq(int i) {
        this.e = i;
    }
}