package defpackage;

import android.view.autofill.AutofillValue;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ek */
public final class ek extends h90 implements m00 {
    public final /* synthetic */ int f = 0;
    public final /* synthetic */ m00 g;
    public final /* synthetic */ Object h;
    public final /* synthetic */ Object i;

    public final Object f(Object obj, Object obj2) {
        int i = this.f;
        we1 we1 = we1.a;
        m00 m00 = this.g;
        Object obj3 = this.i;
        Object obj4 = this.h;
        d10 d10;
        switch (i) {
            case 0:
                d10 = (d10) obj;
                ((Number) obj2).intValue();
                fk.a((lp0) obj4, (nq0) obj3, m00, d10, wc0.s(1));
                return we1;
            default:
                d10 = (d10) obj;
                int intValue = ((Number) obj2).intValue();
                pl1 pl1 = (pl1) obj4;
                if (d10.O(intValue & 1, (intValue & 3) != 2)) {
                    n4 n4Var = pl1.e;
                    AutofillValue h = ((AutofillValue) d10);
                    Object L = d10.L();
                    nq0 nq0 = oj.a;
                    if (h != null || L == nq0) {
                        L = new ol1(pl1, null, 0);
                        d10.g0(L);
                    }
                    j70.j((m00) L, d10, n4Var);
                    h = ((AutofillValue) d10);
                    L = d10.L();
                    if (h != null || L == nq0) {
                        L = new ol1(pl1, null, 1);
                        d10.g0(L);
                    }
                    j70.j((m00) L, d10, n4Var);
                    ((mj) obj3).a(n4Var, m00, d10, 0);
                } else {
                    d10.R();
                }
                return we1;
        }
    }

    public ek(lp0 lp0, nq0 nq0, m00 m00, int i) {
        this.h = lp0;
        this.i = nq0;
        this.g = m00;
        super(2);
    }

    public ek(pl1 pl1, mj mjVar, m00 m00) {
        this.h = pl1;
        this.i = mjVar;
        this.g = m00;
        super(2);
    }
}