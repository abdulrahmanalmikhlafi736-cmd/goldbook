package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ed */
public final class ed implements ua1 {
    public final dd a;
    public final float b;

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof ed)) {
            return false;
        }
        ed edVar = (ed) obj;
        return k70.p(this.a, edVar.a) && Float.compare(this.b, edVar.b) == 0;
    }

    public final String toString() {
        StringBuilder dl1 = new dl1("BrushStyle(value=");
        dl1.append(this.a);
        dl1.append(", alpha=");
        return fu0.F(dl1, this.b, ')');
    }

    public final ua1 d(xz xzVar) {
        return !equals(ta1.a) ? this : (ua1) xzVar.a();
    }

    public final int hashCode() {
        return Float.floatToIntBits(this.b) + (this.a.hashCode() * 31);
    }

    public ed(dd ddVar, float f) {
        this.a = ddVar;
        this.b = f;
    }

    public final long b() {
        int i = zg.j;
        return zg.i;
    }

    public final /* synthetic */ ua1 c(ua1 ua1) {
        return fu0.f(this, ua1);
    }

    public final float a() {
        return this.b;
    }

    public final zi1 e() {
        return this.a;
    }
}