package defpackage;

import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.os.Build.VERSION;
import android.view.View;
import android.view.animation.PathInterpolator;
import java.util.Collections;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ej1 */
public final class ej1 implements AnimatorUpdateListener {
    public final /* synthetic */ mj1 a;
    public final /* synthetic */ hk1 b;
    public final /* synthetic */ hk1 c;
    public final /* synthetic */ int d;
    public final /* synthetic */ View e;

    public final void onAnimationUpdate(ValueAnimator valueAnimator) {
        float animatedFraction = valueAnimator.getAnimatedFraction();
        mj1 mj1 = this.a;
        lj1 lj1 = mj1.a;
        lj1.e(animatedFraction);
        animatedFraction = lj1.c();
        PathInterpolator pathInterpolator = ij1.e;
        int i = VERSION.SDK_INT;
        hk1 hk1 = this.b;
        uj1 tj1 = i >= 36 ? new tj1(hk1) : i >= 35 ? new sj1(hk1) : i >= 34 ? new rj1(hk1) : i >= 31 ? new qj1(hk1) : i >= 30 ? new pj1(hk1) : i >= 29 ? new oj1(hk1) : new nj1(hk1);
        for (int i2 = 1; i2 <= 512; i2 <<= 1) {
            int i3 = this.d & i2;
            dk1 dk1 = hk1.a;
            if (i3 == 0) {
                tj1.d(i2, dk1.i(i2));
            } else {
                c60 i4 = dk1.i(i2);
                c60 i5 = this.c.a.i(i2);
                float f = 1.0f - animatedFraction;
                tj1.d(i2, hk1.a(i4, (int) (((double) (((float) (i4.a - i5.a)) * f)) + 0.5d), (int) (((double) (((float) (i4.b - i5.b)) * f)) + 0.5d), (int) (((double) (((float) (i4.c - i5.c)) * f)) + 0.5d), (int) (((double) (((float) (i4.d - i5.d)) * f)) + 0.5d)));
            }
        }
        ij1.h(this.e, tj1.b(), Collections.singletonList(mj1));
    }

    public ej1(mj1 mj1, hk1 hk1, hk1 hk12, int i, View view) {
        this.a = mj1;
        this.b = hk1;
        this.c = hk12;
        this.d = i;
        this.e = view;
    }
}