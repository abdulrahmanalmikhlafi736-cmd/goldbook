package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dl0 */
public final class dl0 {
    public final int a;
    public final float b;
    public final float c;
    public final float d;
    public final long e;

    public final String toString() {
        StringBuilder dl1 = new dl1("NavigationEvent(touchX=");
        dl1.append(this.c);
        dl1.append(", touchY=");
        dl1.append(this.d);
        dl1.append(", progress=");
        dl1.append(this.b);
        dl1.append(", swipeEdge=");
        dl1.append(this.a);
        dl1.append(", frameTimeMillis=");
        dl1.append(this.e);
        dl1.append(')');
        return dl1.toString();
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null) {
            if (dl0.class == obj.getClass()) {
                dl0 dl0 = (dl0) obj;
                return this.c == dl0.c && this.d == dl0.d && this.b == dl0.b && this.a == dl0.a && this.e == dl0.e;
            }
        }
        return false;
    }

    public final int hashCode() {
        int z = (fu0.z(this.b, fu0.z(this.d, Float.floatToIntBits(this.c) * 31, 31), 31) + this.a) * 31;
        long j = this.e;
        return z + ((int) (j ^ (j >>> 32)));
    }

    public dl0(int i, float f, float f2, float f3, long j) {
        this.a = i;
        this.b = f;
        this.c = f2;
        this.d = f3;
        this.e = j;
    }
}