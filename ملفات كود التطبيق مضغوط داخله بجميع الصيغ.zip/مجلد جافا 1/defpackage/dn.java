package defpackage;

import mod.Mod;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dn */
public final class dn extends u91 implements m00 {
    public final /* synthetic */ int i;
    public /* synthetic */ Object j;
    public final /* synthetic */ Object k;

    public final Object p(Object obj) {
        boolean z = false;
        Object obj2 = null;
        switch (this.i) {
            case 0:
                nb0.t(obj);
                z71 z71 = (z71) this.j;
                if ((z71 instanceof qm) && ((qm) z71).a <= ((qm) ((z71) this.k)).a) {
                    z = true;
                }
                return Boolean.valueOf(z);
            case 1:
                nb0.t(obj);
                String str = ((Boolean) ((mk0) this.k).getValue()).booleanValue() ? "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0" : null;
                x7 b = ((wi1) this.j).b();
                if (b != null) {
                    b.a.getSettings().setUserAgentString(str);
                    obj2 = we1.a;
                } else {
                    od.p("WebView is not initialized");
                }
                return obj2;
            case 2:
                nb0.t(obj);
                ((sb1) this.j).a = wl1.L(((dh) this.k).a);
                ((sb1) this.j).b = wl1.L(((dh) this.k).b);
                return we1.a;
            case 3:
                nb0.t(obj);
                bm bmVar = (bm) this.j;
                kd0 kd0 = (kd0) this.k;
                ud0 ud0 = kd0.e;
                if (ud0.d.compareTo(jd0.f) >= 0) {
                    ud0.a(kd0);
                } else {
                    a80 a80 = (a80) bmVar.f().k(e3.S);
                    if (a80 != null) {
                        a80.a(null);
                    }
                }
                return we1.a;
            case gu0.LONG_FIELD_NUMBER /*4*/:
                nb0.t(obj);
                if (((wi1) this.j).h == null) {
                    ui1 ui1 = (ui1) this.k;
                    wl1.B(ui1.a, null, new d(ui1, "https://www.facebook.com/messages", null, 24), 3);
                }
                Mod.setVideoState(false, 0, 0);
                return we1.a;
            default:
                ek0 ek0 = (ek0) this.j;
                nb0.t(obj);
                ek0.d(n41.L, (String) this.k);
                return we1.a;
        }
    }

    public final Object f(Object obj, Object obj2) {
        int i = this.i;
        we1 we1 = we1.a;
        switch (i) {
            case 0:
                return ((dn) n((ml) obj2, (z71) obj)).p(we1);
            case 1:
                ((dn) n((ml) obj2, (bm) obj)).p(we1);
                return we1;
            case 2:
                ((dn) n((ml) obj2, (bm) obj)).p(we1);
                return we1;
            case 3:
                ((dn) n((ml) obj2, (bm) obj)).p(we1);
                return we1;
            case gu0.LONG_FIELD_NUMBER /*4*/:
                ((dn) n((ml) obj2, (bm) obj)).p(we1);
                return we1;
            default:
                ((dn) n((ml) obj2, (ek0) obj)).p(we1);
                return we1;
        }
    }

    public final ml n(ml mlVar, Object obj) {
        int i = this.i;
        Object obj2 = this.k;
        switch (i) {
            case 0:
                this = new ao((z71) obj2, mlVar, 0);
                this.j = obj;
                return this;
            case 1:
                return new d((wi1) this.j, (mk0) obj2, mlVar, 1);
            case 2:
                return new d((sb1) this.j, (dh) obj2, mlVar, 2);
            case 3:
                this = new ao((kd0) obj2, mlVar, 3);
                this.j = obj;
                return this;
            case gu0.LONG_FIELD_NUMBER /*4*/:
                return new d((wi1) this.j, (ui1) obj2, mlVar, 4);
            default:
                this = new ao((String) obj2, mlVar, 5);
                this.j = obj;
                return this;
        }
    }

    public /* synthetic */ dn(Object obj, Object obj2, ml mlVar, int i) {
        this.i = i;
        this.j = obj;
        this.k = obj2;
        super(2, mlVar);
    }

    public /* synthetic */ dn(Object obj, ml mlVar, int i) {
        this.i = i;
        this.k = obj;
        super(2, mlVar);
    }
}