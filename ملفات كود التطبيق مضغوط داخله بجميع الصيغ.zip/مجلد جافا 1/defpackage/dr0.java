package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dr0 */
public final class dr0 extends jr0 {
    public final float c;
    public final float d;

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof dr0)) {
            return false;
        }
        dr0 dr0 = (dr0) obj;
        return Float.compare(this.c, dr0.c) == 0 && Float.compare(this.d, dr0.d) == 0;
    }

    public final String toString() {
        StringBuilder dl1 = new dl1("RelativeMoveTo(dx=");
        dl1.append(this.c);
        dl1.append(", dy=");
        return fu0.F(dl1, this.d, ')');
    }

    public final int hashCode() {
        return Float.floatToIntBits(this.d) + (Float.floatToIntBits(this.c) * 31);
    }

    public dr0(float f, float f2) {
        super(3);
        this.c = f;
        this.d = f2;
    }
}