package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: eh0 */
public final /* synthetic */ class eh0 implements m00 {
    public final /* synthetic */ int e;
    public final /* synthetic */ ke1 f;
    public final /* synthetic */ pi g;

    public final Object f(Object obj, Object obj2) {
        int i = this.e;
        we1 we1 = we1.a;
        boolean z = false;
        pi piVar = this.g;
        ke1 ke1 = this.f;
        d10 d10 = (d10) obj;
        int intValue = ((Integer) obj2).intValue();
        switch (i) {
            case 0:
                if ((intValue & 3) != 2) {
                    z = true;
                }
                if (d10.O(intValue & 1, z)) {
                    qt0.a(vd1.A(-241536773, new eh0(ke1, piVar, 1), d10), d10, 6);
                } else {
                    d10.R();
                }
                return we1;
            default:
                if (d10.O(intValue & 1, (intValue & 3) != 2)) {
                    za1.a(ke1.j, piVar, d10, 0);
                } else {
                    d10.R();
                }
                return we1;
        }
    }

    public /* synthetic */ eh0(ke1 ke1, pi piVar, int i) {
        this.e = i;
        this.f = ke1;
        this.g = piVar;
    }
}