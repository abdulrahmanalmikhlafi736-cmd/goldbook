package defpackage;

import android.content.pm.PackageInfo;
import android.os.Build.VERSION;
import android.webkit.WebView;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ei1 */
public final class ei1 extends j9 {
    public final Pattern d = Pattern.compile("\\A\\d+");

    /* JADX WARNING: Removed duplicated region for block: B:11:? A:{SYNTHETIC, Splitter: B:8:0x0018, ExcHandler: java.lang.ClassNotFoundException (unused java.lang.ClassNotFoundException)} */
    /* JADX WARNING: Removed duplicated region for block: B:11:? A:{SYNTHETIC, Splitter: B:8:0x0018, ExcHandler: java.lang.ClassNotFoundException (unused java.lang.ClassNotFoundException)} */
    /* JADX WARNING: Removed duplicated region for block: B:11:? A:{SYNTHETIC, Splitter: B:8:0x0018, ExcHandler: java.lang.ClassNotFoundException (unused java.lang.ClassNotFoundException)} */
    /* JADX WARNING: Missing block: B:10:0x001d, code:
            r0 = null;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean b() {
        boolean b = super.b();
        if (b) {
            int i = VERSION.SDK_INT;
            if (i < 29) {
                PackageInfo a;
                int i2 = bi1.a;
                if (i >= 26) {
                    a = WebView.getCurrentWebViewPackage();
                } else {
                    try {
                        a = bi1.a();
                    } catch (ClassNotFoundException unused) {
                    }
                }
                boolean z = false;
                if (a == null) {
                    return false;
                }
                Matcher matcher = this.d.matcher(a.versionName);
                if (matcher.find() && Integer.parseInt(a.versionName.substring(matcher.start(), matcher.end())) >= 105) {
                    z = true;
                }
                return z;
            }
        }
        return b;
    }

    public ei1() {
        String str = "ALGORITHMIC_DARKENING";
        super(str, str);
    }

    public final boolean a() {
        return VERSION.SDK_INT >= 33;
    }
}