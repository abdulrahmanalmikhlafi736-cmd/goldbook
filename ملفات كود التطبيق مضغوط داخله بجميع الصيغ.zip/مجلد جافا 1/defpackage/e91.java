package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: e91 */
public final class e91 extends h90 implements m00 {
    public final /* synthetic */ int f;
    public final /* synthetic */ f91 g;

    public final Object f(Object obj, Object obj2) {
        int i = this.f;
        we1 we1 = we1.a;
        f91 f91 = this.g;
        ba0 ba0;
        pa0 a;
        switch (i) {
            case 0:
                ba0 = (ba0) obj;
                f91.a().f = (sj) obj2;
                return we1;
            case 1:
                ba0 = (ba0) obj;
                m00 m00 = (m00) obj2;
                a = f91.a();
                ba0.c0(new la0(a, m00, a.t));
                return we1;
            default:
                ba0 = (ba0) obj;
                f91 f912 = (f91) obj2;
                i91 i91 = f91.a;
                pa0 pa0 = ba0.L;
                if (pa0 == null) {
                    pa0 = new pa0(ba0, i91);
                    ba0.L = pa0;
                }
                f91.b = pa0;
                f91.a().h();
                a = f91.a();
                if (a.g != i91) {
                    a.g = i91;
                    a.i(false);
                    ba0.V(a.e, false, 7);
                }
                return we1;
        }
    }

    public /* synthetic */ e91(f91 f91, int i) {
        this.f = i;
        this.g = f91;
        super(2);
    }
}