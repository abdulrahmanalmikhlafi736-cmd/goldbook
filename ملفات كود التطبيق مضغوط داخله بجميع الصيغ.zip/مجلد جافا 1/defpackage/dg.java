package defpackage;

import android.view.KeyEvent;
import android.view.ViewGroup;
import android.view.ViewParent;
import java.util.ArrayList;
import java.util.List;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dg */
public class dg extends dp implements gt0, f90, g21, kd1, ak, vm0, d50, o10 {
    public static final nq0 P = new h90(10);
    public final vy A;
    public t40 B;
    public p10 C;
    public cp D;
    public ou0 E;
    public m30 F;
    public final wj0 G = new h90(6);
    public long H = 0;
    public ou0 I;
    public uj0 J;
    public boolean K;
    public s71 L;
    public final nq0 M;
    public dt0 N;
    public v40 O;
    public uj0 u;
    public t40 v;
    public boolean w;
    public iy0 x;
    public boolean y;
    public xz z;

    public final void x(zs0 zs0, at0 at0, long j) {
        int i;
        zs0 zs02 = zs0;
        at0 at02 = at0;
        long j2 = 32;
        long j3 = 4294967295L;
        long j4 = ((j >> 33) << 32) | (((j << 32) >> 33) & 4294967295L);
        this.H = (((long) Float.floatToRawIntBits((float) ((int) (j4 & 4294967295L)))) & 4294967295L) | (((long) Float.floatToRawIntBits((float) ((int) (j4 >> 32)))) << 32);
        y0();
        boolean z = this.y;
        at0 at03 = at0.f;
        int i2 = 1;
        boolean z2 = false;
        if (z) {
            if (this.C == null) {
                p10 p10 = new p10(this);
                r0(p10);
                this.C = p10;
            }
            if (at02 == at03) {
                i = zs02.c;
                if (i == 4) {
                    wl1.B(d0(), null, new k(this, null, 0), 3);
                } else if (i == 5) {
                    wl1.B(d0(), null, new k(this, null, 1), 3);
                }
            }
        }
        dt0 dt0;
        List list;
        int size;
        if (at02 == at03) {
            dt0 dt02;
            if (this.N != null) {
                int i3;
                dt0 = null;
                list = zs02.a;
                size = list.size();
                i = 0;
                while (i < size) {
                    dt0 dt03 = (dt0) list.get(i);
                    int i4 = (dt03.b() || !dt03.h || dt03.d) ? 0 : i2;
                    if (i4 == 0) {
                        long K = k70.O(this).C.K(((yg1) j70.z(this, fk.t)).c());
                        K = (((long) Float.floatToRawIntBits(Math.max(0.0f, Float.intBitsToFloat((int) (K & j3)) - ((float) ((int) (j & j3)))) / 2.0f)) & j3) | (((long) Float.floatToRawIntBits(Math.max(0.0f, Float.intBitsToFloat((int) (K >> j2)) - ((float) ((int) (j >> j2)))) / 2.0f)) << j2);
                        int size2 = list.size();
                        i4 = 0;
                        while (i4 < size2) {
                            boolean z3;
                            dt0 dt04 = (dt0) list.get(i4);
                            if (dt04.b()) {
                                z3 = z2;
                            } else {
                                int i5 = dt04.i == i2 ? i2 : z2;
                                long j5 = dt04.c;
                                Object obj = j2;
                                float intBitsToFloat = Float.intBitsToFloat((int) (j5 >> obj));
                                float intBitsToFloat2 = Float.intBitsToFloat((int) (j5 & j3));
                                float f = (float) i5;
                                float intBitsToFloat3 = Float.intBitsToFloat((int) (K >> obj)) * f;
                                long j6 = j3;
                                float f2 = ((float) ((int) (j >> obj))) + intBitsToFloat3;
                                float intBitsToFloat4 = Float.intBitsToFloat((int) (K & j6)) * f;
                                if (((((intBitsToFloat > f2 ? 1 : 0) | (intBitsToFloat < (-intBitsToFloat3) ? 1 : 0)) | (intBitsToFloat2 < (-intBitsToFloat4) ? 1 : 0)) | (intBitsToFloat2 > ((float) ((int) (j & j6))) + intBitsToFloat4 ? 1 : 0)) != 0) {
                                    z3 = false;
                                } else {
                                    i4++;
                                    j3 = j6;
                                    j2 = 32;
                                    i2 = 1;
                                    z2 = false;
                                }
                            }
                            v0(z3);
                            return;
                        }
                    }
                    i3 = 0;
                    i++;
                    j3 = j3;
                    j2 = 32;
                    i2 = 1;
                }
                i3 = 0;
                ((dt0) list.get(i3)).a();
                if (this.y) {
                    dt02 = this.N;
                    dt02.getClass();
                    x0(dt02.c, i3);
                    this.z.a();
                }
                this.N = dt0;
            } else if (kb0.r(zs02, true)) {
                dt02 = (dt0) zs02.a.get(0);
                dt02.a();
                this.N = dt02;
                if (this.y) {
                    uj0 uj0 = this.u;
                    if (uj0 != null) {
                        ou0 adVar = new ad(dt02.c);
                        jw0 obj2 = new Object();
                        mc0.E(this, p10.t, new a2(new al(7, dt02, obj2), 1));
                        if (!obj2.e) {
                            int i6 = eg.b;
                            ViewParent parent = gh0.N(this).getParent();
                            while (parent != null && (parent instanceof ViewGroup)) {
                                ViewGroup viewGroup = (ViewGroup) parent;
                                if (!viewGroup.shouldDelayChildPressedState()) {
                                    parent = viewGroup.getParent();
                                }
                            }
                            this.E = adVar;
                            wl1.B(d0(), null, new h(uj0, adVar, null, 2), 3);
                            return;
                        }
                        ml mlVar = null;
                        this.L = wl1.B(d0(), mlVar, new i(uj0, adVar, this, mlVar, 1), 3);
                    }
                }
            }
        } else if (at02 == at0.g && this.N != null) {
            list = zs02.a;
            size = list.size();
            i = 0;
            while (i < size) {
                dt0 = (dt0) list.get(i);
                if (!dt0.b() || dt0 == this.N) {
                    i++;
                } else {
                    v0(false);
                    return;
                }
            }
        }
    }

    public final void v(i6 i6Var, at0 at0) {
        ArrayList arrayList = (ArrayList) i6Var.c;
        y0();
        if (this.y && this.C == null) {
            p10 p10 = new p10(this);
            r0(p10);
            this.C = p10;
        }
        int i = 0;
        int size;
        int size2;
        int i2;
        if (at0 != at0.f) {
            if (at0 == at0.g && this.O != null) {
                size = arrayList.size();
                while (i < size) {
                    v40 v40 = (v40) arrayList.get(i);
                    if (!v40.i || v40 == this.O) {
                        i++;
                    } else {
                        v0(true);
                        return;
                    }
                }
            }
        } else if (this.O == null) {
            size2 = arrayList.size();
            for (i2 = 0; i2 < size2; i2++) {
                if (k70.v((v40) arrayList.get(i2))) {
                    v40 v402 = (v40) arrayList.get(0);
                    v402.i = true;
                    this.O = v402;
                    if (this.y) {
                        uj0 uj0 = this.u;
                        if (uj0 != null) {
                            ou0 adVar = new ad(v402.c);
                            jw0 obj = new Object();
                            mc0.E(this, p10.t, new a2(new al(6, v402, obj), 1));
                            if (!obj.e) {
                                int i3 = eg.b;
                                ViewParent parent = gh0.N(this).getParent();
                                while (parent != null && (parent instanceof ViewGroup)) {
                                    ViewGroup viewGroup = (ViewGroup) parent;
                                    if (!viewGroup.shouldDelayChildPressedState()) {
                                        parent = viewGroup.getParent();
                                    }
                                }
                                this.I = adVar;
                                wl1.B(d0(), null, new h(uj0, adVar, null, 1), 3);
                                return;
                            }
                            this.L = wl1.B(d0(), null, new i(uj0, adVar, this, null, 0), 3);
                            return;
                        }
                    }
                }
            }
        } else {
            size = arrayList.size();
            for (size2 = 0; size2 < size; size2++) {
                v40 v403 = (v40) arrayList.get(size2);
                if (v403.i || !v403.h || v403.d) {
                    float b = ((yg1) j70.z(this, fk.t)).b();
                    size2 = arrayList.size();
                    i2 = 0;
                    while (i2 < size2) {
                        v40 v404 = (v40) arrayList.get(i2);
                        long j = v404.c;
                        v40 v405 = this.O;
                        v405.getClass();
                        boolean z = Math.abs(xm0.c(gg1.e(j, v405.c))) > b;
                        if (!v404.i) {
                            if (!z) {
                                i2++;
                            }
                        }
                        v0(true);
                        return;
                    }
                }
            }
            ((v40) arrayList.get(0)).i = true;
            if (this.y) {
                v40 v406 = this.O;
                v406.getClass();
                x0(v406.c, true);
                this.z.a();
            }
            this.O = null;
        }
    }

    public final boolean I(KeyEvent keyEvent) {
        boolean z;
        y0();
        long b = ac.b(keyEvent.getKeyCode());
        boolean z2 = this.y;
        wj0 wj0 = this.G;
        boolean z3 = true;
        boolean z4;
        if (z2 && a5.v(keyEvent) == 2 && gh0.D(keyEvent)) {
            if (!wj0.b(b)) {
                ou0 adVar = new ad(this.H);
                wj0.f(b, adVar);
                if (this.u != null) {
                    wl1.B(d0(), null, new j(this, adVar, null, 2), 3);
                    return true;
                }
                z4 = true;
            }
        } else if (this.y && a5.v(keyEvent) == 1 && gh0.D(keyEvent)) {
            int numberOfTrailingZeros;
            Object obj;
            int i = ((int) ((b >>> 32) ^ b)) * -862048943;
            i ^= i << 16;
            int i2 = i & 127;
            int i3 = wj0.d;
            i = (i >>> 7) & i3;
            int i4 = 0;
            loop0:
            while (true) {
                long[] jArr = wj0.a;
                int i5 = i >> 3;
                int i6 = (i & 7) << 3;
                z4 = z3;
                z = false;
                long j = (((-((long) i6)) >> 63) & (jArr[i5 + z3] << (64 - i6))) | (jArr[i5] >>> i6);
                long j2 = (((long) i2) * 72340172838076673L) ^ j;
                long j3 = -9187201950435737472L;
                j2 = ((~j2) & (j2 - 72340172838076673L)) & -9187201950435737472L;
                while (j2 != 0) {
                    numberOfTrailingZeros = (i + (Long.numberOfTrailingZeros(j2) >> 3)) & i3;
                    long j4 = j3;
                    if (wj0.b[numberOfTrailingZeros] == b) {
                        break loop0;
                    }
                    j2 &= j2 - 1;
                    j3 = j4;
                }
                if (((j & ((~j) << 6)) & j3) != 0) {
                    numberOfTrailingZeros = -1;
                    break;
                }
                i4 += 8;
                i = (i + i4) & i3;
                z3 = z4;
            }
            if (numberOfTrailingZeros >= 0) {
                wj0.e--;
                long[] jArr2 = wj0.a;
                int i7 = wj0.d;
                i = numberOfTrailingZeros >> 3;
                int i8 = (numberOfTrailingZeros & 7) << 3;
                long j5 = (jArr2[i] & (~(255 << i8))) | (254 << i8);
                jArr2[i] = j5;
                jArr2[(((numberOfTrailingZeros - 7) & i7) + (i7 & 7)) >> 3] = j5;
                Object[] objArr = wj0.c;
                obj = objArr[numberOfTrailingZeros];
                objArr[numberOfTrailingZeros] = null;
            } else {
                obj = null;
            }
            ou0 ou0 = (ou0) obj;
            if (ou0 != null) {
                if (this.u != null) {
                    wl1.B(d0(), null, new j(this, ou0, null, 3), 3);
                }
                this.z.a();
            }
            return ou0 != null ? z4 : z;
        }
        z = false;
    }

    /* JADX WARNING: Removed duplicated region for block: B:36:0x006b  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void z0(uj0 uj0, t40 t40, boolean z, boolean z2, iy0 iy0, xz xzVar) {
        boolean z3;
        boolean z4 = true;
        boolean z5 = false;
        if (k70.p(this.J, uj0)) {
            z3 = false;
        } else {
            w0();
            this.J = uj0;
            this.u = uj0;
            z3 = true;
        }
        if (!k70.p(this.v, t40)) {
            this.v = t40;
            z3 = true;
        }
        if (this.w != z) {
            this.w = z;
            if (z) {
                z();
            }
            z3 = true;
        }
        boolean z6 = this.y;
        vy vyVar = this.A;
        if (z6 != z2) {
            if (z2) {
                r0(vyVar);
            } else {
                s0(vyVar);
                w0();
            }
            jb0.n(this);
            this.y = z2;
        }
        if (!k70.p(this.x, iy0)) {
            this.x = iy0;
            jb0.n(this);
        }
        this.z = xzVar;
        z6 = this.K;
        uj0 uj02 = this.J;
        if (z6 != (uj02 == null)) {
            if (uj02 == null) {
                z5 = true;
            }
            this.K = z5;
            if (!z5 && this.D == null) {
                if (z4) {
                    cp cpVar = this.D;
                    if (!(cpVar == null && this.K)) {
                        if (cpVar != null) {
                            s0(cpVar);
                        }
                        this.D = null;
                        y0();
                    }
                }
                vyVar.v0(this.u);
            }
        }
        z4 = z3;
        if (z4) {
        }
        vyVar.v0(this.u);
    }

    public final void w0() {
        uj0 uj0 = this.u;
        wj0 wj0 = this.G;
        if (uj0 != null) {
            ou0 ou0 = this.E;
            if (ou0 != null) {
                uj0.b(new nu0(ou0));
            }
            ou0 = this.I;
            if (ou0 != null) {
                uj0.b(new nu0(ou0));
            }
            m30 m30 = this.F;
            if (m30 != null) {
                uj0.b(new n30(m30));
            }
            Object[] objArr = wj0.c;
            long[] jArr = wj0.a;
            int length = jArr.length - 2;
            if (length >= 0) {
                int i = 0;
                while (true) {
                    long j = jArr[i];
                    if (((((~j) << 7) & j) & -9187201950435737472L) != -9187201950435737472L) {
                        int i2 = 8 - ((~(i - length)) >>> 31);
                        for (int i3 = 0; i3 < i2; i3++) {
                            if ((255 & j) < 128) {
                                uj0.b(new nu0((ou0) objArr[(i << 3) + i3]));
                            }
                            j >>= 8;
                        }
                        if (i2 != 8) {
                            break;
                        }
                    }
                    if (i == length) {
                        break;
                    }
                    i++;
                }
            }
        }
        this.E = null;
        this.I = null;
        this.F = null;
        wj0.a();
    }

    public final void v0(boolean z) {
        if (z) {
            this.O = null;
        } else {
            this.N = null;
        }
        uj0 uj0 = this.u;
        if (uj0 != null) {
            s71 s71 = this.L;
            if (s71 == null || !s71.b()) {
                ou0 ou0 = z ? this.I : this.E;
                if (ou0 != null) {
                    nu0 nu0 = new nu0(ou0);
                    a80 a80 = (a80) ((ll) d0()).e.k(e3.S);
                    wl1.B(d0(), null, new aj(uj0, nu0, a80 != null ? a80.r(new al(0, uj0, nu0)) : null, null, 0), 3);
                }
            } else {
                s71 = this.L;
                if (s71 != null) {
                    s71.a(null);
                }
            }
            if (z) {
                this.I = null;
                return;
            }
            this.E = null;
        }
    }

    public dg(uj0 uj0, t40 t40, boolean z, boolean z2, iy0 iy0, xz xzVar) {
        this.u = uj0;
        this.v = t40;
        this.w = z;
        this.x = iy0;
        this.y = z2;
        this.z = xzVar;
        this.A = new vy(uj0, new e(1, this, dg.class, "onFocusChange", "onFocusChange(Z)V", 0, 0, 0));
        int i = vf0.a;
        uj0 uj02 = this.u;
        this.J = uj02;
        this.K = uj02 == null;
        this.M = P;
    }

    public final void x0(long j, boolean z) {
        uj0 uj0 = this.u;
        if (uj0 != null) {
            s71 s71 = this.L;
            if (s71 == null || !s71.b()) {
                ou0 ou0 = z ? this.I : this.E;
                if (ou0 != null) {
                    wl1.B(d0(), null, new h(ou0, uj0, null), 3);
                }
            } else {
                s71.a(null);
                wl1.B(d0(), null, new g(s71, j, uj0, null, 0), 3);
            }
            if (z) {
                this.I = null;
                return;
            }
            this.E = null;
        }
    }

    public final void Q(r21 r21) {
        iy0 iy0 = this.x;
        if (iy0 != null) {
            p21.a(r21, iy0.a);
        }
        b bVar = new b(this, 1);
        a90[] a90Arr = p21.a;
        r21.a(c21.b, new o0(null, bVar));
        if (this.y) {
            this.A.Q(r21);
        } else {
            r21.a(n21.j, we1.a);
        }
        u0(r21);
    }

    public final void y0() {
        if (this.D == null) {
            t40 t40 = this.w ? this.B : this.v;
            if (t40 != null) {
                if (this.u == null) {
                    this.u = new uj0();
                }
                this.A.v0(this.u);
                uj0 uj0 = this.u;
                uj0.getClass();
                cp a = t40.a(uj0);
                r0(a);
                this.D = a;
            }
        }
    }

    public final void j0() {
        w0();
        if (this.J == null) {
            this.u = null;
        }
        cp cpVar = this.D;
        if (cpVar != null) {
            s0(cpVar);
        }
        this.D = null;
        p10 p10 = this.C;
        if (p10 != null) {
            s0(p10);
        }
        this.C = null;
    }

    public final void R() {
        uj0 uj0 = this.u;
        if (uj0 != null) {
            m30 m30 = this.F;
            if (m30 != null) {
                uj0.b(new n30(m30));
            }
        }
        this.F = null;
        v0(false);
    }

    public final void h0() {
        z();
        if (!this.K) {
            y0();
        }
        if (this.y) {
            r0(this.A);
        }
    }

    public final void z() {
        if (this.w) {
            sb0.r(this, new b(this, 0));
        }
    }

    public final void s() {
        v0(true);
    }

    public final void L() {
        R();
    }

    public final void i0() {
        R();
    }

    public final Object j() {
        return this.M;
    }

    public final long l() {
        return zi1.y;
    }

    public final /* synthetic */ boolean A(v40 v40) {
        return false;
    }

    public final /* synthetic */ boolean J() {
        return false;
    }

    public final /* synthetic */ boolean S() {
        return false;
    }

    public final boolean T() {
        return true;
    }

    public final /* synthetic */ boolean c(dt0 dt0) {
        return false;
    }

    public final /* synthetic */ boolean e() {
        return true;
    }

    public final boolean e0() {
        return false;
    }

    public final /* synthetic */ void a0() {
    }

    public void u0(r21 r21) {
    }
}