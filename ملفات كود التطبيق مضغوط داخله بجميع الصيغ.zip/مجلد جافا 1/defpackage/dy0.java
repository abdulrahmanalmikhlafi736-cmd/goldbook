package defpackage;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dy0 */
public final class dy0 extends ViewGroup {
    public final int e = 5;
    public final ArrayList f;
    public final ArrayList g;
    public final al h;
    public int i;

    public dy0(Context context) {
        super(context);
        ArrayList arrayList = new ArrayList();
        this.f = arrayList;
        ArrayList arrayList2 = new ArrayList();
        this.g = arrayList2;
        this.h = new h90(18);
        setClipChildren(false);
        ey0 view = new View(context);
        addView(view);
        arrayList.add(view);
        arrayList2.add(view);
        this.i = 1;
        setTag(2131034174, Boolean.TRUE);
    }

    public final void onMeasure(int i, int i2) {
        setMeasuredDimension(0, 0);
    }

    public final void onLayout(boolean z, int i, int i2, int i3, int i4) {
    }

    public final void requestLayout() {
    }
}