package defpackage;

import android.view.autofill.AutofillManager$AutofillCallback;
import android.view.autofill.AutofillValue;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ed1 */
public final class ed1 {
    public final al a;
    public final ed1 b;
    public final String c;
    public final lq0 d = mc0.t(c());
    public final lq0 e = mc0.t(new ad1(c(), c()));
    public final jq0 f = new ad(0);
    public final jq0 g = new ad(Long.MIN_VALUE);
    public final lq0 h;
    public final z61 i;
    public final z61 j;
    public final lq0 k;

    public final void a(Object obj, d10 d10, int i) {
        int i2;
        d10.X(-1493585151);
        if ((i & 6) == 0) {
            i2 = (((i & 8) == 0 ? ((AutofillManager$AutofillCallback) d10) : ((AutofillValue) d10)) != null ? 4 : 2) | i;
        } else {
            i2 = i;
        }
        if ((i & 48) == 0) {
            i2 |= ((AutofillManager$AutofillCallback) d10) != null ? 32 : 16;
        }
        int i3 = 1;
        if (!d10.O(i2 & 1, (i2 & 19) != 18)) {
            d10.R();
        } else if (g()) {
            d10.W(467722849);
            d10.p(false);
        } else {
            d10.W(466062241);
            k(obj);
            i2 &= 112;
            int i4 = i2 == 32 ? 1 : 0;
            Object L = d10.L();
            nq0 nq0 = oj.a;
            if (i4 != 0 || L == nq0) {
                L = mc0.j(new xc1(this, 0));
                d10.g0(L);
            }
            if (((Boolean) ((a81) L).getValue()).booleanValue()) {
                d10.W(466470356);
                Object L2 = d10.L();
                if (L2 == nq0) {
                    L2 = j70.y(d10);
                    d10.g0(L2);
                }
                bm bmVar = (bm) L2;
                AutofillValue h = ((AutofillValue) d10);
                if (i2 != 32) {
                    i3 = 0;
                }
                i2 = h | i3;
                Object L3 = d10.L();
                if (i2 != 0 || L3 == nq0) {
                    L3 = new al(24, bmVar, this);
                    d10.g0(L3);
                }
                j70.c(bmVar, this, (i00) L3, d10);
                d10.p(false);
            } else {
                d10.W(467712929);
                d10.p(false);
            }
            d10.p(false);
        }
        xv0 r = d10.r();
        if (r != null) {
            r.d = new hi(i, 4, this, obj);
        }
    }

    public final void h(long j, boolean z) {
        int i;
        al alVar = this.a;
        lq0 lq0 = (lq0) alVar.f;
        jq0 jq0 = this.g;
        if (jq0.g() == Long.MIN_VALUE) {
            jq0.h(j);
            ((lq0) alVar.f).setValue(Boolean.TRUE);
        } else if (!((Boolean) lq0.getValue()).booleanValue()) {
            lq0.setValue(Boolean.TRUE);
        }
        this.h.setValue(Boolean.FALSE);
        z61 z61 = this.i;
        int size = z61.size();
        Object obj = 1;
        for (i = 0; i < size; i++) {
            bd1 bd1 = (bd1) z61.get(i);
            lq0 lq02 = bd1.i;
            lq0 lq03 = bd1.i;
            if (!((Boolean) lq02.getValue()).booleanValue()) {
                long c = z ? bd1.a().c() : j;
                bd1.l.setValue(bd1.a().b(c));
                bd1.m = bd1.a().f(c);
                ja1 a = bd1.a();
                a.getClass();
                if (fu0.a(a, c)) {
                    lq03.setValue(Boolean.TRUE);
                }
            }
            if (!((Boolean) lq03.getValue()).booleanValue()) {
                obj = null;
            }
        }
        z61 = this.j;
        size = z61.size();
        for (i = 0; i < size; i++) {
            ed1 ed1 = (ed1) z61.get(i);
            if (!k70.p(ed1.d.getValue(), ed1.c())) {
                ed1.h(j, z);
            }
            if (!k70.p(ed1.d.getValue(), ed1.c())) {
                obj = null;
            }
        }
        if (obj != null) {
            i();
        }
    }

    public final void j(Object obj, Object obj2) {
        this.g.h(Long.MIN_VALUE);
        al alVar = this.a;
        ((lq0) alVar.f).setValue(Boolean.FALSE);
        boolean g = g();
        lq0 lq0 = this.d;
        if (!(g && k70.p(c(), obj) && k70.p(lq0.getValue(), obj2))) {
            if (!k70.p(c(), obj)) {
                ((lq0) alVar.g).setValue(obj);
            }
            lq0.setValue(obj2);
            this.k.setValue(Boolean.TRUE);
            this.e.setValue(new ad1(obj, obj2));
        }
        z61 z61 = this.j;
        int size = z61.size();
        int i = 0;
        for (int i2 = 0; i2 < size; i2++) {
            ed1 ed1 = (ed1) z61.get(i2);
            ed1.getClass();
            if (ed1.g()) {
                ed1.j(ed1.c(), ed1.d.getValue());
            }
        }
        z61 z612 = this.i;
        int size2 = z612.size();
        while (i < size2) {
            ((bd1) z612.get(i)).c();
            i++;
        }
    }

    public final void k(Object obj) {
        lq0 lq0 = this.d;
        if (!k70.p(lq0.getValue(), obj)) {
            this.e.setValue(new ad1(lq0.getValue(), obj));
            if (!k70.p(c(), lq0.getValue())) {
                ((lq0) this.a.g).setValue(lq0.getValue());
            }
            lq0.setValue(obj);
            if (this.g.g() == Long.MIN_VALUE) {
                this.h.setValue(Boolean.TRUE);
            }
            z61 z61 = this.i;
            int size = z61.size();
            for (int i = 0; i < size; i++) {
                ((bd1) z61.get(i)).j.h(-2.0f);
            }
        }
    }

    public ed1(al alVar, ed1 ed1, String str) {
        this.a = alVar;
        this.b = ed1;
        this.c = str;
        Boolean bool = Boolean.FALSE;
        this.h = mc0.t(bool);
        this.i = new z61();
        this.j = new z61();
        this.k = mc0.t(bool);
        mc0.j(new xc1(this, 1));
    }

    public final void i() {
        this.g.h(Long.MIN_VALUE);
        Object value = this.d.getValue();
        al alVar = this.a;
        ((lq0) alVar.g).setValue(value);
        if (this.b == null) {
            this.f.h(0);
        }
        ((lq0) alVar.f).setValue(Boolean.FALSE);
        z61 z61 = this.j;
        int size = z61.size();
        for (int i = 0; i < size; i++) {
            ((ed1) z61.get(i)).i();
        }
    }

    public final long b() {
        z61 z61 = this.i;
        int size = z61.size();
        long j = 0;
        int i = 0;
        for (int i2 = 0; i2 < size; i2++) {
            j = Math.max(j, ((bd1) z61.get(i2)).n.g());
        }
        z61 z612 = this.j;
        int size2 = z612.size();
        while (i < size2) {
            j = Math.max(j, ((ed1) z612.get(i)).b());
            i++;
        }
        return j;
    }

    public final boolean d() {
        z61 z61 = this.i;
        int size = z61.size();
        for (int i = 0; i < size; i++) {
            ((bd1) z61.get(i)).getClass();
        }
        z61 z612 = this.j;
        int size2 = z612.size();
        for (size = 0; size < size2; size++) {
            if (((ed1) z612.get(size)).d()) {
                return true;
            }
        }
        return false;
    }

    public final String toString() {
        z61 z61 = this.i;
        int size = z61.size();
        String str = "Transition animation values: ";
        for (int i = 0; i < size; i++) {
            bd1 bd1 = (bd1) z61.get(i);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(str);
            stringBuilder.append(bd1);
            stringBuilder.append(", ");
            str = stringBuilder.toString();
        }
        return str;
    }

    public final long e() {
        ed1 ed1 = this.b;
        return ed1 != null ? ed1.e() : this.f.g();
    }

    public final boolean g() {
        return ((Boolean) this.k.getValue()).booleanValue();
    }

    public final Object c() {
        return ((lq0) this.a.g).getValue();
    }

    public final ad1 f() {
        return (ad1) this.e.getValue();
    }
}