package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ec1 */
final class ec1 extends qi0 {
    public final uj0 a;
    public final boolean b;
    public final p71 c;

    public final void f(li0 li0) {
        hc1 hc1 = (hc1) li0;
        hc1.s = this.a;
        boolean z = hc1.t;
        boolean z2 = this.b;
        if (z != z2) {
            vd1.t(hc1);
        }
        hc1.t = z2;
        hc1.u = this.c;
        if (hc1.x == null && !Float.isNaN(hc1.z)) {
            hc1.x = k70.a(hc1.z);
        }
        if (hc1.w == null && !Float.isNaN(hc1.y)) {
            hc1.w = k70.a(hc1.y);
        }
    }

    /* JADX WARNING: Missing block: B:12:0x0024, code:
            if (r2.c.equals(r3.c) == false) goto L_0x0026;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean equals(Object obj) {
        if (this != obj) {
            if (obj instanceof ec1) {
                ec1 ec1 = (ec1) obj;
                if (k70.p(this.a, ec1.a)) {
                    if (this.b != ec1.b) {
                    }
                }
            }
            return false;
        }
        return true;
    }

    public final String toString() {
        StringBuilder dl1 = new dl1("ThumbElement(interactionSource=");
        dl1.append(this.a);
        dl1.append(", checked=");
        dl1.append(this.b);
        dl1.append(", animationSpec=");
        dl1.append(this.c);
        dl1.append(')');
        return dl1.toString();
    }

    public final int hashCode() {
        return this.c.hashCode() + (((this.a.hashCode() * 31) + (this.b ? 1231 : 1237)) * 31);
    }

    public final li0 e() {
        hc1 li0 = new li0();
        li0.s = this.a;
        li0.t = this.b;
        li0.u = this.c;
        li0.y = Float.NaN;
        li0.z = Float.NaN;
        return li0;
    }

    public ec1(uj0 uj0, boolean z, p71 p71) {
        this.a = uj0;
        this.b = z;
        this.c = p71;
    }
}