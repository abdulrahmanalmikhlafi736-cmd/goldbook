package defpackage;

import android.util.LongSparseArray;
import com.almekhlafi.goldbook.MainActivity;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: e5 */
public final /* synthetic */ class e5 implements Runnable {
    public final /* synthetic */ int e;
    public final /* synthetic */ Object f;
    public final /* synthetic */ Object g;

    public final void run() {
        int i = this.e;
        Object obj = this.g;
        Object obj2 = this.f;
        switch (i) {
            case 0:
                vd1.k((h5) obj2, (LongSparseArray) obj);
                return;
            case 1:
                MainActivity mainActivity = (MainActivity) obj2;
                mainActivity.e.a(new bi((jn0) obj, mainActivity));
                return;
            case 2:
                ((ne) obj2).E((w20) obj);
                return;
            default:
                pl1 pl1 = (pl1) obj2;
                ud0 ud0 = (ud0) obj;
                if (!pl1.g) {
                    pl1.h = ud0;
                    ud0.a(pl1);
                }
                return;
        }
    }

    public /* synthetic */ e5(int i, Object obj, Object obj2) {
        this.e = i;
        this.f = obj;
        this.g = obj2;
    }
}