package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ej0 */
public final class ej0 extends nl {
    public /* synthetic */ Object h;
    public final /* synthetic */ tp i;
    public int j;

    public final Object p(Object obj) {
        this.h = obj;
        this.j |= Integer.MIN_VALUE;
        return this.i.i(null, null, this);
    }

    public ej0(tp tpVar, nl nlVar) {
        this.i = tpVar;
        super(nlVar);
    }
}