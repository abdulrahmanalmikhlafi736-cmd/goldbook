package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dl1 */
public final class dl1 {
    public final lq0 a = mc0.t(Boolean.TRUE);
    public final lq0 b = mc0.t(Boolean.FALSE);
    public final hq0 c = new br0(0.0f);
    public final jq0 d = new ad(0);
    public final hq0 e = new br0(1.0f);
    public final w50 f;
    public final w50 g;
    public long h;
    public long i;
    public long j;
    public long k;

    public dl1(String str) {
        this.f = new dl1(str.concat(" source"));
        this.g = new dl1(str.concat(" target"));
        this.h = -1;
        this.i = -1;
        this.j = -1;
        this.k = -1;
    }
}