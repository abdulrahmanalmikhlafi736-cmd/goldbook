package defpackage;

import android.os.CancellationSignal.OnCancelListener;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dj */
public final /* synthetic */ class dj implements OnCancelListener {
    public final /* synthetic */ s71 a;

    public final void onCancel() {
        this.a.a(null);
    }

    public /* synthetic */ dj(s71 s71) {
        this.a = s71;
    }
}