package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dr */
public final class dr {
    public final long a;

    public final String toString() {
        long j = this.a;
        if (j == 9205357640488583168L) {
            return "DpOffset.Unspecified";
        }
        StringBuilder dl1 = new dl1("(");
        dl1.append(br.c(Float.intBitsToFloat((int) (j >> 32))));
        dl1.append(", ");
        dl1.append(br.c(Float.intBitsToFloat((int) (4294967295L & j))));
        dl1.append(')');
        return dl1.toString();
    }

    public final boolean equals(Object obj) {
        if (obj instanceof dr) {
            if (this.a == ((dr) obj).a) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        long j = this.a;
        return (int) (j ^ (j >>> 32));
    }

    public /* synthetic */ dr(long j) {
        this.a = j;
    }
}