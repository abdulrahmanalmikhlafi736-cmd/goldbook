package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: el */
public final class el extends u91 implements m00 {
    public int i;
    public /* synthetic */ Object j;
    public final /* synthetic */ mf1 k;
    public final /* synthetic */ gl l;
    public final /* synthetic */ yc m;
    public final /* synthetic */ long n;
    public final /* synthetic */ a80 o;

    public final Object p(Object obj) {
        int i = this.i;
        if (i == 0) {
            nb0.t(obj);
            w11 w11 = (w11) this.j;
            long j = this.n;
            Object obj2 = this.l;
            Object obj3 = this.m;
            float r0 = gl.r0(obj2, obj3, j);
            Object obj4 = this.k;
            obj4.e = r0;
            z7 z7Var = new z7((gl) obj2, (mf1) obj4, this.o, w11);
            na naVar = new na(obj2, obj4, obj3, 2);
            this.i = 1;
            cm a = obj4.a(z7Var, naVar, this);
            cm cmVar = cm.e;
            if (a == cmVar) {
                return cmVar;
            }
        } else if (i == 1) {
            nb0.t(obj);
        } else {
            od.p("call to 'resume' before 'invoke' with coroutine");
            return null;
        }
        return we1.a;
    }

    public final ml n(ml mlVar, Object obj) {
        el elVar = new el(this.k, this.l, this.m, this.n, this.o, mlVar);
        elVar.j = obj;
        return elVar;
    }

    public final Object f(Object obj, Object obj2) {
        return ((el) n((ml) obj2, (w11) obj)).p(we1.a);
    }

    public el(mf1 mf1, gl glVar, yc ycVar, long j, a80 a80, ml mlVar) {
        this.k = mf1;
        this.l = glVar;
        this.m = ycVar;
        this.n = j;
        this.o = a80;
        super(2, mlVar);
    }
}