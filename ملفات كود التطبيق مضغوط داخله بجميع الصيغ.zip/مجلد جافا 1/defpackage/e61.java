package defpackage;

import java.util.Iterator;
import java.util.Map.Entry;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: e61 */
public final class e61 implements Iterator {
    public int e = -1;
    public boolean f;
    public Iterator g;
    public final /* synthetic */ c61 h;

    public final void remove() {
        if (this.f) {
            this.f = false;
            int i = c61.j;
            c61 c61 = this.h;
            c61.b();
            if (this.e < c61.e.size()) {
                int i2 = this.e;
                this.e = i2 - 1;
                c61.h(i2);
                return;
            }
            a().remove();
            return;
        }
        od.p("remove() was called before next()");
    }

    public final Object next() {
        this.f = true;
        int i = this.e + 1;
        this.e = i;
        c61 c61 = this.h;
        return i < c61.e.size() ? (Entry) c61.e.get(this.e) : (Entry) a().next();
    }

    public final boolean hasNext() {
        int i = this.e + 1;
        c61 c61 = this.h;
        if (i >= c61.e.size()) {
            if (c61.f.isEmpty() || !a().hasNext()) {
                return false;
            }
        }
        return true;
    }

    public final Iterator a() {
        if (this.g == null) {
            this.g = this.h.f.entrySet().iterator();
        }
        return this.g;
    }

    public e61(c61 c61) {
        this.h = c61;
    }
}