package defpackage;

import android.os.Looper;
import android.view.Choreographer;
import android.view.MotionEvent;
import android.view.View;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: e7 */
public final class e7 extends h90 implements i00 {
    public final /* synthetic */ int f;
    public final /* synthetic */ Object g;
    public final /* synthetic */ Object h;

    public final Object i(Object obj) {
        Throwable th;
        switch (this.f) {
            case 0:
                th = (Throwable) obj;
                d7 d7Var = (d7) this.h;
                f7 f7Var = (f7) this.g;
                synchronized (d7Var.i) {
                    d7Var.k.remove(f7Var);
                }
                return we1.a;
            case 1:
                th = (Throwable) obj;
                ((Choreographer) ((g7) this.h).f).removeFrameCallback((f7) this.g);
                return we1.a;
            case 2:
                ((ba0) this.h).d0(((mi0) obj).b((mi0) this.g));
                return we1.a;
            case 3:
                js0.m((js0) obj, (ks0) this.h, ((rb) this.g).s);
                return we1.a;
            case gu0.LONG_FIELD_NUMBER /*4*/:
                MotionEvent motionEvent = (MotionEvent) obj;
                jt0 jt0 = (jt0) this.g;
                if (motionEvent.getActionMasked() == 0) {
                    ((p3) this.h).f = ((Boolean) ((l7) jt0.e()).i(motionEvent)).booleanValue() ? it0.f : it0.g;
                } else {
                    ((l7) jt0.e()).i(motionEvent);
                }
                return we1.a;
            case gu0.STRING_FIELD_NUMBER /*5*/:
                js0.m((js0) obj, (ks0) this.h, ((n51) this.g).D);
                return we1.a;
            case gu0.STRING_SET_FIELD_NUMBER /*6*/:
                mj mjVar = (mj) obj;
                m00 m00 = (m00) this.g;
                pl1 pl1 = (pl1) this.h;
                if (!pl1.g) {
                    sd0 sd0 = mjVar.c;
                    View view = mjVar.a;
                    ud0 g = sd0.g();
                    pl1.i = m00;
                    if (pl1.h == null) {
                        if (k70.p(Looper.myLooper(), view.getHandler().getLooper())) {
                            pl1.h = g;
                            g.a(pl1);
                        } else {
                            view.post(new al(3, pl1, g));
                        }
                    } else if (g.d.compareTo(jd0.g) >= 0) {
                        pl1.f.A(new pi(-1723985096, true, new ek(pl1, mjVar, m00)));
                    }
                }
                return we1.a;
            default:
                js0 js0 = (js0) obj;
                ks0 ks0 = (ks0) this.h;
                float f = ((vl1) this.g).s;
                js0.getClass();
                js0.c(js0, ks0);
                ks0.R(n60.c(0, ks0.i), f, null);
                return we1.a;
        }
    }

    public /* synthetic */ e7(int i, Object obj, Object obj2) {
        this.f = i;
        this.h = obj;
        this.g = obj2;
        super(1);
    }
}