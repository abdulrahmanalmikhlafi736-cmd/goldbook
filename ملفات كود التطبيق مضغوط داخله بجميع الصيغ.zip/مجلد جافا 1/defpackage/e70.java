package defpackage;

import java.util.List;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: e70 */
public final class e70 {
    public final xf0 a;
    public final al b;
    public boolean c;

    public final boolean a(long j) {
        Object obj;
        List list = (List) this.b.f;
        int size = list.size();
        for (int i = 0; i < size; i++) {
            obj = list.get(i);
            if (sb0.k(((ft0) obj).a, j)) {
                break;
            }
        }
        obj = null;
        ft0 ft0 = (ft0) obj;
        return ft0 != null ? ft0.h : false;
    }

    public e70(xf0 xf0, al alVar) {
        this.a = xf0;
        this.b = alVar;
    }
}