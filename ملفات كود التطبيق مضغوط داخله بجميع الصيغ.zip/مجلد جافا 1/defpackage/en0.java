package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: en0 */
public final class en0 extends fl0 {
    public final sa d;
    public boolean e = true;

    public final void b() {
        sa saVar = this.d;
        switch (saVar.d) {
            case 0:
                ((ui) saVar.e).c.a();
                return;
            default:
                ((l5) saVar.e).i(saVar);
                return;
        }
    }

    public final void d(dl0 dl0) {
        dl0.getClass();
        qa qaVar = new qa(dl0);
        switch (this.d.d) {
        }
    }

    public final void g(boolean z) {
        this.e = z;
        z = z && this.d.b;
        f(z);
    }

    public en0(sa saVar, fn0 fn0) {
        boolean z = saVar.b;
        this.a = fn0;
        this.b = z;
        this.d = saVar;
    }

    public final void c(dl0 dl0) {
        qa qaVar = new qa(dl0);
        switch (this.d.d) {
        }
    }

    public final void a() {
        switch (this.d.d) {
        }
    }
}