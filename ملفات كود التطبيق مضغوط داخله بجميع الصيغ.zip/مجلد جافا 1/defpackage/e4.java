package defpackage;

import android.os.Build.VERSION;
import android.view.View;
import android.view.contentcapture.ContentCaptureSession;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: e4 */
public final /* synthetic */ class e4 extends w00 implements xz {
    public final /* synthetic */ int l;

    public final Object a() {
        int i = this.l;
        Object obj = this.f;
        switch (i) {
            case 0:
                Object alVar;
                View view = (View) obj;
                i = VERSION.SDK_INT;
                if (i >= 30) {
                    g1.f(view);
                }
                if (i >= 29) {
                    ContentCaptureSession a = zk.a(view);
                    if (a != null) {
                        alVar = new al(0, a, view);
                        return alVar;
                    }
                }
                alVar = null;
                return alVar;
            case 1:
                cy cyVar = (cy) obj;
                ik0 ik0 = cyVar.c;
                ik0 ik02 = cyVar.d;
                hy hyVar = cyVar.a;
                ry f = hyVar.f();
                long j = -9187201950435737472L;
                int i2;
                int i3;
                if (f == null) {
                    Object[] objArr = ik02.b;
                    long[] jArr = ik02.a;
                    int length = jArr.length - 2;
                    if (length >= 0) {
                        i2 = 7;
                        int i4 = 0;
                        while (true) {
                            long j2 = jArr[i4];
                            if (((((~j2) << i2) & j2) & -9187201950435737472L) != -9187201950435737472L) {
                                int i5 = 8 - ((~(i4 - length)) >>> 31);
                                i3 = 0;
                                while (i3 < i5) {
                                    if ((j2 & 255) >= 128) {
                                        j2 >>= 8;
                                        i3++;
                                    } else {
                                        ((cb) objArr[(i4 << 3) + i3]).s0();
                                        throw null;
                                    }
                                }
                                if (i5 != 8) {
                                }
                            }
                            if (i4 != length) {
                                i4++;
                            }
                        }
                    }
                } else {
                    i2 = 7;
                    if (f.r) {
                        int i6;
                        if (ik0.c(f) != null) {
                            f.x0();
                        }
                        f.w0();
                        if (!f.e.r) {
                            a5.b("visitAncestors called on an unattached node");
                        }
                        li0 li0 = f.e;
                        ba0 O = k70.O(f);
                        int i7 = 0;
                        while (O != null) {
                            if ((O.J.f.h & 5120) != 0) {
                                for (li0 = 
/*
Method generation error in method: e4.a():java.lang.Object, dex: 
jadx.core.utils.exceptions.CodegenException: Error generate insn: PHI: (r3_8 'li0' li0) = (r3_7 'li0' li0), (r3_16 'li0' li0) binds: {(r3_7 'li0' li0)=B:29:0x0093, (r3_16 'li0' li0)=B:94:0x009a} in method: e4.a():java.lang.Object, dex: 
	at jadx.core.codegen.InsnGen.makeInsn(Unknown Source:86)
	at jadx.core.codegen.RegionGen.makeLoop(Unknown Source:137)
	at jadx.core.codegen.RegionGen.makeRegion(Unknown Source:54)
	at jadx.core.codegen.RegionGen.makeSimpleRegion(Unknown Source:24)
	at jadx.core.codegen.RegionGen.makeRegion(Unknown Source:20)
	at jadx.core.codegen.RegionGen.makeRegionIndent(Unknown Source:3)
	at jadx.core.codegen.RegionGen.makeIf(Unknown Source:43)
	at jadx.core.codegen.RegionGen.makeRegion(Unknown Source:34)
	at jadx.core.codegen.RegionGen.makeSimpleRegion(Unknown Source:24)
	at jadx.core.codegen.RegionGen.makeRegion(Unknown Source:20)
	at jadx.core.codegen.RegionGen.makeRegionIndent(Unknown Source:3)
	at jadx.core.codegen.RegionGen.makeLoop(Unknown Source:277)
	at jadx.core.codegen.RegionGen.makeRegion(Unknown Source:54)
	at jadx.core.codegen.RegionGen.makeSimpleRegion(Unknown Source:24)
	at jadx.core.codegen.RegionGen.makeRegion(Unknown Source:20)
	at jadx.core.codegen.RegionGen.makeRegionIndent(Unknown Source:3)
	at jadx.core.codegen.RegionGen.makeIf(Unknown Source:43)
	at jadx.core.codegen.RegionGen.makeRegion(Unknown Source:34)
	at jadx.core.codegen.RegionGen.makeSimpleRegion(Unknown Source:24)
	at jadx.core.codegen.RegionGen.makeRegion(Unknown Source:20)
	at jadx.core.codegen.RegionGen.makeRegionIndent(Unknown Source:3)
	at jadx.core.codegen.RegionGen.makeIf(Unknown Source:80)
	at jadx.core.codegen.RegionGen.makeRegion(Unknown Source:34)
	at jadx.core.codegen.RegionGen.makeSimpleRegion(Unknown Source:24)
	at jadx.core.codegen.RegionGen.makeRegion(Unknown Source:20)
	at jadx.core.codegen.RegionGen.makeRegionIndent(Unknown Source:3)
	at jadx.core.codegen.RegionGen.makeSwitch(Unknown Source:102)
	at jadx.core.codegen.RegionGen.makeRegion(Unknown Source:44)
	at jadx.core.codegen.RegionGen.makeSimpleRegion(Unknown Source:24)
	at jadx.core.codegen.RegionGen.makeRegion(Unknown Source:20)
	at jadx.core.codegen.MethodGen.addInstructions(Unknown Source:40)
	at jadx.core.codegen.ClassGen.addMethod(Unknown Source:103)
	at jadx.core.codegen.ClassGen.addMethods(Unknown Source:51)
	at jadx.core.codegen.ClassGen.addClassBody(Unknown Source:22)
	at jadx.core.codegen.ClassGen.addClassCode(Unknown Source:24)
	at jadx.core.codegen.ClassGen.makeClass(Unknown Source:5)
	at jadx.core.codegen.CodeGen.visit(Unknown Source:13)
	at jadx.core.ProcessClass.process(Unknown Source:71)
	at jadx.api.JadxDecompiler.processClass(Unknown Source:4)
	at jadx.api.JavaClass.decompile(Unknown Source:19)
Caused by: jadx.core.utils.exceptions.CodegenException: PHI can be used only in fallback mode
	at jadx.core.codegen.InsnGen.fallbackOnlyInsn(Unknown Source:28)
	at jadx.core.codegen.InsnGen.makeInsnBody(Unknown Source:61)
	at jadx.core.codegen.InsnGen.makeInsn(Unknown Source:48)
	... 39 more

*/

    public /* synthetic */ e4(int i, Object obj, Class cls, String str, String str2, int i2, int i3, int i4) {
        this.l = i4;
        super(i, obj, cls, str, str2, i2, i3);
    }
}