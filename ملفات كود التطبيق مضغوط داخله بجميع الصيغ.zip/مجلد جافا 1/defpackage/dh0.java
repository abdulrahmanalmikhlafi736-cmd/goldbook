package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dh0 */
public final class dh0 {
    public final dh a;
    public final ke1 b;
    public final c51 c;
    public final yi0 d;

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null) {
            if (dh0.class == obj.getClass()) {
                dh0 dh0 = (dh0) obj;
                return k70.p(this.a, dh0.a) && k70.p(this.b, dh0.b) && k70.p(this.c, dh0.c) && k70.p(this.d, dh0.d);
            }
        }
        return false;
    }

    public final String toString() {
        StringBuilder dl1 = new dl1("Values(colorScheme=");
        dl1.append(this.a);
        dl1.append(", typography=");
        dl1.append(this.b);
        dl1.append(", shapes=");
        dl1.append(this.c);
        dl1.append(", motionScheme=");
        dl1.append(this.d);
        dl1.append(')');
        return dl1.toString();
    }

    public final int hashCode() {
        return this.d.hashCode() + ((this.c.hashCode() + ((this.b.hashCode() + (this.a.hashCode() * 31)) * 31)) * 31);
    }

    public dh0(dh dhVar, ke1 ke1, c51 c51, yi0 yi0) {
        this.a = dhVar;
        this.b = ke1;
        this.c = c51;
        this.d = yi0;
    }
}