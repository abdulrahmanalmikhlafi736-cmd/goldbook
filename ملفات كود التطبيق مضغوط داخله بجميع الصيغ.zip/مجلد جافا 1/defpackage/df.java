package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: df */
public final class df extends nl {
    public ef h;
    public Object i;
    public /* synthetic */ Object j;
    public final /* synthetic */ ef k;
    public int l;

    public final Object p(Object obj) {
        this.j = obj;
        this.l |= Integer.MIN_VALUE;
        return this.k.k(null, this);
    }

    public df(ef efVar, ml mlVar) {
        this.k = efVar;
        super(mlVar);
    }
}