package defpackage;

import android.content.Context;
import android.os.Bundle;
import com.almekhlafi.goldbook.MainActivity;
import java.util.ArrayList;
import java.util.LinkedHashMap;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ei */
public final /* synthetic */ class ei {
    public final /* synthetic */ MainActivity a;

    public final b81 a(Context context) {
        context.getClass();
        MainActivity mainActivity = this.a;
        Bundle k = ((al) mainActivity.h.g).k("android:support:activity-result");
        if (k == null) {
            return;
        }
        ii iiVar = mainActivity.l;
        LinkedHashMap linkedHashMap = iiVar.b;
        LinkedHashMap linkedHashMap2 = iiVar.a;
        Bundle bundle = iiVar.g;
        ArrayList integerArrayList = k.getIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS");
        ArrayList stringArrayList = k.getStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS");
        if (stringArrayList == null) {
            return;
        }
        if (integerArrayList == null) {
            return;
        }
        ArrayList stringArrayList2 = k.getStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS");
        if (stringArrayList2 != null) {
            iiVar.d.addAll(stringArrayList2);
        }
        k = k.getBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT");
        if (k != null) {
            bundle.putAll(k);
        }
        int size = stringArrayList.size();
        for (int i = 0; i < size; i++) {
            String str = (String) stringArrayList.get(i);
            if (linkedHashMap.containsKey(str)) {
                Integer num = (Integer) linkedHashMap.remove(str);
                if (!bundle.containsKey(str)) {
                    bk0.d(linkedHashMap2).remove(num);
                }
            }
            Object obj = integerArrayList.get(i);
            obj.getClass();
            int intValue = ((Number) obj).intValue();
            Object obj2 = stringArrayList.get(i);
            obj2.getClass();
            String str2 = (String) obj2;
            linkedHashMap2.put(Integer.valueOf(intValue), str2);
            iiVar.b.put(str2, Integer.valueOf(intValue));
        }
        return;
    }

    public /* synthetic */ ei(MainActivity mainActivity) {
        this.a = mainActivity;
    }
}