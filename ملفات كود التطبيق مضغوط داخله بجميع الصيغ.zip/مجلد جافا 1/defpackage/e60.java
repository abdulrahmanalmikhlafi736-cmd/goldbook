package defpackage;

import android.graphics.Rect;
import android.os.Build.VERSION;
import android.view.View;
import android.view.View.OnAttachStateChangeListener;
import android.view.ViewParent;
import android.view.autofill.AutofillManager;
import java.util.Collections;
import java.util.List;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: e60 */
public final class e60 extends og implements Runnable, an0, OnAttachStateChangeListener {
    public boolean g;
    public int h;
    public hk1 i;
    public final hk0 j;
    public final iq0 k = new h90(0);
    public final ak0 l = new h90(4);
    public final z61 m = new z61();

    public final void E(hk1 hk1) {
        boolean z;
        boolean z2;
        long j;
        long j2;
        long j3;
        boolean z3;
        long j4;
        c60 j5;
        hk1 hk12 = hk1;
        sj0 sj0 = pk1.a;
        int[] iArr = sj0.b;
        Object[] objArr = sj0.c;
        long[] jArr = sj0.a;
        int length = jArr.length - 2;
        if (length >= 0) {
            int i = 0;
            z = false;
            z2 = false;
            j = 16;
            j2 = 32;
            while (true) {
                long[] jArr2;
                int[] iArr2;
                Object[] objArr2;
                j3 = jArr[i];
                z3 = true;
                if (((((~j3) << 7) & j3) & -9187201950435737472L) != -9187201950435737472L) {
                    int i2 = 8;
                    int i3 = 8 - ((~(i - length)) >>> 31);
                    int i4 = 0;
                    j4 = 48;
                    while (i4 < i3) {
                        long j6;
                        long j7;
                        if ((j3 & 255) < 128) {
                            int i5 = (i << 3) + i4;
                            i2 = iArr[i5];
                            nk1 nk1 = (nk1) objArr[i5];
                            c60 i6 = hk12.a.i(i2);
                            jArr2 = jArr;
                            iArr2 = iArr;
                            j6 = (((((long) i6.a) << 48) | (((long) i6.b) << 32)) | (((long) i6.c) << 16)) | ((long) i6.d);
                            AutofillManager g = ((AutofillManager) this.j);
                            g.getClass();
                            dl1 dl1 = (dl1) g;
                            j7 = j3;
                            if (!wa0.i(j6, dl1.h)) {
                                dl1.h = j6;
                                z = true;
                                if (!wa0.i(j6, 0)) {
                                    z2 = z;
                                }
                            }
                            if (i2 != 8) {
                                j5 = hk12.a.j(i2);
                                objArr2 = objArr;
                                long j8 = (((((long) j5.b) << 32) | (((long) j5.a) << 48)) | (((long) j5.c) << 16)) | ((long) j5.d);
                                if (!wa0.i(dl1.i, j8)) {
                                    dl1.i = j8;
                                    z = true;
                                    if (!wa0.i(j8, 0)) {
                                        z2 = z;
                                    }
                                }
                            } else {
                                objArr2 = objArr;
                            }
                            dl1.a.setValue(Boolean.valueOf(hk12.a.u(i2)));
                            j6 = 8;
                        } else {
                            jArr2 = jArr;
                            iArr2 = iArr;
                            objArr2 = objArr;
                            j7 = j3;
                            j6 = i2;
                        }
                        j3 = j7 >> j6;
                        i4++;
                        i2 = j6;
                        objArr = objArr2;
                        jArr = jArr2;
                        iArr = iArr2;
                    }
                    jArr2 = jArr;
                    iArr2 = iArr;
                    objArr2 = objArr;
                    if (i3 != i2) {
                        break;
                    }
                } else {
                    jArr2 = jArr;
                    iArr2 = iArr;
                    objArr2 = objArr;
                    j4 = 48;
                }
                if (i == length) {
                    break;
                }
                i++;
                objArr = objArr2;
                jArr = jArr2;
                iArr = iArr2;
            }
        } else {
            j = 16;
            j2 = 32;
            z3 = true;
            j4 = 48;
            z = false;
            z2 = false;
        }
        mq h = hk12.a.h();
        if (h == null) {
            j3 = 0;
        } else {
            j5 = h.a();
            j3 = (((((long) j5.a) << j4) | (((long) j5.b) << j2)) | (((long) j5.c) << j)) | ((long) j5.d);
        }
        hk0 hk0 = this.j;
        nk1.a.getClass();
        AutofillManager g2 = ((AutofillManager) hk0);
        g2.getClass();
        dl1 dl12 = (dl1) g2;
        dl12.a.setValue(Boolean.valueOf(wa0.i(j3, 0) ^ 1));
        if (!wa0.i(dl12.h, j3)) {
            dl12.h = j3;
            dl12.i = j3;
            z = z3;
            if (!wa0.i(j3, 0)) {
                z2 = z;
            }
        }
        if (h == null) {
            ak0 ak0 = this.l;
            if (ak0.b > 0) {
                ak0.d();
                this.m.clear();
                z = z3;
            }
        } else {
            int i7;
            List b = VERSION.SDK_INT >= 28 ? f9.b(h.a) : Collections.EMPTY_LIST;
            int size = b.size();
            ak0 ak02 = this.l;
            if (size < ak02.b) {
                ak02.l(b.size(), this.l.b);
                this.m.e(b.size(), this.m.size());
                z = z3;
            } else {
                size = b.size() - this.l.b;
                i7 = 0;
                while (i7 < size) {
                    ak0 ak03 = this.l;
                    ak03.a(mc0.t(b.get(ak03.b)));
                    z61 z61 = this.m;
                    StringBuilder dl13 = new dl1("display cutout rect ");
                    dl13.append(this.l.b);
                    z61.add(new dl1(dl13.toString()));
                    i7++;
                    z = z3;
                }
            }
            size = b.size();
            for (i7 = 0; i7 < size; i7++) {
                Rect rect = (Rect) b.get(i7);
                mk0 mk0 = (mk0) this.l.f(i7);
                if (!k70.p(mk0.getValue(), rect)) {
                    mk0.setValue(rect);
                    z = z3;
                }
            }
            if (!b.isEmpty()) {
                z2 = z3;
            }
        }
        if ((z2 || this.k.g() != 0) && r14) {
            boolean z4;
            iq0 iq0 = this.k;
            iq0.h(iq0.g() + 1);
            synchronized (n61.c) {
                ik0 ik0 = n61.j.h;
                if (ik0 != null) {
                    boolean z5 = z3;
                    if (ik0.h() == z5) {
                        z4 = z5;
                    }
                }
                z4 = false;
            }
            if (z4) {
                n61.a();
            }
        }
    }

    public final al h(mj1 mj1, al alVar) {
        hk1 hk1 = this.i;
        boolean z = false;
        this.g = false;
        this.i = null;
        if (mj1.a.b() > 0 && hk1 != null) {
            int d = mj1.a.d();
            this.h |= d;
            nk1 nk1 = (nk1) pk1.a.b(d);
            if (nk1 != null) {
                AutofillManager g = ((AutofillManager) this.j);
                g.getClass();
                dl1 dl1 = (dl1) g;
                c60 i = hk1.a.i(d);
                long j = (((((long) i.a) << 48) | (((long) i.b) << 32)) | (((long) i.c) << 16)) | ((long) i.d);
                long j2 = dl1.h;
                if (!wa0.i(j, j2)) {
                    dl1.j = j2;
                    dl1.k = j;
                    dl1.b.setValue(Boolean.TRUE);
                    lj1 lj1 = mj1.a;
                    dl1.c.h(lj1.c());
                    dl1.e.h(lj1.a());
                    dl1.d.h(lj1.b());
                    iq0 iq0 = this.k;
                    iq0.h(iq0.g() + 1);
                    synchronized (n61.c) {
                        ik0 ik0 = n61.j.h;
                        if (ik0 != null && ik0.h()) {
                            z = true;
                        }
                    }
                    if (z) {
                        n61.a();
                        return alVar;
                    }
                }
            }
        }
        return alVar;
    }

    public e60() {
        super(1);
        hk0 h90 = new h90(9);
        nk1.a.getClass();
        h90.m(mk1.b, new dl1("caption bar"));
        h90.m(mk1.c, new dl1("display cutout"));
        h90.m(mk1.d, new dl1("ime"));
        h90.m(mk1.e, new dl1("mandatory system gestures"));
        h90.m(mk1.f, new dl1("navigation bars"));
        h90.m(mk1.g, new dl1("status bars"));
        h90.m(mk1.h, new dl1("system gestures"));
        h90.m(mk1.i, new dl1("tappable element"));
        h90.m(mk1.j, new dl1("waterfall"));
        this.j = h90;
    }

    public final void e(mj1 mj1) {
        boolean z = false;
        this.g = false;
        int d = mj1.a.d();
        this.h &= ~d;
        this.i = null;
        nk1 nk1 = (nk1) pk1.a.b(d);
        if (nk1 != null) {
            AutofillManager g = ((AutofillManager) this.j);
            g.getClass();
            dl1 dl1 = (dl1) g;
            dl1.c.h(0.0f);
            dl1.e.h(1.0f);
            dl1.d.h(0);
            dl1.c.h(0.0f);
            dl1.b.setValue(Boolean.FALSE);
            dl1.j = -1;
            dl1.k = -1;
            iq0 iq0 = this.k;
            iq0.h(iq0.g() + 1);
            synchronized (n61.c) {
                ik0 ik0 = n61.j.h;
                if (ik0 != null && ik0.h()) {
                    z = true;
                }
            }
            if (z) {
                n61.a();
            }
        }
    }

    public final hk1 g(hk1 hk1, List list) {
        int size = list.size();
        for (int i = 0; i < size; i++) {
            mj1 mj1 = (mj1) list.get(i);
            nk1 nk1 = (nk1) pk1.a.b(mj1.a.d());
            if (nk1 != null) {
                AutofillManager g = ((AutofillManager) this.j);
                g.getClass();
                dl1 dl1 = (dl1) g;
                if (((Boolean) dl1.b.getValue()).booleanValue()) {
                    lj1 lj1 = mj1.a;
                    dl1.c.h(lj1.c());
                    dl1.e.h(lj1.a());
                    dl1.d.h(lj1.b());
                }
            }
        }
        E(hk1);
        return hk1;
    }

    public final void onViewDetachedFromWindow(View view) {
        ViewParent parent = view.getParent();
        View view2 = parent instanceof View ? (View) parent : null;
        if (view2 != null) {
            view = view2;
        }
        int i = vg1.a;
        qg1.b(view, null);
        vg1.b(view, null);
    }

    public final void onViewAttachedToWindow(View view) {
        ViewParent parent = view.getParent();
        View view2 = parent instanceof View ? (View) parent : null;
        if (view2 != null) {
            view = view2;
        }
        int i = vg1.a;
        qg1.b(view, this);
        vg1.b(view, this);
    }

    public final hk1 b(View view, hk1 hk1) {
        if (this.g) {
            this.i = hk1;
            if (VERSION.SDK_INT == 30) {
                view.post(this);
                return hk1;
            }
        } else if (this.h == 0) {
            E(hk1);
        }
        return hk1;
    }

    public final void run() {
        if (this.g) {
            this.h = 0;
            this.g = false;
            hk1 hk1 = this.i;
            if (hk1 != null) {
                E(hk1);
                this.i = null;
            }
        }
    }

    public final void f(mj1 mj1) {
        this.g = true;
    }
}