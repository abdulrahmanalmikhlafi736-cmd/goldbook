package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: e11 */
public final class e11 extends dp implements ak, vm0 {
    public x5 A;
    public q11 B;
    public cp C;
    public y5 D;
    public x5 E;
    public boolean F;
    public r11 u;
    public bp0 v;
    public boolean w;
    public jo x;
    public uj0 y;
    public boolean z;

    public final void w0(x5 x5Var, jo joVar, uj0 uj0, bp0 bp0, r11 r11, boolean z, boolean z2) {
        Object obj;
        this.u = r11;
        this.v = bp0;
        Object obj2 = 1;
        if (this.z != z) {
            this.z = z;
            obj = 1;
        } else {
            obj = null;
        }
        if (k70.p(this.A, x5Var)) {
            obj2 = null;
        } else {
            this.A = x5Var;
        }
        if (!(obj == null && (obj2 == null || z))) {
            cp cpVar = this.C;
            if (cpVar != null) {
                s0(cpVar);
            }
            this.C = null;
            u0();
        }
        this.w = z2;
        this.x = joVar;
        this.y = uj0;
        boolean v0 = v0();
        this.F = v0;
        q11 q11 = this.B;
        if (q11 != null) {
            q11.I0(this.z ? this.E : this.A, joVar, uj0, bp0, r11, z2, v0);
        }
    }

    public final void z() {
        y5 y5Var = (y5) j70.z(this, jp0.a);
        if (!k70.p(y5Var, this.D)) {
            this.D = y5Var;
            this.E = null;
            cp cpVar = this.C;
            if (cpVar != null) {
                s0(cpVar);
            }
            this.C = null;
            u0();
            q11 q11 = this.B;
            if (q11 != null) {
                r11 r11 = this.u;
                bp0 bp0 = this.v;
                q11.I0(this.z ? this.E : this.A, this.x, this.y, bp0, r11, this.w, this.F);
            }
        }
    }

    public final void u0() {
        cp cpVar = this.C;
        if (cpVar == null) {
            if (this.z) {
                sb0.r(this, new x1(14, (Object) this));
            }
            x5 x5Var = this.z ? this.E : this.A;
            if (x5Var != null) {
                dp dpVar = x5Var.i;
                if (!dpVar.e.r) {
                    r0(dpVar);
                    this.C = dpVar;
                }
            }
        } else if (!((li0) cpVar).e.r) {
            r0(cpVar);
        }
    }

    public final void h0() {
        this.F = v0();
        u0();
        if (this.B == null) {
            r11 r11 = this.u;
            q11 d11 = new d11(this.z ? this.E : this.A, this.x, this.y, this.v, r11, this.w, this.F);
            r0(d11);
            this.B = d11;
        }
    }

    public final void k0() {
        boolean v0 = v0();
        if (this.F != v0) {
            this.F = v0;
            r11 r11 = this.u;
            bp0 bp0 = this.v;
            boolean z = this.z;
            w0(z ? this.E : this.A, this.x, this.y, bp0, r11, z, this.w);
        }
    }

    public final boolean v0() {
        return (this.r ? k70.O(this).D : o90.e) != o90.f || this.v == bp0.e;
    }

    public final void j0() {
        cp cpVar = this.C;
        if (cpVar != null) {
            s0(cpVar);
        }
    }

    public final boolean e0() {
        return false;
    }
}