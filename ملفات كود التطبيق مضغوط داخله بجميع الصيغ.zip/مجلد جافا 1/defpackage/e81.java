package defpackage;

import java.util.concurrent.atomic.AtomicReference;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: e81 */
public final class e81 extends n0 {
    public final AtomicReference a = new AtomicReference(null);

    public final boolean a(m0 m0Var) {
        d81 d81 = (d81) m0Var;
        AtomicReference atomicReference = this.a;
        if (atomicReference.get() != null) {
            return false;
        }
        atomicReference.set(ac.B);
        return true;
    }

    public final ml[] b(m0 m0Var) {
        d81 d81 = (d81) m0Var;
        this.a.set(null);
        return a5.a;
    }
}