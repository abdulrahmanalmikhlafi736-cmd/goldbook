package defpackage;

import android.graphics.Canvas;
import android.graphics.Outline;
import android.view.View;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dh1 */
public final class dh1 extends View {
    public static final zp o = new h90(1);
    public final cs e;
    public final ue f;
    public final te g;
    public boolean h;
    public Outline i;
    public boolean j = true;
    public jp k = ac.l;
    public o90 l = o90.e;
    public i00 m;
    public i20 n;

    public final void dispatchDraw(Canvas canvas) {
        ue ueVar = this.f;
        t3 t3Var = ueVar.a;
        Canvas canvas2 = t3Var.a;
        t3Var.a = canvas;
        jp jpVar = this.k;
        o90 o90 = this.l;
        long floatToRawIntBits = (long) Float.floatToRawIntBits((float) getWidth());
        long floatToRawIntBits2 = (((long) Float.floatToRawIntBits((float) getHeight())) & 4294967295L) | (floatToRawIntBits << 32);
        i20 i20 = this.n;
        i00 i00 = this.m;
        te teVar = this.g;
        k9 k9Var = teVar.f;
        se seVar = ((te) k9Var.h).e;
        jp jpVar2 = seVar.a;
        o90 o902 = seVar.b;
        re q = k9Var.q();
        k9 k9Var2 = teVar.f;
        re reVar = q;
        o90 o903 = o902;
        long t = k9Var2.t();
        re reVar2 = reVar;
        i20 i202 = (i20) k9Var2.g;
        k9Var2.C(jpVar);
        k9Var2.D(o90);
        k9Var2.B(t3Var);
        k9Var2.E(floatToRawIntBits2);
        k9Var2.g = i20;
        t3Var.i();
        try {
            i00.i(teVar);
            t3Var.g();
            k9Var2.C(jpVar2);
            k9Var2.D(o903);
            k9Var2.B(reVar2);
            k9Var2.E(t);
            k9Var2.g = i202;
            ueVar.a.a = canvas2;
            this.h = false;
        } catch (Throwable th) {
            o90 o904 = o903;
            re reVar3 = reVar2;
            t3Var.g();
            k9Var2.C(jpVar2);
            k9Var2.D(o904);
            k9Var2.B(reVar3);
            k9Var2.E(t);
            k9Var2.g = i202;
        }
    }

    public dh1(cs csVar, ue ueVar, te teVar) {
        super(csVar.getContext());
        this.e = csVar;
        this.f = ueVar;
        this.g = teVar;
        setOutlineProvider(o);
        k20.a.getClass();
        this.m = i4.E;
        setWillNotDraw(false);
        setClipBounds(null);
    }

    public final void invalidate() {
        if (!this.h) {
            this.h = true;
            super.invalidate();
        }
    }

    public final void setCanUseCompositingLayer$ui_graphics(boolean z) {
        if (this.j != z) {
            this.j = z;
            invalidate();
        }
    }

    public final boolean getCanUseCompositingLayer$ui_graphics() {
        return this.j;
    }

    public final ue getCanvasHolder() {
        return this.f;
    }

    public final View getOwnerView() {
        return this.e;
    }

    public final boolean hasOverlappingRendering() {
        return this.j;
    }

    public final void setInvalidated(boolean z) {
        this.h = z;
    }

    public final void forceLayout() {
    }

    public final void onLayout(boolean z, int i, int i2, int i3, int i4) {
    }
}