package defpackage;

import android.view.View;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: e9 */
public final class e9 {
    public static final e9 a = new Object();

    public final boolean a(View view) {
        return view.isShowingLayoutBounds();
    }
}