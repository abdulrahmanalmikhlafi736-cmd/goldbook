package defpackage;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: du0 */
public final class du0 extends l10 {
    private static final du0 DEFAULT_INSTANCE;
    private static volatile oq0 PARSER = null;
    public static final int STRINGS_FIELD_NUMBER = 1;
    private c70 strings_ = kv0.h;

    public static void l(du0 du0, Iterable iterable) {
        int i;
        c70 c70 = du0.strings_;
        if (!((kv0) c70).e) {
            kv0 kv0 = (kv0) c70;
            i = kv0.g;
            du0.strings_ = kv0.c(i == 0 ? 10 : i * 2);
        }
        c70 c702 = du0.strings_;
        Charset charset = d70.a;
        if (iterable instanceof yc0) {
            List d = ((yc0) iterable).d();
            if (c702 == null) {
                ((kv0) c702).getClass();
                Iterator it = d.iterator();
                if (it.hasNext()) {
                    Object next = it.next();
                    next.getClass();
                    if (next instanceof zd) {
                        throw null;
                    } else if (next instanceof byte[]) {
                        byte[] bArr = (byte[]) next;
                        zd.c(bArr, 0, bArr.length);
                        throw null;
                    } else {
                        String str = (String) next;
                        throw null;
                    }
                }
            }
            od.d();
        } else if (iterable instanceof su0) {
            ((kv0) c702).addAll((Collection) iterable);
        } else {
            if ((c702 instanceof ArrayList) && (iterable instanceof Collection)) {
                ((ArrayList) c702).ensureCapacity(((Collection) iterable).size() + ((kv0) c702).g);
            }
            kv0 kv02 = (kv0) c702;
            int i2 = kv02.g;
            for (Object next2 : iterable) {
                if (next2 == null) {
                    StringBuilder dl1 = new dl1("Element at index ");
                    dl1.append(kv02.g - i2);
                    dl1.append(" is null.");
                    String stringBuilder = dl1.toString();
                    for (i = kv02.g - 1; i >= i2; i--) {
                        kv02.remove(i);
                    }
                    throw new dl1(stringBuilder);
                }
                kv02.add(next2);
            }
        }
    }

    public final Object c(int i) {
        switch (fu0.N(i)) {
            case 0:
                return Byte.valueOf((byte) 1);
            case 1:
                return null;
            case 2:
                Object[] objArr = new Object[]{"strings_"};
                return new rv0(DEFAULT_INSTANCE, "\u0001\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0000\u0001\u001a", objArr);
            case 3:
                return new du0();
            case gu0.LONG_FIELD_NUMBER /*4*/:
                return new j10(DEFAULT_INSTANCE);
            case gu0.STRING_FIELD_NUMBER /*5*/:
                return DEFAULT_INSTANCE;
            case gu0.STRING_SET_FIELD_NUMBER /*6*/:
                oq0 oq0 = PARSER;
                if (oq0 != null) {
                    return oq0;
                }
                Object obj;
                synchronized (du0.class) {
                    try {
                        obj = PARSER;
                        if (obj == null) {
                            obj = new Object();
                            PARSER = obj;
                        }
                    } finally {
                    }
                }
                return obj;
            default:
                throw new UnsupportedOperationException();
        }
    }

    static {
        du0 du0 = new du0();
        DEFAULT_INSTANCE = du0;
        l10.j(du0.class, du0);
    }

    public static cu0 o() {
        return (cu0) ((j10) DEFAULT_INSTANCE.c(5));
    }

    public static du0 m() {
        return DEFAULT_INSTANCE;
    }

    public final c70 n() {
        return this.strings_;
    }
}