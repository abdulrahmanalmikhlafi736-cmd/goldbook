package defpackage;

import android.os.Bundle;
import com.almekhlafi.goldbook.MainActivity;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: di */
public final /* synthetic */ class di implements vz0 {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;

    public final Bundle a() {
        int i = this.a;
        Object obj = this.b;
        Bundle bundle;
        switch (i) {
            case 0:
                MainActivity mainActivity = (MainActivity) obj;
                bundle = new Bundle();
                ii iiVar = mainActivity.l;
                iiVar.getClass();
                LinkedHashMap linkedHashMap = iiVar.b;
                bundle.putIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS", new ArrayList(linkedHashMap.values()));
                bundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS", new ArrayList(linkedHashMap.keySet()));
                bundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS", new ArrayList(iiVar.d));
                bundle.putBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT", new Bundle(iiVar.g));
                return bundle;
            case 1:
                Map e = ((nz0) obj).e();
                bundle = new Bundle();
                for (Entry entry : e.entrySet()) {
                    String str = (String) entry.getKey();
                    List list = (List) entry.getValue();
                    bundle.putParcelableArrayList(str, list instanceof ArrayList ? (ArrayList) list : new ArrayList(list));
                }
                return bundle;
            default:
                Entry entry2;
                Object[] objArr;
                pa paVar = (pa) obj;
                LinkedHashMap linkedHashMap2 = (LinkedHashMap) paVar.d;
                linkedHashMap2.getClass();
                int size = linkedHashMap2.size();
                bh0 bh0 = vt.e;
                bh0 bh02;
                if (size == 0) {
                    bh02 = bh0;
                } else if (size != 1) {
                    bh02 = new LinkedHashMap(linkedHashMap2);
                } else {
                    entry2 = (Entry) linkedHashMap2.entrySet().iterator().next();
                    bh02 = Collections.singletonMap(entry2.getKey(), entry2.getValue());
                    bh02.getClass();
                }
                for (Entry entry3 : bh02.entrySet()) {
                    paVar.j(((d81) entry3.getValue()).getValue(), (String) entry3.getKey());
                }
                linkedHashMap2 = (LinkedHashMap) paVar.b;
                linkedHashMap2.getClass();
                size = linkedHashMap2.size();
                if (size != 0) {
                    if (size != 1) {
                        bh0 = new LinkedHashMap(linkedHashMap2);
                    } else {
                        entry2 = (Entry) linkedHashMap2.entrySet().iterator().next();
                        bh0 = Collections.singletonMap(entry2.getKey(), entry2.getValue());
                        bh0.getClass();
                    }
                }
                for (Entry entry32 : bh0.entrySet()) {
                    paVar.j(((vz0) entry32.getValue()).a(), (String) entry32.getKey());
                }
                LinkedHashMap linkedHashMap3 = (LinkedHashMap) paVar.a;
                if (linkedHashMap3.isEmpty()) {
                    objArr = new zp0[0];
                } else {
                    ArrayList h90 = new h90(linkedHashMap3.size());
                    for (Entry entry4 : linkedHashMap3.entrySet()) {
                        h90.add(new ad1((String) entry4.getKey(), entry4.getValue()));
                    }
                    objArr = (zp0[]) h90.toArray(new zp0[0]);
                }
                return a5.j((zp0[]) Arrays.copyOf(objArr, objArr.length));
        }
    }

    public /* synthetic */ di(int i, Object obj) {
        this.a = i;
        this.b = obj;
    }
}