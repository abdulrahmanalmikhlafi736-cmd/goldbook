package defpackage;

import android.window.BackEvent;
import android.window.OnBackAnimationCallback;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dn0 */
public final class dn0 implements OnBackAnimationCallback {
    public final /* synthetic */ bn0 a;

    public final void onBackCancelled() {
        bn0 bn0 = this.a;
        p3 p3Var = bn0.a;
        if (p3Var != null) {
            if (!bn0.b) {
                p3Var.g(bn0, null);
            }
            il0 il0 = (il0) p3Var.f;
            il0.getClass();
            if (bn0.equals(il0.h)) {
                if (-1 == il0.g) {
                    fl0 fl0 = il0.f;
                    if (fl0 == null) {
                        fl0 = il0.c(-1);
                    }
                    il0.f = null;
                    il0.g = 0;
                    il0.h = null;
                    if (fl0 != null) {
                        fl0.a();
                    }
                    d81 d81 = il0.a;
                    d81.getClass();
                    d81.i(null, jl0.b);
                }
            }
            bn0.b = false;
            return;
        }
        od.p("This input is not added to any dispatcher.");
    }

    public final void onBackProgressed(BackEvent backEvent) {
        backEvent.getClass();
        dl0 a = jb0.a(backEvent);
        bn0 bn0 = this.a;
        p3 p3Var = bn0.a;
        if (p3Var != null) {
            if (bn0.b) {
                il0 il0 = (il0) p3Var.f;
                il0.getClass();
                if (bn0.equals(il0.h)) {
                    if (-1 == il0.g) {
                        fl0 fl0 = il0.f;
                        if (fl0 == null) {
                            fl0 = il0.c(-1);
                        }
                        if (fl0 != null) {
                            fl0.c(a);
                        }
                        d81 d81 = il0.a;
                        kl0 kl0 = new kl0(a);
                        d81.getClass();
                        d81.i(null, kl0);
                    }
                }
            }
            return;
        }
        od.p("This input is not added to any dispatcher.");
    }

    public final void onBackStarted(BackEvent backEvent) {
        backEvent.getClass();
        dl0 a = jb0.a(backEvent);
        bn0 bn0 = this.a;
        p3 p3Var = bn0.a;
        if (p3Var != null) {
            if (!bn0.b) {
                p3Var.g(bn0, a);
                bn0.b = true;
            }
            return;
        }
        od.p("This input is not added to any dispatcher.");
    }

    public dn0(bn0 bn0) {
        this.a = bn0;
    }

    public final void onBackInvoked() {
        this.a.a();
    }
}