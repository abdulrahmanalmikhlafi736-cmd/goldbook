package defpackage;

import android.content.ContentResolver;
import android.content.Context;
import android.graphics.Typeface;
import android.graphics.Typeface.CustomFallbackBuilder;
import android.graphics.fonts.Font;
import android.graphics.fonts.FontFamily;
import android.graphics.fonts.FontFamily.Builder;
import android.graphics.fonts.FontStyle;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.text.TextUtils;
import android.util.Log;
import java.io.IOException;
import java.util.Objects;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: de1 */
public class de1 extends jb0 {
    public final FontFamily C(rz[] rzVarArr, ContentResolver contentResolver) {
        Builder builder = null;
        for (rz rzVar : rzVarArr) {
            Font D;
            if (Objects.equals(rzVar.a.getScheme(), "systemfont")) {
                D = D(rzVar);
            } else {
                try {
                    Uri uri = rzVar.a;
                    String str = rzVar.e;
                    ParcelFileDescriptor openFileDescriptor = contentResolver.openFileDescriptor(uri, "r", null);
                    if (openFileDescriptor == null) {
                        if (openFileDescriptor != null) {
                            openFileDescriptor.close();
                        }
                        D = null;
                    } else {
                        try {
                            Font.Builder ttcIndex = new Font.Builder(openFileDescriptor).setWeight(rzVar.c).setSlant(rzVar.d).setTtcIndex(rzVar.b);
                            if (!TextUtils.isEmpty(str)) {
                                ttcIndex.setFontVariationSettings(str);
                            }
                            D = ttcIndex.build();
                            openFileDescriptor.close();
                        } catch (Throwable th) {
                            th.addSuppressed(th);
                        }
                    }
                } catch (IOException e) {
                    Log.w("TypefaceCompatApi29Impl", "Font load failed", e);
                }
            }
            if (D != null) {
                if (builder == null) {
                    builder = new Builder(D);
                } else {
                    builder.addFont(D);
                }
            }
        }
        return builder == null ? null : builder.build();
    }

    public final Typeface e(Context context, rz[] rzVarArr) {
        try {
            FontFamily C = C(rzVarArr, context.getContentResolver());
            if (C == null) {
                return null;
            }
            CustomFallbackBuilder customFallbackBuilder = new CustomFallbackBuilder(C);
            FontStyle xo0 = new xo0(400, 0);
            Font font = C.getFont(0);
            int E = de1.E(xo0, font.getStyle());
            for (int i = 1; i < C.getSize(); i++) {
                Font font2 = C.getFont(i);
                int E2 = de1.E(xo0, font2.getStyle());
                if (E2 < E) {
                    font = font2;
                    E = E2;
                }
            }
            return customFallbackBuilder.setStyle(font.getStyle()).build();
        } catch (Exception e) {
            Log.w("TypefaceCompatApi29Impl", "Font load failed", e);
            return null;
        }
    }

    public static int E(FontStyle fontStyle, FontStyle fontStyle2) {
        return (Math.abs(fontStyle.getWeight() - fontStyle2.getWeight()) / 100) + (fontStyle.getSlant() == fontStyle2.getSlant() ? 0 : 2);
    }

    public Font D(rz rzVar) {
        throw new dl1("Getting font from Typeface is not supported before API31");
    }
}