package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: e0 */
public final class e0 {
    public static final e0 b;
    public static final e0 c;
    public final Throwable a;

    static {
        if (k0.h) {
            c = null;
            b = null;
            return;
        }
        c = new e0(null, false);
        b = new e0(null, true);
    }

    public e0(Throwable th, boolean z) {
        this.a = th;
    }
}