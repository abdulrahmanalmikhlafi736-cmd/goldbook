package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: et0 */
public final class et0 {
    public final long a;
    public final long b;
    public final boolean c;

    public et0(long j, long j2, boolean z) {
        this.a = j;
        this.b = j2;
        this.c = z;
    }
}