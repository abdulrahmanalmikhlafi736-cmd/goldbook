package defpackage;

import androidx.core.content.FileProvider;
import java.util.Arrays;
import java.util.ListIterator;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ds0 */
public final class ds0 extends c0 {
    public final Object[] e;
    public final Object[] f;
    public final int g;
    public final int h;

    public final c0 p(Object[] objArr, int i, int i2, int i3) {
        int i4 = this.g - i;
        Object[] objArr2;
        if (i4 != 1) {
            objArr2 = this.f;
            Object[] copyOf = Arrays.copyOf(objArr2, 32);
            int i5 = i4 - 1;
            if (i3 < i5) {
                ba.Y(objArr2, copyOf, i3, i3 + 1, i4);
            }
            copyOf[i5] = null;
            return new ds0(objArr, copyOf, (i + i4) - 1, i2);
        } else if (i2 == 0) {
            if (objArr.length == 33) {
                objArr = Arrays.copyOf(objArr, 32);
            }
            return new b61(objArr);
        } else {
            k1 k1Var = new k1(null);
            objArr = ds0.l(objArr, i2, i - 1, k1Var);
            objArr.getClass();
            Object obj = k1Var.a;
            obj.getClass();
            objArr2 = (Object[]) obj;
            if (objArr[1] != null) {
                return new ds0(objArr, objArr2, i, i2);
            }
            Object obj2 = objArr[0];
            obj2.getClass();
            return new ds0((Object[]) obj2, objArr2, i, i2 - 5);
        }
    }

    public final Object[] o(Object[] objArr, int i, int i2, k1 k1Var) {
        int q = ua0.q(i2, i);
        int i3 = 31;
        if (i == 0) {
            Object[] copyOf = q == 0 ? new Object[32] : Arrays.copyOf(objArr, 32);
            ba.Y(objArr, copyOf, q, q + 1, 32);
            copyOf[31] = k1Var.a;
            k1Var.a = objArr[q];
            return copyOf;
        }
        if (objArr[31] == null) {
            i3 = ua0.q(q() - 1, i);
        }
        objArr = Arrays.copyOf(objArr, 32);
        i -= 5;
        int i4 = q + 1;
        if (i4 <= i3) {
            while (true) {
                Object obj = objArr[i3];
                obj.getClass();
                objArr[i3] = o((Object[]) obj, i, 0, k1Var);
                if (i3 == i4) {
                    break;
                }
                i3--;
            }
        }
        Object obj2 = objArr[q];
        obj2.getClass();
        objArr[q] = o((Object[]) obj2, i, i2, k1Var);
        return objArr;
    }

    public static Object[] j(Object[] objArr, int i, int i2, Object obj, k1 k1Var) {
        int q = ua0.q(i2, i);
        if (i == 0) {
            Object[] copyOf = q == 0 ? new Object[32] : Arrays.copyOf(objArr, 32);
            ba.Y(objArr, copyOf, q + 1, q, 31);
            k1Var.a = objArr[31];
            copyOf[q] = obj;
            return copyOf;
        }
        Object[] copyOf2 = Arrays.copyOf(objArr, 32);
        i -= 5;
        Object obj2 = objArr[q];
        obj2.getClass();
        copyOf2[q] = ds0.j((Object[]) obj2, i, i2, obj, k1Var);
        while (true) {
            q++;
            if (q >= 32 || copyOf2[q] == null) {
                return copyOf2;
            }
            Object obj3 = objArr[q];
            obj3.getClass();
            copyOf2[q] = ds0.j((Object[]) obj3, i, 0, k1Var.a, k1Var);
        }
        return copyOf2;
    }

    public final ds0 k(Object[] objArr, int i, Object obj) {
        int q = q();
        int i2 = this.g;
        q = i2 - q;
        Object[] objArr2 = this.f;
        Object[] copyOf = Arrays.copyOf(objArr2, 32);
        if (q < 32) {
            ba.Y(objArr2, copyOf, i + 1, i, q);
            copyOf[i] = obj;
            return new ds0(objArr, copyOf, i2 + 1, this.h);
        }
        Object obj2 = objArr2[31];
        ba.Y(objArr2, copyOf, i + 1, i, q - 1);
        copyOf[i] = obj;
        Object[] objArr3 = new Object[32];
        objArr3[0] = obj2;
        return m(objArr, copyOf, objArr3);
    }

    public ds0(Object[] objArr, Object[] objArr2, int i, int i2) {
        this.e = objArr;
        this.f = objArr2;
        this.g = i;
        this.h = i2;
        if ((a() > 32 ? 1 : null) == null) {
            StringBuilder dl1 = new dl1("Trie-based persistent vector should have at least 33 elements, got ");
            dl1.append(a());
            FileProvider.a(dl1.toString());
        }
        int length = objArr2.length;
    }

    public final c0 b(int i, Object obj) {
        int i2 = this.g;
        kb0.g(i, i2);
        if (i == i2) {
            return c(obj);
        }
        i2 = q();
        Object[] objArr = this.e;
        if (i >= i2) {
            return k(objArr, i - i2, obj);
        }
        k1 k1Var = new k1(null);
        return k(ds0.j(objArr, this.h, i, obj, k1Var), 0, k1Var.a);
    }

    public final c0 i(int i, Object obj) {
        int i2 = this.g;
        vd1.f(i, i2);
        int q = q();
        Object[] objArr = this.e;
        Object[] objArr2 = this.f;
        int i3 = this.h;
        if (q > i) {
            return new ds0(ds0.r(objArr, i3, i, obj), objArr2, i2, i3);
        }
        Object[] copyOf = Arrays.copyOf(objArr2, 32);
        copyOf[i & 31] = obj;
        return new ds0(objArr, copyOf, i2, i3);
    }

    public final d81 c(Object obj) {
        int q = q();
        int i = this.g;
        q = i - q;
        Object[] objArr = this.e;
        Object[] objArr2 = this.f;
        if (q < 32) {
            objArr2 = Arrays.copyOf(objArr2, 32);
            objArr2[q] = obj;
            return new ds0(objArr, objArr2, i + 1, this.h);
        }
        Object[] objArr3 = new Object[32];
        objArr3[0] = obj;
        return m(objArr, objArr2, objArr3);
    }

    public final Object get(int i) {
        Object[] objArr;
        vd1.f(i, a());
        if (q() <= i) {
            objArr = this.f;
        } else {
            Object[] objArr2 = this.e;
            for (int i2 = this.h; i2 > 0; i2 -= 5) {
                Object obj = objArr2[ua0.q(i, i2)];
                obj.getClass();
                objArr2 = (Object[]) obj;
            }
            objArr = objArr2;
        }
        return objArr[i & 31];
    }

    public final c0 h(int i) {
        vd1.f(i, a());
        int q = q();
        int i2 = this.h;
        Object[] objArr = this.e;
        return i >= q ? p(objArr, q, i2, i - q) : p(o(objArr, i2, i, new k1(this.f[0])), q, i2, 0);
    }

    public final ds0 m(Object[] objArr, Object[] objArr2, Object[] objArr3) {
        int i = this.g;
        int i2 = i >> 5;
        int i3 = this.h;
        if (i2 <= (1 << i3)) {
            return new ds0(n(i3, objArr, objArr2), objArr3, i + 1, i3);
        }
        Object[] objArr4 = new Object[32];
        objArr4[0] = objArr;
        i3 += 5;
        return new ds0(n(i3, objArr4, objArr2), objArr3, i + 1, i3);
    }

    public static Object[] l(Object[] objArr, int i, int i2, k1 k1Var) {
        Object[] objArr2;
        int q = ua0.q(i2, i);
        if (i == 5) {
            k1Var.a = objArr[q];
            objArr2 = null;
        } else {
            Object obj = objArr[q];
            obj.getClass();
            objArr2 = ds0.l((Object[]) obj, i - 5, i2, k1Var);
        }
        if (objArr2 == null && q == 0) {
            return null;
        }
        objArr = Arrays.copyOf(objArr, 32);
        objArr[q] = objArr2;
        return objArr;
    }

    public final Object[] n(int i, Object[] objArr, Object[] objArr2) {
        int q = ua0.q(a() - 1, i);
        objArr = objArr != null ? Arrays.copyOf(objArr, 32) : new Object[32];
        if (i == 5) {
            objArr[q] = objArr2;
            return objArr;
        }
        objArr[q] = n(i - 5, (Object[]) objArr[q], objArr2);
        return objArr;
    }

    public static Object[] r(Object[] objArr, int i, int i2, Object obj) {
        int q = ua0.q(i2, i);
        objArr = Arrays.copyOf(objArr, 32);
        if (i == 0) {
            objArr[q] = obj;
            return objArr;
        }
        Object obj2 = objArr[q];
        obj2.getClass();
        objArr[q] = ds0.r((Object[]) obj2, i - 5, i2, obj);
        return objArr;
    }

    public final ListIterator listIterator(int i) {
        kb0.g(i, this.g);
        return new fs0(this.e, this.f, i, this.g, (this.h / 5) + 1);
    }

    public final c0 g(b0 b0Var) {
        es0 es0 = new es0(this, this.e, this.f, this.h);
        es0.z(b0Var);
        return es0.c();
    }

    public final es0 f() {
        return new es0(this, this.e, this.f, this.h);
    }

    public final int q() {
        return (this.g - 1) & -32;
    }

    public final int a() {
        return this.g;
    }
}