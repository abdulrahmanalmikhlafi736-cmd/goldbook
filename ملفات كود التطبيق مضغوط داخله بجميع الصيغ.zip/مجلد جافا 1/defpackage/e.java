package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: e */
public final /* synthetic */ class e extends w00 implements i00 {
    public final /* synthetic */ int l;

    public final Object i(Object obj) {
        int i = this.l;
        we1 we1 = we1.a;
        Object obj2 = this.f;
        switch (i) {
            case 0:
                boolean booleanValue = ((Boolean) obj).booleanValue();
                dg dgVar = (dg) obj2;
                wj0 wj0 = dgVar.G;
                if (booleanValue) {
                    dgVar.y0();
                } else {
                    if (dgVar.u != null) {
                        Object[] objArr = wj0.c;
                        long[] jArr = wj0.a;
                        int length = jArr.length - 2;
                        if (length >= 0) {
                            int i2 = 0;
                            while (true) {
                                Object[] objArr2;
                                long j = jArr[i2];
                                if (((((~j) << 7) & j) & -9187201950435737472L) != -9187201950435737472L) {
                                    int i3 = 8;
                                    int i4 = 8 - ((~(i2 - length)) >>> 31);
                                    int i5 = 0;
                                    while (i5 < i4) {
                                        long j2;
                                        if ((255 & j) < 128) {
                                            j2 = i3;
                                            objArr2 = objArr;
                                            wl1.B(dgVar.d0(), null, new j(dgVar, (ou0) objArr[(i2 << 3) + i5], null, 0), 3);
                                        } else {
                                            objArr2 = objArr;
                                            j2 = i3;
                                        }
                                        j >>= j2;
                                        i5++;
                                        i3 = j2;
                                        objArr = objArr2;
                                    }
                                    objArr2 = objArr;
                                    if (i4 == i3) {
                                    }
                                } else {
                                    objArr2 = objArr;
                                }
                                if (i2 != length) {
                                    i2++;
                                    objArr = objArr2;
                                }
                            }
                        }
                        ou0 ou0 = dgVar.I;
                        if (ou0 != null) {
                            wl1.B(dgVar.d0(), null, new j(dgVar, ou0, null, 1), 3);
                        }
                    }
                    wj0.a();
                    dgVar.I = null;
                }
                return we1;
            default:
                ((d80) obj2).l((Throwable) obj);
                return we1;
        }
    }

    public /* synthetic */ e(int i, Object obj, Class cls, String str, String str2, int i2, int i3, int i4) {
        this.l = i4;
        super(i, obj, cls, str, str2, i2, i3);
    }
}