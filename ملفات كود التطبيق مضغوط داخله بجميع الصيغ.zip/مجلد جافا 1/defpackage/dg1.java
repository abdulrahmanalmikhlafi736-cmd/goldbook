package defpackage;

import java.util.Arrays;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dg1 */
public abstract class dg1 {
    public static final /* synthetic */ int a = 0;

    static {
        int[] iArr = new int[2];
        r3 = new float[2];
        float[][] fArr = new float[2][];
        fArr[0] = new float[2];
        int i = 1;
        fArr[1] = r3;
        int i2 = iArr[0];
        int i3 = 3;
        if (i2 != 0) {
            if (i2 != 1) {
                if (i2 == 2 || i2 == 3) {
                    i2 = 2;
                } else if (i2 == 4) {
                    i2 = 4;
                } else if (i2 == 5) {
                    i2 = 5;
                }
            }
            i2 = 1;
        } else {
            i2 = 3;
        }
        float[] fArr2 = fArr[0];
        float[] fArr3 = fArr[1];
        int length = (fArr2.length % 2) + (fArr2.length / 2);
        nq0[] nq0Arr = new nq0[length];
        int i4 = 0;
        while (i4 < length) {
            nq0[] nq0Arr2;
            int i5;
            Object obj;
            Object obj2;
            int i6 = i4 * 2;
            float f = fArr2[i6];
            int i7 = i6 + 1;
            float f2 = fArr2[i7];
            float f3 = fArr3[i6];
            float f4 = fArr3[i7];
            nq0 h90 = new h90(19);
            f3 -= f;
            float f5 = f4 - f2;
            int i8 = i;
            float[] fArr4 = new float[101];
            if (i2 != i3 && Math.abs(f3) >= 0.001f) {
                if (Math.abs(f5) >= 0.001f) {
                    f2 -= f4;
                    float[] fArr5 = vd1.a;
                    float f6 = f2;
                    int i9 = i8;
                    float f7 = 0.0f;
                    float f8 = 0.0f;
                    while (true) {
                        double d = (double) ((float) (((((double) i9) * 90.0d) / 90.0d) * 0.017453292519943295d));
                        float f9 = f2;
                        f4 = ((float) Math.sin(d)) * f3;
                        f2 = f9 * ((float) Math.cos(d));
                        f = f2 - f6;
                        nq0Arr2 = nq0Arr;
                        i5 = i2;
                        f7 += (float) Math.hypot((double) (f4 - f8), (double) f);
                        fArr5[i9] = f7;
                        if (i9 == 90) {
                            break;
                        }
                        i9++;
                        f8 = f4;
                        i2 = i5;
                        nq0Arr = nq0Arr2;
                        f6 = f2;
                        f2 = f9;
                    }
                    i2 = i8;
                    while (true) {
                        fArr5[i2] = fArr5[i2] / f7;
                        if (i2 == 90) {
                            break;
                        }
                        i2++;
                    }
                    for (int i10 = 0; i10 < 101; i10++) {
                        float f10 = ((float) i10) / 100.0f;
                        int binarySearch = Arrays.binarySearch(fArr5, 0, 91, f10);
                        if (binarySearch >= 0) {
                            fArr4[i10] = ((float) binarySearch) / 90.0f;
                        } else if (binarySearch == -1) {
                            fArr4[i10] = 0.0f;
                        } else {
                            binarySearch = -binarySearch;
                            int i11 = binarySearch - 2;
                            binarySearch--;
                            f4 = (float) i11;
                            f = fArr5[i11];
                            fArr4[i10] = (((f10 - f) / (fArr5[binarySearch] - f)) + f4) / 90.0f;
                        }
                    }
                    obj = null;
                    nq0Arr2[i4] = h90;
                    i4++;
                    obj2 = obj;
                    i = i8;
                    i2 = i5;
                    nq0Arr = nq0Arr2;
                    i3 = 3;
                }
            }
            obj = null;
            nq0Arr2 = nq0Arr;
            i5 = i2;
            Math.hypot((double) f5, (double) f3);
            nq0Arr2[i4] = h90;
            i4++;
            obj2 = obj;
            i = i8;
            i2 = i5;
            nq0Arr = nq0Arr2;
            i3 = 3;
        }
    }
}