package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: eo0 */
public final class eo0 extends xo0 {
    public static final eo0 c = new xo0(0, 0, 3);

    public final void a(pg pgVar, m9 m9Var, a61 a61, uw0 uw0, yo0 yo0) {
        a61.l(0);
    }
}