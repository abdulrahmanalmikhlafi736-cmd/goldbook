package defpackage;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.function.UnaryOperator;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: e30 */
public final class e30 implements List, w80 {
    public final ak0 e = new h90(16);
    public final vj0 f = new h90(16);
    public int g = -1;

    /* JADX WARNING: Missing block: B:16:0x003b, code:
            return r0;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final long a() {
        long f = zi1.f(Float.POSITIVE_INFINITY, false, false);
        int i = this.g + 1;
        int i2 = this.e.b - 1;
        if (i <= i2) {
            while (true) {
                vj0 vj0 = this.f;
                if (i >= 0) {
                    if (i >= vj0.b) {
                        break;
                    }
                    long j = vj0.a[i];
                    if (vn.m(j, f) < 0) {
                        f = j;
                    }
                    if (vn.v(f) >= 0.0f || !vn.F(f)) {
                        if (i == i2) {
                            break;
                        }
                        i++;
                    } else {
                        break;
                    }
                }
                vj0.getClass();
                break;
            }
            od.f("Index must be between 0 and size");
            f = 0;
        }
        return f;
    }

    public final long b(int i, int i2) {
        if (i < i2) {
            this.e.l(i, i2);
            vj0 vj0 = this.f;
            if (i >= 0) {
                int i3 = vj0.b;
                if (i <= i3 && i2 >= 0 && i2 <= i3) {
                    if (i2 < i) {
                        od.m("The end index must be < start index");
                        return;
                    } else if (i2 != i) {
                        if (i2 < i3) {
                            long[] jArr = vj0.a;
                            ba.X(jArr, jArr, i, i2, i3);
                        }
                        vj0.b -= i2 - i;
                    }
                }
            } else {
                vj0.getClass();
            }
            od.f("Index must be between 0 and size");
            return;
        }
        return;
    }

    public final int indexOf(Object obj) {
        if (!(obj instanceof li0)) {
            return -1;
        }
        li0 li0 = (li0) obj;
        int size = size() - 1;
        if (size >= 0) {
            int i = 0;
            while (!k70.p(this.e.f(i), li0)) {
                if (i != size) {
                    i++;
                }
            }
            return i;
        }
        return -1;
    }

    public final int lastIndexOf(Object obj) {
        if (!(obj instanceof li0)) {
            return -1;
        }
        li0 li0 = (li0) obj;
        for (int size = size() - 1; -1 < size; size--) {
            if (k70.p(this.e.f(size), li0)) {
                return size;
            }
        }
        return -1;
    }

    public final boolean containsAll(Collection collection) {
        for (li0 contains : collection) {
            if (!contains(contains)) {
                return false;
            }
        }
        return true;
    }

    public final boolean contains(Object obj) {
        return (obj instanceof li0) && indexOf((li0) obj) != -1;
    }

    public final void clear() {
        this.g = -1;
        this.e.d();
        this.f.b = 0;
    }

    public final Object get(int i) {
        Object f = this.e.f(i);
        f.getClass();
        return (li0) f;
    }

    public final /* bridge */ /* synthetic */ void add(int i, Object obj) {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final boolean addAll(int i, Collection collection) {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final /* bridge */ /* synthetic */ void addFirst(Object obj) {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final /* bridge */ /* synthetic */ void addLast(Object obj) {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final Iterator iterator() {
        return new c30(this, 0, 7);
    }

    public final ListIterator listIterator() {
        return new c30(this, 0, 7);
    }

    public final boolean removeAll(Collection collection) {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final /* bridge */ /* synthetic */ Object removeFirst() {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final /* bridge */ /* synthetic */ Object removeLast() {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final void replaceAll(UnaryOperator unaryOperator) {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final boolean retainAll(Collection collection) {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final /* bridge */ /* synthetic */ Object set(int i, Object obj) {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final void sort(Comparator comparator) {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final boolean isEmpty() {
        return this.e.h();
    }

    public final List subList(int i, int i2) {
        return new c30(this, i, i2);
    }

    public final int size() {
        return this.e.b;
    }

    public final Object[] toArray() {
        return vd1.G(this);
    }

    public final /* bridge */ /* synthetic */ boolean add(Object obj) {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final boolean addAll(Collection collection) {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final ListIterator listIterator(int i) {
        return new c30(this, i, 6);
    }

    public final boolean remove(Object obj) {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final Object[] toArray(Object[] objArr) {
        return vd1.H(this, objArr);
    }
}