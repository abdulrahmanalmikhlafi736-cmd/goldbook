package defpackage;

import android.util.Log;
import android.view.autofill.AutofillManager;
import android.view.autofill.AutofillValue;
import androidx.core.content.FileProvider;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.CancellationException;
import java.util.concurrent.atomic.AtomicReference;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dw0 */
public final class dw0 extends sj {
    public static final AtomicReference A = new AtomicReference(Boolean.FALSE);
    public static final d81 z = ac.c(cs0.h);
    public final g7 a;
    public final k9 b = new k9(new yv0(this, 1));
    public final Object c = new Object();
    public a80 d;
    public Throwable e;
    public final ArrayList f = new ArrayList();
    public List g;
    public ik0 h = new ik0();
    public final qk0 i = new qk0(new yj[16]);
    public final ArrayList j = new ArrayList();
    public final ArrayList k = new ArrayList();
    public final hk0 l = new hk0();
    public final al m = new h90(13);
    public final hk0 n = new hk0();
    public final hk0 o = new hk0();
    public ArrayList p;
    public ik0 q;
    public ne r;
    public final d81 s = ac.c(null);
    public boolean t;
    public final d81 u = ac.c(aw0.g);
    public final k9 v = new h90(11);
    public final c80 w;
    public final sl x;
    public final av0 y;

    public final List N(List list, ik0 ik0) {
        int i;
        HashMap h90 = new h90(list.size());
        int size = list.size();
        for (i = 0; i < size; i++) {
            Object obj = list.get(i);
            ((gj0) obj).getClass();
            ArrayList arrayList = h90.get(null);
            if (arrayList == null) {
                arrayList = new ArrayList();
                h90.put(null, arrayList);
            }
            arrayList.add(obj);
        }
        for (Entry entry : h90.entrySet()) {
            Object obj2 = (yj) entry.getKey();
            List list2 = (List) entry.getValue();
            if (obj2.z.F) {
                FileProvider.a("Check failed");
            }
            l lVar = new l(16, obj2);
            c alVar = new al(19, obj2, ik0);
            g61 j = n61.j();
            lk0 lk0 = j instanceof lk0 ? (lk0) j : null;
            if (lk0 != null) {
                lk0 D = lk0.D(lVar, alVar);
                if (D != null) {
                    try {
                        g61 j2 = D.j();
                        try {
                            ArrayList h902;
                            int size2;
                            zp0 zp0;
                            ArrayList h903;
                            synchronized (this.c) {
                                try {
                                    hk0 hk0;
                                    h902 = new h90(list2.size());
                                    int size3 = list2.size();
                                    for (int i2 = 0; i2 < size3; i2++) {
                                        gj0 gj0 = (gj0) list2.get(i2);
                                        hk0 = this.l;
                                        gj0.getClass();
                                        Object a = oj0.a(hk0);
                                        gj0 gj02 = (gj0) a;
                                        h902.add(new ad1(gj0, a));
                                    }
                                    size2 = h902.size();
                                    for (i = 0; i < size2; i++) {
                                        zp0 = (zp0) h902.get(i);
                                        if (zp0.f == null) {
                                            al alVar2 = this.m;
                                            ((gj0) zp0.e).getClass();
                                            if (((hk0) alVar2.f).b(null) != null) {
                                                h903 = new h90(h902.size());
                                                i = h902.size();
                                                for (size3 = 0; size3 < i; size3++) {
                                                    zp0 zp02 = (zp0) h902.get(size3);
                                                    if (zp02.f == null) {
                                                        al alVar3 = this.m;
                                                        ((gj0) zp02.e).getClass();
                                                        hk0 = (hk0) alVar3.f;
                                                        ll0 ll0 = (ll0) oj0.a(hk0);
                                                        if (hk0.i()) {
                                                            ((hk0) alVar3.g).a();
                                                        }
                                                    }
                                                    h903.add(zp02);
                                                }
                                                h902 = h903;
                                            }
                                        }
                                    }
                                } catch (Throwable th) {
                                    throw th;
                                }
                            }
                            size2 = h902.size();
                            i = 0;
                            while (i < size2) {
                                if (((zp0) h902.get(i)).f == null) {
                                    i++;
                                } else {
                                    size2 = h902.size();
                                    i = 0;
                                    while (i < size2) {
                                        if (((zp0) h902.get(i)).f != null) {
                                            i++;
                                        } else {
                                            int i3;
                                            h903 = new h90(h902.size());
                                            i = h902.size();
                                            for (i3 = 0; i3 < i; i3++) {
                                                zp0 = (zp0) h902.get(i3);
                                                if (zp0.f == null) {
                                                    gj0 gj03 = (gj0) zp0.e;
                                                }
                                            }
                                            synchronized (this.c) {
                                                try {
                                                    yg.O(h903, this.k);
                                                } catch (Throwable th2) {
                                                    throw th2;
                                                }
                                            }
                                            h903 = new h90(h902.size());
                                            i = h902.size();
                                            for (i3 = 0; i3 < i; i3++) {
                                                Object obj3 = h902.get(i3);
                                                if (((zp0) obj3).f != null) {
                                                    h903.add(obj3);
                                                }
                                            }
                                            h902 = h903;
                                            obj2.r(h902);
                                            g61.q(j2);
                                            dw0.B(D);
                                        }
                                    }
                                    obj2.r(h902);
                                    g61.q(j2);
                                    dw0.B(D);
                                }
                            }
                            obj2.r(h902);
                            g61.q(j2);
                            dw0.B(D);
                        } catch (Throwable th22) {
                            g61.q(j2);
                            throw th22;
                        }
                    } catch (Throwable th222) {
                        dw0.B(D);
                        throw th222;
                    }
                }
            }
            od.p("Cannot create a mutable snapshot of an read-only snapshot");
            return null;
        }
        return tg.c0(h90.keySet());
    }

    public final void a(yj yjVar, m00 m00) {
        aw0 aw0;
        int i;
        boolean z = yjVar.z.F;
        synchronized (this.c) {
            aw0 aw02 = (aw0) this.u.getValue();
            aw0 = aw0.f;
            i = 1;
            if (aw02.compareTo(aw0) > 0) {
                i = 1 ^ I().contains(yjVar);
            }
        }
        try {
            l lVar = new l(16, (Object) yjVar);
            c alVar = new al(19, yjVar, null);
            g61 j = n61.j();
            lk0 lk0 = j instanceof lk0 ? (lk0) j : null;
            if (lk0 != null) {
                lk0 D = lk0.D(lVar, alVar);
                if (D != null) {
                    try {
                        g61 j2 = D.j();
                        try {
                            yjVar.j(m00);
                            synchronized (this.c) {
                                if (((aw0) this.u.getValue()).compareTo(aw0) > 0 && !I().contains(yjVar)) {
                                    this.f.add(yjVar);
                                    this.g = null;
                                }
                            }
                            if (!z) {
                                n61.j().m();
                            }
                            try {
                                L(yjVar);
                                try {
                                    yjVar.d();
                                    yjVar.f();
                                    if (!z) {
                                        n61.j().m();
                                    }
                                    return;
                                } catch (Throwable th) {
                                    P(th, null);
                                    return;
                                }
                            } catch (Throwable th2) {
                                P(th2, yjVar);
                                return;
                            }
                        } finally {
                            g61.q(j2);
                        }
                    } finally {
                        dw0.B(D);
                    }
                }
            }
            throw new dl1("Cannot create a mutable snapshot of an read-only snapshot");
        } catch (Throwable th22) {
            if (i != 0) {
                synchronized (this.c) {
                    P(th22, yjVar);
                }
            }
            P(th22, yjVar);
        }
    }

    public final le D() {
        d81 d81 = this.u;
        int compareTo = ((aw0) d81.getValue()).compareTo(aw0.f);
        d81 d812 = this.s;
        ArrayList arrayList = this.k;
        ArrayList arrayList2 = this.j;
        qk0 qk0 = this.i;
        ne neVar;
        if (compareTo <= 0) {
            List I = I();
            for (int i = 0; i < I.size(); i++) {
                yj yjVar = (yj) I.get(i);
            }
            this.f.clear();
            this.g = ut.e;
            this.h = new ik0();
            qk0.g();
            arrayList2.clear();
            arrayList.clear();
            this.p = null;
            neVar = this.r;
            if (neVar != null) {
                neVar.l(null);
            }
            this.r = null;
            ((AutofillValue) d812);
            return null;
        }
        Object value = d812.getValue();
        aw0 aw0 = aw0.j;
        aw0 aw02 = aw0.g;
        if (value == null) {
            if (this.d == null) {
                this.h = new ik0();
                qk0.g();
                if (E() || G()) {
                    aw02 = aw0.h;
                }
            } else {
                if (qk0.g == 0) {
                    if (!(this.h.h() || !arrayList2.isEmpty() || !arrayList.isEmpty() || E() || G())) {
                        if (!this.l.j()) {
                            aw02 = aw0.i;
                        }
                    }
                }
                aw02 = aw0;
            }
        }
        d81.i(null, aw02);
        if (aw02 != aw0) {
            return null;
        }
        neVar = this.r;
        this.r = null;
        return neVar;
    }

    public dw0(sl slVar) {
        g7 g7Var = new g7(new yv0(this, 0));
        this.a = g7Var;
        c80 c80 = new c80((a80) slVar.k(e3.S));
        c80.r(new l(17, (Object) this));
        this.w = c80;
        this.x = slVar.i(g7Var).i(c80);
        this.y = new h90(5);
    }

    public final void P(Throwable th, yj yjVar) {
        if (!((Boolean) A.get()).booleanValue() || (th instanceof zi)) {
            synchronized (this.c) {
                Log.e("ComposeInternal", "Error was captured in composition.", th);
                zv0 zv0 = (zv0) this.s.getValue();
                if (zv0 == null) {
                    d81 d81 = this.s;
                    zv0 = new zv0(th);
                    d81.getClass();
                    d81.i(null, zv0);
                } else {
                    throw zv0.a;
                }
            }
            throw th;
        }
        synchronized (this.c) {
            try {
                Log.e("ComposeInternal", "Error was captured in composition while live edit was enabled.", th);
                this.j.clear();
                this.i.g();
                this.h = new ik0();
                this.k.clear();
                this.l.a();
                this.n.a();
                d81 d812 = this.s;
                zv0 zv02 = new zv0(th);
                d812.getClass();
                d812.i(null, zv02);
                if (yjVar != null) {
                    R(yjVar);
                }
                if (D() != null) {
                    FileProvider.a("expected to go to inactive state due to composition error");
                }
            } finally {
            }
        }
    }

    /* JADX WARNING: Missing block: B:13:?, code:
            r0 = r1.size();
            r2 = 0;
     */
    /* JADX WARNING: Missing block: B:14:0x002c, code:
            if (r2 >= r0) goto L_0x004c;
     */
    /* JADX WARNING: Missing block: B:15:0x002e, code:
            ((defpackage.yj) r1.get(r2)).x(r3);
     */
    /* JADX WARNING: Missing block: B:16:0x0045, code:
            if (((defpackage.aw0) r6.u.getValue()).compareTo(defpackage.aw0.f) <= 0) goto L_0x004c;
     */
    /* JADX WARNING: Missing block: B:17:0x0047, code:
            r2 = r2 + 1;
     */
    /* JADX WARNING: Missing block: B:19:0x004c, code:
            r0 = r6.c;
     */
    /* JADX WARNING: Missing block: B:20:0x004e, code:
            monitor-enter(r0);
     */
    /* JADX WARNING: Missing block: B:23:0x0053, code:
            if (D() != null) goto L_0x005d;
     */
    /* JADX WARNING: Missing block: B:24:0x0055, code:
            r6 = F();
     */
    /* JADX WARNING: Missing block: B:25:0x0059, code:
            monitor-exit(r0);
     */
    /* JADX WARNING: Missing block: B:26:0x005a, code:
            return r6;
     */
    /* JADX WARNING: Missing block: B:30:0x0064, code:
            throw new defpackage.dl1("called outside of runRecomposeAndApplyChanges");
     */
    /* JADX WARNING: Missing block: B:34:0x0069, code:
            monitor-enter(r6.c);
     */
    /* JADX WARNING: Missing block: B:36:?, code:
            r6 = r6.h;
            r6.getClass();
            r2 = r3.iterator();
     */
    /* JADX WARNING: Missing block: B:38:0x0077, code:
            if (r2.hasNext() != false) goto L_0x0079;
     */
    /* JADX WARNING: Missing block: B:39:0x0079, code:
            r6.k(r2.next());
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean Q() {
        synchronized (this.c) {
            if (this.h.g()) {
                boolean F = F();
                return F;
            }
            List I = I();
            p01 p01 = new p01(this.h);
            this.h = new ik0();
        }
    }

    public final yj O(yj yjVar, ik0 ik0) {
        if (yjVar.z.F || yjVar.A == 3) {
            return null;
        }
        ik0 ik02 = this.q;
        if (ik02 == null || ik02.c(yjVar) != 1) {
            l lVar = new l(16, (Object) yjVar);
            c alVar = new al(19, yjVar, ik0);
            g61 j = n61.j();
            lk0 lk0 = j instanceof lk0 ? (lk0) j : null;
            if (lk0 != null) {
                lk0 D = lk0.D(lVar, alVar);
                if (D != null) {
                    try {
                        g61 j2 = D.j();
                        if (ik0 != null) {
                            try {
                                if (ik0.h()) {
                                    va alVar2 = new al(8, ik0, yjVar);
                                    d10 d10 = yjVar.z;
                                    if (d10.F) {
                                        FileProvider.a("Preparing a composition while composing is not supported");
                                    }
                                    d10.F = true;
                                    try {
                                        alVar2.a();
                                    } finally {
                                        d10.F = false;
                                    }
                                }
                            } catch (Throwable th) {
                                g61.q(j2);
                            }
                        }
                        boolean ik03 = yjVar.w();
                        g61.q(j2);
                        return ik03 ? yjVar : null;
                    } finally {
                        dw0.B(D);
                    }
                }
            }
            od.p("Cannot create a mutable snapshot of an read-only snapshot");
        }
    }

    public static final void x(dw0 dw0) {
        int i;
        ak0 h90;
        synchronized (dw0.c) {
            try {
                i = 0;
                if (dw0.l.j()) {
                    ak0 b = oj0.b(dw0.l);
                    dw0.l.a();
                    al alVar = dw0.m;
                    ((hk0) alVar.f).a();
                    ((hk0) alVar.g).a();
                    dw0.o.a();
                    h90 = new h90(b.b);
                    Object[] objArr = b.a;
                    int i2 = b.b;
                    for (int i3 = 0; i3 < i2; i3++) {
                        gj0 gj0 = (gj0) objArr[i3];
                        h90.a(new ad1(gj0, ((AutofillManager) dw0.n)));
                    }
                    dw0.n.a();
                } else {
                    h90 = tm0.b;
                    h90.getClass();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        Object[] objArr2 = h90.a;
        int i4 = h90.b;
        while (i < i4) {
            zp0 zp0 = (zp0) objArr2[i];
            gj0 gj02 = (gj0) zp0.e;
            fj0 fj0 = (fj0) zp0.f;
            i++;
        }
    }

    public final ik0 n(yj yjVar, l51 l51, ik0 ik0) {
        k9 k9Var = this.v;
        try {
            Q();
            yjVar.x(new p01(ik0));
            l51 l512 = yjVar.t;
            yjVar.t = l51;
            try {
                yj O = O(yjVar, null);
                if (O != null) {
                    L(yjVar);
                    O.d();
                    O.f();
                }
                ik0 ik02 = (ik0) k9Var.p();
                if (ik02 == null) {
                    ik02 = o01.a;
                    ik02.getClass();
                }
                yjVar.t = l512;
                return ik02;
            } finally {
                yjVar.t = l512;
            }
        } finally {
            k9Var.A(null);
        }
    }

    public static final void A(dw0 dw0, a80 a80) {
        synchronized (dw0.c) {
            Throwable th = dw0.e;
            if (th != null) {
                throw th;
            } else if (((aw0) dw0.u.getValue()).compareTo(aw0.f) <= 0) {
                throw new dl1("Recomposer shut down");
            } else if (dw0.d == null) {
                dw0.d = a80;
                if (dw0.D() != null) {
                    FileProvider.a("called outside of runRecomposeAndApplyChanges");
                }
            } else {
                throw new dl1("Recomposer already running");
            }
        }
    }

    public static final Object w(dw0 dw0, cw0 cw0) {
        if (dw0.H()) {
            return we1.a;
        }
        a1 a1Var;
        ne neVar = new ne(1, ac.x(cw0));
        neVar.t();
        synchronized (dw0.c) {
            if (dw0.H()) {
                a1Var = neVar;
            } else {
                dw0.r = neVar;
                a1Var = null;
            }
        }
        if (a1Var != null) {
            ((AutofillValue) a1Var);
        }
        cm s = neVar.s();
        return s == cm.e ? s : we1.a;
    }

    public final void J() {
        le D;
        synchronized (this.c) {
            D = D();
            if (((aw0) this.u.getValue()).compareTo(aw0.f) > 0) {
            } else {
                Throwable th = this.e;
                CancellationException dl1 = new dl1("Recomposer shutdown; frame clock awaiter will never resume");
                dl1.initCause(th);
                throw dl1;
            }
        }
        if (D != null) {
            ((AutofillValue) ((ne) D));
        }
    }

    public final void C() {
        synchronized (this.c) {
            if (((aw0) this.u.getValue()).compareTo(aw0.i) >= 0) {
                d81 d81 = this.u;
                aw0 aw0 = aw0.f;
                d81.getClass();
                d81.i(null, aw0);
            }
        }
        this.w.a(null);
    }

    public final boolean H() {
        boolean z;
        synchronized (this.c) {
            if (!this.h.h()) {
                if (this.i.g == 0) {
                    if (!E()) {
                        if (!G()) {
                            z = false;
                        }
                    }
                }
            }
            z = true;
        }
        return z;
    }

    public final void l(yj yjVar) {
        le D;
        synchronized (this.c) {
            if (((AutofillValue) this.i) == null) {
                this.i.b(yjVar);
                D = D();
            } else {
                D = null;
            }
        }
        if (D != null) {
            ((AutofillValue) ((ne) D));
        }
    }

    public static final void M(ArrayList arrayList, dw0 dw0, yj yjVar) {
        arrayList.clear();
        synchronized (dw0.c) {
            Iterator it = dw0.k.iterator();
            if (it.hasNext()) {
                ((gj0) it.next()).getClass();
                throw null;
            }
        }
    }

    public final boolean F() {
        if (this.i.g == 0) {
            if (!(E() || G())) {
                if (!this.l.j()) {
                    return false;
                }
            }
        }
        return true;
    }

    public final void R(yj yjVar) {
        a91 a91 = this.p;
        if (a91 == null) {
            a91 = new ArrayList();
            this.p = a91;
        }
        if (!a91.contains(yjVar)) {
            a91.add(yjVar);
        }
        if (this.f.remove(yjVar)) {
            this.g = null;
        }
    }

    public final void S() {
        le D;
        synchronized (this.c) {
            if (this.t) {
                this.t = false;
                D = D();
            } else {
                D = null;
            }
        }
        if (D != null) {
            ((AutofillValue) ((ne) D));
        }
    }

    public final void v(yj yjVar) {
        synchronized (this.c) {
            if (this.f.remove(yjVar)) {
                this.g = null;
            }
            this.i.j(yjVar);
            this.j.remove(yjVar);
        }
    }

    public final boolean E() {
        return !this.t && (((ca) ((pa) this.a.g).c).get() & 134217727) > 0;
    }

    public final boolean G() {
        return !this.t && (((ca) ((pa) this.b.g).c).get() & 134217727) > 0;
    }

    public final void L(yj yjVar) {
        synchronized (this.c) {
            ArrayList arrayList = this.k;
            if (arrayList.size() <= 0) {
            } else {
                ((gj0) arrayList.get(0)).getClass();
                throw null;
            }
        }
    }

    public final void r(yj yjVar) {
        synchronized (this.c) {
            try {
                ak0 ak0 = this.q;
                if (ak0 == null) {
                    ik0 ik0 = o01.a;
                    ak0 = new ik0();
                    this.q = ak0;
                }
                ak0.a(yjVar);
            } finally {
            }
        }
    }

    public static void B(lk0 lk0) {
        try {
            if (lk0.w() instanceof i61) {
                throw new dl1("Unsupported concurrent change during composition. A state object was modified by composition as well as being modified outside composition.");
            }
        } finally {
            lk0.c();
        }
    }

    public final List I() {
        List list = this.g;
        if (list != null) {
            return list;
        }
        ArrayList arrayList = this.f;
        list = arrayList.isEmpty() ? ut.e : new ArrayList(arrayList);
        this.g = list;
        return list;
    }

    public final void q(xv0 xv0) {
        k9 k9Var = this.v;
        ak0 ak0 = (ik0) k9Var.p();
        if (ak0 == null) {
            ik0 ik0 = o01.a;
            ak0 = new ik0();
            k9Var.A(ak0);
        }
        ak0.a(xv0);
    }

    public final oe s(f8 f8Var) {
        k9 k9Var = this.b;
        pa paVar = (pa) k9Var.g;
        zl0 obj = new Object();
        obj.a = f8Var;
        return paVar.d(obj, (va) k9Var.h);
    }

    public final fj0 m(gj0 gj0) {
        fj0 fj0;
        synchronized (this.c) {
            fj0 = (fj0) this.n.k(gj0);
        }
        return fj0;
    }

    public final boolean d() {
        return ((Boolean) A.get()).booleanValue();
    }

    public static final boolean y(dw0 dw0) {
        boolean E;
        synchronized (dw0.c) {
            E = dw0.E();
        }
        return E;
    }

    public static final List z(dw0 dw0) {
        List I;
        synchronized (dw0.c) {
            I = dw0.I();
        }
        return I;
    }

    public final void K() {
        synchronized (this.c) {
            this.t = true;
        }
    }

    public final long g() {
        return 1000;
    }

    public final sl j() {
        return this.x;
    }

    public final boolean e() {
        return false;
    }

    public final boolean f() {
        return false;
    }

    public final rj h() {
        return null;
    }

    public final boolean k() {
        return false;
    }

    public final void o(Set set) {
    }

    /*  JADX ERROR: JadxRuntimeException in pass: SSATransform
        jadx.core.utils.exceptions.JadxRuntimeException: Unknown predecessor block by arg (r3_7 ?) in PHI: PHI: (r3_8 ?) = (r3_7 ?), (r3_4 ?) binds: {(r3_4 ?)=B:14:0x0024}
        	at jadx.core.dex.instructions.PhiInsn.replaceArg(Unknown Source:55)
        	at jadx.core.dex.visitors.ssa.SSATransform.inlinePhiInsn(Unknown Source:92)
        	at jadx.core.dex.visitors.ssa.SSATransform.replacePhiWithMove(Unknown Source:34)
        	at jadx.core.dex.visitors.ssa.SSATransform.fixPhiWithSameArgs(Unknown Source:78)
        	at jadx.core.dex.visitors.ssa.SSATransform.fixUselessPhi(Unknown Source:78)
        	at jadx.core.dex.visitors.ssa.SSATransform.process(Unknown Source:32)
        	at jadx.core.dex.visitors.ssa.SSATransform.visit(Unknown Source:7)
        	at jadx.core.dex.visitors.DepthTraversal.visit(Unknown Source:9)
        	at jadx.core.dex.visitors.DepthTraversal.visit(Unknown Source:41)
        	at jadx.core.ProcessClass.process(Unknown Source:54)
        	at jadx.core.ProcessClass.processDependencies(Unknown Source:22)
        	at jadx.core.ProcessClass.process(Unknown Source:68)
        	at jadx.api.JadxDecompiler.processClass(Unknown Source:4)
        	at jadx.api.JavaClass.decompile(Unknown Source:19)
        */
    public final defpackage.ik0 b(defpackage.yj r4, defpackage.l51 r5, defpackage.m00 r6) {
        /*
        r3 = this;
        r0 = r3.v;
        r1 = 0;
        r2 = r4.t;	 Catch:{ all -> 0x001e }
        r4.t = r5;	 Catch:{ all -> 0x001e }
        a(r4, r6);	 Catch:{ all -> 0x0020 }
        r3 = r0.p();	 Catch:{ all -> 0x0020 }
        r3 = (defpackage.ik0) r3;	 Catch:{ all -> 0x0020 }
        if (r3 == 0) goto L_0x0013;	 Catch:{ all -> 0x0020 }
    L_0x0012:
        goto L_0x0018;	 Catch:{ all -> 0x0020 }
    L_0x0013:
        r3 = defpackage.o01.a;	 Catch:{ all -> 0x0020 }
        r3.getClass();	 Catch:{ all -> 0x0020 }
    L_0x0018:
        r4.t = r2;
        r0.A(r1);
        return r3;
        r3 = move-exception;
        goto L_0x0024;
        r3 = move-exception;
        r4.t = r2;
        throw r3;
    L_0x0024:
        r0.A(r1);
        throw r3;
        */
        throw new UnsupportedOperationException("Method not decompiled: dw0.b(yj, l51, m00):ik0");
    }
}