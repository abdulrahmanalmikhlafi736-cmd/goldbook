package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dx */
public final class dx extends u91 implements n00 {
    public int i;
    public /* synthetic */ uw j;
    public /* synthetic */ Object k;
    public final /* synthetic */ aj l;

    /* JADX WARNING: Missing block: B:12:0x0039, code:
            if (r0.k(r6, r5) == r4) goto L_0x003b;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final Object p(Object obj) {
        int i = this.i;
        cm cmVar = cm.e;
        uw uwVar;
        if (i == 0) {
            nb0.t(obj);
            uwVar = this.j;
            obj = this.k;
            this.j = uwVar;
            this.i = 1;
            obj = this.l.f(obj, this);
            if (obj == cmVar) {
                return cmVar;
            }
        } else if (i == 1) {
            uwVar = this.j;
            nb0.t(obj);
        } else if (i == 2) {
            nb0.t(obj);
            return we1.a;
        } else {
            od.p("call to 'resume' before 'invoke' with coroutine");
            return null;
        }
        this.j = null;
        this.i = 2;
    }

    public final Object c(Object obj, Object obj2, Object obj3) {
        uw uwVar = (uw) obj;
        dx dxVar = new dx(this.l, (ml) obj3);
        dxVar.j = uwVar;
        dxVar.k = obj2;
        return dxVar.p(we1.a);
    }

    public dx(aj ajVar, ml mlVar) {
        this.l = ajVar;
        super(3, mlVar);
    }
}