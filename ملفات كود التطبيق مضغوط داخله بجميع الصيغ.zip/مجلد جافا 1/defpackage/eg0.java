package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: eg0 */
public final class eg0 implements n90 {
    public final dg0 e;

    public final long x(n90 n90, long j) {
        boolean z = n90 instanceof eg0;
        dg0 dg0 = this.e;
        gm0 gm0;
        if (z) {
            dg0 dg02 = ((eg0) n90).e;
            gm0 gm02 = dg02.s;
            gm02.H0();
            dg0 w0 = dg0.s.u0(gm02).w0();
            if (w0 != null) {
                long b = n60.b(n60.c(dg02.q0(w0, false), vd1.C(j)), dg0.q0(w0, false));
                return (((long) Float.floatToRawIntBits((float) ((int) (b >> 32)))) << 32) | (((long) Float.floatToRawIntBits((float) ((int) (b & 4294967295L)))) & 4294967295L);
            }
            w0 = nb0.m(dg02);
            j = n60.c(n60.c(dg02.q0(w0, false), w0.t), vd1.C(j));
            dg02 = nb0.m(dg0);
            j = n60.b(j, n60.c(dg0.q0(dg02, false), dg02.t));
            long floatToRawIntBits = (long) Float.floatToRawIntBits((float) ((int) (j >> 32)));
            j = (((long) Float.floatToRawIntBits((float) ((int) (j & 4294967295L)))) & 4294967295L) | (floatToRawIntBits << 32);
            gm0 = dg02.s.u;
            gm0.getClass();
            gm02 = w0.s.u;
            gm02.getClass();
            return gm0.x(gm02, j);
        }
        dg0 m = nb0.m(dg0);
        n90 n902 = m.s;
        j = x(m.v, j);
        long j2 = m.t;
        float f = (float) ((int) (j2 & 4294967295L));
        long floatToRawIntBits2 = 4294967295L & ((long) Float.floatToRawIntBits(f));
        j = gg1.e(j, floatToRawIntBits2 | (((long) Float.floatToRawIntBits((float) ((int) (j2 >> 32)))) << 32));
        if (!n902.y0().r) {
            a5.b("LayoutCoordinate operations are only valid when isAttached is true");
        }
        n902.H0();
        gm0 = n902.u;
        if (gm0 != null) {
            n902 = gm0;
        }
        return xm0.f(j, n902.x(n90, 0));
    }

    public final n90 j() {
        if (!I()) {
            a5.b("LayoutCoordinate operations are only valid when isAttached is true");
        }
        gm0 gm0 = this.e.s.s.J.d.u;
        if (gm0 != null) {
            dg0 w0 = gm0.w0();
            if (w0 != null) {
                return w0.v;
            }
        }
        return null;
    }

    public final long a() {
        dg0 dg0 = this.e;
        dg0 m = nb0.m(dg0);
        return gg1.e(x(m.v, 0), dg0.s.x(m.s, 0));
    }

    public final long A() {
        dg0 dg0 = this.e;
        return (((long) dg0.e) << 32) | (((long) dg0.f) & 4294967295L);
    }

    public final long B(long j) {
        return this.e.s.B(xm0.f(0, a()));
    }

    public final long d(long j) {
        return this.e.s.d(xm0.f(0, a()));
    }

    public final long h(long j) {
        return this.e.s.h(xm0.f(j, a()));
    }

    public final boolean I() {
        return this.e.s.y0().r;
    }

    public final gw0 z(n90 n90, boolean z) {
        return this.e.s.z(n90, z);
    }

    public eg0(dg0 dg0) {
        this.e = dg0;
    }

    public final long v(n90 n90, long j) {
        return x(n90, j);
    }
}