package defpackage;

import androidx.core.content.FileProvider;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: eq0 */
public final class eq0 {
    public String a;
    public ob1 b;
    public yy c;
    public int d;
    public boolean e;
    public int f;
    public int g;
    public long h = t50.a;
    public jp i;
    public m6 j;
    public boolean k;
    public long l = 0;
    public di0 m;
    public dq0 n;
    public o90 o;
    public long p = o.g(0, 0, 0, 0);
    public int q = -1;
    public int r = -1;
    public long s;

    /* JADX WARNING: Removed duplicated region for block: B:59:0x0121  */
    /* JADX WARNING: Removed duplicated region for block: B:58:0x0120  */
    /* JADX WARNING: Removed duplicated region for block: B:58:0x0120  */
    /* JADX WARNING: Removed duplicated region for block: B:59:0x0121  */
    /* JADX WARNING: Missing block: B:51:0x00eb, code:
            if (r12 == 5) goto L_0x00ed;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean b(long j, o90 o90) {
        int i;
        m6 m6Var;
        gw0 d;
        o90 o902 = o90;
        this.s = (this.s << 2) | 3;
        boolean z = true;
        long g = this.g > 1 ? eq0.g(this, j, o90) : j;
        m6 m6Var2 = this.j;
        boolean z2 = false;
        if (m6Var2 != null) {
            dq0 dq0 = this.n;
            if (dq0 != null) {
                if (!dq0.b()) {
                    if (o902 == this.o) {
                        if (n60.b(g, this.p) == null) {
                            if (sk.h(g) == sk.h(this.p)) {
                                if (sk.j(g) == sk.j(this.p)) {
                                    if (((float) sk.g(g)) >= m6Var2.b()) {
                                        if (m6Var2.d.d) {
                                        }
                                    }
                                }
                            }
                        }
                        if (n60.b(g, this.p) == null) {
                            m6 m6Var3 = this.j;
                            m6Var3.getClass();
                            gw0 d2 = ua0.d(g, (((long) sb0.e(Math.min(m6Var3.a.i.c(), m6Var3.c()))) << 32) | (((long) sb0.e(m6Var3.b())) & 4294967295L));
                            this.l = d2;
                            if (this.d != 3) {
                                if (((float) ((int) (d2 >> 32))) >= m6Var3.c()) {
                                    if (((float) ((int) (4294967295L & d2))) < m6Var3.b()) {
                                    }
                                }
                                this.k = z;
                                this.p = g;
                            }
                            z = false;
                            this.k = z;
                            this.p = g;
                        }
                        return false;
                    }
                }
            }
        }
        dq0 e = e(o902);
        long v = wl1.v(g, this.e, this.d, e.c());
        boolean z3 = this.e;
        int i2 = this.d;
        int i3 = this.f;
        if (!z3) {
            if (i2 != 2) {
                if (i2 == 4) {
                }
            }
            i = 1;
            m6Var = new m6((q6) e, i, i2, v);
            this.p = g;
            d = ua0.d(g, (((long) sb0.e(m6Var.b())) & 4294967295L) | (((long) sb0.e(m6Var.c())) << 32));
            this.l = d;
            if (this.d != 3) {
                if (((float) ((int) (d >> 32))) < m6Var.c() || ((float) ((int) (d & 4294967295L))) < m6Var.b()) {
                    z2 = true;
                }
            }
            this.k = z2;
            this.j = m6Var;
            return true;
        }
        if (i3 < 1) {
            i = 1;
            m6Var = new m6((q6) e, i, i2, v);
            this.p = g;
            d = ua0.d(g, (((long) sb0.e(m6Var.b())) & 4294967295L) | (((long) sb0.e(m6Var.c())) << 32));
            this.l = d;
            if (this.d != 3) {
            }
            this.k = z2;
            this.j = m6Var;
            return true;
        }
        i = i3;
        m6Var = new m6((q6) e, i, i2, v);
        this.p = g;
        d = ua0.d(g, (((long) sb0.e(m6Var.b())) & 4294967295L) | (((long) sb0.e(m6Var.c())) << 32));
        this.l = d;
        if (this.d != 3) {
        }
        this.k = z2;
        this.j = m6Var;
        return true;
    }

    public static long g(eq0 eq0, long j, o90 o90) {
        ob1 ob1 = eq0.b;
        di0 di0 = eq0.m;
        jp jpVar = eq0.i;
        jpVar.getClass();
        yy yyVar = eq0.c;
        if (di0 == null || o90 != di0.a || !wa0.v(ob1, o90).equals(di0.b) || jpVar.a() != di0.c.e || yyVar != di0.d) {
            di0 = di0.h;
            if (di0 == null || o90 != di0.a || !wa0.v(ob1, o90).equals(di0.b) || jpVar.a() != di0.c.e || yyVar != di0.d) {
                di0 = new di0(o90, wa0.v(ob1, o90), new aj1(jpVar.a(), jpVar.g()), yyVar);
                di0.h = di0;
            }
        }
        eq0.m = di0;
        int i = eq0.g;
        mp mpVar = di0.c;
        float f = di0.g;
        float f2 = di0.f;
        int i2 = 0;
        if (Float.isNaN(f) || Float.isNaN(f2)) {
            f2 = dd0.a(ei0.a, di0.e, tk.b(0, 0, 15), mpVar, di0.d, 1).b();
            f = dd0.a(ei0.b, di0.e, tk.b(0, 0, 15), mpVar, di0.d, 2).b() - f2;
            di0.g = f2;
            di0.f = f;
            float f3 = f2;
            f2 = f;
            f = f3;
        }
        if (i != 1) {
            i = Math.round((f2 * ((float) (i - 1))) + f);
            if (i >= 0) {
                i2 = i;
            }
            i = sk.g(j);
            if (i2 > i) {
                i2 = i;
            }
        } else {
            i2 = sk.i(j);
        }
        return tk.a(sk.j(j), sk.h(j), i2, sk.g(j));
    }

    /* JADX WARNING: Removed duplicated region for block: B:24:0x005a  */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x005a  */
    /* JADX WARNING: Missing block: B:17:0x003c, code:
            if (r9 == 5) goto L_0x003e;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final int a(int i, o90 o90) {
        int i2 = this.q;
        int i3 = this.r;
        if (i == i2 && i2 != -1) {
            return i3;
        }
        int i4;
        int e;
        long a = tk.a(0, i, 0, Integer.MAX_VALUE);
        if (this.g > 1) {
            a = eq0.g(this, a, o90);
        }
        dq0 e2 = e(o90);
        long v = wl1.v(a, this.e, this.d, e2.c());
        boolean z = this.e;
        int i5 = this.d;
        int i6 = this.f;
        if (!z) {
            if (i5 != 2) {
                if (i5 == 4) {
                }
            }
            i4 = 1;
            e = sb0.e(new m6((q6) e2, i4, i5, v).b());
            i2 = sk.i(a);
            if (e < i2) {
                e = i2;
            }
            this.q = i;
            this.r = e;
            return e;
        }
        if (i6 < 1) {
            i4 = 1;
            e = sb0.e(new m6((q6) e2, i4, i5, v).b());
            i2 = sk.i(a);
            if (e < i2) {
            }
            this.q = i;
            this.r = e;
            return e;
        }
        i4 = i6;
        e = sb0.e(new m6((q6) e2, i4, i5, v).b());
        i2 = sk.i(a);
        if (e < i2) {
        }
        this.q = i;
        this.r = e;
        return e;
    }

    public final void d(jp jpVar) {
        long a;
        jp jpVar2 = this.i;
        if (jpVar != null) {
            int i = t50.b;
            a = br.a(jpVar.a(), jpVar.g());
        } else {
            a = t50.a;
        }
        if (jpVar2 == null) {
            this.i = jpVar;
            this.h = a;
        } else if (jpVar == null || this.h != a) {
            this.i = jpVar;
            this.h = a;
            this.s = (this.s << 2) | 1;
            c();
        }
    }

    public final String toString() {
        StringBuilder dl1 = new dl1("ParagraphLayoutCache(paragraph=");
        dl1.append(this.j != null ? "<paragraph>" : "null");
        dl1.append(", lastDensity=");
        dl1.append(t50.b(this.h));
        dl1.append(", history=");
        dl1.append(this.s);
        dl1.append(", constraints=$)");
        return dl1.toString();
    }

    public final dq0 e(o90 o90) {
        dq0 dq0 = this.n;
        if (dq0 == null || o90 != this.o || dq0.b()) {
            this.o = o90;
            String str = this.a;
            ob1 v = wa0.v(this.b, o90);
            jp jpVar = this.i;
            jpVar.getClass();
            yy yyVar = this.c;
            ut utVar = ut.e;
            dq0 = new q6(str, v, utVar, utVar, yyVar, jpVar);
        }
        this.n = dq0;
        return dq0;
    }

    public eq0(String str, ob1 ob1, yy yyVar, int i, boolean z, int i2, int i3) {
        this.a = str;
        this.b = ob1;
        this.c = yyVar;
        this.d = i;
        this.e = z;
        this.f = i2;
        this.g = i3;
    }

    public final void c() {
        this.j = null;
        this.n = null;
        this.o = null;
        this.q = -1;
        this.r = -1;
        if ((1 & 1) == 0) {
            FileProvider.a("width and height must be >= 0");
        }
        this.p = o.g(0, 0, 0, 0);
        this.l = 0;
        this.k = false;
    }

    public final void f(String str, ob1 ob1, yy yyVar, int i, boolean z, int i2, int i3) {
        this.a = str;
        this.b = ob1;
        this.c = yyVar;
        this.d = i;
        this.e = z;
        this.f = i2;
        this.g = i3;
        this.s = (this.s << 2) | 2;
        c();
    }
}