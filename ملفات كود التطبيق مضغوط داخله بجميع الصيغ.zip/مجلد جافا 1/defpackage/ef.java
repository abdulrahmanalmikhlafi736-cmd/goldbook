package defpackage;

import java.io.Serializable;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ef */
public final class ef implements uw {
    public final /* synthetic */ int e;
    public final /* synthetic */ Serializable f;
    public final /* synthetic */ Object g;
    public final /* synthetic */ Object h;
    public final /* synthetic */ Object i;

    /* JADX WARNING: Removed duplicated region for block: B:59:0x00c5  */
    /* JADX WARNING: Removed duplicated region for block: B:56:0x00b4  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final Object k(Object obj, ml mlVar) {
        int i = this.e;
        Object obj2 = we1.a;
        int i2 = 1;
        Serializable serializable = this.f;
        int i3 = 0;
        switch (i) {
            case 0:
                df dfVar;
                int i4;
                Object obj3;
                if (mlVar instanceof df) {
                    dfVar = (df) mlVar;
                    i4 = dfVar.l;
                    if ((i4 & Integer.MIN_VALUE) != 0) {
                        dfVar.l = i4 - Integer.MIN_VALUE;
                        obj3 = dfVar.j;
                        i4 = dfVar.l;
                        if (i4 != 0) {
                            nb0.t(obj3);
                            a80 a80 = (a80) ((nw0) serializable).e;
                            if (a80 != null) {
                                a80.a(new f1("Child of the scoped flow was cancelled", 0));
                                dfVar.h = this;
                                dfVar.i = obj;
                                dfVar.l = 1;
                                cm v = a80.v(dfVar);
                                cm cmVar = cm.e;
                                if (v == cmVar) {
                                    obj2 = cmVar;
                                    return obj2;
                                }
                            }
                        } else if (i4 == 1) {
                            obj = dfVar.i;
                            this = dfVar.h;
                            nb0.t(obj3);
                        } else {
                            od.p("call to 'resume' before 'invoke' with coroutine");
                            obj2 = null;
                            return obj2;
                        }
                        ((nw0) this.f).e = wl1.B((bm) this.g, null, new cf((ff) this.h, (uw) this.i, obj, null), 1);
                        return obj2;
                    }
                }
                dfVar = new df(this, mlVar);
                obj3 = dfVar.j;
                i4 = dfVar.l;
                if (i4 != 0) {
                }
                ((nw0) this.f).e = wl1.B((bm) this.g, null, new cf((ff) this.h, (uw) this.i, obj, null), 1);
                return obj2;
            default:
                y60 y60 = (y60) obj;
                lw0 lw0 = (lw0) this.h;
                lw0 lw02 = (lw0) this.g;
                lw0 lw03 = (lw0) serializable;
                if (y60 instanceof ou0) {
                    lw03.e++;
                } else if (y60 instanceof pu0) {
                    lw03.e--;
                } else if (y60 instanceof nu0) {
                    lw03.e--;
                } else if (y60 instanceof m30) {
                    lw02.e++;
                } else if (y60 instanceof n30) {
                    lw02.e--;
                } else if (y60 instanceof yx) {
                    lw0.e++;
                } else if (y60 instanceof zx) {
                    lw0.e--;
                }
                boolean z = lw03.e > 0;
                boolean z2 = lw02.e > 0;
                boolean z3 = lw0.e > 0;
                bo boVar = (bo) this.i;
                if (boVar.t != z) {
                    boVar.t = z;
                    i3 = 1;
                }
                if (boVar.u != z2) {
                    boVar.u = z2;
                    i3 = 1;
                }
                if (boVar.v != z3) {
                    boVar.v = z3;
                } else {
                    i2 = i3;
                }
                if (i2 != 0) {
                    a5.x(boVar);
                }
                return obj2;
        }
    }

    public /* synthetic */ ef(Serializable serializable, Object obj, Object obj2, Object obj3, int i) {
        this.e = i;
        this.f = serializable;
        this.g = obj;
        this.h = obj2;
        this.i = obj3;
    }
}