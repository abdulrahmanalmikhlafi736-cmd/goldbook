package defpackage;

import java.util.Comparator;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: eb0 */
public final class eb0 implements Comparator {
    public final /* synthetic */ int a;
    public final /* synthetic */ i6 b;

    public final int compare(Object obj, Object obj2) {
        int i = this.a;
        i6 i6Var = this.b;
        switch (i) {
            case 0:
                return j70.v(Integer.valueOf(i6Var.b(((oc0) obj).f)), Integer.valueOf(i6Var.b(((oc0) obj2).f)));
            case 1:
                return j70.v(Integer.valueOf(i6Var.b(((oc0) obj).f)), Integer.valueOf(i6Var.b(((oc0) obj2).f)));
            case 2:
                return j70.v(Integer.valueOf(i6Var.b(((oc0) obj2).f)), Integer.valueOf(i6Var.b(((oc0) obj).f)));
            default:
                return j70.v(Integer.valueOf(i6Var.b(((oc0) obj2).f)), Integer.valueOf(i6Var.b(((oc0) obj).f)));
        }
    }

    public /* synthetic */ eb0(i6 i6Var, int i) {
        this.a = i;
        this.b = i6Var;
    }
}