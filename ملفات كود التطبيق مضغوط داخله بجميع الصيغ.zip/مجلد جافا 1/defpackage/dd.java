package defpackage;

import android.graphics.Paint;
import android.graphics.Shader;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dd */
public final class dd extends zi1 {
    public cz0 G;
    public long H = 9205357640488583168L;
    public final /* synthetic */ Shader I;

    public final void l(float f, long j, k6 k6Var) {
        Paint paint = k6Var.a;
        cz0 cz0 = this.G;
        Shader shader = null;
        if (cz0 == null || !d90.a(this.H, j)) {
            if (s51.c(j)) {
                this.G = null;
                this.H = 9205357640488583168L;
                cz0 = null;
            } else {
                cz0 = this.G;
                if (cz0 == null) {
                    cz0 = new ba0(6, false);
                    this.G = cz0;
                }
                cz0.f = this.I;
                this.G = cz0;
                this.H = j;
            }
        }
        j = wl1.d(paint.getColor());
        long j2 = zg.b;
        if (n60.c(j, j2) == null) {
            k6Var.c(j2);
        }
        if (!k70.p(k6Var.c, cz0 != null ? (Shader) cz0.f : null)) {
            if (cz0 != null) {
                shader = (Shader) cz0.f;
            }
            k6Var.c = shader;
            paint.setShader(shader);
        }
        if (((float) paint.getAlpha()) / 255.0f != f) {
            k6Var.a(f);
        }
    }

    public dd(Shader shader) {
        this.I = shader;
    }
}