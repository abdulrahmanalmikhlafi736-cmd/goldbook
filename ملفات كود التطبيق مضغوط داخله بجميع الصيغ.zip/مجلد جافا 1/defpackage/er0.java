package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: er0 */
public final class er0 extends jr0 {
    public final float c;
    public final float d;
    public final float e;
    public final float f;

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof er0)) {
            return false;
        }
        er0 er0 = (er0) obj;
        return Float.compare(this.c, er0.c) == 0 && Float.compare(this.d, er0.d) == 0 && Float.compare(this.e, er0.e) == 0 && Float.compare(this.f, er0.f) == 0;
    }

    public final String toString() {
        StringBuilder dl1 = new dl1("RelativeQuadTo(dx1=");
        dl1.append(this.c);
        dl1.append(", dy1=");
        dl1.append(this.d);
        dl1.append(", dx2=");
        dl1.append(this.e);
        dl1.append(", dy2=");
        return fu0.F(dl1, this.f, ')');
    }

    public final int hashCode() {
        return Float.floatToIntBits(this.f) + fu0.z(this.e, fu0.z(this.d, Float.floatToIntBits(this.c) * 31, 31), 31);
    }

    public er0(float f, float f2, float f3, float f4) {
        super(1);
        this.c = f;
        this.d = f2;
        this.e = f3;
        this.f = f4;
    }
}