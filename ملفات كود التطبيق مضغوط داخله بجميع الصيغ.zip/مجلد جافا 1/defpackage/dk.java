package defpackage;

import android.graphics.PathMeasure;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dk */
public final class dk extends h90 implements xz {
    public static final dk g = new xo0(0, 0);
    public static final dk h = new xo0(0, 1);
    public static final dk i = new xo0(0, 2);
    public static final dk j = new xo0(0, 3);
    public static final dk k = new xo0(0, 4);
    public static final dk l = new xo0(0, 5);
    public static final dk m = new xo0(0, 6);
    public static final dk n = new xo0(0, 7);
    public static final dk o = new xo0(0, 8);
    public static final dk p = new xo0(0, 9);
    public static final dk q = new xo0(0, 10);
    public static final dk r = new xo0(0, 11);
    public static final dk s = new xo0(0, 12);
    public final /* synthetic */ int f;

    public final Object a() {
        switch (this.f) {
            case 0:
                return Boolean.FALSE;
            case 1:
            case 2:
                return null;
            case 3:
                a5.b("LocalTextToolbar");
                throw null;
            case gu0.LONG_FIELD_NUMBER /*4*/:
                a5.b("LocalUriHandler");
                throw null;
            case gu0.STRING_FIELD_NUMBER /*5*/:
                a5.b("LocalViewConfiguration");
                throw null;
            case gu0.STRING_SET_FIELD_NUMBER /*6*/:
                a5.b("LocalWindowInfo");
                throw null;
            case gu0.DOUBLE_FIELD_NUMBER /*7*/:
                return Boolean.TRUE;
            case 8:
                return Boolean.FALSE;
            case 9:
                return new h90(3);
            case 10:
                return new s6(new PathMeasure());
            case 11:
                return null;
            default:
                return we1.a;
        }
    }

    public /* synthetic */ dk(int i, int i2) {
        this.f = i2;
        super(i);
    }
}