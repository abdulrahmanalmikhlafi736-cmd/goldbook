package defpackage;

import android.content.Context;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dv0 */
public final /* synthetic */ class dv0 implements Runnable {
    public final /* synthetic */ int e;
    public final /* synthetic */ Context f;

    public final void run() {
        int i = this.e;
        Context context = this.f;
        switch (i) {
            case 0:
                new ThreadPoolExecutor(0, 1, 0, TimeUnit.MILLISECONDS, new LinkedBlockingQueue()).execute(new dv0(context, 1));
                return;
            default:
                wl1.R(context, new Object(), wl1.l, false);
                return;
        }
    }

    public /* synthetic */ dv0(Context context, int i) {
        this.e = i;
        this.f = context;
    }
}