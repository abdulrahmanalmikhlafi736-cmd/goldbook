package defpackage;

import java.util.Iterator;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dz0 */
public final class dz0 extends gz0 implements Iterator {
    public ez0 e;
    public ez0 f;
    public final /* synthetic */ int g;

    public final void a(ez0 ez0) {
        ez0 ez02 = null;
        if (this.e == ez0 && ez0 == this.f) {
            this.f = null;
            this.e = null;
        }
        ez0 ez03 = this.e;
        if (ez03 == ez0) {
            switch (this.g) {
                case 0:
                    ez03 = ez03.h;
                    break;
                default:
                    ez03 = ez03.g;
                    break;
            }
            this.e = ez03;
        }
        ez03 = this.f;
        if (ez03 == ez0) {
            ez0 = this.e;
            if (ez03 != ez0) {
                if (ez0 != null) {
                    ez02 = b(ez03);
                }
            }
            this.f = ez02;
        }
    }

    public final Object next() {
        ez0 ez0 = this.f;
        ez0 ez02 = this.e;
        if (ez0 != ez02) {
            if (ez02 != null) {
                ez02 = b(ez0);
                this.f = ez02;
                return ez0;
            }
        }
        ez02 = null;
        this.f = ez02;
        return ez0;
    }

    public final ez0 b(ez0 ez0) {
        switch (this.g) {
            case 0:
                return ez0.g;
            default:
                return ez0.h;
        }
    }

    public dz0(ez0 ez0, ez0 ez02, int i) {
        this.g = i;
        this.e = ez02;
        this.f = ez0;
    }

    public final boolean hasNext() {
        return this.f != null;
    }
}