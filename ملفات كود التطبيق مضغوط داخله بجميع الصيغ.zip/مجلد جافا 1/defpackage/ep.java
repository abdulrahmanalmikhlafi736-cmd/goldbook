package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ep */
public final /* synthetic */ class ep implements xz {
    public final /* synthetic */ int e;
    public final /* synthetic */ fp f;

    public final Object a() {
        int i = this.e;
        Object obj = this.f;
        switch (i) {
            case 0:
                cy0 cy0 = (cy0) j70.z(obj, fy0.a);
                return j70.e;
            default:
                cy0 cy02 = (cy0) j70.z(obj, fy0.a);
                y6 y6Var = obj.y;
                if (cy02 == null) {
                    if (y6Var != null) {
                        obj.s0(y6Var);
                    }
                    obj.y = null;
                } else if (y6Var == null) {
                    pg0 pg0 = new pg0(13, obj);
                    ep epVar = new ep(obj, 0);
                    uj0 uj0 = obj.u;
                    boolean z = obj.v;
                    float f = obj.w;
                    td1 td1 = gy0.a;
                    y6Var = new y6(uj0, z, f, pg0, epVar);
                    obj.r0(y6Var);
                    obj.y = y6Var;
                }
                return we1.a;
        }
    }

    public /* synthetic */ ep(fp fpVar, int i) {
        this.e = i;
        this.f = fpVar;
    }
}