.class public final Lah1;
.super Lq7;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# instance fields
.field public final E:Landroid/view/View;

.field public final F:Lrl0;

.field public G:Llz0;

.field public H:Li00;

.field public I:Li00;

.field public J:Li00;


# direct methods
.method public constructor <init>(Landroid/content/Context;Li00;Lb10;Lmz0;ILlp0;)V
    .registers 14

    .line 1
    invoke-interface {p2, p1}, Li00;->i(Ljava/lang/Object;)Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    move-result-object p2

    .line 5
    move-object v5, p2

    .line 6
    check-cast v5, Landroid/view/View;

    .line 7
    .line 8
    new-instance v4, Lrl0;

    .line 9
    .line 10
    invoke-direct {v4}, Lrl0;-><init>()V

    .line 11
    .line 12
    .line 13
    move-object v0, p0

    .line 14
    move-object v1, p1

    .line 15
    move-object v2, p3

    .line 16
    move v3, p5

    .line 17
    move-object v6, p6

    .line 18
    invoke-direct/range {v0 .. v6}, Lq7;-><init>(Landroid/content/Context;Lb10;ILrl0;Landroid/view/View;Llp0;)V

    .line 19
    .line 20
    .line 21
    iput-object v5, v0, Lah1;->E:Landroid/view/View;

    .line 22
    .line 23
    iput-object v4, v0, Lah1;->F:Lrl0;

    .line 24
    .line 25
    const/4 p0, 0x0

    .line 26
    invoke-virtual {v0, p0}, Landroid/view/ViewGroup;->setClipChildren(Z)V

    .line 27
    .line 28
    .line 29
    invoke-static {v3}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 30
    .line 31
    .line 32
    move-result-object p0

    .line 33
    const/4 p1, 0x0

    .line 34
    if-eqz p4, :cond_28

    .line 35
    .line 36
    invoke-interface {p4, p0}, Lmz0;->f(Ljava/lang/String;)Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object p2

    .line 40
    goto :goto_29

    .line 41
    :cond_28
    move-object p2, p1

    .line 42
    :goto_29
    instance-of p3, p2, Landroid/util/SparseArray;

    .line 43
    .line 44
    if-eqz p3, :cond_30

    .line 45
    .line 46
    move-object p1, p2

    .line 47
    check-cast p1, Landroid/util/SparseArray;

    .line 48
    .line 49
    :cond_30
    if-eqz p1, :cond_35

    .line 50
    .line 51
    invoke-virtual {v5, p1}, Landroid/view/View;->restoreHierarchyState(Landroid/util/SparseArray;)V

    .line 52
    .line 53
    .line 54
    :cond_35
    if-eqz p4, :cond_44

    .line 55
    .line 56
    new-instance p1, Lp7;

    .line 57
    .line 58
    const/4 p2, 0x2

    .line 59
    invoke-direct {p1, v0, p2}, Lp7;-><init>(Lah1;I)V

    .line 60
    .line 61
    .line 62
    invoke-interface {p4, p0, p1}, Lmz0;->a(Ljava/lang/String;Lxz;)Llz0;

    .line 63
    .line 64
    .line 65
    move-result-object p0

    .line 66
    invoke-direct {v0, p0}, Lah1;->setSavableRegistryEntry(Llz0;)V

    .line 67
    .line 68
    .line 69
    :cond_44
    sget-object p0, Li4;->o:Li4;

    .line 70
    .line 71
    iput-object p0, v0, Lah1;->H:Li00;

    .line 72
    .line 73
    iput-object p0, v0, Lah1;->I:Li00;

    .line 74
    .line 75
    iput-object p0, v0, Lah1;->J:Li00;

    .line 76
    .line 77
    return-void
.end method

.method public static final h(Lah1;)V
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-direct {p0, v0}, Lah1;->setSavableRegistryEntry(Llz0;)V

    .line 3
    .line 4
    .line 5
    return-void
.end method

.method private final setSavableRegistryEntry(Llz0;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lah1;->G:Llz0;

    .line 2
    .line 3
    if-eqz v0, :cond_9

    .line 4
    .line 5
    check-cast v0, Lk9;

    .line 6
    .line 7
    invoke-virtual {v0}, Lk9;->F()V

    .line 8
    .line 9
    .line 10
    :cond_9
    iput-object p1, p0, Lah1;->G:Llz0;

    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final getDispatcher()Lrl0;
    .registers 1

    .line 1
    iget-object p0, p0, Lah1;->F:Lrl0;

    .line 2
    .line 3
    return-object p0
.end method

.method public final getReleaseBlock()Li00;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Li00;"
        }
    .end annotation

    .line 1
    iget-object p0, p0, Lah1;->J:Li00;

    .line 2
    .line 3
    return-object p0
.end method

.method public final getResetBlock()Li00;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Li00;"
        }
    .end annotation

    .line 1
    iget-object p0, p0, Lah1;->I:Li00;

    .line 2
    .line 3
    return-object p0
.end method

.method public bridge synthetic getSubCompositionView()Lo;
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return-object p0
.end method

.method public final getUpdateBlock()Li00;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Li00;"
        }
    .end annotation

    .line 1
    iget-object p0, p0, Lah1;->H:Li00;

    .line 2
    .line 3
    return-object p0
.end method

.method public getViewRoot()Landroid/view/View;
    .registers 1

    .line 1
    return-object p0
.end method

.method public final setReleaseBlock(Li00;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Li00;",
            ")V"
        }
    .end annotation

    .line 1
    iput-object p1, p0, Lah1;->J:Li00;

    .line 2
    .line 3
    new-instance p1, Lp7;

    .line 4
    .line 5
    const/4 v0, 0x3

    .line 6
    invoke-direct {p1, p0, v0}, Lp7;-><init>(Lah1;I)V

    .line 7
    .line 8
    .line 9
    invoke-virtual {p0, p1}, Lq7;->setRelease(Lxz;)V

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method public final setResetBlock(Li00;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Li00;",
            ")V"
        }
    .end annotation

    .line 1
    iput-object p1, p0, Lah1;->I:Li00;

    .line 2
    .line 3
    new-instance p1, Lp7;

    .line 4
    .line 5
    const/4 v0, 0x4

    .line 6
    invoke-direct {p1, p0, v0}, Lp7;-><init>(Lah1;I)V

    .line 7
    .line 8
    .line 9
    invoke-virtual {p0, p1}, Lq7;->setReset(Lxz;)V

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method public final setUpdateBlock(Li00;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Li00;",
            ")V"
        }
    .end annotation

    .line 1
    iput-object p1, p0, Lah1;->H:Li00;

    .line 2
    .line 3
    new-instance p1, Lp7;

    .line 4
    .line 5
    const/4 v0, 0x5

    .line 6
    invoke-direct {p1, p0, v0}, Lp7;-><init>(Lah1;I)V

    .line 7
    .line 8
    .line 9
    invoke-virtual {p0, p1}, Lq7;->setUpdate(Lxz;)V

    .line 10
    .line 11
    .line 12
    return-void
.end method
