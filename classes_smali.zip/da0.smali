.class public final Lda0;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Les;


# instance fields
.field public final e:Lte;

.field public f:Lds;


# direct methods
.method public constructor <init>()V
    .registers 2

    .line 1
    new-instance v0, Lte;

    .line 2
    .line 3
    invoke-direct {v0}, Lte;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, Lda0;->e:Lte;

    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final D(Lh6;JJJFLpb;I)V
    .registers 11

    .line 1
    iget-object p0, p0, Lda0;->e:Lte;

    .line 2
    .line 3
    invoke-virtual/range {p0 .. p10}, Lte;->D(Lh6;JJJFLpb;I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final F(F)I
    .registers 2

    .line 1
    iget-object p0, p0, Lda0;->e:Lte;

    .line 2
    .line 3
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    invoke-static {p1, p0}, Lfu0;->k(FLjp;)I

    .line 7
    .line 8
    .line 9
    move-result p0

    .line 10
    return p0
.end method

.method public final K(J)J
    .registers 3

    .line 1
    iget-object p0, p0, Lda0;->e:Lte;

    .line 2
    .line 3
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    invoke-static {p1, p2, p0}, Lfu0;->p(JLjp;)J

    .line 7
    .line 8
    .line 9
    move-result-wide p0

    .line 10
    return-wide p0
.end method

.method public final N(J)F
    .registers 3

    .line 1
    iget-object p0, p0, Lda0;->e:Lte;

    .line 2
    .line 3
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    invoke-static {p1, p2, p0}, Lfu0;->o(JLjp;)F

    .line 7
    .line 8
    .line 9
    move-result p0

    .line 10
    return p0
.end method

.method public final V(F)J
    .registers 2

    .line 1
    iget-object p0, p0, Lda0;->e:Lte;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Lte;->V(F)J

    .line 4
    .line 5
    .line 6
    move-result-wide p0

    .line 7
    return-wide p0
.end method

.method public final a()F
    .registers 1

    .line 1
    iget-object p0, p0, Lda0;->e:Lte;

    .line 2
    .line 3
    invoke-virtual {p0}, Lte;->a()F

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final b()J
    .registers 3

    .line 1
    iget-object p0, p0, Lda0;->e:Lte;

    .line 2
    .line 3
    iget-object p0, p0, Lte;->f:Lk9;

    .line 4
    .line 5
    invoke-virtual {p0}, Lk9;->t()J

    .line 6
    .line 7
    .line 8
    move-result-wide v0

    .line 9
    return-wide v0
.end method

.method public final b0(I)F
    .registers 2

    .line 1
    iget-object p0, p0, Lda0;->e:Lte;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Lte;->b0(I)F

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final c()V
    .registers 12

    .line 1
    iget-object v0, p0, Lda0;->e:Lte;

    .line 2
    .line 3
    iget-object v1, v0, Lte;->f:Lk9;

    .line 4
    .line 5
    invoke-virtual {v1}, Lk9;->q()Lre;

    .line 6
    .line 7
    .line 8
    move-result-object v3

    .line 9
    iget-object p0, p0, Lda0;->f:Lds;

    .line 10
    .line 11
    if-eqz p0, :cond_b8

    .line 12
    .line 13
    move-object v1, p0

    .line 14
    check-cast v1, Lli0;

    .line 15
    .line 16
    iget-object v2, v1, Lli0;->e:Lli0;

    .line 17
    .line 18
    iget-object v2, v2, Lli0;->j:Lli0;

    .line 19
    .line 20
    const/4 v9, 0x0

    .line 21
    const/4 v10, 0x4

    .line 22
    if-nez v2, :cond_18

    .line 23
    .line 24
    goto :goto_2f

    .line 25
    :cond_18
    iget v4, v2, Lli0;->h:I

    .line 26
    .line 27
    and-int/2addr v4, v10

    .line 28
    if-nez v4, :cond_1e

    .line 29
    .line 30
    goto :goto_2f

    .line 31
    :cond_1e
    :goto_1e
    if-eqz v2, :cond_2f

    .line 32
    .line 33
    iget v4, v2, Lli0;->g:I

    .line 34
    .line 35
    and-int/lit8 v5, v4, 0x2

    .line 36
    .line 37
    if-eqz v5, :cond_27

    .line 38
    .line 39
    goto :goto_2f

    .line 40
    :cond_27
    and-int/lit8 v4, v4, 0x4

    .line 41
    .line 42
    if-eqz v4, :cond_2c

    .line 43
    .line 44
    goto :goto_30

    .line 45
    :cond_2c
    iget-object v2, v2, Lli0;->j:Lli0;

    .line 46
    .line 47
    goto :goto_1e

    .line 48
    :cond_2f
    :goto_2f
    move-object v2, v9

    .line 49
    :goto_30
    if-eqz v2, :cond_9d

    .line 50
    .line 51
    move-object p0, v9

    .line 52
    :goto_33
    if-eqz v2, :cond_9c

    .line 53
    .line 54
    instance-of v1, v2, Lds;

    .line 55
    .line 56
    if-eqz v1, :cond_60

    .line 57
    .line 58
    move-object v7, v2

    .line 59
    check-cast v7, Lds;

    .line 60
    .line 61
    iget-object v1, v0, Lte;->f:Lk9;

    .line 62
    .line 63
    iget-object v1, v1, Lk9;->g:Ljava/lang/Object;

    .line 64
    .line 65
    move-object v8, v1

    .line 66
    check-cast v8, Li20;

    .line 67
    .line 68
    invoke-static {v7, v10}, Lk70;->M(Lcp;I)Lgm0;

    .line 69
    .line 70
    .line 71
    move-result-object v6

    .line 72
    iget-wide v1, v6, Lks0;->g:J

    .line 73
    .line 74
    invoke-static {v1, v2}, Lwl1;->M(J)J

    .line 75
    .line 76
    .line 77
    move-result-wide v4

    .line 78
    iget-object v1, v6, Lgm0;->s:Lba0;

    .line 79
    .line 80
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 81
    .line 82
    .line 83
    invoke-static {v1}, Lea0;->a(Lba0;)Llp0;

    .line 84
    .line 85
    .line 86
    move-result-object v1

    .line 87
    check-cast v1, Ln4;

    .line 88
    .line 89
    invoke-virtual {v1}, Ln4;->getSharedDrawScope()Lda0;

    .line 90
    .line 91
    .line 92
    move-result-object v2

    .line 93
    invoke-virtual/range {v2 .. v8}, Lda0;->d(Lre;JLgm0;Lds;Li20;)V

    .line 94
    .line 95
    .line 96
    goto :goto_97

    .line 97
    :cond_60
    iget v1, v2, Lli0;->g:I

    .line 98
    .line 99
    and-int/2addr v1, v10

    .line 100
    if-eqz v1, :cond_97

    .line 101
    .line 102
    instance-of v1, v2, Ldp;

    .line 103
    .line 104
    if-eqz v1, :cond_97

    .line 105
    .line 106
    move-object v1, v2

    .line 107
    check-cast v1, Ldp;

    .line 108
    .line 109
    iget-object v1, v1, Ldp;->t:Lli0;

    .line 110
    .line 111
    const/4 v4, 0x0

    .line 112
    :goto_6f
    const/4 v5, 0x1

    .line 113
    if-eqz v1, :cond_94

    .line 114
    .line 115
    iget v6, v1, Lli0;->g:I

    .line 116
    .line 117
    and-int/2addr v6, v10

    .line 118
    if-eqz v6, :cond_91

    .line 119
    .line 120
    add-int/lit8 v4, v4, 0x1

    .line 121
    .line 122
    if-ne v4, v5, :cond_7d

    .line 123
    .line 124
    move-object v2, v1

    .line 125
    goto :goto_91

    .line 126
    :cond_7d
    if-nez p0, :cond_88

    .line 127
    .line 128
    new-instance p0, Lqk0;

    .line 129
    .line 130
    const/16 v5, 0x10

    .line 131
    .line 132
    new-array v5, v5, [Lli0;

    .line 133
    .line 134
    invoke-direct {p0, v5}, Lqk0;-><init>([Ljava/lang/Object;)V

    .line 135
    .line 136
    .line 137
    :cond_88
    if-eqz v2, :cond_8e

    .line 138
    .line 139
    invoke-virtual {p0, v2}, Lqk0;->b(Ljava/lang/Object;)V

    .line 140
    .line 141
    .line 142
    move-object v2, v9

    .line 143
    :cond_8e
    invoke-virtual {p0, v1}, Lqk0;->b(Ljava/lang/Object;)V

    .line 144
    .line 145
    .line 146
    :cond_91
    :goto_91
    iget-object v1, v1, Lli0;->j:Lli0;

    .line 147
    .line 148
    goto :goto_6f

    .line 149
    :cond_94
    if-ne v4, v5, :cond_97

    .line 150
    .line 151
    goto :goto_33

    .line 152
    :cond_97
    :goto_97
    invoke-static {p0}, Lk70;->m(Lqk0;)Lli0;

    .line 153
    .line 154
    .line 155
    move-result-object v2

    .line 156
    goto :goto_33

    .line 157
    :cond_9c
    return-void

    .line 158
    :cond_9d
    invoke-static {p0, v10}, Lk70;->M(Lcp;I)Lgm0;

    .line 159
    .line 160
    .line 161
    move-result-object p0

    .line 162
    invoke-virtual {p0}, Lgm0;->y0()Lli0;

    .line 163
    .line 164
    .line 165
    move-result-object v2

    .line 166
    iget-object v1, v1, Lli0;->e:Lli0;

    .line 167
    .line 168
    if-ne v2, v1, :cond_ae

    .line 169
    .line 170
    iget-object p0, p0, Lgm0;->t:Lgm0;

    .line 171
    .line 172
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 173
    .line 174
    .line 175
    :cond_ae
    iget-object v0, v0, Lte;->f:Lk9;

    .line 176
    .line 177
    iget-object v0, v0, Lk9;->g:Ljava/lang/Object;

    .line 178
    .line 179
    check-cast v0, Li20;

    .line 180
    .line 181
    invoke-virtual {p0, v3, v0}, Lgm0;->N0(Lre;Li20;)V

    .line 182
    .line 183
    .line 184
    return-void

    .line 185
    :cond_b8
    const-string p0, "Attempting to drawContent for a `null` node. This usually means that a call to ContentDrawScope#drawContent() has been captured inside a lambda, and is being invoked outside of the draw pass. Capturing the scope this way is unsupported - if you are trying to record drawContent with graphicsLayer.record(), make sure you are using the GraphicsLayer#record function within DrawScope, instead of the member function on GraphicsLayer."

    .line 186
    .line 187
    invoke-static {p0}, Lfu0;->C(Ljava/lang/String;)Lyh;

    .line 188
    .line 189
    .line 190
    move-result-object p0

    .line 191
    throw p0
.end method

.method public final c0(F)F
    .registers 2

    .line 1
    iget-object p0, p0, Lda0;->e:Lte;

    .line 2
    .line 3
    invoke-virtual {p0}, Lte;->a()F

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    div-float/2addr p1, p0

    .line 8
    return p1
.end method

.method public final d(Lre;JLgm0;Lds;Li20;)V
    .registers 16

    .line 1
    iget-object v0, p0, Lda0;->f:Lds;

    .line 2
    .line 3
    iput-object p5, p0, Lda0;->f:Lds;

    .line 4
    .line 5
    iget-object v1, p4, Lgm0;->s:Lba0;

    .line 6
    .line 7
    iget-object v1, v1, Lba0;->D:Lo90;

    .line 8
    .line 9
    iget-object v2, p0, Lda0;->e:Lte;

    .line 10
    .line 11
    iget-object v3, v2, Lte;->f:Lk9;

    .line 12
    .line 13
    iget-object v4, v3, Lk9;->h:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast v4, Lte;

    .line 16
    .line 17
    iget-object v4, v4, Lte;->e:Lse;

    .line 18
    .line 19
    iget-object v5, v4, Lse;->a:Ljp;

    .line 20
    .line 21
    iget-object v4, v4, Lse;->b:Lo90;

    .line 22
    .line 23
    invoke-virtual {v3}, Lk9;->q()Lre;

    .line 24
    .line 25
    .line 26
    move-result-object v3

    .line 27
    iget-object v2, v2, Lte;->f:Lk9;

    .line 28
    .line 29
    invoke-virtual {v2}, Lk9;->t()J

    .line 30
    .line 31
    .line 32
    move-result-wide v6

    .line 33
    iget-object v8, v2, Lk9;->g:Ljava/lang/Object;

    .line 34
    .line 35
    check-cast v8, Li20;

    .line 36
    .line 37
    invoke-virtual {v2, p4}, Lk9;->C(Ljp;)V

    .line 38
    .line 39
    .line 40
    invoke-virtual {v2, v1}, Lk9;->D(Lo90;)V

    .line 41
    .line 42
    .line 43
    invoke-virtual {v2, p1}, Lk9;->B(Lre;)V

    .line 44
    .line 45
    .line 46
    invoke-virtual {v2, p2, p3}, Lk9;->E(J)V

    .line 47
    .line 48
    .line 49
    iput-object p6, v2, Lk9;->g:Ljava/lang/Object;

    .line 50
    .line 51
    invoke-interface {p1}, Lre;->i()V

    .line 52
    .line 53
    .line 54
    :try_start_35
    invoke-interface {p5, p0}, Lds;->C(Lda0;)V
    :try_end_38
    .catchall {:try_start_35 .. :try_end_38} :catchall_4c

    .line 55
    .line 56
    .line 57
    invoke-interface {p1}, Lre;->g()V

    .line 58
    .line 59
    .line 60
    invoke-virtual {v2, v5}, Lk9;->C(Ljp;)V

    .line 61
    .line 62
    .line 63
    invoke-virtual {v2, v4}, Lk9;->D(Lo90;)V

    .line 64
    .line 65
    .line 66
    invoke-virtual {v2, v3}, Lk9;->B(Lre;)V

    .line 67
    .line 68
    .line 69
    invoke-virtual {v2, v6, v7}, Lk9;->E(J)V

    .line 70
    .line 71
    .line 72
    iput-object v8, v2, Lk9;->g:Ljava/lang/Object;

    .line 73
    .line 74
    iput-object v0, p0, Lda0;->f:Lds;

    .line 75
    .line 76
    return-void

    .line 77
    :catchall_4c
    move-exception p0

    .line 78
    invoke-interface {p1}, Lre;->g()V

    .line 79
    .line 80
    .line 81
    invoke-virtual {v2, v5}, Lk9;->C(Ljp;)V

    .line 82
    .line 83
    .line 84
    invoke-virtual {v2, v4}, Lk9;->D(Lo90;)V

    .line 85
    .line 86
    .line 87
    invoke-virtual {v2, v3}, Lk9;->B(Lre;)V

    .line 88
    .line 89
    .line 90
    invoke-virtual {v2, v6, v7}, Lk9;->E(J)V

    .line 91
    .line 92
    .line 93
    iput-object v8, v2, Lk9;->g:Ljava/lang/Object;

    .line 94
    .line 95
    throw p0
.end method

.method public final e(Lr6;JLac;)V
    .registers 7

    .line 1
    iget-object p0, p0, Lda0;->e:Lte;

    .line 2
    .line 3
    iget-object v0, p0, Lte;->e:Lse;

    .line 4
    .line 5
    iget-object v0, v0, Lse;->c:Lre;

    .line 6
    .line 7
    const/4 v1, 0x3

    .line 8
    invoke-static {p0, p2, p3, p4, v1}, Lte;->c(Lte;JLac;I)Lk6;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    invoke-interface {v0, p1, p0}, Lre;->f(Lr6;Lk6;)V

    .line 13
    .line 14
    .line 15
    return-void
.end method

.method public final g()F
    .registers 1

    .line 1
    iget-object p0, p0, Lda0;->e:Lte;

    .line 2
    .line 3
    invoke-virtual {p0}, Lte;->g()F

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final getLayoutDirection()Lo90;
    .registers 1

    .line 1
    iget-object p0, p0, Lda0;->e:Lte;

    .line 2
    .line 3
    iget-object p0, p0, Lte;->e:Lse;

    .line 4
    .line 5
    iget-object p0, p0, Lse;->b:Lo90;

    .line 6
    .line 7
    return-object p0
.end method

.method public final k(JJJLac;I)V
    .registers 9

    .line 1
    iget-object p0, p0, Lda0;->e:Lte;

    .line 2
    .line 3
    invoke-virtual/range {p0 .. p8}, Lte;->k(JJJLac;I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final p(Lr6;Lzi1;FLac;I)V
    .registers 6

    .line 1
    iget-object p0, p0, Lda0;->e:Lte;

    .line 2
    .line 3
    invoke-virtual/range {p0 .. p5}, Lte;->p(Lr6;Lzi1;FLac;I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final q(F)F
    .registers 2

    .line 1
    iget-object p0, p0, Lda0;->e:Lte;

    .line 2
    .line 3
    invoke-virtual {p0}, Lte;->a()F

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    mul-float/2addr p0, p1

    .line 8
    return p0
.end method

.method public final u()Lk9;
    .registers 1

    .line 1
    iget-object p0, p0, Lda0;->e:Lte;

    .line 2
    .line 3
    iget-object p0, p0, Lte;->f:Lk9;

    .line 4
    .line 5
    return-object p0
.end method

.method public final y(J)F
    .registers 3

    .line 1
    iget-object p0, p0, Lda0;->e:Lte;

    .line 2
    .line 3
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    invoke-static {p1, p2, p0}, Lfu0;->m(JLjp;)F

    .line 7
    .line 8
    .line 9
    move-result p0

    .line 10
    return p0
.end method
