.class public interface abstract Lan0;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# virtual methods
.method public abstract b(Landroid/view/View;Lhk1;)Lhk1;
.end method
