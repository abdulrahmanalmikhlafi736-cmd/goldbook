.class public final Let0;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# instance fields
.field public final a:J

.field public final b:J

.field public final c:Z


# direct methods
.method public constructor <init>(JJZ)V
    .registers 6

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-wide p1, p0, Let0;->a:J

    .line 5
    .line 6
    iput-wide p3, p0, Let0;->b:J

    .line 7
    .line 8
    iput-boolean p5, p0, Let0;->c:Z

    .line 9
    .line 10
    return-void
.end method
