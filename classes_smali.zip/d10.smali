.class public final Ld10;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# instance fields
.field public A:I

.field public B:I

.field public C:Z

.field public final D:Lc10;

.field public final E:Ljava/util/ArrayList;

.field public F:Z

.field public G:Lw51;

.field public H:Lx51;

.field public I:La61;

.field public J:Z

.field public K:Lqr0;

.field public L:Lve;

.field public final M:Lpj;

.field public N:Ly00;

.field public O:Lbw;

.field public P:Ll51;

.field public final Q:Lwj;

.field public final R:Lsl;

.field public S:Z

.field public T:J

.field public U:Le10;

.field public final a:Lk9;

.field public final b:Lsj;

.field public final c:Lx51;

.field public final d:Lkk0;

.field public final e:Lve;

.field public final f:Lve;

.field public final g:Lpg0;

.field public final h:Lyj;

.field public final i:Ljava/util/ArrayList;

.field public j:Lg10;

.field public k:I

.field public l:I

.field public m:I

.field public final n:Lw60;

.field public o:[I

.field public p:Lqj0;

.field public q:Z

.field public r:Z

.field public final s:Ljava/util/ArrayList;

.field public final t:Lw60;

.field public u:Lqr0;

.field public v:Lsj0;

.field public w:Z

.field public final x:Lw60;

.field public y:Z

.field public z:I


# direct methods
.method public constructor <init>(Lk9;Lsj;Lx51;Lkk0;Lve;Lve;Lpg0;Lyj;)V
    .registers 9

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Ld10;->a:Lk9;

    .line 5
    .line 6
    iput-object p2, p0, Ld10;->b:Lsj;

    .line 7
    .line 8
    iput-object p3, p0, Ld10;->c:Lx51;

    .line 9
    .line 10
    iput-object p4, p0, Ld10;->d:Lkk0;

    .line 11
    .line 12
    iput-object p5, p0, Ld10;->e:Lve;

    .line 13
    .line 14
    iput-object p6, p0, Ld10;->f:Lve;

    .line 15
    .line 16
    iput-object p7, p0, Ld10;->g:Lpg0;

    .line 17
    .line 18
    iput-object p8, p0, Ld10;->h:Lyj;

    .line 19
    .line 20
    new-instance p1, Ljava/util/ArrayList;

    .line 21
    .line 22
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 23
    .line 24
    .line 25
    iput-object p1, p0, Ld10;->i:Ljava/util/ArrayList;

    .line 26
    .line 27
    new-instance p1, Lw60;

    .line 28
    .line 29
    invoke-direct {p1}, Lw60;-><init>()V

    .line 30
    .line 31
    .line 32
    iput-object p1, p0, Ld10;->n:Lw60;

    .line 33
    .line 34
    new-instance p1, Ljava/util/ArrayList;

    .line 35
    .line 36
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 37
    .line 38
    .line 39
    iput-object p1, p0, Ld10;->s:Ljava/util/ArrayList;

    .line 40
    .line 41
    new-instance p1, Lw60;

    .line 42
    .line 43
    invoke-direct {p1}, Lw60;-><init>()V

    .line 44
    .line 45
    .line 46
    iput-object p1, p0, Ld10;->t:Lw60;

    .line 47
    .line 48
    sget-object p1, Lqr0;->h:Lqr0;

    .line 49
    .line 50
    iput-object p1, p0, Ld10;->u:Lqr0;

    .line 51
    .line 52
    new-instance p1, Lw60;

    .line 53
    .line 54
    invoke-direct {p1}, Lw60;-><init>()V

    .line 55
    .line 56
    .line 57
    iput-object p1, p0, Ld10;->x:Lw60;

    .line 58
    .line 59
    const/4 p1, -0x1

    .line 60
    iput p1, p0, Ld10;->z:I

    .line 61
    .line 62
    invoke-virtual {p2}, Lsj;->f()Z

    .line 63
    .line 64
    .line 65
    move-result p1

    .line 66
    const/4 p4, 0x0

    .line 67
    const/4 p6, 0x1

    .line 68
    if-nez p1, :cond_4e

    .line 69
    .line 70
    invoke-virtual {p2}, Lsj;->d()Z

    .line 71
    .line 72
    .line 73
    move-result p1

    .line 74
    if-eqz p1, :cond_4c

    .line 75
    .line 76
    goto :goto_4e

    .line 77
    :cond_4c
    move p1, p4

    .line 78
    goto :goto_4f

    .line 79
    :cond_4e
    :goto_4e
    move p1, p6

    .line 80
    :goto_4f
    iput-boolean p1, p0, Ld10;->C:Z

    .line 81
    .line 82
    new-instance p1, Lc10;

    .line 83
    .line 84
    invoke-direct {p1, p4, p0}, Lc10;-><init>(ILjava/lang/Object;)V

    .line 85
    .line 86
    .line 87
    iput-object p1, p0, Ld10;->D:Lc10;

    .line 88
    .line 89
    new-instance p1, Ljava/util/ArrayList;

    .line 90
    .line 91
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 92
    .line 93
    .line 94
    iput-object p1, p0, Ld10;->E:Ljava/util/ArrayList;

    .line 95
    .line 96
    invoke-virtual {p3}, Lx51;->c()Lw51;

    .line 97
    .line 98
    .line 99
    move-result-object p1

    .line 100
    invoke-virtual {p1}, Lw51;->c()V

    .line 101
    .line 102
    .line 103
    iput-object p1, p0, Ld10;->G:Lw51;

    .line 104
    .line 105
    new-instance p1, Lx51;

    .line 106
    .line 107
    invoke-direct {p1}, Lx51;-><init>()V

    .line 108
    .line 109
    .line 110
    invoke-virtual {p2}, Lsj;->f()Z

    .line 111
    .line 112
    .line 113
    move-result p3

    .line 114
    if-eqz p3, :cond_76

    .line 115
    .line 116
    invoke-virtual {p1}, Lx51;->b()V

    .line 117
    .line 118
    .line 119
    :cond_76
    invoke-virtual {p2}, Lsj;->d()Z

    .line 120
    .line 121
    .line 122
    move-result p3

    .line 123
    if-eqz p3, :cond_83

    .line 124
    .line 125
    new-instance p3, Lsj0;

    .line 126
    .line 127
    invoke-direct {p3}, Lsj0;-><init>()V

    .line 128
    .line 129
    .line 130
    iput-object p3, p1, Lx51;->o:Lsj0;

    .line 131
    .line 132
    :cond_83
    iput-object p1, p0, Ld10;->H:Lx51;

    .line 133
    .line 134
    invoke-virtual {p1}, Lx51;->e()La61;

    .line 135
    .line 136
    .line 137
    move-result-object p1

    .line 138
    invoke-virtual {p1, p6}, La61;->e(Z)V

    .line 139
    .line 140
    .line 141
    iput-object p1, p0, Ld10;->I:La61;

    .line 142
    .line 143
    new-instance p1, Lpj;

    .line 144
    .line 145
    invoke-direct {p1, p0, p5}, Lpj;-><init>(Ld10;Lve;)V

    .line 146
    .line 147
    .line 148
    iput-object p1, p0, Ld10;->M:Lpj;

    .line 149
    .line 150
    iget-object p1, p0, Ld10;->H:Lx51;

    .line 151
    .line 152
    invoke-virtual {p1}, Lx51;->c()Lw51;

    .line 153
    .line 154
    .line 155
    move-result-object p1

    .line 156
    :try_start_9b
    invoke-virtual {p1, p4}, Lw51;->a(I)Ly00;

    .line 157
    .line 158
    .line 159
    move-result-object p3
    :try_end_9f
    .catchall {:try_start_9b .. :try_end_9f} :catchall_c6

    .line 160
    invoke-virtual {p1}, Lw51;->c()V

    .line 161
    .line 162
    .line 163
    iput-object p3, p0, Ld10;->N:Ly00;

    .line 164
    .line 165
    new-instance p1, Lbw;

    .line 166
    .line 167
    invoke-direct {p1}, Lbw;-><init>()V

    .line 168
    .line 169
    .line 170
    iput-object p1, p0, Ld10;->O:Lbw;

    .line 171
    .line 172
    new-instance p1, Lwj;

    .line 173
    .line 174
    invoke-direct {p1, p0}, Lwj;-><init>(Ld10;)V

    .line 175
    .line 176
    .line 177
    iput-object p1, p0, Ld10;->Q:Lwj;

    .line 178
    .line 179
    invoke-virtual {p2}, Lsj;->j()Lsl;

    .line 180
    .line 181
    .line 182
    move-result-object p1

    .line 183
    invoke-virtual {p0}, Ld10;->z()Lwj;

    .line 184
    .line 185
    .line 186
    move-result-object p2

    .line 187
    if-eqz p2, :cond_bd

    .line 188
    .line 189
    goto :goto_bf

    .line 190
    :cond_bd
    sget-object p2, Lst;->e:Lst;

    .line 191
    .line 192
    :goto_bf
    invoke-interface {p1, p2}, Lsl;->i(Lsl;)Lsl;

    .line 193
    .line 194
    .line 195
    move-result-object p1

    .line 196
    iput-object p1, p0, Ld10;->R:Lsl;

    .line 197
    .line 198
    return-void

    .line 199
    :catchall_c6
    move-exception p0

    .line 200
    invoke-virtual {p1}, Lw51;->c()V

    .line 201
    .line 202
    .line 203
    throw p0
.end method

.method public static final N(Ld10;IZI)I
    .registers 23

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move/from16 v1, p1

    .line 4
    .line 5
    iget-object v2, v0, Ld10;->G:Lw51;

    .line 6
    .line 7
    invoke-virtual {v2, v1}, Lw51;->j(I)Z

    .line 8
    .line 9
    .line 10
    move-result v3

    .line 11
    const/4 v4, 0x0

    .line 12
    if-eqz v3, :cond_154

    .line 13
    .line 14
    invoke-virtual {v2, v1}, Lw51;->i(I)I

    .line 15
    .line 16
    .line 17
    move-result v3

    .line 18
    iget-object v6, v2, Lw51;->b:[I

    .line 19
    .line 20
    invoke-virtual {v2, v6, v1}, Lw51;->p([II)Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v6

    .line 24
    const/16 v7, 0xce

    .line 25
    .line 26
    if-ne v3, v7, :cond_145

    .line 27
    .line 28
    sget-object v3, Lqj;->e:Lqn0;

    .line 29
    .line 30
    invoke-static {v6, v3}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 31
    .line 32
    .line 33
    move-result v3

    .line 34
    if-eqz v3, :cond_145

    .line 35
    .line 36
    invoke-virtual {v2, v1, v4}, Lw51;->h(II)Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object v3

    .line 40
    instance-of v6, v3, Lxw0;

    .line 41
    .line 42
    const/4 v7, 0x0

    .line 43
    if-eqz v6, :cond_2f

    .line 44
    .line 45
    check-cast v3, Lxw0;

    .line 46
    .line 47
    goto :goto_30

    .line 48
    :cond_2f
    move-object v3, v7

    .line 49
    :goto_30
    if-eqz v3, :cond_35

    .line 50
    .line 51
    iget-object v3, v3, Lxw0;->a:Lww0;

    .line 52
    .line 53
    goto :goto_36

    .line 54
    :cond_35
    move-object v3, v7

    .line 55
    :goto_36
    instance-of v6, v3, La10;

    .line 56
    .line 57
    if-eqz v6, :cond_3d

    .line 58
    .line 59
    move-object v7, v3

    .line 60
    check-cast v7, La10;

    .line 61
    .line 62
    :cond_3d
    if-eqz v7, :cond_140

    .line 63
    .line 64
    iget-object v3, v7, La10;->e:Lb10;

    .line 65
    .line 66
    iget-object v3, v3, Lb10;->e:Lik0;

    .line 67
    .line 68
    iget-object v6, v3, Lik0;->b:[Ljava/lang/Object;

    .line 69
    .line 70
    iget-object v3, v3, Lik0;->a:[J

    .line 71
    .line 72
    array-length v7, v3

    .line 73
    add-int/lit8 v7, v7, -0x2

    .line 74
    .line 75
    if-ltz v7, :cond_140

    .line 76
    .line 77
    move v8, v4

    .line 78
    :goto_4d
    aget-wide v9, v3, v8

    .line 79
    .line 80
    not-long v11, v9

    .line 81
    const/4 v13, 0x7

    .line 82
    shl-long/2addr v11, v13

    .line 83
    and-long/2addr v11, v9

    .line 84
    const-wide v13, -0x7f7f7f7f7f7f7f80L  # -2.937446524422997E-306

    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    and-long/2addr v11, v13

    .line 90
    cmp-long v11, v11, v13

    .line 91
    .line 92
    if-eqz v11, :cond_132

    .line 93
    .line 94
    sub-int v11, v8, v7

    .line 95
    .line 96
    not-int v11, v11

    .line 97
    ushr-int/lit8 v11, v11, 0x1f

    .line 98
    .line 99
    const/16 v12, 0x8

    .line 100
    .line 101
    rsub-int/lit8 v11, v11, 0x8

    .line 102
    .line 103
    move v13, v4

    .line 104
    :goto_67
    if-ge v13, v11, :cond_129

    .line 105
    .line 106
    const-wide/16 v14, 0xff

    .line 107
    .line 108
    and-long/2addr v14, v9

    .line 109
    const-wide/16 v16, 0x80

    .line 110
    .line 111
    cmp-long v14, v14, v16

    .line 112
    .line 113
    if-gez v14, :cond_117

    .line 114
    .line 115
    shl-int/lit8 v14, v8, 0x3

    .line 116
    .line 117
    add-int/2addr v14, v13

    .line 118
    aget-object v14, v6, v14

    .line 119
    .line 120
    check-cast v14, Ld10;

    .line 121
    .line 122
    iget-object v15, v14, Ld10;->c:Lx51;

    .line 123
    .line 124
    const/16 v16, 0x1

    .line 125
    .line 126
    iget v5, v15, Lx51;->f:I

    .line 127
    .line 128
    if-lez v5, :cond_10a

    .line 129
    .line 130
    iget-object v5, v15, Lx51;->e:[I

    .line 131
    .line 132
    aget v5, v5, v16

    .line 133
    .line 134
    const/high16 v15, 0x4000000

    .line 135
    .line 136
    and-int/2addr v5, v15

    .line 137
    if-eqz v5, :cond_10a

    .line 138
    .line 139
    iget-object v5, v14, Ld10;->h:Lyj;

    .line 140
    .line 141
    iget-object v15, v5, Lyj;->h:Ljava/lang/Object;

    .line 142
    .line 143
    monitor-enter v15

    .line 144
    :try_start_8f
    invoke-virtual {v5}, Lyj;->p()V

    .line 145
    .line 146
    .line 147
    move/from16 p2, v12

    .line 148
    .line 149
    iget-object v12, v5, Lyj;->r:Lhk0;

    .line 150
    .line 151
    invoke-static {}, Lmc0;->h()Lhk0;

    .line 152
    .line 153
    .line 154
    move-result-object v4

    .line 155
    iput-object v4, v5, Lyj;->r:Lhk0;
    :try_end_9c
    .catchall {:try_start_8f .. :try_end_9c} :catchall_107

    .line 156
    .line 157
    :try_start_9c
    iget-object v4, v5, Lyj;->z:Ld10;

    .line 158
    .line 159
    invoke-virtual {v4, v12}, Ld10;->c0(Lhk0;)V
    :try_end_a1
    .catchall {:try_start_9c .. :try_end_a1} :catchall_103

    .line 160
    .line 161
    .line 162
    monitor-exit v15

    .line 163
    new-instance v4, Lve;

    .line 164
    .line 165
    invoke-direct {v4}, Lve;-><init>()V

    .line 166
    .line 167
    .line 168
    iput-object v4, v14, Ld10;->L:Lve;

    .line 169
    .line 170
    iget-object v5, v14, Ld10;->c:Lx51;

    .line 171
    .line 172
    invoke-virtual {v5}, Lx51;->c()Lw51;

    .line 173
    .line 174
    .line 175
    move-result-object v5

    .line 176
    :try_start_af
    iput-object v5, v14, Ld10;->G:Lw51;

    .line 177
    .line 178
    iget-object v12, v14, Ld10;->M:Lpj;

    .line 179
    .line 180
    iget-object v15, v12, Lpj;->b:Lve;
    :try_end_b5
    .catchall {:try_start_af .. :try_end_b5} :catchall_fc

    .line 181
    .line 182
    :try_start_b5
    iput-object v4, v12, Lpj;->b:Lve;

    .line 183
    .line 184
    const/4 v4, 0x0

    .line 185
    invoke-virtual {v14, v4}, Ld10;->M(I)V

    .line 186
    .line 187
    .line 188
    iget-object v4, v14, Ld10;->M:Lpj;

    .line 189
    .line 190
    invoke-virtual {v4}, Lpj;->b()V

    .line 191
    .line 192
    .line 193
    move-object/from16 p3, v3

    .line 194
    .line 195
    iget-boolean v3, v4, Lpj;->c:Z

    .line 196
    .line 197
    if-eqz v3, :cond_eb

    .line 198
    .line 199
    iget-object v3, v4, Lpj;->b:Lve;

    .line 200
    .line 201
    iget-object v3, v3, Lve;->F:Lzo0;
    :try_end_ca
    .catchall {:try_start_b5 .. :try_end_ca} :catchall_f6

    .line 202
    .line 203
    move-object/from16 v18, v5

    .line 204
    .line 205
    :try_start_cc
    sget-object v5, Lqo0;->c:Lqo0;

    .line 206
    .line 207
    invoke-virtual {v3, v5}, Lzo0;->C(Lxo0;)V

    .line 208
    .line 209
    .line 210
    iget-boolean v3, v4, Lpj;->c:Z

    .line 211
    .line 212
    if-eqz v3, :cond_ed

    .line 213
    .line 214
    const/4 v3, 0x0

    .line 215
    invoke-virtual {v4, v3}, Lpj;->d(Z)V

    .line 216
    .line 217
    .line 218
    invoke-virtual {v4, v3}, Lpj;->d(Z)V

    .line 219
    .line 220
    .line 221
    iget-object v5, v4, Lpj;->b:Lve;

    .line 222
    .line 223
    iget-object v5, v5, Lve;->F:Lzo0;

    .line 224
    .line 225
    sget-object v3, Lao0;->c:Lao0;

    .line 226
    .line 227
    invoke-virtual {v5, v3}, Lzo0;->C(Lxo0;)V

    .line 228
    .line 229
    .line 230
    const/4 v3, 0x0

    .line 231
    iput-boolean v3, v4, Lpj;->c:Z
    :try_end_e8
    .catchall {:try_start_cc .. :try_end_e8} :catchall_e9

    .line 232
    .line 233
    goto :goto_ee

    .line 234
    :catchall_e9
    move-exception v0

    .line 235
    goto :goto_f9

    .line 236
    :cond_eb
    move-object/from16 v18, v5

    .line 237
    .line 238
    :cond_ed
    const/4 v3, 0x0

    .line 239
    :goto_ee
    :try_start_ee
    iput-object v15, v12, Lpj;->b:Lve;
    :try_end_f0
    .catchall {:try_start_ee .. :try_end_f0} :catchall_f4

    .line 240
    .line 241
    invoke-virtual/range {v18 .. v18}, Lw51;->c()V

    .line 242
    .line 243
    .line 244
    goto :goto_10f

    .line 245
    :catchall_f4
    move-exception v0

    .line 246
    goto :goto_ff

    .line 247
    :catchall_f6
    move-exception v0

    .line 248
    move-object/from16 v18, v5

    .line 249
    .line 250
    :goto_f9
    :try_start_f9
    iput-object v15, v12, Lpj;->b:Lve;

    .line 251
    .line 252
    throw v0
    :try_end_fc
    .catchall {:try_start_f9 .. :try_end_fc} :catchall_f4

    .line 253
    :catchall_fc
    move-exception v0

    .line 254
    move-object/from16 v18, v5

    .line 255
    .line 256
    :goto_ff
    invoke-virtual/range {v18 .. v18}, Lw51;->c()V

    .line 257
    .line 258
    .line 259
    throw v0

    .line 260
    :catchall_103
    move-exception v0

    .line 261
    :try_start_104
    iput-object v12, v5, Lyj;->r:Lhk0;

    .line 262
    .line 263
    throw v0
    :try_end_107
    .catchall {:try_start_104 .. :try_end_107} :catchall_107

    .line 264
    :catchall_107
    move-exception v0

    .line 265
    monitor-exit v15

    .line 266
    throw v0

    .line 267
    :cond_10a
    move-object/from16 p3, v3

    .line 268
    .line 269
    move v3, v4

    .line 270
    move/from16 p2, v12

    .line 271
    .line 272
    :goto_10f
    iget-object v4, v0, Ld10;->b:Lsj;

    .line 273
    .line 274
    iget-object v5, v14, Ld10;->h:Lyj;

    .line 275
    .line 276
    invoke-virtual {v4, v5}, Lsj;->r(Lyj;)V

    .line 277
    .line 278
    .line 279
    goto :goto_11e

    .line 280
    :cond_117
    move-object/from16 p3, v3

    .line 281
    .line 282
    move v3, v4

    .line 283
    move/from16 p2, v12

    .line 284
    .line 285
    const/16 v16, 0x1

    .line 286
    .line 287
    :goto_11e
    shr-long v9, v9, p2

    .line 288
    .line 289
    add-int/lit8 v13, v13, 0x1

    .line 290
    .line 291
    move/from16 v12, p2

    .line 292
    .line 293
    move v4, v3

    .line 294
    move-object/from16 v3, p3

    .line 295
    .line 296
    goto/16 :goto_67

    .line 297
    .line 298
    :cond_129
    move-object/from16 p3, v3

    .line 299
    .line 300
    move v3, v4

    .line 301
    move v4, v12

    .line 302
    const/16 v16, 0x1

    .line 303
    .line 304
    if-ne v11, v4, :cond_140

    .line 305
    .line 306
    goto :goto_137

    .line 307
    :cond_132
    move-object/from16 p3, v3

    .line 308
    .line 309
    move v3, v4

    .line 310
    const/16 v16, 0x1

    .line 311
    .line 312
    :goto_137
    if-eq v8, v7, :cond_140

    .line 313
    .line 314
    add-int/lit8 v8, v8, 0x1

    .line 315
    .line 316
    move v4, v3

    .line 317
    move-object/from16 v3, p3

    .line 318
    .line 319
    goto/16 :goto_4d

    .line 320
    .line 321
    :cond_140
    invoke-virtual {v2, v1}, Lw51;->o(I)I

    .line 322
    .line 323
    .line 324
    move-result v0

    .line 325
    return v0

    .line 326
    :cond_145
    const/16 v16, 0x1

    .line 327
    .line 328
    invoke-virtual {v2, v1}, Lw51;->l(I)Z

    .line 329
    .line 330
    .line 331
    move-result v0

    .line 332
    if-eqz v0, :cond_14f

    .line 333
    .line 334
    goto/16 :goto_1bd

    .line 335
    .line 336
    :cond_14f
    invoke-virtual {v2, v1}, Lw51;->o(I)I

    .line 337
    .line 338
    .line 339
    move-result v0

    .line 340
    return v0

    .line 341
    :cond_154
    move v3, v4

    .line 342
    const/16 v16, 0x1

    .line 343
    .line 344
    invoke-virtual {v2, v1}, Lw51;->d(I)Z

    .line 345
    .line 346
    .line 347
    move-result v4

    .line 348
    if-eqz v4, :cond_1b7

    .line 349
    .line 350
    iget-object v4, v2, Lw51;->b:[I

    .line 351
    .line 352
    mul-int/lit8 v5, v1, 0x5

    .line 353
    .line 354
    add-int/lit8 v5, v5, 0x3

    .line 355
    .line 356
    aget v4, v4, v5

    .line 357
    .line 358
    add-int/2addr v4, v1

    .line 359
    add-int/lit8 v5, v1, 0x1

    .line 360
    .line 361
    move v6, v5

    .line 362
    move v5, v3

    .line 363
    :goto_16a
    if-ge v6, v4, :cond_1af

    .line 364
    .line 365
    invoke-virtual {v2, v6}, Lw51;->l(I)Z

    .line 366
    .line 367
    .line 368
    move-result v7

    .line 369
    if-eqz v7, :cond_185

    .line 370
    .line 371
    iget-object v8, v0, Ld10;->M:Lpj;

    .line 372
    .line 373
    invoke-virtual {v8}, Lpj;->c()V

    .line 374
    .line 375
    .line 376
    iget-object v8, v0, Ld10;->M:Lpj;

    .line 377
    .line 378
    invoke-virtual {v2, v6}, Lw51;->n(I)Ljava/lang/Object;

    .line 379
    .line 380
    .line 381
    move-result-object v9

    .line 382
    invoke-virtual {v8}, Lpj;->c()V

    .line 383
    .line 384
    .line 385
    iget-object v8, v8, Lpj;->h:Ljava/util/ArrayList;

    .line 386
    .line 387
    invoke-virtual {v8, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 388
    .line 389
    .line 390
    :cond_185
    if-nez v7, :cond_18c

    .line 391
    .line 392
    if-eqz p2, :cond_18a

    .line 393
    .line 394
    goto :goto_18c

    .line 395
    :cond_18a
    move v8, v3

    .line 396
    goto :goto_18e

    .line 397
    :cond_18c
    :goto_18c
    move/from16 v8, v16

    .line 398
    .line 399
    :goto_18e
    if-eqz v7, :cond_192

    .line 400
    .line 401
    move v9, v3

    .line 402
    goto :goto_194

    .line 403
    :cond_192
    add-int v9, p3, v5

    .line 404
    .line 405
    :goto_194
    invoke-static {v0, v6, v8, v9}, Ld10;->N(Ld10;IZI)I

    .line 406
    .line 407
    .line 408
    move-result v8

    .line 409
    add-int/2addr v5, v8

    .line 410
    if-eqz v7, :cond_1a5

    .line 411
    .line 412
    iget-object v7, v0, Ld10;->M:Lpj;

    .line 413
    .line 414
    invoke-virtual {v7}, Lpj;->c()V

    .line 415
    .line 416
    .line 417
    iget-object v7, v0, Ld10;->M:Lpj;

    .line 418
    .line 419
    invoke-virtual {v7}, Lpj;->a()V

    .line 420
    .line 421
    .line 422
    :cond_1a5
    iget-object v7, v2, Lw51;->b:[I

    .line 423
    .line 424
    mul-int/lit8 v8, v6, 0x5

    .line 425
    .line 426
    add-int/lit8 v8, v8, 0x3

    .line 427
    .line 428
    aget v7, v7, v8

    .line 429
    .line 430
    add-int/2addr v6, v7

    .line 431
    goto :goto_16a

    .line 432
    :cond_1af
    invoke-virtual {v2, v1}, Lw51;->l(I)Z

    .line 433
    .line 434
    .line 435
    move-result v0

    .line 436
    if-eqz v0, :cond_1b6

    .line 437
    .line 438
    goto :goto_1bd

    .line 439
    :cond_1b6
    return v5

    .line 440
    :cond_1b7
    invoke-virtual {v2, v1}, Lw51;->l(I)Z

    .line 441
    .line 442
    .line 443
    move-result v0

    .line 444
    if-eqz v0, :cond_1be

    .line 445
    .line 446
    :goto_1bd
    return v16

    .line 447
    :cond_1be
    invoke-virtual {v2, v1}, Lw51;->o(I)I

    .line 448
    .line 449
    .line 450
    move-result v0

    .line 451
    return v0
.end method


# virtual methods
.method public final A()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, Ld10;->S:Z

    .line 2
    .line 3
    if-nez v0, :cond_1b

    .line 4
    .line 5
    iget-boolean v0, p0, Ld10;->y:Z

    .line 6
    .line 7
    if-nez v0, :cond_1b

    .line 8
    .line 9
    iget-boolean v0, p0, Ld10;->w:Z

    .line 10
    .line 11
    if-nez v0, :cond_1b

    .line 12
    .line 13
    invoke-virtual {p0}, Ld10;->x()Lxv0;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    if-eqz p0, :cond_1b

    .line 18
    .line 19
    iget p0, p0, Lxv0;->b:I

    .line 20
    .line 21
    and-int/lit8 p0, p0, 0x8

    .line 22
    .line 23
    if-eqz p0, :cond_19

    .line 24
    .line 25
    goto :goto_1b

    .line 26
    :cond_19
    const/4 p0, 0x1

    .line 27
    return p0

    .line 28
    :cond_1b
    :goto_1b
    const/4 p0, 0x0

    .line 29
    return p0
.end method

.method public final B(Ljava/util/ArrayList;)V
    .registers 18

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-object v1, v0, Ld10;->f:Lve;

    .line 4
    .line 5
    iget-object v6, v0, Ld10;->M:Lpj;

    .line 6
    .line 7
    iget-object v7, v6, Lpj;->b:Lve;

    .line 8
    .line 9
    :try_start_8
    iput-object v1, v6, Lpj;->b:Lve;

    .line 10
    .line 11
    iget-object v1, v1, Lve;->F:Lzo0;

    .line 12
    .line 13
    sget-object v2, Loo0;->c:Loo0;

    .line 14
    .line 15
    invoke-virtual {v1, v2}, Lzo0;->C(Lxo0;)V

    .line 16
    .line 17
    .line 18
    invoke-interface/range {p1 .. p1}, Ljava/util/Collection;->size()I

    .line 19
    .line 20
    .line 21
    move-result v8

    .line 22
    const/4 v9, 0x0

    .line 23
    move v10, v9

    .line 24
    :goto_17
    if-ge v10, v8, :cond_ac

    .line 25
    .line 26
    move-object/from16 v11, p1

    .line 27
    .line 28
    invoke-interface {v11, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v1

    .line 32
    check-cast v1, Lzp0;

    .line 33
    .line 34
    iget-object v2, v1, Lzp0;->e:Ljava/lang/Object;

    .line 35
    .line 36
    check-cast v2, Lgj0;

    .line 37
    .line 38
    iget-object v1, v1, Lzp0;->f:Ljava/lang/Object;

    .line 39
    .line 40
    check-cast v1, Lgj0;

    .line 41
    .line 42
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 43
    .line 44
    .line 45
    const/4 v1, 0x0

    .line 46
    invoke-static {v1}, Lac;->j(Ly00;)Ly00;

    .line 47
    .line 48
    .line 49
    move-result-object v3

    .line 50
    invoke-static {v1}, Lz51;->d(Lx51;)Lx51;

    .line 51
    .line 52
    .line 53
    move-result-object v1

    .line 54
    invoke-virtual {v1, v3}, Lx51;->a(Ly00;)I

    .line 55
    .line 56
    .line 57
    move-result v4

    .line 58
    new-instance v12, Ls60;

    .line 59
    .line 60
    invoke-direct {v12}, Ls60;-><init>()V

    .line 61
    .line 62
    .line 63
    invoke-virtual {v6}, Lpj;->b()V

    .line 64
    .line 65
    .line 66
    iget-object v5, v6, Lpj;->b:Lve;

    .line 67
    .line 68
    iget-object v5, v5, Lve;->F:Lzo0;

    .line 69
    .line 70
    sget-object v13, Lxn0;->c:Lxn0;

    .line 71
    .line 72
    invoke-virtual {v5, v13}, Lzo0;->C(Lxo0;)V

    .line 73
    .line 74
    .line 75
    const/4 v13, 0x1

    .line 76
    invoke-static {v5, v9, v12, v13, v3}, Ldd0;->w(Lzo0;ILjava/lang/Object;ILjava/lang/Object;)V

    .line 77
    .line 78
    .line 79
    iget-object v3, v0, Ld10;->H:Lx51;

    .line 80
    .line 81
    if-eq v1, v3, :cond_53

    .line 82
    .line 83
    goto :goto_61

    .line 84
    :cond_53
    iget-object v3, v0, Ld10;->I:La61;

    .line 85
    .line 86
    iget-boolean v3, v3, La61;->w:Z

    .line 87
    .line 88
    if-nez v3, :cond_5e

    .line 89
    .line 90
    const-string v3, "Check failed"

    .line 91
    .line 92
    invoke-static {v3}, Lqj;->a(Ljava/lang/String;)V

    .line 93
    .line 94
    .line 95
    :cond_5e
    invoke-virtual {v0}, Ld10;->v()V

    .line 96
    .line 97
    .line 98
    :goto_61
    invoke-virtual {v1}, Lx51;->c()Lw51;

    .line 99
    .line 100
    .line 101
    move-result-object v14
    :try_end_65
    .catchall {:try_start_8 .. :try_end_65} :catchall_a5

    .line 102
    :try_start_65
    invoke-virtual {v14, v4}, Lw51;->r(I)V

    .line 103
    .line 104
    .line 105
    iput v4, v6, Lpj;->f:I

    .line 106
    .line 107
    new-instance v15, Lve;

    .line 108
    .line 109
    invoke-direct {v15}, Lve;-><init>()V

    .line 110
    .line 111
    .line 112
    new-instance v5, Lna;

    .line 113
    .line 114
    invoke-direct {v5, v0, v15, v14, v2}, Lna;-><init>(Ld10;Lve;Lw51;Lgj0;)V

    .line 115
    .line 116
    .line 117
    sget-object v4, Lut;->e:Lut;

    .line 118
    .line 119
    const/4 v3, 0x0

    .line 120
    const/4 v2, 0x0

    .line 121
    const/4 v1, 0x0

    .line 122
    invoke-virtual/range {v0 .. v5}, Ld10;->G(Lyj;Lyj;Ljava/lang/Integer;Ljava/util/List;Lxz;)Ljava/lang/Object;

    .line 123
    .line 124
    .line 125
    iget-object v0, v6, Lpj;->b:Lve;

    .line 126
    .line 127
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 128
    .line 129
    .line 130
    iget-object v1, v15, Lve;->F:Lzo0;

    .line 131
    .line 132
    invoke-virtual {v1}, Lzo0;->B()Z

    .line 133
    .line 134
    .line 135
    move-result v1

    .line 136
    if-nez v1, :cond_93

    .line 137
    .line 138
    iget-object v0, v0, Lve;->F:Lzo0;

    .line 139
    .line 140
    sget-object v1, Ltn0;->c:Ltn0;

    .line 141
    .line 142
    invoke-virtual {v0, v1}, Lzo0;->C(Lxo0;)V

    .line 143
    .line 144
    .line 145
    invoke-static {v0, v9, v15, v13, v12}, Ldd0;->w(Lzo0;ILjava/lang/Object;ILjava/lang/Object;)V
    :try_end_93
    .catchall {:try_start_65 .. :try_end_93} :catchall_a7

    .line 146
    .line 147
    .line 148
    :cond_93
    :try_start_93
    invoke-virtual {v14}, Lw51;->c()V

    .line 149
    .line 150
    .line 151
    iget-object v0, v6, Lpj;->b:Lve;

    .line 152
    .line 153
    iget-object v0, v0, Lve;->F:Lzo0;

    .line 154
    .line 155
    sget-object v1, Lqo0;->c:Lqo0;

    .line 156
    .line 157
    invoke-virtual {v0, v1}, Lzo0;->C(Lxo0;)V

    .line 158
    .line 159
    .line 160
    add-int/lit8 v10, v10, 0x1

    .line 161
    .line 162
    move-object/from16 v0, p0

    .line 163
    .line 164
    goto/16 :goto_17

    .line 165
    .line 166
    :catchall_a5
    move-exception v0

    .line 167
    goto :goto_bd

    .line 168
    :catchall_a7
    move-exception v0

    .line 169
    invoke-virtual {v14}, Lw51;->c()V

    .line 170
    .line 171
    .line 172
    throw v0

    .line 173
    :cond_ac
    invoke-virtual {v6}, Lpj;->b()V

    .line 174
    .line 175
    .line 176
    iget-object v0, v6, Lpj;->b:Lve;

    .line 177
    .line 178
    iget-object v0, v0, Lve;->F:Lzo0;

    .line 179
    .line 180
    sget-object v1, Lbo0;->c:Lbo0;

    .line 181
    .line 182
    invoke-virtual {v0, v1}, Lzo0;->C(Lxo0;)V

    .line 183
    .line 184
    .line 185
    iput v9, v6, Lpj;->f:I
    :try_end_ba
    .catchall {:try_start_93 .. :try_end_ba} :catchall_a5

    .line 186
    .line 187
    iput-object v7, v6, Lpj;->b:Lve;

    .line 188
    .line 189
    return-void

    .line 190
    :goto_bd
    iput-object v7, v6, Lpj;->b:Lve;

    .line 191
    .line 192
    throw v0
.end method

.method public final C(Lqr0;Ljava/lang/Object;)V
    .registers 11

    .line 1
    const v0, 0x78cc281

    .line 2
    .line 3
    .line 4
    const/4 v1, 0x0

    .line 5
    const/4 v2, 0x0

    .line 6
    invoke-virtual {p0, v0, v1, v2, v2}, Ld10;->S(IILjava/lang/Object;Ljava/lang/Object;)V

    .line 7
    .line 8
    .line 9
    invoke-virtual {p0}, Ld10;->D()Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    invoke-virtual {p0, p2}, Ld10;->h0(Ljava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    iget-wide v3, p0, Ld10;->T:J

    .line 16
    .line 17
    const-wide/32 v5, 0x78cc281

    .line 18
    .line 19
    .line 20
    :try_start_13
    iput-wide v5, p0, Ld10;->T:J

    .line 21
    .line 22
    iget-boolean v0, p0, Ld10;->S:Z

    .line 23
    .line 24
    if-eqz v0, :cond_21

    .line 25
    .line 26
    iget-object v0, p0, Ld10;->I:La61;

    .line 27
    .line 28
    invoke-static {v0}, La61;->z(La61;)V

    .line 29
    .line 30
    .line 31
    goto :goto_21

    .line 32
    :catchall_1f
    move-exception p1

    .line 33
    goto :goto_65

    .line 34
    :cond_21
    :goto_21
    iget-boolean v0, p0, Ld10;->S:Z

    .line 35
    .line 36
    const/4 v5, 0x1

    .line 37
    if-eqz v0, :cond_28

    .line 38
    .line 39
    :cond_26
    move v0, v1

    .line 40
    goto :goto_35

    .line 41
    :cond_28
    iget-object v0, p0, Ld10;->G:Lw51;

    .line 42
    .line 43
    invoke-virtual {v0}, Lw51;->f()Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    invoke-static {v0, p1}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    if-nez v0, :cond_26

    .line 52
    .line 53
    move v0, v5

    .line 54
    :goto_35
    if-eqz v0, :cond_3a

    .line 55
    .line 56
    invoke-virtual {p0, p1}, Ld10;->J(Lqr0;)V

    .line 57
    .line 58
    .line 59
    :cond_3a
    sget-object v6, Lqj;->c:Lqn0;

    .line 60
    .line 61
    const/16 v7, 0xca

    .line 62
    .line 63
    invoke-virtual {p0, v7, v1, v6, p1}, Ld10;->S(IILjava/lang/Object;Ljava/lang/Object;)V

    .line 64
    .line 65
    .line 66
    iput-object v2, p0, Ld10;->K:Lqr0;

    .line 67
    .line 68
    iget-boolean p1, p0, Ld10;->w:Z

    .line 69
    .line 70
    iput-boolean v0, p0, Ld10;->w:Z

    .line 71
    .line 72
    new-instance v0, Lhc;

    .line 73
    .line 74
    const/4 v6, 0x3

    .line 75
    invoke-direct {v0, v6, p2}, Lhc;-><init>(ILjava/lang/Object;)V

    .line 76
    .line 77
    .line 78
    new-instance p2, Lpi;

    .line 79
    .line 80
    const v6, -0x3873acb

    .line 81
    .line 82
    .line 83
    invoke-direct {p2, v6, v5, v0}, Lpi;-><init>(IZLu00;)V

    .line 84
    .line 85
    .line 86
    invoke-static {p0, p2}, Lvn;->D(Ld10;Lm00;)V

    .line 87
    .line 88
    .line 89
    iput-boolean p1, p0, Ld10;->w:Z
    :try_end_5a
    .catchall {:try_start_13 .. :try_end_5a} :catchall_1f

    .line 90
    .line 91
    invoke-virtual {p0, v1}, Ld10;->p(Z)V

    .line 92
    .line 93
    .line 94
    iput-object v2, p0, Ld10;->K:Lqr0;

    .line 95
    .line 96
    iput-wide v3, p0, Ld10;->T:J

    .line 97
    .line 98
    invoke-virtual {p0, v1}, Ld10;->p(Z)V

    .line 99
    .line 100
    .line 101
    return-void

    .line 102
    :goto_65
    :try_start_65
    new-instance p2, Lz00;

    .line 103
    .line 104
    const/4 v0, 0x2

    .line 105
    invoke-direct {p2, v0, p0}, Lz00;-><init>(ILd10;)V

    .line 106
    .line 107
    .line 108
    invoke-static {p1, p2}, La5;->P(Ljava/lang/Throwable;Lxz;)Z

    .line 109
    .line 110
    .line 111
    throw p1
    :try_end_6f
    .catchall {:try_start_65 .. :try_end_6f} :catchall_6f

    .line 112
    :catchall_6f
    move-exception p1

    .line 113
    invoke-virtual {p0, v1}, Ld10;->p(Z)V

    .line 114
    .line 115
    .line 116
    iput-object v2, p0, Ld10;->K:Lqr0;

    .line 117
    .line 118
    iput-wide v3, p0, Ld10;->T:J

    .line 119
    .line 120
    invoke-virtual {p0, v1}, Ld10;->p(Z)V

    .line 121
    .line 122
    .line 123
    throw p1
.end method

.method public final D()Ljava/lang/Object;
    .registers 3

    .line 1
    iget-boolean v0, p0, Ld10;->S:Z

    .line 2
    .line 3
    sget-object v1, Loj;->a:Lnq0;

    .line 4
    .line 5
    if-eqz v0, :cond_10

    .line 6
    .line 7
    iget-boolean p0, p0, Ld10;->r:Z

    .line 8
    .line 9
    if-eqz p0, :cond_1e

    .line 10
    .line 11
    const-string p0, "A call to createNode(), emitNode() or useNode() expected"

    .line 12
    .line 13
    invoke-static {p0}, Lqj;->a(Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    return-object v1

    .line 17
    :cond_10
    iget-object v0, p0, Ld10;->G:Lw51;

    .line 18
    .line 19
    invoke-virtual {v0}, Lw51;->m()Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    iget-boolean p0, p0, Ld10;->y:Z

    .line 24
    .line 25
    if-eqz p0, :cond_1f

    .line 26
    .line 27
    instance-of p0, v0, Ltx0;

    .line 28
    .line 29
    if-nez p0, :cond_1f

    .line 30
    .line 31
    :cond_1e
    return-object v1

    .line 32
    :cond_1f
    return-object v0
.end method

.method public final E()Ljava/util/List;
    .registers 6

    .line 1
    iget-object p0, p0, Ld10;->b:Lsj;

    .line 2
    .line 3
    invoke-virtual {p0}, Lsj;->h()Lrj;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    invoke-static {v0}, Lfu0;->M(Ljava/lang/Object;)Z

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    if-eqz v1, :cond_f

    .line 12
    .line 13
    check-cast v0, Lyj;

    .line 14
    .line 15
    goto :goto_10

    .line 16
    :cond_f
    const/4 v0, 0x0

    .line 17
    :goto_10
    if-nez v0, :cond_13

    .line 18
    .line 19
    goto :goto_50

    .line 20
    :cond_13
    iget-object v1, v0, Lyj;->j:Lx51;

    .line 21
    .line 22
    invoke-static {v1}, Lz51;->d(Lx51;)Lx51;

    .line 23
    .line 24
    .line 25
    move-result-object v2

    .line 26
    invoke-virtual {v2}, Lx51;->c()Lw51;

    .line 27
    .line 28
    .line 29
    move-result-object v2

    .line 30
    :try_start_1d
    iget v3, v2, Lw51;->c:I

    .line 31
    .line 32
    const/4 v4, 0x0

    .line 33
    invoke-static {v2, p0, v4, v3}, Lwl1;->w(Lw51;Lsj;II)Ljava/lang/Integer;

    .line 34
    .line 35
    .line 36
    move-result-object p0
    :try_end_24
    .catchall {:try_start_1d .. :try_end_24} :catchall_53

    .line 37
    invoke-virtual {v2}, Lw51;->c()V

    .line 38
    .line 39
    .line 40
    if-eqz p0, :cond_50

    .line 41
    .line 42
    invoke-static {v1}, Lz51;->d(Lx51;)Lx51;

    .line 43
    .line 44
    .line 45
    move-result-object v1

    .line 46
    invoke-virtual {v1}, Lx51;->c()Lw51;

    .line 47
    .line 48
    .line 49
    move-result-object v1

    .line 50
    :try_start_31
    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    .line 51
    .line 52
    .line 53
    move-result p0

    .line 54
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 55
    .line 56
    .line 57
    move-result-object v2

    .line 58
    invoke-static {v1, p0, v2}, Lwl1;->O(Lw51;ILjava/lang/Integer;)Ljava/util/ArrayList;

    .line 59
    .line 60
    .line 61
    move-result-object p0
    :try_end_3d
    .catchall {:try_start_31 .. :try_end_3d} :catchall_4b

    .line 62
    invoke-virtual {v1}, Lw51;->c()V

    .line 63
    .line 64
    .line 65
    iget-object v0, v0, Lyj;->z:Ld10;

    .line 66
    .line 67
    invoke-virtual {v0}, Ld10;->E()Ljava/util/List;

    .line 68
    .line 69
    .line 70
    move-result-object v0

    .line 71
    invoke-static {p0, v0}, Ltg;->Z(Ljava/util/Collection;Ljava/util/List;)Ljava/util/ArrayList;

    .line 72
    .line 73
    .line 74
    move-result-object p0

    .line 75
    return-object p0

    .line 76
    :catchall_4b
    move-exception p0

    .line 77
    invoke-virtual {v1}, Lw51;->c()V

    .line 78
    .line 79
    .line 80
    throw p0

    .line 81
    :cond_50
    :goto_50
    sget-object p0, Lut;->e:Lut;

    .line 82
    .line 83
    return-object p0

    .line 84
    :catchall_53
    move-exception p0

    .line 85
    invoke-virtual {v2}, Lw51;->c()V

    .line 86
    .line 87
    .line 88
    throw p0
.end method

.method public final F(I)I
    .registers 6

    .line 1
    iget-object v0, p0, Ld10;->G:Lw51;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Lw51;->q(I)I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    add-int/lit8 v0, v0, 0x1

    .line 8
    .line 9
    const/4 v1, 0x0

    .line 10
    :goto_9
    if-ge v0, p1, :cond_21

    .line 11
    .line 12
    iget-object v2, p0, Ld10;->G:Lw51;

    .line 13
    .line 14
    invoke-virtual {v2, v0}, Lw51;->k(I)Z

    .line 15
    .line 16
    .line 17
    move-result v2

    .line 18
    if-nez v2, :cond_15

    .line 19
    .line 20
    add-int/lit8 v1, v1, 0x1

    .line 21
    .line 22
    :cond_15
    iget-object v2, p0, Ld10;->G:Lw51;

    .line 23
    .line 24
    iget-object v2, v2, Lw51;->b:[I

    .line 25
    .line 26
    mul-int/lit8 v3, v0, 0x5

    .line 27
    .line 28
    add-int/lit8 v3, v3, 0x3

    .line 29
    .line 30
    aget v2, v2, v3

    .line 31
    .line 32
    add-int/2addr v0, v2

    .line 33
    goto :goto_9

    .line 34
    :cond_21
    return v1
.end method

.method public final G(Lyj;Lyj;Ljava/lang/Integer;Ljava/util/List;Lxz;)Ljava/lang/Object;
    .registers 14

    .line 1
    iget-boolean v0, p0, Ld10;->F:Z

    .line 2
    .line 3
    iget v1, p0, Ld10;->k:I

    .line 4
    .line 5
    const/4 v2, 0x1

    .line 6
    :try_start_5
    iput-boolean v2, p0, Ld10;->F:Z

    .line 7
    .line 8
    const/4 v2, 0x0

    .line 9
    iput v2, p0, Ld10;->k:I

    .line 10
    .line 11
    invoke-interface {p4}, Ljava/util/Collection;->size()I

    .line 12
    .line 13
    .line 14
    move-result v3

    .line 15
    move v4, v2

    .line 16
    :goto_f
    const/4 v5, 0x0

    .line 17
    if-ge v4, v3, :cond_2c

    .line 18
    .line 19
    invoke-interface {p4, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v6

    .line 23
    check-cast v6, Lzp0;

    .line 24
    .line 25
    iget-object v7, v6, Lzp0;->e:Ljava/lang/Object;

    .line 26
    .line 27
    check-cast v7, Lxv0;

    .line 28
    .line 29
    iget-object v6, v6, Lzp0;->f:Ljava/lang/Object;

    .line 30
    .line 31
    if-eqz v6, :cond_26

    .line 32
    .line 33
    invoke-virtual {p0, v7, v6}, Ld10;->b0(Lxv0;Ljava/lang/Object;)Z

    .line 34
    .line 35
    .line 36
    goto :goto_29

    .line 37
    :catchall_24
    move-exception p1

    .line 38
    goto :goto_5e

    .line 39
    :cond_26
    invoke-virtual {p0, v7, v5}, Ld10;->b0(Lxv0;Ljava/lang/Object;)Z

    .line 40
    .line 41
    .line 42
    :goto_29
    add-int/lit8 v4, v4, 0x1

    .line 43
    .line 44
    goto :goto_f

    .line 45
    :cond_2c
    if-eqz p1, :cond_55

    .line 46
    .line 47
    if-eqz p3, :cond_35

    .line 48
    .line 49
    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    .line 50
    .line 51
    .line 52
    move-result p3

    .line 53
    goto :goto_36

    .line 54
    :cond_35
    const/4 p3, -0x1

    .line 55
    :goto_36
    if-eqz p2, :cond_4f

    .line 56
    .line 57
    if-eq p2, p1, :cond_4f

    .line 58
    .line 59
    if-ltz p3, :cond_4f

    .line 60
    .line 61
    iput-object p2, p1, Lyj;->v:Lyj;

    .line 62
    .line 63
    iput p3, p1, Lyj;->w:I
    :try_end_40
    .catchall {:try_start_5 .. :try_end_40} :catchall_24

    .line 64
    .line 65
    :try_start_40
    invoke-interface {p5}, Lxz;->a()Ljava/lang/Object;

    .line 66
    .line 67
    .line 68
    move-result-object p2
    :try_end_44
    .catchall {:try_start_40 .. :try_end_44} :catchall_49

    .line 69
    :try_start_44
    iput-object v5, p1, Lyj;->v:Lyj;

    .line 70
    .line 71
    iput v2, p1, Lyj;->w:I

    .line 72
    .line 73
    goto :goto_53

    .line 74
    :catchall_49
    move-exception p2

    .line 75
    iput-object v5, p1, Lyj;->v:Lyj;

    .line 76
    .line 77
    iput v2, p1, Lyj;->w:I

    .line 78
    .line 79
    throw p2

    .line 80
    :cond_4f
    invoke-interface {p5}, Lxz;->a()Ljava/lang/Object;

    .line 81
    .line 82
    .line 83
    move-result-object p2

    .line 84
    :goto_53
    if-nez p2, :cond_59

    .line 85
    .line 86
    :cond_55
    invoke-interface {p5}, Lxz;->a()Ljava/lang/Object;

    .line 87
    .line 88
    .line 89
    move-result-object p2
    :try_end_59
    .catchall {:try_start_44 .. :try_end_59} :catchall_24

    .line 90
    :cond_59
    iput-boolean v0, p0, Ld10;->F:Z

    .line 91
    .line 92
    iput v1, p0, Ld10;->k:I

    .line 93
    .line 94
    return-object p2

    .line 95
    :goto_5e
    iput-boolean v0, p0, Ld10;->F:Z

    .line 96
    .line 97
    iput v1, p0, Ld10;->k:I

    .line 98
    .line 99
    throw p1
.end method

.method public final H()V
    .registers 41

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    sget-object v1, Lnq0;->j:Lnq0;

    .line 4
    .line 5
    iget-boolean v2, v0, Ld10;->F:Z

    .line 6
    .line 7
    const/4 v3, 0x1

    .line 8
    iput-boolean v3, v0, Ld10;->F:Z

    .line 9
    .line 10
    iget-object v4, v0, Ld10;->G:Lw51;

    .line 11
    .line 12
    iget v5, v4, Lw51;->i:I

    .line 13
    .line 14
    iget-object v6, v4, Lw51;->b:[I

    .line 15
    .line 16
    mul-int/lit8 v7, v5, 0x5

    .line 17
    .line 18
    const/4 v8, 0x3

    .line 19
    add-int/2addr v7, v8

    .line 20
    aget v6, v6, v7

    .line 21
    .line 22
    add-int/2addr v6, v5

    .line 23
    iget v9, v0, Ld10;->k:I

    .line 24
    .line 25
    iget-wide v10, v0, Ld10;->T:J

    .line 26
    .line 27
    iget v12, v0, Ld10;->l:I

    .line 28
    .line 29
    iget v13, v0, Ld10;->m:I

    .line 30
    .line 31
    iget v4, v4, Lw51;->g:I

    .line 32
    .line 33
    iget-object v14, v0, Ld10;->s:Ljava/util/ArrayList;

    .line 34
    .line 35
    invoke-static {v4, v14}, Lvn;->s(ILjava/util/List;)I

    .line 36
    .line 37
    .line 38
    move-result v4

    .line 39
    if-gez v4, :cond_2b

    .line 40
    .line 41
    add-int/lit8 v4, v4, 0x1

    .line 42
    .line 43
    neg-int v4, v4

    .line 44
    :cond_2b
    invoke-virtual {v14}, Ljava/util/ArrayList;->size()I

    .line 45
    .line 46
    .line 47
    move-result v15

    .line 48
    move/from16 v16, v8

    .line 49
    .line 50
    if-ge v4, v15, :cond_3e

    .line 51
    .line 52
    invoke-virtual {v14, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    move-result-object v4

    .line 56
    check-cast v4, Lu70;

    .line 57
    .line 58
    iget v15, v4, Lu70;->b:I

    .line 59
    .line 60
    if-ge v15, v6, :cond_3e

    .line 61
    .line 62
    goto :goto_3f

    .line 63
    :cond_3e
    const/4 v4, 0x0

    .line 64
    :goto_3f
    move/from16 v18, v3

    .line 65
    .line 66
    move v3, v5

    .line 67
    const/16 v17, 0x0

    .line 68
    .line 69
    :goto_44
    if-eqz v4, :cond_34f

    .line 70
    .line 71
    iget-object v15, v4, Lu70;->a:Lxv0;

    .line 72
    .line 73
    iget v8, v4, Lu70;->b:I

    .line 74
    .line 75
    move-object/from16 v20, v1

    .line 76
    .line 77
    invoke-static {v8, v14}, Lvn;->s(ILjava/util/List;)I

    .line 78
    .line 79
    .line 80
    move-result v1

    .line 81
    if-ltz v1, :cond_58

    .line 82
    .line 83
    invoke-virtual {v14, v1}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 84
    .line 85
    .line 86
    move-result-object v1

    .line 87
    check-cast v1, Lu70;

    .line 88
    .line 89
    :cond_58
    iget-object v1, v4, Lu70;->c:Ljava/lang/Object;

    .line 90
    .line 91
    const-wide/16 v21, 0x80

    .line 92
    .line 93
    const-wide/16 v23, 0xff

    .line 94
    .line 95
    const/16 v25, 0x7

    .line 96
    .line 97
    const-wide v26, -0x7f7f7f7f7f7f7f80L  # -2.937446524422997E-306

    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    if-nez v1, :cond_78

    .line 103
    .line 104
    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 105
    .line 106
    .line 107
    move/from16 v34, v6

    .line 108
    .line 109
    move/from16 v29, v7

    .line 110
    .line 111
    move/from16 v30, v9

    .line 112
    .line 113
    :goto_70
    move/from16 v32, v12

    .line 114
    .line 115
    move/from16 v33, v13

    .line 116
    .line 117
    :cond_74
    :goto_74
    move/from16 v1, v18

    .line 118
    .line 119
    goto/16 :goto_137

    .line 120
    .line 121
    :cond_78
    const/16 v28, 0x8

    .line 122
    .line 123
    iget-object v4, v15, Lxv0;->g:Lhk0;

    .line 124
    .line 125
    if-nez v4, :cond_85

    .line 126
    .line 127
    move/from16 v34, v6

    .line 128
    .line 129
    move/from16 v29, v7

    .line 130
    .line 131
    move/from16 v30, v9

    .line 132
    .line 133
    goto :goto_70

    .line 134
    :cond_85
    move/from16 v29, v7

    .line 135
    .line 136
    instance-of v7, v1, Lsp;

    .line 137
    .line 138
    if-eqz v7, :cond_ad

    .line 139
    .line 140
    check-cast v1, Lsp;

    .line 141
    .line 142
    iget-object v7, v1, Lsp;->g:Lt61;

    .line 143
    .line 144
    if-nez v7, :cond_93

    .line 145
    .line 146
    move-object/from16 v7, v20

    .line 147
    .line 148
    :cond_93
    move/from16 v30, v9

    .line 149
    .line 150
    invoke-virtual {v1}, Lsp;->h()Lrp;

    .line 151
    .line 152
    .line 153
    move-result-object v9

    .line 154
    iget-object v9, v9, Lrp;->f:Ljava/lang/Object;

    .line 155
    .line 156
    invoke-virtual {v4, v1}, Lhk0;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 157
    .line 158
    .line 159
    move-result-object v1

    .line 160
    invoke-interface {v7, v9, v1}, Lt61;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 161
    .line 162
    .line 163
    move-result v1

    .line 164
    xor-int/lit8 v1, v1, 0x1

    .line 165
    .line 166
    move/from16 v34, v6

    .line 167
    .line 168
    move/from16 v32, v12

    .line 169
    .line 170
    move/from16 v33, v13

    .line 171
    .line 172
    goto/16 :goto_137

    .line 173
    .line 174
    :cond_ad
    move/from16 v30, v9

    .line 175
    .line 176
    instance-of v7, v1, Lik0;

    .line 177
    .line 178
    if-eqz v7, :cond_133

    .line 179
    .line 180
    check-cast v1, Lik0;

    .line 181
    .line 182
    invoke-virtual {v1}, Lik0;->h()Z

    .line 183
    .line 184
    .line 185
    move-result v7

    .line 186
    if-eqz v7, :cond_12b

    .line 187
    .line 188
    iget-object v7, v1, Lik0;->b:[Ljava/lang/Object;

    .line 189
    .line 190
    iget-object v1, v1, Lik0;->a:[J

    .line 191
    .line 192
    array-length v9, v1

    .line 193
    add-int/lit8 v9, v9, -0x2

    .line 194
    .line 195
    if-ltz v9, :cond_12b

    .line 196
    .line 197
    move-object/from16 v31, v1

    .line 198
    .line 199
    move/from16 v32, v12

    .line 200
    .line 201
    move/from16 v33, v13

    .line 202
    .line 203
    const/4 v1, 0x0

    .line 204
    :goto_cb
    aget-wide v12, v31, v1

    .line 205
    .line 206
    move/from16 v34, v6

    .line 207
    .line 208
    move-object/from16 v35, v7

    .line 209
    .line 210
    not-long v6, v12

    .line 211
    shl-long v6, v6, v25

    .line 212
    .line 213
    and-long/2addr v6, v12

    .line 214
    and-long v6, v6, v26

    .line 215
    .line 216
    cmp-long v6, v6, v26

    .line 217
    .line 218
    if-eqz v6, :cond_120

    .line 219
    .line 220
    sub-int v6, v1, v9

    .line 221
    .line 222
    not-int v6, v6

    .line 223
    ushr-int/lit8 v6, v6, 0x1f

    .line 224
    .line 225
    rsub-int/lit8 v6, v6, 0x8

    .line 226
    .line 227
    const/4 v7, 0x0

    .line 228
    :goto_e3
    if-ge v7, v6, :cond_11c

    .line 229
    .line 230
    and-long v36, v12, v23

    .line 231
    .line 232
    cmp-long v36, v36, v21

    .line 233
    .line 234
    if-gez v36, :cond_113

    .line 235
    .line 236
    shl-int/lit8 v36, v1, 0x3

    .line 237
    .line 238
    add-int v36, v36, v7

    .line 239
    .line 240
    move/from16 v37, v7

    .line 241
    .line 242
    aget-object v7, v35, v36

    .line 243
    .line 244
    move-wide/from16 v38, v12

    .line 245
    .line 246
    instance-of v12, v7, Lsp;

    .line 247
    .line 248
    if-eqz v12, :cond_74

    .line 249
    .line 250
    check-cast v7, Lsp;

    .line 251
    .line 252
    iget-object v12, v7, Lsp;->g:Lt61;

    .line 253
    .line 254
    if-nez v12, :cond_101

    .line 255
    .line 256
    move-object/from16 v12, v20

    .line 257
    .line 258
    :cond_101
    invoke-virtual {v7}, Lsp;->h()Lrp;

    .line 259
    .line 260
    .line 261
    move-result-object v13

    .line 262
    iget-object v13, v13, Lrp;->f:Ljava/lang/Object;

    .line 263
    .line 264
    invoke-virtual {v4, v7}, Lhk0;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 265
    .line 266
    .line 267
    move-result-object v7

    .line 268
    invoke-interface {v12, v13, v7}, Lt61;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 269
    .line 270
    .line 271
    move-result v7

    .line 272
    if-nez v7, :cond_117

    .line 273
    .line 274
    goto/16 :goto_74

    .line 275
    .line 276
    :cond_113
    move/from16 v37, v7

    .line 277
    .line 278
    move-wide/from16 v38, v12

    .line 279
    .line 280
    :cond_117
    shr-long v12, v38, v28

    .line 281
    .line 282
    add-int/lit8 v7, v37, 0x1

    .line 283
    .line 284
    goto :goto_e3

    .line 285
    :cond_11c
    move/from16 v7, v28

    .line 286
    .line 287
    if-ne v6, v7, :cond_131

    .line 288
    .line 289
    :cond_120
    if-eq v1, v9, :cond_131

    .line 290
    .line 291
    add-int/lit8 v1, v1, 0x1

    .line 292
    .line 293
    move/from16 v6, v34

    .line 294
    .line 295
    move-object/from16 v7, v35

    .line 296
    .line 297
    const/16 v28, 0x8

    .line 298
    .line 299
    goto :goto_cb

    .line 300
    :cond_12b
    move/from16 v34, v6

    .line 301
    .line 302
    move/from16 v32, v12

    .line 303
    .line 304
    move/from16 v33, v13

    .line 305
    .line 306
    :cond_131
    const/4 v1, 0x0

    .line 307
    goto :goto_137

    .line 308
    :cond_133
    move/from16 v34, v6

    .line 309
    .line 310
    goto/16 :goto_70

    .line 311
    .line 312
    :goto_137
    if-eqz v1, :cond_290

    .line 313
    .line 314
    iget-object v1, v0, Ld10;->G:Lw51;

    .line 315
    .line 316
    invoke-virtual {v1, v8}, Lw51;->r(I)V

    .line 317
    .line 318
    .line 319
    iget-object v1, v0, Ld10;->G:Lw51;

    .line 320
    .line 321
    iget v1, v1, Lw51;->g:I

    .line 322
    .line 323
    invoke-virtual {v0, v3, v1, v5}, Ld10;->K(III)V

    .line 324
    .line 325
    .line 326
    iget-object v3, v0, Ld10;->G:Lw51;

    .line 327
    .line 328
    invoke-virtual {v3, v1}, Lw51;->q(I)I

    .line 329
    .line 330
    .line 331
    move-result v3

    .line 332
    :goto_14b
    if-eq v3, v5, :cond_15c

    .line 333
    .line 334
    iget-object v4, v0, Ld10;->G:Lw51;

    .line 335
    .line 336
    invoke-virtual {v4, v3}, Lw51;->l(I)Z

    .line 337
    .line 338
    .line 339
    move-result v4

    .line 340
    if-nez v4, :cond_15c

    .line 341
    .line 342
    iget-object v4, v0, Ld10;->G:Lw51;

    .line 343
    .line 344
    invoke-virtual {v4, v3}, Lw51;->q(I)I

    .line 345
    .line 346
    .line 347
    move-result v3

    .line 348
    goto :goto_14b

    .line 349
    :cond_15c
    iget-object v4, v0, Ld10;->G:Lw51;

    .line 350
    .line 351
    invoke-virtual {v4, v3}, Lw51;->l(I)Z

    .line 352
    .line 353
    .line 354
    move-result v4

    .line 355
    if-eqz v4, :cond_166

    .line 356
    .line 357
    const/4 v4, 0x0

    .line 358
    goto :goto_168

    .line 359
    :cond_166
    move/from16 v4, v30

    .line 360
    .line 361
    :goto_168
    if-ne v3, v1, :cond_16b

    .line 362
    .line 363
    goto :goto_19c

    .line 364
    :cond_16b
    invoke-virtual {v0, v3}, Ld10;->i0(I)I

    .line 365
    .line 366
    .line 367
    move-result v6

    .line 368
    iget-object v7, v0, Ld10;->G:Lw51;

    .line 369
    .line 370
    invoke-virtual {v7, v1}, Lw51;->o(I)I

    .line 371
    .line 372
    .line 373
    move-result v7

    .line 374
    sub-int/2addr v6, v7

    .line 375
    add-int/2addr v6, v4

    .line 376
    :cond_177
    if-ge v4, v6, :cond_19c

    .line 377
    .line 378
    if-eq v3, v8, :cond_19c

    .line 379
    .line 380
    add-int/lit8 v3, v3, 0x1

    .line 381
    .line 382
    :goto_17d
    if-ge v3, v8, :cond_19c

    .line 383
    .line 384
    iget-object v7, v0, Ld10;->G:Lw51;

    .line 385
    .line 386
    iget-object v9, v7, Lw51;->b:[I

    .line 387
    .line 388
    mul-int/lit8 v12, v3, 0x5

    .line 389
    .line 390
    add-int/lit8 v12, v12, 0x3

    .line 391
    .line 392
    aget v9, v9, v12

    .line 393
    .line 394
    add-int/2addr v9, v3

    .line 395
    if-lt v8, v9, :cond_177

    .line 396
    .line 397
    invoke-virtual {v7, v3}, Lw51;->l(I)Z

    .line 398
    .line 399
    .line 400
    move-result v7

    .line 401
    if-eqz v7, :cond_195

    .line 402
    .line 403
    move/from16 v3, v18

    .line 404
    .line 405
    goto :goto_199

    .line 406
    :cond_195
    invoke-virtual {v0, v3}, Ld10;->i0(I)I

    .line 407
    .line 408
    .line 409
    move-result v3

    .line 410
    :goto_199
    add-int/2addr v4, v3

    .line 411
    move v3, v9

    .line 412
    goto :goto_17d

    .line 413
    :cond_19c
    :goto_19c
    iput v4, v0, Ld10;->k:I

    .line 414
    .line 415
    invoke-virtual {v0, v1}, Ld10;->F(I)I

    .line 416
    .line 417
    .line 418
    move-result v3

    .line 419
    iput v3, v0, Ld10;->m:I

    .line 420
    .line 421
    iget-object v3, v0, Ld10;->G:Lw51;

    .line 422
    .line 423
    invoke-virtual {v3, v1}, Lw51;->q(I)I

    .line 424
    .line 425
    .line 426
    move-result v3

    .line 427
    const-wide/16 v6, 0x0

    .line 428
    .line 429
    move/from16 v8, v16

    .line 430
    .line 431
    const/4 v4, 0x0

    .line 432
    :goto_1af
    if-ltz v3, :cond_1b8

    .line 433
    .line 434
    if-ne v3, v5, :cond_1bc

    .line 435
    .line 436
    invoke-static {v10, v11, v4}, Ljava/lang/Long;->rotateLeft(JI)J

    .line 437
    .line 438
    .line 439
    move-result-wide v3

    .line 440
    xor-long/2addr v6, v3

    .line 441
    :cond_1b8
    move/from16 v17, v1

    .line 442
    .line 443
    goto/16 :goto_23a

    .line 444
    .line 445
    :cond_1bc
    iget-object v9, v0, Ld10;->G:Lw51;

    .line 446
    .line 447
    invoke-virtual {v9, v3}, Lw51;->k(I)Z

    .line 448
    .line 449
    .line 450
    move-result v12

    .line 451
    iget-object v13, v9, Lw51;->b:[I

    .line 452
    .line 453
    if-eqz v12, :cond_1e2

    .line 454
    .line 455
    invoke-virtual {v9, v13, v3}, Lw51;->p([II)Ljava/lang/Object;

    .line 456
    .line 457
    .line 458
    move-result-object v9

    .line 459
    if-eqz v9, :cond_1de

    .line 460
    .line 461
    instance-of v12, v9, Ljava/lang/Enum;

    .line 462
    .line 463
    if-eqz v12, :cond_1d9

    .line 464
    .line 465
    check-cast v9, Ljava/lang/Enum;

    .line 466
    .line 467
    invoke-virtual {v9}, Ljava/lang/Enum;->ordinal()I

    .line 468
    .line 469
    .line 470
    move-result v9

    .line 471
    :goto_1d6
    move/from16 v17, v1

    .line 472
    .line 473
    goto :goto_202

    .line 474
    :cond_1d9
    invoke-virtual {v9}, Ljava/lang/Object;->hashCode()I

    .line 475
    .line 476
    .line 477
    move-result v9

    .line 478
    goto :goto_1d6

    .line 479
    :cond_1de
    move/from16 v17, v1

    .line 480
    .line 481
    const/4 v9, 0x0

    .line 482
    goto :goto_202

    .line 483
    :cond_1e2
    invoke-virtual {v9, v3}, Lw51;->i(I)I

    .line 484
    .line 485
    .line 486
    move-result v12

    .line 487
    move/from16 v17, v1

    .line 488
    .line 489
    const/16 v1, 0xcf

    .line 490
    .line 491
    if-ne v12, v1, :cond_201

    .line 492
    .line 493
    invoke-virtual {v9, v13, v3}, Lw51;->b([II)Ljava/lang/Object;

    .line 494
    .line 495
    .line 496
    move-result-object v1

    .line 497
    if-eqz v1, :cond_201

    .line 498
    .line 499
    sget-object v9, Loj;->a:Lnq0;

    .line 500
    .line 501
    invoke-virtual {v1, v9}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 502
    .line 503
    .line 504
    move-result v9

    .line 505
    if-eqz v9, :cond_1fb

    .line 506
    .line 507
    goto :goto_201

    .line 508
    :cond_1fb
    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    .line 509
    .line 510
    .line 511
    move-result v1

    .line 512
    move v9, v1

    .line 513
    goto :goto_202

    .line 514
    :cond_201
    :goto_201
    move v9, v12

    .line 515
    :goto_202
    const v1, 0x78cc281

    .line 516
    .line 517
    .line 518
    if-ne v9, v1, :cond_20e

    .line 519
    .line 520
    int-to-long v8, v9

    .line 521
    invoke-static {v8, v9, v4}, Ljava/lang/Long;->rotateLeft(JI)J

    .line 522
    .line 523
    .line 524
    move-result-wide v3

    .line 525
    xor-long/2addr v6, v3

    .line 526
    goto :goto_23a

    .line 527
    :cond_20e
    iget-object v1, v0, Ld10;->G:Lw51;

    .line 528
    .line 529
    invoke-virtual {v1, v3}, Lw51;->k(I)Z

    .line 530
    .line 531
    .line 532
    move-result v1

    .line 533
    if-eqz v1, :cond_218

    .line 534
    .line 535
    const/4 v1, 0x0

    .line 536
    goto :goto_21c

    .line 537
    :cond_218
    invoke-virtual {v0, v3}, Ld10;->F(I)I

    .line 538
    .line 539
    .line 540
    move-result v1

    .line 541
    :goto_21c
    int-to-long v12, v9

    .line 542
    invoke-static {v12, v13, v8}, Ljava/lang/Long;->rotateLeft(JI)J

    .line 543
    .line 544
    .line 545
    move-result-wide v12

    .line 546
    xor-long/2addr v6, v12

    .line 547
    int-to-long v12, v1

    .line 548
    invoke-static {v12, v13, v4}, Ljava/lang/Long;->rotateLeft(JI)J

    .line 549
    .line 550
    .line 551
    move-result-wide v12

    .line 552
    xor-long/2addr v6, v12

    .line 553
    add-int/lit8 v8, v8, 0x6

    .line 554
    .line 555
    rem-int/lit8 v8, v8, 0x40

    .line 556
    .line 557
    add-int/lit8 v4, v4, 0x6

    .line 558
    .line 559
    rem-int/lit8 v4, v4, 0x40

    .line 560
    .line 561
    iget-object v1, v0, Ld10;->G:Lw51;

    .line 562
    .line 563
    invoke-virtual {v1, v3}, Lw51;->q(I)I

    .line 564
    .line 565
    .line 566
    move-result v3

    .line 567
    move/from16 v1, v17

    .line 568
    .line 569
    goto/16 :goto_1af

    .line 570
    .line 571
    :goto_23a
    iput-wide v6, v0, Ld10;->T:J

    .line 572
    .line 573
    const/4 v1, 0x0

    .line 574
    iput-object v1, v0, Ld10;->K:Lqr0;

    .line 575
    .line 576
    iget-object v3, v15, Lxv0;->d:Lm00;

    .line 577
    .line 578
    if-eqz v3, :cond_28a

    .line 579
    .line 580
    invoke-static/range {v18 .. v18}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 581
    .line 582
    .line 583
    move-result-object v4

    .line 584
    invoke-interface {v3, v0, v4}, Lm00;->f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 585
    .line 586
    .line 587
    iput-object v1, v0, Ld10;->K:Lqr0;

    .line 588
    .line 589
    iget-object v3, v0, Ld10;->G:Lw51;

    .line 590
    .line 591
    iget-object v4, v3, Lw51;->b:[I

    .line 592
    .line 593
    aget v4, v4, v29

    .line 594
    .line 595
    add-int/2addr v4, v5

    .line 596
    iget v6, v3, Lw51;->g:I

    .line 597
    .line 598
    if-lt v6, v5, :cond_25c

    .line 599
    .line 600
    if-gt v6, v4, :cond_25c

    .line 601
    .line 602
    move/from16 v7, v18

    .line 603
    .line 604
    goto :goto_25d

    .line 605
    :cond_25c
    const/4 v7, 0x0

    .line 606
    :goto_25d
    if-nez v7, :cond_278

    .line 607
    .line 608
    new-instance v7, Ljava/lang/StringBuilder;

    .line 609
    .line 610
    const-string v8, "Index "

    .line 611
    .line 612
    invoke-direct {v7, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 613
    .line 614
    .line 615
    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 616
    .line 617
    .line 618
    const-string v8, " is not a parent of "

    .line 619
    .line 620
    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 621
    .line 622
    .line 623
    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 624
    .line 625
    .line 626
    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 627
    .line 628
    .line 629
    move-result-object v6

    .line 630
    invoke-static {v6}, Lqj;->a(Ljava/lang/String;)V

    .line 631
    .line 632
    .line 633
    :cond_278
    iput v5, v3, Lw51;->i:I

    .line 634
    .line 635
    iput v4, v3, Lw51;->h:I

    .line 636
    .line 637
    const/4 v4, 0x0

    .line 638
    iput v4, v3, Lw51;->l:I

    .line 639
    .line 640
    iput v4, v3, Lw51;->m:I

    .line 641
    .line 642
    move/from16 v19, v2

    .line 643
    .line 644
    move v1, v4

    .line 645
    move/from16 v3, v17

    .line 646
    .line 647
    move/from16 v17, v18

    .line 648
    .line 649
    goto/16 :goto_31d

    .line 650
    .line 651
    :cond_28a
    const-string v0, "Invalid restart scope"

    .line 652
    .line 653
    invoke-static {v0}, Lod;->p(Ljava/lang/String;)V

    .line 654
    .line 655
    .line 656
    return-void

    .line 657
    :cond_290
    const/4 v1, 0x0

    .line 658
    iget-object v4, v0, Ld10;->E:Ljava/util/ArrayList;

    .line 659
    .line 660
    invoke-virtual {v4, v15}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 661
    .line 662
    .line 663
    iget-object v6, v0, Ld10;->g:Lpg0;

    .line 664
    .line 665
    invoke-virtual {v6}, Lpg0;->k()V

    .line 666
    .line 667
    .line 668
    iget-object v6, v15, Lxv0;->a:Lyj;

    .line 669
    .line 670
    if-eqz v6, :cond_30f

    .line 671
    .line 672
    iget-object v7, v15, Lxv0;->f:Lzj0;

    .line 673
    .line 674
    if-eqz v7, :cond_30f

    .line 675
    .line 676
    move/from16 v8, v18

    .line 677
    .line 678
    invoke-virtual {v15, v8}, Lxv0;->d(Z)V

    .line 679
    .line 680
    .line 681
    :try_start_2a8
    iget-object v8, v7, Lzj0;->b:[Ljava/lang/Object;

    .line 682
    .line 683
    iget-object v9, v7, Lzj0;->c:[I

    .line 684
    .line 685
    iget-object v7, v7, Lzj0;->a:[J

    .line 686
    .line 687
    array-length v12, v7

    .line 688
    add-int/lit8 v12, v12, -0x2

    .line 689
    .line 690
    move/from16 v19, v2

    .line 691
    .line 692
    if-ltz v12, :cond_2fa

    .line 693
    .line 694
    const/4 v13, 0x0

    .line 695
    :goto_2b6
    aget-wide v1, v7, v13

    .line 696
    .line 697
    move-object/from16 v36, v7

    .line 698
    .line 699
    move-object/from16 v35, v8

    .line 700
    .line 701
    not-long v7, v1

    .line 702
    shl-long v7, v7, v25

    .line 703
    .line 704
    and-long/2addr v7, v1

    .line 705
    and-long v7, v7, v26

    .line 706
    .line 707
    cmp-long v7, v7, v26

    .line 708
    .line 709
    if-eqz v7, :cond_2fc

    .line 710
    .line 711
    sub-int v7, v13, v12

    .line 712
    .line 713
    not-int v7, v7

    .line 714
    ushr-int/lit8 v7, v7, 0x1f

    .line 715
    .line 716
    const/16 v28, 0x8

    .line 717
    .line 718
    rsub-int/lit8 v7, v7, 0x8

    .line 719
    .line 720
    const/4 v8, 0x0

    .line 721
    :goto_2d0
    if-ge v8, v7, :cond_2f5

    .line 722
    .line 723
    and-long v37, v1, v23

    .line 724
    .line 725
    cmp-long v37, v37, v21

    .line 726
    .line 727
    if-gez v37, :cond_2eb

    .line 728
    .line 729
    shl-int/lit8 v37, v13, 0x3

    .line 730
    .line 731
    add-int v37, v37, v8

    .line 732
    .line 733
    move-wide/from16 v38, v1

    .line 734
    .line 735
    aget-object v1, v35, v37

    .line 736
    .line 737
    aget v2, v9, v37

    .line 738
    .line 739
    invoke-virtual {v6, v1}, Lyj;->y(Ljava/lang/Object;)V
    :try_end_2e5
    .catchall {:try_start_2a8 .. :try_end_2e5} :catchall_2e8

    .line 740
    .line 741
    .line 742
    :goto_2e5
    const/16 v1, 0x8

    .line 743
    .line 744
    goto :goto_2ee

    .line 745
    :catchall_2e8
    move-exception v0

    .line 746
    const/4 v1, 0x0

    .line 747
    goto :goto_30b

    .line 748
    :cond_2eb
    move-wide/from16 v38, v1

    .line 749
    .line 750
    goto :goto_2e5

    .line 751
    :goto_2ee
    shr-long v37, v38, v1

    .line 752
    .line 753
    add-int/lit8 v8, v8, 0x1

    .line 754
    .line 755
    move-wide/from16 v1, v37

    .line 756
    .line 757
    goto :goto_2d0

    .line 758
    :cond_2f5
    const/16 v1, 0x8

    .line 759
    .line 760
    if-ne v7, v1, :cond_2fa

    .line 761
    .line 762
    goto :goto_2fe

    .line 763
    :cond_2fa
    const/4 v1, 0x0

    .line 764
    goto :goto_307

    .line 765
    :cond_2fc
    const/16 v1, 0x8

    .line 766
    .line 767
    :goto_2fe
    if-eq v13, v12, :cond_2fa

    .line 768
    .line 769
    add-int/lit8 v13, v13, 0x1

    .line 770
    .line 771
    move-object/from16 v8, v35

    .line 772
    .line 773
    move-object/from16 v7, v36

    .line 774
    .line 775
    goto :goto_2b6

    .line 776
    :goto_307
    invoke-virtual {v15, v1}, Lxv0;->d(Z)V

    .line 777
    .line 778
    .line 779
    goto :goto_312

    .line 780
    :goto_30b
    invoke-virtual {v15, v1}, Lxv0;->d(Z)V

    .line 781
    .line 782
    .line 783
    throw v0

    .line 784
    :cond_30f
    move/from16 v19, v2

    .line 785
    .line 786
    const/4 v1, 0x0

    .line 787
    :goto_312
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    .line 788
    .line 789
    .line 790
    move-result v2

    .line 791
    const/16 v18, 0x1

    .line 792
    .line 793
    add-int/lit8 v2, v2, -0x1

    .line 794
    .line 795
    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 796
    .line 797
    .line 798
    :goto_31d
    iget-object v2, v0, Ld10;->G:Lw51;

    .line 799
    .line 800
    iget v2, v2, Lw51;->g:I

    .line 801
    .line 802
    invoke-static {v2, v14}, Lvn;->s(ILjava/util/List;)I

    .line 803
    .line 804
    .line 805
    move-result v2

    .line 806
    if-gez v2, :cond_32a

    .line 807
    .line 808
    add-int/lit8 v2, v2, 0x1

    .line 809
    .line 810
    neg-int v2, v2

    .line 811
    :cond_32a
    invoke-virtual {v14}, Ljava/util/ArrayList;->size()I

    .line 812
    .line 813
    .line 814
    move-result v4

    .line 815
    if-ge v2, v4, :cond_33e

    .line 816
    .line 817
    invoke-virtual {v14, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 818
    .line 819
    .line 820
    move-result-object v2

    .line 821
    check-cast v2, Lu70;

    .line 822
    .line 823
    iget v4, v2, Lu70;->b:I

    .line 824
    .line 825
    move/from16 v6, v34

    .line 826
    .line 827
    if-ge v4, v6, :cond_340

    .line 828
    .line 829
    move-object v4, v2

    .line 830
    goto :goto_341

    .line 831
    :cond_33e
    move/from16 v6, v34

    .line 832
    .line 833
    :cond_340
    const/4 v4, 0x0

    .line 834
    :goto_341
    move/from16 v2, v19

    .line 835
    .line 836
    move-object/from16 v1, v20

    .line 837
    .line 838
    move/from16 v7, v29

    .line 839
    .line 840
    move/from16 v9, v30

    .line 841
    .line 842
    move/from16 v12, v32

    .line 843
    .line 844
    move/from16 v13, v33

    .line 845
    .line 846
    goto/16 :goto_44

    .line 847
    .line 848
    :cond_34f
    move/from16 v19, v2

    .line 849
    .line 850
    move/from16 v30, v9

    .line 851
    .line 852
    move/from16 v32, v12

    .line 853
    .line 854
    move/from16 v33, v13

    .line 855
    .line 856
    if-eqz v17, :cond_372

    .line 857
    .line 858
    invoke-virtual {v0, v3, v5, v5}, Ld10;->K(III)V

    .line 859
    .line 860
    .line 861
    iget-object v1, v0, Ld10;->G:Lw51;

    .line 862
    .line 863
    invoke-virtual {v1}, Lw51;->t()V

    .line 864
    .line 865
    .line 866
    invoke-virtual {v0, v5}, Ld10;->i0(I)I

    .line 867
    .line 868
    .line 869
    move-result v1

    .line 870
    add-int v9, v30, v1

    .line 871
    .line 872
    iput v9, v0, Ld10;->k:I

    .line 873
    .line 874
    add-int v12, v32, v1

    .line 875
    .line 876
    iput v12, v0, Ld10;->l:I

    .line 877
    .line 878
    move/from16 v1, v33

    .line 879
    .line 880
    iput v1, v0, Ld10;->m:I

    .line 881
    .line 882
    goto :goto_375

    .line 883
    :cond_372
    invoke-virtual {v0}, Ld10;->Q()V

    .line 884
    .line 885
    .line 886
    :goto_375
    iput-wide v10, v0, Ld10;->T:J

    .line 887
    .line 888
    move/from16 v1, v19

    .line 889
    .line 890
    iput-boolean v1, v0, Ld10;->F:Z

    .line 891
    .line 892
    return-void
.end method

.method public final I()V
    .registers 9

    .line 1
    iget-object v0, p0, Ld10;->G:Lw51;

    .line 2
    .line 3
    iget v0, v0, Lw51;->g:I

    .line 4
    .line 5
    invoke-virtual {p0, v0}, Ld10;->M(I)V

    .line 6
    .line 7
    .line 8
    iget-object p0, p0, Ld10;->M:Lpj;

    .line 9
    .line 10
    const/4 v0, 0x0

    .line 11
    invoke-virtual {p0, v0}, Lpj;->d(Z)V

    .line 12
    .line 13
    .line 14
    iget-object v1, p0, Lpj;->d:Lw60;

    .line 15
    .line 16
    iget-object v2, p0, Lpj;->a:Ld10;

    .line 17
    .line 18
    iget-object v3, v2, Ld10;->G:Lw51;

    .line 19
    .line 20
    iget v4, v3, Lw51;->c:I

    .line 21
    .line 22
    if-lez v4, :cond_51

    .line 23
    .line 24
    iget v4, v3, Lw51;->i:I

    .line 25
    .line 26
    const/4 v5, -0x2

    .line 27
    invoke-virtual {v1, v5}, Lw60;->a(I)I

    .line 28
    .line 29
    .line 30
    move-result v5

    .line 31
    if-eq v5, v4, :cond_51

    .line 32
    .line 33
    iget-boolean v5, p0, Lpj;->c:Z

    .line 34
    .line 35
    const/4 v6, 0x1

    .line 36
    if-nez v5, :cond_37

    .line 37
    .line 38
    iget-boolean v5, p0, Lpj;->e:Z

    .line 39
    .line 40
    if-eqz v5, :cond_37

    .line 41
    .line 42
    invoke-virtual {p0, v0}, Lpj;->d(Z)V

    .line 43
    .line 44
    .line 45
    iget-object v5, p0, Lpj;->b:Lve;

    .line 46
    .line 47
    iget-object v5, v5, Lve;->F:Lzo0;

    .line 48
    .line 49
    sget-object v7, Leo0;->c:Leo0;

    .line 50
    .line 51
    invoke-virtual {v5, v7}, Lzo0;->C(Lxo0;)V

    .line 52
    .line 53
    .line 54
    iput-boolean v6, p0, Lpj;->c:Z

    .line 55
    .line 56
    :cond_37
    if-lez v4, :cond_51

    .line 57
    .line 58
    invoke-virtual {v3, v4}, Lw51;->a(I)Ly00;

    .line 59
    .line 60
    .line 61
    move-result-object v3

    .line 62
    invoke-virtual {v1, v4}, Lw60;->c(I)V

    .line 63
    .line 64
    .line 65
    invoke-virtual {p0, v0}, Lpj;->d(Z)V

    .line 66
    .line 67
    .line 68
    iget-object v1, p0, Lpj;->b:Lve;

    .line 69
    .line 70
    iget-object v1, v1, Lve;->F:Lzo0;

    .line 71
    .line 72
    sget-object v4, Ldo0;->c:Ldo0;

    .line 73
    .line 74
    invoke-virtual {v1, v4}, Lzo0;->C(Lxo0;)V

    .line 75
    .line 76
    .line 77
    invoke-static {v1, v0, v3}, Ldd0;->v(Lzo0;ILjava/lang/Object;)V

    .line 78
    .line 79
    .line 80
    iput-boolean v6, p0, Lpj;->c:Z

    .line 81
    .line 82
    :cond_51
    iget-object v0, p0, Lpj;->b:Lve;

    .line 83
    .line 84
    iget-object v0, v0, Lve;->F:Lzo0;

    .line 85
    .line 86
    sget-object v1, Lmo0;->c:Lmo0;

    .line 87
    .line 88
    invoke-virtual {v0, v1}, Lzo0;->C(Lxo0;)V

    .line 89
    .line 90
    .line 91
    iget v0, p0, Lpj;->f:I

    .line 92
    .line 93
    iget-object v1, v2, Ld10;->G:Lw51;

    .line 94
    .line 95
    iget-object v2, v1, Lw51;->b:[I

    .line 96
    .line 97
    iget v1, v1, Lw51;->g:I

    .line 98
    .line 99
    mul-int/lit8 v1, v1, 0x5

    .line 100
    .line 101
    add-int/lit8 v1, v1, 0x3

    .line 102
    .line 103
    aget v1, v2, v1

    .line 104
    .line 105
    add-int/2addr v1, v0

    .line 106
    iput v1, p0, Lpj;->f:I

    .line 107
    .line 108
    return-void
.end method

.method public final J(Lqr0;)V
    .registers 3

    .line 1
    iget-object v0, p0, Ld10;->v:Lsj0;

    .line 2
    .line 3
    if-nez v0, :cond_b

    .line 4
    .line 5
    new-instance v0, Lsj0;

    .line 6
    .line 7
    invoke-direct {v0}, Lsj0;-><init>()V

    .line 8
    .line 9
    .line 10
    iput-object v0, p0, Ld10;->v:Lsj0;

    .line 11
    .line 12
    :cond_b
    iget-object p0, p0, Ld10;->G:Lw51;

    .line 13
    .line 14
    iget p0, p0, Lw51;->g:I

    .line 15
    .line 16
    invoke-virtual {v0, p0, p1}, Lsj0;->h(ILjava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    return-void
.end method

.method public final K(III)V
    .registers 10

    .line 1
    iget-object v0, p0, Ld10;->G:Lw51;

    .line 2
    .line 3
    if-ne p1, p2, :cond_5

    .line 4
    .line 5
    goto :goto_1a

    .line 6
    :cond_5
    if-eq p1, p3, :cond_6b

    .line 7
    .line 8
    if-ne p2, p3, :cond_b

    .line 9
    .line 10
    goto/16 :goto_6b

    .line 11
    .line 12
    :cond_b
    invoke-virtual {v0, p1}, Lw51;->q(I)I

    .line 13
    .line 14
    .line 15
    move-result v1

    .line 16
    if-ne v1, p2, :cond_14

    .line 17
    .line 18
    move p3, p2

    .line 19
    goto/16 :goto_6b

    .line 20
    .line 21
    :cond_14
    invoke-virtual {v0, p2}, Lw51;->q(I)I

    .line 22
    .line 23
    .line 24
    move-result v1

    .line 25
    if-ne v1, p1, :cond_1c

    .line 26
    .line 27
    :goto_1a
    move p3, p1

    .line 28
    goto :goto_6b

    .line 29
    :cond_1c
    invoke-virtual {v0, p1}, Lw51;->q(I)I

    .line 30
    .line 31
    .line 32
    move-result v1

    .line 33
    invoke-virtual {v0, p2}, Lw51;->q(I)I

    .line 34
    .line 35
    .line 36
    move-result v2

    .line 37
    if-ne v1, v2, :cond_2b

    .line 38
    .line 39
    invoke-virtual {v0, p1}, Lw51;->q(I)I

    .line 40
    .line 41
    .line 42
    move-result p3

    .line 43
    goto :goto_6b

    .line 44
    :cond_2b
    const/4 v1, 0x0

    .line 45
    move v2, p1

    .line 46
    move v3, v1

    .line 47
    :goto_2e
    if-lez v2, :cond_39

    .line 48
    .line 49
    if-eq v2, p3, :cond_39

    .line 50
    .line 51
    invoke-virtual {v0, v2}, Lw51;->q(I)I

    .line 52
    .line 53
    .line 54
    move-result v2

    .line 55
    add-int/lit8 v3, v3, 0x1

    .line 56
    .line 57
    goto :goto_2e

    .line 58
    :cond_39
    move v2, p2

    .line 59
    move v4, v1

    .line 60
    :goto_3b
    if-lez v2, :cond_46

    .line 61
    .line 62
    if-eq v2, p3, :cond_46

    .line 63
    .line 64
    invoke-virtual {v0, v2}, Lw51;->q(I)I

    .line 65
    .line 66
    .line 67
    move-result v2

    .line 68
    add-int/lit8 v4, v4, 0x1

    .line 69
    .line 70
    goto :goto_3b

    .line 71
    :cond_46
    sub-int p3, v3, v4

    .line 72
    .line 73
    move v5, p1

    .line 74
    move v2, v1

    .line 75
    :goto_4a
    if-ge v2, p3, :cond_53

    .line 76
    .line 77
    invoke-virtual {v0, v5}, Lw51;->q(I)I

    .line 78
    .line 79
    .line 80
    move-result v5

    .line 81
    add-int/lit8 v2, v2, 0x1

    .line 82
    .line 83
    goto :goto_4a

    .line 84
    :cond_53
    sub-int/2addr v4, v3

    .line 85
    move p3, p2

    .line 86
    :goto_55
    if-ge v1, v4, :cond_5e

    .line 87
    .line 88
    invoke-virtual {v0, p3}, Lw51;->q(I)I

    .line 89
    .line 90
    .line 91
    move-result p3

    .line 92
    add-int/lit8 v1, v1, 0x1

    .line 93
    .line 94
    goto :goto_55

    .line 95
    :cond_5e
    move v1, p3

    .line 96
    move p3, v5

    .line 97
    :goto_60
    if-eq p3, v1, :cond_6b

    .line 98
    .line 99
    invoke-virtual {v0, p3}, Lw51;->q(I)I

    .line 100
    .line 101
    .line 102
    move-result p3

    .line 103
    invoke-virtual {v0, v1}, Lw51;->q(I)I

    .line 104
    .line 105
    .line 106
    move-result v1

    .line 107
    goto :goto_60

    .line 108
    :cond_6b
    :goto_6b
    if-lez p1, :cond_7f

    .line 109
    .line 110
    if-eq p1, p3, :cond_7f

    .line 111
    .line 112
    invoke-virtual {v0, p1}, Lw51;->l(I)Z

    .line 113
    .line 114
    .line 115
    move-result v1

    .line 116
    if-eqz v1, :cond_7a

    .line 117
    .line 118
    iget-object v1, p0, Ld10;->M:Lpj;

    .line 119
    .line 120
    invoke-virtual {v1}, Lpj;->a()V

    .line 121
    .line 122
    .line 123
    :cond_7a
    invoke-virtual {v0, p1}, Lw51;->q(I)I

    .line 124
    .line 125
    .line 126
    move-result p1

    .line 127
    goto :goto_6b

    .line 128
    :cond_7f
    invoke-virtual {p0, p2, p3}, Ld10;->o(II)V

    .line 129
    .line 130
    .line 131
    return-void
.end method

.method public final L()Ljava/lang/Object;
    .registers 3

    .line 1
    iget-boolean v0, p0, Ld10;->S:Z

    .line 2
    .line 3
    sget-object v1, Loj;->a:Lnq0;

    .line 4
    .line 5
    if-eqz v0, :cond_10

    .line 6
    .line 7
    iget-boolean p0, p0, Ld10;->r:Z

    .line 8
    .line 9
    if-eqz p0, :cond_1e

    .line 10
    .line 11
    const-string p0, "A call to createNode(), emitNode() or useNode() expected"

    .line 12
    .line 13
    invoke-static {p0}, Lqj;->a(Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    return-object v1

    .line 17
    :cond_10
    iget-object v0, p0, Ld10;->G:Lw51;

    .line 18
    .line 19
    invoke-virtual {v0}, Lw51;->m()Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    iget-boolean p0, p0, Ld10;->y:Z

    .line 24
    .line 25
    if-eqz p0, :cond_1f

    .line 26
    .line 27
    instance-of p0, v0, Ltx0;

    .line 28
    .line 29
    if-nez p0, :cond_1f

    .line 30
    .line 31
    :cond_1e
    return-object v1

    .line 32
    :cond_1f
    instance-of p0, v0, Lxw0;

    .line 33
    .line 34
    if-eqz p0, :cond_28

    .line 35
    .line 36
    check-cast v0, Lxw0;

    .line 37
    .line 38
    iget-object p0, v0, Lxw0;->a:Lww0;

    .line 39
    .line 40
    return-object p0

    .line 41
    :cond_28
    return-object v0
.end method

.method public final M(I)V
    .registers 6

    .line 1
    iget-object v0, p0, Ld10;->G:Lw51;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Lw51;->l(I)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    iget-object v1, p0, Ld10;->M:Lpj;

    .line 8
    .line 9
    if-eqz v0, :cond_1b

    .line 10
    .line 11
    invoke-virtual {v1}, Lpj;->c()V

    .line 12
    .line 13
    .line 14
    iget-object v2, p0, Ld10;->G:Lw51;

    .line 15
    .line 16
    invoke-virtual {v2, p1}, Lw51;->n(I)Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object v2

    .line 20
    invoke-virtual {v1}, Lpj;->c()V

    .line 21
    .line 22
    .line 23
    iget-object v3, v1, Lpj;->h:Ljava/util/ArrayList;

    .line 24
    .line 25
    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 26
    .line 27
    .line 28
    :cond_1b
    const/4 v2, 0x0

    .line 29
    invoke-static {p0, p1, v0, v2}, Ld10;->N(Ld10;IZI)I

    .line 30
    .line 31
    .line 32
    invoke-virtual {v1}, Lpj;->c()V

    .line 33
    .line 34
    .line 35
    if-eqz v0, :cond_27

    .line 36
    .line 37
    invoke-virtual {v1}, Lpj;->a()V

    .line 38
    .line 39
    .line 40
    :cond_27
    return-void
.end method

.method public final O(IZ)Z
    .registers 6

    .line 1
    const/4 v0, 0x1

    .line 2
    and-int/2addr p1, v0

    .line 3
    const/4 v1, 0x0

    .line 4
    if-nez p1, :cond_4b

    .line 5
    .line 6
    iget-boolean p1, p0, Ld10;->S:Z

    .line 7
    .line 8
    if-nez p1, :cond_d

    .line 9
    .line 10
    iget-boolean p1, p0, Ld10;->y:Z

    .line 11
    .line 12
    if-eqz p1, :cond_4b

    .line 13
    .line 14
    :cond_d
    iget-object p1, p0, Ld10;->P:Ll51;

    .line 15
    .line 16
    if-nez p1, :cond_12

    .line 17
    .line 18
    goto :goto_55

    .line 19
    :cond_12
    invoke-virtual {p0}, Ld10;->x()Lxv0;

    .line 20
    .line 21
    .line 22
    move-result-object p2

    .line 23
    if-nez p2, :cond_19

    .line 24
    .line 25
    goto :goto_55

    .line 26
    :cond_19
    invoke-interface {p1}, Ll51;->a()Z

    .line 27
    .line 28
    .line 29
    move-result p1

    .line 30
    if-eqz p1, :cond_55

    .line 31
    .line 32
    iget p1, p2, Lxv0;->b:I

    .line 33
    .line 34
    and-int/lit16 v2, p1, 0x200

    .line 35
    .line 36
    if-eqz v2, :cond_26

    .line 37
    .line 38
    return v0

    .line 39
    :cond_26
    or-int/lit8 v0, p1, 0x1

    .line 40
    .line 41
    iput v0, p2, Lxv0;->b:I

    .line 42
    .line 43
    iget-boolean v2, p0, Ld10;->y:Z

    .line 44
    .line 45
    if-eqz v2, :cond_31

    .line 46
    .line 47
    or-int/lit16 p1, p1, 0x81

    .line 48
    .line 49
    goto :goto_33

    .line 50
    :cond_31
    and-int/lit16 p1, v0, -0x81

    .line 51
    .line 52
    :goto_33
    or-int/lit16 p1, p1, 0x100

    .line 53
    .line 54
    iput p1, p2, Lxv0;->b:I

    .line 55
    .line 56
    iget-object p1, p0, Ld10;->M:Lpj;

    .line 57
    .line 58
    iget-object p1, p1, Lpj;->b:Lve;

    .line 59
    .line 60
    iget-object p1, p1, Lve;->F:Lzo0;

    .line 61
    .line 62
    sget-object v0, Llo0;->c:Llo0;

    .line 63
    .line 64
    invoke-virtual {p1, v0}, Lzo0;->C(Lxo0;)V

    .line 65
    .line 66
    .line 67
    invoke-static {p1, v1, p2}, Ldd0;->v(Lzo0;ILjava/lang/Object;)V

    .line 68
    .line 69
    .line 70
    iget-object p0, p0, Ld10;->b:Lsj;

    .line 71
    .line 72
    invoke-virtual {p0, p2}, Lsj;->q(Lxv0;)V

    .line 73
    .line 74
    .line 75
    return v1

    .line 76
    :cond_4b
    if-nez p2, :cond_55

    .line 77
    .line 78
    invoke-virtual {p0}, Ld10;->A()Z

    .line 79
    .line 80
    .line 81
    move-result p0

    .line 82
    if-nez p0, :cond_54

    .line 83
    .line 84
    goto :goto_55

    .line 85
    :cond_54
    return v1

    .line 86
    :cond_55
    :goto_55
    return v0
.end method

.method public final P()V
    .registers 16

    .line 1
    iget-object v0, p0, Ld10;->s:Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_14

    .line 8
    .line 9
    iget v0, p0, Ld10;->l:I

    .line 10
    .line 11
    iget-object v1, p0, Ld10;->G:Lw51;

    .line 12
    .line 13
    invoke-virtual {v1}, Lw51;->s()I

    .line 14
    .line 15
    .line 16
    move-result v1

    .line 17
    add-int/2addr v1, v0

    .line 18
    iput v1, p0, Ld10;->l:I

    .line 19
    .line 20
    return-void

    .line 21
    :cond_14
    iget-object v0, p0, Ld10;->G:Lw51;

    .line 22
    .line 23
    invoke-virtual {v0}, Lw51;->g()I

    .line 24
    .line 25
    .line 26
    move-result v1

    .line 27
    iget-object v2, v0, Lw51;->b:[I

    .line 28
    .line 29
    iget v3, v0, Lw51;->g:I

    .line 30
    .line 31
    iget v4, v0, Lw51;->h:I

    .line 32
    .line 33
    const/4 v5, 0x0

    .line 34
    if-ge v3, v4, :cond_28

    .line 35
    .line 36
    invoke-virtual {v0, v2, v3}, Lw51;->p([II)Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object v3

    .line 40
    goto :goto_29

    .line 41
    :cond_28
    move-object v3, v5

    .line 42
    :goto_29
    invoke-virtual {v0}, Lw51;->f()Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    move-result-object v4

    .line 46
    iget v6, p0, Ld10;->m:I

    .line 47
    .line 48
    sget-object v7, Loj;->a:Lnq0;

    .line 49
    .line 50
    const/16 v8, 0xcf

    .line 51
    .line 52
    const/4 v9, 0x3

    .line 53
    if-nez v3, :cond_66

    .line 54
    .line 55
    if-eqz v4, :cond_55

    .line 56
    .line 57
    if-ne v1, v8, :cond_55

    .line 58
    .line 59
    invoke-virtual {v4, v7}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 60
    .line 61
    .line 62
    move-result v10

    .line 63
    if-nez v10, :cond_55

    .line 64
    .line 65
    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    .line 66
    .line 67
    .line 68
    move-result v10

    .line 69
    iget-wide v11, p0, Ld10;->T:J

    .line 70
    .line 71
    invoke-static {v11, v12, v9}, Ljava/lang/Long;->rotateLeft(JI)J

    .line 72
    .line 73
    .line 74
    move-result-wide v11

    .line 75
    int-to-long v13, v10

    .line 76
    xor-long/2addr v11, v13

    .line 77
    invoke-static {v11, v12, v9}, Ljava/lang/Long;->rotateLeft(JI)J

    .line 78
    .line 79
    .line 80
    move-result-wide v10

    .line 81
    int-to-long v12, v6

    .line 82
    xor-long/2addr v10, v12

    .line 83
    iput-wide v10, p0, Ld10;->T:J

    .line 84
    .line 85
    goto :goto_83

    .line 86
    :cond_55
    iget-wide v10, p0, Ld10;->T:J

    .line 87
    .line 88
    invoke-static {v10, v11, v9}, Ljava/lang/Long;->rotateLeft(JI)J

    .line 89
    .line 90
    .line 91
    move-result-wide v10

    .line 92
    int-to-long v12, v1

    .line 93
    xor-long/2addr v10, v12

    .line 94
    invoke-static {v10, v11, v9}, Ljava/lang/Long;->rotateLeft(JI)J

    .line 95
    .line 96
    .line 97
    move-result-wide v10

    .line 98
    int-to-long v12, v6

    .line 99
    xor-long/2addr v10, v12

    .line 100
    :goto_63
    iput-wide v10, p0, Ld10;->T:J

    .line 101
    .line 102
    goto :goto_83

    .line 103
    :cond_66
    instance-of v10, v3, Ljava/lang/Enum;

    .line 104
    .line 105
    if-eqz v10, :cond_7e

    .line 106
    .line 107
    move-object v10, v3

    .line 108
    check-cast v10, Ljava/lang/Enum;

    .line 109
    .line 110
    invoke-virtual {v10}, Ljava/lang/Enum;->ordinal()I

    .line 111
    .line 112
    .line 113
    move-result v10

    .line 114
    :goto_71
    iget-wide v11, p0, Ld10;->T:J

    .line 115
    .line 116
    invoke-static {v11, v12, v9}, Ljava/lang/Long;->rotateLeft(JI)J

    .line 117
    .line 118
    .line 119
    move-result-wide v11

    .line 120
    int-to-long v13, v10

    .line 121
    xor-long/2addr v11, v13

    .line 122
    invoke-static {v11, v12, v9}, Ljava/lang/Long;->rotateLeft(JI)J

    .line 123
    .line 124
    .line 125
    move-result-wide v10

    .line 126
    goto :goto_63

    .line 127
    :cond_7e
    invoke-virtual {v3}, Ljava/lang/Object;->hashCode()I

    .line 128
    .line 129
    .line 130
    move-result v10

    .line 131
    goto :goto_71

    .line 132
    :goto_83
    iget v10, v0, Lw51;->g:I

    .line 133
    .line 134
    mul-int/lit8 v10, v10, 0x5

    .line 135
    .line 136
    const/4 v11, 0x1

    .line 137
    add-int/2addr v10, v11

    .line 138
    aget v2, v2, v10

    .line 139
    .line 140
    const/high16 v10, 0x40000000  # 2.0f

    .line 141
    .line 142
    and-int/2addr v2, v10

    .line 143
    if-eqz v2, :cond_91

    .line 144
    .line 145
    goto :goto_92

    .line 146
    :cond_91
    const/4 v11, 0x0

    .line 147
    :goto_92
    invoke-virtual {p0, v5, v11}, Ld10;->V(Ljava/lang/Object;Z)V

    .line 148
    .line 149
    .line 150
    invoke-virtual {p0}, Ld10;->H()V

    .line 151
    .line 152
    .line 153
    invoke-virtual {v0}, Lw51;->e()V

    .line 154
    .line 155
    .line 156
    if-nez v3, :cond_cd

    .line 157
    .line 158
    if-eqz v4, :cond_bc

    .line 159
    .line 160
    if-ne v1, v8, :cond_bc

    .line 161
    .line 162
    invoke-virtual {v4, v7}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 163
    .line 164
    .line 165
    move-result v0

    .line 166
    if-nez v0, :cond_bc

    .line 167
    .line 168
    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    .line 169
    .line 170
    .line 171
    move-result v0

    .line 172
    iget-wide v1, p0, Ld10;->T:J

    .line 173
    .line 174
    int-to-long v3, v6

    .line 175
    xor-long/2addr v1, v3

    .line 176
    invoke-static {v1, v2, v9}, Ljava/lang/Long;->rotateRight(JI)J

    .line 177
    .line 178
    .line 179
    move-result-wide v1

    .line 180
    int-to-long v3, v0

    .line 181
    xor-long/2addr v1, v3

    .line 182
    invoke-static {v1, v2, v9}, Ljava/lang/Long;->rotateRight(JI)J

    .line 183
    .line 184
    .line 185
    move-result-wide v0

    .line 186
    iput-wide v0, p0, Ld10;->T:J

    .line 187
    .line 188
    return-void

    .line 189
    :cond_bc
    iget-wide v2, p0, Ld10;->T:J

    .line 190
    .line 191
    int-to-long v4, v6

    .line 192
    xor-long/2addr v2, v4

    .line 193
    invoke-static {v2, v3, v9}, Ljava/lang/Long;->rotateRight(JI)J

    .line 194
    .line 195
    .line 196
    move-result-wide v2

    .line 197
    int-to-long v0, v1

    .line 198
    xor-long/2addr v0, v2

    .line 199
    invoke-static {v0, v1, v9}, Ljava/lang/Long;->rotateRight(JI)J

    .line 200
    .line 201
    .line 202
    move-result-wide v0

    .line 203
    iput-wide v0, p0, Ld10;->T:J

    .line 204
    .line 205
    return-void

    .line 206
    :cond_cd
    instance-of v0, v3, Ljava/lang/Enum;

    .line 207
    .line 208
    if-eqz v0, :cond_e6

    .line 209
    .line 210
    check-cast v3, Ljava/lang/Enum;

    .line 211
    .line 212
    invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I

    .line 213
    .line 214
    .line 215
    move-result v0

    .line 216
    iget-wide v1, p0, Ld10;->T:J

    .line 217
    .line 218
    invoke-static {v1, v2, v9}, Ljava/lang/Long;->rotateRight(JI)J

    .line 219
    .line 220
    .line 221
    move-result-wide v1

    .line 222
    int-to-long v3, v0

    .line 223
    xor-long/2addr v1, v3

    .line 224
    invoke-static {v1, v2, v9}, Ljava/lang/Long;->rotateRight(JI)J

    .line 225
    .line 226
    .line 227
    move-result-wide v0

    .line 228
    iput-wide v0, p0, Ld10;->T:J

    .line 229
    .line 230
    return-void

    .line 231
    :cond_e6
    invoke-virtual {v3}, Ljava/lang/Object;->hashCode()I

    .line 232
    .line 233
    .line 234
    move-result v0

    .line 235
    iget-wide v1, p0, Ld10;->T:J

    .line 236
    .line 237
    invoke-static {v1, v2, v9}, Ljava/lang/Long;->rotateRight(JI)J

    .line 238
    .line 239
    .line 240
    move-result-wide v1

    .line 241
    int-to-long v3, v0

    .line 242
    xor-long/2addr v1, v3

    .line 243
    invoke-static {v1, v2, v9}, Ljava/lang/Long;->rotateRight(JI)J

    .line 244
    .line 245
    .line 246
    move-result-wide v0

    .line 247
    iput-wide v0, p0, Ld10;->T:J

    .line 248
    .line 249
    return-void
.end method

.method public final Q()V
    .registers 4

    .line 1
    iget-object v0, p0, Ld10;->G:Lw51;

    .line 2
    .line 3
    iget v1, v0, Lw51;->i:I

    .line 4
    .line 5
    if-ltz v1, :cond_13

    .line 6
    .line 7
    iget-object v2, v0, Lw51;->b:[I

    .line 8
    .line 9
    mul-int/lit8 v1, v1, 0x5

    .line 10
    .line 11
    add-int/lit8 v1, v1, 0x1

    .line 12
    .line 13
    aget v1, v2, v1

    .line 14
    .line 15
    const v2, 0x3ffffff

    .line 16
    .line 17
    .line 18
    and-int/2addr v1, v2

    .line 19
    goto :goto_14

    .line 20
    :cond_13
    const/4 v1, 0x0

    .line 21
    :goto_14
    iput v1, p0, Ld10;->l:I

    .line 22
    .line 23
    invoke-virtual {v0}, Lw51;->t()V

    .line 24
    .line 25
    .line 26
    return-void
.end method

.method public final R()V
    .registers 4

    .line 1
    iget v0, p0, Ld10;->l:I

    .line 2
    .line 3
    if-nez v0, :cond_5

    .line 4
    .line 5
    goto :goto_a

    .line 6
    :cond_5
    const-string v0, "No nodes can be emitted before calling skipAndEndGroup"

    .line 7
    .line 8
    invoke-static {v0}, Lqj;->a(Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    :goto_a
    iget-boolean v0, p0, Ld10;->S:Z

    .line 12
    .line 13
    if-nez v0, :cond_2e

    .line 14
    .line 15
    invoke-virtual {p0}, Ld10;->x()Lxv0;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    if-eqz v0, :cond_1f

    .line 20
    .line 21
    iget v1, v0, Lxv0;->b:I

    .line 22
    .line 23
    and-int/lit16 v2, v1, 0x80

    .line 24
    .line 25
    if-eqz v2, :cond_1b

    .line 26
    .line 27
    goto :goto_1f

    .line 28
    :cond_1b
    or-int/lit8 v1, v1, 0x10

    .line 29
    .line 30
    iput v1, v0, Lxv0;->b:I

    .line 31
    .line 32
    :cond_1f
    :goto_1f
    iget-object v0, p0, Ld10;->s:Ljava/util/ArrayList;

    .line 33
    .line 34
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-eqz v0, :cond_2b

    .line 39
    .line 40
    invoke-virtual {p0}, Ld10;->Q()V

    .line 41
    .line 42
    .line 43
    return-void

    .line 44
    :cond_2b
    invoke-virtual {p0}, Ld10;->H()V

    .line 45
    .line 46
    .line 47
    :cond_2e
    return-void
.end method

.method public final S(IILjava/lang/Object;Ljava/lang/Object;)V
    .registers 31

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move/from16 v1, p1

    .line 4
    .line 5
    move/from16 v2, p2

    .line 6
    .line 7
    move-object/from16 v3, p3

    .line 8
    .line 9
    move-object/from16 v4, p4

    .line 10
    .line 11
    const/4 v5, -0x1

    .line 12
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 13
    .line 14
    .line 15
    move-result-object v6

    .line 16
    iget-boolean v7, v0, Ld10;->r:Z

    .line 17
    .line 18
    if-eqz v7, :cond_18

    .line 19
    .line 20
    const-string v7, "A call to createNode(), emitNode() or useNode() expected"

    .line 21
    .line 22
    invoke-static {v7}, Lqj;->a(Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    :cond_18
    iget v7, v0, Ld10;->m:I

    .line 26
    .line 27
    sget-object v8, Loj;->a:Lnq0;

    .line 28
    .line 29
    const/4 v9, 0x3

    .line 30
    if-nez v3, :cond_51

    .line 31
    .line 32
    if-eqz v4, :cond_40

    .line 33
    .line 34
    const/16 v10, 0xcf

    .line 35
    .line 36
    if-ne v1, v10, :cond_40

    .line 37
    .line 38
    invoke-virtual {v4, v8}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 39
    .line 40
    .line 41
    move-result v10

    .line 42
    if-nez v10, :cond_40

    .line 43
    .line 44
    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    .line 45
    .line 46
    .line 47
    move-result v10

    .line 48
    iget-wide v11, v0, Ld10;->T:J

    .line 49
    .line 50
    invoke-static {v11, v12, v9}, Ljava/lang/Long;->rotateLeft(JI)J

    .line 51
    .line 52
    .line 53
    move-result-wide v11

    .line 54
    int-to-long v13, v10

    .line 55
    xor-long/2addr v11, v13

    .line 56
    invoke-static {v11, v12, v9}, Ljava/lang/Long;->rotateLeft(JI)J

    .line 57
    .line 58
    .line 59
    move-result-wide v9

    .line 60
    int-to-long v11, v7

    .line 61
    xor-long/2addr v9, v11

    .line 62
    iput-wide v9, v0, Ld10;->T:J

    .line 63
    .line 64
    goto :goto_6e

    .line 65
    :cond_40
    iget-wide v10, v0, Ld10;->T:J

    .line 66
    .line 67
    invoke-static {v10, v11, v9}, Ljava/lang/Long;->rotateLeft(JI)J

    .line 68
    .line 69
    .line 70
    move-result-wide v10

    .line 71
    int-to-long v12, v1

    .line 72
    xor-long/2addr v10, v12

    .line 73
    invoke-static {v10, v11, v9}, Ljava/lang/Long;->rotateLeft(JI)J

    .line 74
    .line 75
    .line 76
    move-result-wide v9

    .line 77
    int-to-long v11, v7

    .line 78
    xor-long/2addr v9, v11

    .line 79
    :goto_4e
    iput-wide v9, v0, Ld10;->T:J

    .line 80
    .line 81
    goto :goto_6e

    .line 82
    :cond_51
    instance-of v7, v3, Ljava/lang/Enum;

    .line 83
    .line 84
    if-eqz v7, :cond_69

    .line 85
    .line 86
    move-object v7, v3

    .line 87
    check-cast v7, Ljava/lang/Enum;

    .line 88
    .line 89
    invoke-virtual {v7}, Ljava/lang/Enum;->ordinal()I

    .line 90
    .line 91
    .line 92
    move-result v7

    .line 93
    :goto_5c
    iget-wide v10, v0, Ld10;->T:J

    .line 94
    .line 95
    invoke-static {v10, v11, v9}, Ljava/lang/Long;->rotateLeft(JI)J

    .line 96
    .line 97
    .line 98
    move-result-wide v10

    .line 99
    int-to-long v12, v7

    .line 100
    xor-long/2addr v10, v12

    .line 101
    invoke-static {v10, v11, v9}, Ljava/lang/Long;->rotateLeft(JI)J

    .line 102
    .line 103
    .line 104
    move-result-wide v9

    .line 105
    goto :goto_4e

    .line 106
    :cond_69
    invoke-virtual {v3}, Ljava/lang/Object;->hashCode()I

    .line 107
    .line 108
    .line 109
    move-result v7

    .line 110
    goto :goto_5c

    .line 111
    :goto_6e
    const/4 v7, 0x1

    .line 112
    if-nez v3, :cond_76

    .line 113
    .line 114
    iget v9, v0, Ld10;->m:I

    .line 115
    .line 116
    add-int/2addr v9, v7

    .line 117
    iput v9, v0, Ld10;->m:I

    .line 118
    .line 119
    :cond_76
    const/4 v9, 0x0

    .line 120
    if-eqz v2, :cond_7b

    .line 121
    .line 122
    move v10, v7

    .line 123
    goto :goto_7c

    .line 124
    :cond_7b
    move v10, v9

    .line 125
    :goto_7c
    iget-boolean v11, v0, Ld10;->S:Z

    .line 126
    .line 127
    const/4 v12, -0x2

    .line 128
    const/4 v13, 0x0

    .line 129
    if-eqz v11, :cond_c4

    .line 130
    .line 131
    iget-object v2, v0, Ld10;->G:Lw51;

    .line 132
    .line 133
    iget v11, v2, Lw51;->k:I

    .line 134
    .line 135
    add-int/2addr v11, v7

    .line 136
    iput v11, v2, Lw51;->k:I

    .line 137
    .line 138
    iget-object v2, v0, Ld10;->I:La61;

    .line 139
    .line 140
    iget v11, v2, La61;->t:I

    .line 141
    .line 142
    if-eqz v10, :cond_93

    .line 143
    .line 144
    invoke-virtual {v2, v1, v8, v7, v8}, La61;->Q(ILjava/lang/Object;ZLjava/lang/Object;)V

    .line 145
    .line 146
    .line 147
    goto :goto_a2

    .line 148
    :cond_93
    if-eqz v4, :cond_9c

    .line 149
    .line 150
    if-nez v3, :cond_98

    .line 151
    .line 152
    move-object v3, v8

    .line 153
    :cond_98
    invoke-virtual {v2, v1, v3, v9, v4}, La61;->Q(ILjava/lang/Object;ZLjava/lang/Object;)V

    .line 154
    .line 155
    .line 156
    goto :goto_a2

    .line 157
    :cond_9c
    if-nez v3, :cond_9f

    .line 158
    .line 159
    move-object v3, v8

    .line 160
    :cond_9f
    invoke-virtual {v2, v1, v3, v9, v8}, La61;->Q(ILjava/lang/Object;ZLjava/lang/Object;)V

    .line 161
    .line 162
    .line 163
    :goto_a2
    iget-object v2, v0, Ld10;->j:Lg10;

    .line 164
    .line 165
    if-eqz v2, :cond_c0

    .line 166
    .line 167
    new-instance v3, Le90;

    .line 168
    .line 169
    sub-int/2addr v12, v11

    .line 170
    invoke-direct {v3, v6, v1, v12, v5}, Le90;-><init>(Ljava/lang/Object;III)V

    .line 171
    .line 172
    .line 173
    iget v1, v0, Ld10;->k:I

    .line 174
    .line 175
    iget v4, v2, Lg10;->b:I

    .line 176
    .line 177
    sub-int/2addr v1, v4

    .line 178
    iget-object v4, v2, Lg10;->e:Lsj0;

    .line 179
    .line 180
    new-instance v6, Lt20;

    .line 181
    .line 182
    invoke-direct {v6, v5, v1, v9}, Lt20;-><init>(III)V

    .line 183
    .line 184
    .line 185
    invoke-virtual {v4, v12, v6}, Lsj0;->h(ILjava/lang/Object;)V

    .line 186
    .line 187
    .line 188
    iget-object v1, v2, Lg10;->d:Ljava/util/ArrayList;

    .line 189
    .line 190
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 191
    .line 192
    .line 193
    :cond_c0
    invoke-virtual {v0, v10, v13}, Ld10;->u(ZLg10;)V

    .line 194
    .line 195
    .line 196
    return-void

    .line 197
    :cond_c4
    if-eq v2, v7, :cond_c7

    .line 198
    .line 199
    goto :goto_cd

    .line 200
    :cond_c7
    iget-boolean v2, v0, Ld10;->y:Z

    .line 201
    .line 202
    if-eqz v2, :cond_cd

    .line 203
    .line 204
    move v2, v7

    .line 205
    goto :goto_ce

    .line 206
    :cond_cd
    :goto_cd
    move v2, v9

    .line 207
    :goto_ce
    iget-object v11, v0, Ld10;->j:Lg10;

    .line 208
    .line 209
    if-nez v11, :cond_f5

    .line 210
    .line 211
    iget-object v11, v0, Ld10;->G:Lw51;

    .line 212
    .line 213
    invoke-virtual {v11}, Lw51;->g()I

    .line 214
    .line 215
    .line 216
    move-result v11

    .line 217
    if-nez v2, :cond_f8

    .line 218
    .line 219
    if-ne v11, v1, :cond_f8

    .line 220
    .line 221
    iget-object v11, v0, Ld10;->G:Lw51;

    .line 222
    .line 223
    iget v14, v11, Lw51;->g:I

    .line 224
    .line 225
    iget v15, v11, Lw51;->h:I

    .line 226
    .line 227
    if-ge v14, v15, :cond_eb

    .line 228
    .line 229
    iget-object v15, v11, Lw51;->b:[I

    .line 230
    .line 231
    invoke-virtual {v11, v15, v14}, Lw51;->p([II)Ljava/lang/Object;

    .line 232
    .line 233
    .line 234
    move-result-object v11

    .line 235
    goto :goto_ec

    .line 236
    :cond_eb
    move-object v11, v13

    .line 237
    :goto_ec
    invoke-static {v3, v11}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 238
    .line 239
    .line 240
    move-result v11

    .line 241
    if-eqz v11, :cond_f8

    .line 242
    .line 243
    invoke-virtual {v0, v4, v10}, Ld10;->V(Ljava/lang/Object;Z)V

    .line 244
    .line 245
    .line 246
    :cond_f5
    move/from16 p2, v2

    .line 247
    .line 248
    goto :goto_148

    .line 249
    :cond_f8
    new-instance v11, Lg10;

    .line 250
    .line 251
    iget-object v14, v0, Ld10;->G:Lw51;

    .line 252
    .line 253
    iget-object v15, v14, Lw51;->b:[I

    .line 254
    .line 255
    new-instance v5, Ljava/util/ArrayList;

    .line 256
    .line 257
    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    .line 258
    .line 259
    .line 260
    iget v13, v14, Lw51;->k:I

    .line 261
    .line 262
    if-lez v13, :cond_10a

    .line 263
    .line 264
    :cond_107
    move/from16 p2, v2

    .line 265
    .line 266
    goto :goto_141

    .line 267
    :cond_10a
    iget v13, v14, Lw51;->g:I

    .line 268
    .line 269
    :goto_10c
    iget v12, v14, Lw51;->h:I

    .line 270
    .line 271
    if-ge v13, v12, :cond_107

    .line 272
    .line 273
    new-instance v12, Le90;

    .line 274
    .line 275
    mul-int/lit8 v18, v13, 0x5

    .line 276
    .line 277
    aget v7, v15, v18

    .line 278
    .line 279
    invoke-virtual {v14, v15, v13}, Lw51;->p([II)Ljava/lang/Object;

    .line 280
    .line 281
    .line 282
    move-result-object v9

    .line 283
    add-int/lit8 v20, v18, 0x1

    .line 284
    .line 285
    aget v20, v15, v20

    .line 286
    .line 287
    const/high16 v21, 0x40000000  # 2.0f

    .line 288
    .line 289
    and-int v21, v20, v21

    .line 290
    .line 291
    if-eqz v21, :cond_128

    .line 292
    .line 293
    move/from16 p2, v2

    .line 294
    .line 295
    const/4 v2, 0x1

    .line 296
    goto :goto_131

    .line 297
    :cond_128
    const v21, 0x3ffffff

    .line 298
    .line 299
    .line 300
    and-int v20, v20, v21

    .line 301
    .line 302
    move/from16 p2, v2

    .line 303
    .line 304
    move/from16 v2, v20

    .line 305
    .line 306
    :goto_131
    invoke-direct {v12, v9, v7, v13, v2}, Le90;-><init>(Ljava/lang/Object;III)V

    .line 307
    .line 308
    .line 309
    invoke-virtual {v5, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 310
    .line 311
    .line 312
    add-int/lit8 v18, v18, 0x3

    .line 313
    .line 314
    aget v2, v15, v18

    .line 315
    .line 316
    add-int/2addr v13, v2

    .line 317
    move/from16 v2, p2

    .line 318
    .line 319
    const/4 v7, 0x1

    .line 320
    const/4 v9, 0x0

    .line 321
    goto :goto_10c

    .line 322
    :goto_141
    iget v2, v0, Ld10;->k:I

    .line 323
    .line 324
    invoke-direct {v11, v2, v5}, Lg10;-><init>(ILjava/util/ArrayList;)V

    .line 325
    .line 326
    .line 327
    iput-object v11, v0, Ld10;->j:Lg10;

    .line 328
    .line 329
    :goto_148
    iget-object v2, v0, Ld10;->j:Lg10;

    .line 330
    .line 331
    if-eqz v2, :cond_325

    .line 332
    .line 333
    iget-object v5, v2, Lg10;->d:Ljava/util/ArrayList;

    .line 334
    .line 335
    iget-object v7, v2, Lg10;->e:Lsj0;

    .line 336
    .line 337
    iget v9, v2, Lg10;->b:I

    .line 338
    .line 339
    if-eqz v3, :cond_15e

    .line 340
    .line 341
    new-instance v11, Li80;

    .line 342
    .line 343
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 344
    .line 345
    .line 346
    move-result-object v12

    .line 347
    invoke-direct {v11, v12, v3}, Li80;-><init>(Ljava/lang/Integer;Ljava/lang/Object;)V

    .line 348
    .line 349
    .line 350
    goto :goto_162

    .line 351
    :cond_15e
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 352
    .line 353
    .line 354
    move-result-object v11

    .line 355
    :goto_162
    iget-object v12, v2, Lg10;->f:Lda1;

    .line 356
    .line 357
    invoke-virtual {v12}, Lda1;->getValue()Ljava/lang/Object;

    .line 358
    .line 359
    .line 360
    move-result-object v12

    .line 361
    check-cast v12, Loj0;

    .line 362
    .line 363
    iget-object v12, v12, Loj0;->a:Lhk0;

    .line 364
    .line 365
    invoke-virtual {v12, v11}, Lhk0;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 366
    .line 367
    .line 368
    move-result-object v13

    .line 369
    if-nez v13, :cond_174

    .line 370
    .line 371
    const/4 v13, 0x0

    .line 372
    goto :goto_199

    .line 373
    :cond_174
    instance-of v14, v13, Lak0;

    .line 374
    .line 375
    if-eqz v14, :cond_196

    .line 376
    .line 377
    check-cast v13, Lak0;

    .line 378
    .line 379
    const/4 v14, 0x0

    .line 380
    invoke-virtual {v13, v14}, Lak0;->k(I)Ljava/lang/Object;

    .line 381
    .line 382
    .line 383
    move-result-object v15

    .line 384
    invoke-virtual {v13}, Lak0;->h()Z

    .line 385
    .line 386
    .line 387
    move-result v14

    .line 388
    if-eqz v14, :cond_188

    .line 389
    .line 390
    invoke-virtual {v12, v11}, Lhk0;->k(Ljava/lang/Object;)Ljava/lang/Object;

    .line 391
    .line 392
    .line 393
    :cond_188
    iget v14, v13, Lak0;->b:I

    .line 394
    .line 395
    const/4 v3, 0x1

    .line 396
    if-ne v14, v3, :cond_194

    .line 397
    .line 398
    invoke-virtual {v13}, Lak0;->e()Ljava/lang/Object;

    .line 399
    .line 400
    .line 401
    move-result-object v3

    .line 402
    invoke-virtual {v12, v11, v3}, Lhk0;->m(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 403
    .line 404
    .line 405
    :cond_194
    move-object v13, v15

    .line 406
    goto :goto_199

    .line 407
    :cond_196
    invoke-virtual {v12, v11}, Lhk0;->k(Ljava/lang/Object;)Ljava/lang/Object;

    .line 408
    .line 409
    .line 410
    :goto_199
    check-cast v13, Le90;

    .line 411
    .line 412
    if-nez p2, :cond_328

    .line 413
    .line 414
    if-eqz v13, :cond_328

    .line 415
    .line 416
    iget v1, v13, Le90;->c:I

    .line 417
    .line 418
    invoke-virtual {v5, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 419
    .line 420
    .line 421
    invoke-virtual {v7, v1}, Ll60;->b(I)Ljava/lang/Object;

    .line 422
    .line 423
    .line 424
    move-result-object v3

    .line 425
    check-cast v3, Lt20;

    .line 426
    .line 427
    if-eqz v3, :cond_1af

    .line 428
    .line 429
    iget v3, v3, Lt20;->b:I

    .line 430
    .line 431
    goto :goto_1b0

    .line 432
    :cond_1af
    const/4 v3, -0x1

    .line 433
    :goto_1b0
    add-int/2addr v3, v9

    .line 434
    iput v3, v0, Ld10;->k:I

    .line 435
    .line 436
    invoke-virtual {v7, v1}, Ll60;->b(I)Ljava/lang/Object;

    .line 437
    .line 438
    .line 439
    move-result-object v3

    .line 440
    check-cast v3, Lt20;

    .line 441
    .line 442
    if-eqz v3, :cond_1be

    .line 443
    .line 444
    iget v5, v3, Lt20;->a:I

    .line 445
    .line 446
    goto :goto_1bf

    .line 447
    :cond_1be
    const/4 v5, -0x1

    .line 448
    :goto_1bf
    iget v2, v2, Lg10;->c:I

    .line 449
    .line 450
    sub-int v3, v5, v2

    .line 451
    .line 452
    const/16 v15, 0x8

    .line 453
    .line 454
    if-le v5, v2, :cond_238

    .line 455
    .line 456
    const/16 p1, 0x7

    .line 457
    .line 458
    iget-object v6, v7, Ll60;->c:[Ljava/lang/Object;

    .line 459
    .line 460
    iget-object v7, v7, Ll60;->a:[J

    .line 461
    .line 462
    const-wide/16 p2, 0x80

    .line 463
    .line 464
    array-length v8, v7

    .line 465
    add-int/lit8 v8, v8, -0x2

    .line 466
    .line 467
    if-ltz v8, :cond_234

    .line 468
    .line 469
    const/4 v9, 0x0

    .line 470
    const-wide/16 v20, 0xff

    .line 471
    .line 472
    :goto_1d7
    aget-wide v11, v7, v9

    .line 473
    .line 474
    const-wide v22, -0x7f7f7f7f7f7f7f80L  # -2.937446524422997E-306

    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    not-long v13, v11

    .line 480
    shl-long v13, v13, p1

    .line 481
    .line 482
    and-long/2addr v13, v11

    .line 483
    and-long v13, v13, v22

    .line 484
    .line 485
    cmp-long v13, v13, v22

    .line 486
    .line 487
    if-eqz v13, :cond_229

    .line 488
    .line 489
    sub-int v13, v9, v8

    .line 490
    .line 491
    not-int v13, v13

    .line 492
    ushr-int/lit8 v13, v13, 0x1f

    .line 493
    .line 494
    rsub-int/lit8 v13, v13, 0x8

    .line 495
    .line 496
    const/4 v14, 0x0

    .line 497
    :goto_1f0
    if-ge v14, v13, :cond_223

    .line 498
    .line 499
    and-long v24, v11, v20

    .line 500
    .line 501
    cmp-long v16, v24, p2

    .line 502
    .line 503
    if-gez v16, :cond_216

    .line 504
    .line 505
    shl-int/lit8 v16, v9, 0x3

    .line 506
    .line 507
    add-int v16, v16, v14

    .line 508
    .line 509
    aget-object v16, v6, v16

    .line 510
    .line 511
    move/from16 v18, v15

    .line 512
    .line 513
    move-object/from16 v15, v16

    .line 514
    .line 515
    check-cast v15, Lt20;

    .line 516
    .line 517
    move/from16 v16, v3

    .line 518
    .line 519
    iget v3, v15, Lt20;->a:I

    .line 520
    .line 521
    if-ne v3, v5, :cond_20d

    .line 522
    .line 523
    iput v2, v15, Lt20;->a:I

    .line 524
    .line 525
    goto :goto_21a

    .line 526
    :cond_20d
    if-gt v2, v3, :cond_21a

    .line 527
    .line 528
    if-ge v3, v5, :cond_21a

    .line 529
    .line 530
    add-int/lit8 v3, v3, 0x1

    .line 531
    .line 532
    iput v3, v15, Lt20;->a:I

    .line 533
    .line 534
    goto :goto_21a

    .line 535
    :cond_216
    move/from16 v16, v3

    .line 536
    .line 537
    move/from16 v18, v15

    .line 538
    .line 539
    :cond_21a
    :goto_21a
    shr-long v11, v11, v18

    .line 540
    .line 541
    add-int/lit8 v14, v14, 0x1

    .line 542
    .line 543
    move/from16 v3, v16

    .line 544
    .line 545
    move/from16 v15, v18

    .line 546
    .line 547
    goto :goto_1f0

    .line 548
    :cond_223
    move/from16 v16, v3

    .line 549
    .line 550
    move v3, v15

    .line 551
    if-ne v13, v3, :cond_2a7

    .line 552
    .line 553
    goto :goto_22b

    .line 554
    :cond_229
    move/from16 v16, v3

    .line 555
    .line 556
    :goto_22b
    if-eq v9, v8, :cond_2a7

    .line 557
    .line 558
    add-int/lit8 v9, v9, 0x1

    .line 559
    .line 560
    move/from16 v3, v16

    .line 561
    .line 562
    const/16 v15, 0x8

    .line 563
    .line 564
    goto :goto_1d7

    .line 565
    :cond_234
    move/from16 v16, v3

    .line 566
    .line 567
    goto/16 :goto_2a7

    .line 568
    .line 569
    :cond_238
    move/from16 v16, v3

    .line 570
    .line 571
    const/16 p1, 0x7

    .line 572
    .line 573
    const-wide/16 p2, 0x80

    .line 574
    .line 575
    const-wide/16 v20, 0xff

    .line 576
    .line 577
    const-wide v22, -0x7f7f7f7f7f7f7f80L  # -2.937446524422997E-306

    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    if-le v2, v5, :cond_2a7

    .line 583
    .line 584
    iget-object v3, v7, Ll60;->c:[Ljava/lang/Object;

    .line 585
    .line 586
    iget-object v6, v7, Ll60;->a:[J

    .line 587
    .line 588
    array-length v7, v6

    .line 589
    add-int/lit8 v7, v7, -0x2

    .line 590
    .line 591
    if-ltz v7, :cond_2a7

    .line 592
    .line 593
    const/4 v8, 0x0

    .line 594
    :goto_251
    aget-wide v11, v6, v8

    .line 595
    .line 596
    not-long v13, v11

    .line 597
    shl-long v13, v13, p1

    .line 598
    .line 599
    and-long/2addr v13, v11

    .line 600
    and-long v13, v13, v22

    .line 601
    .line 602
    cmp-long v9, v13, v22

    .line 603
    .line 604
    if-eqz v9, :cond_29c

    .line 605
    .line 606
    sub-int v9, v8, v7

    .line 607
    .line 608
    not-int v9, v9

    .line 609
    ushr-int/lit8 v9, v9, 0x1f

    .line 610
    .line 611
    const/16 v18, 0x8

    .line 612
    .line 613
    rsub-int/lit8 v15, v9, 0x8

    .line 614
    .line 615
    const/4 v9, 0x0

    .line 616
    :goto_267
    if-ge v9, v15, :cond_295

    .line 617
    .line 618
    and-long v13, v11, v20

    .line 619
    .line 620
    cmp-long v13, v13, p2

    .line 621
    .line 622
    if-gez v13, :cond_28c

    .line 623
    .line 624
    shl-int/lit8 v13, v8, 0x3

    .line 625
    .line 626
    add-int/2addr v13, v9

    .line 627
    aget-object v13, v3, v13

    .line 628
    .line 629
    check-cast v13, Lt20;

    .line 630
    .line 631
    iget v14, v13, Lt20;->a:I

    .line 632
    .line 633
    if-ne v14, v5, :cond_27d

    .line 634
    .line 635
    iput v2, v13, Lt20;->a:I

    .line 636
    .line 637
    goto :goto_28c

    .line 638
    :cond_27d
    move-object/from16 v24, v3

    .line 639
    .line 640
    add-int/lit8 v3, v5, 0x1

    .line 641
    .line 642
    if-gt v3, v14, :cond_289

    .line 643
    .line 644
    if-ge v14, v2, :cond_289

    .line 645
    .line 646
    add-int/lit8 v14, v14, -0x1

    .line 647
    .line 648
    iput v14, v13, Lt20;->a:I

    .line 649
    .line 650
    :cond_289
    :goto_289
    const/16 v3, 0x8

    .line 651
    .line 652
    goto :goto_28f

    .line 653
    :cond_28c
    :goto_28c
    move-object/from16 v24, v3

    .line 654
    .line 655
    goto :goto_289

    .line 656
    :goto_28f
    shr-long/2addr v11, v3

    .line 657
    add-int/lit8 v9, v9, 0x1

    .line 658
    .line 659
    move-object/from16 v3, v24

    .line 660
    .line 661
    goto :goto_267

    .line 662
    :cond_295
    move-object/from16 v24, v3

    .line 663
    .line 664
    const/16 v3, 0x8

    .line 665
    .line 666
    if-ne v15, v3, :cond_2a7

    .line 667
    .line 668
    goto :goto_2a0

    .line 669
    :cond_29c
    move-object/from16 v24, v3

    .line 670
    .line 671
    const/16 v3, 0x8

    .line 672
    .line 673
    :goto_2a0
    if-eq v8, v7, :cond_2a7

    .line 674
    .line 675
    add-int/lit8 v8, v8, 0x1

    .line 676
    .line 677
    move-object/from16 v3, v24

    .line 678
    .line 679
    goto :goto_251

    .line 680
    :cond_2a7
    :goto_2a7
    iget-object v2, v0, Ld10;->M:Lpj;

    .line 681
    .line 682
    iget v3, v2, Lpj;->f:I

    .line 683
    .line 684
    iget-object v5, v2, Lpj;->a:Ld10;

    .line 685
    .line 686
    iget-object v6, v5, Ld10;->G:Lw51;

    .line 687
    .line 688
    iget v6, v6, Lw51;->g:I

    .line 689
    .line 690
    sub-int v6, v1, v6

    .line 691
    .line 692
    add-int/2addr v6, v3

    .line 693
    iput v6, v2, Lpj;->f:I

    .line 694
    .line 695
    iget-object v3, v0, Ld10;->G:Lw51;

    .line 696
    .line 697
    invoke-virtual {v3, v1}, Lw51;->r(I)V

    .line 698
    .line 699
    .line 700
    if-lez v16, :cond_322

    .line 701
    .line 702
    const/4 v14, 0x0

    .line 703
    invoke-virtual {v2, v14}, Lpj;->d(Z)V

    .line 704
    .line 705
    .line 706
    iget-object v1, v2, Lpj;->d:Lw60;

    .line 707
    .line 708
    iget-object v3, v5, Ld10;->G:Lw51;

    .line 709
    .line 710
    iget v5, v3, Lw51;->c:I

    .line 711
    .line 712
    if-lez v5, :cond_306

    .line 713
    .line 714
    iget v5, v3, Lw51;->i:I

    .line 715
    .line 716
    const/4 v6, -0x2

    .line 717
    invoke-virtual {v1, v6}, Lw60;->a(I)I

    .line 718
    .line 719
    .line 720
    move-result v6

    .line 721
    if-eq v6, v5, :cond_306

    .line 722
    .line 723
    iget-boolean v6, v2, Lpj;->c:Z

    .line 724
    .line 725
    if-nez v6, :cond_2ea

    .line 726
    .line 727
    iget-boolean v6, v2, Lpj;->e:Z

    .line 728
    .line 729
    if-eqz v6, :cond_2ea

    .line 730
    .line 731
    const/4 v14, 0x0

    .line 732
    invoke-virtual {v2, v14}, Lpj;->d(Z)V

    .line 733
    .line 734
    .line 735
    iget-object v6, v2, Lpj;->b:Lve;

    .line 736
    .line 737
    iget-object v6, v6, Lve;->F:Lzo0;

    .line 738
    .line 739
    sget-object v7, Leo0;->c:Leo0;

    .line 740
    .line 741
    invoke-virtual {v6, v7}, Lzo0;->C(Lxo0;)V

    .line 742
    .line 743
    .line 744
    const/4 v6, 0x1

    .line 745
    iput-boolean v6, v2, Lpj;->c:Z

    .line 746
    .line 747
    :cond_2ea
    if-lez v5, :cond_306

    .line 748
    .line 749
    invoke-virtual {v3, v5}, Lw51;->a(I)Ly00;

    .line 750
    .line 751
    .line 752
    move-result-object v3

    .line 753
    invoke-virtual {v1, v5}, Lw60;->c(I)V

    .line 754
    .line 755
    .line 756
    const/4 v14, 0x0

    .line 757
    invoke-virtual {v2, v14}, Lpj;->d(Z)V

    .line 758
    .line 759
    .line 760
    iget-object v1, v2, Lpj;->b:Lve;

    .line 761
    .line 762
    iget-object v1, v1, Lve;->F:Lzo0;

    .line 763
    .line 764
    sget-object v5, Ldo0;->c:Ldo0;

    .line 765
    .line 766
    invoke-virtual {v1, v5}, Lzo0;->C(Lxo0;)V

    .line 767
    .line 768
    .line 769
    invoke-static {v1, v14, v3}, Ldd0;->v(Lzo0;ILjava/lang/Object;)V

    .line 770
    .line 771
    .line 772
    const/4 v3, 0x1

    .line 773
    iput-boolean v3, v2, Lpj;->c:Z

    .line 774
    .line 775
    :cond_306
    iget-object v1, v2, Lpj;->b:Lve;

    .line 776
    .line 777
    iget-object v1, v1, Lve;->F:Lzo0;

    .line 778
    .line 779
    sget-object v2, Lio0;->c:Lio0;

    .line 780
    .line 781
    invoke-virtual {v1, v2}, Lzo0;->C(Lxo0;)V

    .line 782
    .line 783
    .line 784
    iget-object v2, v1, Lzo0;->d:[I

    .line 785
    .line 786
    iget v3, v1, Lzo0;->e:I

    .line 787
    .line 788
    iget-object v5, v1, Lzo0;->b:[Lxo0;

    .line 789
    .line 790
    iget v1, v1, Lzo0;->c:I

    .line 791
    .line 792
    const/16 v19, 0x1

    .line 793
    .line 794
    add-int/lit8 v1, v1, -0x1

    .line 795
    .line 796
    aget-object v1, v5, v1

    .line 797
    .line 798
    iget v1, v1, Lxo0;->a:I

    .line 799
    .line 800
    sub-int/2addr v3, v1

    .line 801
    aput v16, v2, v3

    .line 802
    .line 803
    :cond_322
    invoke-virtual {v0, v4, v10}, Ld10;->V(Ljava/lang/Object;Z)V

    .line 804
    .line 805
    .line 806
    :cond_325
    const/4 v2, 0x0

    .line 807
    goto/16 :goto_3a4

    .line 808
    .line 809
    :cond_328
    iget-object v2, v0, Ld10;->G:Lw51;

    .line 810
    .line 811
    iget v3, v2, Lw51;->k:I

    .line 812
    .line 813
    const/4 v11, 0x1

    .line 814
    add-int/2addr v3, v11

    .line 815
    iput v3, v2, Lw51;->k:I

    .line 816
    .line 817
    iput-boolean v11, v0, Ld10;->S:Z

    .line 818
    .line 819
    const/4 v2, 0x0

    .line 820
    iput-object v2, v0, Ld10;->K:Lqr0;

    .line 821
    .line 822
    iget-object v3, v0, Ld10;->I:La61;

    .line 823
    .line 824
    iget-boolean v3, v3, La61;->w:Z

    .line 825
    .line 826
    if-eqz v3, :cond_34b

    .line 827
    .line 828
    iget-object v3, v0, Ld10;->H:Lx51;

    .line 829
    .line 830
    invoke-virtual {v3}, Lx51;->e()La61;

    .line 831
    .line 832
    .line 833
    move-result-object v3

    .line 834
    iput-object v3, v0, Ld10;->I:La61;

    .line 835
    .line 836
    invoke-virtual {v3}, La61;->M()V

    .line 837
    .line 838
    .line 839
    const/4 v14, 0x0

    .line 840
    iput-boolean v14, v0, Ld10;->J:Z

    .line 841
    .line 842
    iput-object v2, v0, Ld10;->K:Lqr0;

    .line 843
    .line 844
    :cond_34b
    iget-object v2, v0, Ld10;->I:La61;

    .line 845
    .line 846
    invoke-virtual {v2}, La61;->d()V

    .line 847
    .line 848
    .line 849
    iget-object v2, v0, Ld10;->I:La61;

    .line 850
    .line 851
    iget v3, v2, La61;->t:I

    .line 852
    .line 853
    if-eqz v10, :cond_35c

    .line 854
    .line 855
    const/4 v11, 0x1

    .line 856
    invoke-virtual {v2, v1, v8, v11, v8}, La61;->Q(ILjava/lang/Object;ZLjava/lang/Object;)V

    .line 857
    .line 858
    .line 859
    const/4 v14, 0x0

    .line 860
    goto :goto_373

    .line 861
    :cond_35c
    if-eqz v4, :cond_369

    .line 862
    .line 863
    if-nez p3, :cond_362

    .line 864
    .line 865
    :goto_360
    const/4 v14, 0x0

    .line 866
    goto :goto_365

    .line 867
    :cond_362
    move-object/from16 v8, p3

    .line 868
    .line 869
    goto :goto_360

    .line 870
    :goto_365
    invoke-virtual {v2, v1, v8, v14, v4}, La61;->Q(ILjava/lang/Object;ZLjava/lang/Object;)V

    .line 871
    .line 872
    .line 873
    goto :goto_373

    .line 874
    :cond_369
    const/4 v14, 0x0

    .line 875
    if-nez p3, :cond_36e

    .line 876
    .line 877
    move-object v4, v8

    .line 878
    goto :goto_370

    .line 879
    :cond_36e
    move-object/from16 v4, p3

    .line 880
    .line 881
    :goto_370
    invoke-virtual {v2, v1, v4, v14, v8}, La61;->Q(ILjava/lang/Object;ZLjava/lang/Object;)V

    .line 882
    .line 883
    .line 884
    :goto_373
    iget-object v2, v0, Ld10;->I:La61;

    .line 885
    .line 886
    invoke-virtual {v2, v3}, La61;->b(I)Ly00;

    .line 887
    .line 888
    .line 889
    move-result-object v2

    .line 890
    iput-object v2, v0, Ld10;->N:Ly00;

    .line 891
    .line 892
    new-instance v2, Le90;

    .line 893
    .line 894
    const/16 v17, -0x2

    .line 895
    .line 896
    rsub-int/lit8 v12, v3, -0x2

    .line 897
    .line 898
    const/4 v3, -0x1

    .line 899
    invoke-direct {v2, v6, v1, v12, v3}, Le90;-><init>(Ljava/lang/Object;III)V

    .line 900
    .line 901
    .line 902
    iget v1, v0, Ld10;->k:I

    .line 903
    .line 904
    sub-int/2addr v1, v9

    .line 905
    new-instance v4, Lt20;

    .line 906
    .line 907
    invoke-direct {v4, v3, v1, v14}, Lt20;-><init>(III)V

    .line 908
    .line 909
    .line 910
    invoke-virtual {v7, v12, v4}, Lsj0;->h(ILjava/lang/Object;)V

    .line 911
    .line 912
    .line 913
    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 914
    .line 915
    .line 916
    new-instance v13, Lg10;

    .line 917
    .line 918
    new-instance v1, Ljava/util/ArrayList;

    .line 919
    .line 920
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 921
    .line 922
    .line 923
    if-eqz v10, :cond_39e

    .line 924
    .line 925
    move v9, v14

    .line 926
    goto :goto_3a0

    .line 927
    :cond_39e
    iget v9, v0, Ld10;->k:I

    .line 928
    .line 929
    :goto_3a0
    invoke-direct {v13, v9, v1}, Lg10;-><init>(ILjava/util/ArrayList;)V

    .line 930
    .line 931
    .line 932
    goto :goto_3a5

    .line 933
    :goto_3a4
    move-object v13, v2

    .line 934
    :goto_3a5
    invoke-virtual {v0, v10, v13}, Ld10;->u(ZLg10;)V

    .line 935
    .line 936
    .line 937
    return-void
.end method

.method public final T()V
    .registers 4

    .line 1
    const/4 v0, 0x0

    .line 2
    const/4 v1, 0x0

    .line 3
    const/16 v2, -0x7f

    .line 4
    .line 5
    invoke-virtual {p0, v2, v1, v0, v0}, Ld10;->S(IILjava/lang/Object;Ljava/lang/Object;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public final U(ILqn0;)V
    .registers 5

    .line 1
    const/4 v0, 0x0

    .line 2
    const/4 v1, 0x0

    .line 3
    invoke-virtual {p0, p1, v0, p2, v1}, Ld10;->S(IILjava/lang/Object;Ljava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final V(Ljava/lang/Object;Z)V
    .registers 5

    .line 1
    if-eqz p2, :cond_21

    .line 2
    .line 3
    iget-object p0, p0, Ld10;->G:Lw51;

    .line 4
    .line 5
    iget p1, p0, Lw51;->k:I

    .line 6
    .line 7
    if-gtz p1, :cond_20

    .line 8
    .line 9
    iget-object p1, p0, Lw51;->b:[I

    .line 10
    .line 11
    iget p2, p0, Lw51;->g:I

    .line 12
    .line 13
    mul-int/lit8 p2, p2, 0x5

    .line 14
    .line 15
    add-int/lit8 p2, p2, 0x1

    .line 16
    .line 17
    aget p1, p1, p2

    .line 18
    .line 19
    const/high16 p2, 0x40000000  # 2.0f

    .line 20
    .line 21
    and-int/2addr p1, p2

    .line 22
    if-eqz p1, :cond_18

    .line 23
    .line 24
    goto :goto_1d

    .line 25
    :cond_18
    const-string p1, "Expected a node group"

    .line 26
    .line 27
    invoke-static {p1}, Lrt0;->a(Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    :goto_1d
    invoke-virtual {p0}, Lw51;->u()V

    .line 31
    .line 32
    .line 33
    :cond_20
    return-void

    .line 34
    :cond_21
    if-eqz p1, :cond_40

    .line 35
    .line 36
    iget-object p2, p0, Ld10;->G:Lw51;

    .line 37
    .line 38
    invoke-virtual {p2}, Lw51;->f()Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object p2

    .line 42
    if-eq p2, p1, :cond_40

    .line 43
    .line 44
    iget-object p2, p0, Ld10;->M:Lpj;

    .line 45
    .line 46
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 47
    .line 48
    .line 49
    const/4 v0, 0x0

    .line 50
    invoke-virtual {p2, v0}, Lpj;->d(Z)V

    .line 51
    .line 52
    .line 53
    iget-object p2, p2, Lpj;->b:Lve;

    .line 54
    .line 55
    iget-object p2, p2, Lve;->F:Lzo0;

    .line 56
    .line 57
    sget-object v1, Lto0;->c:Lto0;

    .line 58
    .line 59
    invoke-virtual {p2, v1}, Lzo0;->C(Lxo0;)V

    .line 60
    .line 61
    .line 62
    invoke-static {p2, v0, p1}, Ldd0;->v(Lzo0;ILjava/lang/Object;)V

    .line 63
    .line 64
    .line 65
    :cond_40
    iget-object p0, p0, Ld10;->G:Lw51;

    .line 66
    .line 67
    invoke-virtual {p0}, Lw51;->u()V

    .line 68
    .line 69
    .line 70
    return-void
.end method

.method public final W(I)V
    .registers 11

    .line 1
    iget-object v0, p0, Ld10;->j:Lg10;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x0

    .line 5
    if-eqz v0, :cond_a

    .line 6
    .line 7
    invoke-virtual {p0, p1, v1, v2, v2}, Ld10;->S(IILjava/lang/Object;Ljava/lang/Object;)V

    .line 8
    .line 9
    .line 10
    return-void

    .line 11
    :cond_a
    iget-boolean v0, p0, Ld10;->r:Z

    .line 12
    .line 13
    if-eqz v0, :cond_13

    .line 14
    .line 15
    const-string v0, "A call to createNode(), emitNode() or useNode() expected"

    .line 16
    .line 17
    invoke-static {v0}, Lqj;->a(Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    :cond_13
    iget v0, p0, Ld10;->m:I

    .line 21
    .line 22
    iget-wide v3, p0, Ld10;->T:J

    .line 23
    .line 24
    const/4 v5, 0x3

    .line 25
    invoke-static {v3, v4, v5}, Ljava/lang/Long;->rotateLeft(JI)J

    .line 26
    .line 27
    .line 28
    move-result-wide v3

    .line 29
    int-to-long v6, p1

    .line 30
    xor-long/2addr v3, v6

    .line 31
    invoke-static {v3, v4, v5}, Ljava/lang/Long;->rotateLeft(JI)J

    .line 32
    .line 33
    .line 34
    move-result-wide v3

    .line 35
    int-to-long v5, v0

    .line 36
    xor-long/2addr v3, v5

    .line 37
    iput-wide v3, p0, Ld10;->T:J

    .line 38
    .line 39
    iget v0, p0, Ld10;->m:I

    .line 40
    .line 41
    const/4 v3, 0x1

    .line 42
    add-int/2addr v0, v3

    .line 43
    iput v0, p0, Ld10;->m:I

    .line 44
    .line 45
    iget-object v0, p0, Ld10;->G:Lw51;

    .line 46
    .line 47
    iget-boolean v4, p0, Ld10;->S:Z

    .line 48
    .line 49
    sget-object v5, Loj;->a:Lnq0;

    .line 50
    .line 51
    if-eqz v4, :cond_42

    .line 52
    .line 53
    iget v4, v0, Lw51;->k:I

    .line 54
    .line 55
    add-int/2addr v4, v3

    .line 56
    iput v4, v0, Lw51;->k:I

    .line 57
    .line 58
    iget-object v0, p0, Ld10;->I:La61;

    .line 59
    .line 60
    invoke-virtual {v0, p1, v5, v1, v5}, La61;->Q(ILjava/lang/Object;ZLjava/lang/Object;)V

    .line 61
    .line 62
    .line 63
    invoke-virtual {p0, v1, v2}, Ld10;->u(ZLg10;)V

    .line 64
    .line 65
    .line 66
    return-void

    .line 67
    :cond_42
    invoke-virtual {v0}, Lw51;->g()I

    .line 68
    .line 69
    .line 70
    move-result v4

    .line 71
    if-ne v4, p1, :cond_62

    .line 72
    .line 73
    iget v4, v0, Lw51;->g:I

    .line 74
    .line 75
    iget v6, v0, Lw51;->h:I

    .line 76
    .line 77
    if-ge v4, v6, :cond_5b

    .line 78
    .line 79
    iget-object v6, v0, Lw51;->b:[I

    .line 80
    .line 81
    mul-int/lit8 v4, v4, 0x5

    .line 82
    .line 83
    add-int/2addr v4, v3

    .line 84
    aget v4, v6, v4

    .line 85
    .line 86
    const/high16 v6, 0x20000000

    .line 87
    .line 88
    and-int/2addr v4, v6

    .line 89
    if-eqz v4, :cond_5b

    .line 90
    .line 91
    goto :goto_62

    .line 92
    :cond_5b
    invoke-virtual {v0}, Lw51;->u()V

    .line 93
    .line 94
    .line 95
    invoke-virtual {p0, v1, v2}, Ld10;->u(ZLg10;)V

    .line 96
    .line 97
    .line 98
    return-void

    .line 99
    :cond_62
    :goto_62
    iget v4, v0, Lw51;->k:I

    .line 100
    .line 101
    if-lez v4, :cond_67

    .line 102
    .line 103
    goto :goto_83

    .line 104
    :cond_67
    iget v4, v0, Lw51;->g:I

    .line 105
    .line 106
    iget v6, v0, Lw51;->h:I

    .line 107
    .line 108
    if-ne v4, v6, :cond_6e

    .line 109
    .line 110
    goto :goto_83

    .line 111
    :cond_6e
    iget v6, p0, Ld10;->k:I

    .line 112
    .line 113
    invoke-virtual {p0}, Ld10;->I()V

    .line 114
    .line 115
    .line 116
    invoke-virtual {v0}, Lw51;->s()I

    .line 117
    .line 118
    .line 119
    move-result v7

    .line 120
    iget-object v8, p0, Ld10;->M:Lpj;

    .line 121
    .line 122
    invoke-virtual {v8, v6, v7}, Lpj;->e(II)V

    .line 123
    .line 124
    .line 125
    iget-object v6, p0, Ld10;->s:Ljava/util/ArrayList;

    .line 126
    .line 127
    iget v7, v0, Lw51;->g:I

    .line 128
    .line 129
    invoke-static {v6, v4, v7}, Lvn;->f(Ljava/util/List;II)V

    .line 130
    .line 131
    .line 132
    :goto_83
    iget v4, v0, Lw51;->k:I

    .line 133
    .line 134
    add-int/2addr v4, v3

    .line 135
    iput v4, v0, Lw51;->k:I

    .line 136
    .line 137
    iput-boolean v3, p0, Ld10;->S:Z

    .line 138
    .line 139
    iput-object v2, p0, Ld10;->K:Lqr0;

    .line 140
    .line 141
    iget-object v0, p0, Ld10;->I:La61;

    .line 142
    .line 143
    iget-boolean v0, v0, La61;->w:Z

    .line 144
    .line 145
    if-eqz v0, :cond_a1

    .line 146
    .line 147
    iget-object v0, p0, Ld10;->H:Lx51;

    .line 148
    .line 149
    invoke-virtual {v0}, Lx51;->e()La61;

    .line 150
    .line 151
    .line 152
    move-result-object v0

    .line 153
    iput-object v0, p0, Ld10;->I:La61;

    .line 154
    .line 155
    invoke-virtual {v0}, La61;->M()V

    .line 156
    .line 157
    .line 158
    iput-boolean v1, p0, Ld10;->J:Z

    .line 159
    .line 160
    iput-object v2, p0, Ld10;->K:Lqr0;

    .line 161
    .line 162
    :cond_a1
    iget-object v0, p0, Ld10;->I:La61;

    .line 163
    .line 164
    invoke-virtual {v0}, La61;->d()V

    .line 165
    .line 166
    .line 167
    iget v3, v0, La61;->t:I

    .line 168
    .line 169
    invoke-virtual {v0, p1, v5, v1, v5}, La61;->Q(ILjava/lang/Object;ZLjava/lang/Object;)V

    .line 170
    .line 171
    .line 172
    invoke-virtual {v0, v3}, La61;->b(I)Ly00;

    .line 173
    .line 174
    .line 175
    move-result-object p1

    .line 176
    iput-object p1, p0, Ld10;->N:Ly00;

    .line 177
    .line 178
    invoke-virtual {p0, v1, v2}, Ld10;->u(ZLg10;)V

    .line 179
    .line 180
    .line 181
    return-void
.end method

.method public final X(I)Ld10;
    .registers 8

    .line 1
    invoke-virtual {p0, p1}, Ld10;->W(I)V

    .line 2
    .line 3
    .line 4
    iget-boolean p1, p0, Ld10;->S:Z

    .line 5
    .line 6
    iget-object v0, p0, Ld10;->g:Lpg0;

    .line 7
    .line 8
    iget-object v1, p0, Ld10;->E:Ljava/util/ArrayList;

    .line 9
    .line 10
    iget-object v2, p0, Ld10;->h:Lyj;

    .line 11
    .line 12
    if-eqz p1, :cond_26

    .line 13
    .line 14
    new-instance p1, Lxv0;

    .line 15
    .line 16
    invoke-direct {p1, v2}, Lxv0;-><init>(Lyj;)V

    .line 17
    .line 18
    .line 19
    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 20
    .line 21
    .line 22
    invoke-virtual {p0, p1}, Ld10;->h0(Ljava/lang/Object;)V

    .line 23
    .line 24
    .line 25
    iget v1, p0, Ld10;->B:I

    .line 26
    .line 27
    iput v1, p1, Lxv0;->e:I

    .line 28
    .line 29
    iget v1, p1, Lxv0;->b:I

    .line 30
    .line 31
    and-int/lit8 v1, v1, -0x11

    .line 32
    .line 33
    iput v1, p1, Lxv0;->b:I

    .line 34
    .line 35
    invoke-virtual {v0}, Lpg0;->k()V

    .line 36
    .line 37
    .line 38
    return-object p0

    .line 39
    :cond_26
    iget-object p1, p0, Ld10;->G:Lw51;

    .line 40
    .line 41
    iget p1, p1, Lw51;->i:I

    .line 42
    .line 43
    iget-object v3, p0, Ld10;->s:Ljava/util/ArrayList;

    .line 44
    .line 45
    invoke-static {p1, v3}, Lvn;->s(ILjava/util/List;)I

    .line 46
    .line 47
    .line 48
    move-result p1

    .line 49
    if-ltz p1, :cond_39

    .line 50
    .line 51
    invoke-virtual {v3, p1}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    move-result-object p1

    .line 55
    check-cast p1, Lu70;

    .line 56
    .line 57
    goto :goto_3a

    .line 58
    :cond_39
    const/4 p1, 0x0

    .line 59
    :goto_3a
    iget-object v3, p0, Ld10;->G:Lw51;

    .line 60
    .line 61
    invoke-virtual {v3}, Lw51;->m()Ljava/lang/Object;

    .line 62
    .line 63
    .line 64
    move-result-object v3

    .line 65
    sget-object v4, Loj;->a:Lnq0;

    .line 66
    .line 67
    invoke-static {v3, v4}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 68
    .line 69
    .line 70
    move-result v4

    .line 71
    if-eqz v4, :cond_51

    .line 72
    .line 73
    new-instance v3, Lxv0;

    .line 74
    .line 75
    invoke-direct {v3, v2}, Lxv0;-><init>(Lyj;)V

    .line 76
    .line 77
    .line 78
    invoke-virtual {p0, v3}, Ld10;->h0(Ljava/lang/Object;)V

    .line 79
    .line 80
    .line 81
    goto :goto_56

    .line 82
    :cond_51
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 83
    .line 84
    .line 85
    check-cast v3, Lxv0;

    .line 86
    .line 87
    :goto_56
    const/4 v2, 0x0

    .line 88
    const/4 v4, 0x1

    .line 89
    if-nez p1, :cond_6e

    .line 90
    .line 91
    iget p1, v3, Lxv0;->b:I

    .line 92
    .line 93
    and-int/lit8 v5, p1, 0x40

    .line 94
    .line 95
    if-eqz v5, :cond_62

    .line 96
    .line 97
    move v5, v4

    .line 98
    goto :goto_63

    .line 99
    :cond_62
    move v5, v2

    .line 100
    :goto_63
    if-eqz v5, :cond_69

    .line 101
    .line 102
    and-int/lit8 p1, p1, -0x41

    .line 103
    .line 104
    iput p1, v3, Lxv0;->b:I

    .line 105
    .line 106
    :cond_69
    if-eqz v5, :cond_6c

    .line 107
    .line 108
    goto :goto_6e

    .line 109
    :cond_6c
    move p1, v2

    .line 110
    goto :goto_6f

    .line 111
    :cond_6e
    :goto_6e
    move p1, v4

    .line 112
    :goto_6f
    iget v5, v3, Lxv0;->b:I

    .line 113
    .line 114
    if-eqz p1, :cond_76

    .line 115
    .line 116
    or-int/lit8 p1, v5, 0x8

    .line 117
    .line 118
    goto :goto_78

    .line 119
    :cond_76
    and-int/lit8 p1, v5, -0x9

    .line 120
    .line 121
    :goto_78
    iput p1, v3, Lxv0;->b:I

    .line 122
    .line 123
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 124
    .line 125
    .line 126
    iget p1, p0, Ld10;->B:I

    .line 127
    .line 128
    iput p1, v3, Lxv0;->e:I

    .line 129
    .line 130
    iget p1, v3, Lxv0;->b:I

    .line 131
    .line 132
    and-int/lit8 p1, p1, -0x11

    .line 133
    .line 134
    iput p1, v3, Lxv0;->b:I

    .line 135
    .line 136
    invoke-virtual {v0}, Lpg0;->k()V

    .line 137
    .line 138
    .line 139
    iget p1, v3, Lxv0;->b:I

    .line 140
    .line 141
    and-int/lit16 v0, p1, 0x100

    .line 142
    .line 143
    if-eqz v0, :cond_b4

    .line 144
    .line 145
    and-int/lit16 p1, p1, -0x101

    .line 146
    .line 147
    or-int/lit16 p1, p1, 0x200

    .line 148
    .line 149
    iput p1, v3, Lxv0;->b:I

    .line 150
    .line 151
    iget-object p1, p0, Ld10;->M:Lpj;

    .line 152
    .line 153
    iget-object p1, p1, Lpj;->b:Lve;

    .line 154
    .line 155
    iget-object p1, p1, Lve;->F:Lzo0;

    .line 156
    .line 157
    sget-object v0, Lro0;->c:Lro0;

    .line 158
    .line 159
    invoke-virtual {p1, v0}, Lzo0;->C(Lxo0;)V

    .line 160
    .line 161
    .line 162
    invoke-static {p1, v2, v3}, Ldd0;->v(Lzo0;ILjava/lang/Object;)V

    .line 163
    .line 164
    .line 165
    iget-boolean p1, p0, Ld10;->y:Z

    .line 166
    .line 167
    if-nez p1, :cond_b4

    .line 168
    .line 169
    iget p1, v3, Lxv0;->b:I

    .line 170
    .line 171
    and-int/lit16 v0, p1, 0x80

    .line 172
    .line 173
    if-eqz v0, :cond_b4

    .line 174
    .line 175
    iput-boolean v4, p0, Ld10;->y:Z

    .line 176
    .line 177
    or-int/lit16 p1, p1, 0x400

    .line 178
    .line 179
    iput p1, v3, Lxv0;->b:I

    .line 180
    .line 181
    :cond_b4
    return-object p0
.end method

.method public final Y(Ljava/lang/Object;)V
    .registers 5

    .line 1
    iget-boolean v0, p0, Ld10;->S:Z

    .line 2
    .line 3
    const/16 v1, 0xcf

    .line 4
    .line 5
    if-nez v0, :cond_27

    .line 6
    .line 7
    iget-object v0, p0, Ld10;->G:Lw51;

    .line 8
    .line 9
    invoke-virtual {v0}, Lw51;->g()I

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-ne v0, v1, :cond_27

    .line 14
    .line 15
    iget-object v0, p0, Ld10;->G:Lw51;

    .line 16
    .line 17
    invoke-virtual {v0}, Lw51;->f()Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    invoke-static {v0, p1}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    if-nez v0, :cond_27

    .line 26
    .line 27
    iget v0, p0, Ld10;->z:I

    .line 28
    .line 29
    if-gez v0, :cond_27

    .line 30
    .line 31
    iget-object v0, p0, Ld10;->G:Lw51;

    .line 32
    .line 33
    iget v0, v0, Lw51;->g:I

    .line 34
    .line 35
    iput v0, p0, Ld10;->z:I

    .line 36
    .line 37
    const/4 v0, 0x1

    .line 38
    iput-boolean v0, p0, Ld10;->y:Z

    .line 39
    .line 40
    :cond_27
    const/4 v0, 0x0

    .line 41
    const/4 v2, 0x0

    .line 42
    invoke-virtual {p0, v1, v2, v0, p1}, Ld10;->S(IILjava/lang/Object;Ljava/lang/Object;)V

    .line 43
    .line 44
    .line 45
    return-void
.end method

.method public final Z()V
    .registers 4

    .line 1
    const/4 v0, 0x0

    .line 2
    const/4 v1, 0x2

    .line 3
    const/16 v2, 0x7d

    .line 4
    .line 5
    invoke-virtual {p0, v2, v1, v0, v0}, Ld10;->S(IILjava/lang/Object;Ljava/lang/Object;)V

    .line 6
    .line 7
    .line 8
    const/4 v0, 0x1

    .line 9
    iput-boolean v0, p0, Ld10;->r:Z

    .line 10
    .line 11
    return-void
.end method

.method public final a()V
    .registers 5

    .line 1
    invoke-virtual {p0}, Ld10;->i()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Ld10;->i:Ljava/util/ArrayList;

    .line 5
    .line 6
    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 7
    .line 8
    .line 9
    iget-object v0, p0, Ld10;->n:Lw60;

    .line 10
    .line 11
    const/4 v1, 0x0

    .line 12
    iput v1, v0, Lw60;->b:I

    .line 13
    .line 14
    iget-object v0, p0, Ld10;->t:Lw60;

    .line 15
    .line 16
    iput v1, v0, Lw60;->b:I

    .line 17
    .line 18
    iget-object v0, p0, Ld10;->x:Lw60;

    .line 19
    .line 20
    iput v1, v0, Lw60;->b:I

    .line 21
    .line 22
    const/4 v0, 0x0

    .line 23
    iput-object v0, p0, Ld10;->v:Lsj0;

    .line 24
    .line 25
    iget-object v0, p0, Ld10;->O:Lbw;

    .line 26
    .line 27
    iget-object v2, v0, Lbw;->c:Lzo0;

    .line 28
    .line 29
    invoke-virtual {v2}, Lzo0;->z()V

    .line 30
    .line 31
    .line 32
    iget-object v0, v0, Lbw;->b:Lzo0;

    .line 33
    .line 34
    invoke-virtual {v0}, Lzo0;->z()V

    .line 35
    .line 36
    .line 37
    const-wide/16 v2, 0x0

    .line 38
    .line 39
    iput-wide v2, p0, Ld10;->T:J

    .line 40
    .line 41
    iput v1, p0, Ld10;->A:I

    .line 42
    .line 43
    iput-boolean v1, p0, Ld10;->r:Z

    .line 44
    .line 45
    iput-boolean v1, p0, Ld10;->S:Z

    .line 46
    .line 47
    iput-boolean v1, p0, Ld10;->y:Z

    .line 48
    .line 49
    iput-boolean v1, p0, Ld10;->F:Z

    .line 50
    .line 51
    const/4 v0, -0x1

    .line 52
    iput v0, p0, Ld10;->z:I

    .line 53
    .line 54
    iget-object v0, p0, Ld10;->G:Lw51;

    .line 55
    .line 56
    iget-boolean v1, v0, Lw51;->f:Z

    .line 57
    .line 58
    if-nez v1, :cond_3e

    .line 59
    .line 60
    invoke-virtual {v0}, Lw51;->c()V

    .line 61
    .line 62
    .line 63
    :cond_3e
    iget-object v0, p0, Ld10;->I:La61;

    .line 64
    .line 65
    iget-boolean v0, v0, La61;->w:Z

    .line 66
    .line 67
    if-nez v0, :cond_47

    .line 68
    .line 69
    invoke-virtual {p0}, Ld10;->v()V

    .line 70
    .line 71
    .line 72
    :cond_47
    return-void
.end method

.method public final a0()V
    .registers 8

    .line 1
    const/4 v0, 0x0

    .line 2
    iput v0, p0, Ld10;->m:I

    .line 3
    .line 4
    iget-object v1, p0, Ld10;->c:Lx51;

    .line 5
    .line 6
    invoke-virtual {v1}, Lx51;->c()Lw51;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    iput-object v1, p0, Ld10;->G:Lw51;

    .line 11
    .line 12
    const/16 v1, 0x64

    .line 13
    .line 14
    const/4 v2, 0x0

    .line 15
    invoke-virtual {p0, v1, v0, v2, v2}, Ld10;->S(IILjava/lang/Object;Ljava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    iget-object v1, p0, Ld10;->b:Lsj;

    .line 19
    .line 20
    invoke-virtual {v1}, Lsj;->t()V

    .line 21
    .line 22
    .line 23
    invoke-virtual {v1}, Lsj;->i()Lqr0;

    .line 24
    .line 25
    .line 26
    move-result-object v3

    .line 27
    iget-object v4, p0, Ld10;->x:Lw60;

    .line 28
    .line 29
    iget-boolean v5, p0, Ld10;->w:Z

    .line 30
    .line 31
    invoke-virtual {v4, v5}, Lw60;->c(I)V

    .line 32
    .line 33
    .line 34
    invoke-virtual {p0, v3}, Ld10;->f(Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v4

    .line 38
    iput-boolean v4, p0, Ld10;->w:Z

    .line 39
    .line 40
    iput-object v2, p0, Ld10;->K:Lqr0;

    .line 41
    .line 42
    iget-boolean v4, p0, Ld10;->q:Z

    .line 43
    .line 44
    if-nez v4, :cond_33

    .line 45
    .line 46
    invoke-virtual {v1}, Lsj;->e()Z

    .line 47
    .line 48
    .line 49
    move-result v4

    .line 50
    iput-boolean v4, p0, Ld10;->q:Z

    .line 51
    .line 52
    :cond_33
    iget-boolean v4, p0, Ld10;->C:Z

    .line 53
    .line 54
    if-nez v4, :cond_3d

    .line 55
    .line 56
    invoke-virtual {v1}, Lsj;->f()Z

    .line 57
    .line 58
    .line 59
    move-result v4

    .line 60
    iput-boolean v4, p0, Ld10;->C:Z

    .line 61
    .line 62
    :cond_3d
    iget-boolean v4, p0, Ld10;->C:Z

    .line 63
    .line 64
    if-eqz v4, :cond_53

    .line 65
    .line 66
    sget-object v4, Lxj;->a:Lk81;

    .line 67
    .line 68
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 69
    .line 70
    .line 71
    new-instance v5, Ll81;

    .line 72
    .line 73
    invoke-virtual {p0}, Ld10;->z()Lwj;

    .line 74
    .line 75
    .line 76
    move-result-object v6

    .line 77
    invoke-direct {v5, v6}, Ll81;-><init>(Ljava/lang/Object;)V

    .line 78
    .line 79
    .line 80
    invoke-virtual {v3, v4, v5}, Lqr0;->b(Llv0;Ltf1;)Lqr0;

    .line 81
    .line 82
    .line 83
    move-result-object v3

    .line 84
    :cond_53
    iput-object v3, p0, Ld10;->u:Lqr0;

    .line 85
    .line 86
    sget-object v4, Lh60;->a:Lk81;

    .line 87
    .line 88
    invoke-static {v3, v4}, Lgh0;->L(Lqr0;Llv0;)Ljava/lang/Object;

    .line 89
    .line 90
    .line 91
    move-result-object v3

    .line 92
    check-cast v3, Ljava/util/Set;

    .line 93
    .line 94
    if-eqz v3, :cond_69

    .line 95
    .line 96
    invoke-virtual {p0}, Ld10;->w()Luj;

    .line 97
    .line 98
    .line 99
    move-result-object v4

    .line 100
    invoke-interface {v3, v4}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 101
    .line 102
    .line 103
    invoke-virtual {v1, v3}, Lsj;->o(Ljava/util/Set;)V

    .line 104
    .line 105
    .line 106
    :cond_69
    invoke-virtual {v1}, Lsj;->g()J

    .line 107
    .line 108
    .line 109
    move-result-wide v3

    .line 110
    const/16 v1, 0x20

    .line 111
    .line 112
    ushr-long v5, v3, v1

    .line 113
    .line 114
    xor-long/2addr v3, v5

    .line 115
    long-to-int v1, v3

    .line 116
    invoke-virtual {p0, v1, v0, v2, v2}, Ld10;->S(IILjava/lang/Object;Ljava/lang/Object;)V

    .line 117
    .line 118
    .line 119
    return-void
.end method

.method public final b(Lm00;Ljava/lang/Object;)V
    .registers 7

    .line 1
    iget-boolean v0, p0, Ld10;->S:Z

    .line 2
    .line 3
    const/4 v1, 0x2

    .line 4
    const/4 v2, 0x1

    .line 5
    const/4 v3, 0x0

    .line 6
    if-eqz v0, :cond_1d

    .line 7
    .line 8
    iget-object p0, p0, Ld10;->O:Lbw;

    .line 9
    .line 10
    iget-object p0, p0, Lbw;->b:Lzo0;

    .line 11
    .line 12
    sget-object v0, Luo0;->c:Luo0;

    .line 13
    .line 14
    invoke-virtual {p0, v0}, Lzo0;->C(Lxo0;)V

    .line 15
    .line 16
    .line 17
    invoke-static {p0, v3, p2}, Ldd0;->v(Lzo0;ILjava/lang/Object;)V

    .line 18
    .line 19
    .line 20
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 21
    .line 22
    .line 23
    invoke-static {v1, p1}, Lvd1;->e(ILjava/lang/Object;)V

    .line 24
    .line 25
    .line 26
    invoke-static {p0, v2, p1}, Ldd0;->v(Lzo0;ILjava/lang/Object;)V

    .line 27
    .line 28
    .line 29
    return-void

    .line 30
    :cond_1d
    iget-object p0, p0, Ld10;->M:Lpj;

    .line 31
    .line 32
    invoke-virtual {p0}, Lpj;->b()V

    .line 33
    .line 34
    .line 35
    iget-object p0, p0, Lpj;->b:Lve;

    .line 36
    .line 37
    iget-object p0, p0, Lve;->F:Lzo0;

    .line 38
    .line 39
    sget-object v0, Luo0;->c:Luo0;

    .line 40
    .line 41
    invoke-virtual {p0, v0}, Lzo0;->C(Lxo0;)V

    .line 42
    .line 43
    .line 44
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 45
    .line 46
    .line 47
    invoke-static {v1, p1}, Lvd1;->e(ILjava/lang/Object;)V

    .line 48
    .line 49
    .line 50
    invoke-static {p0, v3, p2, v2, p1}, Ldd0;->w(Lzo0;ILjava/lang/Object;ILjava/lang/Object;)V

    .line 51
    .line 52
    .line 53
    return-void
.end method

.method public final b0(Lxv0;Ljava/lang/Object;)Z
    .registers 8

    .line 1
    iget-object v0, p1, Lxv0;->c:Ly00;

    .line 2
    .line 3
    if-nez v0, :cond_5

    .line 4
    .line 5
    goto :goto_65

    .line 6
    :cond_5
    iget-object v1, p0, Ld10;->G:Lw51;

    .line 7
    .line 8
    iget-object v1, v1, Lw51;->a:Lx51;

    .line 9
    .line 10
    invoke-static {v0}, Lac;->j(Ly00;)Ly00;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    invoke-virtual {v1, v0}, Lx51;->a(Ly00;)I

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    iget-boolean v1, p0, Ld10;->F:Z

    .line 19
    .line 20
    if-eqz v1, :cond_65

    .line 21
    .line 22
    iget-object v1, p0, Ld10;->G:Lw51;

    .line 23
    .line 24
    iget v1, v1, Lw51;->g:I

    .line 25
    .line 26
    if-lt v0, v1, :cond_65

    .line 27
    .line 28
    iget-object p0, p0, Ld10;->s:Ljava/util/ArrayList;

    .line 29
    .line 30
    invoke-static {v0, p0}, Lvn;->s(ILjava/util/List;)I

    .line 31
    .line 32
    .line 33
    move-result v1

    .line 34
    const/4 v2, 0x1

    .line 35
    const/4 v3, 0x0

    .line 36
    if-gez v1, :cond_36

    .line 37
    .line 38
    add-int/2addr v1, v2

    .line 39
    neg-int v1, v1

    .line 40
    instance-of v4, p2, Lsp;

    .line 41
    .line 42
    if-eqz v4, :cond_2c

    .line 43
    .line 44
    goto :goto_2d

    .line 45
    :cond_2c
    move-object p2, v3

    .line 46
    :goto_2d
    new-instance v3, Lu70;

    .line 47
    .line 48
    invoke-direct {v3, p1, v0, p2}, Lu70;-><init>(Lxv0;ILjava/lang/Object;)V

    .line 49
    .line 50
    .line 51
    invoke-virtual {p0, v1, v3}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    .line 52
    .line 53
    .line 54
    return v2

    .line 55
    :cond_36
    invoke-virtual {p0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 56
    .line 57
    .line 58
    move-result-object p0

    .line 59
    check-cast p0, Lu70;

    .line 60
    .line 61
    instance-of p1, p2, Lsp;

    .line 62
    .line 63
    if-eqz p1, :cond_62

    .line 64
    .line 65
    iget-object p1, p0, Lu70;->c:Ljava/lang/Object;

    .line 66
    .line 67
    if-nez p1, :cond_47

    .line 68
    .line 69
    iput-object p2, p0, Lu70;->c:Ljava/lang/Object;

    .line 70
    .line 71
    return v2

    .line 72
    :cond_47
    instance-of v0, p1, Lik0;

    .line 73
    .line 74
    if-eqz v0, :cond_51

    .line 75
    .line 76
    check-cast p1, Lik0;

    .line 77
    .line 78
    invoke-virtual {p1, p2}, Lik0;->a(Ljava/lang/Object;)Z

    .line 79
    .line 80
    .line 81
    return v2

    .line 82
    :cond_51
    sget-object v0, Lo01;->a:Lik0;

    .line 83
    .line 84
    new-instance v0, Lik0;

    .line 85
    .line 86
    const/4 v1, 0x2

    .line 87
    invoke-direct {v0, v1}, Lik0;-><init>(I)V

    .line 88
    .line 89
    .line 90
    invoke-virtual {v0, p1}, Lik0;->k(Ljava/lang/Object;)V

    .line 91
    .line 92
    .line 93
    invoke-virtual {v0, p2}, Lik0;->k(Ljava/lang/Object;)V

    .line 94
    .line 95
    .line 96
    iput-object v0, p0, Lu70;->c:Ljava/lang/Object;

    .line 97
    .line 98
    return v2

    .line 99
    :cond_62
    iput-object v3, p0, Lu70;->c:Ljava/lang/Object;

    .line 100
    .line 101
    return v2

    .line 102
    :cond_65
    :goto_65
    const/4 p0, 0x0

    .line 103
    return p0
.end method

.method public final c(F)Z
    .registers 4

    .line 1
    invoke-virtual {p0}, Ld10;->D()Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    instance-of v1, v0, Ljava/lang/Float;

    .line 6
    .line 7
    if-eqz v1, :cond_14

    .line 8
    .line 9
    check-cast v0, Ljava/lang/Number;

    .line 10
    .line 11
    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    cmpg-float v0, p1, v0

    .line 16
    .line 17
    if-nez v0, :cond_14

    .line 18
    .line 19
    const/4 p0, 0x0

    .line 20
    return p0

    .line 21
    :cond_14
    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    invoke-virtual {p0, p1}, Ld10;->h0(Ljava/lang/Object;)V

    .line 26
    .line 27
    .line 28
    const/4 p0, 0x1

    .line 29
    return p0
.end method

.method public final c0(Lhk0;)V
    .registers 19

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    iget-object v0, v0, Ld10;->s:Ljava/util/ArrayList;

    .line 6
    .line 7
    invoke-static {v0}, Lzi1;->t(Ljava/util/List;)I

    .line 8
    .line 9
    .line 10
    move-result v2

    .line 11
    :goto_a
    const/4 v4, -0x1

    .line 12
    if-ge v4, v2, :cond_36

    .line 13
    .line 14
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object v4

    .line 18
    check-cast v4, Lu70;

    .line 19
    .line 20
    iget-object v5, v4, Lu70;->a:Lxv0;

    .line 21
    .line 22
    iget-object v5, v5, Lxv0;->c:Ly00;

    .line 23
    .line 24
    if-eqz v5, :cond_1e

    .line 25
    .line 26
    invoke-static {v5}, Lac;->j(Ly00;)Ly00;

    .line 27
    .line 28
    .line 29
    move-result-object v3

    .line 30
    goto :goto_1f

    .line 31
    :cond_1e
    const/4 v3, 0x0

    .line 32
    :goto_1f
    if-eqz v3, :cond_30

    .line 33
    .line 34
    invoke-virtual {v3}, Ly00;->a()Z

    .line 35
    .line 36
    .line 37
    move-result v5

    .line 38
    if-eqz v5, :cond_30

    .line 39
    .line 40
    iget v5, v4, Lu70;->b:I

    .line 41
    .line 42
    iget v3, v3, Ly00;->a:I

    .line 43
    .line 44
    if-eq v5, v3, :cond_33

    .line 45
    .line 46
    iput v3, v4, Lu70;->b:I

    .line 47
    .line 48
    goto :goto_33

    .line 49
    :cond_30
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    :cond_33
    :goto_33
    add-int/lit8 v2, v2, -0x1

    .line 53
    .line 54
    goto :goto_a

    .line 55
    :cond_36
    iget-object v2, v1, Lhk0;->b:[Ljava/lang/Object;

    .line 56
    .line 57
    iget-object v4, v1, Lhk0;->c:[Ljava/lang/Object;

    .line 58
    .line 59
    iget-object v1, v1, Lhk0;->a:[J

    .line 60
    .line 61
    array-length v5, v1

    .line 62
    add-int/lit8 v5, v5, -0x2

    .line 63
    .line 64
    if-ltz v5, :cond_96

    .line 65
    .line 66
    const/4 v6, 0x0

    .line 67
    move v7, v6

    .line 68
    :goto_43
    aget-wide v8, v1, v7

    .line 69
    .line 70
    not-long v10, v8

    .line 71
    const/4 v12, 0x7

    .line 72
    shl-long/2addr v10, v12

    .line 73
    and-long/2addr v10, v8

    .line 74
    const-wide v12, -0x7f7f7f7f7f7f7f80L  # -2.937446524422997E-306

    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    and-long/2addr v10, v12

    .line 80
    cmp-long v10, v10, v12

    .line 81
    .line 82
    if-eqz v10, :cond_91

    .line 83
    .line 84
    sub-int v10, v7, v5

    .line 85
    .line 86
    not-int v10, v10

    .line 87
    ushr-int/lit8 v10, v10, 0x1f

    .line 88
    .line 89
    const/16 v11, 0x8

    .line 90
    .line 91
    rsub-int/lit8 v10, v10, 0x8

    .line 92
    .line 93
    move v12, v6

    .line 94
    :goto_5d
    if-ge v12, v10, :cond_8f

    .line 95
    .line 96
    const-wide/16 v13, 0xff

    .line 97
    .line 98
    and-long/2addr v13, v8

    .line 99
    const-wide/16 v15, 0x80

    .line 100
    .line 101
    cmp-long v13, v13, v15

    .line 102
    .line 103
    if-gez v13, :cond_8b

    .line 104
    .line 105
    shl-int/lit8 v13, v7, 0x3

    .line 106
    .line 107
    add-int/2addr v13, v12

    .line 108
    aget-object v14, v2, v13

    .line 109
    .line 110
    aget-object v13, v4, v13

    .line 111
    .line 112
    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 113
    .line 114
    .line 115
    check-cast v14, Lxv0;

    .line 116
    .line 117
    iget-object v15, v14, Lxv0;->c:Ly00;

    .line 118
    .line 119
    if-eqz v15, :cond_8b

    .line 120
    .line 121
    invoke-static {v15}, Lac;->j(Ly00;)Ly00;

    .line 122
    .line 123
    .line 124
    move-result-object v15

    .line 125
    iget v15, v15, Ly00;->a:I

    .line 126
    .line 127
    sget-object v3, Lnq0;->i:Lnq0;

    .line 128
    .line 129
    if-ne v13, v3, :cond_83

    .line 130
    .line 131
    const/4 v13, 0x0

    .line 132
    :cond_83
    new-instance v3, Lu70;

    .line 133
    .line 134
    invoke-direct {v3, v14, v15, v13}, Lu70;-><init>(Lxv0;ILjava/lang/Object;)V

    .line 135
    .line 136
    .line 137
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 138
    .line 139
    .line 140
    :cond_8b
    shr-long/2addr v8, v11

    .line 141
    add-int/lit8 v12, v12, 0x1

    .line 142
    .line 143
    goto :goto_5d

    .line 144
    :cond_8f
    if-ne v10, v11, :cond_96

    .line 145
    .line 146
    :cond_91
    if-eq v7, v5, :cond_96

    .line 147
    .line 148
    add-int/lit8 v7, v7, 0x1

    .line 149
    .line 150
    goto :goto_43

    .line 151
    :cond_96
    sget-object v1, Lvn;->h:Lv6;

    .line 152
    .line 153
    invoke-static {v0, v1}, Lxg;->N(Ljava/util/List;Ljava/util/Comparator;)V

    .line 154
    .line 155
    .line 156
    return-void
.end method

.method public final d(I)Z
    .registers 4

    .line 1
    invoke-virtual {p0}, Ld10;->D()Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    instance-of v1, v0, Ljava/lang/Integer;

    .line 6
    .line 7
    if-eqz v1, :cond_12

    .line 8
    .line 9
    check-cast v0, Ljava/lang/Number;

    .line 10
    .line 11
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-ne p1, v0, :cond_12

    .line 16
    .line 17
    const/4 p0, 0x0

    .line 18
    return p0

    .line 19
    :cond_12
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    invoke-virtual {p0, p1}, Ld10;->h0(Ljava/lang/Object;)V

    .line 24
    .line 25
    .line 26
    const/4 p0, 0x1

    .line 27
    return p0
.end method

.method public final d0(II)V
    .registers 7

    .line 1
    invoke-virtual {p0, p1}, Ld10;->i0(I)I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eq v0, p2, :cond_2b

    .line 6
    .line 7
    if-gez p1, :cond_17

    .line 8
    .line 9
    iget-object v0, p0, Ld10;->p:Lqj0;

    .line 10
    .line 11
    if-nez v0, :cond_13

    .line 12
    .line 13
    new-instance v0, Lqj0;

    .line 14
    .line 15
    invoke-direct {v0}, Lqj0;-><init>()V

    .line 16
    .line 17
    .line 18
    iput-object v0, p0, Ld10;->p:Lqj0;

    .line 19
    .line 20
    :cond_13
    invoke-virtual {v0, p1, p2}, Lqj0;->f(II)V

    .line 21
    .line 22
    .line 23
    return-void

    .line 24
    :cond_17
    iget-object v0, p0, Ld10;->o:[I

    .line 25
    .line 26
    if-nez v0, :cond_29

    .line 27
    .line 28
    iget-object v0, p0, Ld10;->G:Lw51;

    .line 29
    .line 30
    iget v0, v0, Lw51;->c:I

    .line 31
    .line 32
    new-array v1, v0, [I

    .line 33
    .line 34
    const/4 v2, -0x1

    .line 35
    const/4 v3, 0x0

    .line 36
    invoke-static {v1, v3, v0, v2}, Ljava/util/Arrays;->fill([IIII)V

    .line 37
    .line 38
    .line 39
    iput-object v1, p0, Ld10;->o:[I

    .line 40
    .line 41
    move-object v0, v1

    .line 42
    :cond_29
    aput p2, v0, p1

    .line 43
    .line 44
    :cond_2b
    return-void
.end method

.method public final e(J)Z
    .registers 5

    .line 1
    invoke-virtual {p0}, Ld10;->D()Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    instance-of v1, v0, Ljava/lang/Long;

    .line 6
    .line 7
    if-eqz v1, :cond_14

    .line 8
    .line 9
    check-cast v0, Ljava/lang/Number;

    .line 10
    .line 11
    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    .line 12
    .line 13
    .line 14
    move-result-wide v0

    .line 15
    cmp-long v0, p1, v0

    .line 16
    .line 17
    if-nez v0, :cond_14

    .line 18
    .line 19
    const/4 p0, 0x0

    .line 20
    return p0

    .line 21
    :cond_14
    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    invoke-virtual {p0, p1}, Ld10;->h0(Ljava/lang/Object;)V

    .line 26
    .line 27
    .line 28
    const/4 p0, 0x1

    .line 29
    return p0
.end method

.method public final e0(II)V
    .registers 9

    .line 1
    invoke-virtual {p0, p1}, Ld10;->i0(I)I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eq v0, p2, :cond_46

    .line 6
    .line 7
    sub-int/2addr p2, v0

    .line 8
    iget-object v0, p0, Ld10;->i:Ljava/util/ArrayList;

    .line 9
    .line 10
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    add-int/lit8 v1, v1, -0x1

    .line 15
    .line 16
    :goto_f
    const/4 v2, -0x1

    .line 17
    if-eq p1, v2, :cond_46

    .line 18
    .line 19
    invoke-virtual {p0, p1}, Ld10;->i0(I)I

    .line 20
    .line 21
    .line 22
    move-result v3

    .line 23
    add-int/2addr v3, p2

    .line 24
    invoke-virtual {p0, p1, v3}, Ld10;->d0(II)V

    .line 25
    .line 26
    .line 27
    move v4, v1

    .line 28
    :goto_1b
    if-ge v2, v4, :cond_32

    .line 29
    .line 30
    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v5

    .line 34
    check-cast v5, Lg10;

    .line 35
    .line 36
    if-eqz v5, :cond_2f

    .line 37
    .line 38
    invoke-virtual {v5, p1, v3}, Lg10;->a(II)Z

    .line 39
    .line 40
    .line 41
    move-result v5

    .line 42
    if-eqz v5, :cond_2f

    .line 43
    .line 44
    add-int/lit8 v4, v4, -0x1

    .line 45
    .line 46
    move v1, v4

    .line 47
    goto :goto_32

    .line 48
    :cond_2f
    add-int/lit8 v4, v4, -0x1

    .line 49
    .line 50
    goto :goto_1b

    .line 51
    :cond_32
    :goto_32
    iget-object v2, p0, Ld10;->G:Lw51;

    .line 52
    .line 53
    if-gez p1, :cond_39

    .line 54
    .line 55
    iget p1, v2, Lw51;->i:I

    .line 56
    .line 57
    goto :goto_f

    .line 58
    :cond_39
    invoke-virtual {v2, p1}, Lw51;->l(I)Z

    .line 59
    .line 60
    .line 61
    move-result v2

    .line 62
    if-nez v2, :cond_46

    .line 63
    .line 64
    iget-object v2, p0, Ld10;->G:Lw51;

    .line 65
    .line 66
    invoke-virtual {v2, p1}, Lw51;->q(I)I

    .line 67
    .line 68
    .line 69
    move-result p1

    .line 70
    goto :goto_f

    .line 71
    :cond_46
    return-void
.end method

.method public final f(Ljava/lang/Object;)Z
    .registers 3

    .line 1
    invoke-virtual {p0}, Ld10;->D()Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-static {v0, p1}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-nez v0, :cond_f

    .line 10
    .line 11
    invoke-virtual {p0, p1}, Ld10;->h0(Ljava/lang/Object;)V

    .line 12
    .line 13
    .line 14
    const/4 p0, 0x1

    .line 15
    return p0

    .line 16
    :cond_f
    const/4 p0, 0x0

    .line 17
    return p0
.end method

.method public final f0(Lqr0;Lqr0;)Lqr0;
    .registers 5

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    new-instance v0, Lpr0;

    .line 5
    .line 6
    invoke-direct {v0, p1}, Lpr0;-><init>(Lqr0;)V

    .line 7
    .line 8
    .line 9
    invoke-virtual {v0, p2}, Ltr0;->putAll(Ljava/util/Map;)V

    .line 10
    .line 11
    .line 12
    invoke-virtual {v0}, Lpr0;->b()Lqr0;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    const/16 v0, 0xcc

    .line 17
    .line 18
    sget-object v1, Lqj;->d:Lqn0;

    .line 19
    .line 20
    invoke-virtual {p0, v0, v1}, Ld10;->U(ILqn0;)V

    .line 21
    .line 22
    .line 23
    invoke-virtual {p0}, Ld10;->D()Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    invoke-virtual {p0, p1}, Ld10;->h0(Ljava/lang/Object;)V

    .line 27
    .line 28
    .line 29
    invoke-virtual {p0}, Ld10;->D()Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    invoke-virtual {p0, p2}, Ld10;->h0(Ljava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    const/4 p2, 0x0

    .line 36
    invoke-virtual {p0, p2}, Ld10;->p(Z)V

    .line 37
    .line 38
    .line 39
    return-object p1
.end method

.method public final g(Z)Z
    .registers 4

    .line 1
    invoke-virtual {p0}, Ld10;->D()Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    instance-of v1, v0, Ljava/lang/Boolean;

    .line 6
    .line 7
    if-eqz v1, :cond_12

    .line 8
    .line 9
    check-cast v0, Ljava/lang/Boolean;

    .line 10
    .line 11
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-ne p1, v0, :cond_12

    .line 16
    .line 17
    const/4 p0, 0x0

    .line 18
    return p0

    .line 19
    :cond_12
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    invoke-virtual {p0, p1}, Ld10;->h0(Ljava/lang/Object;)V

    .line 24
    .line 25
    .line 26
    const/4 p0, 0x1

    .line 27
    return p0
.end method

.method public final g0(Ljava/lang/Object;)V
    .registers 5

    .line 1
    instance-of v0, p1, Lww0;

    .line 2
    .line 3
    if-eqz v0, :cond_29

    .line 4
    .line 5
    new-instance v0, Lxw0;

    .line 6
    .line 7
    move-object v1, p1

    .line 8
    check-cast v1, Lww0;

    .line 9
    .line 10
    iget v2, p0, Ld10;->m:I

    .line 11
    .line 12
    add-int/lit8 v2, v2, -0x1

    .line 13
    .line 14
    invoke-direct {v0, v1, v2}, Lxw0;-><init>(Lww0;I)V

    .line 15
    .line 16
    .line 17
    iget-boolean v1, p0, Ld10;->S:Z

    .line 18
    .line 19
    if-eqz v1, :cond_23

    .line 20
    .line 21
    iget-object v1, p0, Ld10;->M:Lpj;

    .line 22
    .line 23
    iget-object v1, v1, Lpj;->b:Lve;

    .line 24
    .line 25
    iget-object v1, v1, Lve;->F:Lzo0;

    .line 26
    .line 27
    sget-object v2, Lko0;->c:Lko0;

    .line 28
    .line 29
    invoke-virtual {v1, v2}, Lzo0;->C(Lxo0;)V

    .line 30
    .line 31
    .line 32
    const/4 v2, 0x0

    .line 33
    invoke-static {v1, v2, v0}, Ldd0;->v(Lzo0;ILjava/lang/Object;)V

    .line 34
    .line 35
    .line 36
    :cond_23
    iget-object v1, p0, Ld10;->d:Lkk0;

    .line 37
    .line 38
    invoke-virtual {v1, p1}, Lkk0;->add(Ljava/lang/Object;)Z

    .line 39
    .line 40
    .line 41
    move-object p1, v0

    .line 42
    :cond_29
    invoke-virtual {p0, p1}, Ld10;->h0(Ljava/lang/Object;)V

    .line 43
    .line 44
    .line 45
    return-void
.end method

.method public final h(Ljava/lang/Object;)Z
    .registers 3

    .line 1
    invoke-virtual {p0}, Ld10;->D()Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    if-eq v0, p1, :cond_b

    .line 6
    .line 7
    invoke-virtual {p0, p1}, Ld10;->h0(Ljava/lang/Object;)V

    .line 8
    .line 9
    .line 10
    const/4 p0, 0x1

    .line 11
    return p0

    .line 12
    :cond_b
    const/4 p0, 0x0

    .line 13
    return p0
.end method

.method public final h0(Ljava/lang/Object;)V
    .registers 8

    .line 1
    iget-boolean v0, p0, Ld10;->S:Z

    .line 2
    .line 3
    if-eqz v0, :cond_35

    .line 4
    .line 5
    iget-object p0, p0, Ld10;->I:La61;

    .line 6
    .line 7
    iget v0, p0, La61;->n:I

    .line 8
    .line 9
    if-lez v0, :cond_31

    .line 10
    .line 11
    iget v0, p0, La61;->i:I

    .line 12
    .line 13
    iget v1, p0, La61;->k:I

    .line 14
    .line 15
    if-eq v0, v1, :cond_31

    .line 16
    .line 17
    iget-object v0, p0, La61;->s:Lsj0;

    .line 18
    .line 19
    if-nez v0, :cond_19

    .line 20
    .line 21
    new-instance v0, Lsj0;

    .line 22
    .line 23
    invoke-direct {v0}, Lsj0;-><init>()V

    .line 24
    .line 25
    .line 26
    :cond_19
    iput-object v0, p0, La61;->s:Lsj0;

    .line 27
    .line 28
    iget p0, p0, La61;->v:I

    .line 29
    .line 30
    invoke-virtual {v0, p0}, Ll60;->b(I)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v1

    .line 34
    if-nez v1, :cond_2b

    .line 35
    .line 36
    new-instance v1, Lak0;

    .line 37
    .line 38
    invoke-direct {v1}, Lak0;-><init>()V

    .line 39
    .line 40
    .line 41
    invoke-virtual {v0, p0, v1}, Lsj0;->h(ILjava/lang/Object;)V

    .line 42
    .line 43
    .line 44
    :cond_2b
    check-cast v1, Lak0;

    .line 45
    .line 46
    invoke-virtual {v1, p1}, Lak0;->a(Ljava/lang/Object;)V

    .line 47
    .line 48
    .line 49
    goto :goto_34

    .line 50
    :cond_31
    invoke-virtual {p0, p1}, La61;->F(Ljava/lang/Object;)Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    :goto_34
    return-void

    .line 54
    :cond_35
    iget-object v0, p0, Ld10;->G:Lw51;

    .line 55
    .line 56
    iget-boolean v1, v0, Lw51;->n:Z

    .line 57
    .line 58
    iget-object v2, p0, Ld10;->M:Lpj;

    .line 59
    .line 60
    const/4 v3, 0x0

    .line 61
    const/4 v4, 0x1

    .line 62
    if-eqz v1, :cond_9b

    .line 63
    .line 64
    iget v1, v0, Lw51;->l:I

    .line 65
    .line 66
    iget-object v5, v0, Lw51;->b:[I

    .line 67
    .line 68
    iget v0, v0, Lw51;->i:I

    .line 69
    .line 70
    invoke-static {v5, v0}, Lz51;->b([II)I

    .line 71
    .line 72
    .line 73
    move-result v0

    .line 74
    sub-int/2addr v1, v0

    .line 75
    sub-int/2addr v1, v4

    .line 76
    iget-object v0, v2, Lpj;->a:Ld10;

    .line 77
    .line 78
    iget-object v0, v0, Ld10;->G:Lw51;

    .line 79
    .line 80
    iget v0, v0, Lw51;->i:I

    .line 81
    .line 82
    iget v5, v2, Lpj;->f:I

    .line 83
    .line 84
    sub-int/2addr v0, v5

    .line 85
    if-gez v0, :cond_7b

    .line 86
    .line 87
    iget-object p0, p0, Ld10;->G:Lw51;

    .line 88
    .line 89
    iget v0, p0, Lw51;->i:I

    .line 90
    .line 91
    invoke-virtual {p0, v0}, Lw51;->a(I)Ly00;

    .line 92
    .line 93
    .line 94
    move-result-object p0

    .line 95
    iget-object v0, v2, Lpj;->b:Lve;

    .line 96
    .line 97
    iget-object v0, v0, Lve;->F:Lzo0;

    .line 98
    .line 99
    sget-object v2, Lfo0;->f:Lfo0;

    .line 100
    .line 101
    invoke-virtual {v0, v2}, Lzo0;->C(Lxo0;)V

    .line 102
    .line 103
    .line 104
    invoke-static {v0, v3, p1, v4, p0}, Ldd0;->w(Lzo0;ILjava/lang/Object;ILjava/lang/Object;)V

    .line 105
    .line 106
    .line 107
    iget-object p0, v0, Lzo0;->d:[I

    .line 108
    .line 109
    iget p1, v0, Lzo0;->e:I

    .line 110
    .line 111
    iget-object v2, v0, Lzo0;->b:[Lxo0;

    .line 112
    .line 113
    iget v0, v0, Lzo0;->c:I

    .line 114
    .line 115
    sub-int/2addr v0, v4

    .line 116
    aget-object v0, v2, v0

    .line 117
    .line 118
    iget v0, v0, Lxo0;->a:I

    .line 119
    .line 120
    sub-int/2addr p1, v0

    .line 121
    aput v1, p0, p1

    .line 122
    .line 123
    return-void

    .line 124
    :cond_7b
    invoke-virtual {v2, v4}, Lpj;->d(Z)V

    .line 125
    .line 126
    .line 127
    iget-object p0, v2, Lpj;->b:Lve;

    .line 128
    .line 129
    iget-object p0, p0, Lve;->F:Lzo0;

    .line 130
    .line 131
    sget-object v0, Lfo0;->g:Lfo0;

    .line 132
    .line 133
    invoke-virtual {p0, v0}, Lzo0;->C(Lxo0;)V

    .line 134
    .line 135
    .line 136
    invoke-static {p0, v3, p1}, Ldd0;->v(Lzo0;ILjava/lang/Object;)V

    .line 137
    .line 138
    .line 139
    iget-object p1, p0, Lzo0;->d:[I

    .line 140
    .line 141
    iget v0, p0, Lzo0;->e:I

    .line 142
    .line 143
    iget-object v2, p0, Lzo0;->b:[Lxo0;

    .line 144
    .line 145
    iget p0, p0, Lzo0;->c:I

    .line 146
    .line 147
    sub-int/2addr p0, v4

    .line 148
    aget-object p0, v2, p0

    .line 149
    .line 150
    iget p0, p0, Lxo0;->a:I

    .line 151
    .line 152
    sub-int/2addr v0, p0

    .line 153
    aput v1, p1, v0

    .line 154
    .line 155
    return-void

    .line 156
    :cond_9b
    iget p0, v0, Lw51;->i:I

    .line 157
    .line 158
    invoke-virtual {v0, p0}, Lw51;->a(I)Ly00;

    .line 159
    .line 160
    .line 161
    move-result-object p0

    .line 162
    iget-object v0, v2, Lpj;->b:Lve;

    .line 163
    .line 164
    iget-object v0, v0, Lve;->F:Lzo0;

    .line 165
    .line 166
    sget-object v1, Lsn0;->c:Lsn0;

    .line 167
    .line 168
    invoke-virtual {v0, v1}, Lzo0;->C(Lxo0;)V

    .line 169
    .line 170
    .line 171
    invoke-static {v0, v3, p0, v4, p1}, Ldd0;->w(Lzo0;ILjava/lang/Object;ILjava/lang/Object;)V

    .line 172
    .line 173
    .line 174
    return-void
.end method

.method public final i()V
    .registers 5

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-object v0, p0, Ld10;->j:Lg10;

    .line 3
    .line 4
    const/4 v1, 0x0

    .line 5
    iput v1, p0, Ld10;->k:I

    .line 6
    .line 7
    iput v1, p0, Ld10;->l:I

    .line 8
    .line 9
    const-wide/16 v2, 0x0

    .line 10
    .line 11
    iput-wide v2, p0, Ld10;->T:J

    .line 12
    .line 13
    iput-boolean v1, p0, Ld10;->r:Z

    .line 14
    .line 15
    iget-object v2, p0, Ld10;->M:Lpj;

    .line 16
    .line 17
    iput-boolean v1, v2, Lpj;->c:Z

    .line 18
    .line 19
    iget-object v3, v2, Lpj;->d:Lw60;

    .line 20
    .line 21
    iput v1, v3, Lw60;->b:I

    .line 22
    .line 23
    iput v1, v2, Lpj;->f:I

    .line 24
    .line 25
    const/4 v3, 0x1

    .line 26
    iput-boolean v3, v2, Lpj;->e:Z

    .line 27
    .line 28
    iput v1, v2, Lpj;->g:I

    .line 29
    .line 30
    iget-object v3, v2, Lpj;->h:Ljava/util/ArrayList;

    .line 31
    .line 32
    invoke-virtual {v3}, Ljava/util/ArrayList;->clear()V

    .line 33
    .line 34
    .line 35
    const/4 v3, -0x1

    .line 36
    iput v3, v2, Lpj;->i:I

    .line 37
    .line 38
    iput v3, v2, Lpj;->j:I

    .line 39
    .line 40
    iput v3, v2, Lpj;->k:I

    .line 41
    .line 42
    iput v1, v2, Lpj;->l:I

    .line 43
    .line 44
    iget-object v1, p0, Ld10;->E:Ljava/util/ArrayList;

    .line 45
    .line 46
    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    .line 47
    .line 48
    .line 49
    iput-object v0, p0, Ld10;->o:[I

    .line 50
    .line 51
    iput-object v0, p0, Ld10;->p:Lqj0;

    .line 52
    .line 53
    return-void
.end method

.method public final i0(I)I
    .registers 4

    .line 1
    if-gez p1, :cond_25

    .line 2
    .line 3
    iget-object p0, p0, Ld10;->p:Lqj0;

    .line 4
    .line 5
    const/4 v0, 0x0

    .line 6
    if-eqz p0, :cond_24

    .line 7
    .line 8
    invoke-virtual {p0, p1}, Lqj0;->c(I)I

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    if-ltz v1, :cond_24

    .line 13
    .line 14
    invoke-virtual {p0, p1}, Lqj0;->c(I)I

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-ltz v0, :cond_18

    .line 19
    .line 20
    iget-object p0, p0, Lqj0;->c:[I

    .line 21
    .line 22
    aget p0, p0, v0

    .line 23
    .line 24
    return p0

    .line 25
    :cond_18
    const-string p0, "Cannot find value for key "

    .line 26
    .line 27
    invoke-static {p0, p1}, Lfu0;->E(Ljava/lang/String;I)Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    new-instance p1, Ljava/util/NoSuchElementException;

    .line 32
    .line 33
    invoke-direct {p1, p0}, Ljava/util/NoSuchElementException;-><init>(Ljava/lang/String;)V

    .line 34
    .line 35
    .line 36
    throw p1

    .line 37
    :cond_24
    return v0

    .line 38
    :cond_25
    iget-object v0, p0, Ld10;->o:[I

    .line 39
    .line 40
    if-eqz v0, :cond_2e

    .line 41
    .line 42
    aget v0, v0, p1

    .line 43
    .line 44
    if-ltz v0, :cond_2e

    .line 45
    .line 46
    return v0

    .line 47
    :cond_2e
    iget-object p0, p0, Ld10;->G:Lw51;

    .line 48
    .line 49
    invoke-virtual {p0, p1}, Lw51;->o(I)I

    .line 50
    .line 51
    .line 52
    move-result p0

    .line 53
    return p0
.end method

.method public final j(Llv0;)Ljava/lang/Object;
    .registers 2

    .line 1
    invoke-virtual {p0}, Ld10;->l()Lqr0;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    invoke-static {p0, p1}, Lgh0;->L(Lqr0;Llv0;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    return-object p0
.end method

.method public final j0()V
    .registers 4

    .line 1
    iget-boolean v0, p0, Ld10;->r:Z

    .line 2
    .line 3
    if-nez v0, :cond_9

    .line 4
    .line 5
    const-string v0, "A call to createNode(), emitNode() or useNode() expected was not expected"

    .line 6
    .line 7
    invoke-static {v0}, Lqj;->a(Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    :cond_9
    const/4 v0, 0x0

    .line 11
    iput-boolean v0, p0, Ld10;->r:Z

    .line 12
    .line 13
    iget-boolean v0, p0, Ld10;->S:Z

    .line 14
    .line 15
    if-eqz v0, :cond_15

    .line 16
    .line 17
    const-string v0, "useNode() called while inserting"

    .line 18
    .line 19
    invoke-static {v0}, Lqj;->a(Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    :cond_15
    iget-object v0, p0, Ld10;->G:Lw51;

    .line 23
    .line 24
    iget v1, v0, Lw51;->i:I

    .line 25
    .line 26
    invoke-virtual {v0, v1}, Lw51;->n(I)Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    iget-object v1, p0, Ld10;->M:Lpj;

    .line 31
    .line 32
    invoke-virtual {v1}, Lpj;->c()V

    .line 33
    .line 34
    .line 35
    iget-object v2, v1, Lpj;->h:Ljava/util/ArrayList;

    .line 36
    .line 37
    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 38
    .line 39
    .line 40
    iget-boolean p0, p0, Ld10;->y:Z

    .line 41
    .line 42
    if-eqz p0, :cond_3b

    .line 43
    .line 44
    instance-of p0, v0, Lwi;

    .line 45
    .line 46
    if-eqz p0, :cond_3b

    .line 47
    .line 48
    invoke-virtual {v1}, Lpj;->b()V

    .line 49
    .line 50
    .line 51
    iget-object p0, v1, Lpj;->b:Lve;

    .line 52
    .line 53
    iget-object p0, p0, Lve;->F:Lzo0;

    .line 54
    .line 55
    sget-object v0, Lwo0;->c:Lwo0;

    .line 56
    .line 57
    invoke-virtual {p0, v0}, Lzo0;->C(Lxo0;)V

    .line 58
    .line 59
    .line 60
    :cond_3b
    return-void
.end method

.method public final k(Lxz;)V
    .registers 10

    .line 1
    iget-boolean v0, p0, Ld10;->r:Z

    .line 2
    .line 3
    if-nez v0, :cond_9

    .line 4
    .line 5
    const-string v0, "A call to createNode(), emitNode() or useNode() expected was not expected"

    .line 6
    .line 7
    invoke-static {v0}, Lqj;->a(Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    :cond_9
    const/4 v0, 0x0

    .line 11
    iput-boolean v0, p0, Ld10;->r:Z

    .line 12
    .line 13
    iget-boolean v1, p0, Ld10;->S:Z

    .line 14
    .line 15
    if-nez v1, :cond_15

    .line 16
    .line 17
    const-string v1, "createNode() can only be called when inserting"

    .line 18
    .line 19
    invoke-static {v1}, Lqj;->a(Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    :cond_15
    iget-object v1, p0, Ld10;->n:Lw60;

    .line 23
    .line 24
    iget-object v2, v1, Lw60;->a:[I

    .line 25
    .line 26
    iget v1, v1, Lw60;->b:I

    .line 27
    .line 28
    const/4 v3, 0x1

    .line 29
    sub-int/2addr v1, v3

    .line 30
    aget v1, v2, v1

    .line 31
    .line 32
    iget-object v2, p0, Ld10;->I:La61;

    .line 33
    .line 34
    iget v4, v2, La61;->v:I

    .line 35
    .line 36
    invoke-virtual {v2, v4}, La61;->b(I)Ly00;

    .line 37
    .line 38
    .line 39
    move-result-object v2

    .line 40
    iget v4, p0, Ld10;->l:I

    .line 41
    .line 42
    add-int/2addr v4, v3

    .line 43
    iput v4, p0, Ld10;->l:I

    .line 44
    .line 45
    iget-object p0, p0, Ld10;->O:Lbw;

    .line 46
    .line 47
    iget-object v4, p0, Lbw;->b:Lzo0;

    .line 48
    .line 49
    sget-object v5, Lfo0;->d:Lfo0;

    .line 50
    .line 51
    invoke-virtual {v4, v5}, Lzo0;->C(Lxo0;)V

    .line 52
    .line 53
    .line 54
    invoke-static {v4, v0, p1}, Ldd0;->v(Lzo0;ILjava/lang/Object;)V

    .line 55
    .line 56
    .line 57
    iget-object p1, v4, Lzo0;->d:[I

    .line 58
    .line 59
    iget v5, v4, Lzo0;->e:I

    .line 60
    .line 61
    iget-object v6, v4, Lzo0;->b:[Lxo0;

    .line 62
    .line 63
    iget v7, v4, Lzo0;->c:I

    .line 64
    .line 65
    sub-int/2addr v7, v3

    .line 66
    aget-object v6, v6, v7

    .line 67
    .line 68
    iget v6, v6, Lxo0;->a:I

    .line 69
    .line 70
    sub-int/2addr v5, v6

    .line 71
    aput v1, p1, v5

    .line 72
    .line 73
    invoke-static {v4, v3, v2}, Ldd0;->v(Lzo0;ILjava/lang/Object;)V

    .line 74
    .line 75
    .line 76
    iget-object p0, p0, Lbw;->c:Lzo0;

    .line 77
    .line 78
    sget-object p1, Lfo0;->e:Lfo0;

    .line 79
    .line 80
    invoke-virtual {p0, p1}, Lzo0;->C(Lxo0;)V

    .line 81
    .line 82
    .line 83
    iget-object p1, p0, Lzo0;->d:[I

    .line 84
    .line 85
    iget v4, p0, Lzo0;->e:I

    .line 86
    .line 87
    iget-object v5, p0, Lzo0;->b:[Lxo0;

    .line 88
    .line 89
    iget v6, p0, Lzo0;->c:I

    .line 90
    .line 91
    sub-int/2addr v6, v3

    .line 92
    aget-object v3, v5, v6

    .line 93
    .line 94
    iget v3, v3, Lxo0;->a:I

    .line 95
    .line 96
    sub-int/2addr v4, v3

    .line 97
    aput v1, p1, v4

    .line 98
    .line 99
    invoke-static {p0, v0, v2}, Ldd0;->v(Lzo0;ILjava/lang/Object;)V

    .line 100
    .line 101
    .line 102
    return-void
.end method

.method public final l()Lqr0;
    .registers 7

    .line 1
    iget-object v0, p0, Ld10;->K:Lqr0;

    .line 2
    .line 3
    if-eqz v0, :cond_5

    .line 4
    .line 5
    return-object v0

    .line 6
    :cond_5
    iget-object v0, p0, Ld10;->G:Lw51;

    .line 7
    .line 8
    iget v0, v0, Lw51;->i:I

    .line 9
    .line 10
    iget-boolean v1, p0, Ld10;->S:Z

    .line 11
    .line 12
    sget-object v2, Lqj;->c:Lqn0;

    .line 13
    .line 14
    const/16 v3, 0xca

    .line 15
    .line 16
    if-eqz v1, :cond_46

    .line 17
    .line 18
    iget-boolean v1, p0, Ld10;->J:Z

    .line 19
    .line 20
    if-eqz v1, :cond_46

    .line 21
    .line 22
    iget-object v1, p0, Ld10;->I:La61;

    .line 23
    .line 24
    iget v1, v1, La61;->v:I

    .line 25
    .line 26
    :goto_19
    if-lez v1, :cond_46

    .line 27
    .line 28
    iget-object v4, p0, Ld10;->I:La61;

    .line 29
    .line 30
    invoke-virtual {v4, v1}, La61;->s(I)I

    .line 31
    .line 32
    .line 33
    move-result v4

    .line 34
    if-ne v4, v3, :cond_3d

    .line 35
    .line 36
    iget-object v4, p0, Ld10;->I:La61;

    .line 37
    .line 38
    invoke-virtual {v4, v1}, La61;->t(I)Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object v4

    .line 42
    invoke-static {v4, v2}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 43
    .line 44
    .line 45
    move-result v4

    .line 46
    if-eqz v4, :cond_3d

    .line 47
    .line 48
    iget-object v0, p0, Ld10;->I:La61;

    .line 49
    .line 50
    invoke-virtual {v0, v1}, La61;->q(I)Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object v0

    .line 54
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 55
    .line 56
    .line 57
    check-cast v0, Lqr0;

    .line 58
    .line 59
    iput-object v0, p0, Ld10;->K:Lqr0;

    .line 60
    .line 61
    return-object v0

    .line 62
    :cond_3d
    iget-object v4, p0, Ld10;->I:La61;

    .line 63
    .line 64
    iget-object v5, v4, La61;->b:[I

    .line 65
    .line 66
    invoke-virtual {v4, v5, v1}, La61;->E([II)I

    .line 67
    .line 68
    .line 69
    move-result v1

    .line 70
    goto :goto_19

    .line 71
    :cond_46
    iget-object v1, p0, Ld10;->G:Lw51;

    .line 72
    .line 73
    iget v1, v1, Lw51;->c:I

    .line 74
    .line 75
    if-lez v1, :cond_88

    .line 76
    .line 77
    :goto_4c
    if-lez v0, :cond_88

    .line 78
    .line 79
    iget-object v1, p0, Ld10;->G:Lw51;

    .line 80
    .line 81
    invoke-virtual {v1, v0}, Lw51;->i(I)I

    .line 82
    .line 83
    .line 84
    move-result v1

    .line 85
    if-ne v1, v3, :cond_81

    .line 86
    .line 87
    iget-object v1, p0, Ld10;->G:Lw51;

    .line 88
    .line 89
    iget-object v4, v1, Lw51;->b:[I

    .line 90
    .line 91
    invoke-virtual {v1, v4, v0}, Lw51;->p([II)Ljava/lang/Object;

    .line 92
    .line 93
    .line 94
    move-result-object v1

    .line 95
    invoke-static {v1, v2}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 96
    .line 97
    .line 98
    move-result v1

    .line 99
    if-eqz v1, :cond_81

    .line 100
    .line 101
    iget-object v1, p0, Ld10;->v:Lsj0;

    .line 102
    .line 103
    if-eqz v1, :cond_70

    .line 104
    .line 105
    invoke-virtual {v1, v0}, Ll60;->b(I)Ljava/lang/Object;

    .line 106
    .line 107
    .line 108
    move-result-object v1

    .line 109
    check-cast v1, Lqr0;

    .line 110
    .line 111
    if-nez v1, :cond_7e

    .line 112
    .line 113
    :cond_70
    iget-object v1, p0, Ld10;->G:Lw51;

    .line 114
    .line 115
    iget-object v2, v1, Lw51;->b:[I

    .line 116
    .line 117
    invoke-virtual {v1, v2, v0}, Lw51;->b([II)Ljava/lang/Object;

    .line 118
    .line 119
    .line 120
    move-result-object v0

    .line 121
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 122
    .line 123
    .line 124
    move-object v1, v0

    .line 125
    check-cast v1, Lqr0;

    .line 126
    .line 127
    :cond_7e
    iput-object v1, p0, Ld10;->K:Lqr0;

    .line 128
    .line 129
    return-object v1

    .line 130
    :cond_81
    iget-object v1, p0, Ld10;->G:Lw51;

    .line 131
    .line 132
    invoke-virtual {v1, v0}, Lw51;->q(I)I

    .line 133
    .line 134
    .line 135
    move-result v0

    .line 136
    goto :goto_4c

    .line 137
    :cond_88
    iget-object v0, p0, Ld10;->u:Lqr0;

    .line 138
    .line 139
    iput-object v0, p0, Ld10;->K:Lqr0;

    .line 140
    .line 141
    return-object v0
.end method

.method public final m()Lej;
    .registers 10

    .line 1
    iget-object v0, p0, Ld10;->b:Lsj;

    .line 2
    .line 3
    invoke-virtual {v0}, Lsj;->k()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const/4 v1, 0x0

    .line 8
    if-eqz v0, :cond_7a

    .line 9
    .line 10
    new-instance v0, Lqe0;

    .line 11
    .line 12
    const/16 v2, 0xa

    .line 13
    .line 14
    invoke-direct {v0, v2}, Lqe0;-><init>(I)V

    .line 15
    .line 16
    .line 17
    iget-object v2, p0, Ld10;->I:La61;

    .line 18
    .line 19
    iget v3, v2, La61;->t:I

    .line 20
    .line 21
    invoke-static {v2, v1, v3, v1}, Lwl1;->p(La61;Ljava/lang/Integer;ILjava/lang/Integer;)Ljava/util/List;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    invoke-virtual {v0, v1}, Lqe0;->addAll(Ljava/util/Collection;)Z

    .line 26
    .line 27
    .line 28
    iget-object v1, p0, Ld10;->G:Lw51;

    .line 29
    .line 30
    iget-boolean v2, v1, Lw51;->f:Z

    .line 31
    .line 32
    iget-object v3, v1, Lw51;->b:[I

    .line 33
    .line 34
    if-nez v2, :cond_63

    .line 35
    .line 36
    iget v2, v1, Lw51;->c:I

    .line 37
    .line 38
    if-eqz v2, :cond_63

    .line 39
    .line 40
    new-instance v2, Ltv0;

    .line 41
    .line 42
    invoke-direct {v2, v1}, Ltv0;-><init>(Ljava/lang/Object;)V

    .line 43
    .line 44
    .line 45
    iget v4, v1, Lw51;->i:I

    .line 46
    .line 47
    iget v5, v1, Lw51;->l:I

    .line 48
    .line 49
    invoke-static {v3, v4}, Lz51;->b([II)I

    .line 50
    .line 51
    .line 52
    move-result v6

    .line 53
    sub-int/2addr v5, v6

    .line 54
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 55
    .line 56
    .line 57
    move-result-object v5

    .line 58
    :goto_39
    if-ltz v4, :cond_5e

    .line 59
    .line 60
    invoke-virtual {v1, v4}, Lw51;->k(I)Z

    .line 61
    .line 62
    .line 63
    move-result v6

    .line 64
    if-eqz v6, :cond_46

    .line 65
    .line 66
    invoke-virtual {v1, v3, v4}, Lw51;->p([II)Ljava/lang/Object;

    .line 67
    .line 68
    .line 69
    move-result-object v6

    .line 70
    goto :goto_48

    .line 71
    :cond_46
    sget-object v6, Loj;->a:Lnq0;

    .line 72
    .line 73
    :goto_48
    invoke-virtual {v1, v4}, Lw51;->i(I)I

    .line 74
    .line 75
    .line 76
    move-result v7

    .line 77
    iget-object v8, v1, Lw51;->a:Lx51;

    .line 78
    .line 79
    invoke-virtual {v8, v4}, Lx51;->g(I)Lf10;

    .line 80
    .line 81
    .line 82
    move-result-object v8

    .line 83
    invoke-virtual {v2, v7, v6, v8, v5}, Lfj;->f(ILjava/lang/Object;Lf10;Ljava/lang/Object;)V

    .line 84
    .line 85
    .line 86
    invoke-virtual {v1, v4}, Lw51;->a(I)Ly00;

    .line 87
    .line 88
    .line 89
    move-result-object v5

    .line 90
    invoke-virtual {v1, v4}, Lw51;->q(I)I

    .line 91
    .line 92
    .line 93
    move-result v4

    .line 94
    goto :goto_39

    .line 95
    :cond_5e
    iget-object v1, v2, Lfj;->a:Ljava/lang/Object;

    .line 96
    .line 97
    check-cast v1, Ljava/util/ArrayList;

    .line 98
    .line 99
    goto :goto_65

    .line 100
    :cond_63
    sget-object v1, Lut;->e:Lut;

    .line 101
    .line 102
    :goto_65
    invoke-virtual {v0, v1}, Lqe0;->addAll(Ljava/util/Collection;)Z

    .line 103
    .line 104
    .line 105
    invoke-virtual {p0}, Ld10;->E()Ljava/util/List;

    .line 106
    .line 107
    .line 108
    move-result-object v1

    .line 109
    invoke-virtual {v0, v1}, Lqe0;->addAll(Ljava/util/Collection;)Z

    .line 110
    .line 111
    .line 112
    invoke-static {v0}, Lzi1;->o(Lqe0;)Lqe0;

    .line 113
    .line 114
    .line 115
    move-result-object v0

    .line 116
    iget-boolean p0, p0, Ld10;->C:Z

    .line 117
    .line 118
    new-instance v1, Lej;

    .line 119
    .line 120
    invoke-direct {v1, v0, p0}, Lej;-><init>(Ljava/util/List;Z)V

    .line 121
    .line 122
    .line 123
    :cond_7a
    return-object v1
.end method

.method public final n(Lhk0;Lm00;)V
    .registers 10

    .line 1
    const-string v0, "Check failed"

    .line 2
    .line 3
    iget-object v1, p0, Ld10;->s:Ljava/util/ArrayList;

    .line 4
    .line 5
    iget-boolean v2, p0, Ld10;->F:Z

    .line 6
    .line 7
    if-eqz v2, :cond_d

    .line 8
    .line 9
    const-string v2, "Reentrant composition is not supported"

    .line 10
    .line 11
    invoke-static {v2}, Lqj;->a(Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    :cond_d
    iget-object v2, p0, Ld10;->g:Lpg0;

    .line 15
    .line 16
    invoke-virtual {v2}, Lpg0;->k()V

    .line 17
    .line 18
    .line 19
    const-string v2, "Compose:recompose"

    .line 20
    .line 21
    invoke-static {v2}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    :try_start_17
    invoke-static {}, Ln61;->j()Lg61;

    .line 25
    .line 26
    .line 27
    move-result-object v2

    .line 28
    invoke-virtual {v2}, Lg61;->g()J

    .line 29
    .line 30
    .line 31
    move-result-wide v2

    .line 32
    const/16 v4, 0x20

    .line 33
    .line 34
    ushr-long v4, v2, v4

    .line 35
    .line 36
    xor-long/2addr v2, v4

    .line 37
    long-to-int v2, v2

    .line 38
    iput v2, p0, Ld10;->B:I

    .line 39
    .line 40
    const/4 v2, 0x0

    .line 41
    iput-object v2, p0, Ld10;->v:Lsj0;

    .line 42
    .line 43
    invoke-virtual {p0, p1}, Ld10;->c0(Lhk0;)V

    .line 44
    .line 45
    .line 46
    const/4 p1, 0x0

    .line 47
    iput p1, p0, Ld10;->k:I

    .line 48
    .line 49
    const/4 v2, 0x1

    .line 50
    iput-boolean v2, p0, Ld10;->F:Z
    :try_end_33
    .catchall {:try_start_17 .. :try_end_33} :catchall_c4

    .line 51
    .line 52
    :try_start_33
    invoke-virtual {p0}, Ld10;->a0()V

    .line 53
    .line 54
    .line 55
    invoke-virtual {p0}, Ld10;->D()Ljava/lang/Object;

    .line 56
    .line 57
    .line 58
    move-result-object v3

    .line 59
    if-eq v3, p2, :cond_44

    .line 60
    .line 61
    if-eqz p2, :cond_44

    .line 62
    .line 63
    invoke-virtual {p0, p2}, Ld10;->h0(Ljava/lang/Object;)V

    .line 64
    .line 65
    .line 66
    goto :goto_44

    .line 67
    :catchall_42
    move-exception p2

    .line 68
    goto :goto_a5

    .line 69
    :cond_44
    :goto_44
    iget-object v4, p0, Ld10;->D:Lc10;

    .line 70
    .line 71
    invoke-static {}, Lmc0;->i()Lqk0;

    .line 72
    .line 73
    .line 74
    move-result-object v5
    :try_end_4a
    .catchall {:try_start_33 .. :try_end_4a} :catchall_42

    .line 75
    :try_start_4a
    invoke-virtual {v5, v4}, Lqk0;->b(Ljava/lang/Object;)V
    :try_end_4d
    .catchall {:try_start_4a .. :try_end_4d} :catchall_5d

    .line 76
    .line 77
    .line 78
    sget-object v4, Lqj;->a:Lqn0;

    .line 79
    .line 80
    const/16 v6, 0xc8

    .line 81
    .line 82
    if-eqz p2, :cond_5f

    .line 83
    .line 84
    :try_start_53
    invoke-virtual {p0, v6, v4}, Ld10;->U(ILqn0;)V

    .line 85
    .line 86
    .line 87
    invoke-static {p0, p2}, Lvn;->D(Ld10;Lm00;)V

    .line 88
    .line 89
    .line 90
    invoke-virtual {p0, p1}, Ld10;->p(Z)V

    .line 91
    .line 92
    .line 93
    goto :goto_80

    .line 94
    :catchall_5d
    move-exception p2

    .line 95
    goto :goto_9e

    .line 96
    :cond_5f
    iget-boolean p2, p0, Ld10;->w:Z

    .line 97
    .line 98
    if-eqz p2, :cond_7d

    .line 99
    .line 100
    if-eqz v3, :cond_7d

    .line 101
    .line 102
    sget-object p2, Loj;->a:Lnq0;

    .line 103
    .line 104
    invoke-virtual {v3, p2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 105
    .line 106
    .line 107
    move-result p2

    .line 108
    if-nez p2, :cond_7d

    .line 109
    .line 110
    invoke-virtual {p0, v6, v4}, Ld10;->U(ILqn0;)V

    .line 111
    .line 112
    .line 113
    const/4 p2, 0x2

    .line 114
    invoke-static {p2, v3}, Lvd1;->e(ILjava/lang/Object;)V

    .line 115
    .line 116
    .line 117
    check-cast v3, Lm00;

    .line 118
    .line 119
    invoke-static {p0, v3}, Lvn;->D(Ld10;Lm00;)V

    .line 120
    .line 121
    .line 122
    invoke-virtual {p0, p1}, Ld10;->p(Z)V

    .line 123
    .line 124
    .line 125
    goto :goto_80

    .line 126
    :cond_7d
    invoke-virtual {p0}, Ld10;->P()V
    :try_end_80
    .catchall {:try_start_53 .. :try_end_80} :catchall_5d

    .line 127
    .line 128
    .line 129
    :goto_80
    :try_start_80
    iget p2, v5, Lqk0;->g:I

    .line 130
    .line 131
    sub-int/2addr p2, v2

    .line 132
    invoke-virtual {v5, p2}, Lqk0;->k(I)Ljava/lang/Object;

    .line 133
    .line 134
    .line 135
    invoke-virtual {p0}, Ld10;->t()V
    :try_end_89
    .catchall {:try_start_80 .. :try_end_89} :catchall_42

    .line 136
    .line 137
    .line 138
    :try_start_89
    iput-boolean p1, p0, Ld10;->F:Z

    .line 139
    .line 140
    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    .line 141
    .line 142
    .line 143
    iget-object p1, p0, Ld10;->I:La61;

    .line 144
    .line 145
    iget-boolean p1, p1, La61;->w:Z

    .line 146
    .line 147
    if-nez p1, :cond_97

    .line 148
    .line 149
    invoke-static {v0}, Lqj;->a(Ljava/lang/String;)V

    .line 150
    .line 151
    .line 152
    :cond_97
    invoke-virtual {p0}, Ld10;->v()V
    :try_end_9a
    .catchall {:try_start_89 .. :try_end_9a} :catchall_c4

    .line 153
    .line 154
    .line 155
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 156
    .line 157
    .line 158
    return-void

    .line 159
    :goto_9e
    :try_start_9e
    iget v3, v5, Lqk0;->g:I

    .line 160
    .line 161
    sub-int/2addr v3, v2

    .line 162
    invoke-virtual {v5, v3}, Lqk0;->k(I)Ljava/lang/Object;

    .line 163
    .line 164
    .line 165
    throw p2
    :try_end_a5
    .catchall {:try_start_9e .. :try_end_a5} :catchall_42

    .line 166
    :goto_a5
    :try_start_a5
    new-instance v3, Lz00;

    .line 167
    .line 168
    invoke-direct {v3, v2, p0}, Lz00;-><init>(ILd10;)V

    .line 169
    .line 170
    .line 171
    invoke-static {p2, v3}, La5;->P(Ljava/lang/Throwable;Lxz;)Z

    .line 172
    .line 173
    .line 174
    throw p2
    :try_end_ae
    .catchall {:try_start_a5 .. :try_end_ae} :catchall_ae

    .line 175
    :catchall_ae
    move-exception p2

    .line 176
    :try_start_af
    iput-boolean p1, p0, Ld10;->F:Z

    .line 177
    .line 178
    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    .line 179
    .line 180
    .line 181
    invoke-virtual {p0}, Ld10;->a()V

    .line 182
    .line 183
    .line 184
    iget-object p1, p0, Ld10;->I:La61;

    .line 185
    .line 186
    iget-boolean p1, p1, La61;->w:Z

    .line 187
    .line 188
    if-nez p1, :cond_c0

    .line 189
    .line 190
    invoke-static {v0}, Lqj;->a(Ljava/lang/String;)V

    .line 191
    .line 192
    .line 193
    :cond_c0
    invoke-virtual {p0}, Ld10;->v()V

    .line 194
    .line 195
    .line 196
    throw p2
    :try_end_c4
    .catchall {:try_start_af .. :try_end_c4} :catchall_c4

    .line 197
    :catchall_c4
    move-exception p0

    .line 198
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 199
    .line 200
    .line 201
    throw p0
.end method

.method public final o(II)V
    .registers 4

    .line 1
    if-lez p1, :cond_25

    .line 2
    .line 3
    if-eq p1, p2, :cond_25

    .line 4
    .line 5
    iget-object v0, p0, Ld10;->G:Lw51;

    .line 6
    .line 7
    invoke-virtual {v0, p1}, Lw51;->q(I)I

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    invoke-virtual {p0, v0, p2}, Ld10;->o(II)V

    .line 12
    .line 13
    .line 14
    iget-object p2, p0, Ld10;->G:Lw51;

    .line 15
    .line 16
    invoke-virtual {p2, p1}, Lw51;->l(I)Z

    .line 17
    .line 18
    .line 19
    move-result p2

    .line 20
    if-eqz p2, :cond_25

    .line 21
    .line 22
    iget-object p2, p0, Ld10;->G:Lw51;

    .line 23
    .line 24
    invoke-virtual {p2, p1}, Lw51;->n(I)Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object p1

    .line 28
    iget-object p0, p0, Ld10;->M:Lpj;

    .line 29
    .line 30
    invoke-virtual {p0}, Lpj;->c()V

    .line 31
    .line 32
    .line 33
    iget-object p0, p0, Lpj;->h:Ljava/util/ArrayList;

    .line 34
    .line 35
    invoke-virtual {p0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 36
    .line 37
    .line 38
    :cond_25
    return-void
.end method

.method public final p(Z)V
    .registers 44

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-object v1, v0, Ld10;->n:Lw60;

    .line 4
    .line 5
    iget-object v2, v1, Lw60;->a:[I

    .line 6
    .line 7
    iget v3, v1, Lw60;->b:I

    .line 8
    .line 9
    add-int/lit8 v3, v3, -0x2

    .line 10
    .line 11
    aget v2, v2, v3

    .line 12
    .line 13
    const/4 v3, 0x1

    .line 14
    sub-int/2addr v2, v3

    .line 15
    iget-boolean v4, v0, Ld10;->S:Z

    .line 16
    .line 17
    sget-object v5, Loj;->a:Lnq0;

    .line 18
    .line 19
    const/16 v6, 0xcf

    .line 20
    .line 21
    const/4 v7, 0x3

    .line 22
    if-eqz v4, :cond_7b

    .line 23
    .line 24
    iget-object v4, v0, Ld10;->I:La61;

    .line 25
    .line 26
    iget v8, v4, La61;->v:I

    .line 27
    .line 28
    invoke-virtual {v4, v8}, La61;->s(I)I

    .line 29
    .line 30
    .line 31
    move-result v4

    .line 32
    iget-object v9, v0, Ld10;->I:La61;

    .line 33
    .line 34
    invoke-virtual {v9, v8}, La61;->t(I)Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v9

    .line 38
    iget-object v10, v0, Ld10;->I:La61;

    .line 39
    .line 40
    invoke-virtual {v10, v8}, La61;->q(I)Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object v8

    .line 44
    if-nez v9, :cond_5f

    .line 45
    .line 46
    if-eqz v8, :cond_4d

    .line 47
    .line 48
    if-ne v4, v6, :cond_4d

    .line 49
    .line 50
    invoke-virtual {v8, v5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 51
    .line 52
    .line 53
    move-result v5

    .line 54
    if-nez v5, :cond_4d

    .line 55
    .line 56
    invoke-virtual {v8}, Ljava/lang/Object;->hashCode()I

    .line 57
    .line 58
    .line 59
    move-result v4

    .line 60
    iget-wide v5, v0, Ld10;->T:J

    .line 61
    .line 62
    int-to-long v8, v2

    .line 63
    xor-long/2addr v5, v8

    .line 64
    invoke-static {v5, v6, v7}, Ljava/lang/Long;->rotateRight(JI)J

    .line 65
    .line 66
    .line 67
    move-result-wide v5

    .line 68
    int-to-long v8, v4

    .line 69
    xor-long/2addr v5, v8

    .line 70
    invoke-static {v5, v6, v7}, Ljava/lang/Long;->rotateRight(JI)J

    .line 71
    .line 72
    .line 73
    move-result-wide v4

    .line 74
    iput-wide v4, v0, Ld10;->T:J

    .line 75
    .line 76
    goto/16 :goto_e1

    .line 77
    .line 78
    :cond_4d
    iget-wide v5, v0, Ld10;->T:J

    .line 79
    .line 80
    int-to-long v8, v2

    .line 81
    xor-long/2addr v5, v8

    .line 82
    invoke-static {v5, v6, v7}, Ljava/lang/Long;->rotateRight(JI)J

    .line 83
    .line 84
    .line 85
    move-result-wide v5

    .line 86
    int-to-long v8, v4

    .line 87
    xor-long/2addr v5, v8

    .line 88
    invoke-static {v5, v6, v7}, Ljava/lang/Long;->rotateRight(JI)J

    .line 89
    .line 90
    .line 91
    move-result-wide v4

    .line 92
    :goto_5b
    iput-wide v4, v0, Ld10;->T:J

    .line 93
    .line 94
    goto/16 :goto_e1

    .line 95
    .line 96
    :cond_5f
    instance-of v2, v9, Ljava/lang/Enum;

    .line 97
    .line 98
    if-eqz v2, :cond_76

    .line 99
    .line 100
    check-cast v9, Ljava/lang/Enum;

    .line 101
    .line 102
    invoke-virtual {v9}, Ljava/lang/Enum;->ordinal()I

    .line 103
    .line 104
    .line 105
    move-result v2

    .line 106
    :goto_69
    iget-wide v4, v0, Ld10;->T:J

    .line 107
    .line 108
    invoke-static {v4, v5, v7}, Ljava/lang/Long;->rotateRight(JI)J

    .line 109
    .line 110
    .line 111
    move-result-wide v4

    .line 112
    int-to-long v8, v2

    .line 113
    xor-long/2addr v4, v8

    .line 114
    invoke-static {v4, v5, v7}, Ljava/lang/Long;->rotateRight(JI)J

    .line 115
    .line 116
    .line 117
    move-result-wide v4

    .line 118
    goto :goto_5b

    .line 119
    :cond_76
    invoke-virtual {v9}, Ljava/lang/Object;->hashCode()I

    .line 120
    .line 121
    .line 122
    move-result v2

    .line 123
    goto :goto_69

    .line 124
    :cond_7b
    iget-object v4, v0, Ld10;->G:Lw51;

    .line 125
    .line 126
    iget v8, v4, Lw51;->i:I

    .line 127
    .line 128
    invoke-virtual {v4, v8}, Lw51;->i(I)I

    .line 129
    .line 130
    .line 131
    move-result v4

    .line 132
    iget-object v9, v0, Ld10;->G:Lw51;

    .line 133
    .line 134
    iget-object v10, v9, Lw51;->b:[I

    .line 135
    .line 136
    invoke-virtual {v9, v10, v8}, Lw51;->p([II)Ljava/lang/Object;

    .line 137
    .line 138
    .line 139
    move-result-object v9

    .line 140
    iget-object v10, v0, Ld10;->G:Lw51;

    .line 141
    .line 142
    iget-object v11, v10, Lw51;->b:[I

    .line 143
    .line 144
    invoke-virtual {v10, v11, v8}, Lw51;->b([II)Ljava/lang/Object;

    .line 145
    .line 146
    .line 147
    move-result-object v8

    .line 148
    if-nez v9, :cond_c5

    .line 149
    .line 150
    if-eqz v8, :cond_b4

    .line 151
    .line 152
    if-ne v4, v6, :cond_b4

    .line 153
    .line 154
    invoke-virtual {v8, v5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 155
    .line 156
    .line 157
    move-result v5

    .line 158
    if-nez v5, :cond_b4

    .line 159
    .line 160
    invoke-virtual {v8}, Ljava/lang/Object;->hashCode()I

    .line 161
    .line 162
    .line 163
    move-result v4

    .line 164
    iget-wide v5, v0, Ld10;->T:J

    .line 165
    .line 166
    int-to-long v8, v2

    .line 167
    xor-long/2addr v5, v8

    .line 168
    invoke-static {v5, v6, v7}, Ljava/lang/Long;->rotateRight(JI)J

    .line 169
    .line 170
    .line 171
    move-result-wide v5

    .line 172
    int-to-long v8, v4

    .line 173
    xor-long/2addr v5, v8

    .line 174
    invoke-static {v5, v6, v7}, Ljava/lang/Long;->rotateRight(JI)J

    .line 175
    .line 176
    .line 177
    move-result-wide v4

    .line 178
    iput-wide v4, v0, Ld10;->T:J

    .line 179
    .line 180
    goto :goto_e1

    .line 181
    :cond_b4
    iget-wide v5, v0, Ld10;->T:J

    .line 182
    .line 183
    int-to-long v8, v2

    .line 184
    xor-long/2addr v5, v8

    .line 185
    invoke-static {v5, v6, v7}, Ljava/lang/Long;->rotateRight(JI)J

    .line 186
    .line 187
    .line 188
    move-result-wide v5

    .line 189
    int-to-long v8, v4

    .line 190
    xor-long/2addr v5, v8

    .line 191
    invoke-static {v5, v6, v7}, Ljava/lang/Long;->rotateRight(JI)J

    .line 192
    .line 193
    .line 194
    move-result-wide v4

    .line 195
    :goto_c2
    iput-wide v4, v0, Ld10;->T:J

    .line 196
    .line 197
    goto :goto_e1

    .line 198
    :cond_c5
    instance-of v2, v9, Ljava/lang/Enum;

    .line 199
    .line 200
    if-eqz v2, :cond_dc

    .line 201
    .line 202
    check-cast v9, Ljava/lang/Enum;

    .line 203
    .line 204
    invoke-virtual {v9}, Ljava/lang/Enum;->ordinal()I

    .line 205
    .line 206
    .line 207
    move-result v2

    .line 208
    :goto_cf
    iget-wide v4, v0, Ld10;->T:J

    .line 209
    .line 210
    invoke-static {v4, v5, v7}, Ljava/lang/Long;->rotateRight(JI)J

    .line 211
    .line 212
    .line 213
    move-result-wide v4

    .line 214
    int-to-long v8, v2

    .line 215
    xor-long/2addr v4, v8

    .line 216
    invoke-static {v4, v5, v7}, Ljava/lang/Long;->rotateRight(JI)J

    .line 217
    .line 218
    .line 219
    move-result-wide v4

    .line 220
    goto :goto_c2

    .line 221
    :cond_dc
    invoke-virtual {v9}, Ljava/lang/Object;->hashCode()I

    .line 222
    .line 223
    .line 224
    move-result v2

    .line 225
    goto :goto_cf

    .line 226
    :goto_e1
    iget v2, v0, Ld10;->l:I

    .line 227
    .line 228
    iget-object v4, v0, Ld10;->j:Lg10;

    .line 229
    .line 230
    iget-object v5, v0, Ld10;->s:Ljava/util/ArrayList;

    .line 231
    .line 232
    iget-object v9, v0, Ld10;->M:Lpj;

    .line 233
    .line 234
    if-eqz v4, :cond_39e

    .line 235
    .line 236
    iget-object v10, v4, Lg10;->e:Lsj0;

    .line 237
    .line 238
    iget v11, v4, Lg10;->b:I

    .line 239
    .line 240
    iget-object v12, v4, Lg10;->a:Ljava/util/ArrayList;

    .line 241
    .line 242
    invoke-virtual {v12}, Ljava/util/ArrayList;->size()I

    .line 243
    .line 244
    .line 245
    move-result v13

    .line 246
    if-lez v13, :cond_39e

    .line 247
    .line 248
    iget-object v13, v4, Lg10;->d:Ljava/util/ArrayList;

    .line 249
    .line 250
    new-instance v14, Ljava/util/HashSet;

    .line 251
    .line 252
    invoke-virtual {v13}, Ljava/util/ArrayList;->size()I

    .line 253
    .line 254
    .line 255
    move-result v15

    .line 256
    invoke-direct {v14, v15}, Ljava/util/HashSet;-><init>(I)V

    .line 257
    .line 258
    .line 259
    invoke-interface {v13}, Ljava/util/Collection;->size()I

    .line 260
    .line 261
    .line 262
    move-result v15

    .line 263
    move/from16 v16, v7

    .line 264
    .line 265
    const/4 v7, 0x0

    .line 266
    :goto_109
    if-ge v7, v15, :cond_117

    .line 267
    .line 268
    const/16 v17, -0x1

    .line 269
    .line 270
    invoke-interface {v13, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 271
    .line 272
    .line 273
    move-result-object v6

    .line 274
    invoke-virtual {v14, v6}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 275
    .line 276
    .line 277
    add-int/lit8 v7, v7, 0x1

    .line 278
    .line 279
    goto :goto_109

    .line 280
    :cond_117
    const/16 v17, -0x1

    .line 281
    .line 282
    sget-object v6, Lo01;->a:Lik0;

    .line 283
    .line 284
    new-instance v6, Lik0;

    .line 285
    .line 286
    invoke-direct {v6}, Lik0;-><init>()V

    .line 287
    .line 288
    .line 289
    invoke-virtual {v13}, Ljava/util/ArrayList;->size()I

    .line 290
    .line 291
    .line 292
    move-result v7

    .line 293
    invoke-virtual {v12}, Ljava/util/ArrayList;->size()I

    .line 294
    .line 295
    .line 296
    move-result v15

    .line 297
    const/4 v3, 0x0

    .line 298
    const/16 v19, 0x0

    .line 299
    .line 300
    const/16 v20, 0x0

    .line 301
    .line 302
    :goto_12d
    if-ge v3, v15, :cond_37b

    .line 303
    .line 304
    invoke-virtual {v12, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 305
    .line 306
    .line 307
    move-result-object v21

    .line 308
    move-object/from16 v8, v21

    .line 309
    .line 310
    check-cast v8, Le90;

    .line 311
    .line 312
    invoke-virtual {v14, v8}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    .line 313
    .line 314
    .line 315
    move-result v21

    .line 316
    if-nez v21, :cond_18c

    .line 317
    .line 318
    move-object/from16 v21, v1

    .line 319
    .line 320
    iget v1, v8, Le90;->c:I

    .line 321
    .line 322
    invoke-virtual {v10, v1}, Ll60;->b(I)Ljava/lang/Object;

    .line 323
    .line 324
    .line 325
    move-result-object v1

    .line 326
    check-cast v1, Lt20;

    .line 327
    .line 328
    if-eqz v1, :cond_14e

    .line 329
    .line 330
    iget v1, v1, Lt20;->b:I

    .line 331
    .line 332
    move/from16 v22, v1

    .line 333
    .line 334
    goto :goto_150

    .line 335
    :cond_14e
    move/from16 v22, v17

    .line 336
    .line 337
    :goto_150
    iget v1, v8, Le90;->c:I

    .line 338
    .line 339
    move/from16 v23, v3

    .line 340
    .line 341
    add-int v3, v22, v11

    .line 342
    .line 343
    iget v8, v8, Le90;->d:I

    .line 344
    .line 345
    invoke-virtual {v9, v3, v8}, Lpj;->e(II)V

    .line 346
    .line 347
    .line 348
    const/4 v3, 0x0

    .line 349
    invoke-virtual {v4, v1, v3}, Lg10;->a(II)Z

    .line 350
    .line 351
    .line 352
    iget v3, v9, Lpj;->f:I

    .line 353
    .line 354
    iget-object v8, v9, Lpj;->a:Ld10;

    .line 355
    .line 356
    iget-object v8, v8, Ld10;->G:Lw51;

    .line 357
    .line 358
    iget v8, v8, Lw51;->g:I

    .line 359
    .line 360
    sub-int v8, v1, v8

    .line 361
    .line 362
    add-int/2addr v8, v3

    .line 363
    iput v8, v9, Lpj;->f:I

    .line 364
    .line 365
    iget-object v3, v0, Ld10;->G:Lw51;

    .line 366
    .line 367
    invoke-virtual {v3, v1}, Lw51;->r(I)V

    .line 368
    .line 369
    .line 370
    invoke-virtual {v0}, Ld10;->I()V

    .line 371
    .line 372
    .line 373
    iget-object v3, v0, Ld10;->G:Lw51;

    .line 374
    .line 375
    invoke-virtual {v3}, Lw51;->s()I

    .line 376
    .line 377
    .line 378
    iget-object v3, v0, Ld10;->G:Lw51;

    .line 379
    .line 380
    iget-object v3, v3, Lw51;->b:[I

    .line 381
    .line 382
    mul-int/lit8 v8, v1, 0x5

    .line 383
    .line 384
    add-int/lit8 v8, v8, 0x3

    .line 385
    .line 386
    aget v3, v3, v8

    .line 387
    .line 388
    add-int/2addr v3, v1

    .line 389
    invoke-static {v5, v1, v3}, Lvn;->f(Ljava/util/List;II)V

    .line 390
    .line 391
    .line 392
    :goto_187
    add-int/lit8 v3, v23, 0x1

    .line 393
    .line 394
    :goto_189
    move-object/from16 v1, v21

    .line 395
    .line 396
    goto :goto_12d

    .line 397
    :cond_18c
    move-object/from16 v21, v1

    .line 398
    .line 399
    move/from16 v23, v3

    .line 400
    .line 401
    invoke-virtual {v6, v8}, Lik0;->c(Ljava/lang/Object;)Z

    .line 402
    .line 403
    .line 404
    move-result v1

    .line 405
    if-eqz v1, :cond_197

    .line 406
    .line 407
    goto :goto_187

    .line 408
    :cond_197
    move/from16 v1, v19

    .line 409
    .line 410
    if-ge v1, v7, :cond_371

    .line 411
    .line 412
    invoke-virtual {v13, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 413
    .line 414
    .line 415
    move-result-object v3

    .line 416
    check-cast v3, Le90;

    .line 417
    .line 418
    if-eq v3, v8, :cond_334

    .line 419
    .line 420
    iget v8, v3, Le90;->c:I

    .line 421
    .line 422
    invoke-virtual {v10, v8}, Ll60;->b(I)Ljava/lang/Object;

    .line 423
    .line 424
    .line 425
    move-result-object v8

    .line 426
    check-cast v8, Lt20;

    .line 427
    .line 428
    if-eqz v8, :cond_1b0

    .line 429
    .line 430
    iget v8, v8, Lt20;->b:I

    .line 431
    .line 432
    goto :goto_1b2

    .line 433
    :cond_1b0
    move/from16 v8, v17

    .line 434
    .line 435
    :goto_1b2
    invoke-virtual {v6, v3}, Lik0;->a(Ljava/lang/Object;)Z

    .line 436
    .line 437
    .line 438
    move/from16 v19, v1

    .line 439
    .line 440
    move/from16 v1, v20

    .line 441
    .line 442
    move-object/from16 v20, v4

    .line 443
    .line 444
    if-eq v8, v1, :cond_323

    .line 445
    .line 446
    iget v4, v3, Le90;->c:I

    .line 447
    .line 448
    invoke-virtual {v10, v4}, Ll60;->b(I)Ljava/lang/Object;

    .line 449
    .line 450
    .line 451
    move-result-object v4

    .line 452
    check-cast v4, Lt20;

    .line 453
    .line 454
    if-eqz v4, :cond_1cc

    .line 455
    .line 456
    iget v4, v4, Lt20;->c:I

    .line 457
    .line 458
    :goto_1c9
    move-object/from16 v22, v6

    .line 459
    .line 460
    goto :goto_1cf

    .line 461
    :cond_1cc
    iget v4, v3, Le90;->d:I

    .line 462
    .line 463
    goto :goto_1c9

    .line 464
    :goto_1cf
    add-int v6, v8, v11

    .line 465
    .line 466
    move/from16 v24, v7

    .line 467
    .line 468
    add-int v7, v1, v11

    .line 469
    .line 470
    if-lez v4, :cond_1fe

    .line 471
    .line 472
    move/from16 v25, v11

    .line 473
    .line 474
    iget v11, v9, Lpj;->l:I

    .line 475
    .line 476
    if-lez v11, :cond_1f2

    .line 477
    .line 478
    move/from16 v26, v11

    .line 479
    .line 480
    iget v11, v9, Lpj;->j:I

    .line 481
    .line 482
    move-object/from16 v27, v12

    .line 483
    .line 484
    sub-int v12, v6, v26

    .line 485
    .line 486
    if-ne v11, v12, :cond_1f4

    .line 487
    .line 488
    iget v11, v9, Lpj;->k:I

    .line 489
    .line 490
    sub-int v12, v7, v26

    .line 491
    .line 492
    if-ne v11, v12, :cond_1f4

    .line 493
    .line 494
    add-int v11, v26, v4

    .line 495
    .line 496
    iput v11, v9, Lpj;->l:I

    .line 497
    .line 498
    goto :goto_205

    .line 499
    :cond_1f2
    move-object/from16 v27, v12

    .line 500
    .line 501
    :cond_1f4
    invoke-virtual {v9}, Lpj;->c()V

    .line 502
    .line 503
    .line 504
    iput v6, v9, Lpj;->j:I

    .line 505
    .line 506
    iput v7, v9, Lpj;->k:I

    .line 507
    .line 508
    iput v4, v9, Lpj;->l:I

    .line 509
    .line 510
    goto :goto_205

    .line 511
    :cond_1fe
    move/from16 v25, v11

    .line 512
    .line 513
    move-object/from16 v27, v12

    .line 514
    .line 515
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 516
    .line 517
    .line 518
    :goto_205
    const/16 v26, 0x7

    .line 519
    .line 520
    const-wide v28, -0x7f7f7f7f7f7f7f80L  # -2.937446524422997E-306

    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    const-wide/16 v30, 0x80

    .line 526
    .line 527
    if-le v8, v1, :cond_295

    .line 528
    .line 529
    iget-object v7, v10, Ll60;->c:[Ljava/lang/Object;

    .line 530
    .line 531
    const-wide/16 v32, 0xff

    .line 532
    .line 533
    iget-object v11, v10, Ll60;->a:[J

    .line 534
    .line 535
    array-length v12, v11

    .line 536
    add-int/lit8 v12, v12, -0x2

    .line 537
    .line 538
    if-ltz v12, :cond_291

    .line 539
    .line 540
    move-object/from16 v35, v13

    .line 541
    .line 542
    move-object/from16 v36, v14

    .line 543
    .line 544
    const/4 v6, 0x0

    .line 545
    :goto_220
    const/16 v34, 0x8

    .line 546
    .line 547
    aget-wide v13, v11, v6

    .line 548
    .line 549
    move/from16 v38, v4

    .line 550
    .line 551
    move-object/from16 v37, v5

    .line 552
    .line 553
    not-long v4, v13

    .line 554
    shl-long v4, v4, v26

    .line 555
    .line 556
    and-long/2addr v4, v13

    .line 557
    and-long v4, v4, v28

    .line 558
    .line 559
    cmp-long v4, v4, v28

    .line 560
    .line 561
    if-eqz v4, :cond_280

    .line 562
    .line 563
    sub-int v4, v6, v12

    .line 564
    .line 565
    not-int v4, v4

    .line 566
    ushr-int/lit8 v4, v4, 0x1f

    .line 567
    .line 568
    rsub-int/lit8 v4, v4, 0x8

    .line 569
    .line 570
    const/4 v5, 0x0

    .line 571
    :goto_23a
    if-ge v5, v4, :cond_277

    .line 572
    .line 573
    and-long v39, v13, v32

    .line 574
    .line 575
    cmp-long v39, v39, v30

    .line 576
    .line 577
    if-gez v39, :cond_268

    .line 578
    .line 579
    shl-int/lit8 v39, v6, 0x3

    .line 580
    .line 581
    add-int v39, v39, v5

    .line 582
    .line 583
    aget-object v39, v7, v39

    .line 584
    .line 585
    move/from16 v40, v5

    .line 586
    .line 587
    move-object/from16 v5, v39

    .line 588
    .line 589
    check-cast v5, Lt20;

    .line 590
    .line 591
    move-object/from16 v39, v7

    .line 592
    .line 593
    iget v7, v5, Lt20;->b:I

    .line 594
    .line 595
    move-object/from16 v41, v11

    .line 596
    .line 597
    if-gt v8, v7, :cond_25f

    .line 598
    .line 599
    add-int v11, v8, v38

    .line 600
    .line 601
    if-ge v7, v11, :cond_25f

    .line 602
    .line 603
    sub-int/2addr v7, v8

    .line 604
    add-int/2addr v7, v1

    .line 605
    iput v7, v5, Lt20;->b:I

    .line 606
    .line 607
    goto :goto_26e

    .line 608
    :cond_25f
    if-gt v1, v7, :cond_26e

    .line 609
    .line 610
    if-ge v7, v8, :cond_26e

    .line 611
    .line 612
    add-int v7, v7, v38

    .line 613
    .line 614
    iput v7, v5, Lt20;->b:I

    .line 615
    .line 616
    goto :goto_26e

    .line 617
    :cond_268
    move/from16 v40, v5

    .line 618
    .line 619
    move-object/from16 v39, v7

    .line 620
    .line 621
    move-object/from16 v41, v11

    .line 622
    .line 623
    :cond_26e
    :goto_26e
    shr-long v13, v13, v34

    .line 624
    .line 625
    add-int/lit8 v5, v40, 0x1

    .line 626
    .line 627
    move-object/from16 v7, v39

    .line 628
    .line 629
    move-object/from16 v11, v41

    .line 630
    .line 631
    goto :goto_23a

    .line 632
    :cond_277
    move-object/from16 v39, v7

    .line 633
    .line 634
    move-object/from16 v41, v11

    .line 635
    .line 636
    move/from16 v5, v34

    .line 637
    .line 638
    if-ne v4, v5, :cond_331

    .line 639
    .line 640
    goto :goto_284

    .line 641
    :cond_280
    move-object/from16 v39, v7

    .line 642
    .line 643
    move-object/from16 v41, v11

    .line 644
    .line 645
    :goto_284
    if-eq v6, v12, :cond_331

    .line 646
    .line 647
    add-int/lit8 v6, v6, 0x1

    .line 648
    .line 649
    move-object/from16 v5, v37

    .line 650
    .line 651
    move/from16 v4, v38

    .line 652
    .line 653
    move-object/from16 v7, v39

    .line 654
    .line 655
    move-object/from16 v11, v41

    .line 656
    .line 657
    goto :goto_220

    .line 658
    :cond_291
    move-object/from16 v37, v5

    .line 659
    .line 660
    goto/16 :goto_32d

    .line 661
    .line 662
    :cond_295
    move/from16 v38, v4

    .line 663
    .line 664
    move-object/from16 v37, v5

    .line 665
    .line 666
    move-object/from16 v35, v13

    .line 667
    .line 668
    move-object/from16 v36, v14

    .line 669
    .line 670
    const-wide/16 v32, 0xff

    .line 671
    .line 672
    if-le v1, v8, :cond_331

    .line 673
    .line 674
    iget-object v4, v10, Ll60;->c:[Ljava/lang/Object;

    .line 675
    .line 676
    iget-object v5, v10, Ll60;->a:[J

    .line 677
    .line 678
    array-length v6, v5

    .line 679
    add-int/lit8 v6, v6, -0x2

    .line 680
    .line 681
    if-ltz v6, :cond_331

    .line 682
    .line 683
    const/4 v7, 0x0

    .line 684
    :goto_2ab
    aget-wide v11, v5, v7

    .line 685
    .line 686
    not-long v13, v11

    .line 687
    shl-long v13, v13, v26

    .line 688
    .line 689
    and-long/2addr v13, v11

    .line 690
    and-long v13, v13, v28

    .line 691
    .line 692
    cmp-long v13, v13, v28

    .line 693
    .line 694
    if-eqz v13, :cond_310

    .line 695
    .line 696
    sub-int v13, v7, v6

    .line 697
    .line 698
    not-int v13, v13

    .line 699
    ushr-int/lit8 v13, v13, 0x1f

    .line 700
    .line 701
    const/16 v34, 0x8

    .line 702
    .line 703
    rsub-int/lit8 v13, v13, 0x8

    .line 704
    .line 705
    const/4 v14, 0x0

    .line 706
    :goto_2c1
    if-ge v14, v13, :cond_305

    .line 707
    .line 708
    and-long v39, v11, v32

    .line 709
    .line 710
    cmp-long v39, v39, v30

    .line 711
    .line 712
    if-gez v39, :cond_2f4

    .line 713
    .line 714
    shl-int/lit8 v39, v7, 0x3

    .line 715
    .line 716
    add-int v39, v39, v14

    .line 717
    .line 718
    aget-object v39, v4, v39

    .line 719
    .line 720
    move-object/from16 v40, v4

    .line 721
    .line 722
    move-object/from16 v4, v39

    .line 723
    .line 724
    check-cast v4, Lt20;

    .line 725
    .line 726
    move-object/from16 v39, v5

    .line 727
    .line 728
    iget v5, v4, Lt20;->b:I

    .line 729
    .line 730
    move/from16 v41, v8

    .line 731
    .line 732
    if-gt v8, v5, :cond_2e7

    .line 733
    .line 734
    add-int v8, v41, v38

    .line 735
    .line 736
    if-ge v5, v8, :cond_2e7

    .line 737
    .line 738
    sub-int v5, v5, v41

    .line 739
    .line 740
    add-int/2addr v5, v1

    .line 741
    iput v5, v4, Lt20;->b:I

    .line 742
    .line 743
    goto :goto_2f1

    .line 744
    :cond_2e7
    add-int/lit8 v8, v41, 0x1

    .line 745
    .line 746
    if-gt v8, v5, :cond_2f1

    .line 747
    .line 748
    if-ge v5, v1, :cond_2f1

    .line 749
    .line 750
    sub-int v5, v5, v38

    .line 751
    .line 752
    iput v5, v4, Lt20;->b:I

    .line 753
    .line 754
    :cond_2f1
    :goto_2f1
    const/16 v5, 0x8

    .line 755
    .line 756
    goto :goto_2fb

    .line 757
    :cond_2f4
    move-object/from16 v40, v4

    .line 758
    .line 759
    move-object/from16 v39, v5

    .line 760
    .line 761
    move/from16 v41, v8

    .line 762
    .line 763
    goto :goto_2f1

    .line 764
    :goto_2fb
    shr-long/2addr v11, v5

    .line 765
    add-int/lit8 v14, v14, 0x1

    .line 766
    .line 767
    move-object/from16 v5, v39

    .line 768
    .line 769
    move-object/from16 v4, v40

    .line 770
    .line 771
    move/from16 v8, v41

    .line 772
    .line 773
    goto :goto_2c1

    .line 774
    :cond_305
    move-object/from16 v40, v4

    .line 775
    .line 776
    move-object/from16 v39, v5

    .line 777
    .line 778
    move/from16 v41, v8

    .line 779
    .line 780
    const/16 v5, 0x8

    .line 781
    .line 782
    if-ne v13, v5, :cond_331

    .line 783
    .line 784
    goto :goto_318

    .line 785
    :cond_310
    move-object/from16 v40, v4

    .line 786
    .line 787
    move-object/from16 v39, v5

    .line 788
    .line 789
    move/from16 v41, v8

    .line 790
    .line 791
    const/16 v5, 0x8

    .line 792
    .line 793
    :goto_318
    if-eq v7, v6, :cond_331

    .line 794
    .line 795
    add-int/lit8 v7, v7, 0x1

    .line 796
    .line 797
    move-object/from16 v5, v39

    .line 798
    .line 799
    move-object/from16 v4, v40

    .line 800
    .line 801
    move/from16 v8, v41

    .line 802
    .line 803
    goto :goto_2ab

    .line 804
    :cond_323
    move-object/from16 v37, v5

    .line 805
    .line 806
    move-object/from16 v22, v6

    .line 807
    .line 808
    move/from16 v24, v7

    .line 809
    .line 810
    move/from16 v25, v11

    .line 811
    .line 812
    move-object/from16 v27, v12

    .line 813
    .line 814
    :goto_32d
    move-object/from16 v35, v13

    .line 815
    .line 816
    move-object/from16 v36, v14

    .line 817
    .line 818
    :cond_331
    move/from16 v4, v23

    .line 819
    .line 820
    goto :goto_34a

    .line 821
    :cond_334
    move/from16 v19, v1

    .line 822
    .line 823
    move-object/from16 v37, v5

    .line 824
    .line 825
    move-object/from16 v22, v6

    .line 826
    .line 827
    move/from16 v24, v7

    .line 828
    .line 829
    move/from16 v25, v11

    .line 830
    .line 831
    move-object/from16 v27, v12

    .line 832
    .line 833
    move-object/from16 v35, v13

    .line 834
    .line 835
    move-object/from16 v36, v14

    .line 836
    .line 837
    move/from16 v1, v20

    .line 838
    .line 839
    move-object/from16 v20, v4

    .line 840
    .line 841
    add-int/lit8 v4, v23, 0x1

    .line 842
    .line 843
    :goto_34a
    add-int/lit8 v19, v19, 0x1

    .line 844
    .line 845
    iget v5, v3, Le90;->c:I

    .line 846
    .line 847
    invoke-virtual {v10, v5}, Ll60;->b(I)Ljava/lang/Object;

    .line 848
    .line 849
    .line 850
    move-result-object v5

    .line 851
    check-cast v5, Lt20;

    .line 852
    .line 853
    if-eqz v5, :cond_359

    .line 854
    .line 855
    iget v3, v5, Lt20;->c:I

    .line 856
    .line 857
    goto :goto_35b

    .line 858
    :cond_359
    iget v3, v3, Le90;->d:I

    .line 859
    .line 860
    :goto_35b
    add-int/2addr v1, v3

    .line 861
    move v3, v4

    .line 862
    move-object/from16 v4, v20

    .line 863
    .line 864
    move-object/from16 v6, v22

    .line 865
    .line 866
    move/from16 v7, v24

    .line 867
    .line 868
    move/from16 v11, v25

    .line 869
    .line 870
    move-object/from16 v12, v27

    .line 871
    .line 872
    move-object/from16 v13, v35

    .line 873
    .line 874
    move-object/from16 v14, v36

    .line 875
    .line 876
    move-object/from16 v5, v37

    .line 877
    .line 878
    move/from16 v20, v1

    .line 879
    .line 880
    goto/16 :goto_189

    .line 881
    .line 882
    :cond_371
    move/from16 v19, v1

    .line 883
    .line 884
    move/from16 v1, v20

    .line 885
    .line 886
    move-object/from16 v1, v21

    .line 887
    .line 888
    move/from16 v3, v23

    .line 889
    .line 890
    goto/16 :goto_12d

    .line 891
    .line 892
    :cond_37b
    move-object/from16 v21, v1

    .line 893
    .line 894
    move-object/from16 v37, v5

    .line 895
    .line 896
    move-object/from16 v27, v12

    .line 897
    .line 898
    invoke-virtual {v9}, Lpj;->c()V

    .line 899
    .line 900
    .line 901
    invoke-virtual/range {v27 .. v27}, Ljava/util/ArrayList;->size()I

    .line 902
    .line 903
    .line 904
    move-result v1

    .line 905
    if-lez v1, :cond_3a4

    .line 906
    .line 907
    iget-object v1, v0, Ld10;->G:Lw51;

    .line 908
    .line 909
    iget v3, v1, Lw51;->h:I

    .line 910
    .line 911
    iget v4, v9, Lpj;->f:I

    .line 912
    .line 913
    iget-object v5, v9, Lpj;->a:Ld10;

    .line 914
    .line 915
    iget-object v5, v5, Ld10;->G:Lw51;

    .line 916
    .line 917
    iget v5, v5, Lw51;->g:I

    .line 918
    .line 919
    sub-int/2addr v3, v5

    .line 920
    add-int/2addr v3, v4

    .line 921
    iput v3, v9, Lpj;->f:I

    .line 922
    .line 923
    invoke-virtual {v1}, Lw51;->t()V

    .line 924
    .line 925
    .line 926
    goto :goto_3a4

    .line 927
    :cond_39e
    move-object/from16 v21, v1

    .line 928
    .line 929
    move-object/from16 v37, v5

    .line 930
    .line 931
    const/16 v17, -0x1

    .line 932
    .line 933
    :cond_3a4
    :goto_3a4
    iget-boolean v1, v0, Ld10;->S:Z

    .line 934
    .line 935
    const/4 v3, -0x2

    .line 936
    if-nez v1, :cond_41e

    .line 937
    .line 938
    iget-object v4, v0, Ld10;->G:Lw51;

    .line 939
    .line 940
    iget v5, v4, Lw51;->m:I

    .line 941
    .line 942
    iget v4, v4, Lw51;->l:I

    .line 943
    .line 944
    sub-int/2addr v5, v4

    .line 945
    if-lez v5, :cond_41e

    .line 946
    .line 947
    if-lez v5, :cond_41b

    .line 948
    .line 949
    const/4 v4, 0x0

    .line 950
    invoke-virtual {v9, v4}, Lpj;->d(Z)V

    .line 951
    .line 952
    .line 953
    iget-object v4, v9, Lpj;->d:Lw60;

    .line 954
    .line 955
    iget-object v6, v9, Lpj;->a:Ld10;

    .line 956
    .line 957
    iget-object v6, v6, Ld10;->G:Lw51;

    .line 958
    .line 959
    iget v7, v6, Lw51;->c:I

    .line 960
    .line 961
    if-lez v7, :cond_3fe

    .line 962
    .line 963
    iget v7, v6, Lw51;->i:I

    .line 964
    .line 965
    invoke-virtual {v4, v3}, Lw60;->a(I)I

    .line 966
    .line 967
    .line 968
    move-result v8

    .line 969
    if-eq v8, v7, :cond_3fe

    .line 970
    .line 971
    iget-boolean v8, v9, Lpj;->c:Z

    .line 972
    .line 973
    if-nez v8, :cond_3e2

    .line 974
    .line 975
    iget-boolean v8, v9, Lpj;->e:Z

    .line 976
    .line 977
    if-eqz v8, :cond_3e2

    .line 978
    .line 979
    const/4 v8, 0x0

    .line 980
    invoke-virtual {v9, v8}, Lpj;->d(Z)V

    .line 981
    .line 982
    .line 983
    iget-object v8, v9, Lpj;->b:Lve;

    .line 984
    .line 985
    iget-object v8, v8, Lve;->F:Lzo0;

    .line 986
    .line 987
    sget-object v10, Leo0;->c:Leo0;

    .line 988
    .line 989
    invoke-virtual {v8, v10}, Lzo0;->C(Lxo0;)V

    .line 990
    .line 991
    .line 992
    const/4 v8, 0x1

    .line 993
    iput-boolean v8, v9, Lpj;->c:Z

    .line 994
    .line 995
    :cond_3e2
    if-lez v7, :cond_3fe

    .line 996
    .line 997
    invoke-virtual {v6, v7}, Lw51;->a(I)Ly00;

    .line 998
    .line 999
    .line 1000
    move-result-object v6

    .line 1001
    invoke-virtual {v4, v7}, Lw60;->c(I)V

    .line 1002
    .line 1003
    .line 1004
    const/4 v4, 0x0

    .line 1005
    invoke-virtual {v9, v4}, Lpj;->d(Z)V

    .line 1006
    .line 1007
    .line 1008
    iget-object v7, v9, Lpj;->b:Lve;

    .line 1009
    .line 1010
    iget-object v7, v7, Lve;->F:Lzo0;

    .line 1011
    .line 1012
    sget-object v8, Ldo0;->c:Ldo0;

    .line 1013
    .line 1014
    invoke-virtual {v7, v8}, Lzo0;->C(Lxo0;)V

    .line 1015
    .line 1016
    .line 1017
    invoke-static {v7, v4, v6}, Ldd0;->v(Lzo0;ILjava/lang/Object;)V

    .line 1018
    .line 1019
    .line 1020
    const/4 v8, 0x1

    .line 1021
    iput-boolean v8, v9, Lpj;->c:Z

    .line 1022
    .line 1023
    :cond_3fe
    iget-object v4, v9, Lpj;->b:Lve;

    .line 1024
    .line 1025
    iget-object v4, v4, Lve;->F:Lzo0;

    .line 1026
    .line 1027
    sget-object v6, Lso0;->c:Lso0;

    .line 1028
    .line 1029
    invoke-virtual {v4, v6}, Lzo0;->C(Lxo0;)V

    .line 1030
    .line 1031
    .line 1032
    iget-object v6, v4, Lzo0;->d:[I

    .line 1033
    .line 1034
    iget v7, v4, Lzo0;->e:I

    .line 1035
    .line 1036
    iget-object v8, v4, Lzo0;->b:[Lxo0;

    .line 1037
    .line 1038
    iget v4, v4, Lzo0;->c:I

    .line 1039
    .line 1040
    const/16 v18, 0x1

    .line 1041
    .line 1042
    add-int/lit8 v4, v4, -0x1

    .line 1043
    .line 1044
    aget-object v4, v8, v4

    .line 1045
    .line 1046
    iget v4, v4, Lxo0;->a:I

    .line 1047
    .line 1048
    sub-int/2addr v7, v4

    .line 1049
    aput v5, v6, v7

    .line 1050
    .line 1051
    goto :goto_41e

    .line 1052
    :cond_41b
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1053
    .line 1054
    .line 1055
    :cond_41e
    :goto_41e
    iget v4, v0, Ld10;->k:I

    .line 1056
    .line 1057
    :goto_420
    iget-object v5, v0, Ld10;->G:Lw51;

    .line 1058
    .line 1059
    iget v6, v5, Lw51;->k:I

    .line 1060
    .line 1061
    if-lez v6, :cond_427

    .line 1062
    .line 1063
    goto :goto_42d

    .line 1064
    :cond_427
    iget v6, v5, Lw51;->g:I

    .line 1065
    .line 1066
    iget v5, v5, Lw51;->h:I

    .line 1067
    .line 1068
    if-ne v6, v5, :cond_62c

    .line 1069
    .line 1070
    :goto_42d
    if-eqz v1, :cond_5b2

    .line 1071
    .line 1072
    if-eqz p1, :cond_486

    .line 1073
    .line 1074
    iget-object v2, v0, Ld10;->O:Lbw;

    .line 1075
    .line 1076
    iget-object v4, v2, Lbw;->c:Lzo0;

    .line 1077
    .line 1078
    iget v5, v4, Lzo0;->c:I

    .line 1079
    .line 1080
    if-eqz v5, :cond_43a

    .line 1081
    .line 1082
    goto :goto_43f

    .line 1083
    :cond_43a
    const-string v5, "Cannot end node insertion, there are no pending operations that can be realized."

    .line 1084
    .line 1085
    invoke-static {v5}, Lqj;->a(Ljava/lang/String;)V

    .line 1086
    .line 1087
    .line 1088
    :goto_43f
    iget-object v2, v2, Lbw;->b:Lzo0;

    .line 1089
    .line 1090
    iget-object v5, v4, Lzo0;->b:[Lxo0;

    .line 1091
    .line 1092
    iget v6, v4, Lzo0;->c:I

    .line 1093
    .line 1094
    add-int/lit8 v6, v6, -0x1

    .line 1095
    .line 1096
    iput v6, v4, Lzo0;->c:I

    .line 1097
    .line 1098
    aget-object v7, v5, v6

    .line 1099
    .line 1100
    const/4 v8, 0x0

    .line 1101
    aput-object v8, v5, v6

    .line 1102
    .line 1103
    invoke-virtual {v2, v7}, Lzo0;->C(Lxo0;)V

    .line 1104
    .line 1105
    .line 1106
    iget-object v5, v4, Lzo0;->f:[Ljava/lang/Object;

    .line 1107
    .line 1108
    iget-object v6, v2, Lzo0;->f:[Ljava/lang/Object;

    .line 1109
    .line 1110
    iget v10, v2, Lzo0;->g:I

    .line 1111
    .line 1112
    iget v11, v7, Lxo0;->b:I

    .line 1113
    .line 1114
    sub-int/2addr v10, v11

    .line 1115
    iget v12, v4, Lzo0;->g:I

    .line 1116
    .line 1117
    sub-int v13, v12, v11

    .line 1118
    .line 1119
    sub-int/2addr v12, v13

    .line 1120
    invoke-static {v5, v13, v6, v10, v12}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 1121
    .line 1122
    .line 1123
    iget-object v5, v4, Lzo0;->f:[Ljava/lang/Object;

    .line 1124
    .line 1125
    iget v6, v4, Lzo0;->g:I

    .line 1126
    .line 1127
    sub-int v10, v6, v11

    .line 1128
    .line 1129
    invoke-static {v5, v10, v6, v8}, Ljava/util/Arrays;->fill([Ljava/lang/Object;IILjava/lang/Object;)V

    .line 1130
    .line 1131
    .line 1132
    iget-object v5, v4, Lzo0;->d:[I

    .line 1133
    .line 1134
    iget-object v6, v2, Lzo0;->d:[I

    .line 1135
    .line 1136
    iget v2, v2, Lzo0;->e:I

    .line 1137
    .line 1138
    iget v7, v7, Lxo0;->a:I

    .line 1139
    .line 1140
    sub-int/2addr v2, v7

    .line 1141
    iget v8, v4, Lzo0;->e:I

    .line 1142
    .line 1143
    sub-int v10, v8, v7

    .line 1144
    .line 1145
    invoke-static {v5, v6, v2, v10, v8}, Lba;->W([I[IIII)V

    .line 1146
    .line 1147
    .line 1148
    iget v2, v4, Lzo0;->g:I

    .line 1149
    .line 1150
    sub-int/2addr v2, v11

    .line 1151
    iput v2, v4, Lzo0;->g:I

    .line 1152
    .line 1153
    iget v2, v4, Lzo0;->e:I

    .line 1154
    .line 1155
    sub-int/2addr v2, v7

    .line 1156
    iput v2, v4, Lzo0;->e:I

    .line 1157
    .line 1158
    const/4 v2, 0x1

    .line 1159
    :cond_486
    iget-object v4, v0, Ld10;->G:Lw51;

    .line 1160
    .line 1161
    iget v5, v4, Lw51;->k:I

    .line 1162
    .line 1163
    if-lez v5, :cond_48d

    .line 1164
    .line 1165
    goto :goto_492

    .line 1166
    :cond_48d
    const-string v5, "Unbalanced begin/end empty"

    .line 1167
    .line 1168
    invoke-static {v5}, Lrt0;->a(Ljava/lang/String;)V

    .line 1169
    .line 1170
    .line 1171
    :goto_492
    iget v5, v4, Lw51;->k:I

    .line 1172
    .line 1173
    add-int/lit8 v5, v5, -0x1

    .line 1174
    .line 1175
    iput v5, v4, Lw51;->k:I

    .line 1176
    .line 1177
    iget-object v4, v0, Ld10;->I:La61;

    .line 1178
    .line 1179
    iget v5, v4, La61;->v:I

    .line 1180
    .line 1181
    invoke-virtual {v4}, La61;->j()V

    .line 1182
    .line 1183
    .line 1184
    iget-object v4, v0, Ld10;->G:Lw51;

    .line 1185
    .line 1186
    iget v4, v4, Lw51;->k:I

    .line 1187
    .line 1188
    if-lez v4, :cond_4a7

    .line 1189
    .line 1190
    goto/16 :goto_5fb

    .line 1191
    .line 1192
    :cond_4a7
    rsub-int/lit8 v4, v5, -0x2

    .line 1193
    .line 1194
    iget-object v5, v0, Ld10;->I:La61;

    .line 1195
    .line 1196
    invoke-virtual {v5}, La61;->k()V

    .line 1197
    .line 1198
    .line 1199
    iget-object v5, v0, Ld10;->I:La61;

    .line 1200
    .line 1201
    const/4 v8, 0x1

    .line 1202
    invoke-virtual {v5, v8}, La61;->e(Z)V

    .line 1203
    .line 1204
    .line 1205
    iget-object v5, v0, Ld10;->N:Ly00;

    .line 1206
    .line 1207
    iget-object v6, v0, Ld10;->O:Lbw;

    .line 1208
    .line 1209
    iget-object v6, v6, Lbw;->b:Lzo0;

    .line 1210
    .line 1211
    invoke-virtual {v6}, Lzo0;->B()Z

    .line 1212
    .line 1213
    .line 1214
    move-result v6

    .line 1215
    iget-object v7, v0, Ld10;->H:Lx51;

    .line 1216
    .line 1217
    if-eqz v6, :cond_524

    .line 1218
    .line 1219
    invoke-virtual {v9}, Lpj;->b()V

    .line 1220
    .line 1221
    .line 1222
    const/4 v8, 0x0

    .line 1223
    invoke-virtual {v9, v8}, Lpj;->d(Z)V

    .line 1224
    .line 1225
    .line 1226
    iget-object v6, v9, Lpj;->d:Lw60;

    .line 1227
    .line 1228
    iget-object v8, v9, Lpj;->a:Ld10;

    .line 1229
    .line 1230
    iget-object v8, v8, Ld10;->G:Lw51;

    .line 1231
    .line 1232
    iget v10, v8, Lw51;->c:I

    .line 1233
    .line 1234
    if-lez v10, :cond_510

    .line 1235
    .line 1236
    iget v10, v8, Lw51;->i:I

    .line 1237
    .line 1238
    invoke-virtual {v6, v3}, Lw60;->a(I)I

    .line 1239
    .line 1240
    .line 1241
    move-result v3

    .line 1242
    if-eq v3, v10, :cond_510

    .line 1243
    .line 1244
    iget-boolean v3, v9, Lpj;->c:Z

    .line 1245
    .line 1246
    if-nez v3, :cond_4f3

    .line 1247
    .line 1248
    iget-boolean v3, v9, Lpj;->e:Z

    .line 1249
    .line 1250
    if-eqz v3, :cond_4f3

    .line 1251
    .line 1252
    const/4 v3, 0x0

    .line 1253
    invoke-virtual {v9, v3}, Lpj;->d(Z)V

    .line 1254
    .line 1255
    .line 1256
    iget-object v3, v9, Lpj;->b:Lve;

    .line 1257
    .line 1258
    iget-object v3, v3, Lve;->F:Lzo0;

    .line 1259
    .line 1260
    sget-object v11, Leo0;->c:Leo0;

    .line 1261
    .line 1262
    invoke-virtual {v3, v11}, Lzo0;->C(Lxo0;)V

    .line 1263
    .line 1264
    .line 1265
    const/4 v3, 0x1

    .line 1266
    iput-boolean v3, v9, Lpj;->c:Z

    .line 1267
    .line 1268
    :cond_4f3
    if-lez v10, :cond_510

    .line 1269
    .line 1270
    invoke-virtual {v8, v10}, Lw51;->a(I)Ly00;

    .line 1271
    .line 1272
    .line 1273
    move-result-object v3

    .line 1274
    invoke-virtual {v6, v10}, Lw60;->c(I)V

    .line 1275
    .line 1276
    .line 1277
    const/4 v8, 0x0

    .line 1278
    invoke-virtual {v9, v8}, Lpj;->d(Z)V

    .line 1279
    .line 1280
    .line 1281
    iget-object v6, v9, Lpj;->b:Lve;

    .line 1282
    .line 1283
    iget-object v6, v6, Lve;->F:Lzo0;

    .line 1284
    .line 1285
    sget-object v10, Ldo0;->c:Ldo0;

    .line 1286
    .line 1287
    invoke-virtual {v6, v10}, Lzo0;->C(Lxo0;)V

    .line 1288
    .line 1289
    .line 1290
    invoke-static {v6, v8, v3}, Ldd0;->v(Lzo0;ILjava/lang/Object;)V

    .line 1291
    .line 1292
    .line 1293
    const/4 v8, 0x1

    .line 1294
    iput-boolean v8, v9, Lpj;->c:Z

    .line 1295
    .line 1296
    goto :goto_511

    .line 1297
    :cond_510
    const/4 v8, 0x1

    .line 1298
    :goto_511
    invoke-virtual {v9}, Lpj;->c()V

    .line 1299
    .line 1300
    .line 1301
    iget-object v3, v9, Lpj;->b:Lve;

    .line 1302
    .line 1303
    iget-object v3, v3, Lve;->F:Lzo0;

    .line 1304
    .line 1305
    sget-object v6, Lgo0;->c:Lgo0;

    .line 1306
    .line 1307
    invoke-virtual {v3, v6}, Lzo0;->C(Lxo0;)V

    .line 1308
    .line 1309
    .line 1310
    const/4 v6, 0x0

    .line 1311
    invoke-static {v3, v6, v5, v8, v7}, Ldd0;->w(Lzo0;ILjava/lang/Object;ILjava/lang/Object;)V

    .line 1312
    .line 1313
    .line 1314
    move v3, v6

    .line 1315
    goto/16 :goto_5a2

    .line 1316
    .line 1317
    :cond_524
    const/4 v6, 0x0

    .line 1318
    iget-object v8, v0, Ld10;->O:Lbw;

    .line 1319
    .line 1320
    invoke-virtual {v9}, Lpj;->b()V

    .line 1321
    .line 1322
    .line 1323
    invoke-virtual {v9, v6}, Lpj;->d(Z)V

    .line 1324
    .line 1325
    .line 1326
    iget-object v6, v9, Lpj;->d:Lw60;

    .line 1327
    .line 1328
    iget-object v10, v9, Lpj;->a:Ld10;

    .line 1329
    .line 1330
    iget-object v10, v10, Ld10;->G:Lw51;

    .line 1331
    .line 1332
    iget v11, v10, Lw51;->c:I

    .line 1333
    .line 1334
    if-lez v11, :cond_573

    .line 1335
    .line 1336
    iget v11, v10, Lw51;->i:I

    .line 1337
    .line 1338
    invoke-virtual {v6, v3}, Lw60;->a(I)I

    .line 1339
    .line 1340
    .line 1341
    move-result v3

    .line 1342
    if-eq v3, v11, :cond_573

    .line 1343
    .line 1344
    iget-boolean v3, v9, Lpj;->c:Z

    .line 1345
    .line 1346
    if-nez v3, :cond_557

    .line 1347
    .line 1348
    iget-boolean v3, v9, Lpj;->e:Z

    .line 1349
    .line 1350
    if-eqz v3, :cond_557

    .line 1351
    .line 1352
    const/4 v3, 0x0

    .line 1353
    invoke-virtual {v9, v3}, Lpj;->d(Z)V

    .line 1354
    .line 1355
    .line 1356
    iget-object v3, v9, Lpj;->b:Lve;

    .line 1357
    .line 1358
    iget-object v3, v3, Lve;->F:Lzo0;

    .line 1359
    .line 1360
    sget-object v12, Leo0;->c:Leo0;

    .line 1361
    .line 1362
    invoke-virtual {v3, v12}, Lzo0;->C(Lxo0;)V

    .line 1363
    .line 1364
    .line 1365
    const/4 v3, 0x1

    .line 1366
    iput-boolean v3, v9, Lpj;->c:Z

    .line 1367
    .line 1368
    :cond_557
    if-lez v11, :cond_573

    .line 1369
    .line 1370
    invoke-virtual {v10, v11}, Lw51;->a(I)Ly00;

    .line 1371
    .line 1372
    .line 1373
    move-result-object v3

    .line 1374
    invoke-virtual {v6, v11}, Lw60;->c(I)V

    .line 1375
    .line 1376
    .line 1377
    const/4 v6, 0x0

    .line 1378
    invoke-virtual {v9, v6}, Lpj;->d(Z)V

    .line 1379
    .line 1380
    .line 1381
    iget-object v10, v9, Lpj;->b:Lve;

    .line 1382
    .line 1383
    iget-object v10, v10, Lve;->F:Lzo0;

    .line 1384
    .line 1385
    sget-object v11, Ldo0;->c:Ldo0;

    .line 1386
    .line 1387
    invoke-virtual {v10, v11}, Lzo0;->C(Lxo0;)V

    .line 1388
    .line 1389
    .line 1390
    invoke-static {v10, v6, v3}, Ldd0;->v(Lzo0;ILjava/lang/Object;)V

    .line 1391
    .line 1392
    .line 1393
    const/4 v3, 0x1

    .line 1394
    iput-boolean v3, v9, Lpj;->c:Z

    .line 1395
    .line 1396
    :cond_573
    invoke-virtual {v9}, Lpj;->c()V

    .line 1397
    .line 1398
    .line 1399
    iget-object v3, v9, Lpj;->b:Lve;

    .line 1400
    .line 1401
    iget-object v3, v3, Lve;->F:Lzo0;

    .line 1402
    .line 1403
    sget-object v6, Lho0;->c:Lho0;

    .line 1404
    .line 1405
    invoke-virtual {v3, v6}, Lzo0;->C(Lxo0;)V

    .line 1406
    .line 1407
    .line 1408
    iget v6, v3, Lzo0;->g:I

    .line 1409
    .line 1410
    iget-object v9, v3, Lzo0;->b:[Lxo0;

    .line 1411
    .line 1412
    iget v10, v3, Lzo0;->c:I

    .line 1413
    .line 1414
    const/16 v18, 0x1

    .line 1415
    .line 1416
    add-int/lit8 v10, v10, -0x1

    .line 1417
    .line 1418
    aget-object v9, v9, v10

    .line 1419
    .line 1420
    iget v9, v9, Lxo0;->b:I

    .line 1421
    .line 1422
    sub-int/2addr v6, v9

    .line 1423
    iget-object v3, v3, Lzo0;->f:[Ljava/lang/Object;

    .line 1424
    .line 1425
    aput-object v5, v3, v6

    .line 1426
    .line 1427
    add-int/lit8 v5, v6, 0x1

    .line 1428
    .line 1429
    aput-object v7, v3, v5

    .line 1430
    .line 1431
    add-int/lit8 v6, v6, 0x2

    .line 1432
    .line 1433
    aput-object v8, v3, v6

    .line 1434
    .line 1435
    new-instance v3, Lbw;

    .line 1436
    .line 1437
    invoke-direct {v3}, Lbw;-><init>()V

    .line 1438
    .line 1439
    .line 1440
    iput-object v3, v0, Ld10;->O:Lbw;

    .line 1441
    .line 1442
    const/4 v3, 0x0

    .line 1443
    :goto_5a2
    iput-boolean v3, v0, Ld10;->S:Z

    .line 1444
    .line 1445
    iget-object v5, v0, Ld10;->c:Lx51;

    .line 1446
    .line 1447
    iget v5, v5, Lx51;->f:I

    .line 1448
    .line 1449
    if-nez v5, :cond_5ab

    .line 1450
    .line 1451
    goto :goto_5fb

    .line 1452
    :cond_5ab
    invoke-virtual {v0, v4, v3}, Ld10;->d0(II)V

    .line 1453
    .line 1454
    .line 1455
    invoke-virtual {v0, v4, v2}, Ld10;->e0(II)V

    .line 1456
    .line 1457
    .line 1458
    goto :goto_5fb

    .line 1459
    :cond_5b2
    if-eqz p1, :cond_5b7

    .line 1460
    .line 1461
    invoke-virtual {v9}, Lpj;->a()V

    .line 1462
    .line 1463
    .line 1464
    :cond_5b7
    iget-object v3, v9, Lpj;->a:Ld10;

    .line 1465
    .line 1466
    iget-object v3, v3, Ld10;->G:Lw51;

    .line 1467
    .line 1468
    iget v3, v3, Lw51;->i:I

    .line 1469
    .line 1470
    iget-object v4, v9, Lpj;->d:Lw60;

    .line 1471
    .line 1472
    move/from16 v5, v17

    .line 1473
    .line 1474
    invoke-virtual {v4, v5}, Lw60;->a(I)I

    .line 1475
    .line 1476
    .line 1477
    move-result v6

    .line 1478
    if-gt v6, v3, :cond_5c8

    .line 1479
    .line 1480
    goto :goto_5cd

    .line 1481
    :cond_5c8
    const-string v6, "Missed recording an endGroup"

    .line 1482
    .line 1483
    invoke-static {v6}, Lqj;->a(Ljava/lang/String;)V

    .line 1484
    .line 1485
    .line 1486
    :goto_5cd
    invoke-virtual {v4, v5}, Lw60;->a(I)I

    .line 1487
    .line 1488
    .line 1489
    move-result v5

    .line 1490
    if-ne v5, v3, :cond_5e3

    .line 1491
    .line 1492
    const/4 v8, 0x0

    .line 1493
    invoke-virtual {v9, v8}, Lpj;->d(Z)V

    .line 1494
    .line 1495
    .line 1496
    invoke-virtual {v4}, Lw60;->b()I

    .line 1497
    .line 1498
    .line 1499
    iget-object v3, v9, Lpj;->b:Lve;

    .line 1500
    .line 1501
    iget-object v3, v3, Lve;->F:Lzo0;

    .line 1502
    .line 1503
    sget-object v4, Lao0;->c:Lao0;

    .line 1504
    .line 1505
    invoke-virtual {v3, v4}, Lzo0;->C(Lxo0;)V

    .line 1506
    .line 1507
    .line 1508
    :cond_5e3
    iget-object v3, v0, Ld10;->G:Lw51;

    .line 1509
    .line 1510
    iget v3, v3, Lw51;->i:I

    .line 1511
    .line 1512
    invoke-virtual {v0, v3}, Ld10;->i0(I)I

    .line 1513
    .line 1514
    .line 1515
    move-result v4

    .line 1516
    if-eq v2, v4, :cond_5f0

    .line 1517
    .line 1518
    invoke-virtual {v0, v3, v2}, Ld10;->e0(II)V

    .line 1519
    .line 1520
    .line 1521
    :cond_5f0
    if-eqz p1, :cond_5f3

    .line 1522
    .line 1523
    const/4 v2, 0x1

    .line 1524
    :cond_5f3
    iget-object v3, v0, Ld10;->G:Lw51;

    .line 1525
    .line 1526
    invoke-virtual {v3}, Lw51;->e()V

    .line 1527
    .line 1528
    .line 1529
    invoke-virtual {v9}, Lpj;->c()V

    .line 1530
    .line 1531
    .line 1532
    :goto_5fb
    iget-object v3, v0, Ld10;->i:Ljava/util/ArrayList;

    .line 1533
    .line 1534
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    .line 1535
    .line 1536
    .line 1537
    move-result v4

    .line 1538
    const/16 v18, 0x1

    .line 1539
    .line 1540
    add-int/lit8 v4, v4, -0x1

    .line 1541
    .line 1542
    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 1543
    .line 1544
    .line 1545
    move-result-object v3

    .line 1546
    check-cast v3, Lg10;

    .line 1547
    .line 1548
    if-eqz v3, :cond_615

    .line 1549
    .line 1550
    if-nez v1, :cond_615

    .line 1551
    .line 1552
    iget v1, v3, Lg10;->c:I

    .line 1553
    .line 1554
    add-int/lit8 v1, v1, 0x1

    .line 1555
    .line 1556
    iput v1, v3, Lg10;->c:I

    .line 1557
    .line 1558
    :cond_615
    iput-object v3, v0, Ld10;->j:Lg10;

    .line 1559
    .line 1560
    invoke-virtual/range {v21 .. v21}, Lw60;->b()I

    .line 1561
    .line 1562
    .line 1563
    move-result v1

    .line 1564
    add-int/2addr v1, v2

    .line 1565
    iput v1, v0, Ld10;->k:I

    .line 1566
    .line 1567
    invoke-virtual/range {v21 .. v21}, Lw60;->b()I

    .line 1568
    .line 1569
    .line 1570
    move-result v1

    .line 1571
    iput v1, v0, Ld10;->m:I

    .line 1572
    .line 1573
    invoke-virtual/range {v21 .. v21}, Lw60;->b()I

    .line 1574
    .line 1575
    .line 1576
    move-result v1

    .line 1577
    add-int/2addr v1, v2

    .line 1578
    iput v1, v0, Ld10;->l:I

    .line 1579
    .line 1580
    return-void

    .line 1581
    :cond_62c
    move/from16 v5, v17

    .line 1582
    .line 1583
    const/4 v8, 0x0

    .line 1584
    const/16 v18, 0x1

    .line 1585
    .line 1586
    invoke-virtual {v0}, Ld10;->I()V

    .line 1587
    .line 1588
    .line 1589
    iget-object v7, v0, Ld10;->G:Lw51;

    .line 1590
    .line 1591
    invoke-virtual {v7}, Lw51;->s()I

    .line 1592
    .line 1593
    .line 1594
    move-result v7

    .line 1595
    invoke-virtual {v9, v4, v7}, Lpj;->e(II)V

    .line 1596
    .line 1597
    .line 1598
    iget-object v7, v0, Ld10;->G:Lw51;

    .line 1599
    .line 1600
    iget v7, v7, Lw51;->g:I

    .line 1601
    .line 1602
    move-object/from16 v10, v37

    .line 1603
    .line 1604
    invoke-static {v10, v6, v7}, Lvn;->f(Ljava/util/List;II)V

    .line 1605
    .line 1606
    .line 1607
    goto/16 :goto_420
.end method

.method public final q()V
    .registers 3

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-virtual {p0, v0}, Ld10;->p(Z)V

    .line 3
    .line 4
    .line 5
    invoke-virtual {p0}, Ld10;->x()Lxv0;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    if-eqz p0, :cond_14

    .line 10
    .line 11
    iget v0, p0, Lxv0;->b:I

    .line 12
    .line 13
    and-int/lit8 v1, v0, 0x1

    .line 14
    .line 15
    if-eqz v1, :cond_14

    .line 16
    .line 17
    or-int/lit8 v0, v0, 0x2

    .line 18
    .line 19
    iput v0, p0, Lxv0;->b:I

    .line 20
    .line 21
    :cond_14
    return-void
.end method

.method public final r()Lxv0;
    .registers 22

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-object v1, v0, Ld10;->E:Ljava/util/ArrayList;

    .line 4
    .line 5
    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    .line 6
    .line 7
    .line 8
    move-result v2

    .line 9
    const/4 v3, 0x1

    .line 10
    if-nez v2, :cond_17

    .line 11
    .line 12
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 13
    .line 14
    .line 15
    move-result v2

    .line 16
    sub-int/2addr v2, v3

    .line 17
    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    check-cast v1, Lxv0;

    .line 22
    .line 23
    goto :goto_18

    .line 24
    :cond_17
    const/4 v1, 0x0

    .line 25
    :goto_18
    const/4 v2, 0x0

    .line 26
    if-eqz v1, :cond_bf

    .line 27
    .line 28
    iget v5, v1, Lxv0;->b:I

    .line 29
    .line 30
    and-int/lit8 v5, v5, -0x9

    .line 31
    .line 32
    iput v5, v1, Lxv0;->b:I

    .line 33
    .line 34
    iget-object v5, v0, Ld10;->g:Lpg0;

    .line 35
    .line 36
    invoke-virtual {v5}, Lpg0;->k()V

    .line 37
    .line 38
    .line 39
    iget v5, v0, Ld10;->B:I

    .line 40
    .line 41
    iget-object v6, v1, Lxv0;->f:Lzj0;

    .line 42
    .line 43
    if-eqz v6, :cond_85

    .line 44
    .line 45
    iget v7, v1, Lxv0;->b:I

    .line 46
    .line 47
    and-int/lit8 v7, v7, 0x10

    .line 48
    .line 49
    if-eqz v7, :cond_33

    .line 50
    .line 51
    goto :goto_85

    .line 52
    :cond_33
    iget-object v7, v6, Lzj0;->b:[Ljava/lang/Object;

    .line 53
    .line 54
    iget-object v8, v6, Lzj0;->c:[I

    .line 55
    .line 56
    iget-object v9, v6, Lzj0;->a:[J

    .line 57
    .line 58
    array-length v10, v9

    .line 59
    add-int/lit8 v10, v10, -0x2

    .line 60
    .line 61
    if-ltz v10, :cond_85

    .line 62
    .line 63
    move v11, v2

    .line 64
    :goto_3f
    aget-wide v12, v9, v11

    .line 65
    .line 66
    not-long v14, v12

    .line 67
    const/16 v16, 0x7

    .line 68
    .line 69
    shl-long v14, v14, v16

    .line 70
    .line 71
    and-long/2addr v14, v12

    .line 72
    const-wide v16, -0x7f7f7f7f7f7f7f80L  # -2.937446524422997E-306

    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    and-long v14, v14, v16

    .line 78
    .line 79
    cmp-long v14, v14, v16

    .line 80
    .line 81
    if-eqz v14, :cond_7f

    .line 82
    .line 83
    sub-int v14, v11, v10

    .line 84
    .line 85
    not-int v14, v14

    .line 86
    ushr-int/lit8 v14, v14, 0x1f

    .line 87
    .line 88
    const/16 v15, 0x8

    .line 89
    .line 90
    rsub-int/lit8 v14, v14, 0x8

    .line 91
    .line 92
    move v4, v2

    .line 93
    :goto_5c
    if-ge v4, v14, :cond_7d

    .line 94
    .line 95
    const-wide/16 v17, 0xff

    .line 96
    .line 97
    and-long v17, v12, v17

    .line 98
    .line 99
    const-wide/16 v19, 0x80

    .line 100
    .line 101
    cmp-long v17, v17, v19

    .line 102
    .line 103
    if-gez v17, :cond_78

    .line 104
    .line 105
    shl-int/lit8 v17, v11, 0x3

    .line 106
    .line 107
    add-int v17, v17, v4

    .line 108
    .line 109
    aget-object v18, v7, v17

    .line 110
    .line 111
    aget v3, v8, v17

    .line 112
    .line 113
    if-eq v3, v5, :cond_78

    .line 114
    .line 115
    new-instance v3, Lwv0;

    .line 116
    .line 117
    invoke-direct {v3, v5, v2, v1, v6}, Lwv0;-><init>(IILjava/lang/Object;Ljava/lang/Object;)V

    .line 118
    .line 119
    .line 120
    goto :goto_86

    .line 121
    :cond_78
    shr-long/2addr v12, v15

    .line 122
    add-int/lit8 v4, v4, 0x1

    .line 123
    .line 124
    const/4 v3, 0x1

    .line 125
    goto :goto_5c

    .line 126
    :cond_7d
    if-ne v14, v15, :cond_85

    .line 127
    .line 128
    :cond_7f
    if-eq v11, v10, :cond_85

    .line 129
    .line 130
    add-int/lit8 v11, v11, 0x1

    .line 131
    .line 132
    const/4 v3, 0x1

    .line 133
    goto :goto_3f

    .line 134
    :cond_85
    :goto_85
    const/4 v3, 0x0

    .line 135
    :goto_86
    iget-object v4, v0, Ld10;->M:Lpj;

    .line 136
    .line 137
    if-eqz v3, :cond_99

    .line 138
    .line 139
    iget-object v5, v4, Lpj;->b:Lve;

    .line 140
    .line 141
    iget-object v5, v5, Lve;->F:Lzo0;

    .line 142
    .line 143
    sget-object v6, Lzn0;->c:Lzn0;

    .line 144
    .line 145
    invoke-virtual {v5, v6}, Lzo0;->C(Lxo0;)V

    .line 146
    .line 147
    .line 148
    iget-object v6, v0, Ld10;->h:Lyj;

    .line 149
    .line 150
    const/4 v7, 0x1

    .line 151
    invoke-static {v5, v2, v3, v7, v6}, Ldd0;->w(Lzo0;ILjava/lang/Object;ILjava/lang/Object;)V

    .line 152
    .line 153
    .line 154
    :cond_99
    iget v3, v1, Lxv0;->b:I

    .line 155
    .line 156
    and-int/lit16 v5, v3, 0x200

    .line 157
    .line 158
    if-eqz v5, :cond_bf

    .line 159
    .line 160
    and-int/lit16 v3, v3, -0x201

    .line 161
    .line 162
    iput v3, v1, Lxv0;->b:I

    .line 163
    .line 164
    iget-object v3, v4, Lpj;->b:Lve;

    .line 165
    .line 166
    iget-object v3, v3, Lve;->F:Lzo0;

    .line 167
    .line 168
    sget-object v4, Lco0;->c:Lco0;

    .line 169
    .line 170
    invoke-virtual {v3, v4}, Lzo0;->C(Lxo0;)V

    .line 171
    .line 172
    .line 173
    invoke-static {v3, v2, v1}, Ldd0;->v(Lzo0;ILjava/lang/Object;)V

    .line 174
    .line 175
    .line 176
    iget v3, v1, Lxv0;->b:I

    .line 177
    .line 178
    and-int/lit16 v4, v3, -0x81

    .line 179
    .line 180
    iput v4, v1, Lxv0;->b:I

    .line 181
    .line 182
    and-int/lit16 v4, v3, 0x400

    .line 183
    .line 184
    if-eqz v4, :cond_bf

    .line 185
    .line 186
    and-int/lit16 v3, v3, -0x481

    .line 187
    .line 188
    iput v3, v1, Lxv0;->b:I

    .line 189
    .line 190
    iput-boolean v2, v0, Ld10;->y:Z

    .line 191
    .line 192
    :cond_bf
    if-eqz v1, :cond_f6

    .line 193
    .line 194
    iget v3, v1, Lxv0;->b:I

    .line 195
    .line 196
    and-int/lit8 v4, v3, 0x10

    .line 197
    .line 198
    if-eqz v4, :cond_c8

    .line 199
    .line 200
    goto :goto_f6

    .line 201
    :cond_c8
    const/16 v18, 0x1

    .line 202
    .line 203
    and-int/lit8 v3, v3, 0x1

    .line 204
    .line 205
    if-eqz v3, :cond_cf

    .line 206
    .line 207
    goto :goto_d3

    .line 208
    :cond_cf
    iget-boolean v3, v0, Ld10;->q:Z

    .line 209
    .line 210
    if-eqz v3, :cond_f6

    .line 211
    .line 212
    :goto_d3
    iget-object v3, v1, Lxv0;->c:Ly00;

    .line 213
    .line 214
    if-nez v3, :cond_ee

    .line 215
    .line 216
    iget-boolean v3, v0, Ld10;->S:Z

    .line 217
    .line 218
    if-eqz v3, :cond_e4

    .line 219
    .line 220
    iget-object v3, v0, Ld10;->I:La61;

    .line 221
    .line 222
    iget v4, v3, La61;->v:I

    .line 223
    .line 224
    invoke-virtual {v3, v4}, La61;->b(I)Ly00;

    .line 225
    .line 226
    .line 227
    move-result-object v3

    .line 228
    goto :goto_ec

    .line 229
    :cond_e4
    iget-object v3, v0, Ld10;->G:Lw51;

    .line 230
    .line 231
    iget v4, v3, Lw51;->i:I

    .line 232
    .line 233
    invoke-virtual {v3, v4}, Lw51;->a(I)Ly00;

    .line 234
    .line 235
    .line 236
    move-result-object v3

    .line 237
    :goto_ec
    iput-object v3, v1, Lxv0;->c:Ly00;

    .line 238
    .line 239
    :cond_ee
    iget v3, v1, Lxv0;->b:I

    .line 240
    .line 241
    and-int/lit8 v3, v3, -0x5

    .line 242
    .line 243
    iput v3, v1, Lxv0;->b:I

    .line 244
    .line 245
    move-object v4, v1

    .line 246
    goto :goto_f7

    .line 247
    :cond_f6
    :goto_f6
    const/4 v4, 0x0

    .line 248
    :goto_f7
    invoke-virtual {v0, v2}, Ld10;->p(Z)V

    .line 249
    .line 250
    .line 251
    return-object v4
.end method

.method public final s()V
    .registers 3

    .line 1
    iget-boolean v0, p0, Ld10;->F:Z

    .line 2
    .line 3
    if-nez v0, :cond_b

    .line 4
    .line 5
    iget v0, p0, Ld10;->z:I

    .line 6
    .line 7
    const/16 v1, 0x64

    .line 8
    .line 9
    if-ne v0, v1, :cond_b

    .line 10
    .line 11
    goto :goto_10

    .line 12
    :cond_b
    const-string v0, "Cannot disable reuse from root if it was caused by other groups"

    .line 13
    .line 14
    invoke-static {v0}, Lrt0;->a(Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    :goto_10
    const/4 v0, -0x1

    .line 18
    iput v0, p0, Ld10;->z:I

    .line 19
    .line 20
    const/4 v0, 0x0

    .line 21
    iput-boolean v0, p0, Ld10;->y:Z

    .line 22
    .line 23
    return-void
.end method

.method public final t()V
    .registers 5

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-virtual {p0, v0}, Ld10;->p(Z)V

    .line 3
    .line 4
    .line 5
    iget-object v1, p0, Ld10;->b:Lsj;

    .line 6
    .line 7
    invoke-virtual {v1}, Lsj;->c()V

    .line 8
    .line 9
    .line 10
    invoke-virtual {p0, v0}, Ld10;->p(Z)V

    .line 11
    .line 12
    .line 13
    iget-object v1, p0, Ld10;->M:Lpj;

    .line 14
    .line 15
    iget-boolean v2, v1, Lpj;->c:Z

    .line 16
    .line 17
    if-eqz v2, :cond_23

    .line 18
    .line 19
    invoke-virtual {v1, v0}, Lpj;->d(Z)V

    .line 20
    .line 21
    .line 22
    invoke-virtual {v1, v0}, Lpj;->d(Z)V

    .line 23
    .line 24
    .line 25
    iget-object v2, v1, Lpj;->b:Lve;

    .line 26
    .line 27
    iget-object v2, v2, Lve;->F:Lzo0;

    .line 28
    .line 29
    sget-object v3, Lao0;->c:Lao0;

    .line 30
    .line 31
    invoke-virtual {v2, v3}, Lzo0;->C(Lxo0;)V

    .line 32
    .line 33
    .line 34
    iput-boolean v0, v1, Lpj;->c:Z

    .line 35
    .line 36
    :cond_23
    invoke-virtual {v1}, Lpj;->b()V

    .line 37
    .line 38
    .line 39
    iget-object v1, v1, Lpj;->d:Lw60;

    .line 40
    .line 41
    iget v1, v1, Lw60;->b:I

    .line 42
    .line 43
    if-nez v1, :cond_2d

    .line 44
    .line 45
    goto :goto_32

    .line 46
    :cond_2d
    const-string v1, "Missed recording an endGroup()"

    .line 47
    .line 48
    invoke-static {v1}, Lqj;->a(Ljava/lang/String;)V

    .line 49
    .line 50
    .line 51
    :goto_32
    iget-object v1, p0, Ld10;->i:Ljava/util/ArrayList;

    .line 52
    .line 53
    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    .line 54
    .line 55
    .line 56
    move-result v1

    .line 57
    if-nez v1, :cond_3f

    .line 58
    .line 59
    const-string v1, "Start/end imbalance"

    .line 60
    .line 61
    invoke-static {v1}, Lqj;->a(Ljava/lang/String;)V

    .line 62
    .line 63
    .line 64
    :cond_3f
    invoke-virtual {p0}, Ld10;->i()V

    .line 65
    .line 66
    .line 67
    iget-object v1, p0, Ld10;->G:Lw51;

    .line 68
    .line 69
    invoke-virtual {v1}, Lw51;->c()V

    .line 70
    .line 71
    .line 72
    iget-object v1, p0, Ld10;->x:Lw60;

    .line 73
    .line 74
    invoke-virtual {v1}, Lw60;->b()I

    .line 75
    .line 76
    .line 77
    move-result v1

    .line 78
    if-eqz v1, :cond_50

    .line 79
    .line 80
    const/4 v0, 0x1

    .line 81
    :cond_50
    iput-boolean v0, p0, Ld10;->w:Z

    .line 82
    .line 83
    return-void
.end method

.method public final u(ZLg10;)V
    .registers 5

    .line 1
    iget-object v0, p0, Ld10;->i:Ljava/util/ArrayList;

    .line 2
    .line 3
    iget-object v1, p0, Ld10;->j:Lg10;

    .line 4
    .line 5
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 6
    .line 7
    .line 8
    iput-object p2, p0, Ld10;->j:Lg10;

    .line 9
    .line 10
    iget p2, p0, Ld10;->l:I

    .line 11
    .line 12
    iget-object v0, p0, Ld10;->n:Lw60;

    .line 13
    .line 14
    invoke-virtual {v0, p2}, Lw60;->c(I)V

    .line 15
    .line 16
    .line 17
    iget p2, p0, Ld10;->m:I

    .line 18
    .line 19
    invoke-virtual {v0, p2}, Lw60;->c(I)V

    .line 20
    .line 21
    .line 22
    iget p2, p0, Ld10;->k:I

    .line 23
    .line 24
    invoke-virtual {v0, p2}, Lw60;->c(I)V

    .line 25
    .line 26
    .line 27
    const/4 p2, 0x0

    .line 28
    if-eqz p1, :cond_1f

    .line 29
    .line 30
    iput p2, p0, Ld10;->k:I

    .line 31
    .line 32
    :cond_1f
    iput p2, p0, Ld10;->l:I

    .line 33
    .line 34
    iput p2, p0, Ld10;->m:I

    .line 35
    .line 36
    return-void
.end method

.method public final v()V
    .registers 3

    .line 1
    new-instance v0, Lx51;

    .line 2
    .line 3
    invoke-direct {v0}, Lx51;-><init>()V

    .line 4
    .line 5
    .line 6
    iget-boolean v1, p0, Ld10;->C:Z

    .line 7
    .line 8
    if-eqz v1, :cond_c

    .line 9
    .line 10
    invoke-virtual {v0}, Lx51;->b()V

    .line 11
    .line 12
    .line 13
    :cond_c
    iget-object v1, p0, Ld10;->b:Lsj;

    .line 14
    .line 15
    invoke-virtual {v1}, Lsj;->d()Z

    .line 16
    .line 17
    .line 18
    move-result v1

    .line 19
    if-eqz v1, :cond_1b

    .line 20
    .line 21
    new-instance v1, Lsj0;

    .line 22
    .line 23
    invoke-direct {v1}, Lsj0;-><init>()V

    .line 24
    .line 25
    .line 26
    iput-object v1, v0, Lx51;->o:Lsj0;

    .line 27
    .line 28
    :cond_1b
    iput-object v0, p0, Ld10;->H:Lx51;

    .line 29
    .line 30
    invoke-virtual {v0}, Lx51;->e()La61;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    const/4 v1, 0x1

    .line 35
    invoke-virtual {v0, v1}, La61;->e(Z)V

    .line 36
    .line 37
    .line 38
    iput-object v0, p0, Ld10;->I:La61;

    .line 39
    .line 40
    return-void
.end method

.method public final w()Luj;
    .registers 3

    .line 1
    iget-object v0, p0, Ld10;->U:Le10;

    .line 2
    .line 3
    if-nez v0, :cond_d

    .line 4
    .line 5
    new-instance v0, Le10;

    .line 6
    .line 7
    iget-object v1, p0, Ld10;->h:Lyj;

    .line 8
    .line 9
    invoke-direct {v0, v1}, Le10;-><init>(Lrj;)V

    .line 10
    .line 11
    .line 12
    iput-object v0, p0, Ld10;->U:Le10;

    .line 13
    .line 14
    :cond_d
    return-object v0
.end method

.method public final x()Lxv0;
    .registers 2

    .line 1
    iget v0, p0, Ld10;->A:I

    .line 2
    .line 3
    if-nez v0, :cond_19

    .line 4
    .line 5
    iget-object p0, p0, Ld10;->E:Ljava/util/ArrayList;

    .line 6
    .line 7
    invoke-virtual {p0}, Ljava/util/ArrayList;->isEmpty()Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-nez v0, :cond_19

    .line 12
    .line 13
    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    add-int/lit8 v0, v0, -0x1

    .line 18
    .line 19
    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object p0

    .line 23
    check-cast p0, Lxv0;

    .line 24
    .line 25
    return-object p0

    .line 26
    :cond_19
    const/4 p0, 0x0

    .line 27
    return-object p0
.end method

.method public final y()Z
    .registers 2

    .line 1
    invoke-virtual {p0}, Ld10;->A()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_19

    .line 6
    .line 7
    iget-boolean v0, p0, Ld10;->w:Z

    .line 8
    .line 9
    if-nez v0, :cond_19

    .line 10
    .line 11
    invoke-virtual {p0}, Ld10;->x()Lxv0;

    .line 12
    .line 13
    .line 14
    move-result-object p0

    .line 15
    if-eqz p0, :cond_17

    .line 16
    .line 17
    iget p0, p0, Lxv0;->b:I

    .line 18
    .line 19
    and-int/lit8 p0, p0, 0x4

    .line 20
    .line 21
    if-eqz p0, :cond_17

    .line 22
    .line 23
    goto :goto_19

    .line 24
    :cond_17
    const/4 p0, 0x0

    .line 25
    return p0

    .line 26
    :cond_19
    :goto_19
    const/4 p0, 0x1

    .line 27
    return p0
.end method

.method public final z()Lwj;
    .registers 2

    .line 1
    iget-object v0, p0, Ld10;->b:Lsj;

    .line 2
    .line 3
    invoke-virtual {v0}, Lsj;->k()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_b

    .line 8
    .line 9
    iget-object p0, p0, Ld10;->Q:Lwj;

    .line 10
    .line 11
    return-object p0

    .line 12
    :cond_b
    const/4 p0, 0x0

    .line 13
    return-object p0
.end method
