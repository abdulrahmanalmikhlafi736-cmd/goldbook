.class public final Lcom/almekhlafi/goldbook/utils/jsBridge/ClipboardBridge;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field private final context:Landroid/content/Context;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/almekhlafi/goldbook/utils/jsBridge/ClipboardBridge;->context:Landroid/content/Context;

    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final copyImageToClipboard(Ljava/lang/String;Ljava/lang/String;)V
    .registers 13
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .line 1
    const-string v0, ","

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    const/4 p2, 0x0

    .line 10
    :try_start_9
    invoke-static {p1, v0}, Lq81;->z(Ljava/lang/String;Ljava/lang/String;)Z

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    if-nez v1, :cond_23

    .line 15
    .line 16
    iget-object p1, p0, Lcom/almekhlafi/goldbook/utils/jsBridge/ClipboardBridge;->context:Landroid/content/Context;

    .line 17
    .line 18
    const v0, 0x7f0a0020

    .line 19
    .line 20
    .line 21
    invoke-virtual {p1, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    invoke-static {p1, v0, p2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 26
    .line 27
    .line 28
    move-result-object p1

    .line 29
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 30
    .line 31
    .line 32
    return-void

    .line 33
    :catchall_20
    move-exception p1

    .line 34
    goto/16 :goto_11d

    .line 35
    .line 36
    :cond_23
    filled-new-array {v0}, [Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    invoke-static {p1, v0}, Lq81;->H(Ljava/lang/String;[Ljava/lang/String;)Ljava/util/List;

    .line 41
    .line 42
    .line 43
    move-result-object p1

    .line 44
    const/4 v0, 0x1

    .line 45
    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object p1

    .line 49
    check-cast p1, Ljava/lang/String;

    .line 50
    .line 51
    invoke-static {p1, p2}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    .line 52
    .line 53
    .line 54
    move-result-object p1

    .line 55
    array-length v0, p1

    .line 56
    invoke-static {p1, p2, v0}, Landroid/graphics/BitmapFactory;->decodeByteArray([BII)Landroid/graphics/Bitmap;

    .line 57
    .line 58
    .line 59
    move-result-object p1
    :try_end_3b
    .catchall {:try_start_9 .. :try_end_3b} :catchall_20

    .line 60
    iget-object v0, p0, Lcom/almekhlafi/goldbook/utils/jsBridge/ClipboardBridge;->context:Landroid/content/Context;

    .line 61
    .line 62
    if-nez p1, :cond_4e

    .line 63
    .line 64
    const p1, 0x7f0a0021

    .line 65
    .line 66
    .line 67
    :try_start_42
    invoke-virtual {v0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 68
    .line 69
    .line 70
    move-result-object p1

    .line 71
    invoke-static {v0, p1, p2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 72
    .line 73
    .line 74
    move-result-object p1

    .line 75
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 76
    .line 77
    .line 78
    return-void

    .line 79
    :cond_4e
    const-string v1, "clipboard"

    .line 80
    .line 81
    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 82
    .line 83
    .line 84
    move-result-object v0

    .line 85
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 86
    .line 87
    .line 88
    check-cast v0, Landroid/content/ClipboardManager;

    .line 89
    .line 90
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 91
    .line 92
    const/16 v2, 0x18

    .line 93
    .line 94
    if-lt v1, v2, :cond_10a

    .line 95
    .line 96
    new-instance v1, Ljava/io/File;

    .line 97
    .line 98
    iget-object v2, p0, Lcom/almekhlafi/goldbook/utils/jsBridge/ClipboardBridge;->context:Landroid/content/Context;

    .line 99
    .line 100
    invoke-virtual {v2}, Landroid/content/Context;->getCacheDir()Ljava/io/File;

    .line 101
    .line 102
    .line 103
    move-result-object v2

    .line 104
    const-string v3, "clipboard_images"

    .line 105
    .line 106
    invoke-direct {v1, v2, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 107
    .line 108
    .line 109
    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    .line 110
    .line 111
    .line 112
    move-result v2

    .line 113
    if-nez v2, :cond_75

    .line 114
    .line 115
    invoke-virtual {v1}, Ljava/io/File;->mkdirs()Z

    .line 116
    .line 117
    .line 118
    :cond_75
    invoke-virtual {v1}, Ljava/io/File;->listFiles()[Ljava/io/File;

    .line 119
    .line 120
    .line 121
    move-result-object v2

    .line 122
    if-eqz v2, :cond_97

    .line 123
    .line 124
    array-length v3, v2

    .line 125
    move v4, p2

    .line 126
    :goto_7d
    if-ge v4, v3, :cond_97

    .line 127
    .line 128
    aget-object v5, v2, v4

    .line 129
    .line 130
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 131
    .line 132
    .line 133
    move-result-wide v6

    .line 134
    invoke-virtual {v5}, Ljava/io/File;->lastModified()J

    .line 135
    .line 136
    .line 137
    move-result-wide v8

    .line 138
    sub-long/2addr v6, v8

    .line 139
    const-wide/32 v8, 0x36ee80

    .line 140
    .line 141
    .line 142
    cmp-long v6, v6, v8

    .line 143
    .line 144
    if-lez v6, :cond_94

    .line 145
    .line 146
    invoke-virtual {v5}, Ljava/io/File;->delete()Z

    .line 147
    .line 148
    .line 149
    :cond_94
    add-int/lit8 v4, v4, 0x1

    .line 150
    .line 151
    goto :goto_7d

    .line 152
    :cond_97
    new-instance v2, Ljava/io/File;

    .line 153
    .line 154
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 155
    .line 156
    .line 157
    move-result-wide v3

    .line 158
    new-instance v5, Ljava/lang/StringBuilder;

    .line 159
    .line 160
    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    .line 161
    .line 162
    .line 163
    const-string v6, "clipboard_"

    .line 164
    .line 165
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 166
    .line 167
    .line 168
    invoke-virtual {v5, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 169
    .line 170
    .line 171
    const-string v3, ".png"

    .line 172
    .line 173
    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 174
    .line 175
    .line 176
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 177
    .line 178
    .line 179
    move-result-object v3

    .line 180
    invoke-direct {v2, v1, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 181
    .line 182
    .line 183
    new-instance v1, Ljava/io/FileOutputStream;

    .line 184
    .line 185
    invoke-direct {v1, v2}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    :try_end_bb
    .catchall {:try_start_42 .. :try_end_bb} :catchall_20

    .line 186
    .line 187
    .line 188
    :try_start_bb
    sget-object v3, Landroid/graphics/Bitmap$CompressFormat;->PNG:Landroid/graphics/Bitmap$CompressFormat;

    .line 189
    .line 190
    const/16 v4, 0x64

    .line 191
    .line 192
    invoke-virtual {p1, v3, v4, v1}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z
    :try_end_c2
    .catchall {:try_start_bb .. :try_end_c2} :catchall_103

    .line 193
    .line 194
    .line 195
    :try_start_c2
    invoke-virtual {v1}, Ljava/io/FileOutputStream;->close()V

    .line 196
    .line 197
    .line 198
    iget-object p1, p0, Lcom/almekhlafi/goldbook/utils/jsBridge/ClipboardBridge;->context:Landroid/content/Context;

    .line 199
    .line 200
    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 201
    .line 202
    .line 203
    move-result-object v1

    .line 204
    new-instance v3, Ljava/lang/StringBuilder;

    .line 205
    .line 206
    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    .line 207
    .line 208
    .line 209
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 210
    .line 211
    .line 212
    const-string v1, ".fileprovider"

    .line 213
    .line 214
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 215
    .line 216
    .line 217
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 218
    .line 219
    .line 220
    move-result-object v1

    .line 221
    invoke-static {p1, v1, v2}, Landroidx/core/content/FileProvider;->d(Landroid/content/Context;Ljava/lang/String;Ljava/io/File;)Landroid/net/Uri;

    .line 222
    .line 223
    .line 224
    move-result-object p1

    .line 225
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 226
    .line 227
    .line 228
    iget-object v1, p0, Lcom/almekhlafi/goldbook/utils/jsBridge/ClipboardBridge;->context:Landroid/content/Context;

    .line 229
    .line 230
    invoke-virtual {v1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 231
    .line 232
    .line 233
    move-result-object v1

    .line 234
    const-string v2, "Image"

    .line 235
    .line 236
    invoke-static {v1, v2, p1}, Landroid/content/ClipData;->newUri(Landroid/content/ContentResolver;Ljava/lang/CharSequence;Landroid/net/Uri;)Landroid/content/ClipData;

    .line 237
    .line 238
    .line 239
    move-result-object p1

    .line 240
    invoke-virtual {v0, p1}, Landroid/content/ClipboardManager;->setPrimaryClip(Landroid/content/ClipData;)V

    .line 241
    .line 242
    .line 243
    iget-object p1, p0, Lcom/almekhlafi/goldbook/utils/jsBridge/ClipboardBridge;->context:Landroid/content/Context;

    .line 244
    .line 245
    const v0, 0x7f0a003d

    .line 246
    .line 247
    .line 248
    invoke-virtual {p1, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 249
    .line 250
    .line 251
    move-result-object v0

    .line 252
    invoke-static {p1, v0, p2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 253
    .line 254
    .line 255
    move-result-object p1

    .line 256
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V
    :try_end_102
    .catchall {:try_start_c2 .. :try_end_102} :catchall_20

    .line 257
    .line 258
    .line 259
    goto :goto_11a

    .line 260
    :catchall_103
    move-exception p1

    .line 261
    :try_start_104
    throw p1
    :try_end_105
    .catchall {:try_start_104 .. :try_end_105} :catchall_105

    .line 262
    :catchall_105
    move-exception v0

    .line 263
    :try_start_106
    invoke-static {v1, p1}, Lgh0;->t(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 264
    .line 265
    .line 266
    throw v0

    .line 267
    :cond_10a
    iget-object p1, p0, Lcom/almekhlafi/goldbook/utils/jsBridge/ClipboardBridge;->context:Landroid/content/Context;

    .line 268
    .line 269
    const v0, 0x7f0a001d

    .line 270
    .line 271
    .line 272
    invoke-virtual {p1, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 273
    .line 274
    .line 275
    move-result-object v0

    .line 276
    invoke-static {p1, v0, p2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 277
    .line 278
    .line 279
    move-result-object p1

    .line 280
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 281
    .line 282
    .line 283
    :goto_11a
    sget-object p1, Lwe1;->a:Lwe1;
    :try_end_11c
    .catchall {:try_start_106 .. :try_end_11c} :catchall_20

    .line 284
    .line 285
    goto :goto_123

    .line 286
    :goto_11d
    new-instance v0, Lpx0;

    .line 287
    .line 288
    invoke-direct {v0, p1}, Lpx0;-><init>(Ljava/lang/Throwable;)V

    .line 289
    .line 290
    .line 291
    move-object p1, v0

    .line 292
    :goto_123
    invoke-static {p1}, Lqx0;->a(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 293
    .line 294
    .line 295
    move-result-object p1

    .line 296
    if-eqz p1, :cond_139

    .line 297
    .line 298
    iget-object p0, p0, Lcom/almekhlafi/goldbook/utils/jsBridge/ClipboardBridge;->context:Landroid/content/Context;

    .line 299
    .line 300
    const p1, 0x7f0a0030

    .line 301
    .line 302
    .line 303
    invoke-virtual {p0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 304
    .line 305
    .line 306
    move-result-object p1

    .line 307
    invoke-static {p0, p1, p2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 308
    .line 309
    .line 310
    move-result-object p0

    .line 311
    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    .line 312
    .line 313
    .line 314
    :cond_139
    return-void
.end method

.method public final copyText(Ljava/lang/String;)V
    .registers 10
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .line 1
    const/4 v0, 0x0

    .line 2
    if-eqz p1, :cond_81

    .line 3
    .line 4
    invoke-static {p1}, Lq81;->E(Ljava/lang/String;)Z

    .line 5
    .line 6
    .line 7
    move-result v1

    .line 8
    if-eqz v1, :cond_b

    .line 9
    .line 10
    goto/16 :goto_81

    .line 11
    .line 12
    :cond_b
    :try_start_b
    iget-object v1, p0, Lcom/almekhlafi/goldbook/utils/jsBridge/ClipboardBridge;->context:Landroid/content/Context;

    .line 13
    .line 14
    const-string v2, "clipboard"

    .line 15
    .line 16
    invoke-virtual {v1, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object v1

    .line 20
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 21
    .line 22
    .line 23
    check-cast v1, Landroid/content/ClipboardManager;

    .line 24
    .line 25
    const-string v2, "GoldBook"

    .line 26
    .line 27
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 28
    .line 29
    .line 30
    move-result v3

    .line 31
    const/4 v4, 0x1

    .line 32
    sub-int/2addr v3, v4

    .line 33
    move v5, v0

    .line 34
    move v6, v5

    .line 35
    :goto_22
    if-gt v5, v3, :cond_40

    .line 36
    .line 37
    if-nez v6, :cond_28

    .line 38
    .line 39
    move v7, v5

    .line 40
    goto :goto_29

    .line 41
    :cond_28
    move v7, v3

    .line 42
    :goto_29
    invoke-virtual {p1, v7}, Ljava/lang/String;->charAt(I)C

    .line 43
    .line 44
    .line 45
    move-result v7

    .line 46
    invoke-static {v7}, La5;->y(C)Z

    .line 47
    .line 48
    .line 49
    move-result v7

    .line 50
    if-nez v6, :cond_3a

    .line 51
    .line 52
    if-nez v7, :cond_37

    .line 53
    .line 54
    move v6, v4

    .line 55
    goto :goto_22

    .line 56
    :cond_37
    add-int/lit8 v5, v5, 0x1

    .line 57
    .line 58
    goto :goto_22

    .line 59
    :cond_3a
    if-nez v7, :cond_3d

    .line 60
    .line 61
    goto :goto_40

    .line 62
    :cond_3d
    add-int/lit8 v3, v3, -0x1

    .line 63
    .line 64
    goto :goto_22

    .line 65
    :cond_40
    :goto_40
    add-int/2addr v3, v4

    .line 66
    invoke-virtual {p1, v5, v3}, Ljava/lang/String;->subSequence(II)Ljava/lang/CharSequence;

    .line 67
    .line 68
    .line 69
    move-result-object p1

    .line 70
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 71
    .line 72
    .line 73
    move-result-object p1

    .line 74
    invoke-static {v2, p1}, Landroid/content/ClipData;->newPlainText(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Landroid/content/ClipData;

    .line 75
    .line 76
    .line 77
    move-result-object p1

    .line 78
    invoke-virtual {v1, p1}, Landroid/content/ClipboardManager;->setPrimaryClip(Landroid/content/ClipData;)V

    .line 79
    .line 80
    .line 81
    iget-object p1, p0, Lcom/almekhlafi/goldbook/utils/jsBridge/ClipboardBridge;->context:Landroid/content/Context;

    .line 82
    .line 83
    const v1, 0x7f0a00ac

    .line 84
    .line 85
    .line 86
    invoke-virtual {p1, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 87
    .line 88
    .line 89
    move-result-object v1

    .line 90
    invoke-static {p1, v1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 91
    .line 92
    .line 93
    move-result-object p1

    .line 94
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 95
    .line 96
    .line 97
    sget-object p1, Lwe1;->a:Lwe1;
    :try_end_62
    .catchall {:try_start_b .. :try_end_62} :catchall_63

    .line 98
    .line 99
    goto :goto_6a

    .line 100
    :catchall_63
    move-exception p1

    .line 101
    new-instance v1, Lpx0;

    .line 102
    .line 103
    invoke-direct {v1, p1}, Lpx0;-><init>(Ljava/lang/Throwable;)V

    .line 104
    .line 105
    .line 106
    move-object p1, v1

    .line 107
    :goto_6a
    invoke-static {p1}, Lqx0;->a(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 108
    .line 109
    .line 110
    move-result-object p1

    .line 111
    if-eqz p1, :cond_80

    .line 112
    .line 113
    iget-object p0, p0, Lcom/almekhlafi/goldbook/utils/jsBridge/ClipboardBridge;->context:Landroid/content/Context;

    .line 114
    .line 115
    const p1, 0x7f0a002f

    .line 116
    .line 117
    .line 118
    invoke-virtual {p0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 119
    .line 120
    .line 121
    move-result-object p1

    .line 122
    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 123
    .line 124
    .line 125
    move-result-object p0

    .line 126
    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    .line 127
    .line 128
    .line 129
    :cond_80
    return-void

    .line 130
    :cond_81
    :goto_81
    iget-object p0, p0, Lcom/almekhlafi/goldbook/utils/jsBridge/ClipboardBridge;->context:Landroid/content/Context;

    .line 131
    .line 132
    const p1, 0x7f0a008f

    .line 133
    .line 134
    .line 135
    invoke-virtual {p0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 136
    .line 137
    .line 138
    move-result-object p1

    .line 139
    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 140
    .line 141
    .line 142
    move-result-object p0

    .line 143
    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    .line 144
    .line 145
    .line 146
    return-void
.end method
