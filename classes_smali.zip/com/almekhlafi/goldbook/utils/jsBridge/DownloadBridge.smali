.class public final Lcom/almekhlafi/goldbook/utils/jsBridge/DownloadBridge;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# static fields
.field public static final $stable:I = 0x8


# instance fields
.field private final context:Landroid/content/Context;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/almekhlafi/goldbook/utils/jsBridge/DownloadBridge;->context:Landroid/content/Context;

    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final downloadBase64File(Ljava/lang/String;Ljava/lang/String;)V
    .registers 11
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .line 1
    const-string v0, "is_pending"

    .line 2
    .line 3
    const-string v1, ","

    .line 4
    .line 5
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    .line 7
    .line 8
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9
    .line 10
    .line 11
    const/4 v2, 0x0

    .line 12
    :try_start_b
    invoke-static {p1, v1}, Lq81;->z(Ljava/lang/String;Ljava/lang/String;)Z

    .line 13
    .line 14
    .line 15
    move-result v3

    .line 16
    if-nez v3, :cond_25

    .line 17
    .line 18
    iget-object p1, p0, Lcom/almekhlafi/goldbook/utils/jsBridge/DownloadBridge;->context:Landroid/content/Context;

    .line 19
    .line 20
    const p2, 0x7f0a0029

    .line 21
    .line 22
    .line 23
    invoke-virtual {p1, p2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 24
    .line 25
    .line 26
    move-result-object p2

    .line 27
    invoke-static {p1, p2, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 28
    .line 29
    .line 30
    move-result-object p1

    .line 31
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 32
    .line 33
    .line 34
    return-void

    .line 35
    :catchall_22
    move-exception p1

    .line 36
    goto/16 :goto_15a

    .line 37
    .line 38
    :cond_25
    filled-new-array {v1}, [Ljava/lang/String;

    .line 39
    .line 40
    .line 41
    move-result-object v1

    .line 42
    invoke-static {p1, v1}, Lq81;->H(Ljava/lang/String;[Ljava/lang/String;)Ljava/util/List;

    .line 43
    .line 44
    .line 45
    move-result-object p1

    .line 46
    const/4 v1, 0x1

    .line 47
    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object p1

    .line 51
    check-cast p1, Ljava/lang/String;

    .line 52
    .line 53
    invoke-static {p1, v2}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    .line 54
    .line 55
    .line 56
    move-result-object p1

    .line 57
    const-string v3, "image/"

    .line 58
    .line 59
    invoke-virtual {p2, v3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 60
    .line 61
    .line 62
    move-result v3

    .line 63
    const-string v4, "video/"

    .line 64
    .line 65
    invoke-virtual {p2, v4}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 66
    .line 67
    .line 68
    move-result v4
    :try_end_44
    .catchall {:try_start_b .. :try_end_44} :catchall_22

    .line 69
    const-string v5, "bin"

    .line 70
    .line 71
    if-eqz v3, :cond_7c

    .line 72
    .line 73
    :try_start_48
    array-length v3, p1

    .line 74
    invoke-static {p1, v2, v3}, Landroid/graphics/BitmapFactory;->decodeByteArray([BII)Landroid/graphics/Bitmap;

    .line 75
    .line 76
    .line 77
    move-result-object v3

    .line 78
    if-eqz v3, :cond_69

    .line 79
    .line 80
    new-instance p1, Ljava/io/ByteArrayOutputStream;

    .line 81
    .line 82
    invoke-direct {p1}, Ljava/io/ByteArrayOutputStream;-><init>()V

    .line 83
    .line 84
    .line 85
    sget-object p2, Landroid/graphics/Bitmap$CompressFormat;->PNG:Landroid/graphics/Bitmap$CompressFormat;

    .line 86
    .line 87
    const/16 v4, 0x64

    .line 88
    .line 89
    invoke-virtual {v3, p2, v4, p1}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z

    .line 90
    .line 91
    .line 92
    new-instance p2, Lsd1;

    .line 93
    .line 94
    invoke-virtual {p1}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    .line 95
    .line 96
    .line 97
    move-result-object p1

    .line 98
    const-string v3, "image/png"

    .line 99
    .line 100
    const-string v4, "png"

    .line 101
    .line 102
    invoke-direct {p2, p1, v3, v4}, Lsd1;-><init>(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)V

    .line 103
    .line 104
    .line 105
    goto :goto_a3

    .line 106
    :cond_69
    invoke-static {}, Landroid/webkit/MimeTypeMap;->getSingleton()Landroid/webkit/MimeTypeMap;

    .line 107
    .line 108
    .line 109
    move-result-object v3

    .line 110
    invoke-virtual {v3, p2}, Landroid/webkit/MimeTypeMap;->getExtensionFromMimeType(Ljava/lang/String;)Ljava/lang/String;

    .line 111
    .line 112
    .line 113
    move-result-object v3

    .line 114
    if-nez v3, :cond_74

    .line 115
    .line 116
    goto :goto_75

    .line 117
    :cond_74
    move-object v5, v3

    .line 118
    :goto_75
    new-instance v3, Lsd1;

    .line 119
    .line 120
    invoke-direct {v3, p1, p2, v5}, Lsd1;-><init>(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)V

    .line 121
    .line 122
    .line 123
    :goto_7a
    move-object p2, v3

    .line 124
    goto :goto_a3

    .line 125
    :cond_7c
    if-eqz v4, :cond_91

    .line 126
    .line 127
    invoke-static {}, Landroid/webkit/MimeTypeMap;->getSingleton()Landroid/webkit/MimeTypeMap;

    .line 128
    .line 129
    .line 130
    move-result-object v3

    .line 131
    invoke-virtual {v3, p2}, Landroid/webkit/MimeTypeMap;->getExtensionFromMimeType(Ljava/lang/String;)Ljava/lang/String;

    .line 132
    .line 133
    .line 134
    move-result-object v3

    .line 135
    if-nez v3, :cond_8a

    .line 136
    .line 137
    const-string v3, "mp4"

    .line 138
    .line 139
    :cond_8a
    new-instance v4, Lsd1;

    .line 140
    .line 141
    invoke-direct {v4, p1, p2, v3}, Lsd1;-><init>(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)V

    .line 142
    .line 143
    .line 144
    move-object p2, v4

    .line 145
    goto :goto_a3

    .line 146
    :cond_91
    invoke-static {}, Landroid/webkit/MimeTypeMap;->getSingleton()Landroid/webkit/MimeTypeMap;

    .line 147
    .line 148
    .line 149
    move-result-object v3

    .line 150
    invoke-virtual {v3, p2}, Landroid/webkit/MimeTypeMap;->getExtensionFromMimeType(Ljava/lang/String;)Ljava/lang/String;

    .line 151
    .line 152
    .line 153
    move-result-object v3

    .line 154
    if-nez v3, :cond_9c

    .line 155
    .line 156
    goto :goto_9d

    .line 157
    :cond_9c
    move-object v5, v3

    .line 158
    :goto_9d
    new-instance v3, Lsd1;

    .line 159
    .line 160
    invoke-direct {v3, p1, p2, v5}, Lsd1;-><init>(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)V

    .line 161
    .line 162
    .line 163
    goto :goto_7a

    .line 164
    :goto_a3
    iget-object p1, p2, Lsd1;->e:Ljava/lang/Object;

    .line 165
    .line 166
    check-cast p1, [B

    .line 167
    .line 168
    iget-object v3, p2, Lsd1;->f:Ljava/lang/Object;

    .line 169
    .line 170
    check-cast v3, Ljava/lang/String;

    .line 171
    .line 172
    iget-object p2, p2, Lsd1;->g:Ljava/lang/String;

    .line 173
    .line 174
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 175
    .line 176
    .line 177
    move-result-wide v4

    .line 178
    new-instance v6, Ljava/lang/StringBuilder;

    .line 179
    .line 180
    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    .line 181
    .line 182
    .line 183
    invoke-virtual {v6, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 184
    .line 185
    .line 186
    const-string v4, "."

    .line 187
    .line 188
    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 189
    .line 190
    .line 191
    invoke-virtual {v6, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 192
    .line 193
    .line 194
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 195
    .line 196
    .line 197
    move-result-object p2

    .line 198
    sget v4, Landroid/os/Build$VERSION;->SDK_INT:I
    :try_end_c7
    .catchall {:try_start_48 .. :try_end_c7} :catchall_22

    .line 199
    .line 200
    const/16 v5, 0x1d

    .line 201
    .line 202
    sget-object v6, Lwe1;->a:Lwe1;

    .line 203
    .line 204
    const v7, 0x7f0a009c

    .line 205
    .line 206
    .line 207
    if-lt v4, v5, :cond_12f

    .line 208
    .line 209
    :try_start_d0
    new-instance v4, Landroid/content/ContentValues;

    .line 210
    .line 211
    invoke-direct {v4}, Landroid/content/ContentValues;-><init>()V

    .line 212
    .line 213
    .line 214
    const-string v5, "_display_name"

    .line 215
    .line 216
    invoke-virtual {v4, v5, p2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 217
    .line 218
    .line 219
    const-string p2, "mime_type"

    .line 220
    .line 221
    invoke-virtual {v4, p2, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 222
    .line 223
    .line 224
    const-string p2, "relative_path"

    .line 225
    .line 226
    sget-object v3, Landroid/os/Environment;->DIRECTORY_DOWNLOADS:Ljava/lang/String;

    .line 227
    .line 228
    invoke-virtual {v4, p2, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 229
    .line 230
    .line 231
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 232
    .line 233
    .line 234
    move-result-object p2

    .line 235
    invoke-virtual {v4, v0, p2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 236
    .line 237
    .line 238
    iget-object p2, p0, Lcom/almekhlafi/goldbook/utils/jsBridge/DownloadBridge;->context:Landroid/content/Context;

    .line 239
    .line 240
    invoke-virtual {p2}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 241
    .line 242
    .line 243
    move-result-object p2

    .line 244
    invoke-static {}, Ls3;->d()Landroid/net/Uri;

    .line 245
    .line 246
    .line 247
    move-result-object v1

    .line 248
    invoke-virtual {p2, v1, v4}, Landroid/content/ContentResolver;->insert(Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;

    .line 249
    .line 250
    .line 251
    move-result-object v1

    .line 252
    const/4 v3, 0x0

    .line 253
    if-eqz v1, :cond_12d

    .line 254
    .line 255
    invoke-virtual {p2, v1}, Landroid/content/ContentResolver;->openOutputStream(Landroid/net/Uri;)Ljava/io/OutputStream;

    .line 256
    .line 257
    .line 258
    move-result-object v5
    :try_end_102
    .catchall {:try_start_d0 .. :try_end_102} :catchall_22

    .line 259
    if-eqz v5, :cond_112

    .line 260
    .line 261
    :try_start_104
    invoke-virtual {v5, p1}, Ljava/io/OutputStream;->write([B)V
    :try_end_107
    .catchall {:try_start_104 .. :try_end_107} :catchall_10b

    .line 262
    .line 263
    .line 264
    :try_start_107
    invoke-interface {v5}, Ljava/io/Closeable;->close()V
    :try_end_10a
    .catchall {:try_start_107 .. :try_end_10a} :catchall_22

    .line 265
    .line 266
    .line 267
    goto :goto_112

    .line 268
    :catchall_10b
    move-exception p1

    .line 269
    :try_start_10c
    throw p1
    :try_end_10d
    .catchall {:try_start_10c .. :try_end_10d} :catchall_10d

    .line 270
    :catchall_10d
    move-exception p2

    .line 271
    :try_start_10e
    invoke-static {v5, p1}, Lgh0;->t(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 272
    .line 273
    .line 274
    throw p2

    .line 275
    :cond_112
    :goto_112
    invoke-virtual {v4}, Landroid/content/ContentValues;->clear()V

    .line 276
    .line 277
    .line 278
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 279
    .line 280
    .line 281
    move-result-object p1

    .line 282
    invoke-virtual {v4, v0, p1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 283
    .line 284
    .line 285
    invoke-virtual {p2, v1, v4, v3, v3}, Landroid/content/ContentResolver;->update(Landroid/net/Uri;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I

    .line 286
    .line 287
    .line 288
    iget-object p1, p0, Lcom/almekhlafi/goldbook/utils/jsBridge/DownloadBridge;->context:Landroid/content/Context;

    .line 289
    .line 290
    invoke-virtual {p1, v7}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 291
    .line 292
    .line 293
    move-result-object p2

    .line 294
    invoke-static {p1, p2, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 295
    .line 296
    .line 297
    move-result-object p1

    .line 298
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 299
    .line 300
    .line 301
    goto :goto_15f

    .line 302
    :cond_12d
    move-object v6, v3

    .line 303
    goto :goto_15f

    .line 304
    :cond_12f
    sget-object v0, Landroid/os/Environment;->DIRECTORY_DOWNLOADS:Ljava/lang/String;

    .line 305
    .line 306
    invoke-static {v0}, Landroid/os/Environment;->getExternalStoragePublicDirectory(Ljava/lang/String;)Ljava/io/File;

    .line 307
    .line 308
    .line 309
    move-result-object v0

    .line 310
    new-instance v1, Ljava/io/File;

    .line 311
    .line 312
    invoke-direct {v1, v0, p2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 313
    .line 314
    .line 315
    new-instance p2, Ljava/io/FileOutputStream;

    .line 316
    .line 317
    invoke-direct {p2, v1}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    :try_end_13f
    .catchall {:try_start_10e .. :try_end_13f} :catchall_22

    .line 318
    .line 319
    .line 320
    :try_start_13f
    invoke-virtual {p2, p1}, Ljava/io/FileOutputStream;->write([B)V
    :try_end_142
    .catchall {:try_start_13f .. :try_end_142} :catchall_153

    .line 321
    .line 322
    .line 323
    :try_start_142
    invoke-virtual {p2}, Ljava/io/FileOutputStream;->close()V

    .line 324
    .line 325
    .line 326
    iget-object p1, p0, Lcom/almekhlafi/goldbook/utils/jsBridge/DownloadBridge;->context:Landroid/content/Context;

    .line 327
    .line 328
    invoke-virtual {p1, v7}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 329
    .line 330
    .line 331
    move-result-object p2

    .line 332
    invoke-static {p1, p2, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 333
    .line 334
    .line 335
    move-result-object p1

    .line 336
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V
    :try_end_152
    .catchall {:try_start_142 .. :try_end_152} :catchall_22

    .line 337
    .line 338
    .line 339
    goto :goto_15f

    .line 340
    :catchall_153
    move-exception p1

    .line 341
    :try_start_154
    throw p1
    :try_end_155
    .catchall {:try_start_154 .. :try_end_155} :catchall_155

    .line 342
    :catchall_155
    move-exception v0

    .line 343
    :try_start_156
    invoke-static {p2, p1}, Lgh0;->t(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 344
    .line 345
    .line 346
    throw v0
    :try_end_15a
    .catchall {:try_start_156 .. :try_end_15a} :catchall_22

    .line 347
    :goto_15a
    new-instance v6, Lpx0;

    .line 348
    .line 349
    invoke-direct {v6, p1}, Lpx0;-><init>(Ljava/lang/Throwable;)V

    .line 350
    .line 351
    .line 352
    :goto_15f
    invoke-static {v6}, Lqx0;->a(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 353
    .line 354
    .line 355
    move-result-object p1

    .line 356
    if-eqz p1, :cond_175

    .line 357
    .line 358
    iget-object p0, p0, Lcom/almekhlafi/goldbook/utils/jsBridge/DownloadBridge;->context:Landroid/content/Context;

    .line 359
    .line 360
    const p1, 0x7f0a0031

    .line 361
    .line 362
    .line 363
    invoke-virtual {p0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 364
    .line 365
    .line 366
    move-result-object p1

    .line 367
    invoke-static {p0, p1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 368
    .line 369
    .line 370
    move-result-object p0

    .line 371
    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    .line 372
    .line 373
    .line 374
    :cond_175
    return-void
.end method
