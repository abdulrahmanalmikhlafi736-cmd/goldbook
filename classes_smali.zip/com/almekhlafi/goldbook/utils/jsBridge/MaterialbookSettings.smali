.class public final Lcom/almekhlafi/goldbook/utils/jsBridge/MaterialbookSettings;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# static fields
.field public static final $stable:I


# instance fields
.field private final toggleSettings:Lxz;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxz;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lxz;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lxz;",
            ")V"
        }
    .end annotation

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/almekhlafi/goldbook/utils/jsBridge/MaterialbookSettings;->toggleSettings:Lxz;

    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final onSettingsToggle()V
    .registers 1
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .line 1
    iget-object p0, p0, Lcom/almekhlafi/goldbook/utils/jsBridge/MaterialbookSettings;->toggleSettings:Lxz;

    .line 2
    .line 3
    invoke-interface {p0}, Lxz;->a()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    return-void
.end method
