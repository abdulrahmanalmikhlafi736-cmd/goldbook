.class public final Lcom/almekhlafi/goldbook/utils/jsBridge/NavigateFB;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# static fields
.field public static final $stable:I


# instance fields
.field private final onNavigate:Lxz;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lxz;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lxz;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lxz;",
            ")V"
        }
    .end annotation

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lcom/almekhlafi/goldbook/utils/jsBridge/NavigateFB;->onNavigate:Lxz;

    .line 8
    .line 9
    return-void
.end method

.method public static synthetic a(Lcom/almekhlafi/goldbook/utils/jsBridge/NavigateFB;)V
    .registers 1

    .line 1
    invoke-static {p0}, Lcom/almekhlafi/goldbook/utils/jsBridge/NavigateFB;->onNavigateFB$lambda$0(Lcom/almekhlafi/goldbook/utils/jsBridge/NavigateFB;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method private static final onNavigateFB$lambda$0(Lcom/almekhlafi/goldbook/utils/jsBridge/NavigateFB;)V
    .registers 1

    .line 1
    iget-object p0, p0, Lcom/almekhlafi/goldbook/utils/jsBridge/NavigateFB;->onNavigate:Lxz;

    .line 2
    .line 3
    invoke-interface {p0}, Lxz;->a()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onNavigateFB()V
    .registers 4
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .line 1
    new-instance v0, Landroid/os/Handler;

    .line 2
    .line 3
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 8
    .line 9
    .line 10
    new-instance v1, Lo4;

    .line 11
    .line 12
    const/4 v2, 0x6

    .line 13
    invoke-direct {v1, v2, p0}, Lo4;-><init>(ILjava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 17
    .line 18
    .line 19
    return-void
.end method
