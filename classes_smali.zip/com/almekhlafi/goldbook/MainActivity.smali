.class public final Lcom/almekhlafi/goldbook/MainActivity;
.super Lki;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# static fields
.field public static final synthetic z:I


# instance fields
.field public y:Ln41;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Lki;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final onCreate(Landroid/os/Bundle;)V
    .registers 12

    .line 1
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const/4 v1, 0x0

    .line 6
    invoke-static {v0, v1}, Ldd0;->u(Landroid/view/Window;Z)V

    .line 7
    .line 8
    .line 9
    new-instance v0, Lf11;

    .line 10
    .line 11
    const/4 v2, 0x4

    .line 12
    invoke-direct {v0, v2}, Lf11;-><init>(I)V

    .line 13
    .line 14
    .line 15
    new-instance v5, Lea1;

    .line 16
    .line 17
    invoke-direct {v5, v1, v1, v0}, Lea1;-><init>(IILi00;)V

    .line 18
    .line 19
    .line 20
    sget v0, Lps;->a:I

    .line 21
    .line 22
    sget v3, Lps;->b:I

    .line 23
    .line 24
    new-instance v4, Lf11;

    .line 25
    .line 26
    invoke-direct {v4, v2}, Lf11;-><init>(I)V

    .line 27
    .line 28
    .line 29
    new-instance v6, Lea1;

    .line 30
    .line 31
    invoke-direct {v6, v0, v3, v4}, Lea1;-><init>(IILi00;)V

    .line 32
    .line 33
    .line 34
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 39
    .line 40
    .line 41
    move-result-object v8

    .line 42
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 43
    .line 44
    .line 45
    sget-object v0, Lps;->c:Lws;

    .line 46
    .line 47
    if-nez v0, :cond_6b

    .line 48
    .line 49
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 50
    .line 51
    const/16 v2, 0x23

    .line 52
    .line 53
    if-lt v0, v2, :cond_3c

    .line 54
    .line 55
    new-instance v0, Lvs;

    .line 56
    .line 57
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 58
    .line 59
    .line 60
    goto :goto_69

    .line 61
    :cond_3c
    const/16 v2, 0x1e

    .line 62
    .line 63
    if-lt v0, v2, :cond_46

    .line 64
    .line 65
    new-instance v0, Lus;

    .line 66
    .line 67
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 68
    .line 69
    .line 70
    goto :goto_69

    .line 71
    :cond_46
    const/16 v2, 0x1d

    .line 72
    .line 73
    if-lt v0, v2, :cond_50

    .line 74
    .line 75
    new-instance v0, Lts;

    .line 76
    .line 77
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 78
    .line 79
    .line 80
    goto :goto_69

    .line 81
    :cond_50
    const/16 v2, 0x1c

    .line 82
    .line 83
    if-lt v0, v2, :cond_5a

    .line 84
    .line 85
    new-instance v0, Lss;

    .line 86
    .line 87
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 88
    .line 89
    .line 90
    goto :goto_69

    .line 91
    :cond_5a
    const/16 v2, 0x1a

    .line 92
    .line 93
    if-lt v0, v2, :cond_64

    .line 94
    .line 95
    new-instance v0, Lrs;

    .line 96
    .line 97
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 98
    .line 99
    .line 100
    goto :goto_69

    .line 101
    :cond_64
    new-instance v0, Lqs;

    .line 102
    .line 103
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 104
    .line 105
    .line 106
    :goto_69
    sput-object v0, Lps;->c:Lws;

    .line 107
    .line 108
    :cond_6b
    move-object v4, v0

    .line 109
    new-instance v3, Lib;

    .line 110
    .line 111
    const/4 v9, 0x1

    .line 112
    move-object v7, p0

    .line 113
    invoke-direct/range {v3 .. v9}, Lib;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 114
    .line 115
    .line 116
    check-cast v8, Landroid/view/ViewGroup;

    .line 117
    .line 118
    move p0, v1

    .line 119
    :goto_76
    invoke-virtual {v8}, Landroid/view/ViewGroup;->getChildCount()I

    .line 120
    .line 121
    .line 122
    move-result v0

    .line 123
    const/4 v2, 0x1

    .line 124
    if-ge p0, v0, :cond_96

    .line 125
    .line 126
    add-int/lit8 v0, p0, 0x1

    .line 127
    .line 128
    invoke-virtual {v8, p0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 129
    .line 130
    .line 131
    move-result-object p0

    .line 132
    if-eqz p0, :cond_90

    .line 133
    .line 134
    invoke-virtual {p0}, Landroid/view/View;->getTag()Ljava/lang/Object;

    .line 135
    .line 136
    .line 137
    move-result-object p0

    .line 138
    instance-of p0, p0, Lws;

    .line 139
    .line 140
    if-eqz p0, :cond_8e

    .line 141
    .line 142
    goto :goto_ad

    .line 143
    :cond_8e
    move p0, v0

    .line 144
    goto :goto_76

    .line 145
    :cond_90
    new-instance p0, Ljava/lang/IndexOutOfBoundsException;

    .line 146
    .line 147
    invoke-direct {p0}, Ljava/lang/IndexOutOfBoundsException;-><init>()V

    .line 148
    .line 149
    .line 150
    throw p0

    .line 151
    :cond_96
    invoke-virtual {v8}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 152
    .line 153
    .line 154
    move-result-object p0

    .line 155
    new-instance v0, Los;

    .line 156
    .line 157
    invoke-direct {v0, v3, p0}, Los;-><init>(Lib;Landroid/content/Context;)V

    .line 158
    .line 159
    .line 160
    invoke-virtual {v0, v4}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 161
    .line 162
    .line 163
    const/16 p0, 0x8

    .line 164
    .line 165
    invoke-virtual {v0, p0}, Landroid/view/View;->setVisibility(I)V

    .line 166
    .line 167
    .line 168
    invoke-virtual {v0, v2}, Landroid/view/View;->setWillNotDraw(Z)V

    .line 169
    .line 170
    .line 171
    invoke-virtual {v8, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 172
    .line 173
    .line 174
    :goto_ad
    invoke-virtual {v3}, Lib;->run()V

    .line 175
    .line 176
    .line 177
    invoke-virtual {v7}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 178
    .line 179
    .line 180
    move-result-object p0

    .line 181
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 182
    .line 183
    .line 184
    invoke-virtual {v4, p0}, Lws;->a(Landroid/view/Window;)V

    .line 185
    .line 186
    .line 187
    invoke-super {v7, p1}, Lki;->onCreate(Landroid/os/Bundle;)V

    .line 188
    .line 189
    .line 190
    invoke-static {v7}, Lmod/Mod;->warm(Landroid/content/Context;)V

    .line 191
    .line 192
    .line 193
    new-instance p0, Ln41;

    .line 194
    .line 195
    invoke-direct {p0, v7}, Ln41;-><init>(Landroid/content/ContextWrapper;)V

    .line 196
    .line 197
    .line 198
    iput-object p0, v7, Lcom/almekhlafi/goldbook/MainActivity;->y:Ln41;

    .line 199
    .line 200
    invoke-static {v7}, Lmc0;->q(Landroid/content/Context;)Z

    .line 201
    .line 202
    .line 203
    move-result p0

    .line 204
    if-eqz p0, :cond_107

    .line 205
    .line 206
    invoke-virtual {v7}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 207
    .line 208
    .line 209
    move-result-object p0

    .line 210
    if-nez p0, :cond_d5

    .line 211
    .line 212
    :goto_d3
    move p0, v1

    .line 213
    goto :goto_f7

    .line 214
    :cond_d5
    invoke-virtual {p0}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 215
    .line 216
    .line 217
    move-result-object p1

    .line 218
    if-nez p1, :cond_dc

    .line 219
    .line 220
    goto :goto_d3

    .line 221
    :cond_dc
    const-string v0, "android.provider.Telephony.SECRET_CODE"

    .line 222
    .line 223
    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 224
    .line 225
    .line 226
    move-result p1

    .line 227
    if-eqz p1, :cond_e6

    .line 228
    .line 229
    move p0, v2

    .line 230
    goto :goto_f7

    .line 231
    :cond_e6
    invoke-virtual {p0}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    .line 232
    .line 233
    .line 234
    move-result-object p0

    .line 235
    if-nez p0, :cond_ed

    .line 236
    .line 237
    goto :goto_d3

    .line 238
    :cond_ed
    invoke-virtual {p0}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    .line 239
    .line 240
    .line 241
    move-result-object p0

    .line 242
    const-string p1, "goldbook"

    .line 243
    .line 244
    invoke-static {p0, p1}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 245
    .line 246
    .line 247
    move-result p0

    .line 248
    :goto_f7
    if-eqz p0, :cond_107

    .line 249
    .line 250
    const p0, 0x7f0a00a4

    .line 251
    .line 252
    .line 253
    :try_start_fc
    invoke-virtual {v7, p0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 254
    .line 255
    .line 256
    move-result-object p0

    .line 257
    invoke-static {v7, p0, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 258
    .line 259
    .line 260
    move-result-object p0

    .line 261
    invoke-virtual {p0}, Landroid/widget/Toast;->show()V
    :try_end_107
    .catchall {:try_start_fc .. :try_end_107} :catchall_107

    .line 262
    .line 263
    .line 264
    :catchall_107
    :cond_107
    new-instance p0, Lhc;

    .line 265
    .line 266
    const/4 p1, 0x5

    .line 267
    invoke-direct {p0, p1, v7}, Lhc;-><init>(ILjava/lang/Object;)V

    .line 268
    .line 269
    .line 270
    new-instance p1, Lpi;

    .line 271
    .line 272
    const v0, -0x64c8c65a

    .line 273
    .line 274
    .line 275
    invoke-direct {p1, v0, v2, p0}, Lpi;-><init>(IZLu00;)V

    .line 276
    .line 277
    .line 278
    sget-object p0, Lli;->a:Landroid/view/ViewGroup$LayoutParams;

    .line 279
    .line 280
    invoke-virtual {v7}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 281
    .line 282
    .line 283
    move-result-object p0

    .line 284
    invoke-virtual {p0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 285
    .line 286
    .line 287
    move-result-object p0

    .line 288
    const v0, 0x1020002

    .line 289
    .line 290
    .line 291
    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 292
    .line 293
    .line 294
    move-result-object p0

    .line 295
    check-cast p0, Landroid/view/ViewGroup;

    .line 296
    .line 297
    invoke-virtual {p0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 298
    .line 299
    .line 300
    move-result-object p0

    .line 301
    instance-of v0, p0, Ljj;

    .line 302
    .line 303
    const/4 v1, 0x0

    .line 304
    if-eqz v0, :cond_134

    .line 305
    .line 306
    check-cast p0, Ljj;

    .line 307
    .line 308
    goto :goto_135

    .line 309
    :cond_134
    move-object p0, v1

    .line 310
    :goto_135
    if-eqz p0, :cond_13e

    .line 311
    .line 312
    invoke-virtual {p0, v1}, Lo;->setParentCompositionContext(Lsj;)V

    .line 313
    .line 314
    .line 315
    invoke-virtual {p0, p1}, Ljj;->setContent(Lm00;)V

    .line 316
    .line 317
    .line 318
    goto :goto_17a

    .line 319
    :cond_13e
    new-instance p0, Ljj;

    .line 320
    .line 321
    invoke-direct {p0, v7}, Ljj;-><init>(Lcom/almekhlafi/goldbook/MainActivity;)V

    .line 322
    .line 323
    .line 324
    invoke-virtual {p0, v1}, Lo;->setParentCompositionContext(Lsj;)V

    .line 325
    .line 326
    .line 327
    invoke-virtual {p0, p1}, Ljj;->setContent(Lm00;)V

    .line 328
    .line 329
    .line 330
    invoke-virtual {v7}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 331
    .line 332
    .line 333
    move-result-object p1

    .line 334
    invoke-virtual {p1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 335
    .line 336
    .line 337
    move-result-object p1

    .line 338
    invoke-static {p1}, Lua0;->o(Landroid/view/View;)Lsd0;

    .line 339
    .line 340
    .line 341
    move-result-object v0

    .line 342
    if-nez v0, :cond_15d

    .line 343
    .line 344
    const v0, 0x7f050075

    .line 345
    .line 346
    .line 347
    invoke-virtual {p1, v0, v7}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 348
    .line 349
    .line 350
    :cond_15d
    invoke-static {p1}, Ljb0;->j(Landroid/view/View;)Lkh1;

    .line 351
    .line 352
    .line 353
    move-result-object v0

    .line 354
    if-nez v0, :cond_169

    .line 355
    .line 356
    const v0, 0x7f050079

    .line 357
    .line 358
    .line 359
    invoke-virtual {p1, v0, v7}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 360
    .line 361
    .line 362
    :cond_169
    invoke-static {p1}, Lwa0;->j(Landroid/view/View;)Lxz0;

    .line 363
    .line 364
    .line 365
    move-result-object v0

    .line 366
    if-nez v0, :cond_175

    .line 367
    .line 368
    const v0, 0x7f050078

    .line 369
    .line 370
    .line 371
    invoke-virtual {p1, v0, v7}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 372
    .line 373
    .line 374
    :cond_175
    sget-object p1, Lli;->a:Landroid/view/ViewGroup$LayoutParams;

    .line 375
    .line 376
    invoke-virtual {v7, p0, p1}, Lki;->setContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 377
    .line 378
    .line 379
    :goto_17a
    return-void
.end method

.method public final onPictureInPictureModeChanged(ZLandroid/content/res/Configuration;)V
    .registers 3

    .line 1
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-super {p0, p1, p2}, Lki;->onPictureInPictureModeChanged(ZLandroid/content/res/Configuration;)V

    .line 5
    .line 6
    .line 7
    invoke-static {p1}, Lmod/Mod;->setInPip(Z)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public final onUserLeaveHint()V
    .registers 1

    .line 1
    invoke-super {p0}, Lki;->onUserLeaveHint()V

    .line 2
    .line 3
    .line 4
    invoke-static {p0}, Lmod/Mod;->onUserLeaveHint(Landroid/app/Activity;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method
