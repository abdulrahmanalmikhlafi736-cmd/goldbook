.class public final Le8;
.super Lh90;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lm00;


# instance fields
.field public final synthetic f:Led1;

.field public final synthetic g:Li00;

.field public final synthetic h:Lmi0;

.field public final synthetic i:Lju;

.field public final synthetic j:Lwu;

.field public final synthetic k:Lm00;

.field public final synthetic l:Lpi;

.field public final synthetic m:I


# direct methods
.method public constructor <init>(Led1;Li00;Lmi0;Lju;Lwu;Lm00;Lpi;I)V
    .registers 9

    .line 1
    iput-object p1, p0, Le8;->f:Led1;

    .line 2
    .line 3
    iput-object p2, p0, Le8;->g:Li00;

    .line 4
    .line 5
    iput-object p3, p0, Le8;->h:Lmi0;

    .line 6
    .line 7
    iput-object p4, p0, Le8;->i:Lju;

    .line 8
    .line 9
    iput-object p5, p0, Le8;->j:Lwu;

    .line 10
    .line 11
    iput-object p6, p0, Le8;->k:Lm00;

    .line 12
    .line 13
    iput-object p7, p0, Le8;->l:Lpi;

    .line 14
    .line 15
    iput p8, p0, Le8;->m:I

    .line 16
    .line 17
    const/4 p1, 0x2

    .line 18
    invoke-direct {p0, p1}, Lh90;-><init>(I)V

    .line 19
    .line 20
    .line 21
    return-void
.end method


# virtual methods
.method public final f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 12

    .line 1
    move-object v7, p1

    .line 2
    check-cast v7, Ld10;

    .line 3
    .line 4
    check-cast p2, Ljava/lang/Number;

    .line 5
    .line 6
    invoke-virtual {p2}, Ljava/lang/Number;->intValue()I

    .line 7
    .line 8
    .line 9
    iget p1, p0, Le8;->m:I

    .line 10
    .line 11
    or-int/lit8 p1, p1, 0x1

    .line 12
    .line 13
    invoke-static {p1}, Lwc0;->s(I)I

    .line 14
    .line 15
    .line 16
    move-result v8

    .line 17
    iget-object v0, p0, Le8;->f:Led1;

    .line 18
    .line 19
    iget-object v1, p0, Le8;->g:Li00;

    .line 20
    .line 21
    iget-object v2, p0, Le8;->h:Lmi0;

    .line 22
    .line 23
    iget-object v3, p0, Le8;->i:Lju;

    .line 24
    .line 25
    iget-object v4, p0, Le8;->j:Lwu;

    .line 26
    .line 27
    iget-object v5, p0, Le8;->k:Lm00;

    .line 28
    .line 29
    iget-object v6, p0, Le8;->l:Lpi;

    .line 30
    .line 31
    invoke-static/range {v0 .. v8}, Lgh0;->a(Led1;Li00;Lmi0;Lju;Lwu;Lm00;Lpi;Ld10;I)V

    .line 32
    .line 33
    .line 34
    sget-object p0, Lwe1;->a:Lwe1;

    .line 35
    .line 36
    return-object p0
.end method
