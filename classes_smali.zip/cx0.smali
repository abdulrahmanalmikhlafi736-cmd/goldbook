.class public abstract Lcx0;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# direct methods
.method public static a(Landroid/view/RenderNode;)V
    .registers 1

    .line 1
    invoke-virtual {p0}, Landroid/view/RenderNode;->destroyDisplayListData()V

    .line 2
    .line 3
    .line 4
    return-void
.end method
