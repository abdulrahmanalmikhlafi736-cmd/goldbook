.class public abstract Lcl1;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# static fields
.field public static final a:Lhk0;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    sget-object v0, Ln01;->a:[J

    .line 2
    .line 3
    new-instance v0, Lhk0;

    .line 4
    .line 5
    invoke-direct {v0}, Lhk0;-><init>()V

    .line 6
    .line 7
    .line 8
    sput-object v0, Lcl1;->a:Lhk0;

    .line 9
    .line 10
    return-void
.end method

.method public static final a(Landroid/content/Context;)Lb81;
    .registers 10

    .line 1
    sget-object v1, Lcl1;->a:Lhk0;

    .line 2
    .line 3
    monitor-enter v1

    .line 4
    :try_start_3
    invoke-virtual {v1, p0}, Lhk0;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    if-nez v0, :cond_6a

    .line 9
    .line 10
    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 11
    .line 12
    .line 13
    move-result-object v3

    .line 14
    const-string v0, "animator_duration_scale"

    .line 15
    .line 16
    invoke-static {v0}, Landroid/provider/Settings$Global;->getUriFor(Ljava/lang/String;)Landroid/net/Uri;

    .line 17
    .line 18
    .line 19
    move-result-object v4

    .line 20
    const/4 v0, -0x1

    .line 21
    const/4 v2, 0x6

    .line 22
    const/4 v5, 0x0

    .line 23
    invoke-static {v0, v2, v5}, Lwl1;->b(IILgd;)Lid;

    .line 24
    .line 25
    .line 26
    move-result-object v6

    .line 27
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    invoke-static {v0}, Lvd1;->j(Landroid/os/Looper;)Landroid/os/Handler;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    new-instance v5, Lbl1;

    .line 36
    .line 37
    invoke-direct {v5, v6, v0}, Lbl1;-><init>(Lid;Landroid/os/Handler;)V

    .line 38
    .line 39
    .line 40
    new-instance v2, Lal1;

    .line 41
    .line 42
    const/4 v8, 0x0

    .line 43
    move-object v7, p0

    .line 44
    invoke-direct/range {v2 .. v8}, Lal1;-><init>(Landroid/content/ContentResolver;Landroid/net/Uri;Lbl1;Lid;Landroid/content/Context;Lml;)V

    .line 45
    .line 46
    .line 47
    new-instance p0, Lcz0;

    .line 48
    .line 49
    const/4 v0, 0x0

    .line 50
    invoke-direct {p0, v0, v2}, Lcz0;-><init>(ILjava/lang/Object;)V

    .line 51
    .line 52
    .line 53
    new-instance v0, Lll;

    .line 54
    .line 55
    invoke-static {}, Lua0;->e()Ll91;

    .line 56
    .line 57
    .line 58
    move-result-object v2

    .line 59
    sget-object v3, Lkq;->a:Luo;

    .line 60
    .line 61
    sget-object v3, Lkg0;->a:Lw20;

    .line 62
    .line 63
    invoke-static {v2, v3}, Lvn;->O(Lql;Lsl;)Lsl;

    .line 64
    .line 65
    .line 66
    move-result-object v2

    .line 67
    invoke-direct {v0, v2}, Lll;-><init>(Lsl;)V

    .line 68
    .line 69
    .line 70
    new-instance v2, Lx71;

    .line 71
    .line 72
    const-wide v3, 0x7fffffffffffffffL

    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    invoke-direct {v2, v3, v4}, Lx71;-><init>(J)V

    .line 78
    .line 79
    .line 80
    invoke-virtual {v7}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 81
    .line 82
    .line 83
    move-result-object v3

    .line 84
    const-string v4, "animator_duration_scale"

    .line 85
    .line 86
    const/high16 v5, 0x3f800000  # 1.0f

    .line 87
    .line 88
    invoke-static {v3, v4, v5}, Landroid/provider/Settings$Global;->getFloat(Landroid/content/ContentResolver;Ljava/lang/String;F)F

    .line 89
    .line 90
    .line 91
    move-result v3

    .line 92
    invoke-static {v3}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 93
    .line 94
    .line 95
    move-result-object v3

    .line 96
    invoke-static {p0, v0, v2, v3}, Lwl1;->K(Ltw;Lbm;Lk51;Ljava/lang/Object;)Lvv0;

    .line 97
    .line 98
    .line 99
    move-result-object v0

    .line 100
    invoke-virtual {v1, v7, v0}, Lhk0;->m(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 101
    .line 102
    .line 103
    goto :goto_6a

    .line 104
    :catchall_67
    move-exception v0

    .line 105
    move-object p0, v0

    .line 106
    goto :goto_6e

    .line 107
    :cond_6a
    :goto_6a
    check-cast v0, Lb81;
    :try_end_6c
    .catchall {:try_start_3 .. :try_end_6c} :catchall_67

    .line 108
    .line 109
    monitor-exit v1

    .line 110
    return-object v0

    .line 111
    :goto_6e
    monitor-exit v1

    .line 112
    throw p0
.end method

.method public static final b(Landroid/view/View;)Lsj;
    .registers 2

    .line 1
    const v0, 0x7f05002b

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0, v0}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    instance-of v0, p0, Lsj;

    .line 9
    .line 10
    if-eqz v0, :cond_e

    .line 11
    .line 12
    check-cast p0, Lsj;

    .line 13
    .line 14
    return-object p0

    .line 15
    :cond_e
    const/4 p0, 0x0

    .line 16
    return-object p0
.end method
