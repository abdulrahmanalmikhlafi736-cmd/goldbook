.class public final synthetic Lbu;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# instance fields
.field public final synthetic a:Lzc1;

.field public final synthetic b:Lzc1;

.field public final synthetic c:Led1;

.field public final synthetic d:Lju;

.field public final synthetic e:Lwu;

.field public final synthetic f:Lzc1;


# direct methods
.method public synthetic constructor <init>(Lzc1;Lzc1;Led1;Lju;Lwu;Lzc1;)V
    .registers 7

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lbu;->a:Lzc1;

    .line 5
    .line 6
    iput-object p2, p0, Lbu;->b:Lzc1;

    .line 7
    .line 8
    iput-object p3, p0, Lbu;->c:Led1;

    .line 9
    .line 10
    iput-object p4, p0, Lbu;->d:Lju;

    .line 11
    .line 12
    iput-object p5, p0, Lbu;->e:Lwu;

    .line 13
    .line 14
    iput-object p6, p0, Lbu;->f:Lzc1;

    .line 15
    .line 16
    return-void
.end method
