.class public abstract Lch1;
.super Landroid/view/View;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lkp0;


# static fields
.field public static final synthetic e:I


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Lzp;

    .line 2
    .line 3
    const/4 v1, 0x2

    .line 4
    invoke-direct {v0, v1}, Lzp;-><init>(I)V

    .line 5
    .line 6
    .line 7
    return-void
.end method
