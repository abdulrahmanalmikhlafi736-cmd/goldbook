.class public interface abstract La80;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lql;


# virtual methods
.method public abstract a(Ljava/util/concurrent/CancellationException;)V
.end method

.method public abstract b()Z
.end method

.method public abstract g(Lh80;)Lpf;
.end method

.method public abstract o()Ljava/util/concurrent/CancellationException;
.end method

.method public abstract r(Li00;)Lsq;
.end method

.method public abstract start()Z
.end method

.method public abstract v(Lnl;)Ljava/lang/Object;
.end method

.method public abstract w(ZZLe;)Lsq;
.end method
