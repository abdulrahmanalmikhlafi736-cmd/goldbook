.class public final synthetic Le4;
.super Lw00;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lxz;


# instance fields
.field public final synthetic l:I


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;III)V
    .registers 9

    .line 1
    iput p8, p0, Le4;->l:I

    .line 2
    .line 3
    invoke-direct/range {p0 .. p7}, Lw00;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;II)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .registers 27

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget v1, v0, Le4;->l:I

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    const/4 v4, 0x7

    .line 7
    iget-object v0, v0, Lge;->f:Ljava/lang/Object;

    .line 8
    .line 9
    packed-switch v1, :pswitch_data_160

    .line 10
    .line 11
    .line 12
    check-cast v0, Lvy;

    .line 13
    .line 14
    iget-object v0, v0, Lvy;->z:Lry;

    .line 15
    .line 16
    invoke-virtual {v0, v4}, Lry;->y0(I)Z

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    return-object v0

    .line 25
    :pswitch_18  #0x1
    check-cast v0, Lcy;

    .line 26
    .line 27
    iget-object v1, v0, Lcy;->c:Lik0;

    .line 28
    .line 29
    iget-object v5, v0, Lcy;->d:Lik0;

    .line 30
    .line 31
    iget-object v6, v0, Lcy;->a:Lhy;

    .line 32
    .line 33
    invoke-virtual {v6}, Lhy;->f()Lry;

    .line 34
    .line 35
    .line 36
    move-result-object v7

    .line 37
    const-wide v12, -0x7f7f7f7f7f7f7f80L  # -2.937446524422997E-306

    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    const/16 v14, 0x8

    .line 43
    .line 44
    if-nez v7, :cond_70

    .line 45
    .line 46
    iget-object v7, v5, Lik0;->b:[Ljava/lang/Object;

    .line 47
    .line 48
    iget-object v15, v5, Lik0;->a:[J

    .line 49
    .line 50
    const/16 v16, 0x0

    .line 51
    .line 52
    array-length v3, v15

    .line 53
    add-int/lit8 v3, v3, -0x2

    .line 54
    .line 55
    if-ltz v3, :cond_121

    .line 56
    .line 57
    move/from16 v17, v4

    .line 58
    .line 59
    const-wide/16 v18, 0x80

    .line 60
    .line 61
    move v4, v2

    .line 62
    :goto_3d
    aget-wide v8, v15, v4

    .line 63
    .line 64
    const-wide/16 v20, 0xff

    .line 65
    .line 66
    not-long v10, v8

    .line 67
    shl-long v10, v10, v17

    .line 68
    .line 69
    and-long/2addr v10, v8

    .line 70
    and-long/2addr v10, v12

    .line 71
    cmp-long v10, v10, v12

    .line 72
    .line 73
    if-eqz v10, :cond_6b

    .line 74
    .line 75
    sub-int v10, v4, v3

    .line 76
    .line 77
    not-int v10, v10

    .line 78
    ushr-int/lit8 v10, v10, 0x1f

    .line 79
    .line 80
    rsub-int/lit8 v10, v10, 0x8

    .line 81
    .line 82
    move v11, v2

    .line 83
    :goto_52
    if-ge v11, v10, :cond_69

    .line 84
    .line 85
    and-long v22, v8, v20

    .line 86
    .line 87
    cmp-long v22, v22, v18

    .line 88
    .line 89
    if-ltz v22, :cond_5e

    .line 90
    .line 91
    shr-long/2addr v8, v14

    .line 92
    add-int/lit8 v11, v11, 0x1

    .line 93
    .line 94
    goto :goto_52

    .line 95
    :cond_5e
    shl-int/lit8 v0, v4, 0x3

    .line 96
    .line 97
    add-int/2addr v0, v11

    .line 98
    aget-object v0, v7, v0

    .line 99
    .line 100
    check-cast v0, Lcb;

    .line 101
    .line 102
    invoke-virtual {v0}, Lcb;->s0()V

    .line 103
    .line 104
    .line 105
    throw v16

    .line 106
    :cond_69
    if-ne v10, v14, :cond_121

    .line 107
    .line 108
    :cond_6b
    if-eq v4, v3, :cond_121

    .line 109
    .line 110
    add-int/lit8 v4, v4, 0x1

    .line 111
    .line 112
    goto :goto_3d

    .line 113
    :cond_70
    move/from16 v17, v4

    .line 114
    .line 115
    const/16 v16, 0x0

    .line 116
    .line 117
    const-wide/16 v18, 0x80

    .line 118
    .line 119
    const-wide/16 v20, 0xff

    .line 120
    .line 121
    iget-boolean v3, v7, Lli0;->r:Z

    .line 122
    .line 123
    if-eqz v3, :cond_121

    .line 124
    .line 125
    invoke-virtual {v1, v7}, Lik0;->c(Ljava/lang/Object;)Z

    .line 126
    .line 127
    .line 128
    move-result v3

    .line 129
    if-eqz v3, :cond_85

    .line 130
    .line 131
    invoke-virtual {v7}, Lry;->x0()V

    .line 132
    .line 133
    .line 134
    :cond_85
    invoke-virtual {v7}, Lry;->w0()Lmy;

    .line 135
    .line 136
    .line 137
    iget-object v3, v7, Lli0;->e:Lli0;

    .line 138
    .line 139
    iget-boolean v3, v3, Lli0;->r:Z

    .line 140
    .line 141
    if-nez v3, :cond_93

    .line 142
    .line 143
    const-string v3, "visitAncestors called on an unattached node"

    .line 144
    .line 145
    invoke-static {v3}, Lp50;->b(Ljava/lang/String;)V

    .line 146
    .line 147
    .line 148
    :cond_93
    iget-object v3, v7, Lli0;->e:Lli0;

    .line 149
    .line 150
    invoke-static {v7}, Lk70;->O(Lcp;)Lba0;

    .line 151
    .line 152
    .line 153
    move-result-object v4

    .line 154
    move v7, v2

    .line 155
    :goto_9a
    if-eqz v4, :cond_e1

    .line 156
    .line 157
    iget-object v8, v4, Lba0;->J:Lem0;

    .line 158
    .line 159
    iget-object v8, v8, Lem0;->f:Lli0;

    .line 160
    .line 161
    iget v8, v8, Lli0;->h:I

    .line 162
    .line 163
    and-int/lit16 v8, v8, 0x1400

    .line 164
    .line 165
    if-eqz v8, :cond_d1

    .line 166
    .line 167
    :goto_a6
    if-eqz v3, :cond_d1

    .line 168
    .line 169
    iget v8, v3, Lli0;->g:I

    .line 170
    .line 171
    and-int/lit16 v9, v8, 0x1400

    .line 172
    .line 173
    if-eqz v9, :cond_ce

    .line 174
    .line 175
    and-int/lit16 v8, v8, 0x400

    .line 176
    .line 177
    if-eqz v8, :cond_b4

    .line 178
    .line 179
    add-int/lit8 v7, v7, 0x1

    .line 180
    .line 181
    :cond_b4
    instance-of v8, v3, Lcb;

    .line 182
    .line 183
    if-eqz v8, :cond_ce

    .line 184
    .line 185
    invoke-virtual {v5, v3}, Lik0;->c(Ljava/lang/Object;)Z

    .line 186
    .line 187
    .line 188
    move-result v8

    .line 189
    if-nez v8, :cond_bf

    .line 190
    .line 191
    goto :goto_ce

    .line 192
    :cond_bf
    const/4 v0, 0x1

    .line 193
    if-gt v7, v0, :cond_c8

    .line 194
    .line 195
    check-cast v3, Lcb;

    .line 196
    .line 197
    invoke-virtual {v3}, Lcb;->s0()V

    .line 198
    .line 199
    .line 200
    throw v16

    .line 201
    :cond_c8
    check-cast v3, Lcb;

    .line 202
    .line 203
    invoke-virtual {v3}, Lcb;->s0()V

    .line 204
    .line 205
    .line 206
    throw v16

    .line 207
    :cond_ce
    :goto_ce
    iget-object v3, v3, Lli0;->i:Lli0;

    .line 208
    .line 209
    goto :goto_a6

    .line 210
    :cond_d1
    invoke-virtual {v4}, Lba0;->v()Lba0;

    .line 211
    .line 212
    .line 213
    move-result-object v4

    .line 214
    if-eqz v4, :cond_de

    .line 215
    .line 216
    iget-object v3, v4, Lba0;->J:Lem0;

    .line 217
    .line 218
    if-eqz v3, :cond_de

    .line 219
    .line 220
    iget-object v3, v3, Lem0;->e:Lha1;

    .line 221
    .line 222
    goto :goto_9a

    .line 223
    :cond_de
    move-object/from16 v3, v16

    .line 224
    .line 225
    goto :goto_9a

    .line 226
    :cond_e1
    iget-object v3, v5, Lik0;->b:[Ljava/lang/Object;

    .line 227
    .line 228
    iget-object v4, v5, Lik0;->a:[J

    .line 229
    .line 230
    array-length v7, v4

    .line 231
    add-int/lit8 v7, v7, -0x2

    .line 232
    .line 233
    if-ltz v7, :cond_121

    .line 234
    .line 235
    move v8, v2

    .line 236
    :goto_eb
    aget-wide v9, v4, v8

    .line 237
    .line 238
    move-wide/from16 v22, v12

    .line 239
    .line 240
    not-long v12, v9

    .line 241
    shl-long v11, v12, v17

    .line 242
    .line 243
    and-long/2addr v11, v9

    .line 244
    and-long v11, v11, v22

    .line 245
    .line 246
    cmp-long v11, v11, v22

    .line 247
    .line 248
    if-eqz v11, :cond_11a

    .line 249
    .line 250
    sub-int v11, v8, v7

    .line 251
    .line 252
    not-int v11, v11

    .line 253
    ushr-int/lit8 v11, v11, 0x1f

    .line 254
    .line 255
    rsub-int/lit8 v11, v11, 0x8

    .line 256
    .line 257
    move v12, v2

    .line 258
    :goto_101
    if-ge v12, v11, :cond_118

    .line 259
    .line 260
    and-long v24, v9, v20

    .line 261
    .line 262
    cmp-long v13, v24, v18

    .line 263
    .line 264
    if-ltz v13, :cond_10d

    .line 265
    .line 266
    shr-long/2addr v9, v14

    .line 267
    add-int/lit8 v12, v12, 0x1

    .line 268
    .line 269
    goto :goto_101

    .line 270
    :cond_10d
    shl-int/lit8 v0, v8, 0x3

    .line 271
    .line 272
    add-int/2addr v0, v12

    .line 273
    aget-object v0, v3, v0

    .line 274
    .line 275
    check-cast v0, Lcb;

    .line 276
    .line 277
    invoke-virtual {v0}, Lcb;->s0()V

    .line 278
    .line 279
    .line 280
    throw v16

    .line 281
    :cond_118
    if-ne v11, v14, :cond_121

    .line 282
    .line 283
    :cond_11a
    if-eq v8, v7, :cond_121

    .line 284
    .line 285
    add-int/lit8 v8, v8, 0x1

    .line 286
    .line 287
    move-wide/from16 v12, v22

    .line 288
    .line 289
    goto :goto_eb

    .line 290
    :cond_121
    invoke-virtual {v6}, Lhy;->f()Lry;

    .line 291
    .line 292
    .line 293
    move-result-object v3

    .line 294
    if-eqz v3, :cond_131

    .line 295
    .line 296
    iget-object v3, v6, Lhy;->c:Lry;

    .line 297
    .line 298
    invoke-virtual {v3}, Lry;->w0()Lmy;

    .line 299
    .line 300
    .line 301
    move-result-object v3

    .line 302
    sget-object v4, Lmy;->g:Lmy;

    .line 303
    .line 304
    if-ne v3, v4, :cond_134

    .line 305
    .line 306
    :cond_131
    invoke-virtual {v6}, Lhy;->c()V

    .line 307
    .line 308
    .line 309
    :cond_134
    invoke-virtual {v1}, Lik0;->b()V

    .line 310
    .line 311
    .line 312
    invoke-virtual {v5}, Lik0;->b()V

    .line 313
    .line 314
    .line 315
    iput-boolean v2, v0, Lcy;->e:Z

    .line 316
    .line 317
    sget-object v0, Lwe1;->a:Lwe1;

    .line 318
    .line 319
    return-object v0

    .line 320
    :pswitch_13f  #0x0
    const/16 v16, 0x0

    .line 321
    .line 322
    check-cast v0, Landroid/view/View;

    .line 323
    .line 324
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 325
    .line 326
    const/16 v3, 0x1e

    .line 327
    .line 328
    if-lt v1, v3, :cond_14c

    .line 329
    .line 330
    invoke-static {v0}, Lg1;->f(Landroid/view/View;)V

    .line 331
    .line 332
    .line 333
    :cond_14c
    const/16 v3, 0x1d

    .line 334
    .line 335
    if-lt v1, v3, :cond_15d

    .line 336
    .line 337
    invoke-static {v0}, Lzk;->a(Landroid/view/View;)Landroid/view/contentcapture/ContentCaptureSession;

    .line 338
    .line 339
    .line 340
    move-result-object v1

    .line 341
    if-nez v1, :cond_157

    .line 342
    .line 343
    goto :goto_15d

    .line 344
    :cond_157
    new-instance v3, Lal;

    .line 345
    .line 346
    invoke-direct {v3, v2, v1, v0}, Lal;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 347
    .line 348
    .line 349
    goto :goto_15f

    .line 350
    :cond_15d
    :goto_15d
    move-object/from16 v3, v16

    .line 351
    .line 352
    :goto_15f
    return-object v3

    .line 353
    :pswitch_data_160
    .packed-switch 0x0
        :pswitch_13f  #00000000
        :pswitch_18  #00000001
    .end packed-switch
.end method
