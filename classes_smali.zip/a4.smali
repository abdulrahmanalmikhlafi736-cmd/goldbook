.class public final La4;
.super Lh90;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Li00;


# instance fields
.field public final synthetic f:I

.field public final synthetic g:Lks0;


# direct methods
.method public synthetic constructor <init>(Lks0;I)V
    .registers 3

    .line 1
    iput p2, p0, La4;->f:I

    .line 2
    .line 3
    iput-object p1, p0, La4;->g:Lks0;

    .line 4
    .line 5
    const/4 p1, 0x1

    .line 6
    invoke-direct {p0, p1}, Lh90;-><init>(I)V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final i(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 1
    iget v0, p0, La4;->f:I

    .line 2
    .line 3
    sget-object v1, Lwe1;->a:Lwe1;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    iget-object p0, p0, La4;->g:Lks0;

    .line 7
    .line 8
    packed-switch v0, :pswitch_data_2e

    .line 9
    .line 10
    .line 11
    check-cast p1, Ljs0;

    .line 12
    .line 13
    invoke-static {p1, p0, v2, v2}, Ljs0;->l(Ljs0;Lks0;II)V

    .line 14
    .line 15
    .line 16
    return-object v1

    .line 17
    :pswitch_10  #0x4
    check-cast p1, Ljs0;

    .line 18
    .line 19
    invoke-static {p1, p0, v2, v2}, Ljs0;->j(Ljs0;Lks0;II)V

    .line 20
    .line 21
    .line 22
    return-object v1

    .line 23
    :pswitch_16  #0x3
    check-cast p1, Ljs0;

    .line 24
    .line 25
    invoke-static {p1, p0, v2, v2}, Ljs0;->h(Ljs0;Lks0;II)V

    .line 26
    .line 27
    .line 28
    return-object v1

    .line 29
    :pswitch_1c  #0x2
    check-cast p1, Ljs0;

    .line 30
    .line 31
    invoke-static {p1, p0, v2, v2}, Ljs0;->h(Ljs0;Lks0;II)V

    .line 32
    .line 33
    .line 34
    return-object v1

    .line 35
    :pswitch_22  #0x1
    check-cast p1, Ljs0;

    .line 36
    .line 37
    invoke-static {p1, p0, v2, v2}, Ljs0;->h(Ljs0;Lks0;II)V

    .line 38
    .line 39
    .line 40
    return-object v1

    .line 41
    :pswitch_28  #0x0
    check-cast p1, Ljs0;

    .line 42
    .line 43
    invoke-static {p1, p0, v2, v2}, Ljs0;->h(Ljs0;Lks0;II)V

    .line 44
    .line 45
    .line 46
    return-object v1

    .line 47
    :pswitch_data_2e
    .packed-switch 0x0
        :pswitch_28  #00000000
        :pswitch_22  #00000001
        :pswitch_1c  #00000002
        :pswitch_16  #00000003
        :pswitch_10  #00000004
    .end packed-switch
.end method
