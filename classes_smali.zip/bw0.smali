.class public final synthetic Lbw0;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Li00;


# instance fields
.field public final synthetic e:Ldw0;

.field public final synthetic f:Lik0;

.field public final synthetic g:Lik0;

.field public final synthetic h:Ljava/util/List;

.field public final synthetic i:Ljava/util/List;

.field public final synthetic j:Lik0;

.field public final synthetic k:Ljava/util/List;

.field public final synthetic l:Lik0;

.field public final synthetic m:Ljava/util/Set;


# direct methods
.method public synthetic constructor <init>(Ldw0;Lik0;Lik0;Ljava/util/List;Ljava/util/List;Lik0;Ljava/util/List;Lik0;Ljava/util/Set;)V
    .registers 10

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lbw0;->e:Ldw0;

    .line 5
    .line 6
    iput-object p2, p0, Lbw0;->f:Lik0;

    .line 7
    .line 8
    iput-object p3, p0, Lbw0;->g:Lik0;

    .line 9
    .line 10
    iput-object p4, p0, Lbw0;->h:Ljava/util/List;

    .line 11
    .line 12
    iput-object p5, p0, Lbw0;->i:Ljava/util/List;

    .line 13
    .line 14
    iput-object p6, p0, Lbw0;->j:Lik0;

    .line 15
    .line 16
    iput-object p7, p0, Lbw0;->k:Ljava/util/List;

    .line 17
    .line 18
    iput-object p8, p0, Lbw0;->l:Lik0;

    .line 19
    .line 20
    iput-object p9, p0, Lbw0;->m:Ljava/util/Set;

    .line 21
    .line 22
    return-void
.end method


# virtual methods
.method public final i(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 29

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-object v1, v0, Lbw0;->e:Ldw0;

    .line 4
    .line 5
    iget-object v7, v0, Lbw0;->f:Lik0;

    .line 6
    .line 7
    iget-object v8, v0, Lbw0;->g:Lik0;

    .line 8
    .line 9
    iget-object v2, v0, Lbw0;->h:Ljava/util/List;

    .line 10
    .line 11
    iget-object v3, v0, Lbw0;->i:Ljava/util/List;

    .line 12
    .line 13
    iget-object v5, v0, Lbw0;->j:Lik0;

    .line 14
    .line 15
    iget-object v4, v0, Lbw0;->k:Ljava/util/List;

    .line 16
    .line 17
    iget-object v6, v0, Lbw0;->l:Lik0;

    .line 18
    .line 19
    iget-object v0, v0, Lbw0;->m:Ljava/util/Set;

    .line 20
    .line 21
    move-object/from16 v9, p1

    .line 22
    .line 23
    check-cast v9, Ljava/lang/Long;

    .line 24
    .line 25
    invoke-virtual {v9}, Ljava/lang/Long;->longValue()J

    .line 26
    .line 27
    .line 28
    move-result-wide v9

    .line 29
    invoke-static {v1}, Ldw0;->y(Ldw0;)Z

    .line 30
    .line 31
    .line 32
    move-result v11

    .line 33
    if-eqz v11, :cond_41

    .line 34
    .line 35
    const-string v11, "Recomposer:animation"

    .line 36
    .line 37
    invoke-static {v11}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    .line 38
    .line 39
    .line 40
    :try_start_27
    iget-object v11, v1, Ldw0;->a:Lg7;

    .line 41
    .line 42
    iget-object v11, v11, Lg7;->g:Ljava/lang/Object;

    .line 43
    .line 44
    check-cast v11, Lpa;

    .line 45
    .line 46
    new-instance v12, Lad;

    .line 47
    .line 48
    invoke-direct {v12, v9, v10}, Lad;-><init>(J)V

    .line 49
    .line 50
    .line 51
    invoke-virtual {v11, v12}, Lpa;->f(Li00;)V

    .line 52
    .line 53
    .line 54
    invoke-static {}, Lkb0;->A()V
    :try_end_38
    .catchall {:try_start_27 .. :try_end_38} :catchall_3c

    .line 55
    .line 56
    .line 57
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 58
    .line 59
    .line 60
    goto :goto_41

    .line 61
    :catchall_3c
    move-exception v0

    .line 62
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 63
    .line 64
    .line 65
    throw v0

    .line 66
    :cond_41
    :goto_41
    const-string v9, "Recomposer:recompose"

    .line 67
    .line 68
    invoke-static {v9}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    .line 69
    .line 70
    .line 71
    :try_start_46
    invoke-virtual {v1}, Ldw0;->Q()Z

    .line 72
    .line 73
    .line 74
    iget-object v9, v1, Ldw0;->c:Ljava/lang/Object;

    .line 75
    .line 76
    monitor-enter v9
    :try_end_4c
    .catchall {:try_start_46 .. :try_end_4c} :catchall_312

    .line 77
    :try_start_4c
    iget-object v10, v1, Ldw0;->i:Lqk0;

    .line 78
    .line 79
    iget-object v11, v10, Lqk0;->e:[Ljava/lang/Object;

    .line 80
    .line 81
    iget v10, v10, Lqk0;->g:I

    .line 82
    .line 83
    const/4 v12, 0x0

    .line 84
    move v13, v12

    .line 85
    :goto_54
    if-ge v13, v10, :cond_63

    .line 86
    .line 87
    aget-object v14, v11, v13

    .line 88
    .line 89
    check-cast v14, Lyj;

    .line 90
    .line 91
    invoke-interface {v2, v14}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 92
    .line 93
    .line 94
    add-int/lit8 v13, v13, 0x1

    .line 95
    .line 96
    goto :goto_54

    .line 97
    :catchall_60
    move-exception v0

    .line 98
    goto/16 :goto_310

    .line 99
    .line 100
    :cond_63
    iget-object v10, v1, Ldw0;->i:Lqk0;

    .line 101
    .line 102
    invoke-virtual {v10}, Lqk0;->g()V
    :try_end_68
    .catchall {:try_start_4c .. :try_end_68} :catchall_60

    .line 103
    .line 104
    .line 105
    :try_start_68
    monitor-exit v9

    .line 106
    invoke-virtual {v7}, Lik0;->b()V

    .line 107
    .line 108
    .line 109
    invoke-virtual {v8}, Lik0;->b()V

    .line 110
    .line 111
    .line 112
    :goto_6f
    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    .line 113
    .line 114
    .line 115
    move-result v9

    .line 116
    const/4 v10, 0x0

    .line 117
    if-eqz v9, :cond_231

    .line 118
    .line 119
    invoke-interface {v3}, Ljava/util/Collection;->isEmpty()Z

    .line 120
    .line 121
    .line 122
    move-result v9

    .line 123
    if-nez v9, :cond_7e

    .line 124
    .line 125
    goto/16 :goto_231

    .line 126
    .line 127
    :cond_7e
    invoke-static {}, Ln61;->j()Lg61;

    .line 128
    .line 129
    .line 130
    move-result-object v0

    .line 131
    instance-of v9, v0, Llk0;

    .line 132
    .line 133
    if-eqz v9, :cond_96

    .line 134
    .line 135
    new-instance v13, Lhd1;

    .line 136
    .line 137
    move-object v14, v0

    .line 138
    check-cast v14, Llk0;

    .line 139
    .line 140
    const/16 v17, 0x1

    .line 141
    .line 142
    const/16 v18, 0x0

    .line 143
    .line 144
    const/4 v15, 0x0

    .line 145
    const/16 v16, 0x0

    .line 146
    .line 147
    invoke-direct/range {v13 .. v18}, Lhd1;-><init>(Llk0;Li00;Li00;ZZ)V

    .line 148
    .line 149
    .line 150
    goto :goto_9c

    .line 151
    :cond_96
    new-instance v13, Lid1;

    .line 152
    .line 153
    const/4 v9, 0x1

    .line 154
    invoke-direct {v13, v0, v10, v9, v12}, Lid1;-><init>(Lg61;Li00;ZZ)V
    :try_end_9c
    .catchall {:try_start_68 .. :try_end_9c} :catchall_312

    .line 155
    .line 156
    .line 157
    :goto_9c
    :try_start_9c
    invoke-virtual {v13}, Lg61;->j()Lg61;

    .line 158
    .line 159
    .line 160
    move-result-object v9
    :try_end_a0
    .catchall {:try_start_9c .. :try_end_a0} :catchall_e3

    .line 161
    :try_start_a0
    invoke-interface {v4}, Ljava/util/Collection;->isEmpty()Z

    .line 162
    .line 163
    .line 164
    move-result v0
    :try_end_a4
    .catchall {:try_start_a0 .. :try_end_a4} :catchall_d2

    .line 165
    if-nez v0, :cond_eb

    .line 166
    .line 167
    :try_start_a6
    invoke-interface {v4}, Ljava/util/Collection;->size()I

    .line 168
    .line 169
    .line 170
    move-result v0

    .line 171
    move v11, v12

    .line 172
    :goto_ab
    if-ge v11, v0, :cond_bb

    .line 173
    .line 174
    invoke-interface {v4, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 175
    .line 176
    .line 177
    move-result-object v14

    .line 178
    check-cast v14, Lyj;

    .line 179
    .line 180
    invoke-virtual {v6, v14}, Lik0;->a(Ljava/lang/Object;)Z

    .line 181
    .line 182
    .line 183
    add-int/lit8 v11, v11, 0x1

    .line 184
    .line 185
    goto :goto_ab

    .line 186
    :catchall_b9
    move-exception v0

    .line 187
    goto :goto_d5

    .line 188
    :cond_bb
    invoke-interface {v4}, Ljava/util/Collection;->size()I

    .line 189
    .line 190
    .line 191
    move-result v0

    .line 192
    move v11, v12

    .line 193
    :goto_c0
    if-ge v11, v0, :cond_ce

    .line 194
    .line 195
    invoke-interface {v4, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 196
    .line 197
    .line 198
    move-result-object v14

    .line 199
    check-cast v14, Lyj;

    .line 200
    .line 201
    invoke-virtual {v14}, Lyj;->d()V
    :try_end_cb
    .catchall {:try_start_a6 .. :try_end_cb} :catchall_b9

    .line 202
    .line 203
    .line 204
    add-int/lit8 v11, v11, 0x1

    .line 205
    .line 206
    goto :goto_c0

    .line 207
    :cond_ce
    :try_start_ce
    invoke-interface {v4}, Ljava/util/List;->clear()V
    :try_end_d1
    .catchall {:try_start_ce .. :try_end_d1} :catchall_d2

    .line 208
    .line 209
    .line 210
    goto :goto_eb

    .line 211
    :catchall_d2
    move-exception v0

    .line 212
    goto/16 :goto_229

    .line 213
    .line 214
    :goto_d5
    :try_start_d5
    invoke-virtual {v1, v0, v10}, Ldw0;->P(Ljava/lang/Throwable;Lyj;)V

    .line 215
    .line 216
    .line 217
    invoke-static/range {v1 .. v8}, Lcw0;->r(Ldw0;Ljava/util/List;Ljava/util/List;Ljava/util/List;Lik0;Lik0;Lik0;Lik0;)V
    :try_end_db
    .catchall {:try_start_d5 .. :try_end_db} :catchall_e6

    .line 218
    .line 219
    .line 220
    :try_start_db
    invoke-interface {v4}, Ljava/util/List;->clear()V
    :try_end_de
    .catchall {:try_start_db .. :try_end_de} :catchall_d2

    .line 221
    .line 222
    .line 223
    :try_start_de
    invoke-static {v9}, Lg61;->q(Lg61;)V
    :try_end_e1
    .catchall {:try_start_de .. :try_end_e1} :catchall_e3

    .line 224
    .line 225
    .line 226
    goto/16 :goto_1f2

    .line 227
    .line 228
    :catchall_e3
    move-exception v0

    .line 229
    goto/16 :goto_22d

    .line 230
    .line 231
    :catchall_e6
    move-exception v0

    .line 232
    :try_start_e7
    invoke-interface {v4}, Ljava/util/List;->clear()V

    .line 233
    .line 234
    .line 235
    throw v0

    .line 236
    :cond_eb
    :goto_eb
    invoke-virtual {v5}, Lik0;->h()Z

    .line 237
    .line 238
    .line 239
    move-result v0
    :try_end_ef
    .catchall {:try_start_e7 .. :try_end_ef} :catchall_d2

    .line 240
    const-wide/16 v16, 0xff

    .line 241
    .line 242
    const-wide v18, -0x7f7f7f7f7f7f7f80L  # -2.937446524422997E-306

    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    const/16 p0, 0x7

    .line 248
    .line 249
    if-eqz v0, :cond_175

    .line 250
    .line 251
    :try_start_fa
    invoke-virtual {v6, v5}, Lik0;->j(Lik0;)V

    .line 252
    .line 253
    .line 254
    iget-object v0, v5, Lik0;->b:[Ljava/lang/Object;

    .line 255
    .line 256
    iget-object v12, v5, Lik0;->a:[J

    .line 257
    .line 258
    const-wide/16 v20, 0x80

    .line 259
    .line 260
    array-length v14, v12

    .line 261
    add-int/lit8 v14, v14, -0x2

    .line 262
    .line 263
    if-ltz v14, :cond_152

    .line 264
    .line 265
    const/4 v15, 0x0

    .line 266
    :goto_109
    const/16 v22, 0x8

    .line 267
    .line 268
    aget-wide v10, v12, v15
    :try_end_10d
    .catchall {:try_start_fa .. :try_end_10d} :catchall_14c

    .line 269
    .line 270
    move-object/from16 v23, v2

    .line 271
    .line 272
    move-object/from16 v24, v3

    .line 273
    .line 274
    not-long v2, v10

    .line 275
    shl-long v2, v2, p0

    .line 276
    .line 277
    and-long/2addr v2, v10

    .line 278
    and-long v2, v2, v18

    .line 279
    .line 280
    cmp-long v2, v2, v18

    .line 281
    .line 282
    if-eqz v2, :cond_143

    .line 283
    .line 284
    sub-int v2, v15, v14

    .line 285
    .line 286
    not-int v2, v2

    .line 287
    ushr-int/lit8 v2, v2, 0x1f

    .line 288
    .line 289
    rsub-int/lit8 v2, v2, 0x8

    .line 290
    .line 291
    const/4 v3, 0x0

    .line 292
    :goto_123
    if-ge v3, v2, :cond_13f

    .line 293
    .line 294
    and-long v25, v10, v16

    .line 295
    .line 296
    cmp-long v25, v25, v20

    .line 297
    .line 298
    if-gez v25, :cond_13a

    .line 299
    .line 300
    shl-int/lit8 v25, v15, 0x3

    .line 301
    .line 302
    add-int v25, v25, v3

    .line 303
    .line 304
    :try_start_12f
    aget-object v25, v0, v25

    .line 305
    .line 306
    check-cast v25, Lyj;

    .line 307
    .line 308
    invoke-virtual/range {v25 .. v25}, Lyj;->f()V
    :try_end_136
    .catchall {:try_start_12f .. :try_end_136} :catchall_137

    .line 309
    .line 310
    .line 311
    goto :goto_13a

    .line 312
    :catchall_137
    move-exception v0

    .line 313
    :goto_138
    const/4 v2, 0x0

    .line 314
    goto :goto_15e

    .line 315
    :cond_13a
    :goto_13a
    shr-long v10, v10, v22

    .line 316
    .line 317
    add-int/lit8 v3, v3, 0x1

    .line 318
    .line 319
    goto :goto_123

    .line 320
    :cond_13f
    move/from16 v3, v22

    .line 321
    .line 322
    if-ne v2, v3, :cond_156

    .line 323
    .line 324
    :cond_143
    if-eq v15, v14, :cond_156

    .line 325
    .line 326
    add-int/lit8 v15, v15, 0x1

    .line 327
    .line 328
    move-object/from16 v2, v23

    .line 329
    .line 330
    move-object/from16 v3, v24

    .line 331
    .line 332
    goto :goto_109

    .line 333
    :catchall_14c
    move-exception v0

    .line 334
    move-object/from16 v23, v2

    .line 335
    .line 336
    move-object/from16 v24, v3

    .line 337
    .line 338
    goto :goto_138

    .line 339
    :cond_152
    move-object/from16 v23, v2

    .line 340
    .line 341
    move-object/from16 v24, v3

    .line 342
    .line 343
    :cond_156
    :try_start_156
    invoke-virtual {v5}, Lik0;->b()V
    :try_end_159
    .catchall {:try_start_156 .. :try_end_159} :catchall_d2

    .line 344
    .line 345
    .line 346
    move-object/from16 v2, v23

    .line 347
    .line 348
    move-object/from16 v3, v24

    .line 349
    .line 350
    goto :goto_177

    .line 351
    :goto_15e
    :try_start_15e
    invoke-virtual {v1, v0, v2}, Ldw0;->P(Ljava/lang/Throwable;Lyj;)V

    .line 352
    .line 353
    .line 354
    move-object/from16 v2, v23

    .line 355
    .line 356
    move-object/from16 v3, v24

    .line 357
    .line 358
    invoke-static/range {v1 .. v8}, Lcw0;->r(Ldw0;Ljava/util/List;Ljava/util/List;Ljava/util/List;Lik0;Lik0;Lik0;Lik0;)V
    :try_end_168
    .catchall {:try_start_15e .. :try_end_168} :catchall_170

    .line 359
    .line 360
    .line 361
    :try_start_168
    invoke-virtual {v5}, Lik0;->b()V
    :try_end_16b
    .catchall {:try_start_168 .. :try_end_16b} :catchall_d2

    .line 362
    .line 363
    .line 364
    :try_start_16b
    invoke-static {v9}, Lg61;->q(Lg61;)V
    :try_end_16e
    .catchall {:try_start_16b .. :try_end_16e} :catchall_e3

    .line 365
    .line 366
    .line 367
    goto/16 :goto_1f2

    .line 368
    .line 369
    :catchall_170
    move-exception v0

    .line 370
    :try_start_171
    invoke-virtual {v5}, Lik0;->b()V

    .line 371
    .line 372
    .line 373
    throw v0

    .line 374
    :cond_175
    const-wide/16 v20, 0x80

    .line 375
    .line 376
    :goto_177
    invoke-virtual {v6}, Lik0;->h()Z

    .line 377
    .line 378
    .line 379
    move-result v0
    :try_end_17b
    .catchall {:try_start_171 .. :try_end_17b} :catchall_d2

    .line 380
    if-eqz v0, :cond_1fb

    .line 381
    .line 382
    :try_start_17d
    iget-object v0, v6, Lik0;->b:[Ljava/lang/Object;

    .line 383
    .line 384
    iget-object v10, v6, Lik0;->a:[J

    .line 385
    .line 386
    array-length v11, v10

    .line 387
    add-int/lit8 v11, v11, -0x2

    .line 388
    .line 389
    if-ltz v11, :cond_1de

    .line 390
    .line 391
    const/4 v12, 0x0

    .line 392
    :goto_187
    aget-wide v14, v10, v12
    :try_end_189
    .catchall {:try_start_17d .. :try_end_189} :catchall_1d8

    .line 393
    .line 394
    move-object/from16 v23, v2

    .line 395
    .line 396
    move-object/from16 v24, v3

    .line 397
    .line 398
    not-long v2, v14

    .line 399
    shl-long v2, v2, p0

    .line 400
    .line 401
    and-long/2addr v2, v14

    .line 402
    and-long v2, v2, v18

    .line 403
    .line 404
    cmp-long v2, v2, v18

    .line 405
    .line 406
    if-eqz v2, :cond_1c9

    .line 407
    .line 408
    sub-int v2, v12, v11

    .line 409
    .line 410
    not-int v2, v2

    .line 411
    ushr-int/lit8 v2, v2, 0x1f

    .line 412
    .line 413
    const/16 v22, 0x8

    .line 414
    .line 415
    rsub-int/lit8 v2, v2, 0x8

    .line 416
    .line 417
    const/4 v3, 0x0

    .line 418
    :goto_1a1
    if-ge v3, v2, :cond_1c2

    .line 419
    .line 420
    and-long v25, v14, v16

    .line 421
    .line 422
    cmp-long v25, v25, v20

    .line 423
    .line 424
    if-gez v25, :cond_1b4

    .line 425
    .line 426
    shl-int/lit8 v25, v12, 0x3

    .line 427
    .line 428
    add-int v25, v25, v3

    .line 429
    .line 430
    :try_start_1ad
    aget-object v25, v0, v25

    .line 431
    .line 432
    check-cast v25, Lyj;

    .line 433
    .line 434
    invoke-virtual/range {v25 .. v25}, Lyj;->g()V
    :try_end_1b4
    .catchall {:try_start_1ad .. :try_end_1b4} :catchall_1b9

    .line 435
    .line 436
    .line 437
    :cond_1b4
    move-object/from16 v25, v0

    .line 438
    .line 439
    const/16 v0, 0x8

    .line 440
    .line 441
    goto :goto_1bc

    .line 442
    :catchall_1b9
    move-exception v0

    .line 443
    :goto_1ba
    const/4 v2, 0x0

    .line 444
    goto :goto_1e2

    .line 445
    :goto_1bc
    shr-long/2addr v14, v0

    .line 446
    add-int/lit8 v3, v3, 0x1

    .line 447
    .line 448
    move-object/from16 v0, v25

    .line 449
    .line 450
    goto :goto_1a1

    .line 451
    :cond_1c2
    move-object/from16 v25, v0

    .line 452
    .line 453
    const/16 v0, 0x8

    .line 454
    .line 455
    if-ne v2, v0, :cond_1de

    .line 456
    .line 457
    goto :goto_1cd

    .line 458
    :cond_1c9
    move-object/from16 v25, v0

    .line 459
    .line 460
    const/16 v0, 0x8

    .line 461
    .line 462
    :goto_1cd
    if-eq v12, v11, :cond_1de

    .line 463
    .line 464
    add-int/lit8 v12, v12, 0x1

    .line 465
    .line 466
    move-object/from16 v2, v23

    .line 467
    .line 468
    move-object/from16 v3, v24

    .line 469
    .line 470
    move-object/from16 v0, v25

    .line 471
    .line 472
    goto :goto_187

    .line 473
    :catchall_1d8
    move-exception v0

    .line 474
    move-object/from16 v23, v2

    .line 475
    .line 476
    move-object/from16 v24, v3

    .line 477
    .line 478
    goto :goto_1ba

    .line 479
    :cond_1de
    :try_start_1de
    invoke-virtual {v6}, Lik0;->b()V
    :try_end_1e1
    .catchall {:try_start_1de .. :try_end_1e1} :catchall_d2

    .line 480
    .line 481
    .line 482
    goto :goto_1fb

    .line 483
    :goto_1e2
    :try_start_1e2
    invoke-virtual {v1, v0, v2}, Ldw0;->P(Ljava/lang/Throwable;Lyj;)V

    .line 484
    .line 485
    .line 486
    move-object/from16 v2, v23

    .line 487
    .line 488
    move-object/from16 v3, v24

    .line 489
    .line 490
    invoke-static/range {v1 .. v8}, Lcw0;->r(Ldw0;Ljava/util/List;Ljava/util/List;Ljava/util/List;Lik0;Lik0;Lik0;Lik0;)V
    :try_end_1ec
    .catchall {:try_start_1e2 .. :try_end_1ec} :catchall_1f6

    .line 491
    .line 492
    .line 493
    :try_start_1ec
    invoke-virtual {v6}, Lik0;->b()V
    :try_end_1ef
    .catchall {:try_start_1ec .. :try_end_1ef} :catchall_d2

    .line 494
    .line 495
    .line 496
    :try_start_1ef
    invoke-static {v9}, Lg61;->q(Lg61;)V
    :try_end_1f2
    .catchall {:try_start_1ef .. :try_end_1f2} :catchall_e3

    .line 497
    .line 498
    .line 499
    :goto_1f2
    :try_start_1f2
    invoke-virtual {v13}, Lg61;->c()V
    :try_end_1f5
    .catchall {:try_start_1f2 .. :try_end_1f5} :catchall_312

    .line 500
    .line 501
    .line 502
    goto :goto_221

    .line 503
    :catchall_1f6
    move-exception v0

    .line 504
    :try_start_1f7
    invoke-virtual {v6}, Lik0;->b()V

    .line 505
    .line 506
    .line 507
    throw v0
    :try_end_1fb
    .catchall {:try_start_1f7 .. :try_end_1fb} :catchall_d2

    .line 508
    :cond_1fb
    :goto_1fb
    :try_start_1fb
    invoke-static {v9}, Lg61;->q(Lg61;)V
    :try_end_1fe
    .catchall {:try_start_1fb .. :try_end_1fe} :catchall_e3

    .line 509
    .line 510
    .line 511
    :try_start_1fe
    invoke-virtual {v13}, Lg61;->c()V

    .line 512
    .line 513
    .line 514
    iget-object v2, v1, Ldw0;->c:Ljava/lang/Object;

    .line 515
    .line 516
    monitor-enter v2
    :try_end_204
    .catchall {:try_start_1fe .. :try_end_204} :catchall_312

    .line 517
    :try_start_204
    invoke-virtual {v1}, Ldw0;->D()Lle;

    .line 518
    .line 519
    .line 520
    move-result-object v0

    .line 521
    if-nez v0, :cond_20b

    .line 522
    .line 523
    goto :goto_210

    .line 524
    :cond_20b
    const-string v0, "unexpected to get continuation here"

    .line 525
    .line 526
    invoke-static {v0}, Lqj;->a(Ljava/lang/String;)V
    :try_end_210
    .catchall {:try_start_204 .. :try_end_210} :catchall_226

    .line 527
    .line 528
    .line 529
    :goto_210
    :try_start_210
    monitor-exit v2

    .line 530
    invoke-static {}, Ln61;->j()Lg61;

    .line 531
    .line 532
    .line 533
    move-result-object v0

    .line 534
    invoke-virtual {v0}, Lg61;->m()V

    .line 535
    .line 536
    .line 537
    invoke-virtual {v8}, Lik0;->b()V

    .line 538
    .line 539
    .line 540
    invoke-virtual {v7}, Lik0;->b()V

    .line 541
    .line 542
    .line 543
    const/4 v2, 0x0

    .line 544
    iput-object v2, v1, Ldw0;->q:Lik0;
    :try_end_221
    .catchall {:try_start_210 .. :try_end_221} :catchall_312

    .line 545
    .line 546
    :goto_221
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 547
    .line 548
    .line 549
    goto/16 :goto_308

    .line 550
    .line 551
    :catchall_226
    move-exception v0

    .line 552
    :try_start_227
    monitor-exit v2

    .line 553
    throw v0
    :try_end_229
    .catchall {:try_start_227 .. :try_end_229} :catchall_312

    .line 554
    :goto_229
    :try_start_229
    invoke-static {v9}, Lg61;->q(Lg61;)V

    .line 555
    .line 556
    .line 557
    throw v0
    :try_end_22d
    .catchall {:try_start_229 .. :try_end_22d} :catchall_e3

    .line 558
    :goto_22d
    :try_start_22d
    invoke-virtual {v13}, Lg61;->c()V

    .line 559
    .line 560
    .line 561
    throw v0
    :try_end_231
    .catchall {:try_start_22d .. :try_end_231} :catchall_312

    .line 562
    :cond_231
    :goto_231
    :try_start_231
    invoke-interface {v2}, Ljava/util/Collection;->size()I

    .line 563
    .line 564
    .line 565
    move-result v9

    .line 566
    const/4 v10, 0x0

    .line 567
    :goto_236
    if-ge v10, v9, :cond_252

    .line 568
    .line 569
    invoke-interface {v2, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 570
    .line 571
    .line 572
    move-result-object v11

    .line 573
    check-cast v11, Lyj;

    .line 574
    .line 575
    invoke-virtual {v1, v11, v7}, Ldw0;->O(Lyj;Lik0;)Lyj;

    .line 576
    .line 577
    .line 578
    move-result-object v12

    .line 579
    if-eqz v12, :cond_24c

    .line 580
    .line 581
    invoke-interface {v4, v12}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 582
    .line 583
    .line 584
    goto :goto_24c

    .line 585
    :catchall_248
    move-exception v0

    .line 586
    const/4 v13, 0x0

    .line 587
    goto/16 :goto_2fd

    .line 588
    .line 589
    :cond_24c
    :goto_24c
    invoke-virtual {v8, v11}, Lik0;->a(Ljava/lang/Object;)Z
    :try_end_24f
    .catchall {:try_start_231 .. :try_end_24f} :catchall_248

    .line 590
    .line 591
    .line 592
    add-int/lit8 v10, v10, 0x1

    .line 593
    .line 594
    goto :goto_236

    .line 595
    :cond_252
    :try_start_252
    invoke-interface {v2}, Ljava/util/List;->clear()V

    .line 596
    .line 597
    .line 598
    invoke-virtual {v7}, Lik0;->h()Z

    .line 599
    .line 600
    .line 601
    move-result v9

    .line 602
    if-nez v9, :cond_261

    .line 603
    .line 604
    iget-object v9, v1, Ldw0;->i:Lqk0;

    .line 605
    .line 606
    iget v9, v9, Lqk0;->g:I

    .line 607
    .line 608
    if-eqz v9, :cond_2c1

    .line 609
    .line 610
    :cond_261
    iget-object v9, v1, Ldw0;->c:Ljava/lang/Object;

    .line 611
    .line 612
    monitor-enter v9
    :try_end_264
    .catchall {:try_start_252 .. :try_end_264} :catchall_312

    .line 613
    :try_start_264
    invoke-virtual {v1}, Ldw0;->I()Ljava/util/List;

    .line 614
    .line 615
    .line 616
    move-result-object v10

    .line 617
    invoke-interface {v10}, Ljava/util/Collection;->size()I

    .line 618
    .line 619
    .line 620
    move-result v11

    .line 621
    const/4 v12, 0x0

    .line 622
    :goto_26d
    if-ge v12, v11, :cond_28b

    .line 623
    .line 624
    invoke-interface {v10, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 625
    .line 626
    .line 627
    move-result-object v13

    .line 628
    check-cast v13, Lyj;

    .line 629
    .line 630
    invoke-virtual {v8, v13}, Lik0;->c(Ljava/lang/Object;)Z

    .line 631
    .line 632
    .line 633
    move-result v14

    .line 634
    if-nez v14, :cond_288

    .line 635
    .line 636
    invoke-virtual {v13, v0}, Lyj;->v(Ljava/util/Set;)Z

    .line 637
    .line 638
    .line 639
    move-result v14

    .line 640
    if-eqz v14, :cond_288

    .line 641
    .line 642
    invoke-interface {v2, v13}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 643
    .line 644
    .line 645
    goto :goto_288

    .line 646
    :catchall_285
    move-exception v0

    .line 647
    goto/16 :goto_2fb

    .line 648
    .line 649
    :cond_288
    :goto_288
    add-int/lit8 v12, v12, 0x1

    .line 650
    .line 651
    goto :goto_26d

    .line 652
    :cond_28b
    iget-object v10, v1, Ldw0;->i:Lqk0;

    .line 653
    .line 654
    iget v11, v10, Lqk0;->g:I
    :try_end_28f
    .catchall {:try_start_264 .. :try_end_28f} :catchall_285

    .line 655
    .line 656
    const/4 v12, 0x0

    .line 657
    const/4 v13, 0x0

    .line 658
    :goto_291
    iget-object v14, v10, Lqk0;->e:[Ljava/lang/Object;

    .line 659
    .line 660
    if-ge v12, v11, :cond_2b8

    .line 661
    .line 662
    :try_start_295
    aget-object v14, v14, v12

    .line 663
    .line 664
    check-cast v14, Lyj;

    .line 665
    .line 666
    invoke-virtual {v8, v14}, Lik0;->c(Ljava/lang/Object;)Z

    .line 667
    .line 668
    .line 669
    move-result v15

    .line 670
    if-nez v15, :cond_2ab

    .line 671
    .line 672
    invoke-interface {v2, v14}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 673
    .line 674
    .line 675
    move-result v15

    .line 676
    if-nez v15, :cond_2ab

    .line 677
    .line 678
    invoke-interface {v2, v14}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 679
    .line 680
    .line 681
    add-int/lit8 v13, v13, 0x1

    .line 682
    .line 683
    goto :goto_2b5

    .line 684
    :cond_2ab
    if-lez v13, :cond_2b5

    .line 685
    .line 686
    iget-object v14, v10, Lqk0;->e:[Ljava/lang/Object;

    .line 687
    .line 688
    sub-int v15, v12, v13

    .line 689
    .line 690
    aget-object v16, v14, v12

    .line 691
    .line 692
    aput-object v16, v14, v15

    .line 693
    .line 694
    :cond_2b5
    :goto_2b5
    add-int/lit8 v12, v12, 0x1

    .line 695
    .line 696
    goto :goto_291

    .line 697
    :cond_2b8
    sub-int v12, v11, v13

    .line 698
    .line 699
    const/4 v13, 0x0

    .line 700
    invoke-static {v14, v12, v11, v13}, Ljava/util/Arrays;->fill([Ljava/lang/Object;IILjava/lang/Object;)V

    .line 701
    .line 702
    .line 703
    iput v12, v10, Lqk0;->g:I
    :try_end_2c0
    .catchall {:try_start_295 .. :try_end_2c0} :catchall_285

    .line 704
    .line 705
    :try_start_2c0
    monitor-exit v9

    .line 706
    :cond_2c1
    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    .line 707
    .line 708
    .line 709
    move-result v9
    :try_end_2c5
    .catchall {:try_start_2c0 .. :try_end_2c5} :catchall_312

    .line 710
    if-eqz v9, :cond_2f0

    .line 711
    .line 712
    :try_start_2c7
    invoke-static {v3, v1}, Lcw0;->s(Ljava/util/List;Ldw0;)V

    .line 713
    .line 714
    .line 715
    :goto_2ca
    invoke-interface {v3}, Ljava/util/Collection;->isEmpty()Z

    .line 716
    .line 717
    .line 718
    move-result v9

    .line 719
    if-nez v9, :cond_2f0

    .line 720
    .line 721
    invoke-virtual {v1, v3, v7}, Ldw0;->N(Ljava/util/List;Lik0;)Ljava/util/List;

    .line 722
    .line 723
    .line 724
    move-result-object v9

    .line 725
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 726
    .line 727
    .line 728
    invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 729
    .line 730
    .line 731
    move-result-object v9

    .line 732
    :goto_2db
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    .line 733
    .line 734
    .line 735
    move-result v10

    .line 736
    if-eqz v10, :cond_2e9

    .line 737
    .line 738
    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 739
    .line 740
    .line 741
    move-result-object v10

    .line 742
    invoke-virtual {v5, v10}, Lik0;->k(Ljava/lang/Object;)V

    .line 743
    .line 744
    .line 745
    goto :goto_2db

    .line 746
    :cond_2e9
    invoke-static {v3, v1}, Lcw0;->s(Ljava/util/List;Ldw0;)V
    :try_end_2ec
    .catchall {:try_start_2c7 .. :try_end_2ec} :catchall_2ed

    .line 747
    .line 748
    .line 749
    goto :goto_2ca

    .line 750
    :catchall_2ed
    move-exception v0

    .line 751
    const/4 v13, 0x0

    .line 752
    goto :goto_2f3

    .line 753
    :cond_2f0
    const/4 v12, 0x0

    .line 754
    goto/16 :goto_6f

    .line 755
    .line 756
    :goto_2f3
    :try_start_2f3
    invoke-virtual {v1, v0, v13}, Ldw0;->P(Ljava/lang/Throwable;Lyj;)V

    .line 757
    .line 758
    .line 759
    invoke-static/range {v1 .. v8}, Lcw0;->r(Ldw0;Ljava/util/List;Ljava/util/List;Ljava/util/List;Lik0;Lik0;Lik0;Lik0;)V

    .line 760
    .line 761
    .line 762
    goto/16 :goto_221

    .line 763
    .line 764
    :goto_2fb
    monitor-exit v9

    .line 765
    throw v0
    :try_end_2fd
    .catchall {:try_start_2f3 .. :try_end_2fd} :catchall_312

    .line 766
    :goto_2fd
    :try_start_2fd
    invoke-virtual {v1, v0, v13}, Ldw0;->P(Ljava/lang/Throwable;Lyj;)V

    .line 767
    .line 768
    .line 769
    invoke-static/range {v1 .. v8}, Lcw0;->r(Ldw0;Ljava/util/List;Ljava/util/List;Ljava/util/List;Lik0;Lik0;Lik0;Lik0;)V
    :try_end_303
    .catchall {:try_start_2fd .. :try_end_303} :catchall_30b

    .line 770
    .line 771
    .line 772
    :try_start_303
    invoke-interface {v2}, Ljava/util/List;->clear()V
    :try_end_306
    .catchall {:try_start_303 .. :try_end_306} :catchall_312

    .line 773
    .line 774
    .line 775
    goto/16 :goto_221

    .line 776
    .line 777
    :goto_308
    sget-object v0, Lwe1;->a:Lwe1;

    .line 778
    .line 779
    return-object v0

    .line 780
    :catchall_30b
    move-exception v0

    .line 781
    :try_start_30c
    invoke-interface {v2}, Ljava/util/List;->clear()V

    .line 782
    .line 783
    .line 784
    throw v0

    .line 785
    :goto_310
    monitor-exit v9

    .line 786
    throw v0
    :try_end_312
    .catchall {:try_start_30c .. :try_end_312} :catchall_312

    .line 787
    :catchall_312
    move-exception v0

    .line 788
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 789
    .line 790
    .line 791
    throw v0
.end method
