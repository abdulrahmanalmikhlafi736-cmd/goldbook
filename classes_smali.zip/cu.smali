.class public final Lcu;
.super Lh90;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Li00;


# instance fields
.field public final synthetic f:I

.field public final synthetic g:Lju;

.field public final synthetic h:Lwu;


# direct methods
.method public synthetic constructor <init>(Lju;Lwu;I)V
    .registers 4

    .line 1
    iput p3, p0, Lcu;->f:I

    .line 2
    .line 3
    iput-object p1, p0, Lcu;->g:Lju;

    .line 4
    .line 5
    iput-object p2, p0, Lcu;->h:Lwu;

    .line 6
    .line 7
    const/4 p1, 0x1

    .line 8
    invoke-direct {p0, p1}, Lh90;-><init>(I)V

    .line 9
    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final i(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 12

    .line 1
    iget v0, p0, Lcu;->f:I

    .line 2
    .line 3
    sget-object v1, Lzt;->g:Lzt;

    .line 4
    .line 5
    sget-object v2, Lzt;->f:Lzt;

    .line 6
    .line 7
    sget-object v3, Lzt;->e:Lzt;

    .line 8
    .line 9
    const/4 v4, 0x0

    .line 10
    const/4 v5, 0x2

    .line 11
    const/4 v6, 0x1

    .line 12
    const/high16 v7, 0x3f800000  # 1.0f

    .line 13
    .line 14
    const/4 v8, 0x0

    .line 15
    iget-object v9, p0, Lcu;->g:Lju;

    .line 16
    .line 17
    iget-object p0, p0, Lcu;->h:Lwu;

    .line 18
    .line 19
    packed-switch v0, :pswitch_data_b2

    .line 20
    .line 21
    .line 22
    check-cast p1, Lzt;

    .line 23
    .line 24
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 25
    .line 26
    .line 27
    move-result p1

    .line 28
    if-eqz p1, :cond_2d

    .line 29
    .line 30
    if-eq p1, v6, :cond_34

    .line 31
    .line 32
    if-ne p1, v5, :cond_29

    .line 33
    .line 34
    iget-object p0, p0, Lwu;->a:Lfd1;

    .line 35
    .line 36
    iget-object p0, p0, Lfd1;->c:Ll01;

    .line 37
    .line 38
    if-eqz p0, :cond_34

    .line 39
    .line 40
    :goto_27
    move v7, v8

    .line 41
    goto :goto_34

    .line 42
    :cond_29
    invoke-static {}, Lod;->k()V

    .line 43
    .line 44
    .line 45
    goto :goto_38

    .line 46
    :cond_2d
    iget-object p0, v9, Lju;->a:Lfd1;

    .line 47
    .line 48
    iget-object p0, p0, Lfd1;->c:Ll01;

    .line 49
    .line 50
    if-eqz p0, :cond_34

    .line 51
    .line 52
    goto :goto_27

    .line 53
    :cond_34
    :goto_34
    invoke-static {v7}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 54
    .line 55
    .line 56
    move-result-object v4

    .line 57
    :goto_38
    return-object v4

    .line 58
    :pswitch_39  #0x2
    check-cast p1, Lad1;

    .line 59
    .line 60
    invoke-virtual {p1, v3, v2}, Lad1;->a(Lzt;Lzt;)Z

    .line 61
    .line 62
    .line 63
    move-result v0

    .line 64
    if-eqz v0, :cond_4d

    .line 65
    .line 66
    iget-object p0, v9, Lju;->a:Lfd1;

    .line 67
    .line 68
    iget-object p0, p0, Lfd1;->c:Ll01;

    .line 69
    .line 70
    if-eqz p0, :cond_4a

    .line 71
    .line 72
    iget-object p0, p0, Ll01;->b:Lp71;

    .line 73
    .line 74
    goto :goto_61

    .line 75
    :cond_4a
    sget-object p0, Leu;->b:Lp71;

    .line 76
    .line 77
    goto :goto_61

    .line 78
    :cond_4d
    invoke-virtual {p1, v2, v1}, Lad1;->a(Lzt;Lzt;)Z

    .line 79
    .line 80
    .line 81
    move-result p1

    .line 82
    if-eqz p1, :cond_5f

    .line 83
    .line 84
    iget-object p0, p0, Lwu;->a:Lfd1;

    .line 85
    .line 86
    iget-object p0, p0, Lfd1;->c:Ll01;

    .line 87
    .line 88
    if-eqz p0, :cond_5c

    .line 89
    .line 90
    iget-object p0, p0, Ll01;->b:Lp71;

    .line 91
    .line 92
    goto :goto_61

    .line 93
    :cond_5c
    sget-object p0, Leu;->b:Lp71;

    .line 94
    .line 95
    goto :goto_61

    .line 96
    :cond_5f
    sget-object p0, Leu;->b:Lp71;

    .line 97
    .line 98
    :goto_61
    return-object p0

    .line 99
    :pswitch_62  #0x1
    check-cast p1, Lzt;

    .line 100
    .line 101
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 102
    .line 103
    .line 104
    move-result p1

    .line 105
    if-eqz p1, :cond_7a

    .line 106
    .line 107
    if-eq p1, v6, :cond_81

    .line 108
    .line 109
    if-ne p1, v5, :cond_76

    .line 110
    .line 111
    iget-object p0, p0, Lwu;->a:Lfd1;

    .line 112
    .line 113
    iget-object p0, p0, Lfd1;->a:Lcv;

    .line 114
    .line 115
    if-eqz p0, :cond_81

    .line 116
    .line 117
    :goto_74
    move v7, v8

    .line 118
    goto :goto_81

    .line 119
    :cond_76
    invoke-static {}, Lod;->k()V

    .line 120
    .line 121
    .line 122
    goto :goto_85

    .line 123
    :cond_7a
    iget-object p0, v9, Lju;->a:Lfd1;

    .line 124
    .line 125
    iget-object p0, p0, Lfd1;->a:Lcv;

    .line 126
    .line 127
    if-eqz p0, :cond_81

    .line 128
    .line 129
    goto :goto_74

    .line 130
    :cond_81
    :goto_81
    invoke-static {v7}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 131
    .line 132
    .line 133
    move-result-object v4

    .line 134
    :goto_85
    return-object v4

    .line 135
    :pswitch_86  #0x0
    check-cast p1, Lad1;

    .line 136
    .line 137
    invoke-virtual {p1, v3, v2}, Lad1;->a(Lzt;Lzt;)Z

    .line 138
    .line 139
    .line 140
    move-result v0

    .line 141
    if-eqz v0, :cond_9b

    .line 142
    .line 143
    iget-object p0, v9, Lju;->a:Lfd1;

    .line 144
    .line 145
    iget-object p0, p0, Lfd1;->a:Lcv;

    .line 146
    .line 147
    if-eqz p0, :cond_98

    .line 148
    .line 149
    iget-object p0, p0, Lcv;->a:Lyv;

    .line 150
    .line 151
    if-nez p0, :cond_b0

    .line 152
    .line 153
    :cond_98
    sget-object p0, Leu;->b:Lp71;

    .line 154
    .line 155
    goto :goto_b0

    .line 156
    :cond_9b
    invoke-virtual {p1, v2, v1}, Lad1;->a(Lzt;Lzt;)Z

    .line 157
    .line 158
    .line 159
    move-result p1

    .line 160
    if-eqz p1, :cond_ae

    .line 161
    .line 162
    iget-object p0, p0, Lwu;->a:Lfd1;

    .line 163
    .line 164
    iget-object p0, p0, Lfd1;->a:Lcv;

    .line 165
    .line 166
    if-eqz p0, :cond_ab

    .line 167
    .line 168
    iget-object p0, p0, Lcv;->a:Lyv;

    .line 169
    .line 170
    if-nez p0, :cond_b0

    .line 171
    .line 172
    :cond_ab
    sget-object p0, Leu;->b:Lp71;

    .line 173
    .line 174
    goto :goto_b0

    .line 175
    :cond_ae
    sget-object p0, Leu;->b:Lp71;

    .line 176
    .line 177
    :cond_b0
    :goto_b0
    return-object p0

    .line 178
    nop

    .line 179
    :pswitch_data_b2
    .packed-switch 0x0
        :pswitch_86  #00000000
        :pswitch_62  #00000001
        :pswitch_39  #00000002
    .end packed-switch
.end method
