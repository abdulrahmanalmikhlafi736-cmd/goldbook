.class public final Lbj0;
.super Lnl;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# instance fields
.field public h:Ly11;

.field public i:Lkw0;

.field public j:F

.field public synthetic k:Ljava/lang/Object;

.field public final synthetic l:Ltp;

.field public m:I


# direct methods
.method public constructor <init>(Ltp;Lnl;)V
    .registers 3

    .line 1
    iput-object p1, p0, Lbj0;->l:Ltp;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Lnl;-><init>(Lml;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final p(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 8

    .line 1
    iput-object p1, p0, Lbj0;->k:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, Lbj0;->m:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, Lbj0;->m:I

    .line 9
    .line 10
    const/4 v3, 0x0

    .line 11
    const/4 v4, 0x0

    .line 12
    iget-object v0, p0, Lbj0;->l:Ltp;

    .line 13
    .line 14
    const/4 v1, 0x0

    .line 15
    const/4 v2, 0x0

    .line 16
    move-object v5, p0

    .line 17
    invoke-static/range {v0 .. v5}, Ltp;->a(Ltp;Ly11;Laj0;FFLnl;)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object p0

    .line 21
    return-object p0
.end method
