.class public final Lax0;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lbm;
.implements Lww0;


# static fields
.field public static final h:Lqe;


# instance fields
.field public final e:Lsl;

.field public final f:Lax0;

.field public volatile g:Lsl;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Lqe;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Lqe;-><init>(I)V

    .line 5
    .line 6
    .line 7
    sput-object v0, Lax0;->h:Lqe;

    .line 8
    .line 9
    return-void
.end method

.method public constructor <init>(Lsl;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lax0;->e:Lsl;

    .line 5
    .line 6
    iput-object p0, p0, Lax0;->f:Lax0;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final a()V
    .registers 4

    .line 1
    iget-object v0, p0, Lax0;->f:Lax0;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    :try_start_3
    iget-object v1, p0, Lax0;->g:Lsl;

    .line 5
    .line 6
    if-nez v1, :cond_e

    .line 7
    .line 8
    sget-object v1, Lax0;->h:Lqe;

    .line 9
    .line 10
    iput-object v1, p0, Lax0;->g:Lsl;

    .line 11
    .line 12
    goto :goto_21

    .line 13
    :catchall_c
    move-exception p0

    .line 14
    goto :goto_23

    .line 15
    :cond_e
    new-instance p0, Luz;

    .line 16
    .line 17
    const/4 v2, 0x0

    .line 18
    invoke-direct {p0, v2}, Luz;-><init>(I)V

    .line 19
    .line 20
    .line 21
    sget-object v2, Le3;->S:Le3;

    .line 22
    .line 23
    invoke-interface {v1, v2}, Lsl;->k(Lrl;)Lql;

    .line 24
    .line 25
    .line 26
    move-result-object v1

    .line 27
    check-cast v1, La80;

    .line 28
    .line 29
    if-eqz v1, :cond_21

    .line 30
    .line 31
    invoke-interface {v1, p0}, La80;->a(Ljava/util/concurrent/CancellationException;)V
    :try_end_21
    .catchall {:try_start_3 .. :try_end_21} :catchall_c

    .line 32
    .line 33
    .line 34
    :cond_21
    :goto_21
    monitor-exit v0

    .line 35
    return-void

    .line 36
    :goto_23
    monitor-exit v0

    .line 37
    throw p0
.end method

.method public final c()V
    .registers 1

    .line 1
    return-void
.end method

.method public final d()V
    .registers 1

    .line 1
    invoke-virtual {p0}, Lax0;->a()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public final e()V
    .registers 1

    .line 1
    invoke-virtual {p0}, Lax0;->a()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public final f()Lsl;
    .registers 7

    .line 1
    iget-object v0, p0, Lax0;->g:Lsl;

    .line 2
    .line 3
    if-eqz v0, :cond_8

    .line 4
    .line 5
    sget-object v1, Lax0;->h:Lqe;

    .line 6
    .line 7
    if-ne v0, v1, :cond_73

    .line 8
    .line 9
    :cond_8
    iget-object v0, p0, Lax0;->e:Lsl;

    .line 10
    .line 11
    sget-object v1, Lwj;->f:Lvj;

    .line 12
    .line 13
    invoke-interface {v0, v1}, Lsl;->k(Lrl;)Lql;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    check-cast v0, Lwj;

    .line 18
    .line 19
    if-eqz v0, :cond_1a

    .line 20
    .line 21
    new-instance v1, Lzw0;

    .line 22
    .line 23
    invoke-direct {v1, v0, p0}, Lzw0;-><init>(Lwj;Lax0;)V

    .line 24
    .line 25
    .line 26
    goto :goto_1c

    .line 27
    :cond_1a
    sget-object v1, Lst;->e:Lst;

    .line 28
    .line 29
    :goto_1c
    iget-object v0, p0, Lax0;->f:Lax0;

    .line 30
    .line 31
    monitor-enter v0

    .line 32
    :try_start_1f
    iget-object v2, p0, Lax0;->g:Lsl;

    .line 33
    .line 34
    if-nez v2, :cond_43

    .line 35
    .line 36
    iget-object v2, p0, Lax0;->e:Lsl;

    .line 37
    .line 38
    sget-object v3, Le3;->S:Le3;

    .line 39
    .line 40
    invoke-interface {v2, v3}, Lsl;->k(Lrl;)Lql;

    .line 41
    .line 42
    .line 43
    move-result-object v3

    .line 44
    check-cast v3, La80;

    .line 45
    .line 46
    new-instance v4, Lc80;

    .line 47
    .line 48
    invoke-direct {v4, v3}, Lc80;-><init>(La80;)V

    .line 49
    .line 50
    .line 51
    invoke-interface {v2, v4}, Lsl;->i(Lsl;)Lsl;

    .line 52
    .line 53
    .line 54
    move-result-object v2

    .line 55
    sget-object v3, Lst;->e:Lst;

    .line 56
    .line 57
    invoke-interface {v2, v3}, Lsl;->i(Lsl;)Lsl;

    .line 58
    .line 59
    .line 60
    move-result-object v2

    .line 61
    invoke-interface {v2, v1}, Lsl;->i(Lsl;)Lsl;

    .line 62
    .line 63
    .line 64
    move-result-object v1

    .line 65
    goto :goto_6f

    .line 66
    :catchall_41
    move-exception p0

    .line 67
    goto :goto_77

    .line 68
    :cond_43
    sget-object v3, Lax0;->h:Lqe;

    .line 69
    .line 70
    if-ne v2, v3, :cond_6e

    .line 71
    .line 72
    iget-object v2, p0, Lax0;->e:Lsl;

    .line 73
    .line 74
    sget-object v3, Le3;->S:Le3;

    .line 75
    .line 76
    invoke-interface {v2, v3}, Lsl;->k(Lrl;)Lql;

    .line 77
    .line 78
    .line 79
    move-result-object v3

    .line 80
    check-cast v3, La80;

    .line 81
    .line 82
    new-instance v4, Lc80;

    .line 83
    .line 84
    invoke-direct {v4, v3}, Lc80;-><init>(La80;)V

    .line 85
    .line 86
    .line 87
    new-instance v3, Luz;

    .line 88
    .line 89
    const/4 v5, 0x0

    .line 90
    invoke-direct {v3, v5}, Luz;-><init>(I)V

    .line 91
    .line 92
    .line 93
    invoke-virtual {v4, v3}, Lh80;->A(Ljava/lang/Object;)Z

    .line 94
    .line 95
    .line 96
    invoke-interface {v2, v4}, Lsl;->i(Lsl;)Lsl;

    .line 97
    .line 98
    .line 99
    move-result-object v2

    .line 100
    sget-object v3, Lst;->e:Lst;

    .line 101
    .line 102
    invoke-interface {v2, v3}, Lsl;->i(Lsl;)Lsl;

    .line 103
    .line 104
    .line 105
    move-result-object v2

    .line 106
    invoke-interface {v2, v1}, Lsl;->i(Lsl;)Lsl;

    .line 107
    .line 108
    .line 109
    move-result-object v1

    .line 110
    goto :goto_6f

    .line 111
    :cond_6e
    move-object v1, v2

    .line 112
    :goto_6f
    iput-object v1, p0, Lax0;->g:Lsl;
    :try_end_71
    .catchall {:try_start_1f .. :try_end_71} :catchall_41

    .line 113
    .line 114
    monitor-exit v0

    .line 115
    move-object v0, v1

    .line 116
    :cond_73
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 117
    .line 118
    .line 119
    return-object v0

    .line 120
    :goto_77
    monitor-exit v0

    .line 121
    throw p0
.end method
