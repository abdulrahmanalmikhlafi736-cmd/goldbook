.class public final Lbn0;
.super Lhl0;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# instance fields
.field public final c:Landroid/window/OnBackInvokedDispatcher;

.field public final d:I

.field public final e:Landroid/window/OnBackInvokedCallback;

.field public f:Z


# direct methods
.method public constructor <init>(Landroid/window/OnBackInvokedDispatcher;I)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lbn0;->c:Landroid/window/OnBackInvokedDispatcher;

    .line 5
    .line 6
    iput p2, p0, Lbn0;->d:I

    .line 7
    .line 8
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 9
    .line 10
    const/16 p2, 0x21

    .line 11
    .line 12
    if-ne p1, p2, :cond_13

    .line 13
    .line 14
    new-instance p1, Lcn0;

    .line 15
    .line 16
    invoke-direct {p1, p0}, Lcn0;-><init>(Lbn0;)V

    .line 17
    .line 18
    .line 19
    goto :goto_18

    .line 20
    :cond_13
    new-instance p1, Ldn0;

    .line 21
    .line 22
    invoke-direct {p1, p0}, Ldn0;-><init>(Lbn0;)V

    .line 23
    .line 24
    .line 25
    :goto_18
    iput-object p1, p0, Lbn0;->e:Landroid/window/OnBackInvokedCallback;

    .line 26
    .line 27
    return-void
.end method


# virtual methods
.method public final b(Z)V
    .registers 4

    .line 1
    iget-object v0, p0, Lbn0;->e:Landroid/window/OnBackInvokedCallback;

    .line 2
    .line 3
    if-eqz p1, :cond_13

    .line 4
    .line 5
    iget-boolean v1, p0, Lbn0;->f:Z

    .line 6
    .line 7
    if-nez v1, :cond_13

    .line 8
    .line 9
    iget-object p1, p0, Lbn0;->c:Landroid/window/OnBackInvokedDispatcher;

    .line 10
    .line 11
    iget v1, p0, Lbn0;->d:I

    .line 12
    .line 13
    invoke-static {p1, v1, v0}, Le1;->k(Landroid/window/OnBackInvokedDispatcher;ILandroid/window/OnBackInvokedCallback;)V

    .line 14
    .line 15
    .line 16
    const/4 p1, 0x1

    .line 17
    iput-boolean p1, p0, Lbn0;->f:Z

    .line 18
    .line 19
    return-void

    .line 20
    :cond_13
    if-nez p1, :cond_21

    .line 21
    .line 22
    iget-boolean p1, p0, Lbn0;->f:Z

    .line 23
    .line 24
    if-eqz p1, :cond_21

    .line 25
    .line 26
    iget-object p1, p0, Lbn0;->c:Landroid/window/OnBackInvokedDispatcher;

    .line 27
    .line 28
    invoke-static {p1, v0}, Le1;->l(Landroid/window/OnBackInvokedDispatcher;Landroid/window/OnBackInvokedCallback;)V

    .line 29
    .line 30
    .line 31
    const/4 p1, 0x0

    .line 32
    iput-boolean p1, p0, Lbn0;->f:Z

    .line 33
    .line 34
    :cond_21
    return-void
.end method
