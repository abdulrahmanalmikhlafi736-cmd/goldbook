.class public final Lad0;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Ltf1;


# instance fields
.field public final a:Lda1;


# direct methods
.method public constructor <init>(Lxz;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    invoke-static {p1}, Lwa0;->s(Lxz;)Lda1;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    iput-object p1, p0, Lad0;->a:Lda1;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final a(Lqr0;)Ljava/lang/Object;
    .registers 2

    .line 1
    iget-object p0, p0, Lad0;->a:Lda1;

    .line 2
    .line 3
    invoke-virtual {p0}, Lda1;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    return-object p0
.end method
