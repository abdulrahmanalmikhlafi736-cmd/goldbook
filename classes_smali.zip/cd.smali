.class public final Lcd;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Li00;


# instance fields
.field public final synthetic e:I

.field public f:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>()V
    .registers 2

    .line 9
    const/4 v0, 0x2

    iput v0, p0, Lcd;->e:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    .line 1
    iput p1, p0, Lcd;->e:I

    .line 2
    .line 3
    iput-object p2, p0, Lcd;->f:Ljava/lang/Object;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final i(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 7

    .line 1
    iget v0, p0, Lcd;->e:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_4c

    .line 4
    .line 5
    .line 6
    check-cast p1, Ljava/lang/Number;

    .line 7
    .line 8
    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    .line 9
    .line 10
    .line 11
    move-result p1

    .line 12
    iget-object p0, p0, Lcd;->f:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast p0, Ljava/util/List;

    .line 15
    .line 16
    invoke-interface {p0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    const/4 p0, 0x0

    .line 20
    return-object p0

    .line 21
    :pswitch_14  #0x2
    check-cast p1, Ljava/lang/Boolean;

    .line 22
    .line 23
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 24
    .line 25
    .line 26
    move-result p1

    .line 27
    iget-object p0, p0, Lcd;->f:Ljava/lang/Object;

    .line 28
    .line 29
    check-cast p0, Ljt0;

    .line 30
    .line 31
    if-eqz p0, :cond_22

    .line 32
    .line 33
    iput-boolean p1, p0, Ljt0;->c:Z

    .line 34
    .line 35
    :cond_22
    sget-object p0, Lwe1;->a:Lwe1;

    .line 36
    .line 37
    return-object p0

    .line 38
    :pswitch_25  #0x1
    check-cast p1, Ll61;

    .line 39
    .line 40
    sget-object v0, Ln61;->c:Ljava/lang/Object;

    .line 41
    .line 42
    monitor-enter v0

    .line 43
    :try_start_2a
    sget-wide v1, Ln61;->e:J

    .line 44
    .line 45
    const-wide/16 v3, 0x1

    .line 46
    .line 47
    add-long/2addr v3, v1

    .line 48
    sput-wide v3, Ln61;->e:J
    :try_end_31
    .catchall {:try_start_2a .. :try_end_31} :catchall_3c

    .line 49
    .line 50
    monitor-exit v0

    .line 51
    iget-object p0, p0, Lcd;->f:Ljava/lang/Object;

    .line 52
    .line 53
    check-cast p0, Li00;

    .line 54
    .line 55
    new-instance v0, Luv0;

    .line 56
    .line 57
    invoke-direct {v0, v1, v2, p1, p0}, Luv0;-><init>(JLl61;Li00;)V

    .line 58
    .line 59
    .line 60
    return-object v0

    .line 61
    :catchall_3c
    move-exception p0

    .line 62
    monitor-exit v0

    .line 63
    throw p0

    .line 64
    :pswitch_3f  #0x0
    check-cast p1, Ljava/lang/Throwable;

    .line 65
    .line 66
    iget-object p0, p0, Lcd;->f:Ljava/lang/Object;

    .line 67
    .line 68
    check-cast p0, Loe;

    .line 69
    .line 70
    invoke-interface {p0}, Loe;->cancel()V

    .line 71
    .line 72
    .line 73
    sget-object p0, Lwe1;->a:Lwe1;

    .line 74
    .line 75
    return-object p0

    .line 76
    nop

    .line 77
    :pswitch_data_4c
    .packed-switch 0x0
        :pswitch_3f  #00000000
        :pswitch_25  #00000001
        :pswitch_14  #00000002
    .end packed-switch
.end method
