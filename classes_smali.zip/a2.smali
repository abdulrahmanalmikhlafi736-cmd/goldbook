.class public final synthetic La2;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Li00;


# instance fields
.field public final synthetic e:I

.field public final synthetic f:Li00;


# direct methods
.method public synthetic constructor <init>(Li00;I)V
    .registers 3

    .line 1
    iput p2, p0, La2;->e:I

    .line 2
    .line 3
    iput-object p1, p0, La2;->f:Li00;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final i(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 1
    iget v0, p0, La2;->e:I

    .line 2
    .line 3
    iget-object p0, p0, La2;->f:Li00;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_64

    .line 6
    .line 7
    .line 8
    check-cast p1, Landroid/content/Context;

    .line 9
    .line 10
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    .line 12
    .line 13
    new-instance v0, Ldi1;

    .line 14
    .line 15
    invoke-direct {v0, p1}, Ldi1;-><init>(Landroid/content/Context;)V

    .line 16
    .line 17
    .line 18
    invoke-interface {p0, v0}, Li00;->i(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    check-cast p0, Landroid/webkit/WebView;

    .line 23
    .line 24
    return-object p0

    .line 25
    :pswitch_18  #0x3
    check-cast p1, Ljava/lang/Long;

    .line 26
    .line 27
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 28
    .line 29
    .line 30
    invoke-interface {p0, p1}, Li00;->i(Ljava/lang/Object;)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object p0

    .line 34
    return-object p0

    .line 35
    :pswitch_22  #0x2
    check-cast p1, Ll61;

    .line 36
    .line 37
    invoke-interface {p0, p1}, Li00;->i(Ljava/lang/Object;)Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    move-result-object p0

    .line 41
    check-cast p0, Lg61;

    .line 42
    .line 43
    sget-object p1, Ln61;->c:Ljava/lang/Object;

    .line 44
    .line 45
    monitor-enter p1

    .line 46
    :try_start_2d
    sget-object v0, Ln61;->d:Ll61;

    .line 47
    .line 48
    invoke-virtual {p0}, Lg61;->g()J

    .line 49
    .line 50
    .line 51
    move-result-wide v1

    .line 52
    invoke-virtual {v0, v1, v2}, Ll61;->f(J)Ll61;

    .line 53
    .line 54
    .line 55
    move-result-object v0

    .line 56
    sput-object v0, Ln61;->d:Ll61;
    :try_end_39
    .catchall {:try_start_2d .. :try_end_39} :catchall_3b

    .line 57
    .line 58
    monitor-exit p1

    .line 59
    return-object p0

    .line 60
    :catchall_3b
    move-exception p0

    .line 61
    monitor-exit p1

    .line 62
    throw p0

    .line 63
    :pswitch_3e  #0x1
    check-cast p1, Lkd1;

    .line 64
    .line 65
    instance-of v0, p1, Lp10;

    .line 66
    .line 67
    if-eqz v0, :cond_52

    .line 68
    .line 69
    check-cast p1, Lp10;

    .line 70
    .line 71
    iget-object p1, p1, Lp10;->s:Lo10;

    .line 72
    .line 73
    invoke-interface {p0, p1}, Li00;->i(Ljava/lang/Object;)Ljava/lang/Object;

    .line 74
    .line 75
    .line 76
    move-result-object p0

    .line 77
    check-cast p0, Ljava/lang/Boolean;

    .line 78
    .line 79
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 80
    .line 81
    .line 82
    goto :goto_58

    .line 83
    :cond_52
    const-string p0, "Node is not a GestureNode instance"

    .line 84
    .line 85
    invoke-static {p0}, Lod;->p(Ljava/lang/String;)V

    .line 86
    .line 87
    .line 88
    const/4 p0, 0x0

    .line 89
    :goto_58
    return-object p0

    .line 90
    :pswitch_59  #0x0
    check-cast p1, Landroid/webkit/WebView;

    .line 91
    .line 92
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 93
    .line 94
    .line 95
    invoke-interface {p0, p1}, Li00;->i(Ljava/lang/Object;)Ljava/lang/Object;

    .line 96
    .line 97
    .line 98
    sget-object p0, Lwe1;->a:Lwe1;

    .line 99
    .line 100
    return-object p0

    .line 101
    :pswitch_data_64
    .packed-switch 0x0
        :pswitch_59  #00000000
        :pswitch_3e  #00000001
        :pswitch_22  #00000002
        :pswitch_18  #00000003
    .end packed-switch
.end method
