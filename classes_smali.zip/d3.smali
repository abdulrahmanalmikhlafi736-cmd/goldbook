.class public abstract Ld3;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# static fields
.field public static final a:Lup0;

.field public static final b:Lup0;

.field public static final c:Lup0;

.field public static final d:Lgk;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Lup0;

    .line 2
    .line 3
    const/high16 v1, 0x41c00000  # 24.0f

    .line 4
    .line 5
    invoke-direct {v0, v1, v1, v1, v1}, Lup0;-><init>(FFFF)V

    .line 6
    .line 7
    .line 8
    sput-object v0, Ld3;->a:Lup0;

    .line 9
    .line 10
    const/high16 v0, 0x41800000  # 16.0f

    .line 11
    .line 12
    invoke-static {v0}, Lac;->f(F)Lup0;

    .line 13
    .line 14
    .line 15
    invoke-static {v0}, Lac;->f(F)Lup0;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    sput-object v0, Ld3;->b:Lup0;

    .line 20
    .line 21
    invoke-static {v1}, Lac;->f(F)Lup0;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    sput-object v0, Ld3;->c:Lup0;

    .line 26
    .line 27
    new-instance v0, Li2;

    .line 28
    .line 29
    const/4 v1, 0x2

    .line 30
    invoke-direct {v0, v1}, Li2;-><init>(I)V

    .line 31
    .line 32
    .line 33
    new-instance v1, Lgk;

    .line 34
    .line 35
    invoke-direct {v1, v0}, Lgk;-><init>(Lxz;)V

    .line 36
    .line 37
    .line 38
    sput-object v1, Ld3;->d:Lgk;

    .line 39
    .line 40
    return-void
.end method

.method public static final a(Lpi;Lmi0;Lm00;Lm00;Ly41;JJJJJLd10;I)V
    .registers 38

    move-object/from16 v7, p15

    const v0, 0x522d8af1

    .line 1
    invoke-virtual {v7, v0}, Ld10;->X(I)Ld10;

    or-int/lit8 v0, p16, 0x30

    const/4 v1, 0x0

    invoke-virtual {v7, v1}, Ld10;->h(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_14

    const/16 v1, 0x100

    goto :goto_16

    :cond_14
    const/16 v1, 0x80

    :goto_16
    or-int/2addr v0, v1

    move-object/from16 v4, p2

    invoke-virtual {v7, v4}, Ld10;->h(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_22

    const/16 v1, 0x800

    goto :goto_24

    :cond_22
    const/16 v1, 0x400

    :goto_24
    or-int/2addr v0, v1

    move-object/from16 v5, p3

    invoke-virtual {v7, v5}, Ld10;->h(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_30

    const/16 v1, 0x4000

    goto :goto_32

    :cond_30
    const/16 v1, 0x2000

    :goto_32
    or-int/2addr v0, v1

    move-object/from16 v1, p4

    invoke-virtual {v7, v1}, Ld10;->f(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_3e

    const/high16 v2, 0x20000

    goto :goto_40

    :cond_3e
    const/high16 v2, 0x10000

    :goto_40
    or-int/2addr v0, v2

    move-wide/from16 v2, p5

    invoke-virtual {v7, v2, v3}, Ld10;->e(J)Z

    move-result v6

    if-eqz v6, :cond_4c

    const/high16 v6, 0x100000

    goto :goto_4e

    :cond_4c
    const/high16 v6, 0x80000

    :goto_4e
    or-int/2addr v0, v6

    const/4 v6, 0x0

    invoke-virtual {v7, v6}, Ld10;->c(F)Z

    move-result v6

    if-eqz v6, :cond_59

    const/high16 v6, 0x800000

    goto :goto_5b

    :cond_59
    const/high16 v6, 0x400000

    :goto_5b
    or-int/2addr v0, v6

    move-wide/from16 v9, p7

    invoke-virtual {v7, v9, v10}, Ld10;->e(J)Z

    move-result v6

    if-eqz v6, :cond_67

    const/high16 v6, 0x4000000

    goto :goto_69

    :cond_67
    const/high16 v6, 0x2000000

    :goto_69
    or-int/2addr v0, v6

    move-wide/from16 v11, p9

    invoke-virtual {v7, v11, v12}, Ld10;->e(J)Z

    move-result v6

    if-eqz v6, :cond_75

    const/high16 v6, 0x20000000

    goto :goto_77

    :cond_75
    const/high16 v6, 0x10000000

    :goto_77
    or-int/2addr v0, v6

    move-wide/from16 v13, p11

    invoke-virtual {v7, v13, v14}, Ld10;->e(J)Z

    move-result v6

    if-eqz v6, :cond_86

    const/4 v6, 0x4

    :goto_81
    move/from16 v20, v0

    move-wide/from16 v0, p13

    goto :goto_88

    :cond_86
    const/4 v6, 0x2

    goto :goto_81

    :goto_88
    invoke-virtual {v7, v0, v1}, Ld10;->e(J)Z

    move-result v8

    if-eqz v8, :cond_91

    const/16 v8, 0x20

    goto :goto_93

    :cond_91
    const/16 v8, 0x10

    :goto_93
    or-int/2addr v6, v8

    const v8, 0x12492493

    and-int v8, v20, v8

    const v15, 0x12492492

    if-ne v8, v15, :cond_a7

    and-int/lit8 v6, v6, 0x13

    const/16 v8, 0x12

    if-eq v6, v8, :cond_a5

    goto :goto_a7

    :cond_a5
    const/4 v6, 0x0

    goto :goto_a8

    :cond_a7
    :goto_a7
    const/4 v6, 0x1

    :goto_a8
    and-int/lit8 v8, v20, 0x1

    invoke-virtual {v7, v8, v6}, Ld10;->O(IZ)Z

    move-result v6

    if-eqz v6, :cond_e3

    .line 2
    new-instance v8, La3;

    move-object/from16 v19, p0

    move-wide v15, v0

    move-wide/from16 v17, v9

    move-object v9, v4

    move-object v10, v5

    invoke-direct/range {v8 .. v19}, La3;-><init>(Lm00;Lm00;JJJJLpi;)V

    const v0, -0x26e8eb4a

    invoke-static {v0, v8, v7}, Lvd1;->A(ILu00;Ld10;)Lpi;

    move-result-object v6

    shr-int/lit8 v0, v20, 0xc

    and-int/lit8 v1, v0, 0x70

    const v4, 0xc00006

    or-int/2addr v1, v4

    and-int/lit16 v0, v0, 0x380

    or-int/2addr v0, v1

    shr-int/lit8 v1, v20, 0x9

    const v4, 0xe000

    and-int/2addr v1, v4

    or-int v8, v0, v1

    const/16 v9, 0x68

    .line 3
    sget-object v0, Lji0;->a:Lji0;

    const-wide/16 v4, 0x0

    move-object/from16 v1, p4

    invoke-static/range {v0 .. v9}, Lp91;->a(Lmi0;Ly41;JJLpi;Ld10;II)V

    move-object v3, v0

    goto :goto_e8

    .line 4
    :cond_e3
    invoke-virtual/range {p15 .. p15}, Ld10;->R()V

    move-object/from16 v3, p1

    .line 5
    :goto_e8
    invoke-virtual/range {p15 .. p15}, Ld10;->r()Lxv0;

    move-result-object v0

    if-eqz v0, :cond_109

    new-instance v1, Lb3;

    move-object/from16 v2, p0

    move-object/from16 v4, p2

    move-object/from16 v5, p3

    move-object/from16 v6, p4

    move-wide/from16 v7, p5

    move-wide/from16 v9, p7

    move-wide/from16 v11, p9

    move-wide/from16 v13, p11

    move-wide/from16 v15, p13

    move/from16 v17, p16

    invoke-direct/range {v1 .. v17}, Lb3;-><init>(Lpi;Lmi0;Lm00;Lm00;Ly41;JJJJJI)V

    .line 6
    iput-object v1, v0, Lxv0;->d:Lm00;

    :cond_109
    return-void
.end method

.method public static final b(FLpi;Ld10;I)V
    .registers 8

    .line 1
    const v0, -0x36b20a24  # -843613.75f

    .line 2
    .line 3
    .line 4
    invoke-virtual {p2, v0}, Ld10;->X(I)Ld10;

    .line 5
    .line 6
    .line 7
    invoke-virtual {p2, p0}, Ld10;->c(F)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_f

    .line 12
    .line 13
    const/16 v0, 0x20

    .line 14
    .line 15
    goto :goto_11

    .line 16
    :cond_f
    const/16 v0, 0x10

    .line 17
    .line 18
    :goto_11
    or-int/2addr v0, p3

    .line 19
    and-int/lit16 v1, v0, 0x93

    .line 20
    .line 21
    const/16 v2, 0x92

    .line 22
    .line 23
    const/4 v3, 0x1

    .line 24
    if-eq v1, v2, :cond_1b

    .line 25
    .line 26
    move v1, v3

    .line 27
    goto :goto_1c

    .line 28
    :cond_1b
    const/4 v1, 0x0

    .line 29
    :goto_1c
    and-int/2addr v0, v3

    .line 30
    invoke-virtual {p2, v0, v1}, Ld10;->O(IZ)Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    if-eqz v0, :cond_52

    .line 35
    .line 36
    sget-object v0, Lfk;->n:Lk81;

    .line 37
    .line 38
    invoke-virtual {p2, v0}, Ld10;->j(Llv0;)Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object v1

    .line 42
    check-cast v1, Lo90;

    .line 43
    .line 44
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 45
    .line 46
    .line 47
    move-result v2

    .line 48
    if-eqz v2, :cond_3a

    .line 49
    .line 50
    if-ne v2, v3, :cond_36

    .line 51
    .line 52
    sget-object v2, Lo90;->e:Lo90;

    .line 53
    .line 54
    goto :goto_3c

    .line 55
    :cond_36
    invoke-static {}, Lod;->k()V

    .line 56
    .line 57
    .line 58
    return-void

    .line 59
    :cond_3a
    sget-object v2, Lo90;->f:Lo90;

    .line 60
    .line 61
    :goto_3c
    invoke-virtual {v0, v2}, Lk81;->a(Ljava/lang/Object;)Lnv0;

    .line 62
    .line 63
    .line 64
    move-result-object v0

    .line 65
    new-instance v2, Lu2;

    .line 66
    .line 67
    invoke-direct {v2, p0, v1, p1}, Lu2;-><init>(FLo90;Lpi;)V

    .line 68
    .line 69
    .line 70
    const v1, -0x766616e4

    .line 71
    .line 72
    .line 73
    invoke-static {v1, v2, p2}, Lvd1;->A(ILu00;Ld10;)Lpi;

    .line 74
    .line 75
    .line 76
    move-result-object v1

    .line 77
    const/16 v2, 0x38

    .line 78
    .line 79
    invoke-static {v0, v1, p2, v2}, Lk70;->c(Lnv0;Lm00;Ld10;I)V

    .line 80
    .line 81
    .line 82
    goto :goto_55

    .line 83
    :cond_52
    invoke-virtual {p2}, Ld10;->R()V

    .line 84
    .line 85
    .line 86
    :goto_55
    invoke-virtual {p2}, Ld10;->r()Lxv0;

    .line 87
    .line 88
    .line 89
    move-result-object p2

    .line 90
    if-eqz p2, :cond_62

    .line 91
    .line 92
    new-instance v0, Lv2;

    .line 93
    .line 94
    invoke-direct {v0, p0, p1, p3}, Lv2;-><init>(FLpi;I)V

    .line 95
    .line 96
    .line 97
    iput-object v0, p2, Lxv0;->d:Lm00;

    .line 98
    .line 99
    :cond_62
    return-void
.end method

.method public static final c(Lxz;Lpi;Lmi0;Lm00;Lm00;Lm00;Ly41;JJJJLyp;Ld10;II)V
    .registers 45

    move-object/from16 v4, p16

    move/from16 v6, p17

    move/from16 v7, p18

    const v0, -0x33b6c663  # -5.274994E7f

    .line 1
    invoke-virtual {v4, v0}, Ld10;->X(I)Ld10;

    and-int/lit8 v0, v6, 0x6

    if-nez v0, :cond_1d

    move-object/from16 v0, p0

    invoke-virtual {v4, v0}, Ld10;->h(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1a

    const/4 v3, 0x4

    goto :goto_1b

    :cond_1a
    const/4 v3, 0x2

    :goto_1b
    or-int/2addr v3, v6

    goto :goto_20

    :cond_1d
    move-object/from16 v0, p0

    move v3, v6

    :goto_20
    and-int/lit8 v5, v6, 0x30

    if-nez v5, :cond_33

    move-object/from16 v5, p1

    invoke-virtual {v4, v5}, Ld10;->h(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_2f

    const/16 v10, 0x20

    goto :goto_31

    :cond_2f
    const/16 v10, 0x10

    :goto_31
    or-int/2addr v3, v10

    goto :goto_35

    :cond_33
    move-object/from16 v5, p1

    :goto_35
    and-int/lit16 v10, v6, 0x180

    if-nez v10, :cond_48

    move-object/from16 v10, p2

    invoke-virtual {v4, v10}, Ld10;->f(Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_44

    const/16 v13, 0x100

    goto :goto_46

    :cond_44
    const/16 v13, 0x80

    :goto_46
    or-int/2addr v3, v13

    goto :goto_4a

    :cond_48
    move-object/from16 v10, p2

    :goto_4a
    and-int/lit16 v13, v6, 0xc00

    if-nez v13, :cond_5e

    move-object/from16 v13, p3

    invoke-virtual {v4, v13}, Ld10;->h(Ljava/lang/Object;)Z

    move-result v16

    if-eqz v16, :cond_59

    const/16 v16, 0x800

    goto :goto_5b

    :cond_59
    const/16 v16, 0x400

    :goto_5b
    or-int v3, v3, v16

    goto :goto_60

    :cond_5e
    move-object/from16 v13, p3

    :goto_60
    and-int/lit16 v1, v6, 0x6000

    if-nez v1, :cond_71

    const/4 v1, 0x0

    invoke-virtual {v4, v1}, Ld10;->h(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_6e

    const/16 v1, 0x4000

    goto :goto_70

    :cond_6e
    const/16 v1, 0x2000

    :goto_70
    or-int/2addr v3, v1

    :cond_71
    const/high16 v1, 0x30000

    and-int/2addr v1, v6

    if-nez v1, :cond_86

    move-object/from16 v1, p4

    invoke-virtual {v4, v1}, Ld10;->h(Ljava/lang/Object;)Z

    move-result v17

    if-eqz v17, :cond_81

    const/high16 v17, 0x20000

    goto :goto_83

    :cond_81
    const/high16 v17, 0x10000

    :goto_83
    or-int v3, v3, v17

    goto :goto_88

    :cond_86
    move-object/from16 v1, p4

    :goto_88
    const/high16 v17, 0x180000

    and-int v17, v6, v17

    move-object/from16 v2, p5

    if-nez v17, :cond_9d

    invoke-virtual {v4, v2}, Ld10;->h(Ljava/lang/Object;)Z

    move-result v18

    if-eqz v18, :cond_99

    const/high16 v18, 0x100000

    goto :goto_9b

    :cond_99
    const/high16 v18, 0x80000

    :goto_9b
    or-int v3, v3, v18

    :cond_9d
    const/high16 v18, 0xc00000

    and-int v18, v6, v18

    move-object/from16 v8, p6

    if-nez v18, :cond_b2

    invoke-virtual {v4, v8}, Ld10;->f(Ljava/lang/Object;)Z

    move-result v19

    if-eqz v19, :cond_ae

    const/high16 v19, 0x800000

    goto :goto_b0

    :cond_ae
    const/high16 v19, 0x400000

    :goto_b0
    or-int v3, v3, v19

    :cond_b2
    const/high16 v19, 0x6000000

    and-int v19, v6, v19

    move-wide/from16 v9, p7

    if-nez v19, :cond_c7

    invoke-virtual {v4, v9, v10}, Ld10;->e(J)Z

    move-result v20

    if-eqz v20, :cond_c3

    const/high16 v20, 0x4000000

    goto :goto_c5

    :cond_c3
    const/high16 v20, 0x2000000

    :goto_c5
    or-int v3, v3, v20

    :cond_c7
    const/high16 v20, 0x30000000

    and-int v20, v6, v20

    move-wide/from16 v11, p9

    if-nez v20, :cond_dc

    invoke-virtual {v4, v11, v12}, Ld10;->e(J)Z

    move-result v22

    if-eqz v22, :cond_d8

    const/high16 v22, 0x20000000

    goto :goto_da

    :cond_d8
    const/high16 v22, 0x10000000

    :goto_da
    or-int v3, v3, v22

    :cond_dc
    and-int/lit8 v22, v7, 0x6

    move-wide/from16 v14, p11

    if-nez v22, :cond_f0

    invoke-virtual {v4, v14, v15}, Ld10;->e(J)Z

    move-result v24

    if-eqz v24, :cond_eb

    const/16 v16, 0x4

    goto :goto_ed

    :cond_eb
    const/16 v16, 0x2

    :goto_ed
    or-int v16, v7, v16

    goto :goto_f2

    :cond_f0
    move/from16 v16, v7

    :goto_f2
    and-int/lit8 v17, v7, 0x30

    move-wide/from16 v0, p13

    if-nez v17, :cond_105

    invoke-virtual {v4, v0, v1}, Ld10;->e(J)Z

    move-result v17

    if-eqz v17, :cond_101

    const/16 v18, 0x20

    goto :goto_103

    :cond_101
    const/16 v18, 0x10

    :goto_103
    or-int v16, v16, v18

    :cond_105
    and-int/lit16 v0, v7, 0x180

    if-nez v0, :cond_117

    const/4 v0, 0x0

    invoke-virtual {v4, v0}, Ld10;->c(F)Z

    move-result v0

    if-eqz v0, :cond_113

    const/16 v20, 0x100

    goto :goto_115

    :cond_113
    const/16 v20, 0x80

    :goto_115
    or-int v16, v16, v20

    :cond_117
    and-int/lit16 v0, v7, 0xc00

    if-nez v0, :cond_12d

    move-object/from16 v0, p15

    invoke-virtual {v4, v0}, Ld10;->f(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_126

    const/16 v22, 0x800

    goto :goto_128

    :cond_126
    const/16 v22, 0x400

    :goto_128
    or-int v16, v16, v22

    :goto_12a
    move/from16 v1, v16

    goto :goto_130

    :cond_12d
    move-object/from16 v0, p15

    goto :goto_12a

    :goto_130
    const v16, 0x12492493

    and-int v0, v3, v16

    const v2, 0x12492492

    if-ne v0, v2, :cond_143

    and-int/lit16 v0, v1, 0x493

    const/16 v2, 0x492

    if-eq v0, v2, :cond_141

    goto :goto_143

    :cond_141
    const/4 v0, 0x0

    goto :goto_144

    :cond_143
    :goto_143
    const/4 v0, 0x1

    :goto_144
    and-int/lit8 v2, v3, 0x1

    invoke-virtual {v4, v2, v0}, Ld10;->O(IZ)Z

    move-result v0

    if-eqz v0, :cond_183

    .line 2
    new-instance v10, Lt2;

    move-wide/from16 v20, p13

    move-object/from16 v22, v5

    move-wide/from16 v16, v11

    move-object/from16 v23, v13

    move-wide/from16 v18, v14

    move-object/from16 v11, p4

    move-object/from16 v12, p5

    move-wide/from16 v14, p7

    move-object v13, v8

    invoke-direct/range {v10 .. v23}, Lt2;-><init>(Lm00;Lm00;Ly41;JJJJLpi;Lm00;)V

    const v0, 0x1f6fcd57

    invoke-static {v0, v10, v4}, Lvd1;->A(ILu00;Ld10;)Lpi;

    move-result-object v0

    and-int/lit8 v2, v3, 0xe

    or-int/lit16 v2, v2, 0xc00

    shr-int/lit8 v3, v3, 0x3

    and-int/lit8 v3, v3, 0x70

    or-int/2addr v2, v3

    shr-int/lit8 v1, v1, 0x3

    and-int/lit16 v1, v1, 0x380

    or-int v5, v2, v1

    move-object/from16 v1, p2

    move-object/from16 v2, p15

    move-object v3, v0

    move-object/from16 v0, p0

    .line 3
    invoke-static/range {v0 .. v5}, Ld3;->d(Lxz;Lmi0;Lyp;Lpi;Ld10;I)V

    goto :goto_186

    .line 4
    :cond_183
    invoke-virtual/range {p16 .. p16}, Ld10;->R()V

    .line 5
    :goto_186
    invoke-virtual/range {p16 .. p16}, Ld10;->r()Lxv0;

    move-result-object v0

    if-eqz v0, :cond_1b4

    move-object v1, v0

    new-instance v0, Lx2;

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    move-object/from16 v5, p4

    move-wide/from16 v8, p7

    move-wide/from16 v10, p9

    move-wide/from16 v12, p11

    move-wide/from16 v14, p13

    move-object/from16 v16, p15

    move-object/from16 v25, v1

    move/from16 v17, v6

    move/from16 v18, v7

    move-object/from16 v1, p0

    move-object/from16 v6, p5

    move-object/from16 v7, p6

    invoke-direct/range {v0 .. v18}, Lx2;-><init>(Lxz;Lpi;Lmi0;Lm00;Lm00;Lm00;Ly41;JJJJLyp;II)V

    move-object/from16 v1, v25

    .line 6
    iput-object v0, v1, Lxv0;->d:Lm00;

    :cond_1b4
    return-void
.end method

.method public static final d(Lxz;Lmi0;Lyp;Lpi;Ld10;I)V
    .registers 13

    .line 1
    const v0, 0x17c55da

    .line 2
    .line 3
    .line 4
    invoke-virtual {p4, v0}, Ld10;->X(I)Ld10;

    .line 5
    .line 6
    .line 7
    and-int/lit8 v0, p5, 0x6

    .line 8
    .line 9
    if-nez v0, :cond_15

    .line 10
    .line 11
    invoke-virtual {p4, p0}, Ld10;->h(Ljava/lang/Object;)Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_12

    .line 16
    .line 17
    const/4 v0, 0x4

    .line 18
    goto :goto_13

    .line 19
    :cond_12
    const/4 v0, 0x2

    .line 20
    :goto_13
    or-int/2addr v0, p5

    .line 21
    goto :goto_16

    .line 22
    :cond_15
    move v0, p5

    .line 23
    :goto_16
    and-int/lit8 v1, p5, 0x30

    .line 24
    .line 25
    if-nez v1, :cond_26

    .line 26
    .line 27
    invoke-virtual {p4, p1}, Ld10;->f(Ljava/lang/Object;)Z

    .line 28
    .line 29
    .line 30
    move-result v1

    .line 31
    if-eqz v1, :cond_23

    .line 32
    .line 33
    const/16 v1, 0x20

    .line 34
    .line 35
    goto :goto_25

    .line 36
    :cond_23
    const/16 v1, 0x10

    .line 37
    .line 38
    :goto_25
    or-int/2addr v0, v1

    .line 39
    :cond_26
    and-int/lit16 v1, p5, 0x180

    .line 40
    .line 41
    if-nez v1, :cond_36

    .line 42
    .line 43
    invoke-virtual {p4, p2}, Ld10;->f(Ljava/lang/Object;)Z

    .line 44
    .line 45
    .line 46
    move-result v1

    .line 47
    if-eqz v1, :cond_33

    .line 48
    .line 49
    const/16 v1, 0x100

    .line 50
    .line 51
    goto :goto_35

    .line 52
    :cond_33
    const/16 v1, 0x80

    .line 53
    .line 54
    :goto_35
    or-int/2addr v0, v1

    .line 55
    :cond_36
    and-int/lit16 v1, p5, 0xc00

    .line 56
    .line 57
    if-nez v1, :cond_46

    .line 58
    .line 59
    invoke-virtual {p4, p3}, Ld10;->h(Ljava/lang/Object;)Z

    .line 60
    .line 61
    .line 62
    move-result v1

    .line 63
    if-eqz v1, :cond_43

    .line 64
    .line 65
    const/16 v1, 0x800

    .line 66
    .line 67
    goto :goto_45

    .line 68
    :cond_43
    const/16 v1, 0x400

    .line 69
    .line 70
    :goto_45
    or-int/2addr v0, v1

    .line 71
    :cond_46
    and-int/lit16 v1, v0, 0x493

    .line 72
    .line 73
    const/16 v2, 0x492

    .line 74
    .line 75
    const/4 v3, 0x0

    .line 76
    const/4 v4, 0x1

    .line 77
    if-eq v1, v2, :cond_50

    .line 78
    .line 79
    move v1, v4

    .line 80
    goto :goto_51

    .line 81
    :cond_50
    move v1, v3

    .line 82
    :goto_51
    and-int/2addr v0, v4

    .line 83
    invoke-virtual {p4, v0, v1}, Ld10;->O(IZ)Z

    .line 84
    .line 85
    .line 86
    move-result v0

    .line 87
    if-eqz v0, :cond_71

    .line 88
    .line 89
    sget-object v0, Ld3;->d:Lgk;

    .line 90
    .line 91
    invoke-virtual {p4, v0}, Ld10;->j(Llv0;)Ljava/lang/Object;

    .line 92
    .line 93
    .line 94
    move-result-object v0

    .line 95
    check-cast v0, Lzn;

    .line 96
    .line 97
    new-instance v1, Lp3;

    .line 98
    .line 99
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 100
    .line 101
    .line 102
    iput-object p0, v1, Lp3;->e:Ljava/lang/Object;

    .line 103
    .line 104
    iput-object p1, v1, Lp3;->f:Ljava/lang/Object;

    .line 105
    .line 106
    iput-object p2, v1, Lp3;->g:Ljava/lang/Object;

    .line 107
    .line 108
    iput-object p3, v1, Lp3;->h:Ljava/lang/Object;

    .line 109
    .line 110
    invoke-virtual {v0, v1, p4, v3}, Lzn;->a(Lp3;Ld10;I)V

    .line 111
    .line 112
    .line 113
    goto :goto_74

    .line 114
    :cond_71
    invoke-virtual {p4}, Ld10;->R()V

    .line 115
    .line 116
    .line 117
    :goto_74
    invoke-virtual {p4}, Ld10;->r()Lxv0;

    .line 118
    .line 119
    .line 120
    move-result-object p4

    .line 121
    if-eqz p4, :cond_87

    .line 122
    .line 123
    new-instance v0, Lz2;

    .line 124
    .line 125
    const/4 v6, 0x0

    .line 126
    move-object v1, p0

    .line 127
    move-object v2, p1

    .line 128
    move-object v3, p2

    .line 129
    move-object v4, p3

    .line 130
    move v5, p5

    .line 131
    invoke-direct/range {v0 .. v6}, Lz2;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lu00;II)V

    .line 132
    .line 133
    .line 134
    iput-object v0, p4, Lxv0;->d:Lm00;

    .line 135
    .line 136
    :cond_87
    return-void
.end method
