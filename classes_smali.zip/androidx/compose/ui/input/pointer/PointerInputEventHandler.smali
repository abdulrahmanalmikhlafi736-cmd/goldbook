.class public interface abstract Landroidx/compose/ui/input/pointer/PointerInputEventHandler;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# virtual methods
.method public abstract invoke(Lht0;Lml;)Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lht0;",
            "Lml;",
            ")",
            "Ljava/lang/Object;"
        }
    .end annotation
.end method
