.class public interface abstract Landroidx/window/area/reflectionguard/ExtensionWindowAreaPresentationRequirements;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# virtual methods
.method public abstract getPresentationContext()Landroid/content/Context;
.end method

.method public abstract setPresentationView(Landroid/view/View;)V
.end method
