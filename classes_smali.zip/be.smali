.class public final Lbe;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Ljp;


# instance fields
.field public e:Lnd;

.field public f:Lpg0;


# virtual methods
.method public final synthetic F(F)I
    .registers 2

    .line 1
    invoke-static {p1, p0}, Lfu0;->k(FLjp;)I

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    return p0
.end method

.method public final synthetic K(J)J
    .registers 3

    .line 1
    invoke-static {p1, p2, p0}, Lfu0;->p(JLjp;)J

    .line 2
    .line 3
    .line 4
    move-result-wide p0

    .line 5
    return-wide p0
.end method

.method public final synthetic N(J)F
    .registers 3

    .line 1
    invoke-static {p1, p2, p0}, Lfu0;->o(JLjp;)F

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    return p0
.end method

.method public final V(F)J
    .registers 2

    .line 1
    invoke-virtual {p0, p1}, Lbe;->c0(F)F

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    invoke-static {p1, p0}, Lfu0;->q(FLjp;)J

    .line 6
    .line 7
    .line 8
    move-result-wide p0

    .line 9
    return-wide p0
.end method

.method public final a()F
    .registers 1

    .line 1
    iget-object p0, p0, Lbe;->e:Lnd;

    .line 2
    .line 3
    invoke-interface {p0}, Lnd;->a()Ljp;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    invoke-interface {p0}, Ljp;->a()F

    .line 8
    .line 9
    .line 10
    move-result p0

    .line 11
    return p0
.end method

.method public final b0(I)F
    .registers 2

    .line 1
    int-to-float p1, p1

    .line 2
    invoke-virtual {p0}, Lbe;->a()F

    .line 3
    .line 4
    .line 5
    move-result p0

    .line 6
    div-float/2addr p1, p0

    .line 7
    return p1
.end method

.method public final c(Li00;)Lpg0;
    .registers 5

    .line 1
    new-instance v0, Lpg0;

    .line 2
    .line 3
    const/16 v1, 0x11

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    invoke-direct {v0, v1, v2}, Lpg0;-><init>(IZ)V

    .line 7
    .line 8
    .line 9
    iput-object p1, v0, Lpg0;->f:Ljava/lang/Object;

    .line 10
    .line 11
    iput-object v0, p0, Lbe;->f:Lpg0;

    .line 12
    .line 13
    return-object v0
.end method

.method public final c0(F)F
    .registers 2

    .line 1
    invoke-virtual {p0}, Lbe;->a()F

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    div-float/2addr p1, p0

    .line 6
    return p1
.end method

.method public final g()F
    .registers 1

    .line 1
    iget-object p0, p0, Lbe;->e:Lnd;

    .line 2
    .line 3
    invoke-interface {p0}, Lnd;->a()Ljp;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    invoke-interface {p0}, Ljp;->g()F

    .line 8
    .line 9
    .line 10
    move-result p0

    .line 11
    return p0
.end method

.method public final q(F)F
    .registers 2

    .line 1
    invoke-virtual {p0}, Lbe;->a()F

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    mul-float/2addr p0, p1

    .line 6
    return p0
.end method

.method public final synthetic y(J)F
    .registers 3

    .line 1
    invoke-static {p1, p2, p0}, Lfu0;->m(JLjp;)F

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    return p0
.end method
