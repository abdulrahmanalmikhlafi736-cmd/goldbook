.class public final Lbn;
.super Lu91;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lm00;


# instance fields
.field public final synthetic i:I

.field public j:I

.field public final synthetic k:Ltn;


# direct methods
.method public synthetic constructor <init>(Ltn;Lml;I)V
    .registers 4

    .line 1
    iput p3, p0, Lbn;->i:I

    .line 2
    .line 3
    iput-object p1, p0, Lbn;->k:Ltn;

    .line 4
    .line 5
    const/4 p1, 0x2

    .line 6
    invoke-direct {p0, p1, p2}, Lu91;-><init>(ILml;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 1
    iget v0, p0, Lbn;->i:I

    .line 2
    .line 3
    sget-object v1, Lwe1;->a:Lwe1;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_34

    .line 6
    .line 7
    .line 8
    check-cast p1, Lbm;

    .line 9
    .line 10
    check-cast p2, Lml;

    .line 11
    .line 12
    invoke-virtual {p0, p2, p1}, Lbn;->n(Lml;Ljava/lang/Object;)Lml;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    check-cast p0, Lbn;

    .line 17
    .line 18
    invoke-virtual {p0, v1}, Lbn;->p(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    return-object p0

    .line 23
    :pswitch_16  #0x1
    check-cast p1, Lbm;

    .line 24
    .line 25
    check-cast p2, Lml;

    .line 26
    .line 27
    invoke-virtual {p0, p2, p1}, Lbn;->n(Lml;Ljava/lang/Object;)Lml;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    check-cast p0, Lbn;

    .line 32
    .line 33
    invoke-virtual {p0, v1}, Lbn;->p(Ljava/lang/Object;)Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object p0

    .line 37
    return-object p0

    .line 38
    :pswitch_25  #0x0
    check-cast p1, Luw;

    .line 39
    .line 40
    check-cast p2, Lml;

    .line 41
    .line 42
    invoke-virtual {p0, p2, p1}, Lbn;->n(Lml;Ljava/lang/Object;)Lml;

    .line 43
    .line 44
    .line 45
    move-result-object p0

    .line 46
    check-cast p0, Lbn;

    .line 47
    .line 48
    invoke-virtual {p0, v1}, Lbn;->p(Ljava/lang/Object;)Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    move-result-object p0

    .line 52
    return-object p0

    .line 53
    :pswitch_data_34
    .packed-switch 0x0
        :pswitch_25  #00000000
        :pswitch_16  #00000001
    .end packed-switch
.end method

.method public final n(Lml;Ljava/lang/Object;)Lml;
    .registers 4

    .line 1
    iget p2, p0, Lbn;->i:I

    .line 2
    .line 3
    iget-object p0, p0, Lbn;->k:Ltn;

    .line 4
    .line 5
    packed-switch p2, :pswitch_data_1c

    .line 6
    .line 7
    .line 8
    new-instance p2, Lbn;

    .line 9
    .line 10
    const/4 v0, 0x2

    .line 11
    invoke-direct {p2, p0, p1, v0}, Lbn;-><init>(Ltn;Lml;I)V

    .line 12
    .line 13
    .line 14
    return-object p2

    .line 15
    :pswitch_e  #0x1
    new-instance p2, Lbn;

    .line 16
    .line 17
    const/4 v0, 0x1

    .line 18
    invoke-direct {p2, p0, p1, v0}, Lbn;-><init>(Ltn;Lml;I)V

    .line 19
    .line 20
    .line 21
    return-object p2

    .line 22
    :pswitch_15  #0x0
    new-instance p2, Lbn;

    .line 23
    .line 24
    const/4 v0, 0x0

    .line 25
    invoke-direct {p2, p0, p1, v0}, Lbn;-><init>(Ltn;Lml;I)V

    .line 26
    .line 27
    .line 28
    return-object p2

    .line 29
    :pswitch_data_1c
    .packed-switch 0x0
        :pswitch_15  #00000000
        :pswitch_e  #00000001
    .end packed-switch
.end method

.method public final p(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 11

    .line 1
    iget v0, p0, Lbn;->i:I

    .line 2
    .line 3
    sget-object v1, Lwe1;->a:Lwe1;

    .line 4
    .line 5
    const/4 v2, -0x1

    .line 6
    const/4 v3, 0x2

    .line 7
    const/4 v4, 0x0

    .line 8
    const-string v5, "call to \'resume\' before \'invoke\' with coroutine"

    .line 9
    .line 10
    sget-object v6, Lcm;->e:Lcm;

    .line 11
    .line 12
    iget-object v7, p0, Lbn;->k:Ltn;

    .line 13
    .line 14
    const/4 v8, 0x1

    .line 15
    packed-switch v0, :pswitch_data_b8

    .line 16
    .line 17
    .line 18
    iget-object v0, v7, Ltn;->k:Lpg0;

    .line 19
    .line 20
    iget v1, p0, Lbn;->j:I

    .line 21
    .line 22
    if-eqz v1, :cond_29

    .line 23
    .line 24
    if-eq v1, v8, :cond_23

    .line 25
    .line 26
    if-ne v1, v3, :cond_1f

    .line 27
    .line 28
    invoke-static {p1}, Lnb0;->t(Ljava/lang/Object;)V

    .line 29
    .line 30
    .line 31
    goto :goto_4d

    .line 32
    :cond_1f
    invoke-static {v5}, Lod;->p(Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    goto :goto_56

    .line 36
    :cond_23
    :try_start_23
    invoke-static {p1}, Lnb0;->t(Ljava/lang/Object;)V
    :try_end_26
    .catchall {:try_start_23 .. :try_end_26} :catchall_27

    .line 37
    .line 38
    .line 39
    goto :goto_42

    .line 40
    :catchall_27
    move-exception p0

    .line 41
    goto :goto_51

    .line 42
    :cond_29
    invoke-static {p1}, Lnb0;->t(Ljava/lang/Object;)V

    .line 43
    .line 44
    .line 45
    invoke-virtual {v0}, Lpg0;->o()Lz71;

    .line 46
    .line 47
    .line 48
    move-result-object p1

    .line 49
    instance-of p1, p1, Lxv;

    .line 50
    .line 51
    if-eqz p1, :cond_39

    .line 52
    .line 53
    invoke-virtual {v0}, Lpg0;->o()Lz71;

    .line 54
    .line 55
    .line 56
    move-result-object v4

    .line 57
    goto :goto_56

    .line 58
    :cond_39
    :try_start_39
    iput v8, p0, Lbn;->j:I

    .line 59
    .line 60
    invoke-static {v7, p0}, Ltn;->e(Ltn;Lnl;)Ljava/lang/Object;

    .line 61
    .line 62
    .line 63
    move-result-object p1
    :try_end_3f
    .catchall {:try_start_39 .. :try_end_3f} :catchall_27

    .line 64
    if-ne p1, v6, :cond_42

    .line 65
    .line 66
    goto :goto_4b

    .line 67
    :cond_42
    :goto_42
    iput v3, p0, Lbn;->j:I

    .line 68
    .line 69
    const/4 p1, 0x0

    .line 70
    invoke-static {v7, p1, p0}, Ltn;->f(Ltn;ZLml;)Ljava/lang/Object;

    .line 71
    .line 72
    .line 73
    move-result-object p1

    .line 74
    if-ne p1, v6, :cond_4d

    .line 75
    .line 76
    :goto_4b
    move-object v4, v6

    .line 77
    goto :goto_56

    .line 78
    :cond_4d
    :goto_4d
    move-object v4, p1

    .line 79
    check-cast v4, Lz71;

    .line 80
    .line 81
    goto :goto_56

    .line 82
    :goto_51
    new-instance v4, Lsv0;

    .line 83
    .line 84
    invoke-direct {v4, p0, v2}, Lsv0;-><init>(Ljava/lang/Throwable;I)V

    .line 85
    .line 86
    .line 87
    :goto_56
    return-object v4

    .line 88
    :pswitch_57  #0x1
    iget v0, p0, Lbn;->j:I

    .line 89
    .line 90
    if-eqz v0, :cond_6c

    .line 91
    .line 92
    if-eq v0, v8, :cond_68

    .line 93
    .line 94
    if-ne v0, v3, :cond_63

    .line 95
    .line 96
    invoke-static {p1}, Lnb0;->t(Ljava/lang/Object;)V

    .line 97
    .line 98
    .line 99
    goto :goto_9a

    .line 100
    :cond_63
    invoke-static {v5}, Lod;->p(Ljava/lang/String;)V

    .line 101
    .line 102
    .line 103
    move-object v1, v4

    .line 104
    goto :goto_9a

    .line 105
    :cond_68
    invoke-static {p1}, Lnb0;->t(Ljava/lang/Object;)V

    .line 106
    .line 107
    .line 108
    goto :goto_82

    .line 109
    :cond_6c
    invoke-static {p1}, Lnb0;->t(Ljava/lang/Object;)V

    .line 110
    .line 111
    .line 112
    iget-object p1, v7, Ltn;->l:Lp3;

    .line 113
    .line 114
    iput v8, p0, Lbn;->j:I

    .line 115
    .line 116
    iget-object p1, p1, Lp3;->f:Ljava/lang/Object;

    .line 117
    .line 118
    check-cast p1, Luh;

    .line 119
    .line 120
    invoke-virtual {p1, p0}, Luh;->e0(Lnl;)Ljava/lang/Object;

    .line 121
    .line 122
    .line 123
    move-result-object p1

    .line 124
    if-ne p1, v6, :cond_7e

    .line 125
    .line 126
    goto :goto_7f

    .line 127
    :cond_7e
    move-object p1, v1

    .line 128
    :goto_7f
    if-ne p1, v6, :cond_82

    .line 129
    .line 130
    goto :goto_99

    .line 131
    :cond_82
    :goto_82
    invoke-virtual {v7}, Ltn;->h()Lq51;

    .line 132
    .line 133
    .line 134
    move-result-object p1

    .line 135
    iget-object p1, p1, Lq51;->c:Lcz0;

    .line 136
    .line 137
    invoke-static {p1, v2}, Lwl1;->o(Ltw;I)Ltw;

    .line 138
    .line 139
    .line 140
    move-result-object p1

    .line 141
    new-instance v0, Lrd;

    .line 142
    .line 143
    invoke-direct {v0, v8, v7}, Lrd;-><init>(ILjava/lang/Object;)V

    .line 144
    .line 145
    .line 146
    iput v3, p0, Lbn;->j:I

    .line 147
    .line 148
    invoke-interface {p1, v0, p0}, Ltw;->b(Luw;Lml;)Ljava/lang/Object;

    .line 149
    .line 150
    .line 151
    move-result-object p0

    .line 152
    if-ne p0, v6, :cond_9a

    .line 153
    .line 154
    :goto_99
    move-object v1, v6

    .line 155
    :cond_9a
    :goto_9a
    return-object v1

    .line 156
    :pswitch_9b  #0x0
    iget v0, p0, Lbn;->j:I

    .line 157
    .line 158
    if-eqz v0, :cond_aa

    .line 159
    .line 160
    if-ne v0, v8, :cond_a5

    .line 161
    .line 162
    invoke-static {p1}, Lnb0;->t(Ljava/lang/Object;)V

    .line 163
    .line 164
    .line 165
    goto :goto_b6

    .line 166
    :cond_a5
    invoke-static {v5}, Lod;->p(Ljava/lang/String;)V

    .line 167
    .line 168
    .line 169
    move-object v1, v4

    .line 170
    goto :goto_b6

    .line 171
    :cond_aa
    invoke-static {p1}, Lnb0;->t(Ljava/lang/Object;)V

    .line 172
    .line 173
    .line 174
    iput v8, p0, Lbn;->j:I

    .line 175
    .line 176
    invoke-static {v7, p0}, Ltn;->c(Ltn;Lnl;)Ljava/lang/Object;

    .line 177
    .line 178
    .line 179
    move-result-object p0

    .line 180
    if-ne p0, v6, :cond_b6

    .line 181
    .line 182
    move-object v1, v6

    .line 183
    :cond_b6
    :goto_b6
    return-object v1

    .line 184
    nop

    .line 185
    :pswitch_data_b8
    .packed-switch 0x0
        :pswitch_9b  #00000000
        :pswitch_57  #00000001
    .end packed-switch
.end method
