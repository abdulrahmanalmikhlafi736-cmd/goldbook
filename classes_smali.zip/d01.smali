.class public final Ld01;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements La01;


# instance fields
.field public final synthetic e:Lm00;

.field public final synthetic f:Li00;


# direct methods
.method public constructor <init>(Lm00;Li00;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Ld01;->e:Lm00;

    .line 5
    .line 6
    iput-object p2, p0, Ld01;->f:Li00;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 1
    iget-object p0, p0, Ld01;->f:Li00;

    .line 2
    .line 3
    invoke-interface {p0, p1}, Li00;->i(Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    return-object p0
.end method

.method public final j(Liz0;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 1
    iget-object p0, p0, Ld01;->e:Lm00;

    .line 2
    .line 3
    invoke-interface {p0, p1, p2}, Lm00;->f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    return-object p0
.end method
