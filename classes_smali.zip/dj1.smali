.class public interface abstract Ldj1;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# virtual methods
.method public abstract a(Ljp;)I
.end method

.method public abstract b(Ljp;)I
.end method

.method public abstract c(Ljp;Lo90;)I
.end method

.method public abstract d(Ljp;Lo90;)I
.end method
