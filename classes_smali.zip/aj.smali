.class public final Laj;
.super Lu91;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lm00;


# instance fields
.field public final synthetic i:I

.field public j:I

.field public k:Ljava/lang/Object;

.field public synthetic l:Ljava/lang/Object;

.field public final synthetic m:Ljava/lang/Object;

.field public final synthetic n:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lml;I)V
    .registers 7

    .line 1
    iput p6, p0, Laj;->i:I

    .line 2
    .line 3
    iput-object p1, p0, Laj;->k:Ljava/lang/Object;

    .line 4
    .line 5
    iput-object p2, p0, Laj;->l:Ljava/lang/Object;

    .line 6
    .line 7
    iput-object p3, p0, Laj;->m:Ljava/lang/Object;

    .line 8
    .line 9
    iput-object p4, p0, Laj;->n:Ljava/lang/Object;

    .line 10
    .line 11
    const/4 p1, 0x2

    .line 12
    invoke-direct {p0, p1, p5}, Lu91;-><init>(ILml;)V

    .line 13
    .line 14
    .line 15
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lml;I)V
    .registers 6

    .line 16
    iput p5, p0, Laj;->i:I

    iput-object p1, p0, Laj;->l:Ljava/lang/Object;

    iput-object p2, p0, Laj;->m:Ljava/lang/Object;

    iput-object p3, p0, Laj;->n:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p4}, Lu91;-><init>(ILml;)V

    return-void
.end method

.method public constructor <init>(Lmk0;Lj50;Lml;)V
    .registers 5

    const/4 v0, 0x3

    iput v0, p0, Laj;->i:I

    .line 17
    iput-object p1, p0, Laj;->m:Ljava/lang/Object;

    iput-object p2, p0, Laj;->n:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p3}, Lu91;-><init>(ILml;)V

    return-void
.end method


# virtual methods
.method public final f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 1
    iget v0, p0, Laj;->i:I

    .line 2
    .line 3
    sget-object v1, Lwe1;->a:Lwe1;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_54

    .line 6
    .line 7
    .line 8
    check-cast p1, Lbm;

    .line 9
    .line 10
    check-cast p2, Lml;

    .line 11
    .line 12
    invoke-virtual {p0, p2, p1}, Laj;->n(Lml;Ljava/lang/Object;)Lml;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    check-cast p0, Laj;

    .line 17
    .line 18
    invoke-virtual {p0, v1}, Laj;->p(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    return-object p0

    .line 23
    :pswitch_16  #0x3
    check-cast p1, Lbm;

    .line 24
    .line 25
    check-cast p2, Lml;

    .line 26
    .line 27
    invoke-virtual {p0, p2, p1}, Laj;->n(Lml;Ljava/lang/Object;)Lml;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    check-cast p0, Laj;

    .line 32
    .line 33
    invoke-virtual {p0, v1}, Laj;->p(Ljava/lang/Object;)Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    sget-object p0, Lcm;->e:Lcm;

    .line 37
    .line 38
    return-object p0

    .line 39
    :pswitch_26  #0x2
    check-cast p1, Lbm;

    .line 40
    .line 41
    check-cast p2, Lml;

    .line 42
    .line 43
    invoke-virtual {p0, p2, p1}, Laj;->n(Lml;Ljava/lang/Object;)Lml;

    .line 44
    .line 45
    .line 46
    move-result-object p0

    .line 47
    check-cast p0, Laj;

    .line 48
    .line 49
    invoke-virtual {p0, v1}, Laj;->p(Ljava/lang/Object;)Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    move-result-object p0

    .line 53
    return-object p0

    .line 54
    :pswitch_35  #0x1
    check-cast p1, Li51;

    .line 55
    .line 56
    check-cast p2, Lml;

    .line 57
    .line 58
    invoke-virtual {p0, p2, p1}, Laj;->n(Lml;Ljava/lang/Object;)Lml;

    .line 59
    .line 60
    .line 61
    move-result-object p0

    .line 62
    check-cast p0, Laj;

    .line 63
    .line 64
    invoke-virtual {p0, v1}, Laj;->p(Ljava/lang/Object;)Ljava/lang/Object;

    .line 65
    .line 66
    .line 67
    move-result-object p0

    .line 68
    return-object p0

    .line 69
    :pswitch_44  #0x0
    check-cast p1, Lbm;

    .line 70
    .line 71
    check-cast p2, Lml;

    .line 72
    .line 73
    invoke-virtual {p0, p2, p1}, Laj;->n(Lml;Ljava/lang/Object;)Lml;

    .line 74
    .line 75
    .line 76
    move-result-object p0

    .line 77
    check-cast p0, Laj;

    .line 78
    .line 79
    invoke-virtual {p0, v1}, Laj;->p(Ljava/lang/Object;)Ljava/lang/Object;

    .line 80
    .line 81
    .line 82
    move-result-object p0

    .line 83
    return-object p0

    .line 84
    nop

    .line 85
    :pswitch_data_54
    .packed-switch 0x0
        :pswitch_44  #00000000
        :pswitch_35  #00000001
        :pswitch_26  #00000002
        :pswitch_16  #00000003
    .end packed-switch
.end method

.method public final n(Lml;Ljava/lang/Object;)Lml;
    .registers 14

    .line 1
    iget v0, p0, Laj;->i:I

    .line 2
    .line 3
    iget-object v1, p0, Laj;->n:Ljava/lang/Object;

    .line 4
    .line 5
    iget-object v2, p0, Laj;->m:Ljava/lang/Object;

    .line 6
    .line 7
    packed-switch v0, :pswitch_data_6e

    .line 8
    .line 9
    .line 10
    new-instance v3, Laj;

    .line 11
    .line 12
    iget-object p0, p0, Laj;->l:Ljava/lang/Object;

    .line 13
    .line 14
    move-object v4, p0

    .line 15
    check-cast v4, Llg0;

    .line 16
    .line 17
    move-object v5, v2

    .line 18
    check-cast v5, Ljava/util/List;

    .line 19
    .line 20
    move-object v6, v1

    .line 21
    check-cast v6, Landroid/content/res/Resources;

    .line 22
    .line 23
    const/4 v8, 0x4

    .line 24
    move-object v7, p1

    .line 25
    invoke-direct/range {v3 .. v8}, Laj;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lml;I)V

    .line 26
    .line 27
    .line 28
    return-object v3

    .line 29
    :pswitch_1c  #0x3
    move-object v9, p1

    .line 30
    new-instance p0, Laj;

    .line 31
    .line 32
    check-cast v2, Lmk0;

    .line 33
    .line 34
    check-cast v1, Lj50;

    .line 35
    .line 36
    invoke-direct {p0, v2, v1, v9}, Laj;-><init>(Lmk0;Lj50;Lml;)V

    .line 37
    .line 38
    .line 39
    iput-object p2, p0, Laj;->l:Ljava/lang/Object;

    .line 40
    .line 41
    return-object p0

    .line 42
    :pswitch_29  #0x2
    move-object v9, p1

    .line 43
    new-instance v4, Laj;

    .line 44
    .line 45
    iget-object p1, p0, Laj;->k:Ljava/lang/Object;

    .line 46
    .line 47
    move-object v5, p1

    .line 48
    check-cast v5, Lk51;

    .line 49
    .line 50
    iget-object p1, p0, Laj;->l:Ljava/lang/Object;

    .line 51
    .line 52
    move-object v6, p1

    .line 53
    check-cast v6, Ltw;

    .line 54
    .line 55
    move-object v7, v2

    .line 56
    check-cast v7, Ld81;

    .line 57
    .line 58
    iget-object v8, p0, Laj;->n:Ljava/lang/Object;

    .line 59
    .line 60
    const/4 v10, 0x2

    .line 61
    invoke-direct/range {v4 .. v10}, Laj;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lml;I)V

    .line 62
    .line 63
    .line 64
    return-object v4

    .line 65
    :pswitch_40  #0x1
    move-object v9, p1

    .line 66
    new-instance v4, Laj;

    .line 67
    .line 68
    iget-object p1, p0, Laj;->l:Ljava/lang/Object;

    .line 69
    .line 70
    move-object v5, p1

    .line 71
    check-cast v5, Ltw;

    .line 72
    .line 73
    move-object v6, v2

    .line 74
    check-cast v6, Ld81;

    .line 75
    .line 76
    iget-object v7, p0, Laj;->n:Ljava/lang/Object;

    .line 77
    .line 78
    move-object v8, v9

    .line 79
    const/4 v9, 0x1

    .line 80
    invoke-direct/range {v4 .. v9}, Laj;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lml;I)V

    .line 81
    .line 82
    .line 83
    iput-object p2, v4, Laj;->k:Ljava/lang/Object;

    .line 84
    .line 85
    return-object v4

    .line 86
    :pswitch_55  #0x0
    move-object v9, p1

    .line 87
    new-instance v4, Laj;

    .line 88
    .line 89
    iget-object p1, p0, Laj;->k:Ljava/lang/Object;

    .line 90
    .line 91
    move-object v5, p1

    .line 92
    check-cast v5, Lcj;

    .line 93
    .line 94
    iget-object p0, p0, Laj;->l:Ljava/lang/Object;

    .line 95
    .line 96
    move-object v6, p0

    .line 97
    check-cast v6, Landroid/view/ScrollCaptureSession;

    .line 98
    .line 99
    move-object v7, v2

    .line 100
    check-cast v7, Landroid/graphics/Rect;

    .line 101
    .line 102
    move-object v8, v1

    .line 103
    check-cast v8, Ljava/util/function/Consumer;

    .line 104
    .line 105
    const/4 v10, 0x0

    .line 106
    invoke-direct/range {v4 .. v10}, Laj;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lml;I)V

    .line 107
    .line 108
    .line 109
    return-object v4

    .line 110
    nop

    .line 111
    :pswitch_data_6e
    .packed-switch 0x0
        :pswitch_55  #00000000
        :pswitch_40  #00000001
        :pswitch_29  #00000002
        :pswitch_1c  #00000003
    .end packed-switch
.end method

.method public final p(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 25

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget v1, v0, Laj;->i:I

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    const/4 v3, 0x2

    .line 7
    sget-object v4, Lwe1;->a:Lwe1;

    .line 8
    .line 9
    iget-object v5, v0, Laj;->n:Ljava/lang/Object;

    .line 10
    .line 11
    iget-object v6, v0, Laj;->m:Ljava/lang/Object;

    .line 12
    .line 13
    const-string v7, "call to \'resume\' before \'invoke\' with coroutine"

    .line 14
    .line 15
    sget-object v8, Lcm;->e:Lcm;

    .line 16
    .line 17
    const/4 v9, 0x1

    .line 18
    const/4 v10, 0x0

    .line 19
    packed-switch v1, :pswitch_data_27c

    .line 20
    .line 21
    .line 22
    iget v1, v0, Laj;->j:I

    .line 23
    .line 24
    if-eqz v1, :cond_2d

    .line 25
    .line 26
    if-ne v1, v9, :cond_27

    .line 27
    .line 28
    iget-object v0, v0, Laj;->k:Ljava/lang/Object;

    .line 29
    .line 30
    check-cast v0, Llq0;

    .line 31
    .line 32
    invoke-static/range {p1 .. p1}, Lnb0;->t(Ljava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    move-object v1, v0

    .line 36
    move-object/from16 v0, p1

    .line 37
    .line 38
    goto/16 :goto_c2

    .line 39
    .line 40
    :cond_27
    invoke-static {v7}, Lod;->p(Ljava/lang/String;)V

    .line 41
    .line 42
    .line 43
    move-object v4, v10

    .line 44
    goto/16 :goto_c5

    .line 45
    .line 46
    :cond_2d
    invoke-static/range {p1 .. p1}, Lnb0;->t(Ljava/lang/Object;)V

    .line 47
    .line 48
    .line 49
    iget-object v1, v0, Laj;->l:Ljava/lang/Object;

    .line 50
    .line 51
    check-cast v1, Llg0;

    .line 52
    .line 53
    iget-object v1, v1, Llg0;->d:Llq0;

    .line 54
    .line 55
    check-cast v6, Ljava/util/List;

    .line 56
    .line 57
    check-cast v5, Landroid/content/res/Resources;

    .line 58
    .line 59
    iput-object v1, v0, Laj;->k:Ljava/lang/Object;

    .line 60
    .line 61
    iput v9, v0, Laj;->j:I

    .line 62
    .line 63
    new-instance v3, Ljava/lang/StringBuilder;

    .line 64
    .line 65
    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    .line 66
    .line 67
    .line 68
    new-instance v7, Ljava/util/ArrayList;

    .line 69
    .line 70
    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    .line 71
    .line 72
    .line 73
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    :cond_4c
    :goto_4c
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 78
    .line 79
    .line 80
    move-result v6

    .line 81
    if-eqz v6, :cond_61

    .line 82
    .line 83
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 84
    .line 85
    .line 86
    move-result-object v6

    .line 87
    move-object v9, v6

    .line 88
    check-cast v9, Lt01;

    .line 89
    .line 90
    iget-boolean v9, v9, Lt01;->a:Z

    .line 91
    .line 92
    if-eqz v9, :cond_4c

    .line 93
    .line 94
    invoke-virtual {v7, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 95
    .line 96
    .line 97
    goto :goto_4c

    .line 98
    :cond_61
    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    .line 99
    .line 100
    .line 101
    move-result v6

    .line 102
    :goto_65
    if-ge v2, v6, :cond_ba

    .line 103
    .line 104
    invoke-virtual {v7, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 105
    .line 106
    .line 107
    move-result-object v0

    .line 108
    add-int/lit8 v2, v2, 0x1

    .line 109
    .line 110
    check-cast v0, Lt01;

    .line 111
    .line 112
    :try_start_6f
    iget v0, v0, Lt01;->b:I

    .line 113
    .line 114
    new-instance v9, Ljava/lang/Integer;

    .line 115
    .line 116
    invoke-direct {v9, v0}, Ljava/lang/Integer;-><init>(I)V

    .line 117
    .line 118
    .line 119
    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    .line 120
    .line 121
    .line 122
    move-result v0

    .line 123
    invoke-virtual {v5, v0}, Landroid/content/res/Resources;->openRawResource(I)Ljava/io/InputStream;

    .line 124
    .line 125
    .line 126
    move-result-object v0

    .line 127
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 128
    .line 129
    .line 130
    sget-object v9, Lmf;->a:Ljava/nio/charset/Charset;

    .line 131
    .line 132
    new-instance v10, Ljava/io/InputStreamReader;

    .line 133
    .line 134
    invoke-direct {v10, v0, v9}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/nio/charset/Charset;)V

    .line 135
    .line 136
    .line 137
    new-instance v9, Ljava/io/BufferedReader;

    .line 138
    .line 139
    const/16 v0, 0x2000

    .line 140
    .line 141
    invoke-direct {v9, v10, v0}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;I)V
    :try_end_8f
    .catchall {:try_start_6f .. :try_end_8f} :catchall_9f

    .line 142
    .line 143
    .line 144
    :try_start_8f
    invoke-static {v9}, Lua0;->v(Ljava/io/BufferedReader;)Ljava/lang/String;

    .line 145
    .line 146
    .line 147
    move-result-object v0
    :try_end_93
    .catchall {:try_start_8f .. :try_end_93} :catchall_97

    .line 148
    :try_start_93
    invoke-interface {v9}, Ljava/io/Closeable;->close()V
    :try_end_96
    .catchall {:try_start_93 .. :try_end_96} :catchall_9f

    .line 149
    .line 150
    .line 151
    goto :goto_a6

    .line 152
    :catchall_97
    move-exception v0

    .line 153
    move-object v10, v0

    .line 154
    :try_start_99
    throw v10
    :try_end_9a
    .catchall {:try_start_99 .. :try_end_9a} :catchall_9a

    .line 155
    :catchall_9a
    move-exception v0

    .line 156
    :try_start_9b
    invoke-static {v9, v10}, Lgh0;->t(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 157
    .line 158
    .line 159
    throw v0
    :try_end_9f
    .catchall {:try_start_9b .. :try_end_9f} :catchall_9f

    .line 160
    :catchall_9f
    move-exception v0

    .line 161
    new-instance v9, Lpx0;

    .line 162
    .line 163
    invoke-direct {v9, v0}, Lpx0;-><init>(Ljava/lang/Throwable;)V

    .line 164
    .line 165
    .line 166
    move-object v0, v9

    .line 167
    :goto_a6
    invoke-static {v0}, Lqx0;->a(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 168
    .line 169
    .line 170
    move-result-object v9

    .line 171
    if-nez v9, :cond_ad

    .line 172
    .line 173
    goto :goto_af

    .line 174
    :cond_ad
    const-string v0, ""

    .line 175
    .line 176
    :goto_af
    check-cast v0, Ljava/lang/String;

    .line 177
    .line 178
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 179
    .line 180
    .line 181
    const-string v0, "\n"

    .line 182
    .line 183
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 184
    .line 185
    .line 186
    goto :goto_65

    .line 187
    :cond_ba
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 188
    .line 189
    .line 190
    move-result-object v0

    .line 191
    if-ne v0, v8, :cond_c2

    .line 192
    .line 193
    move-object v4, v8

    .line 194
    goto :goto_c5

    .line 195
    :cond_c2
    :goto_c2
    invoke-interface {v1, v0}, Lmk0;->setValue(Ljava/lang/Object;)V

    .line 196
    .line 197
    .line 198
    :goto_c5
    return-object v4

    .line 199
    :pswitch_c6  #0x3
    iget v1, v0, Laj;->j:I

    .line 200
    .line 201
    if-eqz v1, :cond_f6

    .line 202
    .line 203
    if-eq v1, v9, :cond_e5

    .line 204
    .line 205
    if-ne v1, v3, :cond_df

    .line 206
    .line 207
    iget-object v1, v0, Laj;->k:Ljava/lang/Object;

    .line 208
    .line 209
    check-cast v1, Lkw0;

    .line 210
    .line 211
    iget-object v2, v0, Laj;->l:Ljava/lang/Object;

    .line 212
    .line 213
    check-cast v2, Lbm;

    .line 214
    .line 215
    invoke-static/range {p1 .. p1}, Lnb0;->t(Ljava/lang/Object;)V

    .line 216
    .line 217
    .line 218
    move-object/from16 v22, v2

    .line 219
    .line 220
    move-object v2, v1

    .line 221
    move-object/from16 v1, v22

    .line 222
    .line 223
    goto :goto_106

    .line 224
    :cond_df
    invoke-static {v7}, Lod;->p(Ljava/lang/String;)V

    .line 225
    .line 226
    .line 227
    :goto_e2
    move-object v8, v10

    .line 228
    goto/16 :goto_159

    .line 229
    .line 230
    :cond_e5
    iget-object v1, v0, Laj;->k:Ljava/lang/Object;

    .line 231
    .line 232
    check-cast v1, Lkw0;

    .line 233
    .line 234
    iget-object v2, v0, Laj;->l:Ljava/lang/Object;

    .line 235
    .line 236
    check-cast v2, Lbm;

    .line 237
    .line 238
    invoke-static/range {p1 .. p1}, Lnb0;->t(Ljava/lang/Object;)V

    .line 239
    .line 240
    .line 241
    move-object/from16 v22, v2

    .line 242
    .line 243
    move-object v2, v1

    .line 244
    move-object/from16 v1, v22

    .line 245
    .line 246
    goto :goto_132

    .line 247
    :cond_f6
    invoke-static/range {p1 .. p1}, Lnb0;->t(Ljava/lang/Object;)V

    .line 248
    .line 249
    .line 250
    iget-object v1, v0, Laj;->l:Ljava/lang/Object;

    .line 251
    .line 252
    check-cast v1, Lbm;

    .line 253
    .line 254
    new-instance v2, Lkw0;

    .line 255
    .line 256
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 257
    .line 258
    .line 259
    const/high16 v4, 0x3f800000  # 1.0f

    .line 260
    .line 261
    iput v4, v2, Lkw0;->e:F

    .line 262
    .line 263
    :cond_106
    :goto_106
    move-object v4, v6

    .line 264
    check-cast v4, Lmk0;

    .line 265
    .line 266
    move-object v7, v5

    .line 267
    check-cast v7, Lj50;

    .line 268
    .line 269
    new-instance v11, Lho;

    .line 270
    .line 271
    invoke-direct {v11, v4, v7, v2, v1}, Lho;-><init>(Lmk0;Lj50;Lkw0;Lbm;)V

    .line 272
    .line 273
    .line 274
    iput-object v1, v0, Laj;->l:Ljava/lang/Object;

    .line 275
    .line 276
    iput-object v2, v0, Laj;->k:Ljava/lang/Object;

    .line 277
    .line 278
    iput v9, v0, Laj;->j:I

    .line 279
    .line 280
    invoke-interface {v0}, Lml;->e()Lsl;

    .line 281
    .line 282
    .line 283
    move-result-object v4

    .line 284
    sget-object v7, Le3;->R:Le3;

    .line 285
    .line 286
    invoke-interface {v4, v7}, Lsl;->k(Lrl;)Lql;

    .line 287
    .line 288
    .line 289
    move-result-object v4

    .line 290
    if-nez v4, :cond_155

    .line 291
    .line 292
    invoke-interface {v0}, Lml;->e()Lsl;

    .line 293
    .line 294
    .line 295
    move-result-object v4

    .line 296
    invoke-static {v4}, Lsb0;->o(Lsl;)Lg7;

    .line 297
    .line 298
    .line 299
    move-result-object v4

    .line 300
    invoke-virtual {v4, v11, v0}, Lg7;->c(Li00;Lnl;)Ljava/lang/Object;

    .line 301
    .line 302
    .line 303
    move-result-object v4

    .line 304
    if-ne v4, v8, :cond_132

    .line 305
    .line 306
    goto :goto_159

    .line 307
    :cond_132
    :goto_132
    iget v4, v2, Lkw0;->e:F

    .line 308
    .line 309
    const/4 v7, 0x0

    .line 310
    cmpg-float v4, v4, v7

    .line 311
    .line 312
    if-nez v4, :cond_106

    .line 313
    .line 314
    new-instance v4, Lx1;

    .line 315
    .line 316
    const/4 v7, 0x6

    .line 317
    invoke-direct {v4, v7, v1}, Lx1;-><init>(ILjava/lang/Object;)V

    .line 318
    .line 319
    .line 320
    invoke-static {v4}, Lmc0;->C(Lxz;)Lcz0;

    .line 321
    .line 322
    .line 323
    move-result-object v4

    .line 324
    new-instance v7, Li50;

    .line 325
    .line 326
    invoke-direct {v7, v3, v10}, Lu91;-><init>(ILml;)V

    .line 327
    .line 328
    .line 329
    iput-object v1, v0, Laj;->l:Ljava/lang/Object;

    .line 330
    .line 331
    iput-object v2, v0, Laj;->k:Ljava/lang/Object;

    .line 332
    .line 333
    iput v3, v0, Laj;->j:I

    .line 334
    .line 335
    invoke-static {v4, v7, v0}, Lwl1;->y(Ltw;Lm00;Lnl;)Ljava/lang/Object;

    .line 336
    .line 337
    .line 338
    move-result-object v4

    .line 339
    if-ne v4, v8, :cond_106

    .line 340
    .line 341
    goto :goto_159

    .line 342
    :cond_155
    invoke-static {}, Lod;->d()V

    .line 343
    .line 344
    .line 345
    goto :goto_e2

    .line 346
    :goto_159
    return-object v8

    .line 347
    :pswitch_15a  #0x2
    iget-object v1, v0, Laj;->l:Ljava/lang/Object;

    .line 348
    .line 349
    move-object v12, v1

    .line 350
    check-cast v12, Ltw;

    .line 351
    .line 352
    move-object v13, v6

    .line 353
    check-cast v13, Ld81;

    .line 354
    .line 355
    iget v1, v0, Laj;->j:I

    .line 356
    .line 357
    const/4 v5, 0x4

    .line 358
    const/4 v6, 0x3

    .line 359
    if-eqz v1, :cond_17f

    .line 360
    .line 361
    if-eq v1, v9, :cond_170

    .line 362
    .line 363
    if-eq v1, v3, :cond_17b

    .line 364
    .line 365
    if-eq v1, v6, :cond_170

    .line 366
    .line 367
    if-ne v1, v5, :cond_175

    .line 368
    .line 369
    :cond_170
    invoke-static/range {p1 .. p1}, Lnb0;->t(Ljava/lang/Object;)V

    .line 370
    .line 371
    .line 372
    goto/16 :goto_1f5

    .line 373
    .line 374
    :cond_175
    invoke-static {v7}, Lod;->p(Ljava/lang/String;)V

    .line 375
    .line 376
    .line 377
    move-object v4, v10

    .line 378
    goto/16 :goto_1f5

    .line 379
    .line 380
    :cond_17b
    invoke-static/range {p1 .. p1}, Lnb0;->t(Ljava/lang/Object;)V

    .line 381
    .line 382
    .line 383
    goto :goto_1aa

    .line 384
    :cond_17f
    invoke-static/range {p1 .. p1}, Lnb0;->t(Ljava/lang/Object;)V

    .line 385
    .line 386
    .line 387
    iget-object v1, v0, Laj;->k:Ljava/lang/Object;

    .line 388
    .line 389
    check-cast v1, Lk51;

    .line 390
    .line 391
    sget-object v7, Lj51;->a:Lav0;

    .line 392
    .line 393
    if-ne v1, v7, :cond_193

    .line 394
    .line 395
    iput v9, v0, Laj;->j:I

    .line 396
    .line 397
    invoke-interface {v12, v13, v0}, Ltw;->b(Luw;Lml;)Ljava/lang/Object;

    .line 398
    .line 399
    .line 400
    move-result-object v0

    .line 401
    if-ne v0, v8, :cond_1f5

    .line 402
    .line 403
    goto :goto_1f4

    .line 404
    :cond_193
    sget-object v7, Lj51;->b:Lav0;

    .line 405
    .line 406
    const/4 v15, 0x0

    .line 407
    if-ne v1, v7, :cond_1b3

    .line 408
    .line 409
    invoke-virtual {v13}, Lm0;->g()Lj91;

    .line 410
    .line 411
    .line 412
    move-result-object v1

    .line 413
    new-instance v2, Lix;

    .line 414
    .line 415
    invoke-direct {v2, v3, v15}, Lu91;-><init>(ILml;)V

    .line 416
    .line 417
    .line 418
    iput v3, v0, Laj;->j:I

    .line 419
    .line 420
    invoke-static {v1, v2, v0}, Lwl1;->y(Ltw;Lm00;Lnl;)Ljava/lang/Object;

    .line 421
    .line 422
    .line 423
    move-result-object v1

    .line 424
    if-ne v1, v8, :cond_1aa

    .line 425
    .line 426
    goto :goto_1f4

    .line 427
    :cond_1aa
    :goto_1aa
    iput v6, v0, Laj;->j:I

    .line 428
    .line 429
    invoke-interface {v12, v13, v0}, Ltw;->b(Luw;Lml;)Ljava/lang/Object;

    .line 430
    .line 431
    .line 432
    move-result-object v0

    .line 433
    if-ne v0, v8, :cond_1f5

    .line 434
    .line 435
    goto :goto_1f4

    .line 436
    :cond_1b3
    invoke-virtual {v13}, Lm0;->g()Lj91;

    .line 437
    .line 438
    .line 439
    move-result-object v3

    .line 440
    invoke-interface {v1, v3}, Lk51;->b(Lj91;)Ltw;

    .line 441
    .line 442
    .line 443
    move-result-object v1

    .line 444
    invoke-static {v1}, Lwl1;->u(Ltw;)Ltw;

    .line 445
    .line 446
    .line 447
    move-result-object v18

    .line 448
    new-instance v11, Laj;

    .line 449
    .line 450
    iget-object v14, v0, Laj;->n:Ljava/lang/Object;

    .line 451
    .line 452
    const/16 v16, 0x1

    .line 453
    .line 454
    invoke-direct/range {v11 .. v16}, Laj;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lml;I)V

    .line 455
    .line 456
    .line 457
    iput v5, v0, Laj;->j:I

    .line 458
    .line 459
    sget v1, Lex;->a:I

    .line 460
    .line 461
    new-instance v1, Ldx;

    .line 462
    .line 463
    invoke-direct {v1, v11, v15}, Ldx;-><init>(Laj;Lml;)V

    .line 464
    .line 465
    .line 466
    new-instance v16, Lff;

    .line 467
    .line 468
    const/16 v20, -0x2

    .line 469
    .line 470
    sget-object v21, Lgd;->e:Lgd;

    .line 471
    .line 472
    sget-object v19, Lst;->e:Lst;

    .line 473
    .line 474
    move-object/from16 v17, v1

    .line 475
    .line 476
    invoke-direct/range {v16 .. v21}, Lff;-><init>(Ln00;Ltw;Lsl;ILgd;)V

    .line 477
    .line 478
    .line 479
    move-object/from16 v1, v16

    .line 480
    .line 481
    invoke-static {v1, v2}, Lwl1;->o(Ltw;I)Ltw;

    .line 482
    .line 483
    .line 484
    move-result-object v1

    .line 485
    sget-object v2, Lom0;->e:Lom0;

    .line 486
    .line 487
    invoke-interface {v1, v2, v0}, Ltw;->b(Luw;Lml;)Ljava/lang/Object;

    .line 488
    .line 489
    .line 490
    move-result-object v0

    .line 491
    if-ne v0, v8, :cond_1ed

    .line 492
    .line 493
    goto :goto_1ee

    .line 494
    :cond_1ed
    move-object v0, v4

    .line 495
    :goto_1ee
    if-ne v0, v8, :cond_1f1

    .line 496
    .line 497
    goto :goto_1f2

    .line 498
    :cond_1f1
    move-object v0, v4

    .line 499
    :goto_1f2
    if-ne v0, v8, :cond_1f5

    .line 500
    .line 501
    :goto_1f4
    move-object v4, v8

    .line 502
    :cond_1f5
    :goto_1f5
    return-object v4

    .line 503
    :pswitch_1f6  #0x1
    check-cast v6, Ld81;

    .line 504
    .line 505
    iget v1, v0, Laj;->j:I

    .line 506
    .line 507
    if-eqz v1, :cond_207

    .line 508
    .line 509
    if-ne v1, v9, :cond_202

    .line 510
    .line 511
    invoke-static/range {p1 .. p1}, Lnb0;->t(Ljava/lang/Object;)V

    .line 512
    .line 513
    .line 514
    goto :goto_239

    .line 515
    :cond_202
    invoke-static {v7}, Lod;->p(Ljava/lang/String;)V

    .line 516
    .line 517
    .line 518
    :goto_205
    move-object v4, v10

    .line 519
    goto :goto_239

    .line 520
    :cond_207
    invoke-static/range {p1 .. p1}, Lnb0;->t(Ljava/lang/Object;)V

    .line 521
    .line 522
    .line 523
    iget-object v1, v0, Laj;->k:Ljava/lang/Object;

    .line 524
    .line 525
    check-cast v1, Li51;

    .line 526
    .line 527
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 528
    .line 529
    .line 530
    move-result v1

    .line 531
    if-eqz v1, :cond_22c

    .line 532
    .line 533
    if-eq v1, v9, :cond_239

    .line 534
    .line 535
    if-ne v1, v3, :cond_228

    .line 536
    .line 537
    sget-object v0, Lk70;->t:Lmt;

    .line 538
    .line 539
    if-eq v5, v0, :cond_220

    .line 540
    .line 541
    invoke-virtual {v6, v10, v5}, Ld81;->i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 542
    .line 543
    .line 544
    goto :goto_239

    .line 545
    :cond_220
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    .line 546
    .line 547
    const-string v1, "MutableStateFlow.resetReplayCache is not supported"

    .line 548
    .line 549
    invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    .line 550
    .line 551
    .line 552
    throw v0

    .line 553
    :cond_228
    invoke-static {}, Lod;->k()V

    .line 554
    .line 555
    .line 556
    goto :goto_205

    .line 557
    :cond_22c
    iget-object v1, v0, Laj;->l:Ljava/lang/Object;

    .line 558
    .line 559
    check-cast v1, Ltw;

    .line 560
    .line 561
    iput v9, v0, Laj;->j:I

    .line 562
    .line 563
    invoke-interface {v1, v6, v0}, Ltw;->b(Luw;Lml;)Ljava/lang/Object;

    .line 564
    .line 565
    .line 566
    move-result-object v0

    .line 567
    if-ne v0, v8, :cond_239

    .line 568
    .line 569
    move-object v4, v8

    .line 570
    :cond_239
    :goto_239
    return-object v4

    .line 571
    :pswitch_23a  #0x0
    iget v1, v0, Laj;->j:I

    .line 572
    .line 573
    if-eqz v1, :cond_24b

    .line 574
    .line 575
    if-ne v1, v9, :cond_246

    .line 576
    .line 577
    invoke-static/range {p1 .. p1}, Lnb0;->t(Ljava/lang/Object;)V

    .line 578
    .line 579
    .line 580
    move-object/from16 v0, p1

    .line 581
    .line 582
    goto :goto_26f

    .line 583
    :cond_246
    invoke-static {v7}, Lod;->p(Ljava/lang/String;)V

    .line 584
    .line 585
    .line 586
    move-object v4, v10

    .line 587
    goto :goto_27a

    .line 588
    :cond_24b
    invoke-static/range {p1 .. p1}, Lnb0;->t(Ljava/lang/Object;)V

    .line 589
    .line 590
    .line 591
    iget-object v1, v0, Laj;->k:Ljava/lang/Object;

    .line 592
    .line 593
    check-cast v1, Lcj;

    .line 594
    .line 595
    iget-object v2, v0, Laj;->l:Ljava/lang/Object;

    .line 596
    .line 597
    check-cast v2, Landroid/view/ScrollCaptureSession;

    .line 598
    .line 599
    check-cast v6, Landroid/graphics/Rect;

    .line 600
    .line 601
    new-instance v3, Lr60;

    .line 602
    .line 603
    iget v7, v6, Landroid/graphics/Rect;->left:I

    .line 604
    .line 605
    iget v10, v6, Landroid/graphics/Rect;->top:I

    .line 606
    .line 607
    iget v11, v6, Landroid/graphics/Rect;->right:I

    .line 608
    .line 609
    iget v6, v6, Landroid/graphics/Rect;->bottom:I

    .line 610
    .line 611
    invoke-direct {v3, v7, v10, v11, v6}, Lr60;-><init>(IIII)V

    .line 612
    .line 613
    .line 614
    iput v9, v0, Laj;->j:I

    .line 615
    .line 616
    invoke-static {v1, v2, v3, v0}, Lcj;->a(Lcj;Landroid/view/ScrollCaptureSession;Lr60;Lnl;)Ljava/lang/Object;

    .line 617
    .line 618
    .line 619
    move-result-object v0

    .line 620
    if-ne v0, v8, :cond_26f

    .line 621
    .line 622
    move-object v4, v8

    .line 623
    goto :goto_27a

    .line 624
    :cond_26f
    :goto_26f
    check-cast v0, Lr60;

    .line 625
    .line 626
    check-cast v5, Ljava/util/function/Consumer;

    .line 627
    .line 628
    invoke-static {v0}, Ldd0;->x(Lr60;)Landroid/graphics/Rect;

    .line 629
    .line 630
    .line 631
    move-result-object v0

    .line 632
    invoke-static {v5, v0}, Ly0;->p(Ljava/util/function/Consumer;Landroid/graphics/Rect;)V

    .line 633
    .line 634
    .line 635
    :goto_27a
    return-object v4

    .line 636
    nop

    .line 637
    :pswitch_data_27c
    .packed-switch 0x0
        :pswitch_23a  #00000000
        :pswitch_1f6  #00000001
        :pswitch_15a  #00000002
        :pswitch_c6  #00000003
    .end packed-switch
.end method
