.class public final Lbl0;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lle;
.implements Loh1;


# instance fields
.field public final e:Lne;

.field public final synthetic f:Lcl0;


# direct methods
.method public constructor <init>(Lcl0;Lne;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lbl0;->f:Lcl0;

    .line 5
    .line 6
    iput-object p2, p0, Lbl0;->e:Lne;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final a(La21;I)V
    .registers 3

    .line 1
    iget-object p0, p0, Lbl0;->e:Lne;

    .line 2
    .line 3
    invoke-virtual {p0, p1, p2}, Lne;->a(La21;I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final e()Lsl;
    .registers 1

    .line 1
    iget-object p0, p0, Lbl0;->e:Lne;

    .line 2
    .line 3
    iget-object p0, p0, Lne;->i:Lsl;

    .line 4
    .line 5
    return-object p0
.end method

.method public final h(Ljava/lang/Object;)V
    .registers 2

    .line 1
    iget-object p0, p0, Lbl0;->e:Lne;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Lne;->h(Ljava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final j(Ljava/lang/Object;Ln00;)Lmt;
    .registers 4

    .line 1
    check-cast p1, Lwe1;

    .line 2
    .line 3
    new-instance p2, Lme;

    .line 4
    .line 5
    iget-object v0, p0, Lbl0;->f:Lcl0;

    .line 6
    .line 7
    invoke-direct {p2, v0, p0}, Lme;-><init>(Lcl0;Lbl0;)V

    .line 8
    .line 9
    .line 10
    iget-object p0, p0, Lbl0;->e:Lne;

    .line 11
    .line 12
    invoke-virtual {p0, p1, p2}, Lne;->j(Ljava/lang/Object;Ln00;)Lmt;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    if-eqz p0, :cond_17

    .line 17
    .line 18
    sget-object p1, Lcl0;->g:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    .line 19
    .line 20
    const/4 p2, 0x0

    .line 21
    invoke-virtual {p1, v0, p2}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->set(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 22
    .line 23
    .line 24
    :cond_17
    return-object p0
.end method

.method public final l(Ljava/lang/Throwable;)Z
    .registers 2

    .line 1
    iget-object p0, p0, Lbl0;->e:Lne;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Lne;->l(Ljava/lang/Throwable;)Z

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final x(Ljava/lang/Object;)V
    .registers 2

    .line 1
    iget-object p0, p0, Lbl0;->e:Lne;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Lne;->x(Ljava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method
