.class public final Ldn;
.super Lu91;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lm00;


# instance fields
.field public final synthetic i:I

.field public synthetic j:Ljava/lang/Object;

.field public final synthetic k:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Lml;I)V
    .registers 5

    .line 1
    iput p4, p0, Ldn;->i:I

    .line 2
    .line 3
    iput-object p1, p0, Ldn;->j:Ljava/lang/Object;

    .line 4
    .line 5
    iput-object p2, p0, Ldn;->k:Ljava/lang/Object;

    .line 6
    .line 7
    const/4 p1, 0x2

    .line 8
    invoke-direct {p0, p1, p3}, Lu91;-><init>(ILml;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Lml;I)V
    .registers 4

    .line 12
    iput p3, p0, Ldn;->i:I

    iput-object p1, p0, Ldn;->k:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lu91;-><init>(ILml;)V

    return-void
.end method


# virtual methods
.method public final f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 1
    iget v0, p0, Ldn;->i:I

    .line 2
    .line 3
    sget-object v1, Lwe1;->a:Lwe1;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_5c

    .line 6
    .line 7
    .line 8
    check-cast p1, Lek0;

    .line 9
    .line 10
    check-cast p2, Lml;

    .line 11
    .line 12
    invoke-virtual {p0, p2, p1}, Ldn;->n(Lml;Ljava/lang/Object;)Lml;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    check-cast p0, Ldn;

    .line 17
    .line 18
    invoke-virtual {p0, v1}, Ldn;->p(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    return-object v1

    .line 22
    :pswitch_15  #0x4
    check-cast p1, Lbm;

    .line 23
    .line 24
    check-cast p2, Lml;

    .line 25
    .line 26
    invoke-virtual {p0, p2, p1}, Ldn;->n(Lml;Ljava/lang/Object;)Lml;

    .line 27
    .line 28
    .line 29
    move-result-object p0

    .line 30
    check-cast p0, Ldn;

    .line 31
    .line 32
    invoke-virtual {p0, v1}, Ldn;->p(Ljava/lang/Object;)Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    return-object v1

    .line 36
    :pswitch_23  #0x3
    check-cast p1, Lbm;

    .line 37
    .line 38
    check-cast p2, Lml;

    .line 39
    .line 40
    invoke-virtual {p0, p2, p1}, Ldn;->n(Lml;Ljava/lang/Object;)Lml;

    .line 41
    .line 42
    .line 43
    move-result-object p0

    .line 44
    check-cast p0, Ldn;

    .line 45
    .line 46
    invoke-virtual {p0, v1}, Ldn;->p(Ljava/lang/Object;)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    return-object v1

    .line 50
    :pswitch_31  #0x2
    check-cast p1, Lbm;

    .line 51
    .line 52
    check-cast p2, Lml;

    .line 53
    .line 54
    invoke-virtual {p0, p2, p1}, Ldn;->n(Lml;Ljava/lang/Object;)Lml;

    .line 55
    .line 56
    .line 57
    move-result-object p0

    .line 58
    check-cast p0, Ldn;

    .line 59
    .line 60
    invoke-virtual {p0, v1}, Ldn;->p(Ljava/lang/Object;)Ljava/lang/Object;

    .line 61
    .line 62
    .line 63
    return-object v1

    .line 64
    :pswitch_3f  #0x1
    check-cast p1, Lbm;

    .line 65
    .line 66
    check-cast p2, Lml;

    .line 67
    .line 68
    invoke-virtual {p0, p2, p1}, Ldn;->n(Lml;Ljava/lang/Object;)Lml;

    .line 69
    .line 70
    .line 71
    move-result-object p0

    .line 72
    check-cast p0, Ldn;

    .line 73
    .line 74
    invoke-virtual {p0, v1}, Ldn;->p(Ljava/lang/Object;)Ljava/lang/Object;

    .line 75
    .line 76
    .line 77
    return-object v1

    .line 78
    :pswitch_4d  #0x0
    check-cast p1, Lz71;

    .line 79
    .line 80
    check-cast p2, Lml;

    .line 81
    .line 82
    invoke-virtual {p0, p2, p1}, Ldn;->n(Lml;Ljava/lang/Object;)Lml;

    .line 83
    .line 84
    .line 85
    move-result-object p0

    .line 86
    check-cast p0, Ldn;

    .line 87
    .line 88
    invoke-virtual {p0, v1}, Ldn;->p(Ljava/lang/Object;)Ljava/lang/Object;

    .line 89
    .line 90
    .line 91
    move-result-object p0

    .line 92
    return-object p0

    .line 93
    :pswitch_data_5c
    .packed-switch 0x0
        :pswitch_4d  #00000000
        :pswitch_3f  #00000001
        :pswitch_31  #00000002
        :pswitch_23  #00000003
        :pswitch_15  #00000004
    .end packed-switch
.end method

.method public final n(Lml;Ljava/lang/Object;)Lml;
    .registers 5

    .line 1
    iget v0, p0, Ldn;->i:I

    .line 2
    .line 3
    iget-object v1, p0, Ldn;->k:Ljava/lang/Object;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_50

    .line 6
    .line 7
    .line 8
    new-instance p0, Ldn;

    .line 9
    .line 10
    check-cast v1, Ljava/lang/String;

    .line 11
    .line 12
    const/4 v0, 0x5

    .line 13
    invoke-direct {p0, v1, p1, v0}, Ldn;-><init>(Ljava/lang/Object;Lml;I)V

    .line 14
    .line 15
    .line 16
    iput-object p2, p0, Ldn;->j:Ljava/lang/Object;

    .line 17
    .line 18
    return-object p0

    .line 19
    :pswitch_12  #0x4
    new-instance p2, Ldn;

    .line 20
    .line 21
    iget-object p0, p0, Ldn;->j:Ljava/lang/Object;

    .line 22
    .line 23
    check-cast p0, Lwi1;

    .line 24
    .line 25
    check-cast v1, Lui1;

    .line 26
    .line 27
    const/4 v0, 0x4

    .line 28
    invoke-direct {p2, p0, v1, p1, v0}, Ldn;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lml;I)V

    .line 29
    .line 30
    .line 31
    return-object p2

    .line 32
    :pswitch_1f  #0x3
    new-instance p0, Ldn;

    .line 33
    .line 34
    check-cast v1, Lkd0;

    .line 35
    .line 36
    const/4 v0, 0x3

    .line 37
    invoke-direct {p0, v1, p1, v0}, Ldn;-><init>(Ljava/lang/Object;Lml;I)V

    .line 38
    .line 39
    .line 40
    iput-object p2, p0, Ldn;->j:Ljava/lang/Object;

    .line 41
    .line 42
    return-object p0

    .line 43
    :pswitch_2a  #0x2
    new-instance p2, Ldn;

    .line 44
    .line 45
    iget-object p0, p0, Ldn;->j:Ljava/lang/Object;

    .line 46
    .line 47
    check-cast p0, Lsb1;

    .line 48
    .line 49
    check-cast v1, Ldh;

    .line 50
    .line 51
    const/4 v0, 0x2

    .line 52
    invoke-direct {p2, p0, v1, p1, v0}, Ldn;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lml;I)V

    .line 53
    .line 54
    .line 55
    return-object p2

    .line 56
    :pswitch_37  #0x1
    new-instance p2, Ldn;

    .line 57
    .line 58
    iget-object p0, p0, Ldn;->j:Ljava/lang/Object;

    .line 59
    .line 60
    check-cast p0, Lwi1;

    .line 61
    .line 62
    check-cast v1, Lmk0;

    .line 63
    .line 64
    const/4 v0, 0x1

    .line 65
    invoke-direct {p2, p0, v1, p1, v0}, Ldn;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lml;I)V

    .line 66
    .line 67
    .line 68
    return-object p2

    .line 69
    :pswitch_44  #0x0
    new-instance p0, Ldn;

    .line 70
    .line 71
    check-cast v1, Lz71;

    .line 72
    .line 73
    const/4 v0, 0x0

    .line 74
    invoke-direct {p0, v1, p1, v0}, Ldn;-><init>(Ljava/lang/Object;Lml;I)V

    .line 75
    .line 76
    .line 77
    iput-object p2, p0, Ldn;->j:Ljava/lang/Object;

    .line 78
    .line 79
    return-object p0

    .line 80
    nop

    .line 81
    :pswitch_data_50
    .packed-switch 0x0
        :pswitch_44  #00000000
        :pswitch_37  #00000001
        :pswitch_2a  #00000002
        :pswitch_1f  #00000003
        :pswitch_12  #00000004
    .end packed-switch
.end method

.method public final p(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 7

    .line 1
    iget v0, p0, Ldn;->i:I

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x0

    .line 5
    packed-switch v0, :pswitch_data_e6

    .line 6
    .line 7
    .line 8
    iget-object v0, p0, Ldn;->j:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v0, Lek0;

    .line 11
    .line 12
    invoke-static {p1}, Lnb0;->t(Ljava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    sget-object p1, Ln41;->L:Lwt0;

    .line 16
    .line 17
    iget-object p0, p0, Ldn;->k:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast p0, Ljava/lang/String;

    .line 20
    .line 21
    invoke-virtual {v0, p1, p0}, Lek0;->d(Lwt0;Ljava/lang/Object;)V

    .line 22
    .line 23
    .line 24
    sget-object p0, Lwe1;->a:Lwe1;

    .line 25
    .line 26
    return-object p0

    .line 27
    :pswitch_1a  #0x4
    invoke-static {p1}, Lnb0;->t(Ljava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    iget-object p1, p0, Ldn;->j:Ljava/lang/Object;

    .line 31
    .line 32
    check-cast p1, Lwi1;

    .line 33
    .line 34
    iget-object p1, p1, Lwi1;->h:Landroid/os/Bundle;

    .line 35
    .line 36
    if-nez p1, :cond_38

    .line 37
    .line 38
    iget-object p0, p0, Ldn;->k:Ljava/lang/Object;

    .line 39
    .line 40
    check-cast p0, Lui1;

    .line 41
    .line 42
    iget-object p1, p0, Lui1;->a:Lbm;

    .line 43
    .line 44
    new-instance v0, Ld;

    .line 45
    .line 46
    const/16 v3, 0x18

    .line 47
    .line 48
    const-string v4, "https://www.facebook.com/messages"

    .line 49
    .line 50
    invoke-direct {v0, p0, v4, v2, v3}, Ld;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lml;I)V

    .line 51
    .line 52
    .line 53
    const/4 p0, 0x3

    .line 54
    invoke-static {p1, v2, v0, p0}, Lwl1;->B(Lbm;Lsl;Lm00;I)Ls71;

    .line 55
    .line 56
    .line 57
    :cond_38
    invoke-static {v1, v1, v1}, Lmod/Mod;->setVideoState(ZII)V

    .line 58
    .line 59
    .line 60
    sget-object p0, Lwe1;->a:Lwe1;

    .line 61
    .line 62
    return-object p0

    .line 63
    :pswitch_3e  #0x3
    invoke-static {p1}, Lnb0;->t(Ljava/lang/Object;)V

    .line 64
    .line 65
    .line 66
    iget-object p1, p0, Ldn;->j:Ljava/lang/Object;

    .line 67
    .line 68
    check-cast p1, Lbm;

    .line 69
    .line 70
    iget-object p0, p0, Ldn;->k:Ljava/lang/Object;

    .line 71
    .line 72
    check-cast p0, Lkd0;

    .line 73
    .line 74
    iget-object v0, p0, Lkd0;->e:Lud0;

    .line 75
    .line 76
    iget-object v1, v0, Lud0;->d:Ljd0;

    .line 77
    .line 78
    sget-object v3, Ljd0;->f:Ljd0;

    .line 79
    .line 80
    invoke-virtual {v1, v3}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    .line 81
    .line 82
    .line 83
    move-result v1

    .line 84
    if-ltz v1, :cond_59

    .line 85
    .line 86
    invoke-virtual {v0, p0}, Lud0;->a(Lrd0;)V

    .line 87
    .line 88
    .line 89
    goto :goto_6a

    .line 90
    :cond_59
    invoke-interface {p1}, Lbm;->f()Lsl;

    .line 91
    .line 92
    .line 93
    move-result-object p0

    .line 94
    sget-object p1, Le3;->S:Le3;

    .line 95
    .line 96
    invoke-interface {p0, p1}, Lsl;->k(Lrl;)Lql;

    .line 97
    .line 98
    .line 99
    move-result-object p0

    .line 100
    check-cast p0, La80;

    .line 101
    .line 102
    if-eqz p0, :cond_6a

    .line 103
    .line 104
    invoke-interface {p0, v2}, La80;->a(Ljava/util/concurrent/CancellationException;)V

    .line 105
    .line 106
    .line 107
    :cond_6a
    :goto_6a
    sget-object p0, Lwe1;->a:Lwe1;

    .line 108
    .line 109
    return-object p0

    .line 110
    :pswitch_6d  #0x2
    invoke-static {p1}, Lnb0;->t(Ljava/lang/Object;)V

    .line 111
    .line 112
    .line 113
    iget-object p1, p0, Ldn;->j:Ljava/lang/Object;

    .line 114
    .line 115
    check-cast p1, Lsb1;

    .line 116
    .line 117
    iget-object v0, p0, Ldn;->k:Ljava/lang/Object;

    .line 118
    .line 119
    check-cast v0, Ldh;

    .line 120
    .line 121
    iget-wide v0, v0, Ldh;->a:J

    .line 122
    .line 123
    invoke-static {v0, v1}, Lwl1;->L(J)I

    .line 124
    .line 125
    .line 126
    move-result v0

    .line 127
    iput v0, p1, Lsb1;->a:I

    .line 128
    .line 129
    iget-object p1, p0, Ldn;->j:Ljava/lang/Object;

    .line 130
    .line 131
    check-cast p1, Lsb1;

    .line 132
    .line 133
    iget-object p0, p0, Ldn;->k:Ljava/lang/Object;

    .line 134
    .line 135
    check-cast p0, Ldh;

    .line 136
    .line 137
    iget-wide v0, p0, Ldh;->b:J

    .line 138
    .line 139
    invoke-static {v0, v1}, Lwl1;->L(J)I

    .line 140
    .line 141
    .line 142
    move-result p0

    .line 143
    iput p0, p1, Lsb1;->b:I

    .line 144
    .line 145
    sget-object p0, Lwe1;->a:Lwe1;

    .line 146
    .line 147
    return-object p0

    .line 148
    :pswitch_93  #0x1
    invoke-static {p1}, Lnb0;->t(Ljava/lang/Object;)V

    .line 149
    .line 150
    .line 151
    iget-object p1, p0, Ldn;->k:Ljava/lang/Object;

    .line 152
    .line 153
    check-cast p1, Lmk0;

    .line 154
    .line 155
    invoke-interface {p1}, La81;->getValue()Ljava/lang/Object;

    .line 156
    .line 157
    .line 158
    move-result-object p1

    .line 159
    check-cast p1, Ljava/lang/Boolean;

    .line 160
    .line 161
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 162
    .line 163
    .line 164
    move-result p1

    .line 165
    if-eqz p1, :cond_a9

    .line 166
    .line 167
    const-string p1, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0"

    .line 168
    .line 169
    goto :goto_aa

    .line 170
    :cond_a9
    move-object p1, v2

    .line 171
    :goto_aa
    iget-object p0, p0, Ldn;->j:Ljava/lang/Object;

    .line 172
    .line 173
    check-cast p0, Lwi1;

    .line 174
    .line 175
    invoke-virtual {p0}, Lwi1;->b()Lx7;

    .line 176
    .line 177
    .line 178
    move-result-object p0

    .line 179
    if-eqz p0, :cond_c0

    .line 180
    .line 181
    iget-object p0, p0, Lx7;->a:Landroid/webkit/WebView;

    .line 182
    .line 183
    invoke-virtual {p0}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    .line 184
    .line 185
    .line 186
    move-result-object p0

    .line 187
    invoke-virtual {p0, p1}, Landroid/webkit/WebSettings;->setUserAgentString(Ljava/lang/String;)V

    .line 188
    .line 189
    .line 190
    sget-object v2, Lwe1;->a:Lwe1;

    .line 191
    .line 192
    goto :goto_c5

    .line 193
    :cond_c0
    const-string p0, "WebView is not initialized"

    .line 194
    .line 195
    invoke-static {p0}, Lod;->p(Ljava/lang/String;)V

    .line 196
    .line 197
    .line 198
    :goto_c5
    return-object v2

    .line 199
    :pswitch_c6  #0x0
    invoke-static {p1}, Lnb0;->t(Ljava/lang/Object;)V

    .line 200
    .line 201
    .line 202
    iget-object p1, p0, Ldn;->j:Ljava/lang/Object;

    .line 203
    .line 204
    check-cast p1, Lz71;

    .line 205
    .line 206
    instance-of v0, p1, Lqm;

    .line 207
    .line 208
    if-eqz v0, :cond_e0

    .line 209
    .line 210
    check-cast p1, Lqm;

    .line 211
    .line 212
    iget p1, p1, Lz71;->a:I

    .line 213
    .line 214
    iget-object p0, p0, Ldn;->k:Ljava/lang/Object;

    .line 215
    .line 216
    check-cast p0, Lz71;

    .line 217
    .line 218
    check-cast p0, Lqm;

    .line 219
    .line 220
    iget p0, p0, Lz71;->a:I

    .line 221
    .line 222
    if-gt p1, p0, :cond_e0

    .line 223
    .line 224
    const/4 v1, 0x1

    .line 225
    :cond_e0
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 226
    .line 227
    .line 228
    move-result-object p0

    .line 229
    return-object p0

    .line 230
    nop

    .line 231
    :pswitch_data_e6
    .packed-switch 0x0
        :pswitch_c6  #00000000
        :pswitch_93  #00000001
        :pswitch_6d  #00000002
        :pswitch_3e  #00000003
        :pswitch_1a  #00000004
    .end packed-switch
.end method
