.class public final Lao0;
.super Lxo0;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# static fields
.field public static final c:Lao0;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 1
    new-instance v0, Lao0;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x3

    .line 5
    invoke-direct {v0, v1, v1, v2}, Lxo0;-><init>(III)V

    .line 6
    .line 7
    .line 8
    sput-object v0, Lao0;->c:Lao0;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final a(Lpg;Lm9;La61;Luw0;Lyo0;)V
    .registers 6

    .line 1
    invoke-virtual {p3}, La61;->j()V

    .line 2
    .line 3
    .line 4
    return-void
.end method
