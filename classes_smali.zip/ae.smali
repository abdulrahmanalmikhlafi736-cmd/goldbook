.class public final Lae;
.super Lli0;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lvm0;
.implements Lnd;
.implements Lds;


# instance fields
.field public final s:Lbe;

.field public t:Z

.field public final u:Ll;


# direct methods
.method public constructor <init>(Lbe;Ll;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Lli0;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lae;->s:Lbe;

    .line 5
    .line 6
    iput-object p2, p0, Lae;->u:Ll;

    .line 7
    .line 8
    iput-object p0, p1, Lbe;->e:Lnd;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final C(Lda0;)V
    .registers 5

    .line 1
    iget-boolean v0, p0, Lae;->t:Z

    .line 2
    .line 3
    iget-object v1, p0, Lae;->s:Lbe;

    .line 4
    .line 5
    if-nez v0, :cond_21

    .line 6
    .line 7
    const/4 v0, 0x0

    .line 8
    iput-object v0, v1, Lbe;->f:Lpg0;

    .line 9
    .line 10
    new-instance v0, Lg4;

    .line 11
    .line 12
    const/4 v2, 0x3

    .line 13
    invoke-direct {v0, v2, p0, v1}, Lg4;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    invoke-static {p0, v0}, Lsb0;->r(Lli0;Lxz;)V

    .line 17
    .line 18
    .line 19
    iget-object v0, v1, Lbe;->f:Lpg0;

    .line 20
    .line 21
    if-eqz v0, :cond_1a

    .line 22
    .line 23
    const/4 v0, 0x1

    .line 24
    iput-boolean v0, p0, Lae;->t:Z

    .line 25
    .line 26
    goto :goto_21

    .line 27
    :cond_1a
    const-string p0, "DrawResult not defined, did you forget to call onDraw?"

    .line 28
    .line 29
    invoke-static {p0}, Lfu0;->C(Ljava/lang/String;)Lyh;

    .line 30
    .line 31
    .line 32
    move-result-object p0

    .line 33
    throw p0

    .line 34
    :cond_21
    :goto_21
    iget-object p0, v1, Lbe;->f:Lpg0;

    .line 35
    .line 36
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 37
    .line 38
    .line 39
    iget-object p0, p0, Lpg0;->f:Ljava/lang/Object;

    .line 40
    .line 41
    check-cast p0, Li00;

    .line 42
    .line 43
    invoke-interface {p0, p1}, Li00;->i(Ljava/lang/Object;)Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    return-void
.end method

.method public final Z()V
    .registers 1

    .line 1
    invoke-virtual {p0}, Lae;->r0()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public final a()Ljp;
    .registers 1

    .line 1
    invoke-static {p0}, Lk70;->O(Lcp;)Lba0;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    iget-object p0, p0, Lba0;->C:Ljp;

    .line 6
    .line 7
    return-object p0
.end method

.method public final b()J
    .registers 3

    .line 1
    const/4 v0, 0x4

    .line 2
    invoke-static {p0, v0}, Lk70;->M(Lcp;I)Lgm0;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    iget-wide v0, p0, Lks0;->g:J

    .line 7
    .line 8
    invoke-static {v0, v1}, Lwl1;->M(J)J

    .line 9
    .line 10
    .line 11
    move-result-wide v0

    .line 12
    return-wide v0
.end method

.method public final getLayoutDirection()Lo90;
    .registers 1

    .line 1
    invoke-static {p0}, Lk70;->O(Lcp;)Lba0;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    iget-object p0, p0, Lba0;->D:Lo90;

    .line 6
    .line 7
    return-object p0
.end method

.method public final i0()V
    .registers 1

    .line 1
    invoke-virtual {p0}, Lae;->r0()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public final j0()V
    .registers 1

    .line 1
    return-void
.end method

.method public final k0()V
    .registers 1

    .line 1
    invoke-virtual {p0}, Lae;->r0()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public final l0()V
    .registers 1

    .line 1
    invoke-virtual {p0}, Lae;->r0()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public final r0()V
    .registers 3

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-boolean v0, p0, Lae;->t:Z

    .line 3
    .line 4
    iget-object v0, p0, Lae;->s:Lbe;

    .line 5
    .line 6
    const/4 v1, 0x0

    .line 7
    iput-object v1, v0, Lbe;->f:Lpg0;

    .line 8
    .line 9
    invoke-static {p0}, La5;->x(Lds;)V

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method public final z()V
    .registers 1

    .line 1
    invoke-virtual {p0}, Lae;->r0()V

    .line 2
    .line 3
    .line 4
    return-void
.end method
