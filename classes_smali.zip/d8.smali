.class public final Ld8;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lmh0;


# instance fields
.field public final a:Lj8;

.field public b:Z


# direct methods
.method public constructor <init>(Lj8;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Ld8;->a:Lj8;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final a(Lg70;Ljava/util/List;I)I
    .registers 6

    .line 1
    invoke-interface {p2}, Ljava/util/List;->isEmpty()Z

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    const/4 p1, 0x0

    .line 6
    if-eqz p0, :cond_8

    .line 7
    .line 8
    return p1

    .line 9
    :cond_8
    invoke-interface {p2, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    check-cast p0, Lhh0;

    .line 14
    .line 15
    invoke-interface {p0, p3}, Lhh0;->f(I)I

    .line 16
    .line 17
    .line 18
    move-result p0

    .line 19
    invoke-interface {p2}, Ljava/util/List;->size()I

    .line 20
    .line 21
    .line 22
    move-result p1

    .line 23
    const/4 v0, 0x1

    .line 24
    sub-int/2addr p1, v0

    .line 25
    if-gt v0, p1, :cond_2c

    .line 26
    .line 27
    :goto_1a
    invoke-interface {p2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    check-cast v1, Lhh0;

    .line 32
    .line 33
    invoke-interface {v1, p3}, Lhh0;->f(I)I

    .line 34
    .line 35
    .line 36
    move-result v1

    .line 37
    if-le v1, p0, :cond_27

    .line 38
    .line 39
    move p0, v1

    .line 40
    :cond_27
    if-eq v0, p1, :cond_2c

    .line 41
    .line 42
    add-int/lit8 v0, v0, 0x1

    .line 43
    .line 44
    goto :goto_1a

    .line 45
    :cond_2c
    return p0
.end method

.method public final c(Lg70;Ljava/util/List;I)I
    .registers 6

    .line 1
    invoke-interface {p2}, Ljava/util/List;->isEmpty()Z

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    const/4 p1, 0x0

    .line 6
    if-eqz p0, :cond_8

    .line 7
    .line 8
    return p1

    .line 9
    :cond_8
    invoke-interface {p2, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    check-cast p0, Lhh0;

    .line 14
    .line 15
    invoke-interface {p0, p3}, Lhh0;->J(I)I

    .line 16
    .line 17
    .line 18
    move-result p0

    .line 19
    invoke-interface {p2}, Ljava/util/List;->size()I

    .line 20
    .line 21
    .line 22
    move-result p1

    .line 23
    const/4 v0, 0x1

    .line 24
    sub-int/2addr p1, v0

    .line 25
    if-gt v0, p1, :cond_2c

    .line 26
    .line 27
    :goto_1a
    invoke-interface {p2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    check-cast v1, Lhh0;

    .line 32
    .line 33
    invoke-interface {v1, p3}, Lhh0;->J(I)I

    .line 34
    .line 35
    .line 36
    move-result v1

    .line 37
    if-le v1, p0, :cond_27

    .line 38
    .line 39
    move p0, v1

    .line 40
    :cond_27
    if-eq v0, p1, :cond_2c

    .line 41
    .line 42
    add-int/lit8 v0, v0, 0x1

    .line 43
    .line 44
    goto :goto_1a

    .line 45
    :cond_2c
    return p0
.end method

.method public final f(Loh0;Ljava/util/List;J)Lnh0;
    .registers 13

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-interface {p2}, Ljava/util/List;->size()I

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 8
    .line 9
    .line 10
    invoke-interface {p2}, Ljava/util/Collection;->size()I

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    const/4 v2, 0x0

    .line 15
    move v3, v2

    .line 16
    move v4, v3

    .line 17
    :goto_10
    if-ge v2, v1, :cond_2e

    .line 18
    .line 19
    invoke-interface {p2, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v5

    .line 23
    check-cast v5, Lhh0;

    .line 24
    .line 25
    invoke-interface {v5, p3, p4}, Lhh0;->e(J)Lks0;

    .line 26
    .line 27
    .line 28
    move-result-object v5

    .line 29
    iget v6, v5, Lks0;->e:I

    .line 30
    .line 31
    invoke-static {v3, v6}, Ljava/lang/Math;->max(II)I

    .line 32
    .line 33
    .line 34
    move-result v3

    .line 35
    iget v6, v5, Lks0;->f:I

    .line 36
    .line 37
    invoke-static {v4, v6}, Ljava/lang/Math;->max(II)I

    .line 38
    .line 39
    .line 40
    move-result v4

    .line 41
    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 42
    .line 43
    .line 44
    add-int/lit8 v2, v2, 0x1

    .line 45
    .line 46
    goto :goto_10

    .line 47
    :cond_2e
    invoke-interface {p1}, Lg70;->n()Z

    .line 48
    .line 49
    .line 50
    move-result p2

    .line 51
    const-wide p3, 0xffffffffL

    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    const/16 v1, 0x20

    .line 57
    .line 58
    iget-object v2, p0, Ld8;->a:Lj8;

    .line 59
    .line 60
    const/4 v5, 0x1

    .line 61
    if-eqz p2, :cond_51

    .line 62
    .line 63
    iput-boolean v5, p0, Ld8;->b:Z

    .line 64
    .line 65
    iget-object p0, v2, Lj8;->a:Llq0;

    .line 66
    .line 67
    int-to-long v6, v3

    .line 68
    shl-long v1, v6, v1

    .line 69
    .line 70
    int-to-long v6, v4

    .line 71
    and-long/2addr p3, v6

    .line 72
    or-long/2addr p3, v1

    .line 73
    new-instance p2, Lv60;

    .line 74
    .line 75
    invoke-direct {p2, p3, p4}, Lv60;-><init>(J)V

    .line 76
    .line 77
    .line 78
    invoke-virtual {p0, p2}, Llq0;->setValue(Ljava/lang/Object;)V

    .line 79
    .line 80
    .line 81
    goto :goto_65

    .line 82
    :cond_51
    iget-boolean p0, p0, Ld8;->b:Z

    .line 83
    .line 84
    if-nez p0, :cond_65

    .line 85
    .line 86
    iget-object p0, v2, Lj8;->a:Llq0;

    .line 87
    .line 88
    int-to-long v6, v3

    .line 89
    shl-long v1, v6, v1

    .line 90
    .line 91
    int-to-long v6, v4

    .line 92
    and-long/2addr p3, v6

    .line 93
    or-long/2addr p3, v1

    .line 94
    new-instance p2, Lv60;

    .line 95
    .line 96
    invoke-direct {p2, p3, p4}, Lv60;-><init>(J)V

    .line 97
    .line 98
    .line 99
    invoke-virtual {p0, p2}, Llq0;->setValue(Ljava/lang/Object;)V

    .line 100
    .line 101
    .line 102
    :cond_65
    :goto_65
    new-instance p0, Lo5;

    .line 103
    .line 104
    invoke-direct {p0, v5, v0}, Lo5;-><init>(ILjava/util/ArrayList;)V

    .line 105
    .line 106
    .line 107
    sget-object p2, Lvt;->e:Lvt;

    .line 108
    .line 109
    invoke-interface {p1, v3, v4, p2, p0}, Loh0;->O(IILjava/util/Map;Li00;)Lnh0;

    .line 110
    .line 111
    .line 112
    move-result-object p0

    .line 113
    return-object p0
.end method

.method public final g(Lg70;Ljava/util/List;I)I
    .registers 6

    .line 1
    invoke-interface {p2}, Ljava/util/List;->isEmpty()Z

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    const/4 p1, 0x0

    .line 6
    if-eqz p0, :cond_8

    .line 7
    .line 8
    return p1

    .line 9
    :cond_8
    invoke-interface {p2, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    check-cast p0, Lhh0;

    .line 14
    .line 15
    invoke-interface {p0, p3}, Lhh0;->L(I)I

    .line 16
    .line 17
    .line 18
    move-result p0

    .line 19
    invoke-interface {p2}, Ljava/util/List;->size()I

    .line 20
    .line 21
    .line 22
    move-result p1

    .line 23
    const/4 v0, 0x1

    .line 24
    sub-int/2addr p1, v0

    .line 25
    if-gt v0, p1, :cond_2c

    .line 26
    .line 27
    :goto_1a
    invoke-interface {p2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    check-cast v1, Lhh0;

    .line 32
    .line 33
    invoke-interface {v1, p3}, Lhh0;->L(I)I

    .line 34
    .line 35
    .line 36
    move-result v1

    .line 37
    if-le v1, p0, :cond_27

    .line 38
    .line 39
    move p0, v1

    .line 40
    :cond_27
    if-eq v0, p1, :cond_2c

    .line 41
    .line 42
    add-int/lit8 v0, v0, 0x1

    .line 43
    .line 44
    goto :goto_1a

    .line 45
    :cond_2c
    return p0
.end method

.method public final i(Lg70;Ljava/util/List;I)I
    .registers 6

    .line 1
    invoke-interface {p2}, Ljava/util/List;->isEmpty()Z

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    const/4 p1, 0x0

    .line 6
    if-eqz p0, :cond_8

    .line 7
    .line 8
    return p1

    .line 9
    :cond_8
    invoke-interface {p2, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    check-cast p0, Lhh0;

    .line 14
    .line 15
    invoke-interface {p0, p3}, Lhh0;->C(I)I

    .line 16
    .line 17
    .line 18
    move-result p0

    .line 19
    invoke-interface {p2}, Ljava/util/List;->size()I

    .line 20
    .line 21
    .line 22
    move-result p1

    .line 23
    const/4 v0, 0x1

    .line 24
    sub-int/2addr p1, v0

    .line 25
    if-gt v0, p1, :cond_2c

    .line 26
    .line 27
    :goto_1a
    invoke-interface {p2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    check-cast v1, Lhh0;

    .line 32
    .line 33
    invoke-interface {v1, p3}, Lhh0;->C(I)I

    .line 34
    .line 35
    .line 36
    move-result v1

    .line 37
    if-le v1, p0, :cond_27

    .line 38
    .line 39
    move p0, v1

    .line 40
    :cond_27
    if-eq v0, p1, :cond_2c

    .line 41
    .line 42
    add-int/lit8 v0, v0, 0x1

    .line 43
    .line 44
    goto :goto_1a

    .line 45
    :cond_2c
    return p0
.end method
