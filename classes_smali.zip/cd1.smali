.class public final synthetic Lcd1;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Li00;


# instance fields
.field public final synthetic e:Led1;

.field public final synthetic f:F


# direct methods
.method public synthetic constructor <init>(Led1;F)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lcd1;->e:Led1;

    .line 5
    .line 6
    iput p2, p0, Lcd1;->f:F

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final i(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 10

    .line 1
    check-cast p1, Ljava/lang/Long;

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    .line 4
    .line 5
    .line 6
    move-result-wide v0

    .line 7
    iget-object p1, p0, Lcd1;->e:Led1;

    .line 8
    .line 9
    invoke-virtual {p1}, Led1;->g()Z

    .line 10
    .line 11
    .line 12
    move-result v2

    .line 13
    iget-object v3, p1, Led1;->g:Ljq0;

    .line 14
    .line 15
    if-nez v2, :cond_4d

    .line 16
    .line 17
    invoke-virtual {v3}, Ljq0;->g()J

    .line 18
    .line 19
    .line 20
    move-result-wide v4

    .line 21
    const-wide/high16 v6, -0x8000000000000000L

    .line 22
    .line 23
    cmp-long v2, v4, v6

    .line 24
    .line 25
    if-nez v2, :cond_28

    .line 26
    .line 27
    invoke-virtual {v3, v0, v1}, Ljq0;->h(J)V

    .line 28
    .line 29
    .line 30
    iget-object v2, p1, Led1;->a:Lal;

    .line 31
    .line 32
    iget-object v2, v2, Lal;->f:Ljava/lang/Object;

    .line 33
    .line 34
    check-cast v2, Llq0;

    .line 35
    .line 36
    sget-object v4, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 37
    .line 38
    invoke-virtual {v2, v4}, Llq0;->setValue(Ljava/lang/Object;)V

    .line 39
    .line 40
    .line 41
    :cond_28
    invoke-virtual {v3}, Ljq0;->g()J

    .line 42
    .line 43
    .line 44
    move-result-wide v2

    .line 45
    sub-long/2addr v0, v2

    .line 46
    const/4 v2, 0x0

    .line 47
    iget p0, p0, Lcd1;->f:F

    .line 48
    .line 49
    cmpg-float v2, p0, v2

    .line 50
    .line 51
    if-nez v2, :cond_35

    .line 52
    .line 53
    goto :goto_3c

    .line 54
    :cond_35
    long-to-double v0, v0

    .line 55
    float-to-double v3, p0

    .line 56
    div-double/2addr v0, v3

    .line 57
    invoke-static {v0, v1}, Lgh0;->Q(D)J

    .line 58
    .line 59
    .line 60
    move-result-wide v0

    .line 61
    :goto_3c
    iget-object p0, p1, Led1;->b:Led1;

    .line 62
    .line 63
    if-nez p0, :cond_45

    .line 64
    .line 65
    iget-object p0, p1, Led1;->f:Ljq0;

    .line 66
    .line 67
    invoke-virtual {p0, v0, v1}, Ljq0;->h(J)V

    .line 68
    .line 69
    .line 70
    :cond_45
    if-nez v2, :cond_49

    .line 71
    .line 72
    const/4 p0, 0x1

    .line 73
    goto :goto_4a

    .line 74
    :cond_49
    const/4 p0, 0x0

    .line 75
    :goto_4a
    invoke-virtual {p1, v0, v1, p0}, Led1;->h(JZ)V

    .line 76
    .line 77
    .line 78
    :cond_4d
    sget-object p0, Lwe1;->a:Lwe1;

    .line 79
    .line 80
    return-object p0
.end method
