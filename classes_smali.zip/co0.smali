.class public final Lco0;
.super Lxo0;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# static fields
.field public static final c:Lco0;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 1
    new-instance v0, Lco0;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x1

    .line 5
    invoke-direct {v0, v1, v2, v2}, Lxo0;-><init>(III)V

    .line 6
    .line 7
    .line 8
    sput-object v0, Lco0;->c:Lco0;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final a(Lpg;Lm9;La61;Luw0;Lyo0;)V
    .registers 6

    .line 1
    const/4 p0, 0x0

    .line 2
    invoke-virtual {p1, p0}, Lpg;->c(I)Ljava/lang/Object;

    .line 3
    .line 4
    .line 5
    move-result-object p0

    .line 6
    check-cast p0, Lxv0;

    .line 7
    .line 8
    iget-object p1, p4, Luw0;->i:Lhk0;

    .line 9
    .line 10
    if-eqz p1, :cond_2a

    .line 11
    .line 12
    invoke-virtual {p1, p0}, Lhk0;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object p2

    .line 16
    check-cast p2, Lmr0;

    .line 17
    .line 18
    if-eqz p2, :cond_2a

    .line 19
    .line 20
    iget-object p2, p4, Luw0;->j:Ljava/util/ArrayList;

    .line 21
    .line 22
    if-eqz p2, :cond_27

    .line 23
    .line 24
    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    .line 25
    .line 26
    .line 27
    move-result p3

    .line 28
    add-int/lit8 p3, p3, -0x1

    .line 29
    .line 30
    invoke-virtual {p2, p3}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object p2

    .line 34
    check-cast p2, Lqk0;

    .line 35
    .line 36
    if-eqz p2, :cond_27

    .line 37
    .line 38
    iput-object p2, p4, Luw0;->e:Lqk0;

    .line 39
    .line 40
    :cond_27
    invoke-virtual {p1, p0}, Lhk0;->k(Ljava/lang/Object;)Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    :cond_2a
    return-void
.end method
