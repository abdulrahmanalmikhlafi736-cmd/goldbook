.class public final Lcs0;
.super Ll0;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Ljava/util/Set;
.implements Ljava/util/Collection;
.implements Lw80;


# static fields
.field public static final h:Lcs0;


# instance fields
.field public final e:Ljava/lang/Object;

.field public final f:Ljava/lang/Object;

.field public final g:Lrr0;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 1
    new-instance v0, Lcs0;

    .line 2
    .line 3
    sget-object v1, Le3;->L:Le3;

    .line 4
    .line 5
    sget-object v2, Lrr0;->g:Lrr0;

    .line 6
    .line 7
    invoke-direct {v0, v1, v1, v2}, Lcs0;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lrr0;)V

    .line 8
    .line 9
    .line 10
    sput-object v0, Lcs0;->h:Lcs0;

    .line 11
    .line 12
    return-void
.end method

.method public constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Lrr0;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lcs0;->e:Ljava/lang/Object;

    .line 5
    .line 6
    iput-object p2, p0, Lcs0;->f:Ljava/lang/Object;

    .line 7
    .line 8
    iput-object p3, p0, Lcs0;->g:Lrr0;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final a()I
    .registers 1

    .line 1
    iget-object p0, p0, Lcs0;->g:Lrr0;

    .line 2
    .line 3
    iget p0, p0, Lrr0;->f:I

    .line 4
    .line 5
    return p0
.end method

.method public final contains(Ljava/lang/Object;)Z
    .registers 2

    .line 1
    iget-object p0, p0, Lcs0;->g:Lrr0;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Lrr0;->containsKey(Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final iterator()Ljava/util/Iterator;
    .registers 3

    .line 1
    new-instance v0, Lm10;

    .line 2
    .line 3
    iget-object v1, p0, Lcs0;->e:Ljava/lang/Object;

    .line 4
    .line 5
    iget-object p0, p0, Lcs0;->g:Lrr0;

    .line 6
    .line 7
    invoke-direct {v0, v1, p0}, Lm10;-><init>(Ljava/lang/Object;Ljava/util/Map;)V

    .line 8
    .line 9
    .line 10
    return-object v0
.end method
