.class public final Laq;
.super Landroid/app/Dialog;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lsd0;
.implements Lkn0;
.implements Lel0;
.implements Lxz0;


# instance fields
.field public e:Lud0;

.field public final f:Lal;

.field public final g:Lda1;

.field public final h:Lda1;

.field public i:Lxz;

.field public j:Lyp;

.field public final k:Landroid/view/View;

.field public final l:Lxp;

.field public m:Z


# direct methods
.method public constructor <init>(Lxz;Lyp;Landroid/view/View;Lo90;Ljp;Ljava/util/UUID;)V
    .registers 12

    .line 1
    new-instance v0, Landroid/view/ContextThemeWrapper;

    .line 2
    .line 3
    invoke-virtual {p3}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    iget-boolean v2, p2, Lyp;->e:Z

    .line 8
    .line 9
    if-eqz v2, :cond_d

    .line 10
    .line 11
    const/high16 v2, 0x7f0b0000

    .line 12
    .line 13
    goto :goto_10

    .line 14
    :cond_d
    const v2, 0x7f0b0003

    .line 15
    .line 16
    .line 17
    :goto_10
    invoke-direct {v0, v1, v2}, Landroid/view/ContextThemeWrapper;-><init>(Landroid/content/Context;I)V

    .line 18
    .line 19
    .line 20
    const/4 v1, 0x0

    .line 21
    invoke-direct {p0, v0, v1}, Landroid/app/Dialog;-><init>(Landroid/content/Context;I)V

    .line 22
    .line 23
    .line 24
    new-instance v0, Lwz0;

    .line 25
    .line 26
    new-instance v2, Lx1;

    .line 27
    .line 28
    const/16 v3, 0xd

    .line 29
    .line 30
    invoke-direct {v2, v3, p0}, Lx1;-><init>(ILjava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    invoke-direct {v0, p0, v2}, Lwz0;-><init>(Lxz0;Lx1;)V

    .line 34
    .line 35
    .line 36
    new-instance v2, Lal;

    .line 37
    .line 38
    const/16 v3, 0x14

    .line 39
    .line 40
    invoke-direct {v2, v0, v3}, Lal;-><init>(Lwz0;I)V

    .line 41
    .line 42
    .line 43
    iput-object v2, p0, Laq;->f:Lal;

    .line 44
    .line 45
    new-instance v0, Lmi;

    .line 46
    .line 47
    invoke-direct {v0, p0, v1}, Lmi;-><init>(Laq;I)V

    .line 48
    .line 49
    .line 50
    new-instance v2, Lda1;

    .line 51
    .line 52
    invoke-direct {v2, v0}, Lda1;-><init>(Lxz;)V

    .line 53
    .line 54
    .line 55
    iput-object v2, p0, Laq;->g:Lda1;

    .line 56
    .line 57
    new-instance v0, Lmi;

    .line 58
    .line 59
    const/4 v2, 0x1

    .line 60
    invoke-direct {v0, p0, v2}, Lmi;-><init>(Laq;I)V

    .line 61
    .line 62
    .line 63
    new-instance v3, Lda1;

    .line 64
    .line 65
    invoke-direct {v3, v0}, Lda1;-><init>(Lxz;)V

    .line 66
    .line 67
    .line 68
    iput-object v3, p0, Laq;->h:Lda1;

    .line 69
    .line 70
    iput-object p1, p0, Laq;->i:Lxz;

    .line 71
    .line 72
    iput-object p2, p0, Laq;->j:Lyp;

    .line 73
    .line 74
    iput-object p3, p0, Laq;->k:Landroid/view/View;

    .line 75
    .line 76
    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    .line 77
    .line 78
    .line 79
    move-result-object p1

    .line 80
    const/4 p2, 0x0

    .line 81
    if-eqz p1, :cond_14b

    .line 82
    .line 83
    invoke-virtual {p1, v2}, Landroid/view/Window;->requestFeature(I)Z

    .line 84
    .line 85
    .line 86
    const v0, 0x106000d

    .line 87
    .line 88
    .line 89
    invoke-virtual {p1, v0}, Landroid/view/Window;->setBackgroundDrawableResource(I)V

    .line 90
    .line 91
    .line 92
    iget-object v0, p0, Laq;->j:Lyp;

    .line 93
    .line 94
    iget-boolean v0, v0, Lyp;->e:Z

    .line 95
    .line 96
    invoke-static {p1, v0}, Ldd0;->u(Landroid/view/Window;Z)V

    .line 97
    .line 98
    .line 99
    const/16 v0, 0x11

    .line 100
    .line 101
    invoke-virtual {p1, v0}, Landroid/view/Window;->setGravity(I)V

    .line 102
    .line 103
    .line 104
    iget-object v0, p0, Laq;->j:Lyp;

    .line 105
    .line 106
    iget-boolean v0, v0, Lyp;->e:Z

    .line 107
    .line 108
    if-nez v0, :cond_91

    .line 109
    .line 110
    const v0, 0x10100

    .line 111
    .line 112
    .line 113
    invoke-virtual {p1, v0}, Landroid/view/Window;->addFlags(I)V

    .line 114
    .line 115
    .line 116
    invoke-virtual {p1}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    .line 117
    .line 118
    .line 119
    move-result-object v0

    .line 120
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 121
    .line 122
    const/16 v4, 0x1c

    .line 123
    .line 124
    if-lt v3, v4, :cond_82

    .line 125
    .line 126
    sget-object v4, Lc9;->a:Lc9;

    .line 127
    .line 128
    invoke-virtual {v4, v0}, Lc9;->a(Landroid/view/WindowManager$LayoutParams;)V

    .line 129
    .line 130
    .line 131
    :cond_82
    const/16 v4, 0x1e

    .line 132
    .line 133
    if-lt v3, v4, :cond_8e

    .line 134
    .line 135
    sget-object v3, Ld9;->a:Ld9;

    .line 136
    .line 137
    invoke-virtual {v3, v0, v1}, Ld9;->b(Landroid/view/WindowManager$LayoutParams;I)V

    .line 138
    .line 139
    .line 140
    invoke-virtual {v3, v0, v1}, Ld9;->c(Landroid/view/WindowManager$LayoutParams;I)V

    .line 141
    .line 142
    .line 143
    :cond_8e
    invoke-virtual {p1, v0}, Landroid/view/Window;->setAttributes(Landroid/view/WindowManager$LayoutParams;)V

    .line 144
    .line 145
    .line 146
    :cond_91
    new-instance v0, Lxp;

    .line 147
    .line 148
    invoke-virtual {p0}, Landroid/app/Dialog;->getContext()Landroid/content/Context;

    .line 149
    .line 150
    .line 151
    move-result-object v3

    .line 152
    invoke-direct {v0, v3, p1}, Lxp;-><init>(Landroid/content/Context;Landroid/view/Window;)V

    .line 153
    .line 154
    .line 155
    iget-object v3, p0, Laq;->j:Lyp;

    .line 156
    .line 157
    iget-object v3, v3, Lyp;->f:Ljava/lang/String;

    .line 158
    .line 159
    invoke-virtual {p0, v3}, Landroid/app/Dialog;->setTitle(Ljava/lang/CharSequence;)V

    .line 160
    .line 161
    .line 162
    new-instance v3, Ljava/lang/StringBuilder;

    .line 163
    .line 164
    const-string v4, "Dialog:"

    .line 165
    .line 166
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 167
    .line 168
    .line 169
    invoke-virtual {v3, p6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 170
    .line 171
    .line 172
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 173
    .line 174
    .line 175
    move-result-object p6

    .line 176
    const v3, 0x7f050033

    .line 177
    .line 178
    .line 179
    invoke-virtual {v0, v3, p6}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 180
    .line 181
    .line 182
    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->setClipChildren(Z)V

    .line 183
    .line 184
    .line 185
    const/high16 p6, 0x41000000  # 8.0f

    .line 186
    .line 187
    invoke-interface {p5, p6}, Ljp;->q(F)F

    .line 188
    .line 189
    .line 190
    move-result p5

    .line 191
    invoke-virtual {v0, p5}, Landroid/view/View;->setElevation(F)V

    .line 192
    .line 193
    .line 194
    new-instance p5, Lzp;

    .line 195
    .line 196
    invoke-direct {p5, v1}, Lzp;-><init>(I)V

    .line 197
    .line 198
    .line 199
    invoke-virtual {v0, p5}, Landroid/view/View;->setOutlineProvider(Landroid/view/ViewOutlineProvider;)V

    .line 200
    .line 201
    .line 202
    iput-object v0, p0, Laq;->l:Lxp;

    .line 203
    .line 204
    invoke-virtual {p1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 205
    .line 206
    .line 207
    move-result-object p1

    .line 208
    instance-of p5, p1, Landroid/view/ViewGroup;

    .line 209
    .line 210
    if-eqz p5, :cond_d6

    .line 211
    .line 212
    move-object p2, p1

    .line 213
    check-cast p2, Landroid/view/ViewGroup;

    .line 214
    .line 215
    :cond_d6
    if-eqz p2, :cond_db

    .line 216
    .line 217
    invoke-static {p2}, Laq;->e(Landroid/view/ViewGroup;)V

    .line 218
    .line 219
    .line 220
    :cond_db
    invoke-virtual {p0, v0}, Laq;->setContentView(Landroid/view/View;)V

    .line 221
    .line 222
    .line 223
    invoke-static {p3}, Lua0;->o(Landroid/view/View;)Lsd0;

    .line 224
    .line 225
    .line 226
    move-result-object p1

    .line 227
    const p2, 0x7f050075

    .line 228
    .line 229
    .line 230
    invoke-virtual {v0, p2, p1}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 231
    .line 232
    .line 233
    invoke-static {p3}, Ljb0;->j(Landroid/view/View;)Lkh1;

    .line 234
    .line 235
    .line 236
    move-result-object p1

    .line 237
    const p2, 0x7f050079

    .line 238
    .line 239
    .line 240
    invoke-virtual {v0, p2, p1}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 241
    .line 242
    .line 243
    invoke-static {p3}, Lwa0;->j(Landroid/view/View;)Lxz0;

    .line 244
    .line 245
    .line 246
    move-result-object p1

    .line 247
    const p2, 0x7f050078

    .line 248
    .line 249
    .line 250
    invoke-virtual {v0, p2, p1}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 251
    .line 252
    .line 253
    iget-object p1, p0, Laq;->i:Lxz;

    .line 254
    .line 255
    iget-object p2, p0, Laq;->j:Lyp;

    .line 256
    .line 257
    invoke-virtual {p0, p1, p2, p4}, Laq;->i(Lxz;Lyp;Lo90;)V

    .line 258
    .line 259
    .line 260
    invoke-virtual {p0}, Laq;->b()Ljn0;

    .line 261
    .line 262
    .line 263
    move-result-object p1

    .line 264
    new-instance p2, Ll5;

    .line 265
    .line 266
    invoke-direct {p2, p0, v2}, Ll5;-><init>(Laq;I)V

    .line 267
    .line 268
    .line 269
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 270
    .line 271
    .line 272
    new-instance p3, Lsa;

    .line 273
    .line 274
    invoke-direct {p3, p2}, Lsa;-><init>(Ll5;)V

    .line 275
    .line 276
    .line 277
    invoke-virtual {p0}, Laq;->f()Lud0;

    .line 278
    .line 279
    .line 280
    move-result-object p2

    .line 281
    iget-object p4, p2, Lud0;->d:Ljd0;

    .line 282
    .line 283
    sget-object p5, Ljd0;->e:Ljd0;

    .line 284
    .line 285
    if-ne p4, p5, :cond_11f

    .line 286
    .line 287
    return-void

    .line 288
    :cond_11f
    new-instance p4, Lfn0;

    .line 289
    .line 290
    invoke-direct {p4, p3, p0}, Lfn0;-><init>(Lsa;Lsd0;)V

    .line 291
    .line 292
    .line 293
    new-instance p0, Len0;

    .line 294
    .line 295
    invoke-direct {p0, p3, p4}, Len0;-><init>(Lsa;Lfn0;)V

    .line 296
    .line 297
    .line 298
    iget-object p4, p3, Lsa;->a:Ljava/util/ArrayList;

    .line 299
    .line 300
    invoke-virtual {p4, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 301
    .line 302
    .line 303
    invoke-virtual {p0, v1}, Len0;->g(Z)V

    .line 304
    .line 305
    .line 306
    invoke-virtual {p1}, Ljn0;->a()Lp3;

    .line 307
    .line 308
    .line 309
    move-result-object p4

    .line 310
    invoke-static {p4, p0}, Lp3;->b(Lp3;Lfl0;)V

    .line 311
    .line 312
    .line 313
    new-instance p4, Lto;

    .line 314
    .line 315
    invoke-direct {p4, p0, p1, p2}, Lto;-><init>(Len0;Ljn0;Lud0;)V

    .line 316
    .line 317
    .line 318
    invoke-virtual {p2, p4}, Lud0;->a(Lrd0;)V

    .line 319
    .line 320
    .line 321
    new-instance p0, Lgn0;

    .line 322
    .line 323
    invoke-direct {p0, p2, p4}, Lgn0;-><init>(Lud0;Lto;)V

    .line 324
    .line 325
    .line 326
    iget-object p1, p3, Lsa;->c:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 327
    .line 328
    invoke-virtual {p1, p0}, Ljava/util/concurrent/CopyOnWriteArrayList;->add(Ljava/lang/Object;)Z

    .line 329
    .line 330
    .line 331
    return-void

    .line 332
    :cond_14b
    const-string p0, "Dialog has no window"

    .line 333
    .line 334
    invoke-static {p0}, Lod;->p(Ljava/lang/String;)V

    .line 335
    .line 336
    .line 337
    throw p2
.end method

.method public static d(Laq;)V
    .registers 1

    .line 1
    invoke-super {p0}, Landroid/app/Dialog;->onBackPressed()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static final e(Landroid/view/ViewGroup;)V
    .registers 5

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->setClipChildren(Z)V

    .line 3
    .line 4
    .line 5
    instance-of v1, p0, Lxp;

    .line 6
    .line 7
    if-eqz v1, :cond_9

    .line 8
    .line 9
    goto :goto_23

    .line 10
    :cond_9
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    :goto_d
    if-ge v0, v1, :cond_23

    .line 15
    .line 16
    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 17
    .line 18
    .line 19
    move-result-object v2

    .line 20
    instance-of v3, v2, Landroid/view/ViewGroup;

    .line 21
    .line 22
    if-eqz v3, :cond_1a

    .line 23
    .line 24
    check-cast v2, Landroid/view/ViewGroup;

    .line 25
    .line 26
    goto :goto_1b

    .line 27
    :cond_1a
    const/4 v2, 0x0

    .line 28
    :goto_1b
    if-eqz v2, :cond_20

    .line 29
    .line 30
    invoke-static {v2}, Laq;->e(Landroid/view/ViewGroup;)V

    .line 31
    .line 32
    .line 33
    :cond_20
    add-int/lit8 v0, v0, 0x1

    .line 34
    .line 35
    goto :goto_d

    .line 36
    :cond_23
    :goto_23
    return-void
.end method


# virtual methods
.method public final a()Lp3;
    .registers 1

    .line 1
    invoke-virtual {p0}, Laq;->b()Ljn0;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    invoke-virtual {p0}, Ljn0;->a()Lp3;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    return-object p0
.end method

.method public final addContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    .registers 3

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Laq;->h()V

    .line 5
    .line 6
    .line 7
    invoke-super {p0, p1, p2}, Landroid/app/Dialog;->addContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public final b()Ljn0;
    .registers 1

    .line 1
    iget-object p0, p0, Laq;->h:Lda1;

    .line 2
    .line 3
    invoke-virtual {p0}, Lda1;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Ljn0;

    .line 8
    .line 9
    return-object p0
.end method

.method public final c()Lal;
    .registers 1

    .line 1
    iget-object p0, p0, Laq;->f:Lal;

    .line 2
    .line 3
    iget-object p0, p0, Lal;->g:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast p0, Lal;

    .line 6
    .line 7
    return-object p0
.end method

.method public final cancel()V
    .registers 1

    .line 1
    return-void
.end method

.method public final f()Lud0;
    .registers 3

    .line 1
    iget-object v0, p0, Laq;->e:Lud0;

    .line 2
    .line 3
    if-nez v0, :cond_c

    .line 4
    .line 5
    new-instance v0, Lud0;

    .line 6
    .line 7
    const/4 v1, 0x1

    .line 8
    invoke-direct {v0, p0, v1}, Lud0;-><init>(Lsd0;Z)V

    .line 9
    .line 10
    .line 11
    iput-object v0, p0, Laq;->e:Lud0;

    .line 12
    .line 13
    :cond_c
    return-object v0
.end method

.method public final g()Lud0;
    .registers 1

    .line 1
    invoke-virtual {p0}, Laq;->f()Lud0;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public final h()V
    .registers 3

    .line 1
    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    .line 7
    .line 8
    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13
    .line 14
    .line 15
    const v1, 0x7f050075

    .line 16
    .line 17
    .line 18
    invoke-virtual {v0, v1, p0}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 19
    .line 20
    .line 21
    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 26
    .line 27
    .line 28
    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 33
    .line 34
    .line 35
    const v1, 0x7f050077

    .line 36
    .line 37
    .line 38
    invoke-virtual {v0, v1, p0}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 39
    .line 40
    .line 41
    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 46
    .line 47
    .line 48
    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 53
    .line 54
    .line 55
    const v1, 0x7f050078

    .line 56
    .line 57
    .line 58
    invoke-virtual {v0, v1, p0}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 59
    .line 60
    .line 61
    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    .line 62
    .line 63
    .line 64
    move-result-object v0

    .line 65
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 66
    .line 67
    .line 68
    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 69
    .line 70
    .line 71
    move-result-object v0

    .line 72
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 73
    .line 74
    .line 75
    const v1, 0x7f050076

    .line 76
    .line 77
    .line 78
    invoke-virtual {v0, v1, p0}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 79
    .line 80
    .line 81
    return-void
.end method

.method public final i(Lxz;Lyp;Lo90;)V
    .registers 10

    .line 1
    iput-object p1, p0, Laq;->i:Lxz;

    .line 2
    .line 3
    iput-object p2, p0, Laq;->j:Lyp;

    .line 4
    .line 5
    iget-object p1, p2, Lyp;->c:Lz11;

    .line 6
    .line 7
    sget v0, Lu6;->a:I

    .line 8
    .line 9
    iget-object v0, p0, Laq;->k:Landroid/view/View;

    .line 10
    .line 11
    invoke-virtual {v0}, Landroid/view/View;->getRootView()Landroid/view/View;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    instance-of v1, v0, Landroid/view/WindowManager$LayoutParams;

    .line 20
    .line 21
    if-eqz v1, :cond_19

    .line 22
    .line 23
    check-cast v0, Landroid/view/WindowManager$LayoutParams;

    .line 24
    .line 25
    goto :goto_1a

    .line 26
    :cond_19
    const/4 v0, 0x0

    .line 27
    :goto_1a
    const/4 v1, 0x1

    .line 28
    const/16 v2, 0x2000

    .line 29
    .line 30
    const/4 v3, 0x0

    .line 31
    if-eqz v0, :cond_27

    .line 32
    .line 33
    iget v0, v0, Landroid/view/WindowManager$LayoutParams;->flags:I

    .line 34
    .line 35
    and-int/2addr v0, v2

    .line 36
    if-eqz v0, :cond_27

    .line 37
    .line 38
    move v0, v1

    .line 39
    goto :goto_28

    .line 40
    :cond_27
    move v0, v3

    .line 41
    :goto_28
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 42
    .line 43
    .line 44
    move-result p1

    .line 45
    if-eqz p1, :cond_3a

    .line 46
    .line 47
    if-eq p1, v1, :cond_39

    .line 48
    .line 49
    const/4 v0, 0x2

    .line 50
    if-ne p1, v0, :cond_35

    .line 51
    .line 52
    move v0, v3

    .line 53
    goto :goto_3a

    .line 54
    :cond_35
    invoke-static {}, Lod;->k()V

    .line 55
    .line 56
    .line 57
    return-void

    .line 58
    :cond_39
    move v0, v1

    .line 59
    :cond_3a
    :goto_3a
    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    .line 60
    .line 61
    .line 62
    move-result-object p1

    .line 63
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 64
    .line 65
    .line 66
    if-eqz v0, :cond_45

    .line 67
    .line 68
    move v0, v2

    .line 69
    goto :goto_47

    .line 70
    :cond_45
    const/16 v0, -0x2001

    .line 71
    .line 72
    :goto_47
    invoke-virtual {p1, v0, v2}, Landroid/view/Window;->setFlags(II)V

    .line 73
    .line 74
    .line 75
    invoke-virtual {p3}, Ljava/lang/Enum;->ordinal()I

    .line 76
    .line 77
    .line 78
    move-result p1

    .line 79
    if-eqz p1, :cond_58

    .line 80
    .line 81
    if-ne p1, v1, :cond_54

    .line 82
    .line 83
    move p1, v1

    .line 84
    goto :goto_59

    .line 85
    :cond_54
    invoke-static {}, Lod;->k()V

    .line 86
    .line 87
    .line 88
    return-void

    .line 89
    :cond_58
    move p1, v3

    .line 90
    :goto_59
    iget-object p3, p0, Laq;->l:Lxp;

    .line 91
    .line 92
    invoke-virtual {p3, p1}, Landroid/view/View;->setLayoutDirection(I)V

    .line 93
    .line 94
    .line 95
    iget-boolean p1, p2, Lyp;->e:Z

    .line 96
    .line 97
    iget-boolean v0, p2, Lyp;->d:Z

    .line 98
    .line 99
    iget-object v2, p3, Lxp;->n:Landroid/view/Window;

    .line 100
    .line 101
    iget-boolean v4, p3, Lxp;->r:Z

    .line 102
    .line 103
    if-eqz v4, :cond_73

    .line 104
    .line 105
    iget-boolean v4, p3, Lxp;->p:Z

    .line 106
    .line 107
    if-ne v0, v4, :cond_73

    .line 108
    .line 109
    iget-boolean v4, p3, Lxp;->q:Z

    .line 110
    .line 111
    if-eq p1, v4, :cond_71

    .line 112
    .line 113
    goto :goto_73

    .line 114
    :cond_71
    move v4, v3

    .line 115
    goto :goto_74

    .line 116
    :cond_73
    :goto_73
    move v4, v1

    .line 117
    :goto_74
    iput-boolean v0, p3, Lxp;->p:Z

    .line 118
    .line 119
    iput-boolean p1, p3, Lxp;->q:Z

    .line 120
    .line 121
    if-eqz v4, :cond_91

    .line 122
    .line 123
    invoke-virtual {v2}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    .line 124
    .line 125
    .line 126
    move-result-object v4

    .line 127
    const/4 v5, -0x2

    .line 128
    if-eqz v0, :cond_83

    .line 129
    .line 130
    move v0, v5

    .line 131
    goto :goto_84

    .line 132
    :cond_83
    const/4 v0, -0x1

    .line 133
    :goto_84
    iget v4, v4, Landroid/view/WindowManager$LayoutParams;->width:I

    .line 134
    .line 135
    if-ne v0, v4, :cond_8c

    .line 136
    .line 137
    iget-boolean v4, p3, Lxp;->r:Z

    .line 138
    .line 139
    if-nez v4, :cond_91

    .line 140
    .line 141
    :cond_8c
    invoke-virtual {v2, v0, v5}, Landroid/view/Window;->setLayout(II)V

    .line 142
    .line 143
    .line 144
    iput-boolean v1, p3, Lxp;->r:Z

    .line 145
    .line 146
    :cond_91
    iget-boolean p2, p2, Lyp;->b:Z

    .line 147
    .line 148
    invoke-virtual {p0, p2}, Landroid/app/Dialog;->setCanceledOnTouchOutside(Z)V

    .line 149
    .line 150
    .line 151
    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    .line 152
    .line 153
    .line 154
    move-result-object p0

    .line 155
    if-eqz p0, :cond_ad

    .line 156
    .line 157
    if-eqz p1, :cond_9f

    .line 158
    .line 159
    goto :goto_aa

    .line 160
    :cond_9f
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 161
    .line 162
    const/16 p2, 0x1f

    .line 163
    .line 164
    if-ge p1, p2, :cond_a8

    .line 165
    .line 166
    const/16 v3, 0x10

    .line 167
    .line 168
    goto :goto_aa

    .line 169
    :cond_a8
    const/16 v3, 0x30

    .line 170
    .line 171
    :goto_aa
    invoke-virtual {p0, v3}, Landroid/view/Window;->setSoftInputMode(I)V

    .line 172
    .line 173
    .line 174
    :cond_ad
    return-void
.end method

.method public final onBackPressed()V
    .registers 1

    .line 1
    iget-object p0, p0, Laq;->g:Lda1;

    .line 2
    .line 3
    invoke-virtual {p0}, Lda1;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Lcq;

    .line 8
    .line 9
    invoke-virtual {p0}, Lhl0;->a()V

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .registers 4

    .line 1
    invoke-super {p0, p1}, Landroid/app/Dialog;->onCreate(Landroid/os/Bundle;)V

    .line 2
    .line 3
    .line 4
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 5
    .line 6
    const/16 v1, 0x21

    .line 7
    .line 8
    if-lt v0, v1, :cond_17

    .line 9
    .line 10
    invoke-virtual {p0}, Laq;->b()Ljn0;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    invoke-static {p0}, Le1;->h(Laq;)Landroid/window/OnBackInvokedDispatcher;

    .line 15
    .line 16
    .line 17
    move-result-object v1

    .line 18
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 19
    .line 20
    .line 21
    invoke-virtual {v0, v1}, Ljn0;->b(Landroid/window/OnBackInvokedDispatcher;)V

    .line 22
    .line 23
    .line 24
    :cond_17
    iget-object v0, p0, Laq;->f:Lal;

    .line 25
    .line 26
    invoke-virtual {v0, p1}, Lal;->q(Landroid/os/Bundle;)V

    .line 27
    .line 28
    .line 29
    invoke-virtual {p0}, Laq;->f()Lud0;

    .line 30
    .line 31
    .line 32
    move-result-object p0

    .line 33
    sget-object p1, Lid0;->ON_CREATE:Lid0;

    .line 34
    .line 35
    invoke-virtual {p0, p1}, Lud0;->d(Lid0;)V

    .line 36
    .line 37
    .line 38
    return-void
.end method

.method public final onKeyUp(ILandroid/view/KeyEvent;)Z
    .registers 4

    .line 1
    iget-object v0, p0, Laq;->j:Lyp;

    .line 2
    .line 3
    iget-boolean v0, v0, Lyp;->a:Z

    .line 4
    .line 5
    if-eqz v0, :cond_1d

    .line 6
    .line 7
    invoke-virtual {p2}, Landroid/view/KeyEvent;->isTracking()Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_1d

    .line 12
    .line 13
    invoke-virtual {p2}, Landroid/view/KeyEvent;->isCanceled()Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-nez v0, :cond_1d

    .line 18
    .line 19
    const/16 v0, 0x6f

    .line 20
    .line 21
    if-ne p1, v0, :cond_1d

    .line 22
    .line 23
    iget-object p0, p0, Laq;->i:Lxz;

    .line 24
    .line 25
    invoke-interface {p0}, Lxz;->a()Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    const/4 p0, 0x1

    .line 29
    return p0

    .line 30
    :cond_1d
    invoke-super {p0, p1, p2}, Landroid/app/Dialog;->onKeyUp(ILandroid/view/KeyEvent;)Z

    .line 31
    .line 32
    .line 33
    move-result p0

    .line 34
    return p0
.end method

.method public final onSaveInstanceState()Landroid/os/Bundle;
    .registers 2

    .line 1
    invoke-super {p0}, Landroid/app/Dialog;->onSaveInstanceState()Landroid/os/Bundle;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    .line 7
    .line 8
    iget-object p0, p0, Laq;->f:Lal;

    .line 9
    .line 10
    invoke-virtual {p0, v0}, Lal;->r(Landroid/os/Bundle;)V

    .line 11
    .line 12
    .line 13
    return-object v0
.end method

.method public final onStart()V
    .registers 2

    .line 1
    invoke-super {p0}, Landroid/app/Dialog;->onStart()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Laq;->f()Lud0;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    sget-object v0, Lid0;->ON_RESUME:Lid0;

    .line 9
    .line 10
    invoke-virtual {p0, v0}, Lud0;->d(Lid0;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public final onStop()V
    .registers 3

    .line 1
    invoke-virtual {p0}, Laq;->f()Lud0;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    sget-object v1, Lid0;->ON_DESTROY:Lid0;

    .line 6
    .line 7
    invoke-virtual {v0, v1}, Lud0;->d(Lid0;)V

    .line 8
    .line 9
    .line 10
    const/4 v0, 0x0

    .line 11
    iput-object v0, p0, Laq;->e:Lud0;

    .line 12
    .line 13
    invoke-super {p0}, Landroid/app/Dialog;->onStop()V

    .line 14
    .line 15
    .line 16
    return-void
.end method

.method public final onTouchEvent(Landroid/view/MotionEvent;)Z
    .registers 11

    .line 1
    invoke-super {p0, p1}, Landroid/app/Dialog;->onTouchEvent(Landroid/view/MotionEvent;)Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    iget-object v1, p0, Laq;->j:Lyp;

    .line 6
    .line 7
    iget-boolean v1, v1, Lyp;->b:Z

    .line 8
    .line 9
    const/4 v2, 0x3

    .line 10
    const/4 v3, 0x0

    .line 11
    const/4 v4, 0x1

    .line 12
    if-eqz v1, :cond_86

    .line 13
    .line 14
    iget-object v1, p0, Laq;->l:Lxp;

    .line 15
    .line 16
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 17
    .line 18
    .line 19
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    .line 20
    .line 21
    .line 22
    move-result v5

    .line 23
    invoke-static {v5}, Ljava/lang/Math;->abs(F)F

    .line 24
    .line 25
    .line 26
    move-result v5

    .line 27
    const v6, 0x7f7fffff  # Float.MAX_VALUE

    .line 28
    .line 29
    .line 30
    cmpg-float v5, v5, v6

    .line 31
    .line 32
    if-gtz v5, :cond_69

    .line 33
    .line 34
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    .line 35
    .line 36
    .line 37
    move-result v5

    .line 38
    invoke-static {v5}, Ljava/lang/Math;->abs(F)F

    .line 39
    .line 40
    .line 41
    move-result v5

    .line 42
    cmpg-float v5, v5, v6

    .line 43
    .line 44
    if-gtz v5, :cond_69

    .line 45
    .line 46
    invoke-virtual {v1, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 47
    .line 48
    .line 49
    move-result-object v5

    .line 50
    if-nez v5, :cond_34

    .line 51
    .line 52
    goto :goto_69

    .line 53
    :cond_34
    invoke-virtual {v1}, Landroid/view/View;->getLeft()I

    .line 54
    .line 55
    .line 56
    move-result v6

    .line 57
    invoke-virtual {v5}, Landroid/view/View;->getLeft()I

    .line 58
    .line 59
    .line 60
    move-result v7

    .line 61
    add-int/2addr v7, v6

    .line 62
    invoke-virtual {v5}, Landroid/view/View;->getWidth()I

    .line 63
    .line 64
    .line 65
    move-result v6

    .line 66
    add-int/2addr v6, v7

    .line 67
    invoke-virtual {v1}, Landroid/view/View;->getTop()I

    .line 68
    .line 69
    .line 70
    move-result v1

    .line 71
    invoke-virtual {v5}, Landroid/view/View;->getTop()I

    .line 72
    .line 73
    .line 74
    move-result v8

    .line 75
    add-int/2addr v8, v1

    .line 76
    invoke-virtual {v5}, Landroid/view/View;->getHeight()I

    .line 77
    .line 78
    .line 79
    move-result v1

    .line 80
    add-int/2addr v1, v8

    .line 81
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    .line 82
    .line 83
    .line 84
    move-result v5

    .line 85
    invoke-static {v5}, Lgh0;->P(F)I

    .line 86
    .line 87
    .line 88
    move-result v5

    .line 89
    if-gt v7, v5, :cond_69

    .line 90
    .line 91
    if-gt v5, v6, :cond_69

    .line 92
    .line 93
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    .line 94
    .line 95
    .line 96
    move-result v5

    .line 97
    invoke-static {v5}, Lgh0;->P(F)I

    .line 98
    .line 99
    .line 100
    move-result v5

    .line 101
    if-gt v8, v5, :cond_69

    .line 102
    .line 103
    if-gt v5, v1, :cond_69

    .line 104
    .line 105
    goto :goto_86

    .line 106
    :cond_69
    :goto_69
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    .line 107
    .line 108
    .line 109
    move-result p1

    .line 110
    if-eqz p1, :cond_83

    .line 111
    .line 112
    if-eq p1, v4, :cond_77

    .line 113
    .line 114
    if-eq p1, v2, :cond_74

    .line 115
    .line 116
    goto :goto_90

    .line 117
    :cond_74
    iput-boolean v3, p0, Laq;->m:Z

    .line 118
    .line 119
    return v0

    .line 120
    :cond_77
    iget-boolean p1, p0, Laq;->m:Z

    .line 121
    .line 122
    if-eqz p1, :cond_90

    .line 123
    .line 124
    iget-object p1, p0, Laq;->i:Lxz;

    .line 125
    .line 126
    invoke-interface {p1}, Lxz;->a()Ljava/lang/Object;

    .line 127
    .line 128
    .line 129
    iput-boolean v3, p0, Laq;->m:Z

    .line 130
    .line 131
    return v4

    .line 132
    :cond_83
    iput-boolean v4, p0, Laq;->m:Z

    .line 133
    .line 134
    return v4

    .line 135
    :cond_86
    :goto_86
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    .line 136
    .line 137
    .line 138
    move-result p1

    .line 139
    if-eqz p1, :cond_91

    .line 140
    .line 141
    if-eq p1, v4, :cond_91

    .line 142
    .line 143
    if-eq p1, v2, :cond_91

    .line 144
    .line 145
    :cond_90
    :goto_90
    return v0

    .line 146
    :cond_91
    iput-boolean v3, p0, Laq;->m:Z

    .line 147
    .line 148
    return v0
.end method

.method public final setContentView(I)V
    .registers 2

    .line 11
    invoke-virtual {p0}, Laq;->h()V

    .line 12
    invoke-super {p0, p1}, Landroid/app/Dialog;->setContentView(I)V

    return-void
.end method

.method public final setContentView(Landroid/view/View;)V
    .registers 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Laq;->h()V

    .line 5
    .line 6
    .line 7
    invoke-super {p0, p1}, Landroid/app/Dialog;->setContentView(Landroid/view/View;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public final setContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    .registers 3

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13
    invoke-virtual {p0}, Laq;->h()V

    .line 14
    invoke-super {p0, p1, p2}, Landroid/app/Dialog;->setContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method
