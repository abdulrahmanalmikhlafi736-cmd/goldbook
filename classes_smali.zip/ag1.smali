.class public final Lag1;
.super Lwp0;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# instance fields
.field public final e:Llq0;

.field public final f:Llq0;

.field public final g:Lwf1;

.field public final h:Llq0;

.field public i:F

.field public j:Lpb;


# direct methods
.method public constructor <init>(Ls20;)V
    .registers 5

    .line 1
    invoke-direct {p0}, Lwp0;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Ls51;

    .line 5
    .line 6
    const-wide/16 v1, 0x0

    .line 7
    .line 8
    invoke-direct {v0, v1, v2}, Ls51;-><init>(J)V

    .line 9
    .line 10
    .line 11
    invoke-static {v0}, Lmc0;->t(Ljava/lang/Object;)Llq0;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    iput-object v0, p0, Lag1;->e:Llq0;

    .line 16
    .line 17
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 18
    .line 19
    invoke-static {v0}, Lmc0;->t(Ljava/lang/Object;)Llq0;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    iput-object v0, p0, Lag1;->f:Llq0;

    .line 24
    .line 25
    new-instance v0, Lwf1;

    .line 26
    .line 27
    invoke-direct {v0, p1}, Lwf1;-><init>(Ls20;)V

    .line 28
    .line 29
    .line 30
    new-instance p1, Lf8;

    .line 31
    .line 32
    const/16 v1, 0xd

    .line 33
    .line 34
    invoke-direct {p1, v1, p0}, Lf8;-><init>(ILjava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    iput-object p1, v0, Lwf1;->f:Lxz;

    .line 38
    .line 39
    iput-object v0, p0, Lag1;->g:Lwf1;

    .line 40
    .line 41
    sget-object p1, Le3;->X:Le3;

    .line 42
    .line 43
    new-instance v0, Llq0;

    .line 44
    .line 45
    sget-object v1, Lwe1;->a:Lwe1;

    .line 46
    .line 47
    invoke-direct {v0, v1, p1}, Llq0;-><init>(Ljava/lang/Object;Lt61;)V

    .line 48
    .line 49
    .line 50
    iput-object v0, p0, Lag1;->h:Llq0;

    .line 51
    .line 52
    const/high16 p1, 0x3f800000  # 1.0f

    .line 53
    .line 54
    iput p1, p0, Lag1;->i:F

    .line 55
    .line 56
    return-void
.end method


# virtual methods
.method public final a(F)V
    .registers 2

    .line 1
    iput p1, p0, Lag1;->i:F

    .line 2
    .line 3
    return-void
.end method

.method public final b(Lpb;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lag1;->j:Lpb;

    .line 2
    .line 3
    return-void
.end method

.method public final d()J
    .registers 3

    .line 1
    iget-object p0, p0, Lag1;->e:Llq0;

    .line 2
    .line 3
    invoke-virtual {p0}, Llq0;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Ls51;

    .line 8
    .line 9
    iget-wide v0, p0, Ls51;->a:J

    .line 10
    .line 11
    return-wide v0
.end method

.method public final e(Lda0;)V
    .registers 12

    .line 1
    iget-object v0, p1, Lda0;->e:Lte;

    .line 2
    .line 3
    iget-object v1, p0, Lag1;->j:Lpb;

    .line 4
    .line 5
    iget-object v2, p0, Lag1;->g:Lwf1;

    .line 6
    .line 7
    if-nez v1, :cond_10

    .line 8
    .line 9
    iget-object v1, v2, Lwf1;->g:Llq0;

    .line 10
    .line 11
    invoke-virtual {v1}, Llq0;->getValue()Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    check-cast v1, Lpb;

    .line 16
    .line 17
    :cond_10
    iget-object v3, p0, Lag1;->f:Llq0;

    .line 18
    .line 19
    invoke-virtual {v3}, Llq0;->getValue()Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v3

    .line 23
    check-cast v3, Ljava/lang/Boolean;

    .line 24
    .line 25
    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    .line 26
    .line 27
    .line 28
    move-result v3

    .line 29
    if-eqz v3, :cond_5e

    .line 30
    .line 31
    invoke-virtual {p1}, Lda0;->getLayoutDirection()Lo90;

    .line 32
    .line 33
    .line 34
    move-result-object v3

    .line 35
    sget-object v4, Lo90;->f:Lo90;

    .line 36
    .line 37
    if-ne v3, v4, :cond_5e

    .line 38
    .line 39
    invoke-virtual {v0}, Lte;->e()J

    .line 40
    .line 41
    .line 42
    move-result-wide v3

    .line 43
    iget-object v0, v0, Lte;->f:Lk9;

    .line 44
    .line 45
    invoke-virtual {v0}, Lk9;->t()J

    .line 46
    .line 47
    .line 48
    move-result-wide v5

    .line 49
    invoke-virtual {v0}, Lk9;->q()Lre;

    .line 50
    .line 51
    .line 52
    move-result-object v7

    .line 53
    invoke-interface {v7}, Lre;->i()V

    .line 54
    .line 55
    .line 56
    :try_start_37
    iget-object v7, v0, Lk9;->f:Ljava/lang/Object;

    .line 57
    .line 58
    check-cast v7, Lpg0;

    .line 59
    .line 60
    const/high16 v8, -0x40800000  # -1.0f

    .line 61
    .line 62
    const/high16 v9, 0x3f800000  # 1.0f

    .line 63
    .line 64
    invoke-virtual {v7, v8, v9, v3, v4}, Lpg0;->C(FFJ)V

    .line 65
    .line 66
    .line 67
    iget v3, p0, Lag1;->i:F

    .line 68
    .line 69
    invoke-virtual {v2, p1, v3, v1}, Lwf1;->e(Les;FLpb;)V
    :try_end_47
    .catchall {:try_start_37 .. :try_end_47} :catchall_52

    .line 70
    .line 71
    .line 72
    invoke-virtual {v0}, Lk9;->q()Lre;

    .line 73
    .line 74
    .line 75
    move-result-object p1

    .line 76
    invoke-interface {p1}, Lre;->g()V

    .line 77
    .line 78
    .line 79
    invoke-virtual {v0, v5, v6}, Lk9;->E(J)V

    .line 80
    .line 81
    .line 82
    goto :goto_63

    .line 83
    :catchall_52
    move-exception p0

    .line 84
    invoke-virtual {v0}, Lk9;->q()Lre;

    .line 85
    .line 86
    .line 87
    move-result-object p1

    .line 88
    invoke-interface {p1}, Lre;->g()V

    .line 89
    .line 90
    .line 91
    invoke-virtual {v0, v5, v6}, Lk9;->E(J)V

    .line 92
    .line 93
    .line 94
    throw p0

    .line 95
    :cond_5e
    iget v0, p0, Lag1;->i:F

    .line 96
    .line 97
    invoke-virtual {v2, p1, v0, v1}, Lwf1;->e(Les;FLpb;)V

    .line 98
    .line 99
    .line 100
    :goto_63
    iget-object p0, p0, Lag1;->h:Llq0;

    .line 101
    .line 102
    invoke-virtual {p0}, Llq0;->getValue()Ljava/lang/Object;

    .line 103
    .line 104
    .line 105
    return-void
.end method
