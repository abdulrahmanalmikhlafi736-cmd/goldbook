.class public abstract Ld51;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Lhp0;

    .line 2
    .line 3
    const/16 v1, 0xb

    .line 4
    .line 5
    invoke-direct {v0, v1}, Lhp0;-><init>(I)V

    .line 6
    .line 7
    .line 8
    new-instance v1, Lad0;

    .line 9
    .line 10
    invoke-direct {v1, v0}, Lad0;-><init>(Lxz;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public static final a(La51;Ld10;)Ly41;
    .registers 8

    .line 1
    sget-object v0, Lfh0;->a:Lk81;

    .line 2
    .line 3
    invoke-virtual {p1, v0}, Ld10;->j(Llv0;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    check-cast p1, Ldh0;

    .line 8
    .line 9
    iget-object p1, p1, Ldh0;->c:Lc51;

    .line 10
    .line 11
    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    .line 12
    .line 13
    .line 14
    move-result p0

    .line 15
    packed-switch p0, :pswitch_data_64

    .line 16
    .line 17
    .line 18
    invoke-static {}, Lod;->k()V

    .line 19
    .line 20
    .line 21
    const/4 p0, 0x0

    .line 22
    return-object p0

    .line 23
    :pswitch_16  #0xe
    iget-object p0, p1, Lc51;->b:Loy0;

    .line 24
    .line 25
    return-object p0

    .line 26
    :pswitch_19  #0xd
    sget-object p0, Lvn;->j:Lk30;

    .line 27
    .line 28
    return-object p0

    .line 29
    :pswitch_1c  #0xc
    iget-object p0, p1, Lc51;->c:Loy0;

    .line 30
    .line 31
    return-object p0

    .line 32
    :pswitch_1f  #0xb
    iget-object p0, p1, Lc51;->d:Loy0;

    .line 33
    .line 34
    invoke-static {p0}, Ld51;->b(Loy0;)Loy0;

    .line 35
    .line 36
    .line 37
    move-result-object p0

    .line 38
    return-object p0

    .line 39
    :pswitch_26  #0xa
    iget-object v0, p1, Lc51;->d:Loy0;

    .line 40
    .line 41
    sget-object v2, Lz41;->i:Lcr;

    .line 42
    .line 43
    const/4 v4, 0x0

    .line 44
    const/16 v5, 0x9

    .line 45
    .line 46
    const/4 v1, 0x0

    .line 47
    move-object v3, v2

    .line 48
    invoke-static/range {v0 .. v5}, Loy0;->b(Loy0;Lpl;Lpl;Lpl;Lpl;I)Loy0;

    .line 49
    .line 50
    .line 51
    move-result-object p0

    .line 52
    return-object p0

    .line 53
    :pswitch_34  #0x9
    iget-object p0, p1, Lc51;->f:Loy0;

    .line 54
    .line 55
    return-object p0

    .line 56
    :pswitch_37  #0x8
    iget-object v0, p1, Lc51;->d:Loy0;

    .line 57
    .line 58
    sget-object v1, Lz41;->i:Lcr;

    .line 59
    .line 60
    const/4 v3, 0x0

    .line 61
    const/4 v5, 0x6

    .line 62
    const/4 v2, 0x0

    .line 63
    move-object v4, v1

    .line 64
    invoke-static/range {v0 .. v5}, Loy0;->b(Loy0;Lpl;Lpl;Lpl;Lpl;I)Loy0;

    .line 65
    .line 66
    .line 67
    move-result-object p0

    .line 68
    return-object p0

    .line 69
    :pswitch_44  #0x7
    iget-object p0, p1, Lc51;->d:Loy0;

    .line 70
    .line 71
    return-object p0

    .line 72
    :pswitch_47  #0x6
    sget-object p0, Lpy0;->a:Loy0;

    .line 73
    .line 74
    return-object p0

    .line 75
    :pswitch_4a  #0x5
    iget-object p0, p1, Lc51;->a:Loy0;

    .line 76
    .line 77
    invoke-static {p0}, Ld51;->b(Loy0;)Loy0;

    .line 78
    .line 79
    .line 80
    move-result-object p0

    .line 81
    return-object p0

    .line 82
    :pswitch_51  #0x4
    iget-object p0, p1, Lc51;->a:Loy0;

    .line 83
    .line 84
    return-object p0

    .line 85
    :pswitch_54  #0x3
    iget-object p0, p1, Lc51;->e:Loy0;

    .line 86
    .line 87
    invoke-static {p0}, Ld51;->b(Loy0;)Loy0;

    .line 88
    .line 89
    .line 90
    move-result-object p0

    .line 91
    return-object p0

    .line 92
    :pswitch_5b  #0x2
    iget-object p0, p1, Lc51;->g:Loy0;

    .line 93
    .line 94
    return-object p0

    .line 95
    :pswitch_5e  #0x1
    iget-object p0, p1, Lc51;->e:Loy0;

    .line 96
    .line 97
    return-object p0

    .line 98
    :pswitch_61  #0x0
    iget-object p0, p1, Lc51;->h:Loy0;

    .line 99
    .line 100
    return-object p0

    .line 101
    :pswitch_data_64
    .packed-switch 0x0
        :pswitch_61  #00000000
        :pswitch_5e  #00000001
        :pswitch_5b  #00000002
        :pswitch_54  #00000003
        :pswitch_51  #00000004
        :pswitch_4a  #00000005
        :pswitch_47  #00000006
        :pswitch_44  #00000007
        :pswitch_37  #00000008
        :pswitch_34  #00000009
        :pswitch_26  #0000000a
        :pswitch_1f  #0000000b
        :pswitch_1c  #0000000c
        :pswitch_19  #0000000d
        :pswitch_16  #0000000e
    .end packed-switch
.end method

.method public static b(Loy0;)Loy0;
    .registers 7

    .line 1
    sget-object v3, Lz41;->i:Lcr;

    .line 2
    .line 3
    const/4 v2, 0x0

    .line 4
    const/4 v5, 0x3

    .line 5
    const/4 v1, 0x0

    .line 6
    move-object v4, v3

    .line 7
    move-object v0, p0

    .line 8
    invoke-static/range {v0 .. v5}, Loy0;->b(Loy0;Lpl;Lpl;Lpl;Lpl;I)Loy0;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method
