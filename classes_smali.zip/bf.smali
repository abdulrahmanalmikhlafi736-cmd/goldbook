.class public final Lbf;
.super Laf;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# virtual methods
.method public final a(Lsl;ILgd;)Laf;
    .registers 5

    .line 1
    new-instance v0, Lbf;

    .line 2
    .line 3
    iget-object p0, p0, Laf;->h:Ltw;

    .line 4
    .line 5
    invoke-direct {v0, p0, p1, p2, p3}, Laf;-><init>(Ltw;Lsl;ILgd;)V

    .line 6
    .line 7
    .line 8
    return-object v0
.end method

.method public final d()Ltw;
    .registers 1

    .line 1
    iget-object p0, p0, Laf;->h:Ltw;

    .line 2
    .line 3
    return-object p0
.end method

.method public final e(Luw;Lml;)Ljava/lang/Object;
    .registers 3

    .line 1
    iget-object p0, p0, Laf;->h:Ltw;

    .line 2
    .line 3
    invoke-interface {p0, p1, p2}, Ltw;->b(Luw;Lml;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    sget-object p1, Lcm;->e:Lcm;

    .line 8
    .line 9
    if-ne p0, p1, :cond_b

    .line 10
    .line 11
    return-object p0

    .line 12
    :cond_b
    sget-object p0, Lwe1;->a:Lwe1;

    .line 13
    .line 14
    return-object p0
.end method
