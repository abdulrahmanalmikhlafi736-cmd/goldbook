.class public final Lcf;
.super Lu91;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lm00;


# instance fields
.field public final synthetic i:I

.field public j:I

.field public synthetic k:Ljava/lang/Object;

.field public final synthetic l:Lff;

.field public final synthetic m:Luw;


# direct methods
.method public constructor <init>(Lff;Luw;Ljava/lang/Object;Lml;)V
    .registers 6

    .line 1
    const/4 v0, 0x0

    .line 2
    iput v0, p0, Lcf;->i:I

    .line 3
    .line 4
    iput-object p1, p0, Lcf;->l:Lff;

    .line 5
    .line 6
    iput-object p2, p0, Lcf;->m:Luw;

    .line 7
    .line 8
    iput-object p3, p0, Lcf;->k:Ljava/lang/Object;

    .line 9
    .line 10
    const/4 p1, 0x2

    .line 11
    invoke-direct {p0, p1, p4}, Lu91;-><init>(ILml;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method public constructor <init>(Lff;Luw;Lml;)V
    .registers 5

    const/4 v0, 0x1

    iput v0, p0, Lcf;->i:I

    .line 15
    iput-object p1, p0, Lcf;->l:Lff;

    iput-object p2, p0, Lcf;->m:Luw;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p3}, Lu91;-><init>(ILml;)V

    return-void
.end method


# virtual methods
.method public final f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 1
    iget v0, p0, Lcf;->i:I

    .line 2
    .line 3
    sget-object v1, Lwe1;->a:Lwe1;

    .line 4
    .line 5
    check-cast p1, Lbm;

    .line 6
    .line 7
    check-cast p2, Lml;

    .line 8
    .line 9
    packed-switch v0, :pswitch_data_22

    .line 10
    .line 11
    .line 12
    invoke-virtual {p0, p2, p1}, Lcf;->n(Lml;Ljava/lang/Object;)Lml;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    check-cast p0, Lcf;

    .line 17
    .line 18
    invoke-virtual {p0, v1}, Lcf;->p(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    return-object p0

    .line 23
    :pswitch_16  #0x0
    invoke-virtual {p0, p2, p1}, Lcf;->n(Lml;Ljava/lang/Object;)Lml;

    .line 24
    .line 25
    .line 26
    move-result-object p0

    .line 27
    check-cast p0, Lcf;

    .line 28
    .line 29
    invoke-virtual {p0, v1}, Lcf;->p(Ljava/lang/Object;)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object p0

    .line 33
    return-object p0

    .line 34
    nop

    .line 35
    :pswitch_data_22
    .packed-switch 0x0
        :pswitch_16  #00000000
    .end packed-switch
.end method

.method public final n(Lml;Ljava/lang/Object;)Lml;
    .registers 6

    .line 1
    iget v0, p0, Lcf;->i:I

    .line 2
    .line 3
    iget-object v1, p0, Lcf;->m:Luw;

    .line 4
    .line 5
    iget-object v2, p0, Lcf;->l:Lff;

    .line 6
    .line 7
    packed-switch v0, :pswitch_data_1a

    .line 8
    .line 9
    .line 10
    new-instance p0, Lcf;

    .line 11
    .line 12
    invoke-direct {p0, v2, v1, p1}, Lcf;-><init>(Lff;Luw;Lml;)V

    .line 13
    .line 14
    .line 15
    iput-object p2, p0, Lcf;->k:Ljava/lang/Object;

    .line 16
    .line 17
    return-object p0

    .line 18
    :pswitch_11  #0x0
    new-instance p2, Lcf;

    .line 19
    .line 20
    iget-object p0, p0, Lcf;->k:Ljava/lang/Object;

    .line 21
    .line 22
    invoke-direct {p2, v2, v1, p0, p1}, Lcf;-><init>(Lff;Luw;Ljava/lang/Object;Lml;)V

    .line 23
    .line 24
    .line 25
    return-object p2

    .line 26
    nop

    .line 27
    :pswitch_data_1a
    .packed-switch 0x0
        :pswitch_11  #00000000
    .end packed-switch
.end method

.method public final p(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 14

    .line 1
    iget v0, p0, Lcf;->i:I

    .line 2
    .line 3
    sget-object v1, Lwe1;->a:Lwe1;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    const-string v3, "call to \'resume\' before \'invoke\' with coroutine"

    .line 7
    .line 8
    sget-object v4, Lcm;->e:Lcm;

    .line 9
    .line 10
    const/4 v5, 0x1

    .line 11
    packed-switch v0, :pswitch_data_64

    .line 12
    .line 13
    .line 14
    iget v0, p0, Lcf;->j:I

    .line 15
    .line 16
    if-eqz v0, :cond_1c

    .line 17
    .line 18
    if-ne v0, v5, :cond_17

    .line 19
    .line 20
    invoke-static {p1}, Lnb0;->t(Ljava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    goto :goto_3e

    .line 24
    :cond_17
    invoke-static {v3}, Lod;->p(Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    move-object v1, v2

    .line 28
    goto :goto_3e

    .line 29
    :cond_1c
    invoke-static {p1}, Lnb0;->t(Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    iget-object p1, p0, Lcf;->k:Ljava/lang/Object;

    .line 33
    .line 34
    move-object v8, p1

    .line 35
    check-cast v8, Lbm;

    .line 36
    .line 37
    new-instance v7, Lnw0;

    .line 38
    .line 39
    invoke-direct {v7}, Ljava/lang/Object;-><init>()V

    .line 40
    .line 41
    .line 42
    iget-object v9, p0, Lcf;->l:Lff;

    .line 43
    .line 44
    iget-object p1, v9, Laf;->h:Ltw;

    .line 45
    .line 46
    new-instance v6, Lef;

    .line 47
    .line 48
    iget-object v10, p0, Lcf;->m:Luw;

    .line 49
    .line 50
    const/4 v11, 0x0

    .line 51
    invoke-direct/range {v6 .. v11}, Lef;-><init>(Ljava/io/Serializable;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 52
    .line 53
    .line 54
    iput v5, p0, Lcf;->j:I

    .line 55
    .line 56
    invoke-interface {p1, v6, p0}, Ltw;->b(Luw;Lml;)Ljava/lang/Object;

    .line 57
    .line 58
    .line 59
    move-result-object p0

    .line 60
    if-ne p0, v4, :cond_3e

    .line 61
    .line 62
    move-object v1, v4

    .line 63
    :cond_3e
    :goto_3e
    return-object v1

    .line 64
    :pswitch_3f  #0x0
    iget v0, p0, Lcf;->j:I

    .line 65
    .line 66
    if-eqz v0, :cond_4e

    .line 67
    .line 68
    if-ne v0, v5, :cond_49

    .line 69
    .line 70
    invoke-static {p1}, Lnb0;->t(Ljava/lang/Object;)V

    .line 71
    .line 72
    .line 73
    goto :goto_62

    .line 74
    :cond_49
    invoke-static {v3}, Lod;->p(Ljava/lang/String;)V

    .line 75
    .line 76
    .line 77
    move-object v1, v2

    .line 78
    goto :goto_62

    .line 79
    :cond_4e
    invoke-static {p1}, Lnb0;->t(Ljava/lang/Object;)V

    .line 80
    .line 81
    .line 82
    iget-object p1, p0, Lcf;->l:Lff;

    .line 83
    .line 84
    iget-object p1, p1, Lff;->i:Ln00;

    .line 85
    .line 86
    iget-object v0, p0, Lcf;->k:Ljava/lang/Object;

    .line 87
    .line 88
    iput v5, p0, Lcf;->j:I

    .line 89
    .line 90
    iget-object v2, p0, Lcf;->m:Luw;

    .line 91
    .line 92
    invoke-interface {p1, v2, v0, p0}, Ln00;->c(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 93
    .line 94
    .line 95
    move-result-object p0

    .line 96
    if-ne p0, v4, :cond_62

    .line 97
    .line 98
    move-object v1, v4

    .line 99
    :cond_62
    :goto_62
    return-object v1

    .line 100
    nop

    .line 101
    :pswitch_data_64
    .packed-switch 0x0
        :pswitch_3f  #00000000
    .end packed-switch
.end method
