.class public final synthetic Le5;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic e:I

.field public final synthetic f:Ljava/lang/Object;

.field public final synthetic g:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Object;)V
    .registers 4

    .line 1
    iput p1, p0, Le5;->e:I

    .line 2
    .line 3
    iput-object p2, p0, Le5;->f:Ljava/lang/Object;

    .line 4
    .line 5
    iput-object p3, p0, Le5;->g:Ljava/lang/Object;

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final run()V
    .registers 4

    .line 1
    iget v0, p0, Le5;->e:I

    .line 2
    .line 3
    iget-object v1, p0, Le5;->g:Ljava/lang/Object;

    .line 4
    .line 5
    iget-object p0, p0, Le5;->f:Ljava/lang/Object;

    .line 6
    .line 7
    packed-switch v0, :pswitch_data_36

    .line 8
    .line 9
    .line 10
    check-cast p0, Lpl1;

    .line 11
    .line 12
    check-cast v1, Lud0;

    .line 13
    .line 14
    iget-boolean v0, p0, Lpl1;->g:Z

    .line 15
    .line 16
    if-nez v0, :cond_16

    .line 17
    .line 18
    iput-object v1, p0, Lpl1;->h:Lud0;

    .line 19
    .line 20
    invoke-virtual {v1, p0}, Lud0;->a(Lrd0;)V

    .line 21
    .line 22
    .line 23
    :cond_16
    return-void

    .line 24
    :pswitch_17  #0x2
    check-cast p0, Lne;

    .line 25
    .line 26
    check-cast v1, Lw20;

    .line 27
    .line 28
    invoke-virtual {p0, v1}, Lne;->E(Lul;)V

    .line 29
    .line 30
    .line 31
    return-void

    .line 32
    :pswitch_1f  #0x1
    check-cast p0, Lcom/almekhlafi/goldbook/MainActivity;

    .line 33
    .line 34
    check-cast v1, Ljn0;

    .line 35
    .line 36
    iget-object v0, p0, Lji;->e:Lud0;

    .line 37
    .line 38
    new-instance v2, Lbi;

    .line 39
    .line 40
    invoke-direct {v2, v1, p0}, Lbi;-><init>(Ljn0;Lki;)V

    .line 41
    .line 42
    .line 43
    invoke-virtual {v0, v2}, Lud0;->a(Lrd0;)V

    .line 44
    .line 45
    .line 46
    return-void

    .line 47
    :pswitch_2e  #0x0
    check-cast p0, Lh5;

    .line 48
    .line 49
    check-cast v1, Landroid/util/LongSparseArray;

    .line 50
    .line 51
    invoke-static {p0, v1}, Lvd1;->k(Lh5;Landroid/util/LongSparseArray;)V

    .line 52
    .line 53
    .line 54
    return-void

    .line 55
    :pswitch_data_36
    .packed-switch 0x0
        :pswitch_2e  #00000000
        :pswitch_1f  #00000001
        :pswitch_17  #00000002
    .end packed-switch
.end method
