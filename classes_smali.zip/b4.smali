.class public final Lb4;
.super Lli0;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lqc;
.implements Lg21;
.implements Lf90;
.implements Lt90;
.implements Lkd1;


# instance fields
.field public final s:Lj3;

.field public final synthetic t:Ln4;


# direct methods
.method public constructor <init>(Ln4;)V
    .registers 3

    .line 1
    iput-object p1, p0, Lb4;->t:Ln4;

    .line 2
    .line 3
    invoke-direct {p0}, Lli0;-><init>()V

    .line 4
    .line 5
    .line 6
    new-instance p1, Lj3;

    .line 7
    .line 8
    const/4 v0, 0x2

    .line 9
    invoke-direct {p1, v0, p0}, Lj3;-><init>(ILjava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    iput-object p1, p0, Lb4;->s:Lj3;

    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final synthetic G(Lbg0;Lhh0;I)I
    .registers 4

    .line 1
    invoke-static {p0, p1, p2, p3}, Lfu0;->i(Lt90;Lg70;Lhh0;I)I

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    return p0
.end method

.method public final I(Landroid/view/KeyEvent;)Z
    .registers 9

    .line 1
    sget-object v0, Lay;->a:[I

    .line 2
    .line 3
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    invoke-static {v0}, Lac;->b(I)J

    .line 8
    .line 9
    .line 10
    move-result-wide v0

    .line 11
    sget-wide v2, Ld90;->b:J

    .line 12
    .line 13
    invoke-static {v0, v1, v2, v3}, Ld90;->a(JJ)Z

    .line 14
    .line 15
    .line 16
    move-result v2

    .line 17
    const/4 v3, 0x1

    .line 18
    const/4 v4, 0x2

    .line 19
    if-eqz v2, :cond_1b

    .line 20
    .line 21
    new-instance v0, Lux;

    .line 22
    .line 23
    invoke-direct {v0, v4}, Lux;-><init>(I)V

    .line 24
    .line 25
    .line 26
    goto/16 :goto_cd

    .line 27
    .line 28
    :cond_1b
    sget-wide v5, Ld90;->c:J

    .line 29
    .line 30
    invoke-static {v0, v1, v5, v6}, Ld90;->a(JJ)Z

    .line 31
    .line 32
    .line 33
    move-result v2

    .line 34
    if-eqz v2, :cond_2a

    .line 35
    .line 36
    new-instance v0, Lux;

    .line 37
    .line 38
    invoke-direct {v0, v3}, Lux;-><init>(I)V

    .line 39
    .line 40
    .line 41
    goto/16 :goto_cd

    .line 42
    .line 43
    :cond_2a
    sget-wide v5, Ld90;->i:J

    .line 44
    .line 45
    invoke-static {v0, v1, v5, v6}, Ld90;->a(JJ)Z

    .line 46
    .line 47
    .line 48
    move-result v2

    .line 49
    if-eqz v2, :cond_43

    .line 50
    .line 51
    invoke-virtual {p1}, Landroid/view/KeyEvent;->isShiftPressed()Z

    .line 52
    .line 53
    .line 54
    move-result v0

    .line 55
    if-eqz v0, :cond_3a

    .line 56
    .line 57
    move v0, v4

    .line 58
    goto :goto_3b

    .line 59
    :cond_3a
    move v0, v3

    .line 60
    :goto_3b
    new-instance v1, Lux;

    .line 61
    .line 62
    invoke-direct {v1, v0}, Lux;-><init>(I)V

    .line 63
    .line 64
    .line 65
    move-object v0, v1

    .line 66
    goto/16 :goto_cd

    .line 67
    .line 68
    :cond_43
    sget-wide v5, Ld90;->g:J

    .line 69
    .line 70
    invoke-static {v0, v1, v5, v6}, Ld90;->a(JJ)Z

    .line 71
    .line 72
    .line 73
    move-result v2

    .line 74
    if-eqz v2, :cond_53

    .line 75
    .line 76
    new-instance v0, Lux;

    .line 77
    .line 78
    const/4 v1, 0x4

    .line 79
    invoke-direct {v0, v1}, Lux;-><init>(I)V

    .line 80
    .line 81
    .line 82
    goto/16 :goto_cd

    .line 83
    .line 84
    :cond_53
    sget-wide v5, Ld90;->f:J

    .line 85
    .line 86
    invoke-static {v0, v1, v5, v6}, Ld90;->a(JJ)Z

    .line 87
    .line 88
    .line 89
    move-result v2

    .line 90
    if-eqz v2, :cond_63

    .line 91
    .line 92
    new-instance v0, Lux;

    .line 93
    .line 94
    const/4 v1, 0x3

    .line 95
    invoke-direct {v0, v1}, Lux;-><init>(I)V

    .line 96
    .line 97
    .line 98
    goto/16 :goto_cd

    .line 99
    .line 100
    :cond_63
    sget-wide v5, Ld90;->d:J

    .line 101
    .line 102
    invoke-static {v0, v1, v5, v6}, Ld90;->a(JJ)Z

    .line 103
    .line 104
    .line 105
    move-result v2

    .line 106
    if-nez v2, :cond_c7

    .line 107
    .line 108
    sget-wide v5, Ld90;->m:J

    .line 109
    .line 110
    invoke-static {v0, v1, v5, v6}, Ld90;->a(JJ)Z

    .line 111
    .line 112
    .line 113
    move-result v2

    .line 114
    if-eqz v2, :cond_74

    .line 115
    .line 116
    goto :goto_c7

    .line 117
    :cond_74
    sget-wide v5, Ld90;->e:J

    .line 118
    .line 119
    invoke-static {v0, v1, v5, v6}, Ld90;->a(JJ)Z

    .line 120
    .line 121
    .line 122
    move-result v2

    .line 123
    if-nez v2, :cond_c0

    .line 124
    .line 125
    sget-wide v5, Ld90;->n:J

    .line 126
    .line 127
    invoke-static {v0, v1, v5, v6}, Ld90;->a(JJ)Z

    .line 128
    .line 129
    .line 130
    move-result v2

    .line 131
    if-eqz v2, :cond_85

    .line 132
    .line 133
    goto :goto_c0

    .line 134
    :cond_85
    sget-wide v5, Ld90;->h:J

    .line 135
    .line 136
    invoke-static {v0, v1, v5, v6}, Ld90;->a(JJ)Z

    .line 137
    .line 138
    .line 139
    move-result v2

    .line 140
    if-nez v2, :cond_b9

    .line 141
    .line 142
    sget-wide v5, Ld90;->k:J

    .line 143
    .line 144
    invoke-static {v0, v1, v5, v6}, Ld90;->a(JJ)Z

    .line 145
    .line 146
    .line 147
    move-result v2

    .line 148
    if-nez v2, :cond_b9

    .line 149
    .line 150
    sget-wide v5, Ld90;->o:J

    .line 151
    .line 152
    invoke-static {v0, v1, v5, v6}, Ld90;->a(JJ)Z

    .line 153
    .line 154
    .line 155
    move-result v2

    .line 156
    if-eqz v2, :cond_9e

    .line 157
    .line 158
    goto :goto_b9

    .line 159
    :cond_9e
    sget-wide v5, Ld90;->a:J

    .line 160
    .line 161
    invoke-static {v0, v1, v5, v6}, Ld90;->a(JJ)Z

    .line 162
    .line 163
    .line 164
    move-result v2

    .line 165
    if-nez v2, :cond_b1

    .line 166
    .line 167
    sget-wide v5, Ld90;->l:J

    .line 168
    .line 169
    invoke-static {v0, v1, v5, v6}, Ld90;->a(JJ)Z

    .line 170
    .line 171
    .line 172
    move-result v0

    .line 173
    if-eqz v0, :cond_af

    .line 174
    .line 175
    goto :goto_b1

    .line 176
    :cond_af
    const/4 v0, 0x0

    .line 177
    goto :goto_cd

    .line 178
    :cond_b1
    :goto_b1
    new-instance v0, Lux;

    .line 179
    .line 180
    const/16 v1, 0x8

    .line 181
    .line 182
    invoke-direct {v0, v1}, Lux;-><init>(I)V

    .line 183
    .line 184
    .line 185
    goto :goto_cd

    .line 186
    :cond_b9
    :goto_b9
    new-instance v0, Lux;

    .line 187
    .line 188
    const/4 v1, 0x7

    .line 189
    invoke-direct {v0, v1}, Lux;-><init>(I)V

    .line 190
    .line 191
    .line 192
    goto :goto_cd

    .line 193
    :cond_c0
    :goto_c0
    new-instance v0, Lux;

    .line 194
    .line 195
    const/4 v1, 0x6

    .line 196
    invoke-direct {v0, v1}, Lux;-><init>(I)V

    .line 197
    .line 198
    .line 199
    goto :goto_cd

    .line 200
    :cond_c7
    :goto_c7
    new-instance v0, Lux;

    .line 201
    .line 202
    const/4 v1, 0x5

    .line 203
    invoke-direct {v0, v1}, Lux;-><init>(I)V

    .line 204
    .line 205
    .line 206
    :goto_cd
    const/4 v1, 0x0

    .line 207
    if-eqz v0, :cond_14a

    .line 208
    .line 209
    iget v2, v0, Lux;->a:I

    .line 210
    .line 211
    invoke-static {p1}, La5;->v(Landroid/view/KeyEvent;)I

    .line 212
    .line 213
    .line 214
    move-result p1

    .line 215
    if-ne p1, v4, :cond_14a

    .line 216
    .line 217
    iget-object p0, p0, Lb4;->t:Ln4;

    .line 218
    .line 219
    invoke-virtual {p0}, Ln4;->getFocusOwner()Ley;

    .line 220
    .line 221
    .line 222
    move-result-object p1

    .line 223
    check-cast p1, Lhy;

    .line 224
    .line 225
    invoke-virtual {p1}, Lhy;->f()Lry;

    .line 226
    .line 227
    .line 228
    move-result-object p1

    .line 229
    if-eqz p1, :cond_f1

    .line 230
    .line 231
    iget-boolean p1, p1, Lry;->s:Z

    .line 232
    .line 233
    if-ne p1, v3, :cond_f1

    .line 234
    .line 235
    invoke-virtual {p0, v2}, Ln4;->z(I)Z

    .line 236
    .line 237
    .line 238
    move-result p1

    .line 239
    if-eqz p1, :cond_f1

    .line 240
    .line 241
    goto :goto_10e

    .line 242
    :cond_f1
    invoke-virtual {p0}, Ln4;->getEmbeddedViewFocusRect()Lgw0;

    .line 243
    .line 244
    .line 245
    move-result-object p1

    .line 246
    invoke-virtual {p0}, Ln4;->getFocusOwner()Ley;

    .line 247
    .line 248
    .line 249
    move-result-object v5

    .line 250
    new-instance v6, Lj3;

    .line 251
    .line 252
    invoke-direct {v6, v3, v0}, Lj3;-><init>(ILjava/lang/Object;)V

    .line 253
    .line 254
    .line 255
    check-cast v5, Lhy;

    .line 256
    .line 257
    invoke-virtual {v5, v2, p1, v6}, Lhy;->e(ILgw0;Li00;)Ljava/lang/Boolean;

    .line 258
    .line 259
    .line 260
    move-result-object p1

    .line 261
    if-eqz p1, :cond_10b

    .line 262
    .line 263
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 264
    .line 265
    .line 266
    move-result p1

    .line 267
    goto :goto_10c

    .line 268
    :cond_10b
    move p1, v3

    .line 269
    :goto_10c
    if-eqz p1, :cond_10f

    .line 270
    .line 271
    :goto_10e
    return v3

    .line 272
    :cond_10f
    if-ne v2, v3, :cond_112

    .line 273
    .line 274
    goto :goto_116

    .line 275
    :cond_112
    if-ne v2, v4, :cond_115

    .line 276
    .line 277
    goto :goto_116

    .line 278
    :cond_115
    move v3, v1

    .line 279
    :goto_116
    if-eqz v3, :cond_14a

    .line 280
    .line 281
    invoke-static {v2}, Lay;->c(I)Ljava/lang/Integer;

    .line 282
    .line 283
    .line 284
    move-result-object p1

    .line 285
    if-eqz p1, :cond_122

    .line 286
    .line 287
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 288
    .line 289
    .line 290
    move-result v4

    .line 291
    :cond_122
    invoke-static {}, Landroid/view/FocusFinder;->getInstance()Landroid/view/FocusFinder;

    .line 292
    .line 293
    .line 294
    move-result-object p1

    .line 295
    invoke-virtual {p0}, Landroid/view/View;->getRootView()Landroid/view/View;

    .line 296
    .line 297
    .line 298
    move-result-object v0

    .line 299
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 300
    .line 301
    .line 302
    check-cast v0, Landroid/view/ViewGroup;

    .line 303
    .line 304
    invoke-virtual {p0}, Ln4;->getView()Landroid/view/View;

    .line 305
    .line 306
    .line 307
    move-result-object v3

    .line 308
    invoke-virtual {p1, v0, v3, v4}, Landroid/view/FocusFinder;->findNextFocus(Landroid/view/ViewGroup;Landroid/view/View;I)Landroid/view/View;

    .line 309
    .line 310
    .line 311
    move-result-object p1

    .line 312
    if-eqz p1, :cond_13f

    .line 313
    .line 314
    invoke-virtual {p1, p0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 315
    .line 316
    .line 317
    move-result p1

    .line 318
    if-eqz p1, :cond_14a

    .line 319
    .line 320
    :cond_13f
    invoke-virtual {p0}, Ln4;->getFocusOwner()Ley;

    .line 321
    .line 322
    .line 323
    move-result-object p0

    .line 324
    check-cast p0, Lhy;

    .line 325
    .line 326
    invoke-virtual {p0, v2}, Lhy;->g(I)Z

    .line 327
    .line 328
    .line 329
    move-result p0

    .line 330
    return p0

    .line 331
    :cond_14a
    return v1
.end method

.method public final Q(Lr21;)V
    .registers 2

    .line 1
    return-void
.end method

.method public final synthetic S()Z
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public final synthetic T()Z
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public final U(Loh0;Lhh0;J)Lnh0;
    .registers 11

    .line 1
    invoke-interface {p2, p3, p4}, Lhh0;->e(J)Lks0;

    .line 2
    .line 3
    .line 4
    move-result-object p2

    .line 5
    iget v1, p2, Lks0;->e:I

    .line 6
    .line 7
    iget v2, p2, Lks0;->f:I

    .line 8
    .line 9
    new-instance v5, La4;

    .line 10
    .line 11
    const/4 p3, 0x0

    .line 12
    invoke-direct {v5, p2, p3}, La4;-><init>(Lks0;I)V

    .line 13
    .line 14
    .line 15
    sget-object v3, Lvt;->e:Lvt;

    .line 16
    .line 17
    iget-object v4, p0, Lb4;->s:Lj3;

    .line 18
    .line 19
    move-object v0, p1

    .line 20
    invoke-interface/range {v0 .. v5}, Loh0;->E(IILjava/util/Map;Li00;Li00;)Lnh0;

    .line 21
    .line 22
    .line 23
    move-result-object p0

    .line 24
    return-object p0
.end method

.method public final W(Lgm0;Lg4;Lu91;)Ljava/lang/Object;
    .registers 6

    .line 1
    const-wide/16 v0, 0x0

    .line 2
    .line 3
    invoke-virtual {p1, v0, v1}, Lgm0;->B(J)J

    .line 4
    .line 5
    .line 6
    move-result-wide v0

    .line 7
    invoke-virtual {p2}, Lg4;->a()Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object p1

    .line 11
    check-cast p1, Lgw0;

    .line 12
    .line 13
    if-eqz p1, :cond_13

    .line 14
    .line 15
    invoke-virtual {p1, v0, v1}, Lgw0;->e(J)Lgw0;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    goto :goto_14

    .line 20
    :cond_13
    const/4 p1, 0x0

    .line 21
    :goto_14
    if-eqz p1, :cond_2d

    .line 22
    .line 23
    new-instance p2, Landroid/graphics/Rect;

    .line 24
    .line 25
    iget p3, p1, Lgw0;->a:F

    .line 26
    .line 27
    float-to-int p3, p3

    .line 28
    iget v0, p1, Lgw0;->b:F

    .line 29
    .line 30
    float-to-int v0, v0

    .line 31
    iget v1, p1, Lgw0;->c:F

    .line 32
    .line 33
    float-to-int v1, v1

    .line 34
    iget p1, p1, Lgw0;->d:F

    .line 35
    .line 36
    float-to-int p1, p1

    .line 37
    invoke-direct {p2, p3, v0, v1, p1}, Landroid/graphics/Rect;-><init>(IIII)V

    .line 38
    .line 39
    .line 40
    const/4 p1, 0x0

    .line 41
    iget-object p0, p0, Lb4;->t:Ln4;

    .line 42
    .line 43
    invoke-virtual {p0, p2, p1}, Landroid/view/View;->requestRectangleOnScreen(Landroid/graphics/Rect;Z)Z

    .line 44
    .line 45
    .line 46
    :cond_2d
    sget-object p0, Lwe1;->a:Lwe1;

    .line 47
    .line 48
    return-object p0
.end method

.method public final synthetic d(Lbg0;Lhh0;I)I
    .registers 4

    .line 1
    invoke-static {p0, p1, p2, p3}, Lfu0;->d(Lt90;Lg70;Lhh0;I)I

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    return p0
.end method

.method public final synthetic e()Z
    .registers 1

    .line 1
    const/4 p0, 0x1

    .line 2
    return p0
.end method

.method public final synthetic h(Lbg0;Lhh0;I)I
    .registers 4

    .line 1
    invoke-static {p0, p1, p2, p3}, Lfu0;->b(Lt90;Lg70;Lhh0;I)I

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    return p0
.end method

.method public final j()Ljava/lang/Object;
    .registers 1

    .line 1
    const-string p0, "androidx.compose.ui.layout.WindowInsetsRulers"

    .line 2
    .line 3
    return-object p0
.end method

.method public final synthetic t(Lbg0;Lhh0;I)I
    .registers 4

    .line 1
    invoke-static {p0, p1, p2, p3}, Lfu0;->g(Lt90;Lg70;Lhh0;I)I

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    return p0
.end method
