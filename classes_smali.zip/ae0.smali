.class public final Lae0;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public e:Ljava/lang/Runnable;

.field public final synthetic f:Lbe0;


# direct methods
.method public constructor <init>(Lbe0;Ljava/lang/Runnable;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lae0;->f:Lbe0;

    .line 5
    .line 6
    iput-object p2, p0, Lae0;->e:Ljava/lang/Runnable;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final run()V
    .registers 4

    .line 1
    const/4 v0, 0x0

    .line 2
    :cond_1
    :try_start_1
    iget-object v1, p0, Lae0;->e:Ljava/lang/Runnable;

    .line 3
    .line 4
    invoke-interface {v1}, Ljava/lang/Runnable;->run()V
    :try_end_6
    .catchall {:try_start_1 .. :try_end_6} :catchall_7

    .line 5
    .line 6
    .line 7
    goto :goto_d

    .line 8
    :catchall_7
    move-exception v1

    .line 9
    :try_start_8
    sget-object v2, Lst;->e:Lst;

    .line 10
    .line 11
    invoke-static {v2, v1}, Lgh0;->z(Lsl;Ljava/lang/Throwable;)V

    .line 12
    .line 13
    .line 14
    :goto_d
    iget-object v1, p0, Lae0;->f:Lbe0;

    .line 15
    .line 16
    invoke-virtual {v1}, Lbe0;->j()Ljava/lang/Runnable;

    .line 17
    .line 18
    .line 19
    move-result-object v1

    .line 20
    if-nez v1, :cond_16

    .line 21
    .line 22
    goto :goto_2f

    .line 23
    :cond_16
    iput-object v1, p0, Lae0;->e:Ljava/lang/Runnable;

    .line 24
    .line 25
    add-int/lit8 v0, v0, 0x1

    .line 26
    .line 27
    const/16 v1, 0x10

    .line 28
    .line 29
    if-lt v0, v1, :cond_1

    .line 30
    .line 31
    iget-object v1, p0, Lae0;->f:Lbe0;

    .line 32
    .line 33
    iget-object v2, v1, Lbe0;->h:Lul;

    .line 34
    .line 35
    invoke-static {v2, v1}, Lwl1;->I(Lul;Lsl;)Z

    .line 36
    .line 37
    .line 38
    move-result v1

    .line 39
    if-eqz v1, :cond_1

    .line 40
    .line 41
    iget-object v0, p0, Lae0;->f:Lbe0;

    .line 42
    .line 43
    iget-object v1, v0, Lbe0;->h:Lul;

    .line 44
    .line 45
    invoke-static {v1, v0, p0}, Lwl1;->H(Lul;Lsl;Ljava/lang/Runnable;)V
    :try_end_2f
    .catchall {:try_start_8 .. :try_end_2f} :catchall_30

    .line 46
    .line 47
    .line 48
    :goto_2f
    return-void

    .line 49
    :catchall_30
    move-exception v0

    .line 50
    iget-object p0, p0, Lae0;->f:Lbe0;

    .line 51
    .line 52
    iget-object v1, p0, Lbe0;->k:Ljava/lang/Object;

    .line 53
    .line 54
    monitor-enter v1

    .line 55
    :try_start_36
    sget-object v2, Lbe0;->l:Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

    .line 56
    .line 57
    invoke-virtual {v2, p0}, Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;->decrementAndGet(Ljava/lang/Object;)I
    :try_end_3b
    .catchall {:try_start_36 .. :try_end_3b} :catchall_3d

    .line 58
    .line 59
    .line 60
    monitor-exit v1

    .line 61
    throw v0

    .line 62
    :catchall_3d
    move-exception p0

    .line 63
    monitor-exit v1

    .line 64
    throw p0
.end method
