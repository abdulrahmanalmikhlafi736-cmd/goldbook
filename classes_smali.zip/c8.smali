.class public final Lc8;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# instance fields
.field public final a:Lud1;

.field public final b:Ljava/lang/Object;

.field public final c:Lp8;

.field public final d:Llq0;

.field public final e:Llq0;

.field public final f:Lal0;

.field public final g:Lu8;

.field public final h:Lu8;

.field public final i:Lu8;

.field public final j:Lu8;


# direct methods
.method public constructor <init>(Ljava/lang/Object;Lud1;Ljava/lang/Float;I)V
    .registers 7

    .line 1
    and-int/lit8 p4, p4, 0x4

    .line 2
    .line 3
    const/4 v0, 0x0

    .line 4
    if-eqz p4, :cond_6

    .line 5
    .line 6
    move-object p3, v0

    .line 7
    :cond_6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    iput-object p2, p0, Lc8;->a:Lud1;

    .line 11
    .line 12
    new-instance p4, Lp8;

    .line 13
    .line 14
    const/16 v1, 0x3c

    .line 15
    .line 16
    invoke-direct {p4, p2, p1, v0, v1}, Lp8;-><init>(Lud1;Ljava/lang/Object;Lu8;I)V

    .line 17
    .line 18
    .line 19
    iput-object p4, p0, Lc8;->c:Lp8;

    .line 20
    .line 21
    sget-object p2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 22
    .line 23
    invoke-static {p2}, Lmc0;->t(Ljava/lang/Object;)Llq0;

    .line 24
    .line 25
    .line 26
    move-result-object p2

    .line 27
    iput-object p2, p0, Lc8;->d:Llq0;

    .line 28
    .line 29
    invoke-static {p1}, Lmc0;->t(Ljava/lang/Object;)Llq0;

    .line 30
    .line 31
    .line 32
    move-result-object p1

    .line 33
    iput-object p1, p0, Lc8;->e:Llq0;

    .line 34
    .line 35
    new-instance p1, Lal0;

    .line 36
    .line 37
    invoke-direct {p1}, Lal0;-><init>()V

    .line 38
    .line 39
    .line 40
    iput-object p1, p0, Lc8;->f:Lal0;

    .line 41
    .line 42
    new-instance p1, Lp71;

    .line 43
    .line 44
    const/high16 p2, 0x3f800000  # 1.0f

    .line 45
    .line 46
    const v0, 0x44bb8000  # 1500.0f

    .line 47
    .line 48
    .line 49
    invoke-direct {p1, p2, v0, p3}, Lp71;-><init>(FFLjava/lang/Object;)V

    .line 50
    .line 51
    .line 52
    iget-object p1, p4, Lp8;->g:Lu8;

    .line 53
    .line 54
    instance-of p2, p1, Lq8;

    .line 55
    .line 56
    if-eqz p2, :cond_3c

    .line 57
    .line 58
    sget-object p3, Lk70;->e:Lq8;

    .line 59
    .line 60
    goto :goto_4c

    .line 61
    :cond_3c
    instance-of p3, p1, Lr8;

    .line 62
    .line 63
    if-eqz p3, :cond_43

    .line 64
    .line 65
    sget-object p3, Lk70;->f:Lr8;

    .line 66
    .line 67
    goto :goto_4c

    .line 68
    :cond_43
    instance-of p3, p1, Ls8;

    .line 69
    .line 70
    if-eqz p3, :cond_4a

    .line 71
    .line 72
    sget-object p3, Lk70;->g:Ls8;

    .line 73
    .line 74
    goto :goto_4c

    .line 75
    :cond_4a
    sget-object p3, Lk70;->h:Lt8;

    .line 76
    .line 77
    :goto_4c
    iput-object p3, p0, Lc8;->g:Lu8;

    .line 78
    .line 79
    if-eqz p2, :cond_53

    .line 80
    .line 81
    sget-object p1, Lk70;->a:Lq8;

    .line 82
    .line 83
    goto :goto_63

    .line 84
    :cond_53
    instance-of p2, p1, Lr8;

    .line 85
    .line 86
    if-eqz p2, :cond_5a

    .line 87
    .line 88
    sget-object p1, Lk70;->b:Lr8;

    .line 89
    .line 90
    goto :goto_63

    .line 91
    :cond_5a
    instance-of p1, p1, Ls8;

    .line 92
    .line 93
    if-eqz p1, :cond_61

    .line 94
    .line 95
    sget-object p1, Lk70;->c:Ls8;

    .line 96
    .line 97
    goto :goto_63

    .line 98
    :cond_61
    sget-object p1, Lk70;->d:Lt8;

    .line 99
    .line 100
    :goto_63
    iput-object p1, p0, Lc8;->h:Lu8;

    .line 101
    .line 102
    iput-object p3, p0, Lc8;->i:Lu8;

    .line 103
    .line 104
    iput-object p1, p0, Lc8;->j:Lu8;

    .line 105
    .line 106
    return-void
.end method

.method public static final a(Lc8;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 10

    .line 1
    iget-object v0, p0, Lc8;->a:Lud1;

    .line 2
    .line 3
    iget-object v1, p0, Lc8;->j:Lu8;

    .line 4
    .line 5
    iget-object v2, p0, Lc8;->i:Lu8;

    .line 6
    .line 7
    iget-object v3, p0, Lc8;->g:Lu8;

    .line 8
    .line 9
    invoke-static {v2, v3}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 10
    .line 11
    .line 12
    move-result v3

    .line 13
    if-eqz v3, :cond_17

    .line 14
    .line 15
    iget-object p0, p0, Lc8;->h:Lu8;

    .line 16
    .line 17
    invoke-static {v1, p0}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result p0

    .line 21
    if-eqz p0, :cond_17

    .line 22
    .line 23
    goto :goto_5f

    .line 24
    :cond_17
    iget-object p0, v0, Lud1;->a:Li00;

    .line 25
    .line 26
    invoke-interface {p0, p1}, Li00;->i(Ljava/lang/Object;)Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object p0

    .line 30
    check-cast p0, Lu8;

    .line 31
    .line 32
    invoke-virtual {p0}, Lu8;->b()I

    .line 33
    .line 34
    .line 35
    move-result v3

    .line 36
    const/4 v4, 0x0

    .line 37
    move v5, v4

    .line 38
    :goto_25
    if-ge v4, v3, :cond_56

    .line 39
    .line 40
    invoke-virtual {p0, v4}, Lu8;->a(I)F

    .line 41
    .line 42
    .line 43
    move-result v6

    .line 44
    invoke-virtual {v2, v4}, Lu8;->a(I)F

    .line 45
    .line 46
    .line 47
    move-result v7

    .line 48
    cmpg-float v6, v6, v7

    .line 49
    .line 50
    if-ltz v6, :cond_3f

    .line 51
    .line 52
    invoke-virtual {p0, v4}, Lu8;->a(I)F

    .line 53
    .line 54
    .line 55
    move-result v6

    .line 56
    invoke-virtual {v1, v4}, Lu8;->a(I)F

    .line 57
    .line 58
    .line 59
    move-result v7

    .line 60
    cmpl-float v6, v6, v7

    .line 61
    .line 62
    if-lez v6, :cond_53

    .line 63
    .line 64
    :cond_3f
    invoke-virtual {p0, v4}, Lu8;->a(I)F

    .line 65
    .line 66
    .line 67
    move-result v5

    .line 68
    invoke-virtual {v2, v4}, Lu8;->a(I)F

    .line 69
    .line 70
    .line 71
    move-result v6

    .line 72
    invoke-virtual {v1, v4}, Lu8;->a(I)F

    .line 73
    .line 74
    .line 75
    move-result v7

    .line 76
    invoke-static {v5, v6, v7}, Lsb0;->g(FFF)F

    .line 77
    .line 78
    .line 79
    move-result v5

    .line 80
    invoke-virtual {p0, v5, v4}, Lu8;->e(FI)V

    .line 81
    .line 82
    .line 83
    const/4 v5, 0x1

    .line 84
    :cond_53
    add-int/lit8 v4, v4, 0x1

    .line 85
    .line 86
    goto :goto_25

    .line 87
    :cond_56
    if-eqz v5, :cond_5f

    .line 88
    .line 89
    iget-object p1, v0, Lud1;->b:Li00;

    .line 90
    .line 91
    invoke-interface {p1, p0}, Li00;->i(Ljava/lang/Object;)Ljava/lang/Object;

    .line 92
    .line 93
    .line 94
    move-result-object p0

    .line 95
    return-object p0

    .line 96
    :cond_5f
    :goto_5f
    return-object p1
.end method

.method public static final b(Lc8;)V
    .registers 4

    .line 1
    iget-object v0, p0, Lc8;->c:Lp8;

    .line 2
    .line 3
    iget-object v1, v0, Lp8;->g:Lu8;

    .line 4
    .line 5
    invoke-virtual {v1}, Lu8;->d()V

    .line 6
    .line 7
    .line 8
    const-wide/high16 v1, -0x8000000000000000L

    .line 9
    .line 10
    iput-wide v1, v0, Lp8;->h:J

    .line 11
    .line 12
    iget-object p0, p0, Lc8;->d:Llq0;

    .line 13
    .line 14
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 15
    .line 16
    invoke-virtual {p0, v0}, Llq0;->setValue(Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    return-void
.end method

.method public static c(Lc8;Ljava/lang/Comparable;Lo8;Lnl;)Ljava/lang/Object;
    .registers 15

    .line 1
    iget-object v0, p0, Lc8;->a:Lud1;

    .line 2
    .line 3
    iget-object v0, v0, Lud1;->b:Li00;

    .line 4
    .line 5
    iget-object v1, p0, Lc8;->c:Lp8;

    .line 6
    .line 7
    iget-object v1, v1, Lp8;->g:Lu8;

    .line 8
    .line 9
    invoke-interface {v0, v1}, Li00;->i(Ljava/lang/Object;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v4

    .line 13
    invoke-virtual {p0}, Lc8;->d()Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v8

    .line 17
    iget-object v7, p0, Lc8;->a:Lud1;

    .line 18
    .line 19
    new-instance v5, Lja1;

    .line 20
    .line 21
    iget-object v0, v7, Lud1;->a:Li00;

    .line 22
    .line 23
    invoke-interface {v0, v4}, Li00;->i(Ljava/lang/Object;)Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    move-object v10, v0

    .line 28
    check-cast v10, Lu8;

    .line 29
    .line 30
    move-object v9, p1

    .line 31
    move-object v6, p2

    .line 32
    invoke-direct/range {v5 .. v10}, Lja1;-><init>(Lo8;Lud1;Ljava/lang/Object;Ljava/lang/Object;Lu8;)V

    .line 33
    .line 34
    .line 35
    iget-object p1, p0, Lc8;->c:Lp8;

    .line 36
    .line 37
    iget-wide v6, p1, Lp8;->h:J

    .line 38
    .line 39
    iget-object p1, p0, Lc8;->f:Lal0;

    .line 40
    .line 41
    new-instance v2, La8;

    .line 42
    .line 43
    const/4 v8, 0x0

    .line 44
    move-object v3, p0

    .line 45
    invoke-direct/range {v2 .. v8}, La8;-><init>(Lc8;Ljava/lang/Object;Lja1;JLml;)V

    .line 46
    .line 47
    .line 48
    invoke-static {p1, v2, p3}, Lal0;->a(Lal0;Li00;Lnl;)Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    move-result-object p0

    .line 52
    return-object p0
.end method


# virtual methods
.method public final d()Ljava/lang/Object;
    .registers 1

    .line 1
    iget-object p0, p0, Lc8;->c:Lp8;

    .line 2
    .line 3
    iget-object p0, p0, Lp8;->f:Llq0;

    .line 4
    .line 5
    invoke-virtual {p0}, Llq0;->getValue()Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    return-object p0
.end method

.method public final e(Lbr;Lnl;)Ljava/lang/Object;
    .registers 5

    .line 1
    new-instance v0, Lb8;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, p0, p1, v1}, Lb8;-><init>(Lc8;Lbr;Lml;)V

    .line 5
    .line 6
    .line 7
    iget-object p0, p0, Lc8;->f:Lal0;

    .line 8
    .line 9
    invoke-static {p0, v0, p2}, Lal0;->a(Lal0;Li00;Lnl;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    sget-object p1, Lcm;->e:Lcm;

    .line 14
    .line 15
    if-ne p0, p1, :cond_11

    .line 16
    .line 17
    return-object p0

    .line 18
    :cond_11
    sget-object p0, Lwe1;->a:Lwe1;

    .line 19
    .line 20
    return-object p0
.end method
