.class public final Lag0;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lnh0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:I

.field public final synthetic c:Ljava/util/Map;

.field public final synthetic d:Li00;

.field public final synthetic e:Li00;

.field public final synthetic f:Lbg0;


# direct methods
.method public constructor <init>(IILjava/util/Map;Li00;Li00;Lbg0;)V
    .registers 7

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput p1, p0, Lag0;->a:I

    .line 5
    .line 6
    iput p2, p0, Lag0;->b:I

    .line 7
    .line 8
    iput-object p3, p0, Lag0;->c:Ljava/util/Map;

    .line 9
    .line 10
    iput-object p4, p0, Lag0;->d:Li00;

    .line 11
    .line 12
    iput-object p5, p0, Lag0;->e:Li00;

    .line 13
    .line 14
    iput-object p6, p0, Lag0;->f:Lbg0;

    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public final a()V
    .registers 2

    .line 1
    iget-object v0, p0, Lag0;->f:Lbg0;

    .line 2
    .line 3
    iget-object v0, v0, Lbg0;->p:Lcg0;

    .line 4
    .line 5
    iget-object p0, p0, Lag0;->e:Li00;

    .line 6
    .line 7
    invoke-interface {p0, v0}, Li00;->i(Ljava/lang/Object;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public final b()I
    .registers 1

    .line 1
    iget p0, p0, Lag0;->b:I

    .line 2
    .line 3
    return p0
.end method

.method public final c()Ljava/util/Map;
    .registers 1

    .line 1
    iget-object p0, p0, Lag0;->c:Ljava/util/Map;

    .line 2
    .line 3
    return-object p0
.end method

.method public final d()Li00;
    .registers 1

    .line 1
    iget-object p0, p0, Lag0;->d:Li00;

    .line 2
    .line 3
    return-object p0
.end method

.method public final e()I
    .registers 1

    .line 1
    iget p0, p0, Lag0;->a:I

    .line 2
    .line 3
    return p0
.end method
