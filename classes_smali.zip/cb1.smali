.class public final Lcb1;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# instance fields
.field public final a:Lbb1;

.field public final b:Lij0;

.field public final c:J

.field public final d:F

.field public final e:F

.field public final f:Ljava/util/ArrayList;


# direct methods
.method public constructor <init>(Lbb1;Lij0;J)V
    .registers 6

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lcb1;->a:Lbb1;

    .line 5
    .line 6
    iput-object p2, p0, Lcb1;->b:Lij0;

    .line 7
    .line 8
    iput-wide p3, p0, Lcb1;->c:J

    .line 9
    .line 10
    iget-object p1, p2, Lij0;->e:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast p1, Ljava/util/ArrayList;

    .line 13
    .line 14
    invoke-virtual {p1}, Ljava/util/ArrayList;->isEmpty()Z

    .line 15
    .line 16
    .line 17
    move-result p3

    .line 18
    const/4 p4, 0x0

    .line 19
    if-eqz p3, :cond_16

    .line 20
    .line 21
    move p3, p4

    .line 22
    goto :goto_25

    .line 23
    :cond_16
    const/4 p3, 0x0

    .line 24
    invoke-virtual {p1, p3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    check-cast v0, Lbq0;

    .line 29
    .line 30
    iget-object v0, v0, Lbq0;->a:Lm6;

    .line 31
    .line 32
    iget-object v0, v0, Lm6;->d:Lab1;

    .line 33
    .line 34
    invoke-virtual {v0, p3}, Lab1;->c(I)F

    .line 35
    .line 36
    .line 37
    move-result p3

    .line 38
    :goto_25
    iput p3, p0, Lcb1;->d:F

    .line 39
    .line 40
    invoke-virtual {p1}, Ljava/util/ArrayList;->isEmpty()Z

    .line 41
    .line 42
    .line 43
    move-result p3

    .line 44
    if-eqz p3, :cond_2e

    .line 45
    .line 46
    goto :goto_44

    .line 47
    :cond_2e
    invoke-static {p1}, Ltg;->W(Ljava/util/List;)Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object p1

    .line 51
    check-cast p1, Lbq0;

    .line 52
    .line 53
    iget-object p3, p1, Lbq0;->a:Lm6;

    .line 54
    .line 55
    iget-object p3, p3, Lm6;->d:Lab1;

    .line 56
    .line 57
    iget p4, p3, Lab1;->f:I

    .line 58
    .line 59
    add-int/lit8 p4, p4, -0x1

    .line 60
    .line 61
    invoke-virtual {p3, p4}, Lab1;->c(I)F

    .line 62
    .line 63
    .line 64
    move-result p3

    .line 65
    iget p1, p1, Lbq0;->f:F

    .line 66
    .line 67
    add-float p4, p3, p1

    .line 68
    .line 69
    :goto_44
    iput p4, p0, Lcb1;->e:F

    .line 70
    .line 71
    iget-object p1, p2, Lij0;->d:Ljava/lang/Object;

    .line 72
    .line 73
    check-cast p1, Ljava/util/ArrayList;

    .line 74
    .line 75
    iput-object p1, p0, Lcb1;->f:Ljava/util/ArrayList;

    .line 76
    .line 77
    return-void
.end method


# virtual methods
.method public final a(I)I
    .registers 3

    .line 1
    iget-object p0, p0, Lcb1;->b:Lij0;

    .line 2
    .line 3
    iget-object v0, p0, Lij0;->e:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Ljava/util/ArrayList;

    .line 6
    .line 7
    iget-object p0, p0, Lij0;->c:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast p0, Lpa;

    .line 10
    .line 11
    iget-object p0, p0, Lpa;->a:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast p0, Lx8;

    .line 14
    .line 15
    iget-object p0, p0, Lx8;->f:Ljava/lang/String;

    .line 16
    .line 17
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 18
    .line 19
    .line 20
    move-result p0

    .line 21
    if-lt p1, p0, :cond_1b

    .line 22
    .line 23
    invoke-static {v0}, Lzi1;->t(Ljava/util/List;)I

    .line 24
    .line 25
    .line 26
    move-result p0

    .line 27
    goto :goto_23

    .line 28
    :cond_1b
    if-gez p1, :cond_1f

    .line 29
    .line 30
    const/4 p0, 0x0

    .line 31
    goto :goto_23

    .line 32
    :cond_1f
    invoke-static {p1, v0}, Ldd0;->h(ILjava/util/List;)I

    .line 33
    .line 34
    .line 35
    move-result p0

    .line 36
    :goto_23
    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object p0

    .line 40
    check-cast p0, Lbq0;

    .line 41
    .line 42
    iget-object v0, p0, Lbq0;->a:Lm6;

    .line 43
    .line 44
    invoke-virtual {p0, p1}, Lbq0;->a(I)I

    .line 45
    .line 46
    .line 47
    move-result p1

    .line 48
    iget-object v0, v0, Lm6;->d:Lab1;

    .line 49
    .line 50
    iget-object v0, v0, Lab1;->e:Landroid/text/Layout;

    .line 51
    .line 52
    invoke-virtual {v0, p1}, Landroid/text/Layout;->getLineForOffset(I)I

    .line 53
    .line 54
    .line 55
    move-result p1

    .line 56
    iget p0, p0, Lbq0;->d:I

    .line 57
    .line 58
    add-int/2addr p1, p0

    .line 59
    return p1
.end method

.method public final b(F)I
    .registers 9

    .line 1
    iget-object p0, p0, Lcb1;->b:Lij0;

    .line 2
    .line 3
    iget-object p0, p0, Lij0;->e:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast p0, Ljava/util/ArrayList;

    .line 6
    .line 7
    const/4 v0, 0x0

    .line 8
    cmpg-float v0, p1, v0

    .line 9
    .line 10
    const/4 v1, 0x0

    .line 11
    if-gtz v0, :cond_d

    .line 12
    .line 13
    goto :goto_51

    .line 14
    :cond_d
    invoke-static {p0}, Ltg;->W(Ljava/util/List;)Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    check-cast v0, Lbq0;

    .line 19
    .line 20
    iget v0, v0, Lbq0;->g:F

    .line 21
    .line 22
    cmpl-float v0, p1, v0

    .line 23
    .line 24
    const/4 v2, 0x1

    .line 25
    if-ltz v0, :cond_21

    .line 26
    .line 27
    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    add-int/lit8 v1, v0, -0x1

    .line 32
    .line 33
    goto :goto_51

    .line 34
    :cond_21
    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    sub-int/2addr v0, v2

    .line 39
    move v3, v1

    .line 40
    :goto_27
    if-gt v3, v0, :cond_4f

    .line 41
    .line 42
    add-int v4, v3, v0

    .line 43
    .line 44
    ushr-int/2addr v4, v2

    .line 45
    invoke-virtual {p0, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object v5

    .line 49
    check-cast v5, Lbq0;

    .line 50
    .line 51
    iget v6, v5, Lbq0;->f:F

    .line 52
    .line 53
    cmpl-float v6, v6, p1

    .line 54
    .line 55
    if-lez v6, :cond_3a

    .line 56
    .line 57
    move v5, v2

    .line 58
    goto :goto_43

    .line 59
    :cond_3a
    iget v5, v5, Lbq0;->g:F

    .line 60
    .line 61
    cmpg-float v5, v5, p1

    .line 62
    .line 63
    if-gtz v5, :cond_42

    .line 64
    .line 65
    const/4 v5, -0x1

    .line 66
    goto :goto_43

    .line 67
    :cond_42
    move v5, v1

    .line 68
    :goto_43
    if-gez v5, :cond_48

    .line 69
    .line 70
    add-int/lit8 v3, v4, 0x1

    .line 71
    .line 72
    goto :goto_27

    .line 73
    :cond_48
    if-lez v5, :cond_4d

    .line 74
    .line 75
    add-int/lit8 v0, v4, -0x1

    .line 76
    .line 77
    goto :goto_27

    .line 78
    :cond_4d
    move v1, v4

    .line 79
    goto :goto_51

    .line 80
    :cond_4f
    add-int/2addr v3, v2

    .line 81
    neg-int v1, v3

    .line 82
    :goto_51
    invoke-virtual {p0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 83
    .line 84
    .line 85
    move-result-object p0

    .line 86
    check-cast p0, Lbq0;

    .line 87
    .line 88
    iget v0, p0, Lbq0;->c:I

    .line 89
    .line 90
    iget v1, p0, Lbq0;->d:I

    .line 91
    .line 92
    iget v2, p0, Lbq0;->b:I

    .line 93
    .line 94
    sub-int/2addr v0, v2

    .line 95
    if-nez v0, :cond_61

    .line 96
    .line 97
    return v1

    .line 98
    :cond_61
    iget-object v0, p0, Lbq0;->a:Lm6;

    .line 99
    .line 100
    iget p0, p0, Lbq0;->f:F

    .line 101
    .line 102
    sub-float/2addr p1, p0

    .line 103
    iget-object p0, v0, Lm6;->d:Lab1;

    .line 104
    .line 105
    float-to-int p1, p1

    .line 106
    iget-object v0, p0, Lab1;->e:Landroid/text/Layout;

    .line 107
    .line 108
    iget p0, p0, Lab1;->g:I

    .line 109
    .line 110
    sub-int/2addr p1, p0

    .line 111
    invoke-virtual {v0, p1}, Landroid/text/Layout;->getLineForVertical(I)I

    .line 112
    .line 113
    .line 114
    move-result p0

    .line 115
    add-int/2addr p0, v1

    .line 116
    return p0
.end method

.method public final c(I)I
    .registers 4

    .line 1
    iget-object p0, p0, Lcb1;->b:Lij0;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Lij0;->b(I)V

    .line 4
    .line 5
    .line 6
    iget-object p0, p0, Lij0;->e:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast p0, Ljava/util/ArrayList;

    .line 9
    .line 10
    invoke-static {p1, p0}, Ldd0;->i(ILjava/util/List;)I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object p0

    .line 18
    check-cast p0, Lbq0;

    .line 19
    .line 20
    iget-object v0, p0, Lbq0;->a:Lm6;

    .line 21
    .line 22
    iget v1, p0, Lbq0;->d:I

    .line 23
    .line 24
    sub-int/2addr p1, v1

    .line 25
    iget-object v0, v0, Lm6;->d:Lab1;

    .line 26
    .line 27
    iget-object v0, v0, Lab1;->e:Landroid/text/Layout;

    .line 28
    .line 29
    invoke-virtual {v0, p1}, Landroid/text/Layout;->getLineStart(I)I

    .line 30
    .line 31
    .line 32
    move-result p1

    .line 33
    iget p0, p0, Lbq0;->b:I

    .line 34
    .line 35
    add-int/2addr p1, p0

    .line 36
    return p1
.end method

.method public final d(I)F
    .registers 4

    .line 1
    iget-object p0, p0, Lcb1;->b:Lij0;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Lij0;->b(I)V

    .line 4
    .line 5
    .line 6
    iget-object p0, p0, Lij0;->e:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast p0, Ljava/util/ArrayList;

    .line 9
    .line 10
    invoke-static {p1, p0}, Ldd0;->i(ILjava/util/List;)I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object p0

    .line 18
    check-cast p0, Lbq0;

    .line 19
    .line 20
    iget-object v0, p0, Lbq0;->a:Lm6;

    .line 21
    .line 22
    iget v1, p0, Lbq0;->d:I

    .line 23
    .line 24
    sub-int/2addr p1, v1

    .line 25
    iget-object v0, v0, Lm6;->d:Lab1;

    .line 26
    .line 27
    invoke-virtual {v0, p1}, Lab1;->f(I)F

    .line 28
    .line 29
    .line 30
    move-result p1

    .line 31
    iget p0, p0, Lbq0;->f:F

    .line 32
    .line 33
    add-float/2addr p1, p0

    .line 34
    return p1
.end method

.method public final e(I)Llx0;
    .registers 5

    .line 1
    iget-object p0, p0, Lcb1;->b:Lij0;

    .line 2
    .line 3
    iget-object v0, p0, Lij0;->c:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Lpa;

    .line 6
    .line 7
    iget-object v0, v0, Lpa;->a:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v0, Lx8;

    .line 10
    .line 11
    if-ltz p1, :cond_15

    .line 12
    .line 13
    iget-object v1, v0, Lx8;->f:Ljava/lang/String;

    .line 14
    .line 15
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 16
    .line 17
    .line 18
    move-result v1

    .line 19
    if-gt p1, v1, :cond_15

    .line 20
    .line 21
    goto :goto_32

    .line 22
    :cond_15
    const-string v1, "offset("

    .line 23
    .line 24
    const-string v2, ") is out of bounds [0, "

    .line 25
    .line 26
    invoke-static {p1, v1, v2}, Lfu0;->H(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    iget-object v0, v0, Lx8;->f:Ljava/lang/String;

    .line 31
    .line 32
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 37
    .line 38
    .line 39
    const/16 v0, 0x5d

    .line 40
    .line 41
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 42
    .line 43
    .line 44
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    invoke-static {v0}, Lq50;->a(Ljava/lang/String;)V

    .line 49
    .line 50
    .line 51
    :goto_32
    iget-object v0, p0, Lij0;->c:Ljava/lang/Object;

    .line 52
    .line 53
    check-cast v0, Lpa;

    .line 54
    .line 55
    iget-object v0, v0, Lpa;->a:Ljava/lang/Object;

    .line 56
    .line 57
    check-cast v0, Lx8;

    .line 58
    .line 59
    iget-object v0, v0, Lx8;->f:Ljava/lang/String;

    .line 60
    .line 61
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 62
    .line 63
    .line 64
    move-result v0

    .line 65
    iget-object p0, p0, Lij0;->e:Ljava/lang/Object;

    .line 66
    .line 67
    check-cast p0, Ljava/util/ArrayList;

    .line 68
    .line 69
    if-ne p1, v0, :cond_4b

    .line 70
    .line 71
    invoke-static {p0}, Lzi1;->t(Ljava/util/List;)I

    .line 72
    .line 73
    .line 74
    move-result v0

    .line 75
    goto :goto_4f

    .line 76
    :cond_4b
    invoke-static {p1, p0}, Ldd0;->h(ILjava/util/List;)I

    .line 77
    .line 78
    .line 79
    move-result v0

    .line 80
    :goto_4f
    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 81
    .line 82
    .line 83
    move-result-object p0

    .line 84
    check-cast p0, Lbq0;

    .line 85
    .line 86
    iget-object v0, p0, Lbq0;->a:Lm6;

    .line 87
    .line 88
    invoke-virtual {p0, p1}, Lbq0;->a(I)I

    .line 89
    .line 90
    .line 91
    move-result p0

    .line 92
    iget-object p1, v0, Lm6;->d:Lab1;

    .line 93
    .line 94
    iget-object v0, p1, Lab1;->e:Landroid/text/Layout;

    .line 95
    .line 96
    invoke-virtual {v0, p0}, Landroid/text/Layout;->getLineForOffset(I)I

    .line 97
    .line 98
    .line 99
    move-result p0

    .line 100
    iget-object p1, p1, Lab1;->e:Landroid/text/Layout;

    .line 101
    .line 102
    invoke-virtual {p1, p0}, Landroid/text/Layout;->getParagraphDirection(I)I

    .line 103
    .line 104
    .line 105
    move-result p0

    .line 106
    const/4 p1, 0x1

    .line 107
    if-ne p0, p1, :cond_6f

    .line 108
    .line 109
    sget-object p0, Llx0;->e:Llx0;

    .line 110
    .line 111
    return-object p0

    .line 112
    :cond_6f
    sget-object p0, Llx0;->f:Llx0;

    .line 113
    .line 114
    return-object p0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 8

    .line 1
    if-ne p0, p1, :cond_3

    .line 2
    .line 3
    goto :goto_43

    .line 4
    :cond_3
    instance-of v0, p1, Lcb1;

    .line 5
    .line 6
    const/4 v1, 0x0

    .line 7
    if-nez v0, :cond_9

    .line 8
    .line 9
    goto :goto_45

    .line 10
    :cond_9
    check-cast p1, Lcb1;

    .line 11
    .line 12
    iget-object v0, p1, Lcb1;->a:Lbb1;

    .line 13
    .line 14
    iget-object v2, p0, Lcb1;->a:Lbb1;

    .line 15
    .line 16
    invoke-static {v2, v0}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    if-nez v0, :cond_16

    .line 21
    .line 22
    goto :goto_45

    .line 23
    :cond_16
    iget-object v0, p0, Lcb1;->b:Lij0;

    .line 24
    .line 25
    iget-object v2, p1, Lcb1;->b:Lij0;

    .line 26
    .line 27
    if-eq v0, v2, :cond_1d

    .line 28
    .line 29
    return v1

    .line 30
    :cond_1d
    iget-wide v2, p0, Lcb1;->c:J

    .line 31
    .line 32
    iget-wide v4, p1, Lcb1;->c:J

    .line 33
    .line 34
    invoke-static {v2, v3, v4, v5}, Lv60;->a(JJ)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-nez v0, :cond_28

    .line 39
    .line 40
    goto :goto_45

    .line 41
    :cond_28
    iget v0, p0, Lcb1;->d:F

    .line 42
    .line 43
    iget v2, p1, Lcb1;->d:F

    .line 44
    .line 45
    cmpg-float v0, v0, v2

    .line 46
    .line 47
    if-nez v0, :cond_45

    .line 48
    .line 49
    iget v0, p0, Lcb1;->e:F

    .line 50
    .line 51
    iget v2, p1, Lcb1;->e:F

    .line 52
    .line 53
    cmpg-float v0, v0, v2

    .line 54
    .line 55
    if-nez v0, :cond_45

    .line 56
    .line 57
    iget-object p0, p0, Lcb1;->f:Ljava/util/ArrayList;

    .line 58
    .line 59
    iget-object p1, p1, Lcb1;->f:Ljava/util/ArrayList;

    .line 60
    .line 61
    invoke-static {p0, p1}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 62
    .line 63
    .line 64
    move-result p0

    .line 65
    if-nez p0, :cond_43

    .line 66
    .line 67
    goto :goto_45

    .line 68
    :cond_43
    :goto_43
    const/4 p0, 0x1

    .line 69
    return p0

    .line 70
    :cond_45
    :goto_45
    return v1
.end method

.method public final hashCode()I
    .registers 8

    .line 1
    iget-object v0, p0, Lcb1;->a:Lbb1;

    .line 2
    .line 3
    invoke-virtual {v0}, Lbb1;->hashCode()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const/16 v1, 0x1f

    .line 8
    .line 9
    mul-int/2addr v0, v1

    .line 10
    iget-object v2, p0, Lcb1;->b:Lij0;

    .line 11
    .line 12
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    .line 13
    .line 14
    .line 15
    move-result v2

    .line 16
    add-int/2addr v2, v0

    .line 17
    mul-int/2addr v2, v1

    .line 18
    const/16 v0, 0x20

    .line 19
    .line 20
    iget-wide v3, p0, Lcb1;->c:J

    .line 21
    .line 22
    ushr-long v5, v3, v0

    .line 23
    .line 24
    xor-long/2addr v3, v5

    .line 25
    long-to-int v0, v3

    .line 26
    add-int/2addr v0, v2

    .line 27
    mul-int/2addr v0, v1

    .line 28
    iget v2, p0, Lcb1;->d:F

    .line 29
    .line 30
    invoke-static {v2, v0, v1}, Lfu0;->z(FII)I

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    iget v2, p0, Lcb1;->e:F

    .line 35
    .line 36
    invoke-static {v2, v0, v1}, Lfu0;->z(FII)I

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    iget-object p0, p0, Lcb1;->f:Ljava/util/ArrayList;

    .line 41
    .line 42
    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    .line 43
    .line 44
    .line 45
    move-result p0

    .line 46
    add-int/2addr p0, v0

    .line 47
    return p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 4

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-string v1, "TextLayoutResult(layoutInput="

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    iget-object v1, p0, Lcb1;->a:Lbb1;

    .line 9
    .line 10
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 11
    .line 12
    .line 13
    const-string v1, ", multiParagraph="

    .line 14
    .line 15
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 16
    .line 17
    .line 18
    iget-object v1, p0, Lcb1;->b:Lij0;

    .line 19
    .line 20
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 21
    .line 22
    .line 23
    const-string v1, ", size="

    .line 24
    .line 25
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 26
    .line 27
    .line 28
    iget-wide v1, p0, Lcb1;->c:J

    .line 29
    .line 30
    invoke-static {v1, v2}, Lv60;->b(J)Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    move-result-object v1

    .line 34
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 35
    .line 36
    .line 37
    const-string v1, ", firstBaseline="

    .line 38
    .line 39
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 40
    .line 41
    .line 42
    iget v1, p0, Lcb1;->d:F

    .line 43
    .line 44
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    .line 45
    .line 46
    .line 47
    const-string v1, ", lastBaseline="

    .line 48
    .line 49
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 50
    .line 51
    .line 52
    iget v1, p0, Lcb1;->e:F

    .line 53
    .line 54
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    .line 55
    .line 56
    .line 57
    const-string v1, ", placeholderRects="

    .line 58
    .line 59
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 60
    .line 61
    .line 62
    iget-object p0, p0, Lcb1;->f:Ljava/util/ArrayList;

    .line 63
    .line 64
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 65
    .line 66
    .line 67
    const/16 p0, 0x29

    .line 68
    .line 69
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 70
    .line 71
    .line 72
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 73
    .line 74
    .line 75
    move-result-object p0

    .line 76
    return-object p0
.end method
