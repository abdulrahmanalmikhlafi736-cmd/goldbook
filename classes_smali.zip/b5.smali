.class public final Lb5;
.super Lh90;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lxz;


# static fields
.field public static final A:Lb5;

.field public static final B:Lb5;

.field public static final C:Lb5;

.field public static final D:Lb5;

.field public static final E:Lb5;

.field public static final F:Lb5;

.field public static final G:Lb5;

.field public static final H:Lb5;

.field public static final I:Lb5;

.field public static final J:Lb5;

.field public static final g:Lb5;

.field public static final h:Lb5;

.field public static final i:Lb5;

.field public static final j:Lb5;

.field public static final k:Lb5;

.field public static final l:Lb5;

.field public static final m:Lb5;

.field public static final n:Lb5;

.field public static final o:Lb5;

.field public static final p:Lb5;

.field public static final q:Lb5;

.field public static final r:Lb5;

.field public static final s:Lb5;

.field public static final t:Lb5;

.field public static final u:Lb5;

.field public static final v:Lb5;

.field public static final w:Lb5;

.field public static final x:Lb5;

.field public static final y:Lb5;

.field public static final z:Lb5;


# instance fields
.field public final synthetic f:I


# direct methods
.method static synthetic constructor <clinit>()V
    .registers 3

    .line 1
    new-instance v0, Lb5;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x0

    .line 5
    invoke-direct {v0, v1, v2}, Lb5;-><init>(II)V

    .line 6
    .line 7
    .line 8
    sput-object v0, Lb5;->g:Lb5;

    .line 9
    .line 10
    new-instance v0, Lb5;

    .line 11
    .line 12
    const/4 v2, 0x1

    .line 13
    invoke-direct {v0, v1, v2}, Lb5;-><init>(II)V

    .line 14
    .line 15
    .line 16
    sput-object v0, Lb5;->h:Lb5;

    .line 17
    .line 18
    new-instance v0, Lb5;

    .line 19
    .line 20
    const/4 v2, 0x2

    .line 21
    invoke-direct {v0, v1, v2}, Lb5;-><init>(II)V

    .line 22
    .line 23
    .line 24
    sput-object v0, Lb5;->i:Lb5;

    .line 25
    .line 26
    new-instance v0, Lb5;

    .line 27
    .line 28
    const/4 v2, 0x3

    .line 29
    invoke-direct {v0, v1, v2}, Lb5;-><init>(II)V

    .line 30
    .line 31
    .line 32
    sput-object v0, Lb5;->j:Lb5;

    .line 33
    .line 34
    new-instance v0, Lb5;

    .line 35
    .line 36
    const/4 v2, 0x4

    .line 37
    invoke-direct {v0, v1, v2}, Lb5;-><init>(II)V

    .line 38
    .line 39
    .line 40
    sput-object v0, Lb5;->k:Lb5;

    .line 41
    .line 42
    new-instance v0, Lb5;

    .line 43
    .line 44
    const/4 v2, 0x5

    .line 45
    invoke-direct {v0, v1, v2}, Lb5;-><init>(II)V

    .line 46
    .line 47
    .line 48
    sput-object v0, Lb5;->l:Lb5;

    .line 49
    .line 50
    new-instance v0, Lb5;

    .line 51
    .line 52
    const/4 v2, 0x6

    .line 53
    invoke-direct {v0, v1, v2}, Lb5;-><init>(II)V

    .line 54
    .line 55
    .line 56
    sput-object v0, Lb5;->m:Lb5;

    .line 57
    .line 58
    new-instance v0, Lb5;

    .line 59
    .line 60
    const/4 v2, 0x7

    .line 61
    invoke-direct {v0, v1, v2}, Lb5;-><init>(II)V

    .line 62
    .line 63
    .line 64
    sput-object v0, Lb5;->n:Lb5;

    .line 65
    .line 66
    new-instance v0, Lb5;

    .line 67
    .line 68
    const/16 v2, 0x8

    .line 69
    .line 70
    invoke-direct {v0, v1, v2}, Lb5;-><init>(II)V

    .line 71
    .line 72
    .line 73
    sput-object v0, Lb5;->o:Lb5;

    .line 74
    .line 75
    new-instance v0, Lb5;

    .line 76
    .line 77
    const/16 v2, 0x9

    .line 78
    .line 79
    invoke-direct {v0, v1, v2}, Lb5;-><init>(II)V

    .line 80
    .line 81
    .line 82
    sput-object v0, Lb5;->p:Lb5;

    .line 83
    .line 84
    new-instance v0, Lb5;

    .line 85
    .line 86
    const/16 v2, 0xa

    .line 87
    .line 88
    invoke-direct {v0, v1, v2}, Lb5;-><init>(II)V

    .line 89
    .line 90
    .line 91
    sput-object v0, Lb5;->q:Lb5;

    .line 92
    .line 93
    new-instance v0, Lb5;

    .line 94
    .line 95
    const/16 v2, 0xb

    .line 96
    .line 97
    invoke-direct {v0, v1, v2}, Lb5;-><init>(II)V

    .line 98
    .line 99
    .line 100
    sput-object v0, Lb5;->r:Lb5;

    .line 101
    .line 102
    new-instance v0, Lb5;

    .line 103
    .line 104
    const/16 v2, 0xc

    .line 105
    .line 106
    invoke-direct {v0, v1, v2}, Lb5;-><init>(II)V

    .line 107
    .line 108
    .line 109
    sput-object v0, Lb5;->s:Lb5;

    .line 110
    .line 111
    new-instance v0, Lb5;

    .line 112
    .line 113
    const/16 v2, 0xd

    .line 114
    .line 115
    invoke-direct {v0, v1, v2}, Lb5;-><init>(II)V

    .line 116
    .line 117
    .line 118
    sput-object v0, Lb5;->t:Lb5;

    .line 119
    .line 120
    new-instance v0, Lb5;

    .line 121
    .line 122
    const/16 v2, 0xe

    .line 123
    .line 124
    invoke-direct {v0, v1, v2}, Lb5;-><init>(II)V

    .line 125
    .line 126
    .line 127
    sput-object v0, Lb5;->u:Lb5;

    .line 128
    .line 129
    new-instance v0, Lb5;

    .line 130
    .line 131
    const/16 v2, 0xf

    .line 132
    .line 133
    invoke-direct {v0, v1, v2}, Lb5;-><init>(II)V

    .line 134
    .line 135
    .line 136
    sput-object v0, Lb5;->v:Lb5;

    .line 137
    .line 138
    new-instance v0, Lb5;

    .line 139
    .line 140
    const/16 v2, 0x10

    .line 141
    .line 142
    invoke-direct {v0, v1, v2}, Lb5;-><init>(II)V

    .line 143
    .line 144
    .line 145
    sput-object v0, Lb5;->w:Lb5;

    .line 146
    .line 147
    new-instance v0, Lb5;

    .line 148
    .line 149
    const/16 v2, 0x11

    .line 150
    .line 151
    invoke-direct {v0, v1, v2}, Lb5;-><init>(II)V

    .line 152
    .line 153
    .line 154
    sput-object v0, Lb5;->x:Lb5;

    .line 155
    .line 156
    new-instance v0, Lb5;

    .line 157
    .line 158
    const/16 v2, 0x12

    .line 159
    .line 160
    invoke-direct {v0, v1, v2}, Lb5;-><init>(II)V

    .line 161
    .line 162
    .line 163
    sput-object v0, Lb5;->y:Lb5;

    .line 164
    .line 165
    new-instance v0, Lb5;

    .line 166
    .line 167
    const/16 v2, 0x13

    .line 168
    .line 169
    invoke-direct {v0, v1, v2}, Lb5;-><init>(II)V

    .line 170
    .line 171
    .line 172
    sput-object v0, Lb5;->z:Lb5;

    .line 173
    .line 174
    new-instance v0, Lb5;

    .line 175
    .line 176
    const/16 v2, 0x14

    .line 177
    .line 178
    invoke-direct {v0, v1, v2}, Lb5;-><init>(II)V

    .line 179
    .line 180
    .line 181
    sput-object v0, Lb5;->A:Lb5;

    .line 182
    .line 183
    new-instance v0, Lb5;

    .line 184
    .line 185
    const/16 v2, 0x15

    .line 186
    .line 187
    invoke-direct {v0, v1, v2}, Lb5;-><init>(II)V

    .line 188
    .line 189
    .line 190
    sput-object v0, Lb5;->B:Lb5;

    .line 191
    .line 192
    new-instance v0, Lb5;

    .line 193
    .line 194
    const/16 v2, 0x16

    .line 195
    .line 196
    invoke-direct {v0, v1, v2}, Lb5;-><init>(II)V

    .line 197
    .line 198
    .line 199
    sput-object v0, Lb5;->C:Lb5;

    .line 200
    .line 201
    new-instance v0, Lb5;

    .line 202
    .line 203
    const/16 v2, 0x17

    .line 204
    .line 205
    invoke-direct {v0, v1, v2}, Lb5;-><init>(II)V

    .line 206
    .line 207
    .line 208
    sput-object v0, Lb5;->D:Lb5;

    .line 209
    .line 210
    new-instance v0, Lb5;

    .line 211
    .line 212
    const/16 v2, 0x18

    .line 213
    .line 214
    invoke-direct {v0, v1, v2}, Lb5;-><init>(II)V

    .line 215
    .line 216
    .line 217
    sput-object v0, Lb5;->E:Lb5;

    .line 218
    .line 219
    new-instance v0, Lb5;

    .line 220
    .line 221
    const/16 v2, 0x19

    .line 222
    .line 223
    invoke-direct {v0, v1, v2}, Lb5;-><init>(II)V

    .line 224
    .line 225
    .line 226
    sput-object v0, Lb5;->F:Lb5;

    .line 227
    .line 228
    new-instance v0, Lb5;

    .line 229
    .line 230
    const/16 v2, 0x1a

    .line 231
    .line 232
    invoke-direct {v0, v1, v2}, Lb5;-><init>(II)V

    .line 233
    .line 234
    .line 235
    sput-object v0, Lb5;->G:Lb5;

    .line 236
    .line 237
    new-instance v0, Lb5;

    .line 238
    .line 239
    const/16 v2, 0x1b

    .line 240
    .line 241
    invoke-direct {v0, v1, v2}, Lb5;-><init>(II)V

    .line 242
    .line 243
    .line 244
    sput-object v0, Lb5;->H:Lb5;

    .line 245
    .line 246
    new-instance v0, Lb5;

    .line 247
    .line 248
    const/16 v2, 0x1c

    .line 249
    .line 250
    invoke-direct {v0, v1, v2}, Lb5;-><init>(II)V

    .line 251
    .line 252
    .line 253
    sput-object v0, Lb5;->I:Lb5;

    .line 254
    .line 255
    new-instance v0, Lb5;

    .line 256
    .line 257
    const/16 v2, 0x1d

    .line 258
    .line 259
    invoke-direct {v0, v1, v2}, Lb5;-><init>(II)V

    .line 260
    .line 261
    .line 262
    sput-object v0, Lb5;->J:Lb5;

    .line 263
    .line 264
    return-void
.end method

.method public synthetic constructor <init>(II)V
    .registers 3

    .line 1
    iput p2, p0, Lb5;->f:I

    .line 2
    .line 3
    invoke-direct {p0, p1}, Lh90;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .registers 6

    .line 1
    iget p0, p0, Lb5;->f:I

    .line 2
    .line 3
    const/4 v0, 0x2

    .line 4
    sget-object v1, Lwe1;->a:Lwe1;

    .line 5
    .line 6
    const/4 v2, 0x0

    .line 7
    packed-switch p0, :pswitch_data_c0

    .line 8
    .line 9
    .line 10
    const-string p0, "LocalProvidableLocaleList"

    .line 11
    .line 12
    invoke-static {p0}, Lfk;->b(Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    throw v2

    .line 16
    :pswitch_f  #0x1c
    return-object v2

    .line 17
    :pswitch_10  #0x1b
    const-string p0, "LocalLayoutDirection"

    .line 18
    .line 19
    invoke-static {p0}, Lfk;->b(Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    throw v2

    .line 23
    :pswitch_16  #0x1a
    const-string p0, "LocalInputManager"

    .line 24
    .line 25
    invoke-static {p0}, Lfk;->b(Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    throw v2

    .line 29
    :pswitch_1c  #0x19
    const-string p0, "LocalHapticFeedback"

    .line 30
    .line 31
    invoke-static {p0}, Lfk;->b(Ljava/lang/String;)V

    .line 32
    .line 33
    .line 34
    throw v2

    .line 35
    :pswitch_22  #0x18
    const-string p0, "LocalGraphicsContext"

    .line 36
    .line 37
    invoke-static {p0}, Lfk;->b(Ljava/lang/String;)V

    .line 38
    .line 39
    .line 40
    throw v2

    .line 41
    :pswitch_28  #0x17
    const-string p0, "LocalFontLoader"

    .line 42
    .line 43
    invoke-static {p0}, Lfk;->b(Ljava/lang/String;)V

    .line 44
    .line 45
    .line 46
    throw v2

    .line 47
    :pswitch_2e  #0x16
    const-string p0, "LocalFontFamilyResolver"

    .line 48
    .line 49
    invoke-static {p0}, Lfk;->b(Ljava/lang/String;)V

    .line 50
    .line 51
    .line 52
    throw v2

    .line 53
    :pswitch_34  #0x15
    const-string p0, "LocalFocusManager"

    .line 54
    .line 55
    invoke-static {p0}, Lfk;->b(Ljava/lang/String;)V

    .line 56
    .line 57
    .line 58
    throw v2

    .line 59
    :pswitch_3a  #0x14
    const-string p0, "LocalDensity"

    .line 60
    .line 61
    invoke-static {p0}, Lfk;->b(Ljava/lang/String;)V

    .line 62
    .line 63
    .line 64
    throw v2

    .line 65
    :pswitch_40  #0x13
    sget-object p0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 66
    .line 67
    return-object p0

    .line 68
    :pswitch_43  #0x12
    const-string p0, "LocalClipboardManager"

    .line 69
    .line 70
    invoke-static {p0}, Lfk;->b(Ljava/lang/String;)V

    .line 71
    .line 72
    .line 73
    throw v2

    .line 74
    :pswitch_49  #0x11
    const-string p0, "LocalClipboard"

    .line 75
    .line 76
    invoke-static {p0}, Lfk;->b(Ljava/lang/String;)V

    .line 77
    .line 78
    .line 79
    throw v2

    .line 80
    :pswitch_4f  #0x10
    const-string p0, "LocalAutofillTree"

    .line 81
    .line 82
    invoke-static {p0}, Lfk;->b(Ljava/lang/String;)V

    .line 83
    .line 84
    .line 85
    throw v2

    .line 86
    :pswitch_55  #0xf
    const-string p0, "LocalAutofillManager"

    .line 87
    .line 88
    invoke-static {p0}, Lfk;->b(Ljava/lang/String;)V

    .line 89
    .line 90
    .line 91
    throw v2

    .line 92
    :pswitch_5b  #0xd, 0xe
    return-object v2

    .line 93
    :pswitch_5c  #0xc
    new-instance p0, Lba0;

    .line 94
    .line 95
    invoke-direct {p0, v0}, Lba0;-><init>(I)V

    .line 96
    .line 97
    .line 98
    return-object p0

    .line 99
    :pswitch_62  #0x9, 0xa, 0xb
    return-object v1

    .line 100
    :pswitch_63  #0x8
    new-instance p0, Ld7;

    .line 101
    .line 102
    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    .line 103
    .line 104
    .line 105
    move-result-object v1

    .line 106
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 107
    .line 108
    .line 109
    move-result-object v3

    .line 110
    if-ne v1, v3, :cond_74

    .line 111
    .line 112
    invoke-static {}, Landroid/view/Choreographer;->getInstance()Landroid/view/Choreographer;

    .line 113
    .line 114
    .line 115
    move-result-object v0

    .line 116
    goto :goto_84

    .line 117
    :cond_74
    sget-object v1, Lkq;->a:Luo;

    .line 118
    .line 119
    sget-object v1, Lkg0;->a:Lw20;

    .line 120
    .line 121
    new-instance v3, La7;

    .line 122
    .line 123
    const/4 v4, 0x0

    .line 124
    invoke-direct {v3, v0, v2, v4}, La7;-><init>(ILml;I)V

    .line 125
    .line 126
    .line 127
    invoke-static {v1, v3}, Lwl1;->G(Lsl;Lm00;)Ljava/lang/Object;

    .line 128
    .line 129
    .line 130
    move-result-object v0

    .line 131
    check-cast v0, Landroid/view/Choreographer;

    .line 132
    .line 133
    :goto_84
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 134
    .line 135
    .line 136
    move-result-object v1

    .line 137
    invoke-static {v1}, Lvd1;->j(Landroid/os/Looper;)Landroid/os/Handler;

    .line 138
    .line 139
    .line 140
    move-result-object v1

    .line 141
    invoke-direct {p0, v0, v1}, Ld7;-><init>(Landroid/view/Choreographer;Landroid/os/Handler;)V

    .line 142
    .line 143
    .line 144
    iget-object v0, p0, Ld7;->p:Lg7;

    .line 145
    .line 146
    invoke-static {p0, v0}, Lvn;->O(Lql;Lsl;)Lsl;

    .line 147
    .line 148
    .line 149
    move-result-object p0

    .line 150
    return-object p0

    .line 151
    :pswitch_96  #0x7
    const-string p0, "DEFAULT_TEST_TAG"

    .line 152
    .line 153
    return-object p0

    .line 154
    :pswitch_99  #0x6
    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 155
    .line 156
    return-object p0

    .line 157
    :pswitch_9c  #0x5
    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    .line 158
    .line 159
    .line 160
    move-result-object p0

    .line 161
    return-object p0

    .line 162
    :pswitch_a1  #0x4
    const-string p0, "LocalView"

    .line 163
    .line 164
    invoke-static {p0}, Lc5;->a(Ljava/lang/String;)V

    .line 165
    .line 166
    .line 167
    throw v2

    .line 168
    :pswitch_a7  #0x3
    const-string p0, "LocalResourceIdCache"

    .line 169
    .line 170
    invoke-static {p0}, Lc5;->a(Ljava/lang/String;)V

    .line 171
    .line 172
    .line 173
    throw v2

    .line 174
    :pswitch_ad  #0x2
    const-string p0, "LocalImageVectorCache"

    .line 175
    .line 176
    invoke-static {p0}, Lc5;->a(Ljava/lang/String;)V

    .line 177
    .line 178
    .line 179
    throw v2

    .line 180
    :pswitch_b3  #0x1
    const-string p0, "LocalContext"

    .line 181
    .line 182
    invoke-static {p0}, Lc5;->a(Ljava/lang/String;)V

    .line 183
    .line 184
    .line 185
    throw v2

    .line 186
    :pswitch_b9  #0x0
    const-string p0, "LocalConfiguration"

    .line 187
    .line 188
    invoke-static {p0}, Lc5;->a(Ljava/lang/String;)V

    .line 189
    .line 190
    .line 191
    throw v2

    .line 192
    nop

    .line 193
    :pswitch_data_c0
    .packed-switch 0x0
        :pswitch_b9  #00000000
        :pswitch_b3  #00000001
        :pswitch_ad  #00000002
        :pswitch_a7  #00000003
        :pswitch_a1  #00000004
        :pswitch_9c  #00000005
        :pswitch_99  #00000006
        :pswitch_96  #00000007
        :pswitch_63  #00000008
        :pswitch_62  #00000009
        :pswitch_62  #0000000a
        :pswitch_62  #0000000b
        :pswitch_5c  #0000000c
        :pswitch_5b  #0000000d
        :pswitch_5b  #0000000e
        :pswitch_55  #0000000f
        :pswitch_4f  #00000010
        :pswitch_49  #00000011
        :pswitch_43  #00000012
        :pswitch_40  #00000013
        :pswitch_3a  #00000014
        :pswitch_34  #00000015
        :pswitch_2e  #00000016
        :pswitch_28  #00000017
        :pswitch_22  #00000018
        :pswitch_1c  #00000019
        :pswitch_16  #0000001a
        :pswitch_10  #0000001b
        :pswitch_f  #0000001c
    .end packed-switch
.end method
