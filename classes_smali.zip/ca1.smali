.class public abstract Lca1;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# static fields
.field public static final a:F

.field public static final b:F

.field public static final c:F

.field public static final d:F

.field public static final e:F

.field public static final f:Lf61;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    sget v0, Lj70;->u:F

    .line 2
    .line 3
    sput v0, Lca1;->a:F

    .line 4
    .line 5
    sget v1, Lj70;->E:F

    .line 6
    .line 7
    sput v1, Lca1;->b:F

    .line 8
    .line 9
    sget v1, Lj70;->B:F

    .line 10
    .line 11
    sput v1, Lca1;->c:F

    .line 12
    .line 13
    sget v1, Lj70;->y:F

    .line 14
    .line 15
    sput v1, Lca1;->d:F

    .line 16
    .line 17
    sub-float/2addr v1, v0

    .line 18
    const/high16 v0, 0x40000000  # 2.0f

    .line 19
    .line 20
    div-float/2addr v1, v0

    .line 21
    sput v1, Lca1;->e:F

    .line 22
    .line 23
    new-instance v0, Lf61;

    .line 24
    .line 25
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 26
    .line 27
    .line 28
    sput-object v0, Lca1;->f:Lf61;

    .line 29
    .line 30
    return-void
.end method

.method public static final a(ZLi00;Lmi0;ZLz91;Ld10;I)V
    .registers 53

    .line 1
    move-object/from16 v2, p1

    .line 2
    .line 3
    move-object/from16 v6, p5

    .line 4
    .line 5
    const v0, -0xfb23c9f

    .line 6
    .line 7
    .line 8
    invoke-virtual {v6, v0}, Ld10;->X(I)Ld10;

    .line 9
    .line 10
    .line 11
    move/from16 v1, p0

    .line 12
    .line 13
    invoke-virtual {v6, v1}, Ld10;->g(Z)Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-eqz v0, :cond_14

    .line 18
    .line 19
    const/4 v0, 0x4

    .line 20
    goto :goto_15

    .line 21
    :cond_14
    const/4 v0, 0x2

    .line 22
    :goto_15
    or-int v0, p6, v0

    .line 23
    .line 24
    invoke-virtual {v6, v2}, Ld10;->h(Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v4

    .line 28
    if-eqz v4, :cond_20

    .line 29
    .line 30
    const/16 v4, 0x20

    .line 31
    .line 32
    goto :goto_22

    .line 33
    :cond_20
    const/16 v4, 0x10

    .line 34
    .line 35
    :goto_22
    or-int/2addr v0, v4

    .line 36
    const v4, 0x196c00

    .line 37
    .line 38
    .line 39
    or-int/2addr v0, v4

    .line 40
    const v4, 0x92493

    .line 41
    .line 42
    .line 43
    and-int/2addr v4, v0

    .line 44
    const v5, 0x92492

    .line 45
    .line 46
    .line 47
    const/4 v7, 0x0

    .line 48
    if-eq v4, v5, :cond_33

    .line 49
    .line 50
    const/4 v4, 0x1

    .line 51
    goto :goto_34

    .line 52
    :cond_33
    move v4, v7

    .line 53
    :goto_34
    and-int/lit8 v5, v0, 0x1

    .line 54
    .line 55
    invoke-virtual {v6, v5, v4}, Ld10;->O(IZ)Z

    .line 56
    .line 57
    .line 58
    move-result v4

    .line 59
    if-eqz v4, :cond_17d

    .line 60
    .line 61
    invoke-virtual {v6}, Ld10;->T()V

    .line 62
    .line 63
    .line 64
    and-int/lit8 v4, p6, 0x1

    .line 65
    .line 66
    const v5, -0x70001

    .line 67
    .line 68
    .line 69
    if-eqz v4, :cond_58

    .line 70
    .line 71
    invoke-virtual {v6}, Ld10;->y()Z

    .line 72
    .line 73
    .line 74
    move-result v4

    .line 75
    if-eqz v4, :cond_4d

    .line 76
    .line 77
    goto :goto_58

    .line 78
    :cond_4d
    invoke-virtual {v6}, Ld10;->R()V

    .line 79
    .line 80
    .line 81
    and-int/2addr v0, v5

    .line 82
    move/from16 v3, p3

    .line 83
    .line 84
    move-object/from16 v9, p4

    .line 85
    .line 86
    :goto_55
    move v8, v0

    .line 87
    goto/16 :goto_114

    .line 88
    .line 89
    :cond_58
    :goto_58
    sget-object v4, Lfh0;->a:Lk81;

    .line 90
    .line 91
    invoke-virtual {v6, v4}, Ld10;->j(Llv0;)Ljava/lang/Object;

    .line 92
    .line 93
    .line 94
    move-result-object v4

    .line 95
    check-cast v4, Ldh0;

    .line 96
    .line 97
    iget-object v4, v4, Ldh0;->a:Ldh;

    .line 98
    .line 99
    iget-object v9, v4, Ldh;->Z:Lz91;

    .line 100
    .line 101
    iget-wide v10, v4, Ldh;->p:J

    .line 102
    .line 103
    if-nez v9, :cond_10d

    .line 104
    .line 105
    new-instance v12, Lz91;

    .line 106
    .line 107
    sget-object v9, Lj70;->t:Leh;

    .line 108
    .line 109
    invoke-static {v4, v9}, Lfh;->c(Ldh;Leh;)J

    .line 110
    .line 111
    .line 112
    move-result-wide v13

    .line 113
    sget-object v9, Lj70;->w:Leh;

    .line 114
    .line 115
    invoke-static {v4, v9}, Lfh;->c(Ldh;Leh;)J

    .line 116
    .line 117
    .line 118
    move-result-wide v15

    .line 119
    sget-wide v17, Lzg;->h:J

    .line 120
    .line 121
    sget-object v9, Lj70;->v:Leh;

    .line 122
    .line 123
    invoke-static {v4, v9}, Lfh;->c(Ldh;Leh;)J

    .line 124
    .line 125
    .line 126
    move-result-wide v19

    .line 127
    sget-object v9, Lj70;->D:Leh;

    .line 128
    .line 129
    invoke-static {v4, v9}, Lfh;->c(Ldh;Leh;)J

    .line 130
    .line 131
    .line 132
    move-result-wide v21

    .line 133
    sget-object v9, Lj70;->G:Leh;

    .line 134
    .line 135
    invoke-static {v4, v9}, Lfh;->c(Ldh;Leh;)J

    .line 136
    .line 137
    .line 138
    move-result-wide v23

    .line 139
    sget-object v9, Lj70;->C:Leh;

    .line 140
    .line 141
    invoke-static {v4, v9}, Lfh;->c(Ldh;Leh;)J

    .line 142
    .line 143
    .line 144
    move-result-wide v25

    .line 145
    sget-object v9, Lj70;->F:Leh;

    .line 146
    .line 147
    invoke-static {v4, v9}, Lfh;->c(Ldh;Leh;)J

    .line 148
    .line 149
    .line 150
    move-result-wide v27

    .line 151
    sget-object v9, Lj70;->f:Leh;

    .line 152
    .line 153
    invoke-static {v4, v9}, Lfh;->c(Ldh;Leh;)J

    .line 154
    .line 155
    .line 156
    move-result-wide v8

    .line 157
    move/from16 v45, v5

    .line 158
    .line 159
    sget v5, Lj70;->g:F

    .line 160
    .line 161
    invoke-static {v8, v9, v5}, Lzg;->b(JF)J

    .line 162
    .line 163
    .line 164
    move-result-wide v8

    .line 165
    invoke-static {v8, v9, v10, v11}, Lwl1;->q(JJ)J

    .line 166
    .line 167
    .line 168
    move-result-wide v29

    .line 169
    sget-object v5, Lj70;->j:Leh;

    .line 170
    .line 171
    invoke-static {v4, v5}, Lfh;->c(Ldh;Leh;)J

    .line 172
    .line 173
    .line 174
    move-result-wide v8

    .line 175
    sget v5, Lj70;->k:F

    .line 176
    .line 177
    invoke-static {v8, v9, v5}, Lzg;->b(JF)J

    .line 178
    .line 179
    .line 180
    move-result-wide v8

    .line 181
    invoke-static {v8, v9, v10, v11}, Lwl1;->q(JJ)J

    .line 182
    .line 183
    .line 184
    move-result-wide v31

    .line 185
    sget-object v8, Lj70;->h:Leh;

    .line 186
    .line 187
    invoke-static {v4, v8}, Lfh;->c(Ldh;Leh;)J

    .line 188
    .line 189
    .line 190
    move-result-wide v8

    .line 191
    sget v3, Lj70;->i:F

    .line 192
    .line 193
    invoke-static {v8, v9, v3}, Lzg;->b(JF)J

    .line 194
    .line 195
    .line 196
    move-result-wide v8

    .line 197
    invoke-static {v8, v9, v10, v11}, Lwl1;->q(JJ)J

    .line 198
    .line 199
    .line 200
    move-result-wide v35

    .line 201
    sget-object v3, Lj70;->l:Leh;

    .line 202
    .line 203
    invoke-static {v4, v3}, Lfh;->c(Ldh;Leh;)J

    .line 204
    .line 205
    .line 206
    move-result-wide v8

    .line 207
    sget v3, Lj70;->m:F

    .line 208
    .line 209
    invoke-static {v8, v9, v3}, Lzg;->b(JF)J

    .line 210
    .line 211
    .line 212
    move-result-wide v8

    .line 213
    invoke-static {v8, v9, v10, v11}, Lwl1;->q(JJ)J

    .line 214
    .line 215
    .line 216
    move-result-wide v37

    .line 217
    sget-object v3, Lj70;->p:Leh;

    .line 218
    .line 219
    invoke-static {v4, v3}, Lfh;->c(Ldh;Leh;)J

    .line 220
    .line 221
    .line 222
    move-result-wide v8

    .line 223
    invoke-static {v8, v9, v5}, Lzg;->b(JF)J

    .line 224
    .line 225
    .line 226
    move-result-wide v8

    .line 227
    invoke-static {v8, v9, v10, v11}, Lwl1;->q(JJ)J

    .line 228
    .line 229
    .line 230
    move-result-wide v39

    .line 231
    sget-object v3, Lj70;->q:Leh;

    .line 232
    .line 233
    invoke-static {v4, v3}, Lfh;->c(Ldh;Leh;)J

    .line 234
    .line 235
    .line 236
    move-result-wide v8

    .line 237
    invoke-static {v8, v9, v5}, Lzg;->b(JF)J

    .line 238
    .line 239
    .line 240
    move-result-wide v8

    .line 241
    invoke-static {v8, v9, v10, v11}, Lwl1;->q(JJ)J

    .line 242
    .line 243
    .line 244
    move-result-wide v41

    .line 245
    sget-object v3, Lj70;->n:Leh;

    .line 246
    .line 247
    invoke-static {v4, v3}, Lfh;->c(Ldh;Leh;)J

    .line 248
    .line 249
    .line 250
    move-result-wide v8

    .line 251
    sget v3, Lj70;->o:F

    .line 252
    .line 253
    invoke-static {v8, v9, v3}, Lzg;->b(JF)J

    .line 254
    .line 255
    .line 256
    move-result-wide v8

    .line 257
    invoke-static {v8, v9, v10, v11}, Lwl1;->q(JJ)J

    .line 258
    .line 259
    .line 260
    move-result-wide v43

    .line 261
    move-wide/from16 v33, v17

    .line 262
    .line 263
    invoke-direct/range {v12 .. v44}, Lz91;-><init>(JJJJJJJJJJJJJJJJ)V

    .line 264
    .line 265
    .line 266
    iput-object v12, v4, Ldh;->Z:Lz91;

    .line 267
    .line 268
    move-object v9, v12

    .line 269
    goto :goto_10f

    .line 270
    :cond_10d
    move/from16 v45, v5

    .line 271
    .line 272
    :goto_10f
    and-int v0, v0, v45

    .line 273
    .line 274
    const/4 v3, 0x1

    .line 275
    goto/16 :goto_55

    .line 276
    .line 277
    :goto_114
    invoke-virtual {v6}, Ld10;->q()V

    .line 278
    .line 279
    .line 280
    const v0, 0x6969555a

    .line 281
    .line 282
    .line 283
    invoke-virtual {v6, v0}, Ld10;->W(I)V

    .line 284
    .line 285
    .line 286
    invoke-virtual {v6}, Ld10;->L()Ljava/lang/Object;

    .line 287
    .line 288
    .line 289
    move-result-object v0

    .line 290
    sget-object v4, Loj;->a:Lnq0;

    .line 291
    .line 292
    if-ne v0, v4, :cond_12d

    .line 293
    .line 294
    new-instance v0, Luj0;

    .line 295
    .line 296
    invoke-direct {v0}, Luj0;-><init>()V

    .line 297
    .line 298
    .line 299
    invoke-virtual {v6, v0}, Ld10;->g0(Ljava/lang/Object;)V

    .line 300
    .line 301
    .line 302
    :cond_12d
    move-object v4, v0

    .line 303
    check-cast v4, Luj0;

    .line 304
    .line 305
    invoke-virtual {v6, v7}, Ld10;->p(Z)V

    .line 306
    .line 307
    .line 308
    if-eqz v2, :cond_14b

    .line 309
    .line 310
    sget-object v0, Lb70;->a:Lh30;

    .line 311
    .line 312
    sget-object v0, Lfi0;->a:Lfi0;

    .line 313
    .line 314
    move-object v2, v4

    .line 315
    new-instance v4, Liy0;

    .line 316
    .line 317
    const/4 v5, 0x2

    .line 318
    invoke-direct {v4, v5}, Liy0;-><init>(I)V

    .line 319
    .line 320
    .line 321
    move-object/from16 v5, p1

    .line 322
    .line 323
    invoke-static/range {v0 .. v5}, Lvd1;->I(Lmi0;ZLuj0;ZLiy0;Li00;)Lmi0;

    .line 324
    .line 325
    .line 326
    move-result-object v0

    .line 327
    move-object v4, v2

    .line 328
    move v2, v3

    .line 329
    :goto_148
    move-object/from16 v10, p2

    .line 330
    .line 331
    goto :goto_14f

    .line 332
    :cond_14b
    move v2, v3

    .line 333
    sget-object v0, Lji0;->a:Lji0;

    .line 334
    .line 335
    goto :goto_148

    .line 336
    :goto_14f
    invoke-interface {v10, v0}, Lmi0;->b(Lmi0;)Lmi0;

    .line 337
    .line 338
    .line 339
    move-result-object v0

    .line 340
    invoke-static {v0}, Lu51;->g(Lmi0;)Lmi0;

    .line 341
    .line 342
    .line 343
    move-result-object v0

    .line 344
    new-instance v11, Lt51;

    .line 345
    .line 346
    const/16 v16, 0x0

    .line 347
    .line 348
    sget v12, Lca1;->c:F

    .line 349
    .line 350
    sget v13, Lca1;->d:F

    .line 351
    .line 352
    move v14, v12

    .line 353
    move v15, v13

    .line 354
    invoke-direct/range {v11 .. v16}, Lt51;-><init>(FFFFZ)V

    .line 355
    .line 356
    .line 357
    invoke-interface {v0, v11}, Lmi0;->b(Lmi0;)Lmi0;

    .line 358
    .line 359
    .line 360
    move-result-object v0

    .line 361
    sget-object v1, Lj70;->r:La51;

    .line 362
    .line 363
    invoke-static {v1, v6}, Ld51;->a(La51;Ld10;)Ly41;

    .line 364
    .line 365
    .line 366
    move-result-object v5

    .line 367
    shl-int/lit8 v1, v8, 0x3

    .line 368
    .line 369
    and-int/lit8 v1, v1, 0x70

    .line 370
    .line 371
    or-int/lit16 v7, v1, 0x6180

    .line 372
    .line 373
    move/from16 v1, p0

    .line 374
    .line 375
    move-object v3, v9

    .line 376
    invoke-static/range {v0 .. v7}, Lca1;->b(Lmi0;ZZLz91;Luj0;Ly41;Ld10;I)V

    .line 377
    .line 378
    .line 379
    move v4, v2

    .line 380
    move-object v5, v3

    .line 381
    goto :goto_186

    .line 382
    :cond_17d
    move-object/from16 v10, p2

    .line 383
    .line 384
    invoke-virtual/range {p5 .. p5}, Ld10;->R()V

    .line 385
    .line 386
    .line 387
    move/from16 v4, p3

    .line 388
    .line 389
    move-object/from16 v5, p4

    .line 390
    .line 391
    :goto_186
    invoke-virtual/range {p5 .. p5}, Ld10;->r()Lxv0;

    .line 392
    .line 393
    .line 394
    move-result-object v7

    .line 395
    if-eqz v7, :cond_19a

    .line 396
    .line 397
    new-instance v0, Laa1;

    .line 398
    .line 399
    move/from16 v1, p0

    .line 400
    .line 401
    move-object/from16 v2, p1

    .line 402
    .line 403
    move/from16 v6, p6

    .line 404
    .line 405
    move-object v3, v10

    .line 406
    invoke-direct/range {v0 .. v6}, Laa1;-><init>(ZLi00;Lmi0;ZLz91;I)V

    .line 407
    .line 408
    .line 409
    iput-object v0, v7, Lxv0;->d:Lm00;

    .line 410
    .line 411
    :cond_19a
    return-void
.end method

.method public static final b(Lmi0;ZZLz91;Luj0;Ly41;Ld10;I)V
    .registers 27

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move/from16 v2, p1

    .line 4
    .line 5
    move/from16 v3, p2

    .line 6
    .line 7
    move-object/from16 v4, p3

    .line 8
    .line 9
    move-object/from16 v5, p4

    .line 10
    .line 11
    move-object/from16 v6, p5

    .line 12
    .line 13
    move-object/from16 v0, p6

    .line 14
    .line 15
    move/from16 v7, p7

    .line 16
    .line 17
    const v8, -0x27fd625d

    .line 18
    .line 19
    .line 20
    invoke-virtual {v0, v8}, Ld10;->X(I)Ld10;

    .line 21
    .line 22
    .line 23
    and-int/lit8 v8, v7, 0x6

    .line 24
    .line 25
    if-nez v8, :cond_25

    .line 26
    .line 27
    invoke-virtual {v0, v1}, Ld10;->f(Ljava/lang/Object;)Z

    .line 28
    .line 29
    .line 30
    move-result v8

    .line 31
    if-eqz v8, :cond_22

    .line 32
    .line 33
    const/4 v8, 0x4

    .line 34
    goto :goto_23

    .line 35
    :cond_22
    const/4 v8, 0x2

    .line 36
    :goto_23
    or-int/2addr v8, v7

    .line 37
    goto :goto_26

    .line 38
    :cond_25
    move v8, v7

    .line 39
    :goto_26
    and-int/lit8 v10, v7, 0x30

    .line 40
    .line 41
    if-nez v10, :cond_36

    .line 42
    .line 43
    invoke-virtual {v0, v2}, Ld10;->g(Z)Z

    .line 44
    .line 45
    .line 46
    move-result v10

    .line 47
    if-eqz v10, :cond_33

    .line 48
    .line 49
    const/16 v10, 0x20

    .line 50
    .line 51
    goto :goto_35

    .line 52
    :cond_33
    const/16 v10, 0x10

    .line 53
    .line 54
    :goto_35
    or-int/2addr v8, v10

    .line 55
    :cond_36
    and-int/lit16 v10, v7, 0x180

    .line 56
    .line 57
    if-nez v10, :cond_46

    .line 58
    .line 59
    invoke-virtual {v0, v3}, Ld10;->g(Z)Z

    .line 60
    .line 61
    .line 62
    move-result v10

    .line 63
    if-eqz v10, :cond_43

    .line 64
    .line 65
    const/16 v10, 0x100

    .line 66
    .line 67
    goto :goto_45

    .line 68
    :cond_43
    const/16 v10, 0x80

    .line 69
    .line 70
    :goto_45
    or-int/2addr v8, v10

    .line 71
    :cond_46
    and-int/lit16 v10, v7, 0xc00

    .line 72
    .line 73
    if-nez v10, :cond_56

    .line 74
    .line 75
    invoke-virtual {v0, v4}, Ld10;->f(Ljava/lang/Object;)Z

    .line 76
    .line 77
    .line 78
    move-result v10

    .line 79
    if-eqz v10, :cond_53

    .line 80
    .line 81
    const/16 v10, 0x800

    .line 82
    .line 83
    goto :goto_55

    .line 84
    :cond_53
    const/16 v10, 0x400

    .line 85
    .line 86
    :goto_55
    or-int/2addr v8, v10

    .line 87
    :cond_56
    and-int/lit16 v10, v7, 0x6000

    .line 88
    .line 89
    if-nez v10, :cond_67

    .line 90
    .line 91
    const/4 v10, 0x0

    .line 92
    invoke-virtual {v0, v10}, Ld10;->h(Ljava/lang/Object;)Z

    .line 93
    .line 94
    .line 95
    move-result v10

    .line 96
    if-eqz v10, :cond_64

    .line 97
    .line 98
    const/16 v10, 0x4000

    .line 99
    .line 100
    goto :goto_66

    .line 101
    :cond_64
    const/16 v10, 0x2000

    .line 102
    .line 103
    :goto_66
    or-int/2addr v8, v10

    .line 104
    :cond_67
    const/high16 v10, 0x30000

    .line 105
    .line 106
    and-int/2addr v10, v7

    .line 107
    if-nez v10, :cond_78

    .line 108
    .line 109
    invoke-virtual {v0, v5}, Ld10;->f(Ljava/lang/Object;)Z

    .line 110
    .line 111
    .line 112
    move-result v10

    .line 113
    if-eqz v10, :cond_75

    .line 114
    .line 115
    const/high16 v10, 0x20000

    .line 116
    .line 117
    goto :goto_77

    .line 118
    :cond_75
    const/high16 v10, 0x10000

    .line 119
    .line 120
    :goto_77
    or-int/2addr v8, v10

    .line 121
    :cond_78
    const/high16 v10, 0x180000

    .line 122
    .line 123
    and-int/2addr v10, v7

    .line 124
    if-nez v10, :cond_89

    .line 125
    .line 126
    invoke-virtual {v0, v6}, Ld10;->f(Ljava/lang/Object;)Z

    .line 127
    .line 128
    .line 129
    move-result v10

    .line 130
    if-eqz v10, :cond_86

    .line 131
    .line 132
    const/high16 v10, 0x100000

    .line 133
    .line 134
    goto :goto_88

    .line 135
    :cond_86
    const/high16 v10, 0x80000

    .line 136
    .line 137
    :goto_88
    or-int/2addr v8, v10

    .line 138
    :cond_89
    const v10, 0x92493

    .line 139
    .line 140
    .line 141
    and-int/2addr v10, v8

    .line 142
    const v12, 0x92492

    .line 143
    .line 144
    .line 145
    const/4 v13, 0x1

    .line 146
    if-eq v10, v12, :cond_95

    .line 147
    .line 148
    move v10, v13

    .line 149
    goto :goto_96

    .line 150
    :cond_95
    const/4 v10, 0x0

    .line 151
    :goto_96
    and-int/2addr v8, v13

    .line 152
    invoke-virtual {v0, v8, v10}, Ld10;->O(IZ)Z

    .line 153
    .line 154
    .line 155
    move-result v8

    .line 156
    if-eqz v8, :cond_1b4

    .line 157
    .line 158
    if-eqz v3, :cond_ab

    .line 159
    .line 160
    if-eqz v2, :cond_a6

    .line 161
    .line 162
    const/16 v8, 0x20

    .line 163
    .line 164
    iget-wide v11, v4, Lz91;->b:J

    .line 165
    .line 166
    goto :goto_b4

    .line 167
    :cond_a6
    const/16 v8, 0x20

    .line 168
    .line 169
    iget-wide v11, v4, Lz91;->f:J

    .line 170
    .line 171
    goto :goto_b4

    .line 172
    :cond_ab
    const/16 v8, 0x20

    .line 173
    .line 174
    if-eqz v2, :cond_b2

    .line 175
    .line 176
    iget-wide v11, v4, Lz91;->j:J

    .line 177
    .line 178
    goto :goto_b4

    .line 179
    :cond_b2
    iget-wide v11, v4, Lz91;->n:J

    .line 180
    .line 181
    :goto_b4
    if-eqz v3, :cond_bf

    .line 182
    .line 183
    move v15, v8

    .line 184
    if-eqz v2, :cond_bc

    .line 185
    .line 186
    iget-wide v8, v4, Lz91;->a:J

    .line 187
    .line 188
    goto :goto_c7

    .line 189
    :cond_bc
    iget-wide v8, v4, Lz91;->e:J

    .line 190
    .line 191
    goto :goto_c7

    .line 192
    :cond_bf
    move v15, v8

    .line 193
    if-eqz v2, :cond_c5

    .line 194
    .line 195
    iget-wide v8, v4, Lz91;->i:J

    .line 196
    .line 197
    goto :goto_c7

    .line 198
    :cond_c5
    iget-wide v8, v4, Lz91;->m:J

    .line 199
    .line 200
    :goto_c7
    sget-object v10, Lj70;->A:La51;

    .line 201
    .line 202
    invoke-static {v10, v0}, Ld51;->a(La51;Ld10;)Ly41;

    .line 203
    .line 204
    .line 205
    move-result-object v10

    .line 206
    move/from16 v17, v15

    .line 207
    .line 208
    sget v15, Lj70;->z:F

    .line 209
    .line 210
    if-eqz v3, :cond_db

    .line 211
    .line 212
    if-eqz v2, :cond_d8

    .line 213
    .line 214
    iget-wide v13, v4, Lz91;->c:J

    .line 215
    .line 216
    goto :goto_e2

    .line 217
    :cond_d8
    iget-wide v13, v4, Lz91;->g:J

    .line 218
    .line 219
    goto :goto_e2

    .line 220
    :cond_db
    if-eqz v2, :cond_e0

    .line 221
    .line 222
    iget-wide v13, v4, Lz91;->k:J

    .line 223
    .line 224
    goto :goto_e2

    .line 225
    :cond_e0
    iget-wide v13, v4, Lz91;->o:J

    .line 226
    .line 227
    :goto_e2
    new-instance v3, Lf71;

    .line 228
    .line 229
    invoke-direct {v3, v13, v14}, Lf71;-><init>(J)V

    .line 230
    .line 231
    .line 232
    new-instance v13, Lzb;

    .line 233
    .line 234
    invoke-direct {v13, v15, v3, v10}, Lzb;-><init>(FLf71;Ly41;)V

    .line 235
    .line 236
    .line 237
    invoke-interface {v1, v13}, Lmi0;->b(Lmi0;)Lmi0;

    .line 238
    .line 239
    .line 240
    move-result-object v3

    .line 241
    invoke-static {v3, v11, v12, v10}, Lwl1;->n(Lmi0;JLy41;)Lmi0;

    .line 242
    .line 243
    .line 244
    move-result-object v3

    .line 245
    sget-object v10, Le3;->f:Lnb;

    .line 246
    .line 247
    const/4 v11, 0x0

    .line 248
    invoke-static {v10, v11}, Lic;->d(Lnb;Z)Lmh0;

    .line 249
    .line 250
    .line 251
    move-result-object v10

    .line 252
    iget-wide v11, v0, Ld10;->T:J

    .line 253
    .line 254
    ushr-long v13, v11, v17

    .line 255
    .line 256
    xor-long/2addr v11, v13

    .line 257
    long-to-int v11, v11

    .line 258
    invoke-virtual {v0}, Ld10;->l()Lqr0;

    .line 259
    .line 260
    .line 261
    move-result-object v12

    .line 262
    invoke-static {v0, v3}, Lvn;->I(Ld10;Lmi0;)Lmi0;

    .line 263
    .line 264
    .line 265
    move-result-object v3

    .line 266
    sget-object v13, Lij;->c:Lhj;

    .line 267
    .line 268
    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 269
    .line 270
    .line 271
    sget-object v13, Lhj;->b:Ldk;

    .line 272
    .line 273
    invoke-virtual {v0}, Ld10;->Z()V

    .line 274
    .line 275
    .line 276
    iget-boolean v14, v0, Ld10;->S:Z

    .line 277
    .line 278
    if-eqz v14, :cond_11b

    .line 279
    .line 280
    invoke-virtual {v0, v13}, Ld10;->k(Lxz;)V

    .line 281
    .line 282
    .line 283
    goto :goto_11e

    .line 284
    :cond_11b
    invoke-virtual {v0}, Ld10;->j0()V

    .line 285
    .line 286
    .line 287
    :goto_11e
    sget-object v14, Lhj;->f:Ls7;

    .line 288
    .line 289
    invoke-static {v14, v0, v10}, Lmc0;->B(Lm00;Ld10;Ljava/lang/Object;)V

    .line 290
    .line 291
    .line 292
    sget-object v10, Lhj;->e:Ls7;

    .line 293
    .line 294
    invoke-static {v10, v0, v12}, Lmc0;->B(Lm00;Ld10;Ljava/lang/Object;)V

    .line 295
    .line 296
    .line 297
    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 298
    .line 299
    .line 300
    move-result-object v11

    .line 301
    sget-object v12, Lhj;->g:Ls7;

    .line 302
    .line 303
    invoke-static {v0, v11, v12}, Lmc0;->p(Ld10;Ljava/lang/Integer;Lm00;)V

    .line 304
    .line 305
    .line 306
    sget-object v11, Lhj;->h:Li4;

    .line 307
    .line 308
    invoke-static {v0, v11}, Lmc0;->w(Ld10;Li00;)V

    .line 309
    .line 310
    .line 311
    sget-object v15, Lhj;->d:Ls7;

    .line 312
    .line 313
    invoke-static {v15, v0, v3}, Lmc0;->B(Lm00;Ld10;Ljava/lang/Object;)V

    .line 314
    .line 315
    .line 316
    sget-object v3, Le3;->x:Le3;

    .line 317
    .line 318
    sget-object v1, Le3;->i:Lnb;

    .line 319
    .line 320
    invoke-virtual {v3, v1}, Le3;->j(Lnb;)Lmi0;

    .line 321
    .line 322
    .line 323
    move-result-object v1

    .line 324
    new-instance v3, Lec1;

    .line 325
    .line 326
    move-object/from16 v18, v1

    .line 327
    .line 328
    sget-object v1, Lzi0;->f:Lzi0;

    .line 329
    .line 330
    invoke-static {v1, v0}, Lmc0;->H(Lzi0;Ld10;)Lp71;

    .line 331
    .line 332
    .line 333
    move-result-object v1

    .line 334
    invoke-direct {v3, v5, v2, v1}, Lec1;-><init>(Luj0;ZLp71;)V

    .line 335
    .line 336
    .line 337
    move-object/from16 v1, v18

    .line 338
    .line 339
    check-cast v1, Lqi0;

    .line 340
    .line 341
    invoke-static {v1, v3}, Lfu0;->l(Lmi0;Lmi0;)Lmi0;

    .line 342
    .line 343
    .line 344
    move-result-object v1

    .line 345
    sget v3, Lj70;->x:F

    .line 346
    .line 347
    const/high16 v18, 0x40000000  # 2.0f

    .line 348
    .line 349
    div-float v3, v3, v18

    .line 350
    .line 351
    const/4 v2, 0x4

    .line 352
    invoke-static {v3, v2}, Lfy0;->a(FI)Lhy0;

    .line 353
    .line 354
    .line 355
    move-result-object v2

    .line 356
    invoke-static {v1, v5, v2}, Lp40;->a(Lmi0;Luj0;Lt40;)Lmi0;

    .line 357
    .line 358
    .line 359
    move-result-object v1

    .line 360
    invoke-static {v1, v8, v9, v6}, Lwl1;->n(Lmi0;JLy41;)Lmi0;

    .line 361
    .line 362
    .line 363
    move-result-object v1

    .line 364
    sget-object v2, Le3;->j:Lnb;

    .line 365
    .line 366
    const/4 v3, 0x0

    .line 367
    invoke-static {v2, v3}, Lic;->d(Lnb;Z)Lmh0;

    .line 368
    .line 369
    .line 370
    move-result-object v2

    .line 371
    iget-wide v8, v0, Ld10;->T:J

    .line 372
    .line 373
    ushr-long v16, v8, v17

    .line 374
    .line 375
    xor-long v8, v8, v16

    .line 376
    .line 377
    long-to-int v3, v8

    .line 378
    invoke-virtual {v0}, Ld10;->l()Lqr0;

    .line 379
    .line 380
    .line 381
    move-result-object v8

    .line 382
    invoke-static {v0, v1}, Lvn;->I(Ld10;Lmi0;)Lmi0;

    .line 383
    .line 384
    .line 385
    move-result-object v1

    .line 386
    invoke-virtual {v0}, Ld10;->Z()V

    .line 387
    .line 388
    .line 389
    iget-boolean v9, v0, Ld10;->S:Z

    .line 390
    .line 391
    if-eqz v9, :cond_18c

    .line 392
    .line 393
    invoke-virtual {v0, v13}, Ld10;->k(Lxz;)V

    .line 394
    .line 395
    .line 396
    goto :goto_18f

    .line 397
    :cond_18c
    invoke-virtual {v0}, Ld10;->j0()V

    .line 398
    .line 399
    .line 400
    :goto_18f
    invoke-static {v14, v0, v2}, Lmc0;->B(Lm00;Ld10;Ljava/lang/Object;)V

    .line 401
    .line 402
    .line 403
    invoke-static {v10, v0, v8}, Lmc0;->B(Lm00;Ld10;Ljava/lang/Object;)V

    .line 404
    .line 405
    .line 406
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 407
    .line 408
    .line 409
    move-result-object v2

    .line 410
    invoke-static {v0, v2, v12}, Lmc0;->p(Ld10;Ljava/lang/Integer;Lm00;)V

    .line 411
    .line 412
    .line 413
    invoke-static {v0, v11}, Lmc0;->w(Ld10;Li00;)V

    .line 414
    .line 415
    .line 416
    invoke-static {v15, v0, v1}, Lmc0;->B(Lm00;Ld10;Ljava/lang/Object;)V

    .line 417
    .line 418
    .line 419
    const v1, 0x49acf3f3

    .line 420
    .line 421
    .line 422
    invoke-virtual {v0, v1}, Ld10;->W(I)V

    .line 423
    .line 424
    .line 425
    const/4 v11, 0x0

    .line 426
    invoke-virtual {v0, v11}, Ld10;->p(Z)V

    .line 427
    .line 428
    .line 429
    const/4 v1, 0x1

    .line 430
    invoke-virtual {v0, v1}, Ld10;->p(Z)V

    .line 431
    .line 432
    .line 433
    invoke-virtual {v0, v1}, Ld10;->p(Z)V

    .line 434
    .line 435
    .line 436
    goto :goto_1b7

    .line 437
    :cond_1b4
    invoke-virtual {v0}, Ld10;->R()V

    .line 438
    .line 439
    .line 440
    :goto_1b7
    invoke-virtual {v0}, Ld10;->r()Lxv0;

    .line 441
    .line 442
    .line 443
    move-result-object v8

    .line 444
    if-eqz v8, :cond_1ca

    .line 445
    .line 446
    new-instance v0, Lba1;

    .line 447
    .line 448
    move-object/from16 v1, p0

    .line 449
    .line 450
    move/from16 v2, p1

    .line 451
    .line 452
    move/from16 v3, p2

    .line 453
    .line 454
    invoke-direct/range {v0 .. v7}, Lba1;-><init>(Lmi0;ZZLz91;Luj0;Ly41;I)V

    .line 455
    .line 456
    .line 457
    iput-object v0, v8, Lxv0;->d:Lm00;

    .line 458
    .line 459
    :cond_1ca
    return-void
.end method
