.class public final Le7;
.super Lh90;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Li00;


# instance fields
.field public final synthetic f:I

.field public final synthetic g:Ljava/lang/Object;

.field public final synthetic h:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Object;)V
    .registers 4

    .line 1
    iput p1, p0, Le7;->f:I

    .line 2
    .line 3
    iput-object p2, p0, Le7;->h:Ljava/lang/Object;

    .line 4
    .line 5
    iput-object p3, p0, Le7;->g:Ljava/lang/Object;

    .line 6
    .line 7
    const/4 p1, 0x1

    .line 8
    invoke-direct {p0, p1}, Lh90;-><init>(I)V

    .line 9
    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final i(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 7

    .line 1
    iget v0, p0, Le7;->f:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_120

    .line 4
    .line 5
    .line 6
    check-cast p1, Ljs0;

    .line 7
    .line 8
    iget-object v0, p0, Le7;->h:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v0, Lks0;

    .line 11
    .line 12
    iget-object p0, p0, Le7;->g:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast p0, Lvl1;

    .line 15
    .line 16
    iget p0, p0, Lvl1;->s:F

    .line 17
    .line 18
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 19
    .line 20
    .line 21
    invoke-static {p1, v0}, Ljs0;->c(Ljs0;Lks0;)V

    .line 22
    .line 23
    .line 24
    iget-wide v1, v0, Lks0;->i:J

    .line 25
    .line 26
    const-wide/16 v3, 0x0

    .line 27
    .line 28
    invoke-static {v3, v4, v1, v2}, Ln60;->c(JJ)J

    .line 29
    .line 30
    .line 31
    move-result-wide v1

    .line 32
    const/4 p1, 0x0

    .line 33
    invoke-virtual {v0, v1, v2, p0, p1}, Lks0;->R(JFLi00;)V

    .line 34
    .line 35
    .line 36
    sget-object p0, Lwe1;->a:Lwe1;

    .line 37
    .line 38
    return-object p0

    .line 39
    :pswitch_26  #0x6
    check-cast p1, Lmj;

    .line 40
    .line 41
    iget-object v0, p0, Le7;->g:Ljava/lang/Object;

    .line 42
    .line 43
    check-cast v0, Lm00;

    .line 44
    .line 45
    iget-object p0, p0, Le7;->h:Ljava/lang/Object;

    .line 46
    .line 47
    check-cast p0, Lpl1;

    .line 48
    .line 49
    iget-boolean v1, p0, Lpl1;->g:Z

    .line 50
    .line 51
    if-nez v1, :cond_81

    .line 52
    .line 53
    iget-object v1, p1, Lmj;->c:Lsd0;

    .line 54
    .line 55
    iget-object v2, p1, Lmj;->a:Landroid/view/View;

    .line 56
    .line 57
    invoke-interface {v1}, Lsd0;->g()Lud0;

    .line 58
    .line 59
    .line 60
    move-result-object v1

    .line 61
    iput-object v0, p0, Lpl1;->i:Lm00;

    .line 62
    .line 63
    iget-object v3, p0, Lpl1;->h:Lud0;

    .line 64
    .line 65
    if-nez v3, :cond_64

    .line 66
    .line 67
    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    .line 68
    .line 69
    .line 70
    move-result-object p1

    .line 71
    invoke-virtual {v2}, Landroid/view/View;->getHandler()Landroid/os/Handler;

    .line 72
    .line 73
    .line 74
    move-result-object v0

    .line 75
    invoke-virtual {v0}, Landroid/os/Handler;->getLooper()Landroid/os/Looper;

    .line 76
    .line 77
    .line 78
    move-result-object v0

    .line 79
    invoke-static {p1, v0}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 80
    .line 81
    .line 82
    move-result p1

    .line 83
    if-nez p1, :cond_5e

    .line 84
    .line 85
    new-instance p1, Le5;

    .line 86
    .line 87
    const/4 v0, 0x3

    .line 88
    invoke-direct {p1, v0, p0, v1}, Le5;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 89
    .line 90
    .line 91
    invoke-virtual {v2, p1}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 92
    .line 93
    .line 94
    goto :goto_81

    .line 95
    :cond_5e
    iput-object v1, p0, Lpl1;->h:Lud0;

    .line 96
    .line 97
    invoke-virtual {v1, p0}, Lud0;->a(Lrd0;)V

    .line 98
    .line 99
    .line 100
    goto :goto_81

    .line 101
    :cond_64
    iget-object v1, v1, Lud0;->d:Ljd0;

    .line 102
    .line 103
    sget-object v2, Ljd0;->g:Ljd0;

    .line 104
    .line 105
    invoke-virtual {v1, v2}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    .line 106
    .line 107
    .line 108
    move-result v1

    .line 109
    if-ltz v1, :cond_81

    .line 110
    .line 111
    iget-object v1, p0, Lpl1;->f:Lyj;

    .line 112
    .line 113
    new-instance v2, Lek;

    .line 114
    .line 115
    invoke-direct {v2, p0, p1, v0}, Lek;-><init>(Lpl1;Lmj;Lm00;)V

    .line 116
    .line 117
    .line 118
    new-instance p0, Lpi;

    .line 119
    .line 120
    const p1, -0x66c1ecc8

    .line 121
    .line 122
    .line 123
    const/4 v0, 0x1

    .line 124
    invoke-direct {p0, p1, v0, v2}, Lpi;-><init>(IZLu00;)V

    .line 125
    .line 126
    .line 127
    invoke-virtual {v1, p0}, Lyj;->A(Lm00;)V

    .line 128
    .line 129
    .line 130
    :cond_81
    :goto_81
    sget-object p0, Lwe1;->a:Lwe1;

    .line 131
    .line 132
    return-object p0

    .line 133
    :pswitch_84  #0x5
    check-cast p1, Ljs0;

    .line 134
    .line 135
    iget-object v0, p0, Le7;->h:Ljava/lang/Object;

    .line 136
    .line 137
    check-cast v0, Lks0;

    .line 138
    .line 139
    iget-object p0, p0, Le7;->g:Ljava/lang/Object;

    .line 140
    .line 141
    check-cast p0, Ln51;

    .line 142
    .line 143
    iget-object p0, p0, Ln51;->D:Lj3;

    .line 144
    .line 145
    invoke-static {p1, v0, p0}, Ljs0;->m(Ljs0;Lks0;Li00;)V

    .line 146
    .line 147
    .line 148
    sget-object p0, Lwe1;->a:Lwe1;

    .line 149
    .line 150
    return-object p0

    .line 151
    :pswitch_96  #0x4
    check-cast p1, Landroid/view/MotionEvent;

    .line 152
    .line 153
    iget-object v0, p0, Le7;->g:Ljava/lang/Object;

    .line 154
    .line 155
    check-cast v0, Ljt0;

    .line 156
    .line 157
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    .line 158
    .line 159
    .line 160
    move-result v1

    .line 161
    if-nez v1, :cond_c0

    .line 162
    .line 163
    iget-object p0, p0, Le7;->h:Ljava/lang/Object;

    .line 164
    .line 165
    check-cast p0, Lp3;

    .line 166
    .line 167
    invoke-virtual {v0}, Ljt0;->e()Li00;

    .line 168
    .line 169
    .line 170
    move-result-object v0

    .line 171
    check-cast v0, Ll7;

    .line 172
    .line 173
    invoke-virtual {v0, p1}, Ll7;->i(Ljava/lang/Object;)Ljava/lang/Object;

    .line 174
    .line 175
    .line 176
    move-result-object p1

    .line 177
    check-cast p1, Ljava/lang/Boolean;

    .line 178
    .line 179
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 180
    .line 181
    .line 182
    move-result p1

    .line 183
    if-eqz p1, :cond_bb

    .line 184
    .line 185
    sget-object p1, Lit0;->f:Lit0;

    .line 186
    .line 187
    goto :goto_bd

    .line 188
    :cond_bb
    sget-object p1, Lit0;->g:Lit0;

    .line 189
    .line 190
    :goto_bd
    iput-object p1, p0, Lp3;->f:Ljava/lang/Object;

    .line 191
    .line 192
    goto :goto_c9

    .line 193
    :cond_c0
    invoke-virtual {v0}, Ljt0;->e()Li00;

    .line 194
    .line 195
    .line 196
    move-result-object p0

    .line 197
    check-cast p0, Ll7;

    .line 198
    .line 199
    invoke-virtual {p0, p1}, Ll7;->i(Ljava/lang/Object;)Ljava/lang/Object;

    .line 200
    .line 201
    .line 202
    :goto_c9
    sget-object p0, Lwe1;->a:Lwe1;

    .line 203
    .line 204
    return-object p0

    .line 205
    :pswitch_cc  #0x3
    check-cast p1, Ljs0;

    .line 206
    .line 207
    iget-object v0, p0, Le7;->h:Ljava/lang/Object;

    .line 208
    .line 209
    check-cast v0, Lks0;

    .line 210
    .line 211
    iget-object p0, p0, Le7;->g:Ljava/lang/Object;

    .line 212
    .line 213
    check-cast p0, Lrb;

    .line 214
    .line 215
    iget-object p0, p0, Lrb;->s:Li00;

    .line 216
    .line 217
    invoke-static {p1, v0, p0}, Ljs0;->m(Ljs0;Lks0;Li00;)V

    .line 218
    .line 219
    .line 220
    sget-object p0, Lwe1;->a:Lwe1;

    .line 221
    .line 222
    return-object p0

    .line 223
    :pswitch_de  #0x2
    check-cast p1, Lmi0;

    .line 224
    .line 225
    iget-object v0, p0, Le7;->h:Ljava/lang/Object;

    .line 226
    .line 227
    check-cast v0, Lba0;

    .line 228
    .line 229
    iget-object p0, p0, Le7;->g:Ljava/lang/Object;

    .line 230
    .line 231
    check-cast p0, Lmi0;

    .line 232
    .line 233
    invoke-interface {p1, p0}, Lmi0;->b(Lmi0;)Lmi0;

    .line 234
    .line 235
    .line 236
    move-result-object p0

    .line 237
    invoke-virtual {v0, p0}, Lba0;->d0(Lmi0;)V

    .line 238
    .line 239
    .line 240
    sget-object p0, Lwe1;->a:Lwe1;

    .line 241
    .line 242
    return-object p0

    .line 243
    :pswitch_f2  #0x1
    check-cast p1, Ljava/lang/Throwable;

    .line 244
    .line 245
    iget-object p1, p0, Le7;->h:Ljava/lang/Object;

    .line 246
    .line 247
    check-cast p1, Lg7;

    .line 248
    .line 249
    iget-object p1, p1, Lg7;->f:Ljava/lang/Object;

    .line 250
    .line 251
    check-cast p1, Landroid/view/Choreographer;

    .line 252
    .line 253
    iget-object p0, p0, Le7;->g:Ljava/lang/Object;

    .line 254
    .line 255
    check-cast p0, Lf7;

    .line 256
    .line 257
    invoke-virtual {p1, p0}, Landroid/view/Choreographer;->removeFrameCallback(Landroid/view/Choreographer$FrameCallback;)V

    .line 258
    .line 259
    .line 260
    sget-object p0, Lwe1;->a:Lwe1;

    .line 261
    .line 262
    return-object p0

    .line 263
    :pswitch_106  #0x0
    check-cast p1, Ljava/lang/Throwable;

    .line 264
    .line 265
    iget-object p1, p0, Le7;->h:Ljava/lang/Object;

    .line 266
    .line 267
    check-cast p1, Ld7;

    .line 268
    .line 269
    iget-object p0, p0, Le7;->g:Ljava/lang/Object;

    .line 270
    .line 271
    check-cast p0, Lf7;

    .line 272
    .line 273
    iget-object v0, p1, Ld7;->i:Ljava/lang/Object;

    .line 274
    .line 275
    monitor-enter v0

    .line 276
    :try_start_113
    iget-object p1, p1, Ld7;->k:Ljava/util/ArrayList;

    .line 277
    .line 278
    invoke-virtual {p1, p0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z
    :try_end_118
    .catchall {:try_start_113 .. :try_end_118} :catchall_11c

    .line 279
    .line 280
    .line 281
    monitor-exit v0

    .line 282
    sget-object p0, Lwe1;->a:Lwe1;

    .line 283
    .line 284
    return-object p0

    .line 285
    :catchall_11c
    move-exception p0

    .line 286
    monitor-exit v0

    .line 287
    throw p0

    .line 288
    nop

    .line 289
    :pswitch_data_120
    .packed-switch 0x0
        :pswitch_106  #00000000
        :pswitch_f2  #00000001
        :pswitch_de  #00000002
        :pswitch_cc  #00000003
        :pswitch_96  #00000004
        :pswitch_84  #00000005
        :pswitch_26  #00000006
    .end packed-switch
.end method
