.class public interface abstract Leg1;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lcg1;


# virtual methods
.method public abstract d()I
.end method

.method public abstract h()I
.end method
