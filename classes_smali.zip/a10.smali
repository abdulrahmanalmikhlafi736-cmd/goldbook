.class public final La10;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lww0;


# instance fields
.field public final e:Lb10;


# direct methods
.method public constructor <init>(Lb10;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, La10;->e:Lb10;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final c()V
    .registers 1

    .line 1
    return-void
.end method

.method public final d()V
    .registers 1

    .line 1
    iget-object p0, p0, La10;->e:Lb10;

    .line 2
    .line 3
    invoke-virtual {p0}, Lb10;->w()V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final e()V
    .registers 1

    .line 1
    iget-object p0, p0, La10;->e:Lb10;

    .line 2
    .line 3
    invoke-virtual {p0}, Lb10;->w()V

    .line 4
    .line 5
    .line 6
    return-void
.end method
