.class public final Le61;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Ljava/util/Iterator;


# instance fields
.field public e:I

.field public f:Z

.field public g:Ljava/util/Iterator;

.field public final synthetic h:Lc61;


# direct methods
.method public constructor <init>(Lc61;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Le61;->h:Lc61;

    .line 5
    .line 6
    const/4 p1, -0x1

    .line 7
    iput p1, p0, Le61;->e:I

    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final a()Ljava/util/Iterator;
    .registers 2

    .line 1
    iget-object v0, p0, Le61;->g:Ljava/util/Iterator;

    .line 2
    .line 3
    if-nez v0, :cond_12

    .line 4
    .line 5
    iget-object v0, p0, Le61;->h:Lc61;

    .line 6
    .line 7
    iget-object v0, v0, Lc61;->f:Ljava/util/Map;

    .line 8
    .line 9
    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    iput-object v0, p0, Le61;->g:Ljava/util/Iterator;

    .line 18
    .line 19
    :cond_12
    iget-object p0, p0, Le61;->g:Ljava/util/Iterator;

    .line 20
    .line 21
    return-object p0
.end method

.method public final hasNext()Z
    .registers 5

    .line 1
    iget v0, p0, Le61;->e:I

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    add-int/2addr v0, v1

    .line 5
    iget-object v2, p0, Le61;->h:Lc61;

    .line 6
    .line 7
    iget-object v3, v2, Lc61;->e:Ljava/util/List;

    .line 8
    .line 9
    invoke-interface {v3}, Ljava/util/List;->size()I

    .line 10
    .line 11
    .line 12
    move-result v3

    .line 13
    if-lt v0, v3, :cond_23

    .line 14
    .line 15
    iget-object v0, v2, Lc61;->f:Ljava/util/Map;

    .line 16
    .line 17
    invoke-interface {v0}, Ljava/util/Map;->isEmpty()Z

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    if-nez v0, :cond_21

    .line 22
    .line 23
    invoke-virtual {p0}, Le61;->a()Ljava/util/Iterator;

    .line 24
    .line 25
    .line 26
    move-result-object p0

    .line 27
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 28
    .line 29
    .line 30
    move-result p0

    .line 31
    if-eqz p0, :cond_21

    .line 32
    .line 33
    goto :goto_23

    .line 34
    :cond_21
    const/4 p0, 0x0

    .line 35
    return p0

    .line 36
    :cond_23
    :goto_23
    return v1
.end method

.method public final next()Ljava/lang/Object;
    .registers 4

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, Le61;->f:Z

    .line 3
    .line 4
    iget v1, p0, Le61;->e:I

    .line 5
    .line 6
    add-int/2addr v1, v0

    .line 7
    iput v1, p0, Le61;->e:I

    .line 8
    .line 9
    iget-object v0, p0, Le61;->h:Lc61;

    .line 10
    .line 11
    iget-object v2, v0, Lc61;->e:Ljava/util/List;

    .line 12
    .line 13
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 14
    .line 15
    .line 16
    move-result v2

    .line 17
    if-ge v1, v2, :cond_1d

    .line 18
    .line 19
    iget-object v0, v0, Lc61;->e:Ljava/util/List;

    .line 20
    .line 21
    iget p0, p0, Le61;->e:I

    .line 22
    .line 23
    invoke-interface {v0, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object p0

    .line 27
    check-cast p0, Ljava/util/Map$Entry;

    .line 28
    .line 29
    return-object p0

    .line 30
    :cond_1d
    invoke-virtual {p0}, Le61;->a()Ljava/util/Iterator;

    .line 31
    .line 32
    .line 33
    move-result-object p0

    .line 34
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object p0

    .line 38
    check-cast p0, Ljava/util/Map$Entry;

    .line 39
    .line 40
    return-object p0
.end method

.method public final remove()V
    .registers 4

    .line 1
    iget-boolean v0, p0, Le61;->f:Z

    .line 2
    .line 3
    if-eqz v0, :cond_2a

    .line 4
    .line 5
    const/4 v0, 0x0

    .line 6
    iput-boolean v0, p0, Le61;->f:Z

    .line 7
    .line 8
    sget v0, Lc61;->j:I

    .line 9
    .line 10
    iget-object v0, p0, Le61;->h:Lc61;

    .line 11
    .line 12
    invoke-virtual {v0}, Lc61;->b()V

    .line 13
    .line 14
    .line 15
    iget v1, p0, Le61;->e:I

    .line 16
    .line 17
    iget-object v2, v0, Lc61;->e:Ljava/util/List;

    .line 18
    .line 19
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 20
    .line 21
    .line 22
    move-result v2

    .line 23
    if-ge v1, v2, :cond_22

    .line 24
    .line 25
    iget v1, p0, Le61;->e:I

    .line 26
    .line 27
    add-int/lit8 v2, v1, -0x1

    .line 28
    .line 29
    iput v2, p0, Le61;->e:I

    .line 30
    .line 31
    invoke-virtual {v0, v1}, Lc61;->h(I)Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    return-void

    .line 35
    :cond_22
    invoke-virtual {p0}, Le61;->a()Ljava/util/Iterator;

    .line 36
    .line 37
    .line 38
    move-result-object p0

    .line 39
    invoke-interface {p0}, Ljava/util/Iterator;->remove()V

    .line 40
    .line 41
    .line 42
    return-void

    .line 43
    :cond_2a
    const-string p0, "remove() was called before next()"

    .line 44
    .line 45
    invoke-static {p0}, Lod;->p(Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    return-void
.end method
