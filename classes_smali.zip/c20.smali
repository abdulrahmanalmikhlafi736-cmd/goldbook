.class public final synthetic Lc20;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Landroid/webkit/ValueCallback;


# instance fields
.field public final synthetic a:Landroid/app/Activity;

.field public final synthetic b:Ljq0;

.field public final synthetic c:Lmk0;

.field public final synthetic d:Lui1;

.field public final synthetic e:Lmk0;


# direct methods
.method public synthetic constructor <init>(Lmk0;Lmk0;Ljq0;Lui1;Landroid/app/Activity;)V
    .registers 6

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p5, p0, Lc20;->a:Landroid/app/Activity;

    .line 5
    .line 6
    iput-object p3, p0, Lc20;->b:Ljq0;

    .line 7
    .line 8
    iput-object p1, p0, Lc20;->c:Lmk0;

    .line 9
    .line 10
    iput-object p4, p0, Lc20;->d:Lui1;

    .line 11
    .line 12
    iput-object p2, p0, Lc20;->e:Lmk0;

    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final onReceiveValue(Ljava/lang/Object;)V
    .registers 5

    .line 1
    check-cast p1, Ljava/lang/String;

    .line 2
    .line 3
    const-wide/16 v0, 0x0

    .line 4
    .line 5
    iget-object v2, p0, Lc20;->b:Ljq0;

    .line 6
    .line 7
    invoke-virtual {v2, v0, v1}, Ljq0;->h(J)V

    .line 8
    .line 9
    .line 10
    if-nez p1, :cond_d

    .line 11
    .line 12
    const-string p1, "\"false\""

    .line 13
    .line 14
    :cond_d
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    const/4 v1, 0x2

    .line 19
    if-lt v0, v1, :cond_2c

    .line 20
    .line 21
    const-string v0, "\""

    .line 22
    .line 23
    invoke-virtual {p1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 24
    .line 25
    .line 26
    move-result v1

    .line 27
    if-eqz v1, :cond_2c

    .line 28
    .line 29
    invoke-static {p1, v0}, Lq81;->A(Ljava/lang/CharSequence;Ljava/lang/String;)Z

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    if-eqz v0, :cond_2c

    .line 34
    .line 35
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    const/4 v1, 0x1

    .line 40
    sub-int/2addr v0, v1

    .line 41
    invoke-virtual {p1, v1, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object p1

    .line 45
    :cond_2c
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    const v1, 0x2fb91e

    .line 50
    .line 51
    .line 52
    iget-object v2, p0, Lc20;->a:Landroid/app/Activity;

    .line 53
    .line 54
    if-eq v0, v1, :cond_5d

    .line 55
    .line 56
    const v1, 0x36758e

    .line 57
    .line 58
    .line 59
    if-eq v0, v1, :cond_53

    .line 60
    .line 61
    const v1, 0x18e721f5

    .line 62
    .line 63
    .line 64
    if-eq v0, v1, :cond_42

    .line 65
    .line 66
    goto :goto_65

    .line 67
    :cond_42
    const-string v0, "scrolling"

    .line 68
    .line 69
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 70
    .line 71
    .line 72
    move-result p1

    .line 73
    if-nez p1, :cond_4b

    .line 74
    .line 75
    goto :goto_65

    .line 76
    :cond_4b
    sget-object p1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 77
    .line 78
    iget-object p0, p0, Lc20;->c:Lmk0;

    .line 79
    .line 80
    invoke-interface {p0, p1}, Lmk0;->setValue(Ljava/lang/Object;)V

    .line 81
    .line 82
    .line 83
    return-void

    .line 84
    :cond_53
    const-string v0, "true"

    .line 85
    .line 86
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 87
    .line 88
    .line 89
    move-result p1

    .line 90
    if-nez p1, :cond_5c

    .line 91
    .line 92
    goto :goto_65

    .line 93
    :cond_5c
    return-void

    .line 94
    :cond_5d
    const-string v0, "exit"

    .line 95
    .line 96
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 97
    .line 98
    .line 99
    move-result p1

    .line 100
    if-nez p1, :cond_6d

    .line 101
    .line 102
    :goto_65
    iget-object p1, p0, Lc20;->d:Lui1;

    .line 103
    .line 104
    iget-object p0, p0, Lc20;->e:Lmk0;

    .line 105
    .line 106
    invoke-static {p1, v2, p0}, Lj70;->e(Lui1;Landroid/app/Activity;Lmk0;)V

    .line 107
    .line 108
    .line 109
    return-void

    .line 110
    :cond_6d
    invoke-static {v2}, Lmod/Mod;->warmExit(Landroid/app/Activity;)V

    .line 111
    .line 112
    .line 113
    return-void
.end method
