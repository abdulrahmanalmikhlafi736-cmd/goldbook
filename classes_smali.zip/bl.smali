.class public final Lbl;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lxz;


# static fields
.field public static final e:Lbl;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, Lbl;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lbl;->e:Lbl;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .registers 3

    .line 1
    sget-wide v0, Lzg;->b:J

    .line 2
    .line 3
    new-instance p0, Lzg;

    .line 4
    .line 5
    invoke-direct {p0, v0, v1}, Lzg;-><init>(J)V

    .line 6
    .line 7
    .line 8
    return-object p0
.end method
