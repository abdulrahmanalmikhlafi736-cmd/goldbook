.class public final synthetic Lb20;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Ln00;


# instance fields
.field public final synthetic e:Ljz0;

.field public final synthetic f:Lmk0;

.field public final synthetic g:Ljava/lang/String;

.field public final synthetic h:Lt41;

.field public final synthetic i:Landroid/content/Context;


# direct methods
.method public synthetic constructor <init>(Lkz0;Lmk0;Ljava/lang/String;Lt41;Landroid/content/Context;)V
    .registers 6

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lb20;->e:Ljz0;

    .line 5
    .line 6
    iput-object p2, p0, Lb20;->f:Lmk0;

    .line 7
    .line 8
    iput-object p3, p0, Lb20;->g:Ljava/lang/String;

    .line 9
    .line 10
    iput-object p4, p0, Lb20;->h:Lt41;

    .line 11
    .line 12
    iput-object p5, p0, Lb20;->i:Landroid/content/Context;

    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final c(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 10

    .line 1
    move-object v1, p1

    .line 2
    check-cast v1, Ljava/lang/String;

    .line 3
    .line 4
    check-cast p2, Ld10;

    .line 5
    .line 6
    check-cast p3, Ljava/lang/Integer;

    .line 7
    .line 8
    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    .line 9
    .line 10
    .line 11
    move-result p1

    .line 12
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13
    .line 14
    .line 15
    and-int/lit8 p3, p1, 0x6

    .line 16
    .line 17
    if-nez p3, :cond_1c

    .line 18
    .line 19
    invoke-virtual {p2, v1}, Ld10;->f(Ljava/lang/Object;)Z

    .line 20
    .line 21
    .line 22
    move-result p3

    .line 23
    if-eqz p3, :cond_1a

    .line 24
    .line 25
    const/4 p3, 0x4

    .line 26
    goto :goto_1b

    .line 27
    :cond_1a
    const/4 p3, 0x2

    .line 28
    :goto_1b
    or-int/2addr p1, p3

    .line 29
    :cond_1c
    and-int/lit8 p3, p1, 0x13

    .line 30
    .line 31
    const/16 v0, 0x12

    .line 32
    .line 33
    if-eq p3, v0, :cond_24

    .line 34
    .line 35
    const/4 p3, 0x1

    .line 36
    goto :goto_25

    .line 37
    :cond_24
    const/4 p3, 0x0

    .line 38
    :goto_25
    and-int/lit8 v0, p1, 0x1

    .line 39
    .line 40
    invoke-virtual {p2, v0, p3}, Ld10;->O(IZ)Z

    .line 41
    .line 42
    .line 43
    move-result p3

    .line 44
    if-eqz p3, :cond_4b

    .line 45
    .line 46
    new-instance v0, Ld20;

    .line 47
    .line 48
    iget-object v2, p0, Lb20;->f:Lmk0;

    .line 49
    .line 50
    iget-object v3, p0, Lb20;->g:Ljava/lang/String;

    .line 51
    .line 52
    iget-object v4, p0, Lb20;->h:Lt41;

    .line 53
    .line 54
    iget-object v5, p0, Lb20;->i:Landroid/content/Context;

    .line 55
    .line 56
    invoke-direct/range {v0 .. v5}, Ld20;-><init>(Ljava/lang/String;Lmk0;Ljava/lang/String;Lt41;Landroid/content/Context;)V

    .line 57
    .line 58
    .line 59
    const p3, 0x5b8b13a

    .line 60
    .line 61
    .line 62
    invoke-static {p3, v0, p2}, Lvd1;->A(ILu00;Ld10;)Lpi;

    .line 63
    .line 64
    .line 65
    move-result-object p3

    .line 66
    and-int/lit8 p1, p1, 0xe

    .line 67
    .line 68
    or-int/lit8 p1, p1, 0x30

    .line 69
    .line 70
    iget-object p0, p0, Lb20;->e:Ljz0;

    .line 71
    .line 72
    invoke-interface {p0, v1, p3, p2, p1}, Ljz0;->b(Ljava/lang/Object;Lpi;Ld10;I)V

    .line 73
    .line 74
    .line 75
    goto :goto_4e

    .line 76
    :cond_4b
    invoke-virtual {p2}, Ld10;->R()V

    .line 77
    .line 78
    .line 79
    :goto_4e
    sget-object p0, Lwe1;->a:Lwe1;

    .line 80
    .line 81
    return-object p0
.end method
