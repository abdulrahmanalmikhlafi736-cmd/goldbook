.class public interface abstract Le21;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lki0;


# virtual methods
.method public abstract c()Ld21;
.end method
