.class public final Ldz;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# static fields
.field public static final a:Lcz;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    sget-object v0, Le3;->C:Le3;

    .line 2
    .line 3
    new-instance v1, Lcz;

    .line 4
    .line 5
    invoke-direct {v1, v0}, Lq;-><init>(Lrl;)V

    .line 6
    .line 7
    .line 8
    sput-object v1, Ldz;->a:Lcz;

    .line 9
    .line 10
    return-void
.end method
