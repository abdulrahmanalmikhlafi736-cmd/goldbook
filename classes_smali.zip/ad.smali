.class public final synthetic Lad;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Li00;


# instance fields
.field public final synthetic e:J


# direct methods
.method public synthetic constructor <init>(J)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-wide p1, p0, Lad;->e:J

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final i(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 1
    iget-wide v0, p0, Lad;->e:J

    .line 2
    .line 3
    check-cast p1, Lbd;

    .line 4
    .line 5
    iget-object p0, p1, Lbd;->b:Li00;

    .line 6
    .line 7
    if-nez p0, :cond_9

    .line 8
    .line 9
    goto :goto_20

    .line 10
    :cond_9
    iget-object p1, p1, Lbd;->a:Lne;

    .line 11
    .line 12
    if-eqz p1, :cond_20

    .line 13
    .line 14
    :try_start_d
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    invoke-interface {p0, v0}, Li00;->i(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object p0
    :try_end_15
    .catchall {:try_start_d .. :try_end_15} :catchall_16

    .line 22
    goto :goto_1d

    .line 23
    :catchall_16
    move-exception p0

    .line 24
    new-instance v0, Lpx0;

    .line 25
    .line 26
    invoke-direct {v0, p0}, Lpx0;-><init>(Ljava/lang/Throwable;)V

    .line 27
    .line 28
    .line 29
    move-object p0, v0

    .line 30
    :goto_1d
    invoke-virtual {p1, p0}, Lne;->h(Ljava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    :cond_20
    :goto_20
    sget-object p0, Lwe1;->a:Lwe1;

    .line 34
    .line 35
    return-object p0
.end method
