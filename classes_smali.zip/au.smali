.class final Lau;
.super Lqi0;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lqi0;"
    }
.end annotation


# instance fields
.field public final a:Led1;

.field public final b:Lzc1;

.field public final c:Lzc1;

.field public final d:Lju;

.field public final e:Lwu;

.field public final f:Lxz;

.field public final g:Lbu;


# direct methods
.method public constructor <init>(Led1;Lzc1;Lzc1;Lju;Lwu;Lxz;Lbu;)V
    .registers 8

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lau;->a:Led1;

    .line 5
    .line 6
    iput-object p2, p0, Lau;->b:Lzc1;

    .line 7
    .line 8
    iput-object p3, p0, Lau;->c:Lzc1;

    .line 9
    .line 10
    iput-object p4, p0, Lau;->d:Lju;

    .line 11
    .line 12
    iput-object p5, p0, Lau;->e:Lwu;

    .line 13
    .line 14
    iput-object p6, p0, Lau;->f:Lxz;

    .line 15
    .line 16
    iput-object p7, p0, Lau;->g:Lbu;

    .line 17
    .line 18
    return-void
.end method


# virtual methods
.method public final e()Lli0;
    .registers 9

    .line 1
    new-instance v0, Liu;

    .line 2
    .line 3
    iget-object v6, p0, Lau;->f:Lxz;

    .line 4
    .line 5
    iget-object v7, p0, Lau;->g:Lbu;

    .line 6
    .line 7
    iget-object v1, p0, Lau;->a:Led1;

    .line 8
    .line 9
    iget-object v2, p0, Lau;->b:Lzc1;

    .line 10
    .line 11
    iget-object v3, p0, Lau;->c:Lzc1;

    .line 12
    .line 13
    iget-object v4, p0, Lau;->d:Lju;

    .line 14
    .line 15
    iget-object v5, p0, Lau;->e:Lwu;

    .line 16
    .line 17
    invoke-direct/range {v0 .. v7}, Liu;-><init>(Led1;Lzc1;Lzc1;Lju;Lwu;Lxz;Lbu;)V

    .line 18
    .line 19
    .line 20
    return-object v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 4

    .line 1
    instance-of v0, p1, Lau;

    .line 2
    .line 3
    if-eqz v0, :cond_47

    .line 4
    .line 5
    check-cast p1, Lau;

    .line 6
    .line 7
    iget-object v0, p1, Lau;->a:Led1;

    .line 8
    .line 9
    iget-object v1, p0, Lau;->a:Led1;

    .line 10
    .line 11
    if-eq v0, v1, :cond_d

    .line 12
    .line 13
    goto :goto_47

    .line 14
    :cond_d
    iget-object v0, p1, Lau;->b:Lzc1;

    .line 15
    .line 16
    iget-object v1, p0, Lau;->b:Lzc1;

    .line 17
    .line 18
    invoke-static {v0, v1}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    if-eqz v0, :cond_47

    .line 23
    .line 24
    iget-object v0, p1, Lau;->c:Lzc1;

    .line 25
    .line 26
    iget-object v1, p0, Lau;->c:Lzc1;

    .line 27
    .line 28
    invoke-static {v0, v1}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    if-eqz v0, :cond_47

    .line 33
    .line 34
    iget-object v0, p1, Lau;->d:Lju;

    .line 35
    .line 36
    iget-object v1, p0, Lau;->d:Lju;

    .line 37
    .line 38
    invoke-virtual {v0, v1}, Lju;->equals(Ljava/lang/Object;)Z

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    if-eqz v0, :cond_47

    .line 43
    .line 44
    iget-object v0, p1, Lau;->e:Lwu;

    .line 45
    .line 46
    iget-object v1, p0, Lau;->e:Lwu;

    .line 47
    .line 48
    invoke-static {v0, v1}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 49
    .line 50
    .line 51
    move-result v0

    .line 52
    if-eqz v0, :cond_47

    .line 53
    .line 54
    iget-object v0, p1, Lau;->f:Lxz;

    .line 55
    .line 56
    iget-object v1, p0, Lau;->f:Lxz;

    .line 57
    .line 58
    if-ne v0, v1, :cond_47

    .line 59
    .line 60
    iget-object p1, p1, Lau;->g:Lbu;

    .line 61
    .line 62
    iget-object p0, p0, Lau;->g:Lbu;

    .line 63
    .line 64
    invoke-static {p1, p0}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 65
    .line 66
    .line 67
    move-result p0

    .line 68
    if-eqz p0, :cond_47

    .line 69
    .line 70
    const/4 p0, 0x1

    .line 71
    return p0

    .line 72
    :cond_47
    :goto_47
    const/4 p0, 0x0

    .line 73
    return p0
.end method

.method public final f(Lli0;)V
    .registers 3

    .line 1
    check-cast p1, Liu;

    .line 2
    .line 3
    iget-object v0, p0, Lau;->a:Led1;

    .line 4
    .line 5
    iput-object v0, p1, Liu;->s:Led1;

    .line 6
    .line 7
    iget-object v0, p0, Lau;->b:Lzc1;

    .line 8
    .line 9
    iput-object v0, p1, Liu;->t:Lzc1;

    .line 10
    .line 11
    iget-object v0, p0, Lau;->c:Lzc1;

    .line 12
    .line 13
    iput-object v0, p1, Liu;->u:Lzc1;

    .line 14
    .line 15
    iget-object v0, p0, Lau;->d:Lju;

    .line 16
    .line 17
    iput-object v0, p1, Liu;->v:Lju;

    .line 18
    .line 19
    iget-object v0, p0, Lau;->e:Lwu;

    .line 20
    .line 21
    iput-object v0, p1, Liu;->w:Lwu;

    .line 22
    .line 23
    iget-object v0, p0, Lau;->f:Lxz;

    .line 24
    .line 25
    iput-object v0, p1, Liu;->x:Lxz;

    .line 26
    .line 27
    iget-object p0, p0, Lau;->g:Lbu;

    .line 28
    .line 29
    iput-object p0, p1, Liu;->y:Lbu;

    .line 30
    .line 31
    return-void
.end method

.method public final hashCode()I
    .registers 4

    .line 1
    iget-object v0, p0, Lau;->a:Led1;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    mul-int/lit8 v0, v0, 0x1f

    .line 8
    .line 9
    const/4 v1, 0x0

    .line 10
    iget-object v2, p0, Lau;->b:Lzc1;

    .line 11
    .line 12
    if-eqz v2, :cond_12

    .line 13
    .line 14
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    .line 15
    .line 16
    .line 17
    move-result v2

    .line 18
    goto :goto_13

    .line 19
    :cond_12
    move v2, v1

    .line 20
    :goto_13
    add-int/2addr v0, v2

    .line 21
    mul-int/lit8 v0, v0, 0x1f

    .line 22
    .line 23
    iget-object v2, p0, Lau;->c:Lzc1;

    .line 24
    .line 25
    if-eqz v2, :cond_1e

    .line 26
    .line 27
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    .line 28
    .line 29
    .line 30
    move-result v1

    .line 31
    :cond_1e
    add-int/2addr v0, v1

    .line 32
    mul-int/lit16 v0, v0, 0x3c1

    .line 33
    .line 34
    iget-object v1, p0, Lau;->d:Lju;

    .line 35
    .line 36
    iget-object v1, v1, Lju;->a:Lfd1;

    .line 37
    .line 38
    invoke-virtual {v1}, Lfd1;->hashCode()I

    .line 39
    .line 40
    .line 41
    move-result v1

    .line 42
    add-int/2addr v1, v0

    .line 43
    mul-int/lit8 v1, v1, 0x1f

    .line 44
    .line 45
    iget-object v0, p0, Lau;->e:Lwu;

    .line 46
    .line 47
    iget-object v0, v0, Lwu;->a:Lfd1;

    .line 48
    .line 49
    invoke-virtual {v0}, Lfd1;->hashCode()I

    .line 50
    .line 51
    .line 52
    move-result v0

    .line 53
    add-int/2addr v0, v1

    .line 54
    mul-int/lit8 v0, v0, 0x1f

    .line 55
    .line 56
    iget-object v1, p0, Lau;->f:Lxz;

    .line 57
    .line 58
    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    .line 59
    .line 60
    .line 61
    move-result v1

    .line 62
    add-int/2addr v1, v0

    .line 63
    mul-int/lit8 v1, v1, 0x1f

    .line 64
    .line 65
    iget-object p0, p0, Lau;->g:Lbu;

    .line 66
    .line 67
    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    .line 68
    .line 69
    .line 70
    move-result p0

    .line 71
    add-int/2addr p0, v1

    .line 72
    return p0
.end method
