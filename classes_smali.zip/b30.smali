.class public final Lb30;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# instance fields
.field public final a:Ln90;

.field public b:Z

.field public c:Z

.field public d:Z

.field public e:Z

.field public final f:Lak0;

.field public final g:Llm0;

.field public final h:Lwj0;


# direct methods
.method public constructor <init>(Ln90;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lb30;->a:Ln90;

    .line 5
    .line 6
    new-instance p1, Lak0;

    .line 7
    .line 8
    invoke-direct {p1}, Lak0;-><init>()V

    .line 9
    .line 10
    .line 11
    iput-object p1, p0, Lb30;->f:Lak0;

    .line 12
    .line 13
    new-instance p1, Llm0;

    .line 14
    .line 15
    invoke-direct {p1}, Llm0;-><init>()V

    .line 16
    .line 17
    .line 18
    iput-object p1, p0, Lb30;->g:Llm0;

    .line 19
    .line 20
    new-instance p1, Lwj0;

    .line 21
    .line 22
    const/16 v0, 0xa

    .line 23
    .line 24
    invoke-direct {p1, v0}, Lwj0;-><init>(I)V

    .line 25
    .line 26
    .line 27
    iput-object p1, p0, Lb30;->h:Lwj0;

    .line 28
    .line 29
    return-void
.end method


# virtual methods
.method public final a(JLjava/util/List;Z)V
    .registers 23

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-wide/from16 v1, p1

    .line 4
    .line 5
    invoke-interface/range {p3 .. p3}, Ljava/util/Collection;->size()I

    .line 6
    .line 7
    .line 8
    move-result v3

    .line 9
    iget-object v4, v0, Lb30;->g:Llm0;

    .line 10
    .line 11
    const/4 v5, 0x1

    .line 12
    move-object v9, v4

    .line 13
    move v8, v5

    .line 14
    const/4 v7, 0x0

    .line 15
    :goto_e
    iget-object v10, v0, Lb30;->h:Lwj0;

    .line 16
    .line 17
    if-ge v7, v3, :cond_93

    .line 18
    .line 19
    move-object/from16 v11, p3

    .line 20
    .line 21
    invoke-interface {v11, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v12

    .line 25
    check-cast v12, Lli0;

    .line 26
    .line 27
    iget-boolean v13, v12, Lli0;->r:Z

    .line 28
    .line 29
    if-eqz v13, :cond_8f

    .line 30
    .line 31
    new-instance v13, Lg4;

    .line 32
    .line 33
    const/4 v14, 0x6

    .line 34
    invoke-direct {v13, v14, v0, v12}, Lg4;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    iput-object v13, v12, Lli0;->q:Lg4;

    .line 38
    .line 39
    if-eqz v8, :cond_6a

    .line 40
    .line 41
    iget-object v13, v9, Llm0;->a:Lqk0;

    .line 42
    .line 43
    iget-object v14, v13, Lqk0;->e:[Ljava/lang/Object;

    .line 44
    .line 45
    iget v13, v13, Lqk0;->g:I

    .line 46
    .line 47
    const/4 v15, 0x0

    .line 48
    :goto_2f
    if-ge v15, v13, :cond_43

    .line 49
    .line 50
    aget-object v16, v14, v15

    .line 51
    .line 52
    move-object/from16 v6, v16

    .line 53
    .line 54
    check-cast v6, Lbm0;

    .line 55
    .line 56
    iget-object v6, v6, Lbm0;->c:Lli0;

    .line 57
    .line 58
    invoke-static {v6, v12}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 59
    .line 60
    .line 61
    move-result v6

    .line 62
    if-eqz v6, :cond_40

    .line 63
    .line 64
    goto :goto_45

    .line 65
    :cond_40
    add-int/lit8 v15, v15, 0x1

    .line 66
    .line 67
    goto :goto_2f

    .line 68
    :cond_43
    const/16 v16, 0x0

    .line 69
    .line 70
    :goto_45
    move-object/from16 v6, v16

    .line 71
    .line 72
    check-cast v6, Lbm0;

    .line 73
    .line 74
    if-eqz v6, :cond_69

    .line 75
    .line 76
    iput-boolean v5, v6, Lbm0;->i:Z

    .line 77
    .line 78
    iget-object v9, v6, Lbm0;->d:Lzh;

    .line 79
    .line 80
    invoke-virtual {v9, v1, v2}, Lzh;->b(J)V

    .line 81
    .line 82
    .line 83
    if-eqz p4, :cond_67

    .line 84
    .line 85
    invoke-virtual {v10, v1, v2}, Lwj0;->d(J)Ljava/lang/Object;

    .line 86
    .line 87
    .line 88
    move-result-object v9

    .line 89
    if-nez v9, :cond_62

    .line 90
    .line 91
    new-instance v9, Lak0;

    .line 92
    .line 93
    invoke-direct {v9}, Lak0;-><init>()V

    .line 94
    .line 95
    .line 96
    invoke-virtual {v10, v1, v2, v9}, Lwj0;->f(JLjava/lang/Object;)V

    .line 97
    .line 98
    .line 99
    :cond_62
    check-cast v9, Lak0;

    .line 100
    .line 101
    invoke-virtual {v9, v6}, Lak0;->a(Ljava/lang/Object;)V

    .line 102
    .line 103
    .line 104
    :cond_67
    :goto_67
    move-object v9, v6

    .line 105
    goto :goto_8f

    .line 106
    :cond_69
    const/4 v8, 0x0

    .line 107
    :cond_6a
    new-instance v6, Lbm0;

    .line 108
    .line 109
    invoke-direct {v6, v12}, Lbm0;-><init>(Lli0;)V

    .line 110
    .line 111
    .line 112
    iget-object v12, v6, Lbm0;->d:Lzh;

    .line 113
    .line 114
    invoke-virtual {v12, v1, v2}, Lzh;->b(J)V

    .line 115
    .line 116
    .line 117
    if-eqz p4, :cond_89

    .line 118
    .line 119
    invoke-virtual {v10, v1, v2}, Lwj0;->d(J)Ljava/lang/Object;

    .line 120
    .line 121
    .line 122
    move-result-object v12

    .line 123
    if-nez v12, :cond_84

    .line 124
    .line 125
    new-instance v12, Lak0;

    .line 126
    .line 127
    invoke-direct {v12}, Lak0;-><init>()V

    .line 128
    .line 129
    .line 130
    invoke-virtual {v10, v1, v2, v12}, Lwj0;->f(JLjava/lang/Object;)V

    .line 131
    .line 132
    .line 133
    :cond_84
    check-cast v12, Lak0;

    .line 134
    .line 135
    invoke-virtual {v12, v6}, Lak0;->a(Ljava/lang/Object;)V

    .line 136
    .line 137
    .line 138
    :cond_89
    iget-object v9, v9, Llm0;->a:Lqk0;

    .line 139
    .line 140
    invoke-virtual {v9, v6}, Lqk0;->b(Ljava/lang/Object;)V

    .line 141
    .line 142
    .line 143
    goto :goto_67

    .line 144
    :cond_8f
    :goto_8f
    add-int/lit8 v7, v7, 0x1

    .line 145
    .line 146
    goto/16 :goto_e

    .line 147
    .line 148
    :cond_93
    if-eqz p4, :cond_106

    .line 149
    .line 150
    iget-object v0, v10, Lwj0;->b:[J

    .line 151
    .line 152
    iget-object v1, v10, Lwj0;->c:[Ljava/lang/Object;

    .line 153
    .line 154
    iget-object v2, v10, Lwj0;->a:[J

    .line 155
    .line 156
    array-length v3, v2

    .line 157
    add-int/lit8 v3, v3, -0x2

    .line 158
    .line 159
    if-ltz v3, :cond_106

    .line 160
    .line 161
    const/4 v5, 0x0

    .line 162
    :goto_a1
    aget-wide v6, v2, v5

    .line 163
    .line 164
    not-long v8, v6

    .line 165
    const/4 v11, 0x7

    .line 166
    shl-long/2addr v8, v11

    .line 167
    and-long/2addr v8, v6

    .line 168
    const-wide v11, -0x7f7f7f7f7f7f7f80L  # -2.937446524422997E-306

    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    and-long/2addr v8, v11

    .line 174
    cmp-long v8, v8, v11

    .line 175
    .line 176
    if-eqz v8, :cond_fd

    .line 177
    .line 178
    sub-int v8, v5, v3

    .line 179
    .line 180
    not-int v8, v8

    .line 181
    ushr-int/lit8 v8, v8, 0x1f

    .line 182
    .line 183
    const/16 v9, 0x8

    .line 184
    .line 185
    rsub-int/lit8 v8, v8, 0x8

    .line 186
    .line 187
    const/4 v11, 0x0

    .line 188
    :goto_bb
    if-ge v11, v8, :cond_f7

    .line 189
    .line 190
    const-wide/16 v12, 0xff

    .line 191
    .line 192
    and-long/2addr v12, v6

    .line 193
    const-wide/16 v14, 0x80

    .line 194
    .line 195
    cmp-long v12, v12, v14

    .line 196
    .line 197
    if-gez v12, :cond_ea

    .line 198
    .line 199
    shl-int/lit8 v12, v5, 0x3

    .line 200
    .line 201
    add-int/2addr v12, v11

    .line 202
    aget-wide v13, v0, v12

    .line 203
    .line 204
    aget-object v12, v1, v12

    .line 205
    .line 206
    check-cast v12, Lak0;

    .line 207
    .line 208
    iget-object v15, v4, Llm0;->a:Lqk0;

    .line 209
    .line 210
    move/from16 p0, v9

    .line 211
    .line 212
    iget-object v9, v15, Lqk0;->e:[Ljava/lang/Object;

    .line 213
    .line 214
    iget v15, v15, Lqk0;->g:I

    .line 215
    .line 216
    move-object/from16 v16, v0

    .line 217
    .line 218
    const/4 v0, 0x0

    .line 219
    :goto_da
    if-ge v0, v15, :cond_ee

    .line 220
    .line 221
    aget-object v17, v9, v0

    .line 222
    .line 223
    move/from16 p1, v0

    .line 224
    .line 225
    move-object/from16 v0, v17

    .line 226
    .line 227
    check-cast v0, Lbm0;

    .line 228
    .line 229
    invoke-virtual {v0, v13, v14, v12}, Lbm0;->f(JLak0;)V

    .line 230
    .line 231
    .line 232
    add-int/lit8 v0, p1, 0x1

    .line 233
    .line 234
    goto :goto_da

    .line 235
    :cond_ea
    move-object/from16 v16, v0

    .line 236
    .line 237
    move/from16 p0, v9

    .line 238
    .line 239
    :cond_ee
    shr-long v6, v6, p0

    .line 240
    .line 241
    add-int/lit8 v11, v11, 0x1

    .line 242
    .line 243
    move/from16 v9, p0

    .line 244
    .line 245
    move-object/from16 v0, v16

    .line 246
    .line 247
    goto :goto_bb

    .line 248
    :cond_f7
    move-object/from16 v16, v0

    .line 249
    .line 250
    move v0, v9

    .line 251
    if-ne v8, v0, :cond_106

    .line 252
    .line 253
    goto :goto_ff

    .line 254
    :cond_fd
    move-object/from16 v16, v0

    .line 255
    .line 256
    :goto_ff
    if-eq v5, v3, :cond_106

    .line 257
    .line 258
    add-int/lit8 v5, v5, 0x1

    .line 259
    .line 260
    move-object/from16 v0, v16

    .line 261
    .line 262
    goto :goto_a1

    .line 263
    :cond_106
    invoke-virtual {v10}, Lwj0;->a()V

    .line 264
    .line 265
    .line 266
    return-void
.end method

.method public final b(Le70;Z)Z
    .registers 12

    .line 1
    iget-object v0, p1, Le70;->a:Lxf0;

    .line 2
    .line 3
    iget-object v1, p0, Lb30;->a:Ln90;

    .line 4
    .line 5
    iget-object v2, p0, Lb30;->g:Llm0;

    .line 6
    .line 7
    invoke-virtual {v2, v0, v1, p1, p2}, Llm0;->a(Lxf0;Ln90;Le70;Z)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    iget-object v1, v2, Llm0;->a:Lqk0;

    .line 12
    .line 13
    const/4 v3, 0x0

    .line 14
    if-nez v0, :cond_10

    .line 15
    .line 16
    return v3

    .line 17
    :cond_10
    const/4 v0, 0x1

    .line 18
    iput-boolean v0, p0, Lb30;->b:Z

    .line 19
    .line 20
    iget-object v4, v1, Lqk0;->e:[Ljava/lang/Object;

    .line 21
    .line 22
    iget v5, v1, Lqk0;->g:I

    .line 23
    .line 24
    move v6, v3

    .line 25
    move v7, v6

    .line 26
    :goto_19
    if-ge v6, v5, :cond_2e

    .line 27
    .line 28
    aget-object v8, v4, v6

    .line 29
    .line 30
    check-cast v8, Lbm0;

    .line 31
    .line 32
    invoke-virtual {v8, p1, p2}, Lbm0;->e(Le70;Z)Z

    .line 33
    .line 34
    .line 35
    move-result v8

    .line 36
    if-nez v8, :cond_2a

    .line 37
    .line 38
    if-eqz v7, :cond_28

    .line 39
    .line 40
    goto :goto_2a

    .line 41
    :cond_28
    move v7, v3

    .line 42
    goto :goto_2b

    .line 43
    :cond_2a
    :goto_2a
    move v7, v0

    .line 44
    :goto_2b
    add-int/lit8 v6, v6, 0x1

    .line 45
    .line 46
    goto :goto_19

    .line 47
    :cond_2e
    iget-object p2, v1, Lqk0;->e:[Ljava/lang/Object;

    .line 48
    .line 49
    iget v1, v1, Lqk0;->g:I

    .line 50
    .line 51
    move v4, v3

    .line 52
    move v5, v4

    .line 53
    :goto_34
    if-ge v4, v1, :cond_49

    .line 54
    .line 55
    aget-object v6, p2, v4

    .line 56
    .line 57
    check-cast v6, Lbm0;

    .line 58
    .line 59
    invoke-virtual {v6, p1}, Lbm0;->d(Le70;)Z

    .line 60
    .line 61
    .line 62
    move-result v6

    .line 63
    if-nez v6, :cond_45

    .line 64
    .line 65
    if-eqz v5, :cond_43

    .line 66
    .line 67
    goto :goto_45

    .line 68
    :cond_43
    move v5, v3

    .line 69
    goto :goto_46

    .line 70
    :cond_45
    :goto_45
    move v5, v0

    .line 71
    :goto_46
    add-int/lit8 v4, v4, 0x1

    .line 72
    .line 73
    goto :goto_34

    .line 74
    :cond_49
    invoke-virtual {v2, p1}, Llm0;->b(Le70;)V

    .line 75
    .line 76
    .line 77
    if-nez v5, :cond_52

    .line 78
    .line 79
    if-eqz v7, :cond_51

    .line 80
    .line 81
    goto :goto_52

    .line 82
    :cond_51
    move v0, v3

    .line 83
    :cond_52
    :goto_52
    iput-boolean v3, p0, Lb30;->b:Z

    .line 84
    .line 85
    iget-boolean p1, p0, Lb30;->e:Z

    .line 86
    .line 87
    if-eqz p1, :cond_70

    .line 88
    .line 89
    iput-boolean v3, p0, Lb30;->e:Z

    .line 90
    .line 91
    iget-object p1, p0, Lb30;->f:Lak0;

    .line 92
    .line 93
    iget p2, p1, Lak0;->b:I

    .line 94
    .line 95
    move v1, v3

    .line 96
    :goto_5f
    if-ge v1, p2, :cond_6d

    .line 97
    .line 98
    invoke-virtual {p1, v1}, Lak0;->f(I)Ljava/lang/Object;

    .line 99
    .line 100
    .line 101
    move-result-object v4

    .line 102
    check-cast v4, Lli0;

    .line 103
    .line 104
    invoke-virtual {p0, v4}, Lb30;->d(Lli0;)V

    .line 105
    .line 106
    .line 107
    add-int/lit8 v1, v1, 0x1

    .line 108
    .line 109
    goto :goto_5f

    .line 110
    :cond_6d
    invoke-virtual {p1}, Lak0;->d()V

    .line 111
    .line 112
    .line 113
    :cond_70
    iget-boolean p1, p0, Lb30;->c:Z

    .line 114
    .line 115
    if-eqz p1, :cond_79

    .line 116
    .line 117
    iput-boolean v3, p0, Lb30;->c:Z

    .line 118
    .line 119
    invoke-virtual {p0}, Lb30;->c()V

    .line 120
    .line 121
    .line 122
    :cond_79
    iget-boolean p1, p0, Lb30;->d:Z

    .line 123
    .line 124
    if-eqz p1, :cond_84

    .line 125
    .line 126
    iput-boolean v3, p0, Lb30;->d:Z

    .line 127
    .line 128
    iget-object p0, v2, Llm0;->a:Lqk0;

    .line 129
    .line 130
    invoke-virtual {p0}, Lqk0;->g()V

    .line 131
    .line 132
    .line 133
    :cond_84
    return v0
.end method

.method public final c()V
    .registers 7

    .line 1
    iget-boolean v0, p0, Lb30;->b:Z

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-eqz v0, :cond_8

    .line 5
    .line 6
    iput-boolean v1, p0, Lb30;->c:Z

    .line 7
    .line 8
    return-void

    .line 9
    :cond_8
    iget-object v0, p0, Lb30;->g:Llm0;

    .line 10
    .line 11
    iget-object v2, v0, Llm0;->a:Lqk0;

    .line 12
    .line 13
    iget-object v3, v2, Lqk0;->e:[Ljava/lang/Object;

    .line 14
    .line 15
    iget v2, v2, Lqk0;->g:I

    .line 16
    .line 17
    const/4 v4, 0x0

    .line 18
    :goto_11
    if-ge v4, v2, :cond_1d

    .line 19
    .line 20
    aget-object v5, v3, v4

    .line 21
    .line 22
    check-cast v5, Lbm0;

    .line 23
    .line 24
    invoke-virtual {v5}, Lbm0;->c()V

    .line 25
    .line 26
    .line 27
    add-int/lit8 v4, v4, 0x1

    .line 28
    .line 29
    goto :goto_11

    .line 30
    :cond_1d
    iget-boolean v2, p0, Lb30;->d:Z

    .line 31
    .line 32
    if-eqz v2, :cond_24

    .line 33
    .line 34
    iput-boolean v1, p0, Lb30;->d:Z

    .line 35
    .line 36
    return-void

    .line 37
    :cond_24
    iget-object p0, v0, Llm0;->a:Lqk0;

    .line 38
    .line 39
    invoke-virtual {p0}, Lqk0;->g()V

    .line 40
    .line 41
    .line 42
    return-void
.end method

.method public final d(Lli0;)V
    .registers 7

    .line 1
    iget-boolean v0, p0, Lb30;->b:Z

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-eqz v0, :cond_d

    .line 5
    .line 6
    iput-boolean v1, p0, Lb30;->e:Z

    .line 7
    .line 8
    iget-object p0, p0, Lb30;->f:Lak0;

    .line 9
    .line 10
    invoke-virtual {p0, p1}, Lak0;->a(Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    return-void

    .line 14
    :cond_d
    iget-object p0, p0, Lb30;->g:Llm0;

    .line 15
    .line 16
    iget-object v0, p0, Llm0;->b:Lak0;

    .line 17
    .line 18
    invoke-virtual {v0}, Lak0;->d()V

    .line 19
    .line 20
    .line 21
    invoke-virtual {v0, p0}, Lak0;->a(Ljava/lang/Object;)V

    .line 22
    .line 23
    .line 24
    :cond_17
    invoke-virtual {v0}, Lak0;->i()Z

    .line 25
    .line 26
    .line 27
    move-result p0

    .line 28
    if-eqz p0, :cond_4a

    .line 29
    .line 30
    iget p0, v0, Lak0;->b:I

    .line 31
    .line 32
    sub-int/2addr p0, v1

    .line 33
    invoke-virtual {v0, p0}, Lak0;->k(I)Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object p0

    .line 37
    check-cast p0, Llm0;

    .line 38
    .line 39
    const/4 v2, 0x0

    .line 40
    :goto_27
    iget-object v3, p0, Llm0;->a:Lqk0;

    .line 41
    .line 42
    iget v4, v3, Lqk0;->g:I

    .line 43
    .line 44
    if-ge v2, v4, :cond_17

    .line 45
    .line 46
    iget-object v3, v3, Lqk0;->e:[Ljava/lang/Object;

    .line 47
    .line 48
    aget-object v3, v3, v2

    .line 49
    .line 50
    check-cast v3, Lbm0;

    .line 51
    .line 52
    iget-object v4, v3, Lbm0;->c:Lli0;

    .line 53
    .line 54
    invoke-static {v4, p1}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 55
    .line 56
    .line 57
    move-result v4

    .line 58
    if-eqz v4, :cond_44

    .line 59
    .line 60
    iget-object v4, p0, Llm0;->a:Lqk0;

    .line 61
    .line 62
    invoke-virtual {v4, v3}, Lqk0;->j(Ljava/lang/Object;)Z

    .line 63
    .line 64
    .line 65
    invoke-virtual {v3}, Lbm0;->c()V

    .line 66
    .line 67
    .line 68
    goto :goto_27

    .line 69
    :cond_44
    invoke-virtual {v0, v3}, Lak0;->a(Ljava/lang/Object;)V

    .line 70
    .line 71
    .line 72
    add-int/lit8 v2, v2, 0x1

    .line 73
    .line 74
    goto :goto_27

    .line 75
    :cond_4a
    return-void
.end method
