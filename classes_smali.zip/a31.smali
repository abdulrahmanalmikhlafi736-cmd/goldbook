.class public final La31;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Luw;


# instance fields
.field public final e:Lz21;


# direct methods
.method public constructor <init>(Lyu0;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, La31;->e:Lz21;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final k(Ljava/lang/Object;Lml;)Ljava/lang/Object;
    .registers 3

    .line 1
    iget-object p0, p0, La31;->e:Lz21;

    .line 2
    .line 3
    invoke-interface {p0, p2, p1}, Lz21;->c(Lml;Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    sget-object p1, Lcm;->e:Lcm;

    .line 8
    .line 9
    if-ne p0, p1, :cond_b

    .line 10
    .line 11
    return-object p0

    .line 12
    :cond_b
    sget-object p0, Lwe1;->a:Lwe1;

    .line 13
    .line 14
    return-object p0
.end method
