.class public abstract Lea0;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# static fields
.field public static final a:Lmp;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    invoke-static {}, Lvd1;->b()Lmp;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    sput-object v0, Lea0;->a:Lmp;

    .line 6
    .line 7
    return-void
.end method

.method public static final a(Lba0;)Llp0;
    .registers 1

    .line 1
    iget-object p0, p0, Lba0;->r:Llp0;

    .line 2
    .line 3
    if-eqz p0, :cond_5

    .line 4
    .line 5
    return-object p0

    .line 6
    :cond_5
    const-string p0, "LayoutNode should be attached to an owner"

    .line 7
    .line 8
    invoke-static {p0}, Lfu0;->C(Ljava/lang/String;)Lyh;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    throw p0
.end method
