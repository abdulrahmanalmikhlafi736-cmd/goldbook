.class public final Ldx;
.super Lu91;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Ln00;


# instance fields
.field public i:I

.field public synthetic j:Luw;

.field public synthetic k:Ljava/lang/Object;

.field public final synthetic l:Laj;


# direct methods
.method public constructor <init>(Laj;Lml;)V
    .registers 3

    .line 1
    iput-object p1, p0, Ldx;->l:Laj;

    .line 2
    .line 3
    const/4 p1, 0x3

    .line 4
    invoke-direct {p0, p1, p2}, Lu91;-><init>(ILml;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final c(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 1
    check-cast p1, Luw;

    .line 2
    .line 3
    check-cast p3, Lml;

    .line 4
    .line 5
    new-instance v0, Ldx;

    .line 6
    .line 7
    iget-object p0, p0, Ldx;->l:Laj;

    .line 8
    .line 9
    invoke-direct {v0, p0, p3}, Ldx;-><init>(Laj;Lml;)V

    .line 10
    .line 11
    .line 12
    iput-object p1, v0, Ldx;->j:Luw;

    .line 13
    .line 14
    iput-object p2, v0, Ldx;->k:Ljava/lang/Object;

    .line 15
    .line 16
    sget-object p0, Lwe1;->a:Lwe1;

    .line 17
    .line 18
    invoke-virtual {v0, p0}, Ldx;->p(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    return-object p0
.end method

.method public final p(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 7

    .line 1
    iget v0, p0, Ldx;->i:I

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x2

    .line 5
    const/4 v3, 0x1

    .line 6
    sget-object v4, Lcm;->e:Lcm;

    .line 7
    .line 8
    if-eqz v0, :cond_1d

    .line 9
    .line 10
    if-eq v0, v3, :cond_17

    .line 11
    .line 12
    if-ne v0, v2, :cond_11

    .line 13
    .line 14
    invoke-static {p1}, Lnb0;->t(Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    goto :goto_3c

    .line 18
    :cond_11
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 19
    .line 20
    invoke-static {p0}, Lod;->p(Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    return-object v1

    .line 24
    :cond_17
    iget-object v0, p0, Ldx;->j:Luw;

    .line 25
    .line 26
    invoke-static {p1}, Lnb0;->t(Ljava/lang/Object;)V

    .line 27
    .line 28
    .line 29
    goto :goto_31

    .line 30
    :cond_1d
    invoke-static {p1}, Lnb0;->t(Ljava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    iget-object v0, p0, Ldx;->j:Luw;

    .line 34
    .line 35
    iget-object p1, p0, Ldx;->k:Ljava/lang/Object;

    .line 36
    .line 37
    iput-object v0, p0, Ldx;->j:Luw;

    .line 38
    .line 39
    iput v3, p0, Ldx;->i:I

    .line 40
    .line 41
    iget-object v3, p0, Ldx;->l:Laj;

    .line 42
    .line 43
    invoke-virtual {v3, p1, p0}, Laj;->f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object p1

    .line 47
    if-ne p1, v4, :cond_31

    .line 48
    .line 49
    goto :goto_3b

    .line 50
    :cond_31
    :goto_31
    iput-object v1, p0, Ldx;->j:Luw;

    .line 51
    .line 52
    iput v2, p0, Ldx;->i:I

    .line 53
    .line 54
    invoke-interface {v0, p1, p0}, Luw;->k(Ljava/lang/Object;Lml;)Ljava/lang/Object;

    .line 55
    .line 56
    .line 57
    move-result-object p0

    .line 58
    if-ne p0, v4, :cond_3c

    .line 59
    .line 60
    :goto_3b
    return-object v4

    .line 61
    :cond_3c
    :goto_3c
    sget-object p0, Lwe1;->a:Lwe1;

    .line 62
    .line 63
    return-object p0
.end method
