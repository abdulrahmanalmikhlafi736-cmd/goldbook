.class public Lav0;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lbv0;
.implements Lk51;
.implements Leg1;


# static fields
.field public static f:Lav0;


# instance fields
.field public final synthetic e:I


# direct methods
.method public synthetic constructor <init>(I)V
    .registers 2

    .line 1
    iput p1, p0, Lav0;->e:I

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public static final c(Lav0;)V
    .registers 9

    .line 1
    sget-object v0, Ldw0;->z:Ld81;

    .line 2
    .line 3
    :cond_2
    sget-object v0, Ldw0;->z:Ld81;

    .line 4
    .line 5
    invoke-virtual {v0}, Ld81;->getValue()Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    check-cast v1, Lcs0;

    .line 10
    .line 11
    iget-object v2, v1, Lcs0;->g:Lrr0;

    .line 12
    .line 13
    invoke-virtual {v2, p0}, Lrr0;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v3

    .line 17
    check-cast v3, Loe0;

    .line 18
    .line 19
    if-nez v3, :cond_16

    .line 20
    .line 21
    move-object v3, v1

    .line 22
    goto :goto_78

    .line 23
    :cond_16
    iget-object v4, v3, Loe0;->a:Ljava/lang/Object;

    .line 24
    .line 25
    iget-object v3, v3, Loe0;->b:Ljava/lang/Object;

    .line 26
    .line 27
    iget-object v5, v2, Lrr0;->e:Lod1;

    .line 28
    .line 29
    const/4 v6, 0x0

    .line 30
    if-eqz p0, :cond_24

    .line 31
    .line 32
    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    .line 33
    .line 34
    .line 35
    move-result v7

    .line 36
    goto :goto_25

    .line 37
    :cond_24
    move v7, v6

    .line 38
    :goto_25
    invoke-virtual {v5, v7, v6, p0}, Lod1;->v(IILjava/lang/Object;)Lod1;

    .line 39
    .line 40
    .line 41
    move-result-object v6

    .line 42
    if-ne v5, v6, :cond_2c

    .line 43
    .line 44
    goto :goto_3b

    .line 45
    :cond_2c
    if-nez v6, :cond_31

    .line 46
    .line 47
    sget-object v2, Lrr0;->g:Lrr0;

    .line 48
    .line 49
    goto :goto_3b

    .line 50
    :cond_31
    new-instance v5, Lrr0;

    .line 51
    .line 52
    iget v2, v2, Lrr0;->f:I

    .line 53
    .line 54
    add-int/lit8 v2, v2, -0x1

    .line 55
    .line 56
    invoke-direct {v5, v6, v2}, Lrr0;-><init>(Lod1;I)V

    .line 57
    .line 58
    .line 59
    move-object v2, v5

    .line 60
    :goto_3b
    sget-object v5, Le3;->L:Le3;

    .line 61
    .line 62
    if-eq v4, v5, :cond_53

    .line 63
    .line 64
    invoke-interface {v2, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 65
    .line 66
    .line 67
    move-result-object v6

    .line 68
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 69
    .line 70
    .line 71
    check-cast v6, Loe0;

    .line 72
    .line 73
    new-instance v7, Loe0;

    .line 74
    .line 75
    iget-object v6, v6, Loe0;->a:Ljava/lang/Object;

    .line 76
    .line 77
    invoke-direct {v7, v6, v3}, Loe0;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 78
    .line 79
    .line 80
    invoke-virtual {v2, v4, v7}, Lrr0;->a(Ljava/lang/Object;Loe0;)Lrr0;

    .line 81
    .line 82
    .line 83
    move-result-object v2

    .line 84
    :cond_53
    if-eq v3, v5, :cond_69

    .line 85
    .line 86
    invoke-interface {v2, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 87
    .line 88
    .line 89
    move-result-object v6

    .line 90
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 91
    .line 92
    .line 93
    check-cast v6, Loe0;

    .line 94
    .line 95
    new-instance v7, Loe0;

    .line 96
    .line 97
    iget-object v6, v6, Loe0;->b:Ljava/lang/Object;

    .line 98
    .line 99
    invoke-direct {v7, v4, v6}, Loe0;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 100
    .line 101
    .line 102
    invoke-virtual {v2, v3, v7}, Lrr0;->a(Ljava/lang/Object;Loe0;)Lrr0;

    .line 103
    .line 104
    .line 105
    move-result-object v2

    .line 106
    :cond_69
    if-eq v4, v5, :cond_6e

    .line 107
    .line 108
    iget-object v6, v1, Lcs0;->e:Ljava/lang/Object;

    .line 109
    .line 110
    goto :goto_6f

    .line 111
    :cond_6e
    move-object v6, v3

    .line 112
    :goto_6f
    if-eq v3, v5, :cond_73

    .line 113
    .line 114
    iget-object v4, v1, Lcs0;->f:Ljava/lang/Object;

    .line 115
    .line 116
    :cond_73
    new-instance v3, Lcs0;

    .line 117
    .line 118
    invoke-direct {v3, v6, v4, v2}, Lcs0;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lrr0;)V

    .line 119
    .line 120
    .line 121
    :goto_78
    if-eq v1, v3, :cond_80

    .line 122
    .line 123
    invoke-virtual {v0, v1, v3}, Ld81;->i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 124
    .line 125
    .line 126
    move-result v0

    .line 127
    if-eqz v0, :cond_2

    .line 128
    .line 129
    :cond_80
    return-void
.end method

.method public static final l(Ljava/lang/String;I)Ly7;
    .registers 3

    .line 1
    sget-object v0, Llk1;->v:Ljava/util/WeakHashMap;

    .line 2
    .line 3
    new-instance v0, Ly7;

    .line 4
    .line 5
    invoke-direct {v0, p0, p1}, Ly7;-><init>(Ljava/lang/String;I)V

    .line 6
    .line 7
    .line 8
    return-object v0
.end method

.method public static final m(IJ)I
    .registers 4

    .line 1
    sget v0, Lzi1;->z:I

    .line 2
    .line 3
    mul-int/lit8 p0, p0, 0xf

    .line 4
    .line 5
    shr-long p0, p1, p0

    .line 6
    .line 7
    long-to-int p0, p0

    .line 8
    and-int/lit16 p0, p0, 0x7fff

    .line 9
    .line 10
    return p0
.end method

.method public static final n(Ljava/lang/String;I)Luf1;
    .registers 4

    .line 1
    sget-object p1, Llk1;->v:Ljava/util/WeakHashMap;

    .line 2
    .line 3
    new-instance p1, Luf1;

    .line 4
    .line 5
    new-instance v0, Lg60;

    .line 6
    .line 7
    const/4 v1, 0x0

    .line 8
    invoke-direct {v0, v1, v1, v1, v1}, Lg60;-><init>(IIII)V

    .line 9
    .line 10
    .line 11
    invoke-direct {p1, v0, p0}, Luf1;-><init>(Lg60;Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    return-object p1
.end method

.method public static o(Lkh1;Lap;I)Lpg0;
    .registers 4

    .line 1
    and-int/lit8 p2, p2, 0x2

    .line 2
    .line 3
    if-eqz p2, :cond_18

    .line 4
    .line 5
    instance-of p1, p0, Lz20;

    .line 6
    .line 7
    if-eqz p1, :cond_16

    .line 8
    .line 9
    move-object p1, p0

    .line 10
    check-cast p1, Lz20;

    .line 11
    .line 12
    check-cast p1, Lki;

    .line 13
    .line 14
    iget-object p1, p1, Lki;->w:Lda1;

    .line 15
    .line 16
    invoke-virtual {p1}, Lda1;->getValue()Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object p1

    .line 20
    check-cast p1, Ljh1;

    .line 21
    .line 22
    goto :goto_18

    .line 23
    :cond_16
    sget-object p1, Lap;->b:Lap;

    .line 24
    .line 25
    :cond_18
    :goto_18
    instance-of p2, p0, Lz20;

    .line 26
    .line 27
    if-eqz p2, :cond_26

    .line 28
    .line 29
    move-object p2, p0

    .line 30
    check-cast p2, Lz20;

    .line 31
    .line 32
    check-cast p2, Lki;

    .line 33
    .line 34
    invoke-virtual {p2}, Lki;->e()Lpj0;

    .line 35
    .line 36
    .line 37
    move-result-object p2

    .line 38
    goto :goto_28

    .line 39
    :cond_26
    sget-object p2, Lhm;->b:Lhm;

    .line 40
    .line 41
    :goto_28
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 42
    .line 43
    .line 44
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 45
    .line 46
    .line 47
    new-instance v0, Lpg0;

    .line 48
    .line 49
    check-cast p0, Lki;

    .line 50
    .line 51
    invoke-virtual {p0}, Lki;->f()Ljg0;

    .line 52
    .line 53
    .line 54
    move-result-object p0

    .line 55
    invoke-direct {v0, p0, p1, p2}, Lpg0;-><init>(Ljg0;Ljh1;Lim;)V

    .line 56
    .line 57
    .line 58
    return-object v0
.end method

.method public static p(Ld10;)Llk1;
    .registers 5

    .line 1
    sget-object v0, Lc5;->f:Lk81;

    .line 2
    .line 3
    invoke-virtual {p0, v0}, Ld10;->j(Llv0;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Landroid/view/View;

    .line 8
    .line 9
    sget-object v1, Llk1;->v:Ljava/util/WeakHashMap;

    .line 10
    .line 11
    monitor-enter v1

    .line 12
    :try_start_b
    invoke-virtual {v1, v0}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v2

    .line 16
    if-nez v2, :cond_1c

    .line 17
    .line 18
    new-instance v2, Llk1;

    .line 19
    .line 20
    invoke-direct {v2, v0}, Llk1;-><init>(Landroid/view/View;)V

    .line 21
    .line 22
    .line 23
    invoke-virtual {v1, v0, v2}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    goto :goto_1c

    .line 27
    :catchall_1a
    move-exception p0

    .line 28
    goto :goto_42

    .line 29
    :cond_1c
    :goto_1c
    check-cast v2, Llk1;
    :try_end_1e
    .catchall {:try_start_b .. :try_end_1e} :catchall_1a

    .line 30
    .line 31
    monitor-exit v1

    .line 32
    invoke-virtual {p0, v2}, Ld10;->h(Ljava/lang/Object;)Z

    .line 33
    .line 34
    .line 35
    move-result v1

    .line 36
    invoke-virtual {p0, v0}, Ld10;->h(Ljava/lang/Object;)Z

    .line 37
    .line 38
    .line 39
    move-result v3

    .line 40
    or-int/2addr v1, v3

    .line 41
    invoke-virtual {p0}, Ld10;->L()Ljava/lang/Object;

    .line 42
    .line 43
    .line 44
    move-result-object v3

    .line 45
    if-nez v1, :cond_32

    .line 46
    .line 47
    sget-object v1, Loj;->a:Lnq0;

    .line 48
    .line 49
    if-ne v3, v1, :cond_3c

    .line 50
    .line 51
    :cond_32
    new-instance v3, Lc;

    .line 52
    .line 53
    const/16 v1, 0x1d

    .line 54
    .line 55
    invoke-direct {v3, v1, v2, v0}, Lc;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 56
    .line 57
    .line 58
    invoke-virtual {p0, v3}, Ld10;->g0(Ljava/lang/Object;)V

    .line 59
    .line 60
    .line 61
    :cond_3c
    check-cast v3, Li00;

    .line 62
    .line 63
    invoke-static {v2, v3, p0}, Lj70;->b(Ljava/lang/Object;Li00;Ld10;)V

    .line 64
    .line 65
    .line 66
    return-object v2

    .line 67
    :goto_42
    monitor-exit v1

    .line 68
    throw p0
.end method

.method private final r()V
    .registers 1

    .line 1
    return-void
.end method

.method private final s(ILjava/lang/Object;)V
    .registers 3

    .line 1
    return-void
.end method


# virtual methods
.method public synthetic a()Z
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public b(Lj91;)Ltw;
    .registers 4

    .line 1
    iget p0, p0, Lav0;->e:I

    .line 2
    .line 3
    packed-switch p0, :pswitch_data_1c

    .line 4
    .line 5
    .line 6
    new-instance p0, Ld;

    .line 7
    .line 8
    const/4 v0, 0x0

    .line 9
    const/16 v1, 0x14

    .line 10
    .line 11
    invoke-direct {p0, p1, v0, v1}, Ld;-><init>(Ljava/lang/Object;Lml;I)V

    .line 12
    .line 13
    .line 14
    new-instance p1, Lcz0;

    .line 15
    .line 16
    const/4 v0, 0x0

    .line 17
    invoke-direct {p1, v0, p0}, Lcz0;-><init>(ILjava/lang/Object;)V

    .line 18
    .line 19
    .line 20
    return-object p1

    .line 21
    :pswitch_14  #0xa
    new-instance p0, Lvj;

    .line 22
    .line 23
    const/16 p1, 0x9

    .line 24
    .line 25
    invoke-direct {p0, p1}, Lvj;-><init>(I)V

    .line 26
    .line 27
    .line 28
    return-object p0

    .line 29
    :pswitch_data_1c
    .packed-switch 0xa
        :pswitch_14  #0000000a
    .end packed-switch
.end method

.method public d()I
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public e()V
    .registers 2

    .line 1
    iget p0, p0, Lav0;->e:I

    .line 2
    .line 3
    packed-switch p0, :pswitch_data_e

    .line 4
    .line 5
    .line 6
    const-string p0, "DIAGNOSTIC_PROFILE_IS_COMPRESSED"

    .line 7
    .line 8
    const-string v0, "ProfileInstaller"

    .line 9
    .line 10
    invoke-static {v0, p0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 11
    .line 12
    .line 13
    :pswitch_c  #0x0
    return-void

    .line 14
    nop

    .line 15
    :pswitch_data_e
    .packed-switch 0x0
        :pswitch_c  #00000000
    .end packed-switch
.end method

.method public f(JLu8;Lu8;Lu8;)Lu8;
    .registers 6

    .line 1
    return-object p5
.end method

.method public g(ILjava/lang/Object;)V
    .registers 5

    .line 1
    iget p0, p0, Lav0;->e:I

    .line 2
    .line 3
    packed-switch p0, :pswitch_data_3e

    .line 4
    .line 5
    .line 6
    packed-switch p1, :pswitch_data_44

    .line 7
    .line 8
    .line 9
    :pswitch_8  #0x9
    const-string p0, ""

    .line 10
    .line 11
    goto :goto_28

    .line 12
    :pswitch_b  #0xb
    const-string p0, "RESULT_DELETE_SKIP_FILE_SUCCESS"

    .line 13
    .line 14
    goto :goto_28

    .line 15
    :pswitch_e  #0xa
    const-string p0, "RESULT_INSTALL_SKIP_FILE_SUCCESS"

    .line 16
    .line 17
    goto :goto_28

    .line 18
    :pswitch_11  #0x8
    const-string p0, "RESULT_PARSE_EXCEPTION"

    .line 19
    .line 20
    goto :goto_28

    .line 21
    :pswitch_14  #0x7
    const-string p0, "RESULT_IO_EXCEPTION"

    .line 22
    .line 23
    goto :goto_28

    .line 24
    :pswitch_17  #0x6
    const-string p0, "RESULT_BASELINE_PROFILE_NOT_FOUND"

    .line 25
    .line 26
    goto :goto_28

    .line 27
    :pswitch_1a  #0x5
    const-string p0, "RESULT_DESIRED_FORMAT_UNSUPPORTED"

    .line 28
    .line 29
    goto :goto_28

    .line 30
    :pswitch_1d  #0x4
    const-string p0, "RESULT_NOT_WRITABLE"

    .line 31
    .line 32
    goto :goto_28

    .line 33
    :pswitch_20  #0x3
    const-string p0, "RESULT_UNSUPPORTED_ART_VERSION"

    .line 34
    .line 35
    goto :goto_28

    .line 36
    :pswitch_23  #0x2
    const-string p0, "RESULT_ALREADY_INSTALLED"

    .line 37
    .line 38
    goto :goto_28

    .line 39
    :pswitch_26  #0x1
    const-string p0, "RESULT_INSTALL_SUCCESS"

    .line 40
    .line 41
    :goto_28
    const/4 v0, 0x6

    .line 42
    const-string v1, "ProfileInstaller"

    .line 43
    .line 44
    if-eq p1, v0, :cond_38

    .line 45
    .line 46
    const/4 v0, 0x7

    .line 47
    if-eq p1, v0, :cond_38

    .line 48
    .line 49
    const/16 v0, 0x8

    .line 50
    .line 51
    if-eq p1, v0, :cond_38

    .line 52
    .line 53
    invoke-static {v1, p0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 54
    .line 55
    .line 56
    goto :goto_3d

    .line 57
    :cond_38
    check-cast p2, Ljava/lang/Throwable;

    .line 58
    .line 59
    invoke-static {v1, p0, p2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 60
    .line 61
    .line 62
    :goto_3d
    :pswitch_3d  #0x0
    return-void

    .line 63
    :pswitch_data_3e
    .packed-switch 0x0
        :pswitch_3d  #00000000
    .end packed-switch

    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    :pswitch_data_44
    .packed-switch 0x1
        :pswitch_26  #00000001
        :pswitch_23  #00000002
        :pswitch_20  #00000003
        :pswitch_1d  #00000004
        :pswitch_1a  #00000005
        :pswitch_17  #00000006
        :pswitch_14  #00000007
        :pswitch_11  #00000008
        :pswitch_8  #00000009
        :pswitch_e  #0000000a
        :pswitch_b  #0000000b
    .end packed-switch
.end method

.method public h()I
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public i(JLu8;Lu8;Lu8;)Lu8;
    .registers 8

    .line 1
    const-wide/16 v0, 0x0

    .line 2
    .line 3
    cmp-long p0, p1, v0

    .line 4
    .line 5
    if-gez p0, :cond_7

    .line 6
    .line 7
    return-object p3

    .line 8
    :cond_7
    return-object p4
.end method

.method public j(Lu8;Lu8;Lu8;)Lu8;
    .registers 4

    .line 1
    return-object p3
.end method

.method public k(Lu8;Lu8;Lu8;)J
    .registers 4

    .line 1
    const-wide/16 p0, 0x0

    .line 2
    .line 3
    return-wide p0
.end method

.method public q(Ljava/lang/CharSequence;)Z
    .registers 2

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public toString()Ljava/lang/String;
    .registers 2

    .line 1
    iget v0, p0, Lav0;->e:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_14

    .line 4
    .line 5
    .line 6
    :pswitch_5  #0xc
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    return-object p0

    .line 11
    :pswitch_a  #0xd
    const-string p0, "ReusedSlotId"

    .line 12
    .line 13
    return-object p0

    .line 14
    :pswitch_d  #0xb
    const-string p0, "SharingStarted.Lazily"

    .line 15
    .line 16
    return-object p0

    .line 17
    :pswitch_10  #0xa
    const-string p0, "SharingStarted.Eagerly"

    .line 18
    .line 19
    return-object p0

    .line 20
    nop

    .line 21
    :pswitch_data_14
    .packed-switch 0xa
        :pswitch_10  #0000000a
        :pswitch_d  #0000000b
        :pswitch_5  #0000000c
        :pswitch_a  #0000000d
    .end packed-switch
.end method
