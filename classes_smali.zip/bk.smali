.class public final Lbk;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# static fields
.field public static final synthetic a:Lbk;

.field public static final b:Lqr0;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, Lbk;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lbk;->a:Lbk;

    .line 7
    .line 8
    sget-object v0, Lqr0;->h:Lqr0;

    .line 9
    .line 10
    sput-object v0, Lbk;->b:Lqr0;

    .line 11
    .line 12
    return-void
.end method
