.class public final Ldk;
.super Lh90;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lxz;


# static fields
.field public static final g:Ldk;

.field public static final h:Ldk;

.field public static final i:Ldk;

.field public static final j:Ldk;

.field public static final k:Ldk;

.field public static final l:Ldk;

.field public static final m:Ldk;

.field public static final n:Ldk;

.field public static final o:Ldk;

.field public static final p:Ldk;

.field public static final q:Ldk;

.field public static final r:Ldk;

.field public static final s:Ldk;


# instance fields
.field public final synthetic f:I


# direct methods
.method static synthetic constructor <clinit>()V
    .registers 3

    .line 1
    new-instance v0, Ldk;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x0

    .line 5
    invoke-direct {v0, v1, v2}, Ldk;-><init>(II)V

    .line 6
    .line 7
    .line 8
    sput-object v0, Ldk;->g:Ldk;

    .line 9
    .line 10
    new-instance v0, Ldk;

    .line 11
    .line 12
    const/4 v2, 0x1

    .line 13
    invoke-direct {v0, v1, v2}, Ldk;-><init>(II)V

    .line 14
    .line 15
    .line 16
    sput-object v0, Ldk;->h:Ldk;

    .line 17
    .line 18
    new-instance v0, Ldk;

    .line 19
    .line 20
    const/4 v2, 0x2

    .line 21
    invoke-direct {v0, v1, v2}, Ldk;-><init>(II)V

    .line 22
    .line 23
    .line 24
    sput-object v0, Ldk;->i:Ldk;

    .line 25
    .line 26
    new-instance v0, Ldk;

    .line 27
    .line 28
    const/4 v2, 0x3

    .line 29
    invoke-direct {v0, v1, v2}, Ldk;-><init>(II)V

    .line 30
    .line 31
    .line 32
    sput-object v0, Ldk;->j:Ldk;

    .line 33
    .line 34
    new-instance v0, Ldk;

    .line 35
    .line 36
    const/4 v2, 0x4

    .line 37
    invoke-direct {v0, v1, v2}, Ldk;-><init>(II)V

    .line 38
    .line 39
    .line 40
    sput-object v0, Ldk;->k:Ldk;

    .line 41
    .line 42
    new-instance v0, Ldk;

    .line 43
    .line 44
    const/4 v2, 0x5

    .line 45
    invoke-direct {v0, v1, v2}, Ldk;-><init>(II)V

    .line 46
    .line 47
    .line 48
    sput-object v0, Ldk;->l:Ldk;

    .line 49
    .line 50
    new-instance v0, Ldk;

    .line 51
    .line 52
    const/4 v2, 0x6

    .line 53
    invoke-direct {v0, v1, v2}, Ldk;-><init>(II)V

    .line 54
    .line 55
    .line 56
    sput-object v0, Ldk;->m:Ldk;

    .line 57
    .line 58
    new-instance v0, Ldk;

    .line 59
    .line 60
    const/4 v2, 0x7

    .line 61
    invoke-direct {v0, v1, v2}, Ldk;-><init>(II)V

    .line 62
    .line 63
    .line 64
    sput-object v0, Ldk;->n:Ldk;

    .line 65
    .line 66
    new-instance v0, Ldk;

    .line 67
    .line 68
    const/16 v2, 0x8

    .line 69
    .line 70
    invoke-direct {v0, v1, v2}, Ldk;-><init>(II)V

    .line 71
    .line 72
    .line 73
    sput-object v0, Ldk;->o:Ldk;

    .line 74
    .line 75
    new-instance v0, Ldk;

    .line 76
    .line 77
    const/16 v2, 0x9

    .line 78
    .line 79
    invoke-direct {v0, v1, v2}, Ldk;-><init>(II)V

    .line 80
    .line 81
    .line 82
    sput-object v0, Ldk;->p:Ldk;

    .line 83
    .line 84
    new-instance v0, Ldk;

    .line 85
    .line 86
    const/16 v2, 0xa

    .line 87
    .line 88
    invoke-direct {v0, v1, v2}, Ldk;-><init>(II)V

    .line 89
    .line 90
    .line 91
    sput-object v0, Ldk;->q:Ldk;

    .line 92
    .line 93
    new-instance v0, Ldk;

    .line 94
    .line 95
    const/16 v2, 0xb

    .line 96
    .line 97
    invoke-direct {v0, v1, v2}, Ldk;-><init>(II)V

    .line 98
    .line 99
    .line 100
    sput-object v0, Ldk;->r:Ldk;

    .line 101
    .line 102
    new-instance v0, Ldk;

    .line 103
    .line 104
    const/16 v2, 0xc

    .line 105
    .line 106
    invoke-direct {v0, v1, v2}, Ldk;-><init>(II)V

    .line 107
    .line 108
    .line 109
    sput-object v0, Ldk;->s:Ldk;

    .line 110
    .line 111
    return-void
.end method

.method public synthetic constructor <init>(II)V
    .registers 3

    .line 1
    iput p2, p0, Ldk;->f:I

    .line 2
    .line 3
    invoke-direct {p0, p1}, Lh90;-><init>(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .registers 2

    .line 1
    iget p0, p0, Ldk;->f:I

    .line 2
    .line 3
    const/4 v0, 0x0

    .line 4
    packed-switch p0, :pswitch_data_3e

    .line 5
    .line 6
    .line 7
    sget-object p0, Lwe1;->a:Lwe1;

    .line 8
    .line 9
    return-object p0

    .line 10
    :pswitch_9  #0xb
    return-object v0

    .line 11
    :pswitch_a  #0xa
    new-instance p0, Ls6;

    .line 12
    .line 13
    new-instance v0, Landroid/graphics/PathMeasure;

    .line 14
    .line 15
    invoke-direct {v0}, Landroid/graphics/PathMeasure;-><init>()V

    .line 16
    .line 17
    .line 18
    invoke-direct {p0, v0}, Ls6;-><init>(Landroid/graphics/PathMeasure;)V

    .line 19
    .line 20
    .line 21
    return-object p0

    .line 22
    :pswitch_15  #0x9
    new-instance p0, Lba0;

    .line 23
    .line 24
    const/4 v0, 0x3

    .line 25
    invoke-direct {p0, v0}, Lba0;-><init>(I)V

    .line 26
    .line 27
    .line 28
    return-object p0

    .line 29
    :pswitch_1c  #0x8
    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 30
    .line 31
    return-object p0

    .line 32
    :pswitch_1f  #0x7
    sget-object p0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 33
    .line 34
    return-object p0

    .line 35
    :pswitch_22  #0x6
    const-string p0, "LocalWindowInfo"

    .line 36
    .line 37
    invoke-static {p0}, Lfk;->b(Ljava/lang/String;)V

    .line 38
    .line 39
    .line 40
    throw v0

    .line 41
    :pswitch_28  #0x5
    const-string p0, "LocalViewConfiguration"

    .line 42
    .line 43
    invoke-static {p0}, Lfk;->b(Ljava/lang/String;)V

    .line 44
    .line 45
    .line 46
    throw v0

    .line 47
    :pswitch_2e  #0x4
    const-string p0, "LocalUriHandler"

    .line 48
    .line 49
    invoke-static {p0}, Lfk;->b(Ljava/lang/String;)V

    .line 50
    .line 51
    .line 52
    throw v0

    .line 53
    :pswitch_34  #0x3
    const-string p0, "LocalTextToolbar"

    .line 54
    .line 55
    invoke-static {p0}, Lfk;->b(Ljava/lang/String;)V

    .line 56
    .line 57
    .line 58
    throw v0

    .line 59
    :pswitch_3a  #0x1, 0x2
    return-object v0

    .line 60
    :pswitch_3b  #0x0
    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 61
    .line 62
    return-object p0

    .line 63
    :pswitch_data_3e
    .packed-switch 0x0
        :pswitch_3b  #00000000
        :pswitch_3a  #00000001
        :pswitch_3a  #00000002
        :pswitch_34  #00000003
        :pswitch_2e  #00000004
        :pswitch_28  #00000005
        :pswitch_22  #00000006
        :pswitch_1f  #00000007
        :pswitch_1c  #00000008
        :pswitch_15  #00000009
        :pswitch_a  #0000000a
        :pswitch_9  #0000000b
    .end packed-switch
.end method
