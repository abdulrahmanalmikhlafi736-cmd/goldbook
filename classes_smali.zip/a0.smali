.class public abstract La0;
.super Ljava/util/AbstractSet;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Ljava/util/Set;
.implements Ly80;


# virtual methods
.method public abstract a()I
.end method

.method public final bridge size()I
    .registers 1

    .line 1
    invoke-virtual {p0}, La0;->a()I

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    return p0
.end method
