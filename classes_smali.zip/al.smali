.class public final Lal;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Llt;
.implements Ltw;
.implements Li91;
.implements Loe;
.implements Lyo0;
.implements La01;


# instance fields
.field public final synthetic e:I

.field public f:Ljava/lang/Object;

.field public g:Ljava/lang/Object;


# direct methods
.method public constructor <init>(I)V
    .registers 3

    .line 1
    iput p1, p0, Lal;->e:I

    .line 2
    .line 3
    const/16 v0, 0x10

    .line 4
    .line 5
    sparse-switch p1, :sswitch_data_82

    .line 6
    .line 7
    .line 8
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 9
    .line 10
    .line 11
    return-void

    .line 12
    :sswitch_b
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 13
    .line 14
    .line 15
    new-instance p1, Lqk0;

    .line 16
    .line 17
    new-array v0, v0, [Ljava/lang/ref/Reference;

    .line 18
    .line 19
    invoke-direct {p1, v0}, Lqk0;-><init>([Ljava/lang/Object;)V

    .line 20
    .line 21
    .line 22
    iput-object p1, p0, Lal;->f:Ljava/lang/Object;

    .line 23
    .line 24
    new-instance p1, Ljava/lang/ref/ReferenceQueue;

    .line 25
    .line 26
    invoke-direct {p1}, Ljava/lang/ref/ReferenceQueue;-><init>()V

    .line 27
    .line 28
    .line 29
    iput-object p1, p0, Lal;->g:Ljava/lang/Object;

    .line 30
    .line 31
    return-void

    .line 32
    :sswitch_1f
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 33
    .line 34
    .line 35
    new-instance p1, Lav0;

    .line 36
    .line 37
    invoke-direct {p1, v0}, Lav0;-><init>(I)V

    .line 38
    .line 39
    .line 40
    iput-object p1, p0, Lal;->f:Ljava/lang/Object;

    .line 41
    .line 42
    new-instance p1, Lig0;

    .line 43
    .line 44
    invoke-direct {p1, v0}, Lig0;-><init>(I)V

    .line 45
    .line 46
    .line 47
    iput-object p1, p0, Lal;->g:Ljava/lang/Object;

    .line 48
    .line 49
    return-void

    .line 50
    :sswitch_31
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 51
    .line 52
    .line 53
    new-instance p1, Ljava/util/LinkedHashMap;

    .line 54
    .line 55
    invoke-direct {p1}, Ljava/util/LinkedHashMap;-><init>()V

    .line 56
    .line 57
    .line 58
    iput-object p1, p0, Lal;->f:Ljava/lang/Object;

    .line 59
    .line 60
    new-instance p1, Ljava/util/LinkedHashMap;

    .line 61
    .line 62
    invoke-direct {p1}, Ljava/util/LinkedHashMap;-><init>()V

    .line 63
    .line 64
    .line 65
    iput-object p1, p0, Lal;->g:Ljava/lang/Object;

    .line 66
    .line 67
    return-void

    .line 68
    :sswitch_43
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 69
    .line 70
    .line 71
    new-instance p1, Lqk0;

    .line 72
    .line 73
    new-array v0, v0, [Lba0;

    .line 74
    .line 75
    invoke-direct {p1, v0}, Lqk0;-><init>([Ljava/lang/Object;)V

    .line 76
    .line 77
    .line 78
    iput-object p1, p0, Lal;->f:Ljava/lang/Object;

    .line 79
    .line 80
    return-void

    .line 81
    :sswitch_50
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 82
    .line 83
    .line 84
    new-instance p1, Lhk0;

    .line 85
    .line 86
    invoke-direct {p1}, Lhk0;-><init>()V

    .line 87
    .line 88
    .line 89
    iput-object p1, p0, Lal;->f:Ljava/lang/Object;

    .line 90
    .line 91
    new-instance p1, Lhk0;

    .line 92
    .line 93
    invoke-direct {p1}, Lhk0;-><init>()V

    .line 94
    .line 95
    .line 96
    iput-object p1, p0, Lal;->g:Ljava/lang/Object;

    .line 97
    .line 98
    return-void

    .line 99
    :sswitch_62
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 100
    .line 101
    .line 102
    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 103
    .line 104
    invoke-static {p1}, Lmc0;->t(Ljava/lang/Object;)Llq0;

    .line 105
    .line 106
    .line 107
    move-result-object p1

    .line 108
    iput-object p1, p0, Lal;->f:Ljava/lang/Object;

    .line 109
    .line 110
    return-void

    .line 111
    :sswitch_6e
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 112
    .line 113
    .line 114
    new-instance p1, Lig1;

    .line 115
    .line 116
    const/4 v0, 0x0

    .line 117
    invoke-direct {p1, v0}, Lig1;-><init>(I)V

    .line 118
    .line 119
    .line 120
    iput-object p1, p0, Lal;->f:Ljava/lang/Object;

    .line 121
    .line 122
    new-instance p1, Lig1;

    .line 123
    .line 124
    invoke-direct {p1, v0}, Lig1;-><init>(I)V

    .line 125
    .line 126
    .line 127
    iput-object p1, p0, Lal;->g:Ljava/lang/Object;

    .line 128
    .line 129
    return-void

    .line 130
    nop

    .line 131
    :sswitch_data_82
    .sparse-switch
        0xa -> :sswitch_6e
        0xb -> :sswitch_62
        0xd -> :sswitch_50
        0xe -> :sswitch_43
        0x12 -> :sswitch_31
        0x17 -> :sswitch_1f
        0x18 -> :sswitch_b
    .end sparse-switch
.end method

.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Object;)V
    .registers 4

    .line 137
    iput p1, p0, Lal;->e:I

    iput-object p2, p0, Lal;->f:Ljava/lang/Object;

    iput-object p3, p0, Lal;->g:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Landroid/view/WindowInsetsAnimation$Bounds;)V
    .registers 3

    const/16 v0, 0x19

    iput v0, p0, Lal;->e:I

    .line 151
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 152
    invoke-static {p1}, Lc1;->f(Landroid/view/WindowInsetsAnimation$Bounds;)Landroid/graphics/Insets;

    move-result-object v0

    invoke-static {v0}, Lc60;->c(Landroid/graphics/Insets;)Lc60;

    move-result-object v0

    .line 153
    iput-object v0, p0, Lal;->f:Ljava/lang/Object;

    .line 154
    invoke-static {p1}, Lc1;->z(Landroid/view/WindowInsetsAnimation$Bounds;)Landroid/graphics/Insets;

    move-result-object p1

    invoke-static {p1}, Lc60;->c(Landroid/graphics/Insets;)Lc60;

    move-result-object p1

    .line 155
    iput-object p1, p0, Lal;->g:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lba0;Lmh0;)V
    .registers 4

    const/4 v0, 0x6

    iput v0, p0, Lal;->e:I

    .line 138
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lal;->f:Ljava/lang/Object;

    .line 139
    invoke-static {p2}, Lmc0;->t(Ljava/lang/Object;)Llq0;

    move-result-object p1

    iput-object p1, p0, Lal;->g:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lhb0;)V
    .registers 3

    const/4 v0, 0x7

    iput v0, p0, Lal;->e:I

    .line 144
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lal;->f:Ljava/lang/Object;

    .line 145
    sget-object p1, Lsm0;->a:Lzj0;

    .line 146
    new-instance p1, Lzj0;

    invoke-direct {p1}, Lzj0;-><init>()V

    .line 147
    iput-object p1, p0, Lal;->g:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Ljava/lang/Object;)V
    .registers 3

    const/16 v0, 0xb

    iput v0, p0, Lal;->e:I

    .line 148
    invoke-direct {p0, v0}, Lal;-><init>(I)V

    .line 149
    invoke-static {p1}, Lmc0;->t(Ljava/lang/Object;)Llq0;

    move-result-object v0

    iput-object v0, p0, Lal;->g:Ljava/lang/Object;

    .line 150
    invoke-static {p1}, Lmc0;->t(Ljava/lang/Object;)Llq0;

    return-void
.end method

.method public constructor <init>(Lna;)V
    .registers 3

    const/16 v0, 0xf

    iput v0, p0, Lal;->e:I

    .line 140
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lal;->f:Ljava/lang/Object;

    .line 141
    new-instance p1, Lca;

    const/4 v0, 0x0

    .line 142
    invoke-direct {p1, v0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V

    .line 143
    iput-object p1, p0, Lal;->g:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lwz0;I)V
    .registers 4

    iput p2, p0, Lal;->e:I

    packed-switch p2, :pswitch_data_1a

    .line 134
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lal;->f:Ljava/lang/Object;

    return-void

    .line 135
    :pswitch_b  #0x14
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lal;->f:Ljava/lang/Object;

    .line 136
    new-instance p2, Lal;

    const/16 v0, 0x13

    invoke-direct {p2, p1, v0}, Lal;-><init>(Lwz0;I)V

    iput-object p2, p0, Lal;->g:Ljava/lang/Object;

    return-void

    :pswitch_data_1a
    .packed-switch 0x14
        :pswitch_b  #00000014
    .end packed-switch
.end method

.method public constructor <init>(Lxz;Li00;)V
    .registers 4

    const/4 v0, 0x2

    iput v0, p0, Lal;->e:I

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 131
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 132
    iput-object p2, p0, Lal;->f:Ljava/lang/Object;

    .line 133
    iput-object p1, p0, Lal;->g:Ljava/lang/Object;

    return-void
.end method

.method public static m(Lba0;)V
    .registers 11

    .line 1
    iget v0, p0, Lba0;->T:I

    .line 2
    .line 3
    if-lez v0, :cond_a6

    .line 4
    .line 5
    iget-object v0, p0, Lba0;->K:Lfa0;

    .line 6
    .line 7
    iget-object v0, v0, Lfa0;->d:Lx90;

    .line 8
    .line 9
    sget-object v1, Lx90;->i:Lx90;

    .line 10
    .line 11
    const/4 v2, 0x0

    .line 12
    if-ne v0, v1, :cond_90

    .line 13
    .line 14
    invoke-virtual {p0}, Lba0;->p()Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-nez v0, :cond_90

    .line 19
    .line 20
    invoke-virtual {p0}, Lba0;->q()Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    if-nez v0, :cond_90

    .line 25
    .line 26
    iget-boolean v0, p0, Lba0;->U:Z

    .line 27
    .line 28
    if-eqz v0, :cond_1f

    .line 29
    .line 30
    goto/16 :goto_90

    .line 31
    .line 32
    :cond_1f
    invoke-virtual {p0}, Lba0;->I()Z

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    if-nez v0, :cond_27

    .line 37
    .line 38
    goto/16 :goto_90

    .line 39
    .line 40
    :cond_27
    iget-object v0, p0, Lba0;->J:Lem0;

    .line 41
    .line 42
    iget-object v0, v0, Lem0;->f:Lli0;

    .line 43
    .line 44
    iget v1, v0, Lli0;->h:I

    .line 45
    .line 46
    const/16 v3, 0x100

    .line 47
    .line 48
    and-int/2addr v1, v3

    .line 49
    if-eqz v1, :cond_90

    .line 50
    .line 51
    :goto_32
    if-eqz v0, :cond_90

    .line 52
    .line 53
    iget v1, v0, Lli0;->g:I

    .line 54
    .line 55
    and-int/2addr v1, v3

    .line 56
    if-eqz v1, :cond_88

    .line 57
    .line 58
    const/4 v1, 0x0

    .line 59
    move-object v4, v0

    .line 60
    move-object v5, v1

    .line 61
    :goto_3c
    if-eqz v4, :cond_88

    .line 62
    .line 63
    instance-of v6, v4, Lq10;

    .line 64
    .line 65
    if-eqz v6, :cond_4c

    .line 66
    .line 67
    check-cast v4, Lq10;

    .line 68
    .line 69
    invoke-static {v4, v3}, Lk70;->M(Lcp;I)Lgm0;

    .line 70
    .line 71
    .line 72
    move-result-object v6

    .line 73
    invoke-interface {v4, v6}, Lq10;->o(Lgm0;)V

    .line 74
    .line 75
    .line 76
    goto :goto_83

    .line 77
    :cond_4c
    iget v6, v4, Lli0;->g:I

    .line 78
    .line 79
    and-int/2addr v6, v3

    .line 80
    if-eqz v6, :cond_83

    .line 81
    .line 82
    instance-of v6, v4, Ldp;

    .line 83
    .line 84
    if-eqz v6, :cond_83

    .line 85
    .line 86
    move-object v6, v4

    .line 87
    check-cast v6, Ldp;

    .line 88
    .line 89
    iget-object v6, v6, Ldp;->t:Lli0;

    .line 90
    .line 91
    move v7, v2

    .line 92
    :goto_5b
    const/4 v8, 0x1

    .line 93
    if-eqz v6, :cond_80

    .line 94
    .line 95
    iget v9, v6, Lli0;->g:I

    .line 96
    .line 97
    and-int/2addr v9, v3

    .line 98
    if-eqz v9, :cond_7d

    .line 99
    .line 100
    add-int/lit8 v7, v7, 0x1

    .line 101
    .line 102
    if-ne v7, v8, :cond_69

    .line 103
    .line 104
    move-object v4, v6

    .line 105
    goto :goto_7d

    .line 106
    :cond_69
    if-nez v5, :cond_74

    .line 107
    .line 108
    new-instance v5, Lqk0;

    .line 109
    .line 110
    const/16 v8, 0x10

    .line 111
    .line 112
    new-array v8, v8, [Lli0;

    .line 113
    .line 114
    invoke-direct {v5, v8}, Lqk0;-><init>([Ljava/lang/Object;)V

    .line 115
    .line 116
    .line 117
    :cond_74
    if-eqz v4, :cond_7a

    .line 118
    .line 119
    invoke-virtual {v5, v4}, Lqk0;->b(Ljava/lang/Object;)V

    .line 120
    .line 121
    .line 122
    move-object v4, v1

    .line 123
    :cond_7a
    invoke-virtual {v5, v6}, Lqk0;->b(Ljava/lang/Object;)V

    .line 124
    .line 125
    .line 126
    :cond_7d
    :goto_7d
    iget-object v6, v6, Lli0;->j:Lli0;

    .line 127
    .line 128
    goto :goto_5b

    .line 129
    :cond_80
    if-ne v7, v8, :cond_83

    .line 130
    .line 131
    goto :goto_3c

    .line 132
    :cond_83
    :goto_83
    invoke-static {v5}, Lk70;->m(Lqk0;)Lli0;

    .line 133
    .line 134
    .line 135
    move-result-object v4

    .line 136
    goto :goto_3c

    .line 137
    :cond_88
    iget v1, v0, Lli0;->h:I

    .line 138
    .line 139
    and-int/2addr v1, v3

    .line 140
    if-eqz v1, :cond_90

    .line 141
    .line 142
    iget-object v0, v0, Lli0;->j:Lli0;

    .line 143
    .line 144
    goto :goto_32

    .line 145
    :cond_90
    :goto_90
    iput-boolean v2, p0, Lba0;->S:Z

    .line 146
    .line 147
    invoke-virtual {p0}, Lba0;->z()Lqk0;

    .line 148
    .line 149
    .line 150
    move-result-object p0

    .line 151
    iget-object v0, p0, Lqk0;->e:[Ljava/lang/Object;

    .line 152
    .line 153
    iget p0, p0, Lqk0;->g:I

    .line 154
    .line 155
    :goto_9a
    if-ge v2, p0, :cond_a6

    .line 156
    .line 157
    aget-object v1, v0, v2

    .line 158
    .line 159
    check-cast v1, Lba0;

    .line 160
    .line 161
    invoke-static {v1}, Lal;->m(Lba0;)V

    .line 162
    .line 163
    .line 164
    add-int/lit8 v2, v2, 0x1

    .line 165
    .line 166
    goto :goto_9a

    .line 167
    :cond_a6
    return-void
.end method


# virtual methods
.method public a()Ljava/lang/Object;
    .registers 1

    .line 1
    iget-object p0, p0, Lal;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Lbf1;

    .line 4
    .line 5
    return-object p0
.end method

.method public b(Luw;Lml;)Ljava/lang/Object;
    .registers 13

    .line 1
    iget v0, p0, Lal;->e:I

    .line 2
    .line 3
    const/4 v1, 0x2

    .line 4
    const-string v2, "call to \'resume\' before \'invoke\' with coroutine"

    .line 5
    .line 6
    const/high16 v3, -0x80000000

    .line 7
    .line 8
    sget-object v4, Lwe1;->a:Lwe1;

    .line 9
    .line 10
    const/4 v5, 0x0

    .line 11
    sget-object v6, Lcm;->e:Lcm;

    .line 12
    .line 13
    const/4 v7, 0x1

    .line 14
    packed-switch v0, :pswitch_data_fa

    .line 15
    .line 16
    .line 17
    instance-of v0, p2, Lbx;

    .line 18
    .line 19
    if-eqz v0, :cond_21

    .line 20
    .line 21
    move-object v0, p2

    .line 22
    check-cast v0, Lbx;

    .line 23
    .line 24
    iget v1, v0, Lbx;->i:I

    .line 25
    .line 26
    and-int v8, v1, v3

    .line 27
    .line 28
    if-eqz v8, :cond_21

    .line 29
    .line 30
    sub-int/2addr v1, v3

    .line 31
    iput v1, v0, Lbx;->i:I

    .line 32
    .line 33
    goto :goto_26

    .line 34
    :cond_21
    new-instance v0, Lbx;

    .line 35
    .line 36
    invoke-direct {v0, p0, p2}, Lbx;-><init>(Lal;Lml;)V

    .line 37
    .line 38
    .line 39
    :goto_26
    iget-object p2, v0, Lbx;->h:Ljava/lang/Object;

    .line 40
    .line 41
    iget v1, v0, Lbx;->i:I

    .line 42
    .line 43
    if-eqz v1, :cond_3b

    .line 44
    .line 45
    if-ne v1, v7, :cond_36

    .line 46
    .line 47
    iget-object p0, v0, Lbx;->k:Lxq;

    .line 48
    .line 49
    :try_start_30
    invoke-static {p2}, Lnb0;->t(Ljava/lang/Object;)V
    :try_end_33
    .catch La; {:try_start_30 .. :try_end_33} :catch_34

    .line 50
    .line 51
    .line 52
    goto :goto_65

    .line 53
    :catch_34
    move-exception p1

    .line 54
    goto :goto_59

    .line 55
    :cond_36
    invoke-static {v2}, Lod;->p(Ljava/lang/String;)V

    .line 56
    .line 57
    .line 58
    move-object v4, v5

    .line 59
    goto :goto_65

    .line 60
    :cond_3b
    invoke-static {p2}, Lnb0;->t(Ljava/lang/Object;)V

    .line 61
    .line 62
    .line 63
    iget-object p2, p0, Lal;->f:Ljava/lang/Object;

    .line 64
    .line 65
    check-cast p2, Lal;

    .line 66
    .line 67
    new-instance v1, Lxq;

    .line 68
    .line 69
    iget-object p0, p0, Lal;->g:Ljava/lang/Object;

    .line 70
    .line 71
    check-cast p0, Lcn;

    .line 72
    .line 73
    invoke-direct {v1, v7, p0, p1}, Lxq;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 74
    .line 75
    .line 76
    :try_start_4b
    iput-object v1, v0, Lbx;->k:Lxq;

    .line 77
    .line 78
    iput v7, v0, Lbx;->i:I

    .line 79
    .line 80
    invoke-virtual {p2, v1, v0}, Lal;->b(Luw;Lml;)Ljava/lang/Object;

    .line 81
    .line 82
    .line 83
    move-result-object p0
    :try_end_53
    .catch La; {:try_start_4b .. :try_end_53} :catch_57

    .line 84
    if-ne p0, v6, :cond_65

    .line 85
    .line 86
    move-object v4, v6

    .line 87
    goto :goto_65

    .line 88
    :catch_57
    move-exception p1

    .line 89
    move-object p0, v1

    .line 90
    :goto_59
    iget-object p2, p1, La;->e:Ljava/lang/Object;

    .line 91
    .line 92
    if-ne p2, p0, :cond_66

    .line 93
    .line 94
    iget-object p0, v0, Lnl;->f:Lsl;

    .line 95
    .line 96
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 97
    .line 98
    .line 99
    invoke-static {p0}, Lj70;->B(Lsl;)V

    .line 100
    .line 101
    .line 102
    :cond_65
    :goto_65
    return-object v4

    .line 103
    :cond_66
    throw p1

    .line 104
    :pswitch_67  #0x4
    new-instance v0, Ljw0;

    .line 105
    .line 106
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 107
    .line 108
    .line 109
    iget-object v2, p0, Lal;->f:Ljava/lang/Object;

    .line 110
    .line 111
    check-cast v2, Ltw;

    .line 112
    .line 113
    new-instance v3, Lg8;

    .line 114
    .line 115
    iget-object p0, p0, Lal;->g:Ljava/lang/Object;

    .line 116
    .line 117
    check-cast p0, Lm00;

    .line 118
    .line 119
    invoke-direct {v3, v0, p1, p0, v1}, Lg8;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 120
    .line 121
    .line 122
    invoke-interface {v2, v3, p2}, Ltw;->b(Luw;Lml;)Ljava/lang/Object;

    .line 123
    .line 124
    .line 125
    move-result-object p0

    .line 126
    if-ne p0, v6, :cond_80

    .line 127
    .line 128
    move-object v4, p0

    .line 129
    :cond_80
    return-object v4

    .line 130
    :pswitch_81  #0x3
    instance-of v0, p2, Lzw;

    .line 131
    .line 132
    if-eqz v0, :cond_92

    .line 133
    .line 134
    move-object v0, p2

    .line 135
    check-cast v0, Lzw;

    .line 136
    .line 137
    iget v8, v0, Lzw;->i:I

    .line 138
    .line 139
    and-int v9, v8, v3

    .line 140
    .line 141
    if-eqz v9, :cond_92

    .line 142
    .line 143
    sub-int/2addr v8, v3

    .line 144
    iput v8, v0, Lzw;->i:I

    .line 145
    .line 146
    goto :goto_97

    .line 147
    :cond_92
    new-instance v0, Lzw;

    .line 148
    .line 149
    invoke-direct {v0, p0, p2}, Lzw;-><init>(Lal;Lml;)V

    .line 150
    .line 151
    .line 152
    :goto_97
    iget-object p2, v0, Lzw;->h:Ljava/lang/Object;

    .line 153
    .line 154
    iget v3, v0, Lzw;->i:I

    .line 155
    .line 156
    if-eqz v3, :cond_b6

    .line 157
    .line 158
    if-eq v3, v7, :cond_aa

    .line 159
    .line 160
    if-ne v3, v1, :cond_a5

    .line 161
    .line 162
    invoke-static {p2}, Lnb0;->t(Ljava/lang/Object;)V

    .line 163
    .line 164
    .line 165
    goto :goto_ee

    .line 166
    :cond_a5
    invoke-static {v2}, Lod;->p(Ljava/lang/String;)V

    .line 167
    .line 168
    .line 169
    move-object v4, v5

    .line 170
    goto :goto_ee

    .line 171
    :cond_aa
    iget-object p0, v0, Lzw;->m:Lyy0;

    .line 172
    .line 173
    iget-object p1, v0, Lzw;->l:Luw;

    .line 174
    .line 175
    iget-object v2, v0, Lzw;->k:Lal;

    .line 176
    .line 177
    :try_start_b0
    invoke-static {p2}, Lnb0;->t(Ljava/lang/Object;)V
    :try_end_b3
    .catchall {:try_start_b0 .. :try_end_b3} :catchall_b4

    .line 178
    .line 179
    .line 180
    goto :goto_d8

    .line 181
    :catchall_b4
    move-exception p1

    .line 182
    goto :goto_f5

    .line 183
    :cond_b6
    invoke-static {p2}, Lnb0;->t(Ljava/lang/Object;)V

    .line 184
    .line 185
    .line 186
    new-instance p2, Lyy0;

    .line 187
    .line 188
    iget-object v2, v0, Lnl;->f:Lsl;

    .line 189
    .line 190
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 191
    .line 192
    .line 193
    invoke-direct {p2, p1, v2}, Lyy0;-><init>(Luw;Lsl;)V

    .line 194
    .line 195
    .line 196
    :try_start_c3
    iget-object v2, p0, Lal;->f:Ljava/lang/Object;

    .line 197
    .line 198
    check-cast v2, Lbn;
    :try_end_c7
    .catchall {:try_start_c3 .. :try_end_c7} :catchall_f2

    .line 199
    .line 200
    :try_start_c7
    iput-object p0, v0, Lzw;->k:Lal;

    .line 201
    .line 202
    iput-object p1, v0, Lzw;->l:Luw;

    .line 203
    .line 204
    iput-object p2, v0, Lzw;->m:Lyy0;

    .line 205
    .line 206
    iput v7, v0, Lzw;->i:I

    .line 207
    .line 208
    invoke-virtual {v2, p2, v0}, Lbn;->f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 209
    .line 210
    .line 211
    move-result-object v2
    :try_end_d3
    .catchall {:try_start_c7 .. :try_end_d3} :catchall_ef

    .line 212
    if-ne v2, v6, :cond_d6

    .line 213
    .line 214
    goto :goto_ed

    .line 215
    :cond_d6
    move-object v2, p0

    .line 216
    move-object p0, p2

    .line 217
    :goto_d8
    invoke-virtual {p0}, Lnl;->q()V

    .line 218
    .line 219
    .line 220
    iget-object p0, v2, Lal;->g:Ljava/lang/Object;

    .line 221
    .line 222
    check-cast p0, Ltw;

    .line 223
    .line 224
    iput-object v5, v0, Lzw;->k:Lal;

    .line 225
    .line 226
    iput-object v5, v0, Lzw;->l:Luw;

    .line 227
    .line 228
    iput-object v5, v0, Lzw;->m:Lyy0;

    .line 229
    .line 230
    iput v1, v0, Lzw;->i:I

    .line 231
    .line 232
    invoke-interface {p0, p1, v0}, Ltw;->b(Luw;Lml;)Ljava/lang/Object;

    .line 233
    .line 234
    .line 235
    move-result-object p0

    .line 236
    if-ne p0, v6, :cond_ee

    .line 237
    .line 238
    :goto_ed
    move-object v4, v6

    .line 239
    :cond_ee
    :goto_ee
    return-object v4

    .line 240
    :catchall_ef
    move-exception p1

    .line 241
    :goto_f0
    move-object p0, p2

    .line 242
    goto :goto_f5

    .line 243
    :catchall_f2
    move-exception p0

    .line 244
    move-object p1, p0

    .line 245
    goto :goto_f0

    .line 246
    :goto_f5
    invoke-virtual {p0}, Lnl;->q()V

    .line 247
    .line 248
    .line 249
    throw p1

    .line 250
    nop

    .line 251
    :pswitch_data_fa
    .packed-switch 0x3
        :pswitch_81  #00000003
        :pswitch_67  #00000004
    .end packed-switch
.end method

.method public cancel()V
    .registers 3

    .line 1
    iget-object v0, p0, Lal;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lca;

    .line 4
    .line 5
    const/4 v1, 0x1

    .line 6
    invoke-virtual {v0, v1, v1}, Ljava/util/concurrent/atomic/AtomicInteger;->compareAndSet(II)Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    if-nez v0, :cond_12

    .line 11
    .line 12
    iget-object p0, p0, Lal;->f:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast p0, Lna;

    .line 15
    .line 16
    invoke-virtual {p0}, Lna;->a()Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    :cond_12
    return-void
.end method

.method public d(Ljava/lang/Integer;)Ljava/util/List;
    .registers 5

    .line 1
    iget-object v0, p0, Lal;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lyo0;

    .line 4
    .line 5
    const/4 v1, 0x0

    .line 6
    invoke-interface {v0, v1}, Lyo0;->d(Ljava/lang/Integer;)Ljava/util/List;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    iget-object p0, p0, Lal;->g:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast p0, La61;

    .line 13
    .line 14
    iget v1, p0, La61;->v:I

    .line 15
    .line 16
    if-gez v1, :cond_12

    .line 17
    .line 18
    return-object v0

    .line 19
    :cond_12
    iget-object v2, p0, La61;->b:[I

    .line 20
    .line 21
    invoke-virtual {p0, v2, v1}, La61;->E([II)I

    .line 22
    .line 23
    .line 24
    move-result v2

    .line 25
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 26
    .line 27
    .line 28
    move-result-object v2

    .line 29
    invoke-static {p0, p1, v1, v2}, Lwl1;->p(La61;Ljava/lang/Integer;ILjava/lang/Integer;)Ljava/util/List;

    .line 30
    .line 31
    .line 32
    move-result-object p0

    .line 33
    invoke-static {p0, v0}, Ltg;->Z(Ljava/util/Collection;Ljava/util/List;)Ljava/util/ArrayList;

    .line 34
    .line 35
    .line 36
    move-result-object p0

    .line 37
    return-object p0
.end method

.method public e(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 1
    iget-object p0, p0, Lal;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Li00;

    .line 4
    .line 5
    invoke-interface {p0, p1}, Li00;->i(Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    return-object p0
.end method

.method public f(Lh91;)V
    .registers 10

    .line 1
    iget-object v0, p0, Lal;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lzj0;

    .line 4
    .line 5
    invoke-virtual {v0}, Lzj0;->a()V

    .line 6
    .line 7
    .line 8
    iget-object v1, p1, Lh91;->f:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v1, Lbk0;

    .line 11
    .line 12
    iget-object v2, v1, Lbk0;->b:[Ljava/lang/Object;

    .line 13
    .line 14
    iget-object v3, v1, Lbk0;->c:[J

    .line 15
    .line 16
    iget v1, v1, Lbk0;->e:I

    .line 17
    .line 18
    :goto_11
    const v4, 0x7fffffff

    .line 19
    .line 20
    .line 21
    if-eq v1, v4, :cond_44

    .line 22
    .line 23
    aget-wide v4, v3, v1

    .line 24
    .line 25
    const/16 v6, 0x1f

    .line 26
    .line 27
    shr-long/2addr v4, v6

    .line 28
    const-wide/32 v6, 0x7fffffff

    .line 29
    .line 30
    .line 31
    and-long/2addr v4, v6

    .line 32
    long-to-int v4, v4

    .line 33
    aget-object v1, v2, v1

    .line 34
    .line 35
    iget-object v5, p0, Lal;->f:Ljava/lang/Object;

    .line 36
    .line 37
    check-cast v5, Lhb0;

    .line 38
    .line 39
    invoke-virtual {v5, v1}, Lhb0;->b(Ljava/lang/Object;)Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object v5

    .line 43
    invoke-virtual {v0, v5}, Lzj0;->d(Ljava/lang/Object;)I

    .line 44
    .line 45
    .line 46
    move-result v6

    .line 47
    if-ltz v6, :cond_35

    .line 48
    .line 49
    iget-object v7, v0, Lzj0;->c:[I

    .line 50
    .line 51
    aget v6, v7, v6

    .line 52
    .line 53
    goto :goto_36

    .line 54
    :cond_35
    const/4 v6, 0x0

    .line 55
    :goto_36
    const/4 v7, 0x7

    .line 56
    if-ne v6, v7, :cond_3d

    .line 57
    .line 58
    invoke-virtual {p1, v1}, Lh91;->remove(Ljava/lang/Object;)Z

    .line 59
    .line 60
    .line 61
    goto :goto_42

    .line 62
    :cond_3d
    add-int/lit8 v6, v6, 0x1

    .line 63
    .line 64
    invoke-virtual {v0, v6, v5}, Lzj0;->g(ILjava/lang/Object;)V

    .line 65
    .line 66
    .line 67
    :goto_42
    move v1, v4

    .line 68
    goto :goto_11

    .line 69
    :cond_44
    return-void
.end method

.method public g(Ljava/lang/CharSequence;IILfe1;)Z
    .registers 8

    .line 1
    iget v0, p4, Lfe1;->c:I

    .line 2
    .line 3
    and-int/lit8 v0, v0, 0x4

    .line 4
    .line 5
    const/4 v1, 0x1

    .line 6
    if-lez v0, :cond_8

    .line 7
    .line 8
    return v1

    .line 9
    :cond_8
    iget-object v0, p0, Lal;->f:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v0, Lbf1;

    .line 12
    .line 13
    if-nez v0, :cond_22

    .line 14
    .line 15
    new-instance v0, Lbf1;

    .line 16
    .line 17
    instance-of v2, p1, Landroid/text/Spannable;

    .line 18
    .line 19
    if-eqz v2, :cond_17

    .line 20
    .line 21
    check-cast p1, Landroid/text/Spannable;

    .line 22
    .line 23
    goto :goto_1d

    .line 24
    :cond_17
    new-instance v2, Landroid/text/SpannableString;

    .line 25
    .line 26
    invoke-direct {v2, p1}, Landroid/text/SpannableString;-><init>(Ljava/lang/CharSequence;)V

    .line 27
    .line 28
    .line 29
    move-object p1, v2

    .line 30
    :goto_1d
    invoke-direct {v0, p1}, Lbf1;-><init>(Landroid/text/Spannable;)V

    .line 31
    .line 32
    .line 33
    iput-object v0, p0, Lal;->f:Ljava/lang/Object;

    .line 34
    .line 35
    :cond_22
    iget-object p1, p0, Lal;->g:Ljava/lang/Object;

    .line 36
    .line 37
    check-cast p1, Lvj;

    .line 38
    .line 39
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 40
    .line 41
    .line 42
    new-instance p1, Lge1;

    .line 43
    .line 44
    invoke-direct {p1, p4}, Lge1;-><init>(Lfe1;)V

    .line 45
    .line 46
    .line 47
    iget-object p0, p0, Lal;->f:Ljava/lang/Object;

    .line 48
    .line 49
    check-cast p0, Lbf1;

    .line 50
    .line 51
    const/16 p4, 0x21

    .line 52
    .line 53
    invoke-virtual {p0, p1, p2, p3, p4}, Lbf1;->setSpan(Ljava/lang/Object;III)V

    .line 54
    .line 55
    .line 56
    return v1
.end method

.method public h()Z
    .registers 1

    .line 1
    iget-object p0, p0, Lal;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Lyo0;

    .line 4
    .line 5
    invoke-interface {p0}, Lyo0;->h()Z

    .line 6
    .line 7
    .line 8
    move-result p0

    .line 9
    return p0
.end method

.method public i(Ljava/lang/Object;Ljava/lang/Object;)Z
    .registers 3

    .line 1
    iget-object p0, p0, Lal;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Lhb0;

    .line 4
    .line 5
    invoke-virtual {p0, p1}, Lhb0;->b(Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    invoke-virtual {p0, p2}, Lhb0;->b(Ljava/lang/Object;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    invoke-static {p1, p0}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    move-result p0

    .line 17
    return p0
.end method

.method public j(Liz0;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 1
    iget-object p0, p0, Lal;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Lm00;

    .line 4
    .line 5
    invoke-interface {p0, p1, p2}, Lm00;->f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    return-object p0
.end method

.method public k(Ljava/lang/String;)Landroid/os/Bundle;
    .registers 5

    .line 1
    iget-object p0, p0, Lal;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Lwz0;

    .line 4
    .line 5
    iget-boolean v0, p0, Lwz0;->g:Z

    .line 6
    .line 7
    const/4 v1, 0x0

    .line 8
    if-eqz v0, :cond_26

    .line 9
    .line 10
    iget-object v0, p0, Lwz0;->f:Landroid/os/Bundle;

    .line 11
    .line 12
    if-nez v0, :cond_e

    .line 13
    .line 14
    return-object v1

    .line 15
    :cond_e
    invoke-virtual {v0, p1}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    .line 16
    .line 17
    .line 18
    move-result v2

    .line 19
    if-eqz v2, :cond_19

    .line 20
    .line 21
    invoke-static {v0, p1}, Lkb0;->n(Landroid/os/Bundle;Ljava/lang/String;)Landroid/os/Bundle;

    .line 22
    .line 23
    .line 24
    move-result-object v2

    .line 25
    goto :goto_1a

    .line 26
    :cond_19
    move-object v2, v1

    .line 27
    :goto_1a
    invoke-virtual {v0, p1}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    invoke-virtual {v0}, Landroid/os/BaseBundle;->isEmpty()Z

    .line 31
    .line 32
    .line 33
    move-result p1

    .line 34
    if-eqz p1, :cond_25

    .line 35
    .line 36
    iput-object v1, p0, Lwz0;->f:Landroid/os/Bundle;

    .line 37
    .line 38
    :cond_25
    return-object v2

    .line 39
    :cond_26
    const-string p0, "You can \'consumeRestoredStateForKey\' only after the corresponding component has moved to the \'CREATED\' state"

    .line 40
    .line 41
    invoke-static {p0}, Lod;->p(Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    return-object v1
.end method

.method public l()V
    .registers 7

    .line 1
    iget-object v0, p0, Lal;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lqk0;

    .line 4
    .line 5
    sget-object v1, Luy;->d:Luy;

    .line 6
    .line 7
    iget-object v2, v0, Lqk0;->e:[Ljava/lang/Object;

    .line 8
    .line 9
    iget v3, v0, Lqk0;->g:I

    .line 10
    .line 11
    const/4 v4, 0x0

    .line 12
    invoke-static {v2, v4, v3, v1}, Ljava/util/Arrays;->sort([Ljava/lang/Object;IILjava/util/Comparator;)V

    .line 13
    .line 14
    .line 15
    iget v1, v0, Lqk0;->g:I

    .line 16
    .line 17
    iget-object v2, p0, Lal;->g:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast v2, [Lba0;

    .line 20
    .line 21
    if-eqz v2, :cond_19

    .line 22
    .line 23
    array-length v3, v2

    .line 24
    if-ge v3, v1, :cond_21

    .line 25
    .line 26
    :cond_19
    const/16 v2, 0x10

    .line 27
    .line 28
    invoke-static {v2, v1}, Ljava/lang/Math;->max(II)I

    .line 29
    .line 30
    .line 31
    move-result v2

    .line 32
    new-array v2, v2, [Lba0;

    .line 33
    .line 34
    :cond_21
    const/4 v3, 0x0

    .line 35
    iput-object v3, p0, Lal;->g:Ljava/lang/Object;

    .line 36
    .line 37
    :goto_24
    if-ge v4, v1, :cond_2f

    .line 38
    .line 39
    iget-object v5, v0, Lqk0;->e:[Ljava/lang/Object;

    .line 40
    .line 41
    aget-object v5, v5, v4

    .line 42
    .line 43
    aput-object v5, v2, v4

    .line 44
    .line 45
    add-int/lit8 v4, v4, 0x1

    .line 46
    .line 47
    goto :goto_24

    .line 48
    :cond_2f
    invoke-virtual {v0}, Lqk0;->g()V

    .line 49
    .line 50
    .line 51
    add-int/lit8 v1, v1, -0x1

    .line 52
    .line 53
    :goto_34
    const/4 v0, -0x1

    .line 54
    if-ge v0, v1, :cond_48

    .line 55
    .line 56
    aget-object v0, v2, v1

    .line 57
    .line 58
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 59
    .line 60
    .line 61
    iget-boolean v4, v0, Lba0;->S:Z

    .line 62
    .line 63
    if-eqz v4, :cond_43

    .line 64
    .line 65
    invoke-static {v0}, Lal;->m(Lba0;)V

    .line 66
    .line 67
    .line 68
    :cond_43
    aput-object v3, v2, v1

    .line 69
    .line 70
    add-int/lit8 v1, v1, -0x1

    .line 71
    .line 72
    goto :goto_34

    .line 73
    :cond_48
    iput-object v2, p0, Lal;->g:Ljava/lang/Object;

    .line 74
    .line 75
    return-void
.end method

.method public n()Lmh0;
    .registers 1

    .line 1
    iget-object p0, p0, Lal;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Llq0;

    .line 4
    .line 5
    invoke-virtual {p0}, Llq0;->getValue()Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    check-cast p0, Lmh0;

    .line 10
    .line 11
    return-object p0
.end method

.method public o(Ljava/lang/String;)Lvz0;
    .registers 6

    .line 1
    iget-object p0, p0, Lal;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Lwz0;

    .line 4
    .line 5
    iget-object v0, p0, Lwz0;->c:Lav0;

    .line 6
    .line 7
    monitor-enter v0

    .line 8
    :try_start_7
    iget-object p0, p0, Lwz0;->d:Ljava/util/LinkedHashMap;

    .line 9
    .line 10
    invoke-virtual {p0}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    .line 11
    .line 12
    .line 13
    move-result-object p0

    .line 14
    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 15
    .line 16
    .line 17
    move-result-object p0

    .line 18
    :cond_11
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 19
    .line 20
    .line 21
    move-result v1

    .line 22
    const/4 v2, 0x0

    .line 23
    if-eqz v1, :cond_36

    .line 24
    .line 25
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object v1

    .line 29
    check-cast v1, Ljava/util/Map$Entry;

    .line 30
    .line 31
    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    move-result-object v3

    .line 35
    check-cast v3, Ljava/lang/String;

    .line 36
    .line 37
    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    move-result-object v1

    .line 41
    check-cast v1, Lvz0;

    .line 42
    .line 43
    invoke-static {v3, p1}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 44
    .line 45
    .line 46
    move-result v3
    :try_end_2e
    .catchall {:try_start_7 .. :try_end_2e} :catchall_34

    .line 47
    if-eqz v3, :cond_31

    .line 48
    .line 49
    move-object v2, v1

    .line 50
    :cond_31
    if-eqz v2, :cond_11

    .line 51
    .line 52
    goto :goto_36

    .line 53
    :catchall_34
    move-exception p0

    .line 54
    goto :goto_38

    .line 55
    :cond_36
    :goto_36
    monitor-exit v0

    .line 56
    return-object v2

    .line 57
    :goto_38
    monitor-exit v0

    .line 58
    throw p0
.end method

.method public p(J)Landroid/view/autofill/AutofillId;
    .registers 5

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 2
    .line 3
    const/16 v1, 0x1d

    .line 4
    .line 5
    if-lt v0, v1, :cond_22

    .line 6
    .line 7
    iget-object v0, p0, Lal;->f:Ljava/lang/Object;

    .line 8
    .line 9
    invoke-static {v0}, Ls3;->e(Ljava/lang/Object;)Landroid/view/contentcapture/ContentCaptureSession;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    iget-object p0, p0, Lal;->g:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast p0, Landroid/view/View;

    .line 16
    .line 17
    invoke-static {p0}, Lsb0;->m(Landroid/view/View;)Lk1;

    .line 18
    .line 19
    .line 20
    move-result-object p0

    .line 21
    invoke-static {p0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    iget-object p0, p0, Lk1;->a:Ljava/lang/Object;

    .line 25
    .line 26
    invoke-static {p0}, Lga;->d(Ljava/lang/Object;)Landroid/view/autofill/AutofillId;

    .line 27
    .line 28
    .line 29
    move-result-object p0

    .line 30
    invoke-static {v0, p0, p1, p2}, Lzk;->b(Landroid/view/contentcapture/ContentCaptureSession;Landroid/view/autofill/AutofillId;J)Landroid/view/autofill/AutofillId;

    .line 31
    .line 32
    .line 33
    move-result-object p0

    .line 34
    return-object p0

    .line 35
    :cond_22
    const/4 p0, 0x0

    .line 36
    return-object p0
.end method

.method public q(Landroid/os/Bundle;)V
    .registers 5

    .line 1
    iget-object p0, p0, Lal;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Lwz0;

    .line 4
    .line 5
    iget-object v0, p0, Lwz0;->a:Lxz0;

    .line 6
    .line 7
    iget-boolean v1, p0, Lwz0;->e:Z

    .line 8
    .line 9
    if-nez v1, :cond_d

    .line 10
    .line 11
    invoke-virtual {p0}, Lwz0;->a()V

    .line 12
    .line 13
    .line 14
    :cond_d
    invoke-interface {v0}, Lsd0;->g()Lud0;

    .line 15
    .line 16
    .line 17
    move-result-object v1

    .line 18
    iget-object v1, v1, Lud0;->d:Ljd0;

    .line 19
    .line 20
    sget-object v2, Ljd0;->h:Ljd0;

    .line 21
    .line 22
    invoke-virtual {v1, v2}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    .line 23
    .line 24
    .line 25
    move-result v1

    .line 26
    if-gez v1, :cond_3a

    .line 27
    .line 28
    iget-boolean v0, p0, Lwz0;->g:Z

    .line 29
    .line 30
    if-nez v0, :cond_34

    .line 31
    .line 32
    const/4 v0, 0x0

    .line 33
    if-eqz p1, :cond_2e

    .line 34
    .line 35
    const-string v1, "androidx.lifecycle.BundlableSavedStateRegistry.key"

    .line 36
    .line 37
    invoke-virtual {p1, v1}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    .line 38
    .line 39
    .line 40
    move-result v2

    .line 41
    if-eqz v2, :cond_2e

    .line 42
    .line 43
    invoke-static {p1, v1}, Lkb0;->n(Landroid/os/Bundle;Ljava/lang/String;)Landroid/os/Bundle;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    :cond_2e
    iput-object v0, p0, Lwz0;->f:Landroid/os/Bundle;

    .line 48
    .line 49
    const/4 p1, 0x1

    .line 50
    iput-boolean p1, p0, Lwz0;->g:Z

    .line 51
    .line 52
    return-void

    .line 53
    :cond_34
    const-string p0, "SavedStateRegistry was already restored."

    .line 54
    .line 55
    invoke-static {p0}, Lod;->p(Ljava/lang/String;)V

    .line 56
    .line 57
    .line 58
    return-void

    .line 59
    :cond_3a
    invoke-interface {v0}, Lsd0;->g()Lud0;

    .line 60
    .line 61
    .line 62
    move-result-object p0

    .line 63
    iget-object p0, p0, Lud0;->d:Ljd0;

    .line 64
    .line 65
    new-instance p1, Ljava/lang/StringBuilder;

    .line 66
    .line 67
    const-string v0, "performRestore cannot be called when owner is "

    .line 68
    .line 69
    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 70
    .line 71
    .line 72
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 73
    .line 74
    .line 75
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 76
    .line 77
    .line 78
    move-result-object p0

    .line 79
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 80
    .line 81
    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 82
    .line 83
    .line 84
    move-result-object p0

    .line 85
    invoke-direct {p1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 86
    .line 87
    .line 88
    throw p1
.end method

.method public r(Landroid/os/Bundle;)V
    .registers 6

    .line 1
    iget-object p0, p0, Lal;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Lwz0;

    .line 4
    .line 5
    const/4 v0, 0x0

    .line 6
    new-array v1, v0, [Lzp0;

    .line 7
    .line 8
    invoke-static {v1, v0}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    check-cast v0, [Lzp0;

    .line 13
    .line 14
    invoke-static {v0}, La5;->j([Lzp0;)Landroid/os/Bundle;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    iget-object v1, p0, Lwz0;->f:Landroid/os/Bundle;

    .line 19
    .line 20
    if-eqz v1, :cond_18

    .line 21
    .line 22
    invoke-virtual {v0, v1}, Landroid/os/Bundle;->putAll(Landroid/os/Bundle;)V

    .line 23
    .line 24
    .line 25
    :cond_18
    iget-object v1, p0, Lwz0;->c:Lav0;

    .line 26
    .line 27
    monitor-enter v1

    .line 28
    :try_start_1b
    iget-object p0, p0, Lwz0;->d:Ljava/util/LinkedHashMap;

    .line 29
    .line 30
    invoke-virtual {p0}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    .line 31
    .line 32
    .line 33
    move-result-object p0

    .line 34
    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 35
    .line 36
    .line 37
    move-result-object p0

    .line 38
    :goto_25
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 39
    .line 40
    .line 41
    move-result v2

    .line 42
    if-eqz v2, :cond_4a

    .line 43
    .line 44
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    move-result-object v2

    .line 48
    check-cast v2, Ljava/util/Map$Entry;

    .line 49
    .line 50
    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object v3

    .line 54
    check-cast v3, Ljava/lang/String;

    .line 55
    .line 56
    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 57
    .line 58
    .line 59
    move-result-object v2

    .line 60
    check-cast v2, Lvz0;

    .line 61
    .line 62
    invoke-interface {v2}, Lvz0;->a()Landroid/os/Bundle;

    .line 63
    .line 64
    .line 65
    move-result-object v2

    .line 66
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 67
    .line 68
    .line 69
    invoke-virtual {v0, v3, v2}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V
    :try_end_47
    .catchall {:try_start_1b .. :try_end_47} :catchall_48

    .line 70
    .line 71
    .line 72
    goto :goto_25

    .line 73
    :catchall_48
    move-exception p0

    .line 74
    goto :goto_57

    .line 75
    :cond_4a
    monitor-exit v1

    .line 76
    invoke-virtual {v0}, Landroid/os/BaseBundle;->isEmpty()Z

    .line 77
    .line 78
    .line 79
    move-result p0

    .line 80
    if-nez p0, :cond_56

    .line 81
    .line 82
    const-string p0, "androidx.lifecycle.BundlableSavedStateRegistry.key"

    .line 83
    .line 84
    invoke-virtual {p1, p0, v0}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    .line 85
    .line 86
    .line 87
    :cond_56
    return-void

    .line 88
    :goto_57
    monitor-exit v1

    .line 89
    throw p0
.end method

.method public s(Ljava/lang/String;Lvz0;)V
    .registers 5

    .line 1
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget-object p0, p0, Lal;->f:Ljava/lang/Object;

    .line 5
    .line 6
    check-cast p0, Lwz0;

    .line 7
    .line 8
    iget-object v0, p0, Lwz0;->c:Lav0;

    .line 9
    .line 10
    monitor-enter v0

    .line 11
    :try_start_a
    iget-object v1, p0, Lwz0;->d:Ljava/util/LinkedHashMap;

    .line 12
    .line 13
    invoke-interface {v1, p1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    move-result v1

    .line 17
    if-nez v1, :cond_1b

    .line 18
    .line 19
    iget-object p0, p0, Lwz0;->d:Ljava/util/LinkedHashMap;

    .line 20
    .line 21
    invoke-interface {p0, p1, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_17
    .catchall {:try_start_a .. :try_end_17} :catchall_19

    .line 22
    .line 23
    .line 24
    monitor-exit v0

    .line 25
    return-void

    .line 26
    :catchall_19
    move-exception p0

    .line 27
    goto :goto_23

    .line 28
    :cond_1b
    :try_start_1b
    const-string p0, "SavedStateProvider with the given key is already registered"

    .line 29
    .line 30
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 31
    .line 32
    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    throw p1
    :try_end_23
    .catchall {:try_start_1b .. :try_end_23} :catchall_19

    .line 36
    :goto_23
    monitor-exit v0

    .line 37
    throw p0
.end method

.method public t()V
    .registers 5

    .line 1
    const-class v0, Lcd0;

    .line 2
    .line 3
    iget-object v1, p0, Lal;->f:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v1, Lwz0;

    .line 6
    .line 7
    iget-boolean v1, v1, Lwz0;->h:Z

    .line 8
    .line 9
    if-eqz v1, :cond_49

    .line 10
    .line 11
    iget-object v1, p0, Lal;->g:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v1, Lew0;

    .line 14
    .line 15
    if-nez v1, :cond_15

    .line 16
    .line 17
    new-instance v1, Lew0;

    .line 18
    .line 19
    invoke-direct {v1, p0}, Lew0;-><init>(Lal;)V

    .line 20
    .line 21
    .line 22
    :cond_15
    iput-object v1, p0, Lal;->g:Ljava/lang/Object;

    .line 23
    .line 24
    const/4 v1, 0x0

    .line 25
    :try_start_18
    invoke-virtual {v0, v1}, Ljava/lang/Class;->getDeclaredConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;
    :try_end_1b
    .catch Ljava/lang/NoSuchMethodException; {:try_start_18 .. :try_end_1b} :catch_2b

    .line 26
    .line 27
    .line 28
    iget-object p0, p0, Lal;->g:Ljava/lang/Object;

    .line 29
    .line 30
    check-cast p0, Lew0;

    .line 31
    .line 32
    if-eqz p0, :cond_2a

    .line 33
    .line 34
    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    iget-object p0, p0, Lew0;->a:Ljava/util/LinkedHashSet;

    .line 39
    .line 40
    invoke-interface {p0, v0}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 41
    .line 42
    .line 43
    :cond_2a
    return-void

    .line 44
    :catch_2b
    move-exception p0

    .line 45
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 46
    .line 47
    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    new-instance v2, Ljava/lang/StringBuilder;

    .line 52
    .line 53
    const-string v3, "Class "

    .line 54
    .line 55
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 56
    .line 57
    .line 58
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 59
    .line 60
    .line 61
    const-string v0, " must have default constructor in order to be automatically recreated"

    .line 62
    .line 63
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 64
    .line 65
    .line 66
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 67
    .line 68
    .line 69
    move-result-object v0

    .line 70
    invoke-direct {v1, v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 71
    .line 72
    .line 73
    throw v1

    .line 74
    :cond_49
    const-string p0, "Can not perform this action after onSaveInstanceState"

    .line 75
    .line 76
    invoke-static {p0}, Lod;->p(Ljava/lang/String;)V

    .line 77
    .line 78
    .line 79
    return-void
.end method

.method public toString()Ljava/lang/String;
    .registers 3

    .line 1
    iget v0, p0, Lal;->e:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_2e

    .line 4
    .line 5
    .line 6
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    return-object p0

    .line 11
    :pswitch_a  #0x19
    new-instance v0, Ljava/lang/StringBuilder;

    .line 12
    .line 13
    const-string v1, "Bounds{lower="

    .line 14
    .line 15
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    iget-object v1, p0, Lal;->f:Ljava/lang/Object;

    .line 19
    .line 20
    check-cast v1, Lc60;

    .line 21
    .line 22
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 23
    .line 24
    .line 25
    const-string v1, " upper="

    .line 26
    .line 27
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 28
    .line 29
    .line 30
    iget-object p0, p0, Lal;->g:Ljava/lang/Object;

    .line 31
    .line 32
    check-cast p0, Lc60;

    .line 33
    .line 34
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 35
    .line 36
    .line 37
    const-string p0, "}"

    .line 38
    .line 39
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 40
    .line 41
    .line 42
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 43
    .line 44
    .line 45
    move-result-object p0

    .line 46
    return-object p0

    .line 47
    :pswitch_data_2e
    .packed-switch 0x19
        :pswitch_a  #00000019
    .end packed-switch
.end method
