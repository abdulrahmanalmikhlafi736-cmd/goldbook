.class public final Law;
.super Lks0;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# instance fields
.field public final synthetic j:I


# direct methods
.method public constructor <init>(III)V
    .registers 8

    .line 1
    iput p3, p0, Law;->j:I

    .line 2
    .line 3
    packed-switch p3, :pswitch_data_2c

    .line 4
    .line 5
    .line 6
    invoke-direct {p0}, Lks0;-><init>()V

    .line 7
    .line 8
    .line 9
    int-to-long v0, p1

    .line 10
    const/16 p1, 0x20

    .line 11
    .line 12
    shl-long/2addr v0, p1

    .line 13
    int-to-long p1, p2

    .line 14
    const-wide v2, 0xffffffffL

    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    and-long/2addr p1, v2

    .line 20
    or-long/2addr p1, v0

    .line 21
    invoke-virtual {p0, p1, p2}, Lks0;->S(J)V

    .line 22
    .line 23
    .line 24
    return-void

    .line 25
    :pswitch_18  #0x1
    invoke-direct {p0}, Lks0;-><init>()V

    .line 26
    .line 27
    .line 28
    int-to-long v0, p1

    .line 29
    const/16 p1, 0x20

    .line 30
    .line 31
    shl-long/2addr v0, p1

    .line 32
    int-to-long p1, p2

    .line 33
    const-wide v2, 0xffffffffL

    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    and-long/2addr p1, v2

    .line 39
    or-long/2addr p1, v0

    .line 40
    invoke-virtual {p0, p1, p2}, Lks0;->S(J)V

    .line 41
    .line 42
    .line 43
    return-void

    .line 44
    nop

    .line 45
    :pswitch_data_2c
    .packed-switch 0x1
        :pswitch_18  #00000001
    .end packed-switch
.end method

.method private final U(JFLi00;)V
    .registers 5

    .line 1
    return-void
.end method

.method private final W(JFLi00;)V
    .registers 5

    .line 1
    return-void
.end method


# virtual methods
.method public final R(JFLi00;)V
    .registers 5

    .line 1
    iget p0, p0, Law;->j:I

    .line 2
    .line 3
    return-void
.end method
