.class public abstract Laf;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lx00;


# instance fields
.field public final e:Lsl;

.field public final f:I

.field public final g:Lgd;

.field public final h:Ltw;


# direct methods
.method public constructor <init>(Ltw;Lsl;ILgd;)V
    .registers 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p2, p0, Laf;->e:Lsl;

    .line 5
    .line 6
    iput p3, p0, Laf;->f:I

    .line 7
    .line 8
    iput-object p4, p0, Laf;->g:Lgd;

    .line 9
    .line 10
    iput-object p1, p0, Laf;->h:Ltw;

    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public abstract a(Lsl;ILgd;)Laf;
.end method

.method public final b(Luw;Lml;)Ljava/lang/Object;
    .registers 10

    .line 1
    iget v0, p0, Laf;->f:I

    .line 2
    .line 3
    const/4 v1, -0x3

    .line 4
    const/4 v2, 0x0

    .line 5
    sget-object v3, Lcm;->e:Lcm;

    .line 6
    .line 7
    sget-object v4, Lwe1;->a:Lwe1;

    .line 8
    .line 9
    if-ne v0, v1, :cond_70

    .line 10
    .line 11
    invoke-interface {p2}, Lml;->e()Lsl;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 16
    .line 17
    new-instance v5, Lo9;

    .line 18
    .line 19
    const/16 v6, 0xe

    .line 20
    .line 21
    invoke-direct {v5, v6}, Lo9;-><init>(I)V

    .line 22
    .line 23
    .line 24
    iget-object v6, p0, Laf;->e:Lsl;

    .line 25
    .line 26
    invoke-interface {v6, v5, v1}, Lsl;->p(Lm00;Ljava/lang/Object;)Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    check-cast v1, Ljava/lang/Boolean;

    .line 31
    .line 32
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 33
    .line 34
    .line 35
    move-result v1

    .line 36
    if-nez v1, :cond_2a

    .line 37
    .line 38
    invoke-interface {v0, v6}, Lsl;->i(Lsl;)Lsl;

    .line 39
    .line 40
    .line 41
    move-result-object v1

    .line 42
    goto :goto_2f

    .line 43
    :cond_2a
    const/4 v1, 0x0

    .line 44
    invoke-static {v0, v6, v1}, Lj70;->D(Lsl;Lsl;Z)Lsl;

    .line 45
    .line 46
    .line 47
    move-result-object v1

    .line 48
    :goto_2f
    invoke-static {v1, v0}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 49
    .line 50
    .line 51
    move-result v5

    .line 52
    if-eqz v5, :cond_3c

    .line 53
    .line 54
    invoke-virtual {p0, p1, p2}, Laf;->e(Luw;Lml;)Ljava/lang/Object;

    .line 55
    .line 56
    .line 57
    move-result-object p0

    .line 58
    if-ne p0, v3, :cond_81

    .line 59
    .line 60
    return-object p0

    .line 61
    :cond_3c
    sget-object v5, Le3;->B:Le3;

    .line 62
    .line 63
    invoke-interface {v1, v5}, Lsl;->k(Lrl;)Lql;

    .line 64
    .line 65
    .line 66
    move-result-object v6

    .line 67
    invoke-interface {v0, v5}, Lsl;->k(Lrl;)Lql;

    .line 68
    .line 69
    .line 70
    move-result-object v0

    .line 71
    invoke-static {v6, v0}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 72
    .line 73
    .line 74
    move-result v0

    .line 75
    if-eqz v0, :cond_70

    .line 76
    .line 77
    invoke-interface {p2}, Lml;->e()Lsl;

    .line 78
    .line 79
    .line 80
    move-result-object v0

    .line 81
    instance-of v5, p1, La31;

    .line 82
    .line 83
    if-nez v5, :cond_5f

    .line 84
    .line 85
    instance-of v5, p1, Lom0;

    .line 86
    .line 87
    if-eqz v5, :cond_59

    .line 88
    .line 89
    goto :goto_5f

    .line 90
    :cond_59
    new-instance v5, Lg8;

    .line 91
    .line 92
    invoke-direct {v5, p1, v0}, Lg8;-><init>(Luw;Lsl;)V

    .line 93
    .line 94
    .line 95
    move-object p1, v5

    .line 96
    :cond_5f
    :goto_5f
    new-instance v0, Lze;

    .line 97
    .line 98
    const/4 v5, 0x1

    .line 99
    invoke-direct {v0, p0, v2, v5}, Lze;-><init>(Laf;Lml;I)V

    .line 100
    .line 101
    .line 102
    invoke-static {v1}, Lgh0;->U(Lsl;)Ljava/lang/Object;

    .line 103
    .line 104
    .line 105
    move-result-object p0

    .line 106
    invoke-static {v1, p1, p0, v0, p2}, Lzi1;->L(Lsl;Ljava/lang/Object;Ljava/lang/Object;Lm00;Lml;)Ljava/lang/Object;

    .line 107
    .line 108
    .line 109
    move-result-object p0

    .line 110
    if-ne p0, v3, :cond_81

    .line 111
    .line 112
    return-object p0

    .line 113
    :cond_70
    new-instance v0, Lf;

    .line 114
    .line 115
    const/4 v1, 0x3

    .line 116
    invoke-direct {v0, p1, p0, v2, v1}, Lf;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lml;I)V

    .line 117
    .line 118
    .line 119
    invoke-static {v0, p2}, Lvd1;->i(Lm00;Lml;)Ljava/lang/Object;

    .line 120
    .line 121
    .line 122
    move-result-object p0

    .line 123
    if-ne p0, v3, :cond_7d

    .line 124
    .line 125
    goto :goto_7e

    .line 126
    :cond_7d
    move-object p0, v4

    .line 127
    :goto_7e
    if-ne p0, v3, :cond_81

    .line 128
    .line 129
    return-object p0

    .line 130
    :cond_81
    return-object v4
.end method

.method public final c(Lsl;ILgd;)Ltw;
    .registers 8

    .line 1
    iget-object v0, p0, Laf;->e:Lsl;

    .line 2
    .line 3
    invoke-interface {p1, v0}, Lsl;->i(Lsl;)Lsl;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    sget-object v1, Lgd;->e:Lgd;

    .line 8
    .line 9
    iget-object v2, p0, Laf;->g:Lgd;

    .line 10
    .line 11
    iget v3, p0, Laf;->f:I

    .line 12
    .line 13
    if-eq p3, v1, :cond_f

    .line 14
    .line 15
    goto :goto_26

    .line 16
    :cond_f
    const/4 p3, -0x3

    .line 17
    if-ne v3, p3, :cond_13

    .line 18
    .line 19
    goto :goto_25

    .line 20
    :cond_13
    if-ne p2, p3, :cond_17

    .line 21
    .line 22
    :goto_15
    move p2, v3

    .line 23
    goto :goto_25

    .line 24
    :cond_17
    const/4 p3, -0x2

    .line 25
    if-ne v3, p3, :cond_1b

    .line 26
    .line 27
    goto :goto_25

    .line 28
    :cond_1b
    if-ne p2, p3, :cond_1e

    .line 29
    .line 30
    goto :goto_15

    .line 31
    :cond_1e
    add-int/2addr p2, v3

    .line 32
    if-ltz p2, :cond_22

    .line 33
    .line 34
    goto :goto_25

    .line 35
    :cond_22
    const p2, 0x7fffffff

    .line 36
    .line 37
    .line 38
    :goto_25
    move-object p3, v2

    .line 39
    :goto_26
    invoke-static {p1, v0}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 40
    .line 41
    .line 42
    move-result v0

    .line 43
    if-eqz v0, :cond_31

    .line 44
    .line 45
    if-ne p2, v3, :cond_31

    .line 46
    .line 47
    if-ne p3, v2, :cond_31

    .line 48
    .line 49
    return-object p0

    .line 50
    :cond_31
    invoke-virtual {p0, p1, p2, p3}, Laf;->a(Lsl;ILgd;)Laf;

    .line 51
    .line 52
    .line 53
    move-result-object p0

    .line 54
    return-object p0
.end method

.method public d()Ltw;
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return-object p0
.end method

.method public abstract e(Luw;Lml;)Ljava/lang/Object;
.end method

.method public final f()Ljava/lang/String;
    .registers 8

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    .line 2
    .line 3
    const/4 v1, 0x4

    .line 4
    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 5
    .line 6
    .line 7
    sget-object v1, Lst;->e:Lst;

    .line 8
    .line 9
    iget-object v2, p0, Laf;->e:Lsl;

    .line 10
    .line 11
    if-eq v2, v1, :cond_1d

    .line 12
    .line 13
    new-instance v1, Ljava/lang/StringBuilder;

    .line 14
    .line 15
    const-string v3, "context="

    .line 16
    .line 17
    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 21
    .line 22
    .line 23
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 24
    .line 25
    .line 26
    move-result-object v1

    .line 27
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 28
    .line 29
    .line 30
    :cond_1d
    const/4 v1, -0x3

    .line 31
    iget v2, p0, Laf;->f:I

    .line 32
    .line 33
    if-eq v2, v1, :cond_33

    .line 34
    .line 35
    new-instance v1, Ljava/lang/StringBuilder;

    .line 36
    .line 37
    const-string v3, "capacity="

    .line 38
    .line 39
    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 40
    .line 41
    .line 42
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 43
    .line 44
    .line 45
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 46
    .line 47
    .line 48
    move-result-object v1

    .line 49
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 50
    .line 51
    .line 52
    :cond_33
    sget-object v1, Lgd;->e:Lgd;

    .line 53
    .line 54
    iget-object v2, p0, Laf;->g:Lgd;

    .line 55
    .line 56
    if-eq v2, v1, :cond_4a

    .line 57
    .line 58
    new-instance v1, Ljava/lang/StringBuilder;

    .line 59
    .line 60
    const-string v3, "onBufferOverflow="

    .line 61
    .line 62
    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 63
    .line 64
    .line 65
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 66
    .line 67
    .line 68
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 69
    .line 70
    .line 71
    move-result-object v1

    .line 72
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 73
    .line 74
    .line 75
    :cond_4a
    new-instance v6, Ljava/lang/StringBuilder;

    .line 76
    .line 77
    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    .line 78
    .line 79
    .line 80
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 81
    .line 82
    .line 83
    move-result-object p0

    .line 84
    invoke-virtual {p0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 85
    .line 86
    .line 87
    move-result-object p0

    .line 88
    invoke-virtual {v6, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 89
    .line 90
    .line 91
    const/16 p0, 0x5b

    .line 92
    .line 93
    invoke-virtual {v6, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 94
    .line 95
    .line 96
    const/4 v4, 0x0

    .line 97
    const/16 v5, 0x3e

    .line 98
    .line 99
    const-string v1, ", "

    .line 100
    .line 101
    const/4 v2, 0x0

    .line 102
    const/4 v3, 0x0

    .line 103
    invoke-static/range {v0 .. v5}, Ltg;->V(Ljava/lang/Iterable;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Li00;I)Ljava/lang/String;

    .line 104
    .line 105
    .line 106
    move-result-object p0

    .line 107
    invoke-virtual {v6, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 108
    .line 109
    .line 110
    const/16 p0, 0x5d

    .line 111
    .line 112
    invoke-virtual {v6, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 113
    .line 114
    .line 115
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 116
    .line 117
    .line 118
    move-result-object p0

    .line 119
    return-object p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 4
    .line 5
    .line 6
    iget-object v1, p0, Laf;->h:Ltw;

    .line 7
    .line 8
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 9
    .line 10
    .line 11
    const-string v1, " -> "

    .line 12
    .line 13
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 14
    .line 15
    .line 16
    invoke-virtual {p0}, Laf;->f()Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object p0

    .line 20
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 21
    .line 22
    .line 23
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 24
    .line 25
    .line 26
    move-result-object p0

    .line 27
    return-object p0
.end method
