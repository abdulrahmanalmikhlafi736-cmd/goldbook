.class public final Ldw0;
.super Lsj;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# static fields
.field public static final A:Ljava/util/concurrent/atomic/AtomicReference;

.field public static final z:Ld81;


# instance fields
.field public final a:Lg7;

.field public final b:Lk9;

.field public final c:Ljava/lang/Object;

.field public d:La80;

.field public e:Ljava/lang/Throwable;

.field public final f:Ljava/util/ArrayList;

.field public g:Ljava/util/List;

.field public h:Lik0;

.field public final i:Lqk0;

.field public final j:Ljava/util/ArrayList;

.field public final k:Ljava/util/ArrayList;

.field public final l:Lhk0;

.field public final m:Lal;

.field public final n:Lhk0;

.field public final o:Lhk0;

.field public p:Ljava/util/ArrayList;

.field public q:Lik0;

.field public r:Lne;

.field public final s:Ld81;

.field public t:Z

.field public final u:Ld81;

.field public final v:Lk9;

.field public final w:Lc80;

.field public final x:Lsl;

.field public final y:Lav0;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    sget-object v0, Lcs0;->h:Lcs0;

    .line 2
    .line 3
    invoke-static {v0}, Lac;->c(Ljava/lang/Object;)Ld81;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    sput-object v0, Ldw0;->z:Ld81;

    .line 8
    .line 9
    new-instance v0, Ljava/util/concurrent/atomic/AtomicReference;

    .line 10
    .line 11
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 12
    .line 13
    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicReference;-><init>(Ljava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    sput-object v0, Ldw0;->A:Ljava/util/concurrent/atomic/AtomicReference;

    .line 17
    .line 18
    return-void
.end method

.method public constructor <init>(Lsl;)V
    .registers 6

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Lg7;

    .line 5
    .line 6
    new-instance v1, Lyv0;

    .line 7
    .line 8
    const/4 v2, 0x0

    .line 9
    invoke-direct {v1, p0, v2}, Lyv0;-><init>(Ldw0;I)V

    .line 10
    .line 11
    .line 12
    invoke-direct {v0, v1}, Lg7;-><init>(Lyv0;)V

    .line 13
    .line 14
    .line 15
    iput-object v0, p0, Ldw0;->a:Lg7;

    .line 16
    .line 17
    new-instance v1, Lk9;

    .line 18
    .line 19
    new-instance v2, Lyv0;

    .line 20
    .line 21
    const/4 v3, 0x1

    .line 22
    invoke-direct {v2, p0, v3}, Lyv0;-><init>(Ldw0;I)V

    .line 23
    .line 24
    .line 25
    invoke-direct {v1, v2}, Lk9;-><init>(Lyv0;)V

    .line 26
    .line 27
    .line 28
    iput-object v1, p0, Ldw0;->b:Lk9;

    .line 29
    .line 30
    new-instance v1, Ljava/lang/Object;

    .line 31
    .line 32
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 33
    .line 34
    .line 35
    iput-object v1, p0, Ldw0;->c:Ljava/lang/Object;

    .line 36
    .line 37
    new-instance v1, Ljava/util/ArrayList;

    .line 38
    .line 39
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 40
    .line 41
    .line 42
    iput-object v1, p0, Ldw0;->f:Ljava/util/ArrayList;

    .line 43
    .line 44
    new-instance v1, Lik0;

    .line 45
    .line 46
    invoke-direct {v1}, Lik0;-><init>()V

    .line 47
    .line 48
    .line 49
    iput-object v1, p0, Ldw0;->h:Lik0;

    .line 50
    .line 51
    new-instance v1, Lqk0;

    .line 52
    .line 53
    const/16 v2, 0x10

    .line 54
    .line 55
    new-array v2, v2, [Lyj;

    .line 56
    .line 57
    invoke-direct {v1, v2}, Lqk0;-><init>([Ljava/lang/Object;)V

    .line 58
    .line 59
    .line 60
    iput-object v1, p0, Ldw0;->i:Lqk0;

    .line 61
    .line 62
    new-instance v1, Ljava/util/ArrayList;

    .line 63
    .line 64
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 65
    .line 66
    .line 67
    iput-object v1, p0, Ldw0;->j:Ljava/util/ArrayList;

    .line 68
    .line 69
    new-instance v1, Ljava/util/ArrayList;

    .line 70
    .line 71
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 72
    .line 73
    .line 74
    iput-object v1, p0, Ldw0;->k:Ljava/util/ArrayList;

    .line 75
    .line 76
    new-instance v1, Lhk0;

    .line 77
    .line 78
    invoke-direct {v1}, Lhk0;-><init>()V

    .line 79
    .line 80
    .line 81
    iput-object v1, p0, Ldw0;->l:Lhk0;

    .line 82
    .line 83
    new-instance v1, Lal;

    .line 84
    .line 85
    const/16 v2, 0xd

    .line 86
    .line 87
    invoke-direct {v1, v2}, Lal;-><init>(I)V

    .line 88
    .line 89
    .line 90
    iput-object v1, p0, Ldw0;->m:Lal;

    .line 91
    .line 92
    new-instance v1, Lhk0;

    .line 93
    .line 94
    invoke-direct {v1}, Lhk0;-><init>()V

    .line 95
    .line 96
    .line 97
    iput-object v1, p0, Ldw0;->n:Lhk0;

    .line 98
    .line 99
    new-instance v1, Lhk0;

    .line 100
    .line 101
    invoke-direct {v1}, Lhk0;-><init>()V

    .line 102
    .line 103
    .line 104
    iput-object v1, p0, Ldw0;->o:Lhk0;

    .line 105
    .line 106
    const/4 v1, 0x0

    .line 107
    invoke-static {v1}, Lac;->c(Ljava/lang/Object;)Ld81;

    .line 108
    .line 109
    .line 110
    move-result-object v1

    .line 111
    iput-object v1, p0, Ldw0;->s:Ld81;

    .line 112
    .line 113
    sget-object v1, Law0;->g:Law0;

    .line 114
    .line 115
    invoke-static {v1}, Lac;->c(Ljava/lang/Object;)Ld81;

    .line 116
    .line 117
    .line 118
    move-result-object v1

    .line 119
    iput-object v1, p0, Ldw0;->u:Ld81;

    .line 120
    .line 121
    new-instance v1, Lk9;

    .line 122
    .line 123
    const/16 v2, 0xb

    .line 124
    .line 125
    invoke-direct {v1, v2}, Lk9;-><init>(I)V

    .line 126
    .line 127
    .line 128
    iput-object v1, p0, Ldw0;->v:Lk9;

    .line 129
    .line 130
    sget-object v1, Le3;->S:Le3;

    .line 131
    .line 132
    invoke-interface {p1, v1}, Lsl;->k(Lrl;)Lql;

    .line 133
    .line 134
    .line 135
    move-result-object v1

    .line 136
    check-cast v1, La80;

    .line 137
    .line 138
    new-instance v2, Lc80;

    .line 139
    .line 140
    invoke-direct {v2, v1}, Lc80;-><init>(La80;)V

    .line 141
    .line 142
    .line 143
    new-instance v1, Ll;

    .line 144
    .line 145
    const/16 v3, 0x11

    .line 146
    .line 147
    invoke-direct {v1, v3, p0}, Ll;-><init>(ILjava/lang/Object;)V

    .line 148
    .line 149
    .line 150
    invoke-virtual {v2, v1}, Lh80;->r(Li00;)Lsq;

    .line 151
    .line 152
    .line 153
    iput-object v2, p0, Ldw0;->w:Lc80;

    .line 154
    .line 155
    invoke-interface {p1, v0}, Lsl;->i(Lsl;)Lsl;

    .line 156
    .line 157
    .line 158
    move-result-object p1

    .line 159
    invoke-interface {p1, v2}, Lsl;->i(Lsl;)Lsl;

    .line 160
    .line 161
    .line 162
    move-result-object p1

    .line 163
    iput-object p1, p0, Ldw0;->x:Lsl;

    .line 164
    .line 165
    new-instance p1, Lav0;

    .line 166
    .line 167
    const/4 v0, 0x5

    .line 168
    invoke-direct {p1, v0}, Lav0;-><init>(I)V

    .line 169
    .line 170
    .line 171
    iput-object p1, p0, Ldw0;->y:Lav0;

    .line 172
    .line 173
    return-void
.end method

.method public static final A(Ldw0;La80;)V
    .registers 5

    .line 1
    iget-object v0, p0, Ldw0;->c:Ljava/lang/Object;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    :try_start_3
    iget-object v1, p0, Ldw0;->e:Ljava/lang/Throwable;

    .line 5
    .line 6
    if-nez v1, :cond_3d

    .line 7
    .line 8
    iget-object v1, p0, Ldw0;->u:Ld81;

    .line 9
    .line 10
    invoke-virtual {v1}, Ld81;->getValue()Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    check-cast v1, Law0;

    .line 15
    .line 16
    sget-object v2, Law0;->f:Law0;

    .line 17
    .line 18
    invoke-virtual {v1, v2}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    .line 19
    .line 20
    .line 21
    move-result v1

    .line 22
    if-lez v1, :cond_35

    .line 23
    .line 24
    iget-object v1, p0, Ldw0;->d:La80;

    .line 25
    .line 26
    if-nez v1, :cond_2d

    .line 27
    .line 28
    iput-object p1, p0, Ldw0;->d:La80;

    .line 29
    .line 30
    invoke-virtual {p0}, Ldw0;->D()Lle;

    .line 31
    .line 32
    .line 33
    move-result-object p0

    .line 34
    if-eqz p0, :cond_2b

    .line 35
    .line 36
    const-string p0, "called outside of runRecomposeAndApplyChanges"

    .line 37
    .line 38
    invoke-static {p0}, Lqj;->a(Ljava/lang/String;)V
    :try_end_28
    .catchall {:try_start_3 .. :try_end_28} :catchall_29

    .line 39
    .line 40
    .line 41
    goto :goto_2b

    .line 42
    :catchall_29
    move-exception p0

    .line 43
    goto :goto_3e

    .line 44
    :cond_2b
    :goto_2b
    monitor-exit v0

    .line 45
    return-void

    .line 46
    :cond_2d
    :try_start_2d
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 47
    .line 48
    const-string p1, "Recomposer already running"

    .line 49
    .line 50
    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 51
    .line 52
    .line 53
    throw p0

    .line 54
    :cond_35
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 55
    .line 56
    const-string p1, "Recomposer shut down"

    .line 57
    .line 58
    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 59
    .line 60
    .line 61
    throw p0

    .line 62
    :cond_3d
    throw v1
    :try_end_3e
    .catchall {:try_start_2d .. :try_end_3e} :catchall_29

    .line 63
    :goto_3e
    monitor-exit v0

    .line 64
    throw p0
.end method

.method public static B(Llk0;)V
    .registers 3

    .line 1
    :try_start_0
    invoke-virtual {p0}, Llk0;->w()Lnb0;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    instance-of v0, v0, Li61;
    :try_end_6
    .catchall {:try_start_0 .. :try_end_6} :catchall_14

    .line 6
    .line 7
    if-nez v0, :cond_c

    .line 8
    .line 9
    invoke-virtual {p0}, Llk0;->c()V

    .line 10
    .line 11
    .line 12
    return-void

    .line 13
    :cond_c
    :try_start_c
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 14
    .line 15
    const-string v1, "Unsupported concurrent change during composition. A state object was modified by composition as well as being modified outside composition."

    .line 16
    .line 17
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    throw v0
    :try_end_14
    .catchall {:try_start_c .. :try_end_14} :catchall_14

    .line 21
    :catchall_14
    move-exception v0

    .line 22
    invoke-virtual {p0}, Llk0;->c()V

    .line 23
    .line 24
    .line 25
    throw v0
.end method

.method public static final M(Ljava/util/ArrayList;Ldw0;Lyj;)V
    .registers 3

    .line 1
    invoke-virtual {p0}, Ljava/util/ArrayList;->clear()V

    .line 2
    .line 3
    .line 4
    iget-object p0, p1, Ldw0;->c:Ljava/lang/Object;

    .line 5
    .line 6
    monitor-enter p0

    .line 7
    :try_start_6
    iget-object p1, p1, Ldw0;->k:Ljava/util/ArrayList;

    .line 8
    .line 9
    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 10
    .line 11
    .line 12
    move-result-object p1

    .line 13
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 14
    .line 15
    .line 16
    move-result p2
    :try_end_10
    .catchall {:try_start_6 .. :try_end_10} :catchall_1f

    .line 17
    if-nez p2, :cond_14

    .line 18
    .line 19
    monitor-exit p0

    .line 20
    return-void

    .line 21
    :cond_14
    :try_start_14
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    check-cast p1, Lgj0;

    .line 26
    .line 27
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 28
    .line 29
    .line 30
    const/4 p1, 0x0

    .line 31
    throw p1
    :try_end_1f
    .catchall {:try_start_14 .. :try_end_1f} :catchall_1f

    .line 32
    :catchall_1f
    move-exception p1

    .line 33
    monitor-exit p0

    .line 34
    throw p1
.end method

.method public static final w(Ldw0;Lcw0;)Ljava/lang/Object;
    .registers 4

    .line 1
    invoke-virtual {p0}, Ldw0;->H()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_38

    .line 6
    .line 7
    new-instance v0, Lne;

    .line 8
    .line 9
    invoke-static {p1}, Lac;->x(Lml;)Lml;

    .line 10
    .line 11
    .line 12
    move-result-object p1

    .line 13
    const/4 v1, 0x1

    .line 14
    invoke-direct {v0, v1, p1}, Lne;-><init>(ILml;)V

    .line 15
    .line 16
    .line 17
    invoke-virtual {v0}, Lne;->t()V

    .line 18
    .line 19
    .line 20
    iget-object p1, p0, Ldw0;->c:Ljava/lang/Object;

    .line 21
    .line 22
    monitor-enter p1

    .line 23
    :try_start_16
    invoke-virtual {p0}, Ldw0;->H()Z

    .line 24
    .line 25
    .line 26
    move-result v1

    .line 27
    if-eqz v1, :cond_1e

    .line 28
    .line 29
    move-object p0, v0

    .line 30
    goto :goto_21

    .line 31
    :cond_1e
    iput-object v0, p0, Ldw0;->r:Lne;
    :try_end_20
    .catchall {:try_start_16 .. :try_end_20} :catchall_35

    .line 32
    .line 33
    const/4 p0, 0x0

    .line 34
    :goto_21
    monitor-exit p1

    .line 35
    if-eqz p0, :cond_29

    .line 36
    .line 37
    sget-object p1, Lwe1;->a:Lwe1;

    .line 38
    .line 39
    invoke-virtual {p0, p1}, Lne;->h(Ljava/lang/Object;)V

    .line 40
    .line 41
    .line 42
    :cond_29
    invoke-virtual {v0}, Lne;->s()Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    move-result-object p0

    .line 46
    sget-object p1, Lcm;->e:Lcm;

    .line 47
    .line 48
    if-ne p0, p1, :cond_32

    .line 49
    .line 50
    return-object p0

    .line 51
    :cond_32
    sget-object p0, Lwe1;->a:Lwe1;

    .line 52
    .line 53
    return-object p0

    .line 54
    :catchall_35
    move-exception p0

    .line 55
    monitor-exit p1

    .line 56
    throw p0

    .line 57
    :cond_38
    sget-object p0, Lwe1;->a:Lwe1;

    .line 58
    .line 59
    return-object p0
.end method

.method public static final x(Ldw0;)V
    .registers 10

    .line 1
    iget-object v0, p0, Ldw0;->c:Ljava/lang/Object;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    :try_start_3
    iget-object v1, p0, Ldw0;->l:Lhk0;

    .line 5
    .line 6
    invoke-virtual {v1}, Lhk0;->j()Z

    .line 7
    .line 8
    .line 9
    move-result v1

    .line 10
    const/4 v2, 0x0

    .line 11
    if-eqz v1, :cond_57

    .line 12
    .line 13
    iget-object v1, p0, Ldw0;->l:Lhk0;

    .line 14
    .line 15
    invoke-static {v1}, Loj0;->b(Lhk0;)Lak0;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    iget-object v3, p0, Ldw0;->l:Lhk0;

    .line 20
    .line 21
    invoke-virtual {v3}, Lhk0;->a()V

    .line 22
    .line 23
    .line 24
    iget-object v3, p0, Ldw0;->m:Lal;

    .line 25
    .line 26
    iget-object v4, v3, Lal;->f:Ljava/lang/Object;

    .line 27
    .line 28
    check-cast v4, Lhk0;

    .line 29
    .line 30
    invoke-virtual {v4}, Lhk0;->a()V

    .line 31
    .line 32
    .line 33
    iget-object v3, v3, Lal;->g:Ljava/lang/Object;

    .line 34
    .line 35
    check-cast v3, Lhk0;

    .line 36
    .line 37
    invoke-virtual {v3}, Lhk0;->a()V

    .line 38
    .line 39
    .line 40
    iget-object v3, p0, Ldw0;->o:Lhk0;

    .line 41
    .line 42
    invoke-virtual {v3}, Lhk0;->a()V

    .line 43
    .line 44
    .line 45
    new-instance v3, Lak0;

    .line 46
    .line 47
    iget v4, v1, Lak0;->b:I

    .line 48
    .line 49
    invoke-direct {v3, v4}, Lak0;-><init>(I)V

    .line 50
    .line 51
    .line 52
    iget-object v4, v1, Lak0;->a:[Ljava/lang/Object;

    .line 53
    .line 54
    iget v1, v1, Lak0;->b:I

    .line 55
    .line 56
    move v5, v2

    .line 57
    :goto_38
    if-ge v5, v1, :cond_51

    .line 58
    .line 59
    aget-object v6, v4, v5

    .line 60
    .line 61
    check-cast v6, Lgj0;

    .line 62
    .line 63
    iget-object v7, p0, Ldw0;->n:Lhk0;

    .line 64
    .line 65
    invoke-virtual {v7, v6}, Lhk0;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 66
    .line 67
    .line 68
    move-result-object v7

    .line 69
    new-instance v8, Lzp0;

    .line 70
    .line 71
    invoke-direct {v8, v6, v7}, Lzp0;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 72
    .line 73
    .line 74
    invoke-virtual {v3, v8}, Lak0;->a(Ljava/lang/Object;)V

    .line 75
    .line 76
    .line 77
    add-int/lit8 v5, v5, 0x1

    .line 78
    .line 79
    goto :goto_38

    .line 80
    :catchall_4f
    move-exception p0

    .line 81
    goto :goto_73

    .line 82
    :cond_51
    iget-object p0, p0, Ldw0;->n:Lhk0;

    .line 83
    .line 84
    invoke-virtual {p0}, Lhk0;->a()V

    .line 85
    .line 86
    .line 87
    goto :goto_5c

    .line 88
    :cond_57
    sget-object v3, Ltm0;->b:Lak0;

    .line 89
    .line 90
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_5c
    .catchall {:try_start_3 .. :try_end_5c} :catchall_4f

    .line 91
    .line 92
    .line 93
    :goto_5c
    monitor-exit v0

    .line 94
    iget-object p0, v3, Lak0;->a:[Ljava/lang/Object;

    .line 95
    .line 96
    iget v0, v3, Lak0;->b:I

    .line 97
    .line 98
    :goto_61
    if-ge v2, v0, :cond_72

    .line 99
    .line 100
    aget-object v1, p0, v2

    .line 101
    .line 102
    check-cast v1, Lzp0;

    .line 103
    .line 104
    iget-object v3, v1, Lzp0;->e:Ljava/lang/Object;

    .line 105
    .line 106
    check-cast v3, Lgj0;

    .line 107
    .line 108
    iget-object v1, v1, Lzp0;->f:Ljava/lang/Object;

    .line 109
    .line 110
    check-cast v1, Lfj0;

    .line 111
    .line 112
    add-int/lit8 v2, v2, 0x1

    .line 113
    .line 114
    goto :goto_61

    .line 115
    :cond_72
    return-void

    .line 116
    :goto_73
    monitor-exit v0

    .line 117
    throw p0
.end method

.method public static final y(Ldw0;)Z
    .registers 2

    .line 1
    iget-object v0, p0, Ldw0;->c:Ljava/lang/Object;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    :try_start_3
    invoke-virtual {p0}, Ldw0;->E()Z

    .line 5
    .line 6
    .line 7
    move-result p0
    :try_end_7
    .catchall {:try_start_3 .. :try_end_7} :catchall_9

    .line 8
    monitor-exit v0

    .line 9
    return p0

    .line 10
    :catchall_9
    move-exception p0

    .line 11
    monitor-exit v0

    .line 12
    throw p0
.end method

.method public static final z(Ldw0;)Ljava/util/List;
    .registers 2

    .line 1
    iget-object v0, p0, Ldw0;->c:Ljava/lang/Object;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    :try_start_3
    invoke-virtual {p0}, Ldw0;->I()Ljava/util/List;

    .line 5
    .line 6
    .line 7
    move-result-object p0
    :try_end_7
    .catchall {:try_start_3 .. :try_end_7} :catchall_9

    .line 8
    monitor-exit v0

    .line 9
    return-object p0

    .line 10
    :catchall_9
    move-exception p0

    .line 11
    monitor-exit v0

    .line 12
    throw p0
.end method


# virtual methods
.method public final C()V
    .registers 5

    .line 1
    iget-object v0, p0, Ldw0;->c:Ljava/lang/Object;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    :try_start_3
    iget-object v1, p0, Ldw0;->u:Ld81;

    .line 5
    .line 6
    invoke-virtual {v1}, Ld81;->getValue()Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    check-cast v1, Law0;

    .line 11
    .line 12
    sget-object v2, Law0;->i:Law0;

    .line 13
    .line 14
    invoke-virtual {v1, v2}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    .line 15
    .line 16
    .line 17
    move-result v1

    .line 18
    const/4 v2, 0x0

    .line 19
    if-ltz v1, :cond_21

    .line 20
    .line 21
    iget-object v1, p0, Ldw0;->u:Ld81;

    .line 22
    .line 23
    sget-object v3, Law0;->f:Law0;

    .line 24
    .line 25
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 26
    .line 27
    .line 28
    invoke-virtual {v1, v2, v3}, Ld81;->i(Ljava/lang/Object;Ljava/lang/Object;)Z
    :try_end_1e
    .catchall {:try_start_3 .. :try_end_1e} :catchall_1f

    .line 29
    .line 30
    .line 31
    goto :goto_21

    .line 32
    :catchall_1f
    move-exception p0

    .line 33
    goto :goto_28

    .line 34
    :cond_21
    :goto_21
    monitor-exit v0

    .line 35
    iget-object p0, p0, Ldw0;->w:Lc80;

    .line 36
    .line 37
    invoke-virtual {p0, v2}, Lh80;->a(Ljava/util/concurrent/CancellationException;)V

    .line 38
    .line 39
    .line 40
    return-void

    .line 41
    :goto_28
    monitor-exit v0

    .line 42
    throw p0
.end method

.method public final D()Lle;
    .registers 10

    .line 1
    iget-object v0, p0, Ldw0;->u:Ld81;

    .line 2
    .line 3
    invoke-virtual {v0}, Ld81;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    check-cast v1, Law0;

    .line 8
    .line 9
    sget-object v2, Law0;->f:Law0;

    .line 10
    .line 11
    invoke-virtual {v1, v2}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    iget-object v2, p0, Ldw0;->s:Ld81;

    .line 16
    .line 17
    iget-object v3, p0, Ldw0;->k:Ljava/util/ArrayList;

    .line 18
    .line 19
    iget-object v4, p0, Ldw0;->j:Ljava/util/ArrayList;

    .line 20
    .line 21
    iget-object v5, p0, Ldw0;->i:Lqk0;

    .line 22
    .line 23
    const/4 v6, 0x0

    .line 24
    if-gtz v1, :cond_55

    .line 25
    .line 26
    invoke-virtual {p0}, Ldw0;->I()Ljava/util/List;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    invoke-interface {v0}, Ljava/util/Collection;->size()I

    .line 31
    .line 32
    .line 33
    move-result v1

    .line 34
    const/4 v7, 0x0

    .line 35
    :goto_22
    if-ge v7, v1, :cond_2d

    .line 36
    .line 37
    invoke-interface {v0, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    move-result-object v8

    .line 41
    check-cast v8, Lyj;

    .line 42
    .line 43
    add-int/lit8 v7, v7, 0x1

    .line 44
    .line 45
    goto :goto_22

    .line 46
    :cond_2d
    iget-object v0, p0, Ldw0;->f:Ljava/util/ArrayList;

    .line 47
    .line 48
    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 49
    .line 50
    .line 51
    sget-object v0, Lut;->e:Lut;

    .line 52
    .line 53
    iput-object v0, p0, Ldw0;->g:Ljava/util/List;

    .line 54
    .line 55
    new-instance v0, Lik0;

    .line 56
    .line 57
    invoke-direct {v0}, Lik0;-><init>()V

    .line 58
    .line 59
    .line 60
    iput-object v0, p0, Ldw0;->h:Lik0;

    .line 61
    .line 62
    invoke-virtual {v5}, Lqk0;->g()V

    .line 63
    .line 64
    .line 65
    invoke-virtual {v4}, Ljava/util/ArrayList;->clear()V

    .line 66
    .line 67
    .line 68
    invoke-virtual {v3}, Ljava/util/ArrayList;->clear()V

    .line 69
    .line 70
    .line 71
    iput-object v6, p0, Ldw0;->p:Ljava/util/ArrayList;

    .line 72
    .line 73
    iget-object v0, p0, Ldw0;->r:Lne;

    .line 74
    .line 75
    if-eqz v0, :cond_4f

    .line 76
    .line 77
    invoke-virtual {v0, v6}, Lne;->l(Ljava/lang/Throwable;)Z

    .line 78
    .line 79
    .line 80
    :cond_4f
    iput-object v6, p0, Ldw0;->r:Lne;

    .line 81
    .line 82
    invoke-virtual {v2, v6}, Ld81;->h(Ljava/lang/Object;)V

    .line 83
    .line 84
    .line 85
    return-object v6

    .line 86
    :cond_55
    invoke-virtual {v2}, Ld81;->getValue()Ljava/lang/Object;

    .line 87
    .line 88
    .line 89
    move-result-object v1

    .line 90
    sget-object v2, Law0;->j:Law0;

    .line 91
    .line 92
    sget-object v7, Law0;->g:Law0;

    .line 93
    .line 94
    if-eqz v1, :cond_60

    .line 95
    .line 96
    goto :goto_af

    .line 97
    :cond_60
    iget-object v1, p0, Ldw0;->d:La80;

    .line 98
    .line 99
    if-nez v1, :cond_7d

    .line 100
    .line 101
    new-instance v1, Lik0;

    .line 102
    .line 103
    invoke-direct {v1}, Lik0;-><init>()V

    .line 104
    .line 105
    .line 106
    iput-object v1, p0, Ldw0;->h:Lik0;

    .line 107
    .line 108
    invoke-virtual {v5}, Lqk0;->g()V

    .line 109
    .line 110
    .line 111
    invoke-virtual {p0}, Ldw0;->E()Z

    .line 112
    .line 113
    .line 114
    move-result v1

    .line 115
    if-nez v1, :cond_7a

    .line 116
    .line 117
    invoke-virtual {p0}, Ldw0;->G()Z

    .line 118
    .line 119
    .line 120
    move-result v1

    .line 121
    if-eqz v1, :cond_af

    .line 122
    .line 123
    :cond_7a
    sget-object v7, Law0;->h:Law0;

    .line 124
    .line 125
    goto :goto_af

    .line 126
    :cond_7d
    iget v1, v5, Lqk0;->g:I

    .line 127
    .line 128
    if-eqz v1, :cond_82

    .line 129
    .line 130
    goto :goto_ae

    .line 131
    :cond_82
    iget-object v1, p0, Ldw0;->h:Lik0;

    .line 132
    .line 133
    invoke-virtual {v1}, Lik0;->h()Z

    .line 134
    .line 135
    .line 136
    move-result v1

    .line 137
    if-nez v1, :cond_ae

    .line 138
    .line 139
    invoke-virtual {v4}, Ljava/util/ArrayList;->isEmpty()Z

    .line 140
    .line 141
    .line 142
    move-result v1

    .line 143
    if-eqz v1, :cond_ae

    .line 144
    .line 145
    invoke-virtual {v3}, Ljava/util/ArrayList;->isEmpty()Z

    .line 146
    .line 147
    .line 148
    move-result v1

    .line 149
    if-eqz v1, :cond_ae

    .line 150
    .line 151
    invoke-virtual {p0}, Ldw0;->E()Z

    .line 152
    .line 153
    .line 154
    move-result v1

    .line 155
    if-nez v1, :cond_ae

    .line 156
    .line 157
    invoke-virtual {p0}, Ldw0;->G()Z

    .line 158
    .line 159
    .line 160
    move-result v1

    .line 161
    if-nez v1, :cond_ae

    .line 162
    .line 163
    iget-object v1, p0, Ldw0;->l:Lhk0;

    .line 164
    .line 165
    invoke-virtual {v1}, Lhk0;->j()Z

    .line 166
    .line 167
    .line 168
    move-result v1

    .line 169
    if-eqz v1, :cond_ab

    .line 170
    .line 171
    goto :goto_ae

    .line 172
    :cond_ab
    sget-object v7, Law0;->i:Law0;

    .line 173
    .line 174
    goto :goto_af

    .line 175
    :cond_ae
    :goto_ae
    move-object v7, v2

    .line 176
    :cond_af
    :goto_af
    invoke-virtual {v0, v6, v7}, Ld81;->i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 177
    .line 178
    .line 179
    if-ne v7, v2, :cond_b9

    .line 180
    .line 181
    iget-object v0, p0, Ldw0;->r:Lne;

    .line 182
    .line 183
    iput-object v6, p0, Ldw0;->r:Lne;

    .line 184
    .line 185
    return-object v0

    .line 186
    :cond_b9
    return-object v6
.end method

.method public final E()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, Ldw0;->t:Z

    .line 2
    .line 3
    if-nez v0, :cond_1a

    .line 4
    .line 5
    iget-object p0, p0, Ldw0;->a:Lg7;

    .line 6
    .line 7
    iget-object p0, p0, Lg7;->g:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast p0, Lpa;

    .line 10
    .line 11
    iget-object p0, p0, Lpa;->c:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast p0, Lca;

    .line 14
    .line 15
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    .line 16
    .line 17
    .line 18
    move-result p0

    .line 19
    const v0, 0x7ffffff

    .line 20
    .line 21
    .line 22
    and-int/2addr p0, v0

    .line 23
    if-lez p0, :cond_1a

    .line 24
    .line 25
    const/4 p0, 0x1

    .line 26
    return p0

    .line 27
    :cond_1a
    const/4 p0, 0x0

    .line 28
    return p0
.end method

.method public final F()Z
    .registers 2

    .line 1
    iget-object v0, p0, Ldw0;->i:Lqk0;

    .line 2
    .line 3
    iget v0, v0, Lqk0;->g:I

    .line 4
    .line 5
    if-eqz v0, :cond_7

    .line 6
    .line 7
    goto :goto_1e

    .line 8
    :cond_7
    invoke-virtual {p0}, Ldw0;->E()Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    if-nez v0, :cond_1e

    .line 13
    .line 14
    invoke-virtual {p0}, Ldw0;->G()Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-nez v0, :cond_1e

    .line 19
    .line 20
    iget-object p0, p0, Ldw0;->l:Lhk0;

    .line 21
    .line 22
    invoke-virtual {p0}, Lhk0;->j()Z

    .line 23
    .line 24
    .line 25
    move-result p0

    .line 26
    if-eqz p0, :cond_1c

    .line 27
    .line 28
    goto :goto_1e

    .line 29
    :cond_1c
    const/4 p0, 0x0

    .line 30
    return p0

    .line 31
    :cond_1e
    :goto_1e
    const/4 p0, 0x1

    .line 32
    return p0
.end method

.method public final G()Z
    .registers 2

    .line 1
    iget-boolean v0, p0, Ldw0;->t:Z

    .line 2
    .line 3
    if-nez v0, :cond_1a

    .line 4
    .line 5
    iget-object p0, p0, Ldw0;->b:Lk9;

    .line 6
    .line 7
    iget-object p0, p0, Lk9;->g:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast p0, Lpa;

    .line 10
    .line 11
    iget-object p0, p0, Lpa;->c:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast p0, Lca;

    .line 14
    .line 15
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    .line 16
    .line 17
    .line 18
    move-result p0

    .line 19
    const v0, 0x7ffffff

    .line 20
    .line 21
    .line 22
    and-int/2addr p0, v0

    .line 23
    if-lez p0, :cond_1a

    .line 24
    .line 25
    const/4 p0, 0x1

    .line 26
    return p0

    .line 27
    :cond_1a
    const/4 p0, 0x0

    .line 28
    return p0
.end method

.method public final H()Z
    .registers 3

    .line 1
    iget-object v0, p0, Ldw0;->c:Ljava/lang/Object;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    :try_start_3
    iget-object v1, p0, Ldw0;->h:Lik0;

    .line 5
    .line 6
    invoke-virtual {v1}, Lik0;->h()Z

    .line 7
    .line 8
    .line 9
    move-result v1

    .line 10
    if-nez v1, :cond_23

    .line 11
    .line 12
    iget-object v1, p0, Ldw0;->i:Lqk0;

    .line 13
    .line 14
    iget v1, v1, Lqk0;->g:I

    .line 15
    .line 16
    if-eqz v1, :cond_12

    .line 17
    .line 18
    goto :goto_23

    .line 19
    :cond_12
    invoke-virtual {p0}, Ldw0;->E()Z

    .line 20
    .line 21
    .line 22
    move-result v1

    .line 23
    if-nez v1, :cond_23

    .line 24
    .line 25
    invoke-virtual {p0}, Ldw0;->G()Z

    .line 26
    .line 27
    .line 28
    move-result p0
    :try_end_1c
    .catchall {:try_start_3 .. :try_end_1c} :catchall_21

    .line 29
    if-eqz p0, :cond_1f

    .line 30
    .line 31
    goto :goto_23

    .line 32
    :cond_1f
    const/4 p0, 0x0

    .line 33
    goto :goto_24

    .line 34
    :catchall_21
    move-exception p0

    .line 35
    goto :goto_26

    .line 36
    :cond_23
    :goto_23
    const/4 p0, 0x1

    .line 37
    :goto_24
    monitor-exit v0

    .line 38
    return p0

    .line 39
    :goto_26
    monitor-exit v0

    .line 40
    throw p0
.end method

.method public final I()Ljava/util/List;
    .registers 3

    .line 1
    iget-object v0, p0, Ldw0;->g:Ljava/util/List;

    .line 2
    .line 3
    if-eqz v0, :cond_5

    .line 4
    .line 5
    return-object v0

    .line 6
    :cond_5
    iget-object v0, p0, Ldw0;->f:Ljava/util/ArrayList;

    .line 7
    .line 8
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    if-eqz v1, :cond_10

    .line 13
    .line 14
    sget-object v0, Lut;->e:Lut;

    .line 15
    .line 16
    goto :goto_16

    .line 17
    :cond_10
    new-instance v1, Ljava/util/ArrayList;

    .line 18
    .line 19
    invoke-direct {v1, v0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 20
    .line 21
    .line 22
    move-object v0, v1

    .line 23
    :goto_16
    iput-object v0, p0, Ldw0;->g:Ljava/util/List;

    .line 24
    .line 25
    return-object v0
.end method

.method public final J()V
    .registers 5

    .line 1
    iget-object v0, p0, Ldw0;->c:Ljava/lang/Object;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    :try_start_3
    invoke-virtual {p0}, Ldw0;->D()Lle;

    .line 5
    .line 6
    .line 7
    move-result-object v1

    .line 8
    iget-object v2, p0, Ldw0;->u:Ld81;

    .line 9
    .line 10
    invoke-virtual {v2}, Ld81;->getValue()Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v2

    .line 14
    check-cast v2, Law0;

    .line 15
    .line 16
    sget-object v3, Law0;->f:Law0;

    .line 17
    .line 18
    invoke-virtual {v2, v3}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    .line 19
    .line 20
    .line 21
    move-result v2
    :try_end_15
    .catchall {:try_start_3 .. :try_end_15} :catchall_2f

    .line 22
    if-lez v2, :cond_22

    .line 23
    .line 24
    monitor-exit v0

    .line 25
    if-eqz v1, :cond_21

    .line 26
    .line 27
    sget-object p0, Lwe1;->a:Lwe1;

    .line 28
    .line 29
    check-cast v1, Lne;

    .line 30
    .line 31
    invoke-virtual {v1, p0}, Lne;->h(Ljava/lang/Object;)V

    .line 32
    .line 33
    .line 34
    :cond_21
    return-void

    .line 35
    :cond_22
    :try_start_22
    const-string v1, "Recomposer shutdown; frame clock awaiter will never resume"

    .line 36
    .line 37
    iget-object p0, p0, Ldw0;->e:Ljava/lang/Throwable;

    .line 38
    .line 39
    new-instance v2, Ljava/util/concurrent/CancellationException;

    .line 40
    .line 41
    invoke-direct {v2, v1}, Ljava/util/concurrent/CancellationException;-><init>(Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    invoke-virtual {v2, p0}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    .line 45
    .line 46
    .line 47
    throw v2
    :try_end_2f
    .catchall {:try_start_22 .. :try_end_2f} :catchall_2f

    .line 48
    :catchall_2f
    move-exception p0

    .line 49
    monitor-exit v0

    .line 50
    throw p0
.end method

.method public final K()V
    .registers 3

    .line 1
    iget-object v0, p0, Ldw0;->c:Ljava/lang/Object;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    const/4 v1, 0x1

    .line 5
    :try_start_4
    iput-boolean v1, p0, Ldw0;->t:Z
    :try_end_6
    .catchall {:try_start_4 .. :try_end_6} :catchall_8

    .line 6
    .line 7
    monitor-exit v0

    .line 8
    return-void

    .line 9
    :catchall_8
    move-exception p0

    .line 10
    monitor-exit v0

    .line 11
    throw p0
.end method

.method public final L(Lyj;)V
    .registers 3

    .line 1
    iget-object p1, p0, Ldw0;->c:Ljava/lang/Object;

    .line 2
    .line 3
    monitor-enter p1

    .line 4
    :try_start_3
    iget-object p0, p0, Ldw0;->k:Ljava/util/ArrayList;

    .line 5
    .line 6
    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    .line 7
    .line 8
    .line 9
    move-result v0
    :try_end_9
    .catchall {:try_start_3 .. :try_end_9} :catchall_19

    .line 10
    if-gtz v0, :cond_d

    .line 11
    .line 12
    monitor-exit p1

    .line 13
    return-void

    .line 14
    :cond_d
    const/4 v0, 0x0

    .line 15
    :try_start_e
    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object p0

    .line 19
    check-cast p0, Lgj0;

    .line 20
    .line 21
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    .line 23
    .line 24
    const/4 p0, 0x0

    .line 25
    throw p0
    :try_end_19
    .catchall {:try_start_e .. :try_end_19} :catchall_19

    .line 26
    :catchall_19
    move-exception p0

    .line 27
    monitor-exit p1

    .line 28
    throw p0
.end method

.method public final N(Ljava/util/List;Lik0;)Ljava/util/List;
    .registers 21

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    new-instance v1, Ljava/util/HashMap;

    .line 4
    .line 5
    invoke-interface/range {p1 .. p1}, Ljava/util/List;->size()I

    .line 6
    .line 7
    .line 8
    move-result v2

    .line 9
    invoke-direct {v1, v2}, Ljava/util/HashMap;-><init>(I)V

    .line 10
    .line 11
    .line 12
    invoke-interface/range {p1 .. p1}, Ljava/util/Collection;->size()I

    .line 13
    .line 14
    .line 15
    move-result v2

    .line 16
    const/4 v4, 0x0

    .line 17
    :goto_10
    const/4 v5, 0x0

    .line 18
    if-ge v4, v2, :cond_35

    .line 19
    .line 20
    move-object/from16 v6, p1

    .line 21
    .line 22
    invoke-interface {v6, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object v7

    .line 26
    move-object v8, v7

    .line 27
    check-cast v8, Lgj0;

    .line 28
    .line 29
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 30
    .line 31
    .line 32
    invoke-virtual {v1, v5}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    move-result-object v8

    .line 36
    if-nez v8, :cond_2d

    .line 37
    .line 38
    new-instance v8, Ljava/util/ArrayList;

    .line 39
    .line 40
    invoke-direct {v8}, Ljava/util/ArrayList;-><init>()V

    .line 41
    .line 42
    .line 43
    invoke-virtual {v1, v5, v8}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    :cond_2d
    check-cast v8, Ljava/util/ArrayList;

    .line 47
    .line 48
    invoke-virtual {v8, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 49
    .line 50
    .line 51
    add-int/lit8 v4, v4, 0x1

    .line 52
    .line 53
    goto :goto_10

    .line 54
    :cond_35
    invoke-virtual {v1}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    .line 55
    .line 56
    .line 57
    move-result-object v2

    .line 58
    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 59
    .line 60
    .line 61
    move-result-object v2

    .line 62
    :goto_3d
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 63
    .line 64
    .line 65
    move-result v4

    .line 66
    if-eqz v4, :cond_1be

    .line 67
    .line 68
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 69
    .line 70
    .line 71
    move-result-object v4

    .line 72
    check-cast v4, Ljava/util/Map$Entry;

    .line 73
    .line 74
    invoke-interface {v4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 75
    .line 76
    .line 77
    move-result-object v6

    .line 78
    check-cast v6, Lyj;

    .line 79
    .line 80
    invoke-interface {v4}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 81
    .line 82
    .line 83
    move-result-object v4

    .line 84
    check-cast v4, Ljava/util/List;

    .line 85
    .line 86
    iget-object v7, v6, Lyj;->z:Ld10;

    .line 87
    .line 88
    iget-boolean v7, v7, Ld10;->F:Z

    .line 89
    .line 90
    if-eqz v7, :cond_60

    .line 91
    .line 92
    const-string v7, "Check failed"

    .line 93
    .line 94
    invoke-static {v7}, Lqj;->a(Ljava/lang/String;)V

    .line 95
    .line 96
    .line 97
    :cond_60
    new-instance v7, Ll;

    .line 98
    .line 99
    const/16 v8, 0x10

    .line 100
    .line 101
    invoke-direct {v7, v8, v6}, Ll;-><init>(ILjava/lang/Object;)V

    .line 102
    .line 103
    .line 104
    new-instance v8, Lc;

    .line 105
    .line 106
    const/16 v9, 0x13

    .line 107
    .line 108
    move-object/from16 v10, p2

    .line 109
    .line 110
    invoke-direct {v8, v9, v6, v10}, Lc;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 111
    .line 112
    .line 113
    invoke-static {}, Ln61;->j()Lg61;

    .line 114
    .line 115
    .line 116
    move-result-object v9

    .line 117
    instance-of v11, v9, Llk0;

    .line 118
    .line 119
    if-eqz v11, :cond_7b

    .line 120
    .line 121
    check-cast v9, Llk0;

    .line 122
    .line 123
    goto :goto_7c

    .line 124
    :cond_7b
    move-object v9, v5

    .line 125
    :goto_7c
    if-eqz v9, :cond_1b8

    .line 126
    .line 127
    invoke-virtual {v9, v7, v8}, Llk0;->D(Li00;Li00;)Llk0;

    .line 128
    .line 129
    .line 130
    move-result-object v7

    .line 131
    if-eqz v7, :cond_1b8

    .line 132
    .line 133
    :try_start_84
    invoke-virtual {v7}, Lg61;->j()Lg61;

    .line 134
    .line 135
    .line 136
    move-result-object v8
    :try_end_88
    .catchall {:try_start_84 .. :try_end_88} :catchall_1ac

    .line 137
    :try_start_88
    iget-object v9, v0, Ldw0;->c:Ljava/lang/Object;

    .line 138
    .line 139
    monitor-enter v9
    :try_end_8b
    .catchall {:try_start_88 .. :try_end_8b} :catchall_16d

    .line 140
    :try_start_8b
    new-instance v11, Ljava/util/ArrayList;

    .line 141
    .line 142
    invoke-interface {v4}, Ljava/util/List;->size()I

    .line 143
    .line 144
    .line 145
    move-result v12

    .line 146
    invoke-direct {v11, v12}, Ljava/util/ArrayList;-><init>(I)V

    .line 147
    .line 148
    .line 149
    invoke-interface {v4}, Ljava/util/Collection;->size()I

    .line 150
    .line 151
    .line 152
    move-result v12

    .line 153
    const/4 v13, 0x0

    .line 154
    :goto_99
    if-ge v13, v12, :cond_bc

    .line 155
    .line 156
    invoke-interface {v4, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 157
    .line 158
    .line 159
    move-result-object v14

    .line 160
    check-cast v14, Lgj0;

    .line 161
    .line 162
    iget-object v15, v0, Ldw0;->l:Lhk0;

    .line 163
    .line 164
    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 165
    .line 166
    .line 167
    invoke-static {v15}, Loj0;->a(Lhk0;)Ljava/lang/Object;

    .line 168
    .line 169
    .line 170
    move-result-object v15

    .line 171
    move-object/from16 v16, v15

    .line 172
    .line 173
    check-cast v16, Lgj0;

    .line 174
    .line 175
    new-instance v3, Lzp0;

    .line 176
    .line 177
    invoke-direct {v3, v14, v15}, Lzp0;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 178
    .line 179
    .line 180
    invoke-virtual {v11, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 181
    .line 182
    .line 183
    add-int/lit8 v13, v13, 0x1

    .line 184
    .line 185
    goto :goto_99

    .line 186
    :catchall_b9
    move-exception v0

    .line 187
    goto/16 :goto_1ae

    .line 188
    .line 189
    :cond_bc
    invoke-virtual {v11}, Ljava/util/ArrayList;->size()I

    .line 190
    .line 191
    .line 192
    move-result v3

    .line 193
    const/4 v4, 0x0

    .line 194
    :goto_c1
    if-ge v4, v3, :cond_125

    .line 195
    .line 196
    invoke-virtual {v11, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 197
    .line 198
    .line 199
    move-result-object v12

    .line 200
    check-cast v12, Lzp0;

    .line 201
    .line 202
    iget-object v13, v12, Lzp0;->f:Ljava/lang/Object;

    .line 203
    .line 204
    if-nez v13, :cond_122

    .line 205
    .line 206
    iget-object v13, v0, Ldw0;->m:Lal;

    .line 207
    .line 208
    iget-object v12, v12, Lzp0;->e:Ljava/lang/Object;

    .line 209
    .line 210
    check-cast v12, Lgj0;

    .line 211
    .line 212
    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 213
    .line 214
    .line 215
    iget-object v12, v13, Lal;->f:Ljava/lang/Object;

    .line 216
    .line 217
    check-cast v12, Lhk0;

    .line 218
    .line 219
    invoke-virtual {v12, v5}, Lhk0;->b(Ljava/lang/Object;)Z

    .line 220
    .line 221
    .line 222
    move-result v12

    .line 223
    if-eqz v12, :cond_122

    .line 224
    .line 225
    new-instance v3, Ljava/util/ArrayList;

    .line 226
    .line 227
    invoke-virtual {v11}, Ljava/util/ArrayList;->size()I

    .line 228
    .line 229
    .line 230
    move-result v4

    .line 231
    invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(I)V

    .line 232
    .line 233
    .line 234
    invoke-virtual {v11}, Ljava/util/ArrayList;->size()I

    .line 235
    .line 236
    .line 237
    move-result v4

    .line 238
    const/4 v12, 0x0

    .line 239
    :goto_ee
    if-ge v12, v4, :cond_120

    .line 240
    .line 241
    invoke-virtual {v11, v12}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 242
    .line 243
    .line 244
    move-result-object v13

    .line 245
    check-cast v13, Lzp0;

    .line 246
    .line 247
    iget-object v14, v13, Lzp0;->f:Ljava/lang/Object;

    .line 248
    .line 249
    if-nez v14, :cond_11a

    .line 250
    .line 251
    iget-object v14, v0, Ldw0;->m:Lal;

    .line 252
    .line 253
    iget-object v15, v13, Lzp0;->e:Ljava/lang/Object;

    .line 254
    .line 255
    check-cast v15, Lgj0;

    .line 256
    .line 257
    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 258
    .line 259
    .line 260
    iget-object v15, v14, Lal;->f:Ljava/lang/Object;

    .line 261
    .line 262
    check-cast v15, Lhk0;

    .line 263
    .line 264
    invoke-static {v15}, Loj0;->a(Lhk0;)Ljava/lang/Object;

    .line 265
    .line 266
    .line 267
    move-result-object v17

    .line 268
    check-cast v17, Lll0;

    .line 269
    .line 270
    invoke-virtual {v15}, Lhk0;->i()Z

    .line 271
    .line 272
    .line 273
    move-result v15

    .line 274
    if-eqz v15, :cond_11a

    .line 275
    .line 276
    iget-object v14, v14, Lal;->g:Ljava/lang/Object;

    .line 277
    .line 278
    check-cast v14, Lhk0;

    .line 279
    .line 280
    invoke-virtual {v14}, Lhk0;->a()V

    .line 281
    .line 282
    .line 283
    :cond_11a
    invoke-virtual {v3, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_11d
    .catchall {:try_start_8b .. :try_end_11d} :catchall_b9

    .line 284
    .line 285
    .line 286
    add-int/lit8 v12, v12, 0x1

    .line 287
    .line 288
    goto :goto_ee

    .line 289
    :cond_120
    move-object v11, v3

    .line 290
    goto :goto_125

    .line 291
    :cond_122
    add-int/lit8 v4, v4, 0x1

    .line 292
    .line 293
    goto :goto_c1

    .line 294
    :cond_125
    :goto_125
    :try_start_125
    monitor-exit v9

    .line 295
    invoke-interface {v11}, Ljava/util/Collection;->size()I

    .line 296
    .line 297
    .line 298
    move-result v3

    .line 299
    const/4 v4, 0x0

    .line 300
    :goto_12b
    if-ge v4, v3, :cond_1a1

    .line 301
    .line 302
    invoke-interface {v11, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 303
    .line 304
    .line 305
    move-result-object v9

    .line 306
    check-cast v9, Lzp0;

    .line 307
    .line 308
    iget-object v9, v9, Lzp0;->f:Ljava/lang/Object;

    .line 309
    .line 310
    if-nez v9, :cond_13a

    .line 311
    .line 312
    add-int/lit8 v4, v4, 0x1

    .line 313
    .line 314
    goto :goto_12b

    .line 315
    :cond_13a
    invoke-interface {v11}, Ljava/util/Collection;->size()I

    .line 316
    .line 317
    .line 318
    move-result v3

    .line 319
    const/4 v4, 0x0

    .line 320
    :goto_13f
    if-ge v4, v3, :cond_1a1

    .line 321
    .line 322
    invoke-interface {v11, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 323
    .line 324
    .line 325
    move-result-object v9

    .line 326
    check-cast v9, Lzp0;

    .line 327
    .line 328
    iget-object v9, v9, Lzp0;->f:Ljava/lang/Object;

    .line 329
    .line 330
    if-eqz v9, :cond_14e

    .line 331
    .line 332
    add-int/lit8 v4, v4, 0x1

    .line 333
    .line 334
    goto :goto_13f

    .line 335
    :cond_14e
    new-instance v3, Ljava/util/ArrayList;

    .line 336
    .line 337
    invoke-interface {v11}, Ljava/util/List;->size()I

    .line 338
    .line 339
    .line 340
    move-result v4

    .line 341
    invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(I)V

    .line 342
    .line 343
    .line 344
    invoke-interface {v11}, Ljava/util/Collection;->size()I

    .line 345
    .line 346
    .line 347
    move-result v4

    .line 348
    const/4 v9, 0x0

    .line 349
    :goto_15c
    if-ge v9, v4, :cond_172

    .line 350
    .line 351
    invoke-interface {v11, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 352
    .line 353
    .line 354
    move-result-object v12

    .line 355
    check-cast v12, Lzp0;

    .line 356
    .line 357
    iget-object v13, v12, Lzp0;->f:Ljava/lang/Object;

    .line 358
    .line 359
    if-nez v13, :cond_16f

    .line 360
    .line 361
    iget-object v12, v12, Lzp0;->e:Ljava/lang/Object;

    .line 362
    .line 363
    check-cast v12, Lgj0;

    .line 364
    .line 365
    goto :goto_16f

    .line 366
    :catchall_16d
    move-exception v0

    .line 367
    goto :goto_1b0

    .line 368
    :cond_16f
    :goto_16f
    add-int/lit8 v9, v9, 0x1

    .line 369
    .line 370
    goto :goto_15c

    .line 371
    :cond_172
    iget-object v4, v0, Ldw0;->c:Ljava/lang/Object;

    .line 372
    .line 373
    monitor-enter v4
    :try_end_175
    .catchall {:try_start_125 .. :try_end_175} :catchall_16d

    .line 374
    :try_start_175
    iget-object v9, v0, Ldw0;->k:Ljava/util/ArrayList;

    .line 375
    .line 376
    invoke-static {v3, v9}, Lyg;->O(Ljava/lang/Iterable;Ljava/util/AbstractCollection;)V
    :try_end_17a
    .catchall {:try_start_175 .. :try_end_17a} :catchall_19e

    .line 377
    .line 378
    .line 379
    :try_start_17a
    monitor-exit v4

    .line 380
    new-instance v3, Ljava/util/ArrayList;

    .line 381
    .line 382
    invoke-interface {v11}, Ljava/util/List;->size()I

    .line 383
    .line 384
    .line 385
    move-result v4

    .line 386
    invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(I)V

    .line 387
    .line 388
    .line 389
    invoke-interface {v11}, Ljava/util/Collection;->size()I

    .line 390
    .line 391
    .line 392
    move-result v4

    .line 393
    const/4 v9, 0x0

    .line 394
    :goto_189
    if-ge v9, v4, :cond_19c

    .line 395
    .line 396
    invoke-interface {v11, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 397
    .line 398
    .line 399
    move-result-object v12

    .line 400
    move-object v13, v12

    .line 401
    check-cast v13, Lzp0;

    .line 402
    .line 403
    iget-object v13, v13, Lzp0;->f:Ljava/lang/Object;

    .line 404
    .line 405
    if-eqz v13, :cond_199

    .line 406
    .line 407
    invoke-virtual {v3, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 408
    .line 409
    .line 410
    :cond_199
    add-int/lit8 v9, v9, 0x1

    .line 411
    .line 412
    goto :goto_189

    .line 413
    :cond_19c
    move-object v11, v3

    .line 414
    goto :goto_1a1

    .line 415
    :catchall_19e
    move-exception v0

    .line 416
    monitor-exit v4

    .line 417
    throw v0

    .line 418
    :cond_1a1
    :goto_1a1
    invoke-virtual {v6, v11}, Lyj;->r(Ljava/util/ArrayList;)V
    :try_end_1a4
    .catchall {:try_start_17a .. :try_end_1a4} :catchall_16d

    .line 419
    .line 420
    .line 421
    :try_start_1a4
    invoke-static {v8}, Lg61;->q(Lg61;)V
    :try_end_1a7
    .catchall {:try_start_1a4 .. :try_end_1a7} :catchall_1ac

    .line 422
    .line 423
    .line 424
    invoke-static {v7}, Ldw0;->B(Llk0;)V

    .line 425
    .line 426
    .line 427
    goto/16 :goto_3d

    .line 428
    .line 429
    :catchall_1ac
    move-exception v0

    .line 430
    goto :goto_1b4

    .line 431
    :goto_1ae
    :try_start_1ae
    monitor-exit v9

    .line 432
    throw v0
    :try_end_1b0
    .catchall {:try_start_1ae .. :try_end_1b0} :catchall_16d

    .line 433
    :goto_1b0
    :try_start_1b0
    invoke-static {v8}, Lg61;->q(Lg61;)V

    .line 434
    .line 435
    .line 436
    throw v0
    :try_end_1b4
    .catchall {:try_start_1b0 .. :try_end_1b4} :catchall_1ac

    .line 437
    :goto_1b4
    invoke-static {v7}, Ldw0;->B(Llk0;)V

    .line 438
    .line 439
    .line 440
    throw v0

    .line 441
    :cond_1b8
    const-string v0, "Cannot create a mutable snapshot of an read-only snapshot"

    .line 442
    .line 443
    invoke-static {v0}, Lod;->p(Ljava/lang/String;)V

    .line 444
    .line 445
    .line 446
    return-object v5

    .line 447
    :cond_1be
    invoke-virtual {v1}, Ljava/util/HashMap;->keySet()Ljava/util/Set;

    .line 448
    .line 449
    .line 450
    move-result-object v0

    .line 451
    check-cast v0, Ljava/lang/Iterable;

    .line 452
    .line 453
    invoke-static {v0}, Ltg;->c0(Ljava/lang/Iterable;)Ljava/util/List;

    .line 454
    .line 455
    .line 456
    move-result-object v0

    .line 457
    return-object v0
.end method

.method public final O(Lyj;Lik0;)Lyj;
    .registers 8

    .line 1
    iget-object v0, p1, Lyj;->z:Ld10;

    .line 2
    .line 3
    iget-boolean v0, v0, Ld10;->F:Z

    .line 4
    .line 5
    const/4 v1, 0x0

    .line 6
    if-nez v0, :cond_84

    .line 7
    .line 8
    iget v0, p1, Lyj;->A:I

    .line 9
    .line 10
    const/4 v2, 0x3

    .line 11
    if-ne v0, v2, :cond_d

    .line 12
    .line 13
    return-object v1

    .line 14
    :cond_d
    iget-object p0, p0, Ldw0;->q:Lik0;

    .line 15
    .line 16
    const/4 v0, 0x1

    .line 17
    if-eqz p0, :cond_19

    .line 18
    .line 19
    invoke-virtual {p0, p1}, Lik0;->c(Ljava/lang/Object;)Z

    .line 20
    .line 21
    .line 22
    move-result p0

    .line 23
    if-ne p0, v0, :cond_19

    .line 24
    .line 25
    goto :goto_84

    .line 26
    :cond_19
    new-instance p0, Ll;

    .line 27
    .line 28
    const/16 v2, 0x10

    .line 29
    .line 30
    invoke-direct {p0, v2, p1}, Ll;-><init>(ILjava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    new-instance v2, Lc;

    .line 34
    .line 35
    const/16 v3, 0x13

    .line 36
    .line 37
    invoke-direct {v2, v3, p1, p2}, Lc;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 38
    .line 39
    .line 40
    invoke-static {}, Ln61;->j()Lg61;

    .line 41
    .line 42
    .line 43
    move-result-object v3

    .line 44
    instance-of v4, v3, Llk0;

    .line 45
    .line 46
    if-eqz v4, :cond_32

    .line 47
    .line 48
    check-cast v3, Llk0;

    .line 49
    .line 50
    goto :goto_33

    .line 51
    :cond_32
    move-object v3, v1

    .line 52
    :goto_33
    if-eqz v3, :cond_7f

    .line 53
    .line 54
    invoke-virtual {v3, p0, v2}, Llk0;->D(Li00;Li00;)Llk0;

    .line 55
    .line 56
    .line 57
    move-result-object p0

    .line 58
    if-eqz p0, :cond_7f

    .line 59
    .line 60
    :try_start_3b
    invoke-virtual {p0}, Lg61;->j()Lg61;

    .line 61
    .line 62
    .line 63
    move-result-object v2
    :try_end_3f
    .catchall {:try_start_3b .. :try_end_3f} :catchall_75

    .line 64
    if-eqz p2, :cond_68

    .line 65
    .line 66
    :try_start_41
    invoke-virtual {p2}, Lik0;->h()Z

    .line 67
    .line 68
    .line 69
    move-result v3

    .line 70
    if-ne v3, v0, :cond_68

    .line 71
    .line 72
    new-instance v3, Lva;

    .line 73
    .line 74
    const/16 v4, 0x8

    .line 75
    .line 76
    invoke-direct {v3, v4, p2, p1}, Lva;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 77
    .line 78
    .line 79
    iget-object p2, p1, Lyj;->z:Ld10;

    .line 80
    .line 81
    iget-boolean v4, p2, Ld10;->F:Z

    .line 82
    .line 83
    if-eqz v4, :cond_59

    .line 84
    .line 85
    const-string v4, "Preparing a composition while composing is not supported"

    .line 86
    .line 87
    invoke-static {v4}, Lqj;->a(Ljava/lang/String;)V

    .line 88
    .line 89
    .line 90
    :cond_59
    iput-boolean v0, p2, Ld10;->F:Z
    :try_end_5b
    .catchall {:try_start_41 .. :try_end_5b} :catchall_66

    .line 91
    .line 92
    const/4 v0, 0x0

    .line 93
    :try_start_5c
    invoke-virtual {v3}, Lva;->a()Ljava/lang/Object;
    :try_end_5f
    .catchall {:try_start_5c .. :try_end_5f} :catchall_62

    .line 94
    .line 95
    .line 96
    :try_start_5f
    iput-boolean v0, p2, Ld10;->F:Z

    .line 97
    .line 98
    goto :goto_68

    .line 99
    :catchall_62
    move-exception p1

    .line 100
    iput-boolean v0, p2, Ld10;->F:Z

    .line 101
    .line 102
    throw p1

    .line 103
    :catchall_66
    move-exception p1

    .line 104
    goto :goto_77

    .line 105
    :cond_68
    :goto_68
    invoke-virtual {p1}, Lyj;->w()Z

    .line 106
    .line 107
    .line 108
    move-result p2
    :try_end_6c
    .catchall {:try_start_5f .. :try_end_6c} :catchall_66

    .line 109
    :try_start_6c
    invoke-static {v2}, Lg61;->q(Lg61;)V
    :try_end_6f
    .catchall {:try_start_6c .. :try_end_6f} :catchall_75

    .line 110
    .line 111
    .line 112
    invoke-static {p0}, Ldw0;->B(Llk0;)V

    .line 113
    .line 114
    .line 115
    if-eqz p2, :cond_84

    .line 116
    .line 117
    return-object p1

    .line 118
    :catchall_75
    move-exception p1

    .line 119
    goto :goto_7b

    .line 120
    :goto_77
    :try_start_77
    invoke-static {v2}, Lg61;->q(Lg61;)V

    .line 121
    .line 122
    .line 123
    throw p1
    :try_end_7b
    .catchall {:try_start_77 .. :try_end_7b} :catchall_75

    .line 124
    :goto_7b
    invoke-static {p0}, Ldw0;->B(Llk0;)V

    .line 125
    .line 126
    .line 127
    throw p1

    .line 128
    :cond_7f
    const-string p0, "Cannot create a mutable snapshot of an read-only snapshot"

    .line 129
    .line 130
    invoke-static {p0}, Lod;->p(Ljava/lang/String;)V

    .line 131
    .line 132
    .line 133
    :cond_84
    :goto_84
    return-object v1
.end method

.method public final P(Ljava/lang/Throwable;Lyj;)V
    .registers 7

    .line 1
    sget-object v0, Ldw0;->A:Ljava/util/concurrent/atomic/AtomicReference;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Ljava/lang/Boolean;

    .line 8
    .line 9
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    const/4 v1, 0x0

    .line 14
    if-eqz v0, :cond_61

    .line 15
    .line 16
    instance-of v0, p1, Lzi;

    .line 17
    .line 18
    if-nez v0, :cond_61

    .line 19
    .line 20
    iget-object v0, p0, Ldw0;->c:Ljava/lang/Object;

    .line 21
    .line 22
    monitor-enter v0

    .line 23
    :try_start_16
    const-string v2, "Error was captured in composition while live edit was enabled."

    .line 24
    .line 25
    const-string v3, "ComposeInternal"

    .line 26
    .line 27
    invoke-static {v3, v2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 28
    .line 29
    .line 30
    iget-object v2, p0, Ldw0;->j:Ljava/util/ArrayList;

    .line 31
    .line 32
    invoke-virtual {v2}, Ljava/util/ArrayList;->clear()V

    .line 33
    .line 34
    .line 35
    iget-object v2, p0, Ldw0;->i:Lqk0;

    .line 36
    .line 37
    invoke-virtual {v2}, Lqk0;->g()V

    .line 38
    .line 39
    .line 40
    new-instance v2, Lik0;

    .line 41
    .line 42
    invoke-direct {v2}, Lik0;-><init>()V

    .line 43
    .line 44
    .line 45
    iput-object v2, p0, Ldw0;->h:Lik0;

    .line 46
    .line 47
    iget-object v2, p0, Ldw0;->k:Ljava/util/ArrayList;

    .line 48
    .line 49
    invoke-virtual {v2}, Ljava/util/ArrayList;->clear()V

    .line 50
    .line 51
    .line 52
    iget-object v2, p0, Ldw0;->l:Lhk0;

    .line 53
    .line 54
    invoke-virtual {v2}, Lhk0;->a()V

    .line 55
    .line 56
    .line 57
    iget-object v2, p0, Ldw0;->n:Lhk0;

    .line 58
    .line 59
    invoke-virtual {v2}, Lhk0;->a()V

    .line 60
    .line 61
    .line 62
    iget-object v2, p0, Ldw0;->s:Ld81;

    .line 63
    .line 64
    new-instance v3, Lzv0;

    .line 65
    .line 66
    invoke-direct {v3, p1}, Lzv0;-><init>(Ljava/lang/Throwable;)V

    .line 67
    .line 68
    .line 69
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 70
    .line 71
    .line 72
    invoke-virtual {v2, v1, v3}, Ld81;->i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 73
    .line 74
    .line 75
    if-eqz p2, :cond_52

    .line 76
    .line 77
    invoke-virtual {p0, p2}, Ldw0;->R(Lyj;)V

    .line 78
    .line 79
    .line 80
    goto :goto_52

    .line 81
    :catchall_50
    move-exception p0

    .line 82
    goto :goto_5f

    .line 83
    :cond_52
    :goto_52
    invoke-virtual {p0}, Ldw0;->D()Lle;

    .line 84
    .line 85
    .line 86
    move-result-object p0

    .line 87
    if-eqz p0, :cond_5d

    .line 88
    .line 89
    const-string p0, "expected to go to inactive state due to composition error"

    .line 90
    .line 91
    invoke-static {p0}, Lqj;->a(Ljava/lang/String;)V
    :try_end_5d
    .catchall {:try_start_16 .. :try_end_5d} :catchall_50

    .line 92
    .line 93
    .line 94
    :cond_5d
    monitor-exit v0

    .line 95
    return-void

    .line 96
    :goto_5f
    monitor-exit v0

    .line 97
    throw p0

    .line 98
    :cond_61
    iget-object p2, p0, Ldw0;->c:Ljava/lang/Object;

    .line 99
    .line 100
    monitor-enter p2

    .line 101
    :try_start_64
    const-string v0, "Error was captured in composition."

    .line 102
    .line 103
    const-string v2, "ComposeInternal"

    .line 104
    .line 105
    invoke-static {v2, v0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 106
    .line 107
    .line 108
    iget-object v0, p0, Ldw0;->s:Ld81;

    .line 109
    .line 110
    invoke-virtual {v0}, Ld81;->getValue()Ljava/lang/Object;

    .line 111
    .line 112
    .line 113
    move-result-object v0

    .line 114
    check-cast v0, Lzv0;

    .line 115
    .line 116
    if-nez v0, :cond_86

    .line 117
    .line 118
    iget-object p0, p0, Ldw0;->s:Ld81;

    .line 119
    .line 120
    new-instance v0, Lzv0;

    .line 121
    .line 122
    invoke-direct {v0, p1}, Lzv0;-><init>(Ljava/lang/Throwable;)V

    .line 123
    .line 124
    .line 125
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 126
    .line 127
    .line 128
    invoke-virtual {p0, v1, v0}, Ld81;->i(Ljava/lang/Object;Ljava/lang/Object;)Z
    :try_end_82
    .catchall {:try_start_64 .. :try_end_82} :catchall_84

    .line 129
    .line 130
    .line 131
    monitor-exit p2

    .line 132
    throw p1

    .line 133
    :catchall_84
    move-exception p0

    .line 134
    goto :goto_89

    .line 135
    :cond_86
    :try_start_86
    iget-object p0, v0, Lzv0;->a:Ljava/lang/Throwable;

    .line 136
    .line 137
    throw p0
    :try_end_89
    .catchall {:try_start_86 .. :try_end_89} :catchall_84

    .line 138
    :goto_89
    monitor-exit p2

    .line 139
    throw p0
.end method

.method public final Q()Z
    .registers 7

    .line 1
    iget-object v0, p0, Ldw0;->c:Ljava/lang/Object;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    :try_start_3
    iget-object v1, p0, Ldw0;->h:Lik0;

    .line 5
    .line 6
    invoke-virtual {v1}, Lik0;->g()Z

    .line 7
    .line 8
    .line 9
    move-result v1

    .line 10
    if-eqz v1, :cond_14

    .line 11
    .line 12
    invoke-virtual {p0}, Ldw0;->F()Z

    .line 13
    .line 14
    .line 15
    move-result p0
    :try_end_f
    .catchall {:try_start_3 .. :try_end_f} :catchall_11

    .line 16
    monitor-exit v0

    .line 17
    return p0

    .line 18
    :catchall_11
    move-exception p0

    .line 19
    goto/16 :goto_86

    .line 20
    .line 21
    :cond_14
    :try_start_14
    invoke-virtual {p0}, Ldw0;->I()Ljava/util/List;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    iget-object v2, p0, Ldw0;->h:Lik0;

    .line 26
    .line 27
    new-instance v3, Lp01;

    .line 28
    .line 29
    invoke-direct {v3, v2}, Lp01;-><init>(Lik0;)V

    .line 30
    .line 31
    .line 32
    new-instance v2, Lik0;

    .line 33
    .line 34
    invoke-direct {v2}, Lik0;-><init>()V

    .line 35
    .line 36
    .line 37
    iput-object v2, p0, Ldw0;->h:Lik0;
    :try_end_26
    .catchall {:try_start_14 .. :try_end_26} :catchall_11

    .line 38
    .line 39
    monitor-exit v0

    .line 40
    :try_start_27
    invoke-interface {v1}, Ljava/util/Collection;->size()I

    .line 41
    .line 42
    .line 43
    move-result v0

    .line 44
    const/4 v2, 0x0

    .line 45
    :goto_2c
    if-ge v2, v0, :cond_4c

    .line 46
    .line 47
    invoke-interface {v1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object v4

    .line 51
    check-cast v4, Lyj;

    .line 52
    .line 53
    invoke-virtual {v4, v3}, Lyj;->x(Lp01;)V

    .line 54
    .line 55
    .line 56
    iget-object v4, p0, Ldw0;->u:Ld81;

    .line 57
    .line 58
    invoke-virtual {v4}, Ld81;->getValue()Ljava/lang/Object;

    .line 59
    .line 60
    .line 61
    move-result-object v4

    .line 62
    check-cast v4, Law0;

    .line 63
    .line 64
    sget-object v5, Law0;->f:Law0;

    .line 65
    .line 66
    invoke-virtual {v4, v5}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    .line 67
    .line 68
    .line 69
    move-result v4
    :try_end_45
    .catchall {:try_start_27 .. :try_end_45} :catchall_4a

    .line 70
    if-lez v4, :cond_4c

    .line 71
    .line 72
    add-int/lit8 v2, v2, 0x1

    .line 73
    .line 74
    goto :goto_2c

    .line 75
    :catchall_4a
    move-exception v0

    .line 76
    goto :goto_67

    .line 77
    :cond_4c
    iget-object v0, p0, Ldw0;->c:Ljava/lang/Object;

    .line 78
    .line 79
    monitor-enter v0

    .line 80
    :try_start_4f
    invoke-virtual {p0}, Ldw0;->D()Lle;

    .line 81
    .line 82
    .line 83
    move-result-object v1

    .line 84
    if-nez v1, :cond_5d

    .line 85
    .line 86
    invoke-virtual {p0}, Ldw0;->F()Z

    .line 87
    .line 88
    .line 89
    move-result p0
    :try_end_59
    .catchall {:try_start_4f .. :try_end_59} :catchall_5b

    .line 90
    monitor-exit v0

    .line 91
    return p0

    .line 92
    :catchall_5b
    move-exception p0

    .line 93
    goto :goto_65

    .line 94
    :cond_5d
    :try_start_5d
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 95
    .line 96
    const-string v1, "called outside of runRecomposeAndApplyChanges"

    .line 97
    .line 98
    invoke-direct {p0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 99
    .line 100
    .line 101
    throw p0
    :try_end_65
    .catchall {:try_start_5d .. :try_end_65} :catchall_5b

    .line 102
    :goto_65
    monitor-exit v0

    .line 103
    throw p0

    .line 104
    :goto_67
    iget-object v1, p0, Ldw0;->c:Ljava/lang/Object;

    .line 105
    .line 106
    monitor-enter v1

    .line 107
    :try_start_6a
    iget-object p0, p0, Ldw0;->h:Lik0;

    .line 108
    .line 109
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 110
    .line 111
    .line 112
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 113
    .line 114
    .line 115
    move-result-object v2

    .line 116
    :goto_73
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 117
    .line 118
    .line 119
    move-result v3

    .line 120
    if-eqz v3, :cond_81

    .line 121
    .line 122
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 123
    .line 124
    .line 125
    move-result-object v3

    .line 126
    invoke-virtual {p0, v3}, Lik0;->k(Ljava/lang/Object;)V
    :try_end_80
    .catchall {:try_start_6a .. :try_end_80} :catchall_83

    .line 127
    .line 128
    .line 129
    goto :goto_73

    .line 130
    :cond_81
    monitor-exit v1

    .line 131
    throw v0

    .line 132
    :catchall_83
    move-exception p0

    .line 133
    monitor-exit v1

    .line 134
    throw p0

    .line 135
    :goto_86
    monitor-exit v0

    .line 136
    throw p0
.end method

.method public final R(Lyj;)V
    .registers 4

    .line 1
    iget-object v0, p0, Ldw0;->p:Ljava/util/ArrayList;

    .line 2
    .line 3
    if-nez v0, :cond_b

    .line 4
    .line 5
    new-instance v0, Ljava/util/ArrayList;

    .line 6
    .line 7
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 8
    .line 9
    .line 10
    iput-object v0, p0, Ldw0;->p:Ljava/util/ArrayList;

    .line 11
    .line 12
    :cond_b
    invoke-interface {v0, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 13
    .line 14
    .line 15
    move-result v1

    .line 16
    if-nez v1, :cond_14

    .line 17
    .line 18
    invoke-interface {v0, p1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 19
    .line 20
    .line 21
    :cond_14
    iget-object v0, p0, Ldw0;->f:Ljava/util/ArrayList;

    .line 22
    .line 23
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    .line 24
    .line 25
    .line 26
    move-result p1

    .line 27
    if-eqz p1, :cond_1f

    .line 28
    .line 29
    const/4 p1, 0x0

    .line 30
    iput-object p1, p0, Ldw0;->g:Ljava/util/List;

    .line 31
    .line 32
    :cond_1f
    return-void
.end method

.method public final S()V
    .registers 3

    .line 1
    iget-object v0, p0, Ldw0;->c:Ljava/lang/Object;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    :try_start_3
    iget-boolean v1, p0, Ldw0;->t:Z

    .line 5
    .line 6
    if-eqz v1, :cond_11

    .line 7
    .line 8
    const/4 v1, 0x0

    .line 9
    iput-boolean v1, p0, Ldw0;->t:Z

    .line 10
    .line 11
    invoke-virtual {p0}, Ldw0;->D()Lle;

    .line 12
    .line 13
    .line 14
    move-result-object p0
    :try_end_e
    .catchall {:try_start_3 .. :try_end_e} :catchall_f

    .line 15
    goto :goto_12

    .line 16
    :catchall_f
    move-exception p0

    .line 17
    goto :goto_1d

    .line 18
    :cond_11
    const/4 p0, 0x0

    .line 19
    :goto_12
    monitor-exit v0

    .line 20
    if-eqz p0, :cond_1c

    .line 21
    .line 22
    sget-object v0, Lwe1;->a:Lwe1;

    .line 23
    .line 24
    check-cast p0, Lne;

    .line 25
    .line 26
    invoke-virtual {p0, v0}, Lne;->h(Ljava/lang/Object;)V

    .line 27
    .line 28
    .line 29
    :cond_1c
    return-void

    .line 30
    :goto_1d
    monitor-exit v0

    .line 31
    throw p0
.end method

.method public final a(Lyj;Lm00;)V
    .registers 11

    .line 1
    iget-object v0, p1, Lyj;->z:Ld10;

    .line 2
    .line 3
    iget-boolean v0, v0, Ld10;->F:Z

    .line 4
    .line 5
    iget-object v1, p0, Ldw0;->c:Ljava/lang/Object;

    .line 6
    .line 7
    monitor-enter v1

    .line 8
    :try_start_7
    iget-object v2, p0, Ldw0;->u:Ld81;

    .line 9
    .line 10
    invoke-virtual {v2}, Ld81;->getValue()Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v2

    .line 14
    check-cast v2, Law0;

    .line 15
    .line 16
    sget-object v3, Law0;->f:Law0;

    .line 17
    .line 18
    invoke-virtual {v2, v3}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    .line 19
    .line 20
    .line 21
    move-result v2

    .line 22
    const/4 v4, 0x1

    .line 23
    if-lez v2, :cond_25

    .line 24
    .line 25
    invoke-virtual {p0}, Ldw0;->I()Ljava/util/List;

    .line 26
    .line 27
    .line 28
    move-result-object v2

    .line 29
    invoke-interface {v2, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 30
    .line 31
    .line 32
    move-result v2
    :try_end_20
    .catchall {:try_start_7 .. :try_end_20} :catchall_22

    .line 33
    xor-int/2addr v4, v2

    .line 34
    goto :goto_25

    .line 35
    :catchall_22
    move-exception p0

    .line 36
    goto/16 :goto_c3

    .line 37
    .line 38
    :cond_25
    :goto_25
    monitor-exit v1

    .line 39
    :try_start_26
    new-instance v1, Ll;

    .line 40
    .line 41
    const/16 v2, 0x10

    .line 42
    .line 43
    invoke-direct {v1, v2, p1}, Ll;-><init>(ILjava/lang/Object;)V

    .line 44
    .line 45
    .line 46
    new-instance v2, Lc;

    .line 47
    .line 48
    const/16 v5, 0x13

    .line 49
    .line 50
    const/4 v6, 0x0

    .line 51
    invoke-direct {v2, v5, p1, v6}, Lc;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 52
    .line 53
    .line 54
    invoke-static {}, Ln61;->j()Lg61;

    .line 55
    .line 56
    .line 57
    move-result-object v5

    .line 58
    instance-of v7, v5, Llk0;

    .line 59
    .line 60
    if-eqz v7, :cond_40

    .line 61
    .line 62
    check-cast v5, Llk0;

    .line 63
    .line 64
    goto :goto_41

    .line 65
    :cond_40
    move-object v5, v6

    .line 66
    :goto_41
    if-eqz v5, :cond_b1

    .line 67
    .line 68
    invoke-virtual {v5, v1, v2}, Llk0;->D(Li00;Li00;)Llk0;

    .line 69
    .line 70
    .line 71
    move-result-object v1
    :try_end_47
    .catchall {:try_start_26 .. :try_end_47} :catchall_a4

    .line 72
    if-eqz v1, :cond_b1

    .line 73
    .line 74
    :try_start_49
    invoke-virtual {v1}, Lg61;->j()Lg61;

    .line 75
    .line 76
    .line 77
    move-result-object v2
    :try_end_4d
    .catchall {:try_start_49 .. :try_end_4d} :catchall_a6

    .line 78
    :try_start_4d
    invoke-virtual {p1, p2}, Lyj;->j(Lm00;)V
    :try_end_50
    .catchall {:try_start_4d .. :try_end_50} :catchall_a8

    .line 79
    .line 80
    .line 81
    :try_start_50
    invoke-static {v2}, Lg61;->q(Lg61;)V
    :try_end_53
    .catchall {:try_start_50 .. :try_end_53} :catchall_a6

    .line 82
    .line 83
    .line 84
    :try_start_53
    invoke-static {v1}, Ldw0;->B(Llk0;)V
    :try_end_56
    .catchall {:try_start_53 .. :try_end_56} :catchall_a4

    .line 85
    .line 86
    .line 87
    iget-object p2, p0, Ldw0;->c:Ljava/lang/Object;

    .line 88
    .line 89
    monitor-enter p2

    .line 90
    :try_start_59
    iget-object v1, p0, Ldw0;->u:Ld81;

    .line 91
    .line 92
    invoke-virtual {v1}, Ld81;->getValue()Ljava/lang/Object;

    .line 93
    .line 94
    .line 95
    move-result-object v1

    .line 96
    check-cast v1, Law0;

    .line 97
    .line 98
    invoke-virtual {v1, v3}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    .line 99
    .line 100
    .line 101
    move-result v1

    .line 102
    if-lez v1, :cond_7b

    .line 103
    .line 104
    invoke-virtual {p0}, Ldw0;->I()Ljava/util/List;

    .line 105
    .line 106
    .line 107
    move-result-object v1

    .line 108
    invoke-interface {v1, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 109
    .line 110
    .line 111
    move-result v1

    .line 112
    if-nez v1, :cond_7b

    .line 113
    .line 114
    iget-object v1, p0, Ldw0;->f:Ljava/util/ArrayList;

    .line 115
    .line 116
    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 117
    .line 118
    .line 119
    iput-object v6, p0, Ldw0;->g:Ljava/util/List;
    :try_end_78
    .catchall {:try_start_59 .. :try_end_78} :catchall_79

    .line 120
    .line 121
    goto :goto_7b

    .line 122
    :catchall_79
    move-exception p0

    .line 123
    goto :goto_a2

    .line 124
    :cond_7b
    :goto_7b
    monitor-exit p2

    .line 125
    if-nez v0, :cond_85

    .line 126
    .line 127
    invoke-static {}, Ln61;->j()Lg61;

    .line 128
    .line 129
    .line 130
    move-result-object p2

    .line 131
    invoke-virtual {p2}, Lg61;->m()V

    .line 132
    .line 133
    .line 134
    :cond_85
    :try_start_85
    invoke-virtual {p0, p1}, Ldw0;->L(Lyj;)V
    :try_end_88
    .catchall {:try_start_85 .. :try_end_88} :catchall_9d

    .line 135
    .line 136
    .line 137
    :try_start_88
    invoke-virtual {p1}, Lyj;->d()V

    .line 138
    .line 139
    .line 140
    invoke-virtual {p1}, Lyj;->f()V
    :try_end_8e
    .catchall {:try_start_88 .. :try_end_8e} :catchall_98

    .line 141
    .line 142
    .line 143
    if-nez v0, :cond_97

    .line 144
    .line 145
    invoke-static {}, Ln61;->j()Lg61;

    .line 146
    .line 147
    .line 148
    move-result-object p0

    .line 149
    invoke-virtual {p0}, Lg61;->m()V

    .line 150
    .line 151
    .line 152
    :cond_97
    return-void

    .line 153
    :catchall_98
    move-exception p1

    .line 154
    invoke-virtual {p0, p1, v6}, Ldw0;->P(Ljava/lang/Throwable;Lyj;)V

    .line 155
    .line 156
    .line 157
    return-void

    .line 158
    :catchall_9d
    move-exception p2

    .line 159
    invoke-virtual {p0, p2, p1}, Ldw0;->P(Ljava/lang/Throwable;Lyj;)V

    .line 160
    .line 161
    .line 162
    return-void

    .line 163
    :goto_a2
    monitor-exit p2

    .line 164
    throw p0

    .line 165
    :catchall_a4
    move-exception p2

    .line 166
    goto :goto_b9

    .line 167
    :catchall_a6
    move-exception p2

    .line 168
    goto :goto_ad

    .line 169
    :catchall_a8
    move-exception p2

    .line 170
    :try_start_a9
    invoke-static {v2}, Lg61;->q(Lg61;)V

    .line 171
    .line 172
    .line 173
    throw p2
    :try_end_ad
    .catchall {:try_start_a9 .. :try_end_ad} :catchall_a6

    .line 174
    :goto_ad
    :try_start_ad
    invoke-static {v1}, Ldw0;->B(Llk0;)V

    .line 175
    .line 176
    .line 177
    throw p2

    .line 178
    :cond_b1
    new-instance p2, Ljava/lang/IllegalStateException;

    .line 179
    .line 180
    const-string v0, "Cannot create a mutable snapshot of an read-only snapshot"

    .line 181
    .line 182
    invoke-direct {p2, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 183
    .line 184
    .line 185
    throw p2
    :try_end_b9
    .catchall {:try_start_ad .. :try_end_b9} :catchall_a4

    .line 186
    :goto_b9
    if-eqz v4, :cond_bf

    .line 187
    .line 188
    iget-object v0, p0, Ldw0;->c:Ljava/lang/Object;

    .line 189
    .line 190
    monitor-enter v0

    .line 191
    monitor-exit v0

    .line 192
    :cond_bf
    invoke-virtual {p0, p2, p1}, Ldw0;->P(Ljava/lang/Throwable;Lyj;)V

    .line 193
    .line 194
    .line 195
    return-void

    .line 196
    :goto_c3
    monitor-exit v1

    .line 197
    throw p0
.end method

.method public final b(Lyj;Ll51;Lm00;)Lik0;
    .registers 7

    .line 1
    iget-object v0, p0, Ldw0;->v:Lk9;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    :try_start_3
    iget-object v2, p1, Lyj;->t:Ll51;

    .line 5
    .line 6
    iput-object p2, p1, Lyj;->t:Ll51;
    :try_end_7
    .catchall {:try_start_3 .. :try_end_7} :catchall_1e

    .line 7
    .line 8
    :try_start_7
    invoke-virtual {p0, p1, p3}, Ldw0;->a(Lyj;Lm00;)V

    .line 9
    .line 10
    .line 11
    invoke-virtual {v0}, Lk9;->p()Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object p0

    .line 15
    check-cast p0, Lik0;

    .line 16
    .line 17
    if-eqz p0, :cond_13

    .line 18
    .line 19
    goto :goto_18

    .line 20
    :cond_13
    sget-object p0, Lo01;->a:Lik0;

    .line 21
    .line 22
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_18
    .catchall {:try_start_7 .. :try_end_18} :catchall_20

    .line 23
    .line 24
    .line 25
    :goto_18
    :try_start_18
    iput-object v2, p1, Lyj;->t:Ll51;
    :try_end_1a
    .catchall {:try_start_18 .. :try_end_1a} :catchall_1e

    .line 26
    .line 27
    invoke-virtual {v0, v1}, Lk9;->A(Ljava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    return-object p0

    .line 31
    :catchall_1e
    move-exception p0

    .line 32
    goto :goto_24

    .line 33
    :catchall_20
    move-exception p0

    .line 34
    :try_start_21
    iput-object v2, p1, Lyj;->t:Ll51;

    .line 35
    .line 36
    throw p0
    :try_end_24
    .catchall {:try_start_21 .. :try_end_24} :catchall_1e

    .line 37
    :goto_24
    invoke-virtual {v0, v1}, Lk9;->A(Ljava/lang/Object;)V

    .line 38
    .line 39
    .line 40
    throw p0
.end method

.method public final d()Z
    .registers 1

    .line 1
    sget-object p0, Ldw0;->A:Ljava/util/concurrent/atomic/AtomicReference;

    .line 2
    .line 3
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Ljava/lang/Boolean;

    .line 8
    .line 9
    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 10
    .line 11
    .line 12
    move-result p0

    .line 13
    return p0
.end method

.method public final e()Z
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public final f()Z
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public final g()J
    .registers 3

    .line 1
    const-wide/16 v0, 0x3e8

    .line 2
    .line 3
    return-wide v0
.end method

.method public final h()Lrj;
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return-object p0
.end method

.method public final j()Lsl;
    .registers 1

    .line 1
    iget-object p0, p0, Ldw0;->x:Lsl;

    .line 2
    .line 3
    return-object p0
.end method

.method public final k()Z
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public final l(Lyj;)V
    .registers 4

    .line 1
    iget-object v0, p0, Ldw0;->c:Ljava/lang/Object;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    :try_start_3
    iget-object v1, p0, Ldw0;->i:Lqk0;

    .line 5
    .line 6
    invoke-virtual {v1, p1}, Lqk0;->h(Ljava/lang/Object;)Z

    .line 7
    .line 8
    .line 9
    move-result v1

    .line 10
    if-nez v1, :cond_17

    .line 11
    .line 12
    iget-object v1, p0, Ldw0;->i:Lqk0;

    .line 13
    .line 14
    invoke-virtual {v1, p1}, Lqk0;->b(Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    invoke-virtual {p0}, Ldw0;->D()Lle;

    .line 18
    .line 19
    .line 20
    move-result-object p0
    :try_end_14
    .catchall {:try_start_3 .. :try_end_14} :catchall_15

    .line 21
    goto :goto_18

    .line 22
    :catchall_15
    move-exception p0

    .line 23
    goto :goto_23

    .line 24
    :cond_17
    const/4 p0, 0x0

    .line 25
    :goto_18
    monitor-exit v0

    .line 26
    if-eqz p0, :cond_22

    .line 27
    .line 28
    sget-object p1, Lwe1;->a:Lwe1;

    .line 29
    .line 30
    check-cast p0, Lne;

    .line 31
    .line 32
    invoke-virtual {p0, p1}, Lne;->h(Ljava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    :cond_22
    return-void

    .line 36
    :goto_23
    monitor-exit v0

    .line 37
    throw p0
.end method

.method public final m(Lgj0;)Lfj0;
    .registers 3

    .line 1
    iget-object v0, p0, Ldw0;->c:Ljava/lang/Object;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    :try_start_3
    iget-object p0, p0, Ldw0;->n:Lhk0;

    .line 5
    .line 6
    invoke-virtual {p0, p1}, Lhk0;->k(Ljava/lang/Object;)Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    check-cast p0, Lfj0;
    :try_end_b
    .catchall {:try_start_3 .. :try_end_b} :catchall_d

    .line 11
    .line 12
    monitor-exit v0

    .line 13
    return-object p0

    .line 14
    :catchall_d
    move-exception p0

    .line 15
    monitor-exit v0

    .line 16
    throw p0
.end method

.method public final n(Lyj;Ll51;Lik0;)Lik0;
    .registers 7

    .line 1
    iget-object v0, p0, Ldw0;->v:Lk9;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    :try_start_3
    invoke-virtual {p0}, Ldw0;->Q()Z

    .line 5
    .line 6
    .line 7
    new-instance v2, Lp01;

    .line 8
    .line 9
    invoke-direct {v2, p3}, Lp01;-><init>(Lik0;)V

    .line 10
    .line 11
    .line 12
    invoke-virtual {p1, v2}, Lyj;->x(Lp01;)V

    .line 13
    .line 14
    .line 15
    iget-object p3, p1, Lyj;->t:Ll51;

    .line 16
    .line 17
    iput-object p2, p1, Lyj;->t:Ll51;
    :try_end_12
    .catchall {:try_start_3 .. :try_end_12} :catchall_38

    .line 18
    .line 19
    :try_start_12
    invoke-virtual {p0, p1, v1}, Ldw0;->O(Lyj;Lik0;)Lyj;

    .line 20
    .line 21
    .line 22
    move-result-object p2

    .line 23
    if-eqz p2, :cond_24

    .line 24
    .line 25
    invoke-virtual {p0, p1}, Ldw0;->L(Lyj;)V

    .line 26
    .line 27
    .line 28
    invoke-virtual {p2}, Lyj;->d()V

    .line 29
    .line 30
    .line 31
    invoke-virtual {p2}, Lyj;->f()V

    .line 32
    .line 33
    .line 34
    goto :goto_24

    .line 35
    :catchall_22
    move-exception p0

    .line 36
    goto :goto_3a

    .line 37
    :cond_24
    :goto_24
    invoke-virtual {v0}, Lk9;->p()Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    move-result-object p0

    .line 41
    check-cast p0, Lik0;

    .line 42
    .line 43
    if-eqz p0, :cond_2d

    .line 44
    .line 45
    goto :goto_32

    .line 46
    :cond_2d
    sget-object p0, Lo01;->a:Lik0;

    .line 47
    .line 48
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_32
    .catchall {:try_start_12 .. :try_end_32} :catchall_22

    .line 49
    .line 50
    .line 51
    :goto_32
    :try_start_32
    iput-object p3, p1, Lyj;->t:Ll51;
    :try_end_34
    .catchall {:try_start_32 .. :try_end_34} :catchall_38

    .line 52
    .line 53
    invoke-virtual {v0, v1}, Lk9;->A(Ljava/lang/Object;)V

    .line 54
    .line 55
    .line 56
    return-object p0

    .line 57
    :catchall_38
    move-exception p0

    .line 58
    goto :goto_3d

    .line 59
    :goto_3a
    :try_start_3a
    iput-object p3, p1, Lyj;->t:Ll51;

    .line 60
    .line 61
    throw p0
    :try_end_3d
    .catchall {:try_start_3a .. :try_end_3d} :catchall_38

    .line 62
    :goto_3d
    invoke-virtual {v0, v1}, Lk9;->A(Ljava/lang/Object;)V

    .line 63
    .line 64
    .line 65
    throw p0
.end method

.method public final o(Ljava/util/Set;)V
    .registers 2

    .line 1
    return-void
.end method

.method public final q(Lxv0;)V
    .registers 3

    .line 1
    iget-object p0, p0, Ldw0;->v:Lk9;

    .line 2
    .line 3
    invoke-virtual {p0}, Lk9;->p()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Lik0;

    .line 8
    .line 9
    if-nez v0, :cond_14

    .line 10
    .line 11
    sget-object v0, Lo01;->a:Lik0;

    .line 12
    .line 13
    new-instance v0, Lik0;

    .line 14
    .line 15
    invoke-direct {v0}, Lik0;-><init>()V

    .line 16
    .line 17
    .line 18
    invoke-virtual {p0, v0}, Lk9;->A(Ljava/lang/Object;)V

    .line 19
    .line 20
    .line 21
    :cond_14
    invoke-virtual {v0, p1}, Lik0;->a(Ljava/lang/Object;)Z

    .line 22
    .line 23
    .line 24
    return-void
.end method

.method public final r(Lyj;)V
    .registers 4

    .line 1
    iget-object v0, p0, Ldw0;->c:Ljava/lang/Object;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    :try_start_3
    iget-object v1, p0, Ldw0;->q:Lik0;

    .line 5
    .line 6
    if-nez v1, :cond_13

    .line 7
    .line 8
    sget-object v1, Lo01;->a:Lik0;

    .line 9
    .line 10
    new-instance v1, Lik0;

    .line 11
    .line 12
    invoke-direct {v1}, Lik0;-><init>()V

    .line 13
    .line 14
    .line 15
    iput-object v1, p0, Ldw0;->q:Lik0;

    .line 16
    .line 17
    goto :goto_13

    .line 18
    :catchall_11
    move-exception p0

    .line 19
    goto :goto_18

    .line 20
    :cond_13
    :goto_13
    invoke-virtual {v1, p1}, Lik0;->a(Ljava/lang/Object;)Z
    :try_end_16
    .catchall {:try_start_3 .. :try_end_16} :catchall_11

    .line 21
    .line 22
    .line 23
    monitor-exit v0

    .line 24
    return-void

    .line 25
    :goto_18
    monitor-exit v0

    .line 26
    throw p0
.end method

.method public final s(Lf8;)Loe;
    .registers 4

    .line 1
    iget-object p0, p0, Ldw0;->b:Lk9;

    .line 2
    .line 3
    iget-object v0, p0, Lk9;->g:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Lpa;

    .line 6
    .line 7
    new-instance v1, Lzl0;

    .line 8
    .line 9
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 10
    .line 11
    .line 12
    iput-object p1, v1, Lzl0;->a:Lf8;

    .line 13
    .line 14
    iget-object p0, p0, Lk9;->h:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast p0, Lva;

    .line 17
    .line 18
    invoke-virtual {v0, v1, p0}, Lpa;->d(Loa;Lxz;)Loe;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    return-object p0
.end method

.method public final v(Lyj;)V
    .registers 4

    .line 1
    iget-object v0, p0, Ldw0;->c:Ljava/lang/Object;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    :try_start_3
    iget-object v1, p0, Ldw0;->f:Ljava/util/ArrayList;

    .line 5
    .line 6
    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    .line 7
    .line 8
    .line 9
    move-result v1

    .line 10
    if-eqz v1, :cond_e

    .line 11
    .line 12
    const/4 v1, 0x0

    .line 13
    iput-object v1, p0, Ldw0;->g:Ljava/util/List;

    .line 14
    .line 15
    :cond_e
    iget-object v1, p0, Ldw0;->i:Lqk0;

    .line 16
    .line 17
    invoke-virtual {v1, p1}, Lqk0;->j(Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    iget-object p0, p0, Ldw0;->j:Ljava/util/ArrayList;

    .line 21
    .line 22
    invoke-virtual {p0, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z
    :try_end_18
    .catchall {:try_start_3 .. :try_end_18} :catchall_1a

    .line 23
    .line 24
    .line 25
    monitor-exit v0

    .line 26
    return-void

    .line 27
    :catchall_1a
    move-exception p0

    .line 28
    monitor-exit v0

    .line 29
    throw p0
.end method
