.class public abstract Lau0;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# static fields
.field public static final a:Lxg0;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 1
    sget-object v0, Lil1;->g:Lel1;

    .line 2
    .line 3
    sget-object v1, Lil1;->i:Lgl1;

    .line 4
    .line 5
    invoke-static {}, Lgu0;->v()Lgu0;

    .line 6
    .line 7
    .line 8
    move-result-object v2

    .line 9
    new-instance v3, Lxg0;

    .line 10
    .line 11
    invoke-direct {v3, v0, v1, v2}, Lxg0;-><init>(Lil1;Lil1;Lgu0;)V

    .line 12
    .line 13
    .line 14
    sput-object v3, Lau0;->a:Lxg0;

    .line 15
    .line 16
    return-void
.end method
