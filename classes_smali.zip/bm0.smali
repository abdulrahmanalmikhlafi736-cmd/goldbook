.class public final Lbm0;
.super Llm0;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# instance fields
.field public final c:Lli0;

.field public final d:Lzh;

.field public final e:Lxf0;

.field public f:Lgm0;

.field public g:Lzs0;

.field public h:Z

.field public i:Z

.field public j:Z


# direct methods
.method public constructor <init>(Lli0;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Llm0;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lbm0;->c:Lli0;

    .line 5
    .line 6
    new-instance p1, Lzh;

    .line 7
    .line 8
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 9
    .line 10
    .line 11
    const/4 v0, 0x2

    .line 12
    new-array v1, v0, [J

    .line 13
    .line 14
    iput-object v1, p1, Lzh;->f:Ljava/lang/Object;

    .line 15
    .line 16
    iput-object p1, p0, Lbm0;->d:Lzh;

    .line 17
    .line 18
    new-instance p1, Lxf0;

    .line 19
    .line 20
    invoke-direct {p1, v0}, Lxf0;-><init>(I)V

    .line 21
    .line 22
    .line 23
    iput-object p1, p0, Lbm0;->e:Lxf0;

    .line 24
    .line 25
    const/4 p1, 0x1

    .line 26
    iput-boolean p1, p0, Lbm0;->i:Z

    .line 27
    .line 28
    iput-boolean p1, p0, Lbm0;->j:Z

    .line 29
    .line 30
    return-void
.end method


# virtual methods
.method public final a(Lxf0;Ln90;Le70;Z)Z
    .registers 61

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    move-object/from16 v2, p2

    .line 6
    .line 7
    move-object/from16 v3, p3

    .line 8
    .line 9
    invoke-super/range {p0 .. p4}, Llm0;->a(Lxf0;Ln90;Le70;Z)Z

    .line 10
    .line 11
    .line 12
    move-result v4

    .line 13
    iget-object v5, v0, Lbm0;->c:Lli0;

    .line 14
    .line 15
    iget-boolean v6, v5, Lli0;->r:Z

    .line 16
    .line 17
    const/4 v7, 0x1

    .line 18
    if-nez v6, :cond_14

    .line 19
    .line 20
    goto :goto_63

    .line 21
    :cond_14
    const/4 v8, 0x0

    .line 22
    :goto_15
    if-eqz v5, :cond_5f

    .line 23
    .line 24
    instance-of v10, v5, Lgt0;

    .line 25
    .line 26
    const/16 v11, 0x10

    .line 27
    .line 28
    if-eqz v10, :cond_26

    .line 29
    .line 30
    check-cast v5, Lgt0;

    .line 31
    .line 32
    invoke-static {v5, v11}, Lk70;->M(Lcp;I)Lgm0;

    .line 33
    .line 34
    .line 35
    move-result-object v5

    .line 36
    iput-object v5, v0, Lbm0;->f:Lgm0;

    .line 37
    .line 38
    goto :goto_5a

    .line 39
    :cond_26
    iget v10, v5, Lli0;->g:I

    .line 40
    .line 41
    and-int/2addr v10, v11

    .line 42
    if-eqz v10, :cond_5a

    .line 43
    .line 44
    instance-of v10, v5, Ldp;

    .line 45
    .line 46
    if-eqz v10, :cond_5a

    .line 47
    .line 48
    move-object v10, v5

    .line 49
    check-cast v10, Ldp;

    .line 50
    .line 51
    iget-object v10, v10, Ldp;->t:Lli0;

    .line 52
    .line 53
    const/4 v9, 0x0

    .line 54
    :goto_35
    if-eqz v10, :cond_57

    .line 55
    .line 56
    iget v12, v10, Lli0;->g:I

    .line 57
    .line 58
    and-int/2addr v12, v11

    .line 59
    if-eqz v12, :cond_54

    .line 60
    .line 61
    add-int/lit8 v9, v9, 0x1

    .line 62
    .line 63
    if-ne v9, v7, :cond_42

    .line 64
    .line 65
    move-object v5, v10

    .line 66
    goto :goto_54

    .line 67
    :cond_42
    if-nez v8, :cond_4b

    .line 68
    .line 69
    new-instance v8, Lqk0;

    .line 70
    .line 71
    new-array v12, v11, [Lli0;

    .line 72
    .line 73
    invoke-direct {v8, v12}, Lqk0;-><init>([Ljava/lang/Object;)V

    .line 74
    .line 75
    .line 76
    :cond_4b
    if-eqz v5, :cond_51

    .line 77
    .line 78
    invoke-virtual {v8, v5}, Lqk0;->b(Ljava/lang/Object;)V

    .line 79
    .line 80
    .line 81
    const/4 v5, 0x0

    .line 82
    :cond_51
    invoke-virtual {v8, v10}, Lqk0;->b(Ljava/lang/Object;)V

    .line 83
    .line 84
    .line 85
    :cond_54
    :goto_54
    iget-object v10, v10, Lli0;->j:Lli0;

    .line 86
    .line 87
    goto :goto_35

    .line 88
    :cond_57
    if-ne v9, v7, :cond_5a

    .line 89
    .line 90
    goto :goto_15

    .line 91
    :cond_5a
    :goto_5a
    invoke-static {v8}, Lk70;->m(Lqk0;)Lli0;

    .line 92
    .line 93
    .line 94
    move-result-object v5

    .line 95
    goto :goto_15

    .line 96
    :cond_5f
    iget-object v5, v0, Lbm0;->f:Lgm0;

    .line 97
    .line 98
    if-nez v5, :cond_64

    .line 99
    .line 100
    :goto_63
    return v7

    .line 101
    :cond_64
    invoke-virtual {v1}, Lxf0;->d()I

    .line 102
    .line 103
    .line 104
    move-result v5

    .line 105
    const/4 v8, 0x0

    .line 106
    :goto_69
    iget-object v10, v0, Lbm0;->d:Lzh;

    .line 107
    .line 108
    iget-object v11, v0, Lbm0;->e:Lxf0;

    .line 109
    .line 110
    if-ge v8, v5, :cond_1af

    .line 111
    .line 112
    invoke-virtual {v1, v8}, Lxf0;->a(I)J

    .line 113
    .line 114
    .line 115
    move-result-wide v12

    .line 116
    invoke-virtual {v1, v8}, Lxf0;->e(I)Ljava/lang/Object;

    .line 117
    .line 118
    .line 119
    move-result-object v14

    .line 120
    check-cast v14, Ldt0;

    .line 121
    .line 122
    invoke-virtual {v10, v12, v13}, Lzh;->c(J)Z

    .line 123
    .line 124
    .line 125
    move-result v10

    .line 126
    if-eqz v10, :cond_199

    .line 127
    .line 128
    move v15, v7

    .line 129
    const/16 v16, 0x0

    .line 130
    .line 131
    iget-wide v6, v14, Ldt0;->g:J

    .line 132
    .line 133
    iget-object v10, v14, Ldt0;->m:Ljava/util/ArrayList;

    .line 134
    .line 135
    move-object/from16 v17, v10

    .line 136
    .line 137
    iget-wide v9, v14, Ldt0;->c:J

    .line 138
    .line 139
    const-wide v18, 0x7fffffff7fffffffL

    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    and-long v20, v6, v18

    .line 145
    .line 146
    const-wide v22, 0x7fffff007fffffL

    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    add-long v20, v20, v22

    .line 152
    .line 153
    const-wide v24, -0x7fffffff80000000L  # -1.0609978955E-314

    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    and-long v20, v20, v24

    .line 159
    .line 160
    const-wide/16 v26, 0x0

    .line 161
    .line 162
    cmp-long v20, v20, v26

    .line 163
    .line 164
    if-nez v20, :cond_190

    .line 165
    .line 166
    and-long v20, v9, v18

    .line 167
    .line 168
    add-long v20, v20, v22

    .line 169
    .line 170
    and-long v20, v20, v24

    .line 171
    .line 172
    cmp-long v20, v20, v26

    .line 173
    .line 174
    if-nez v20, :cond_190

    .line 175
    .line 176
    move/from16 v20, v15

    .line 177
    .line 178
    new-instance v15, Ljava/util/ArrayList;

    .line 179
    .line 180
    sget-object v21, Lut;->e:Lut;

    .line 181
    .line 182
    if-nez v17, :cond_bc

    .line 183
    .line 184
    move-object/from16 v28, v21

    .line 185
    .line 186
    :goto_b9
    move/from16 v51, v4

    .line 187
    .line 188
    goto :goto_bf

    .line 189
    :cond_bc
    move-object/from16 v28, v17

    .line 190
    .line 191
    goto :goto_b9

    .line 192
    :goto_bf
    invoke-interface/range {v28 .. v28}, Ljava/util/List;->size()I

    .line 193
    .line 194
    .line 195
    move-result v4

    .line 196
    invoke-direct {v15, v4}, Ljava/util/ArrayList;-><init>(I)V

    .line 197
    .line 198
    .line 199
    if-nez v17, :cond_cd

    .line 200
    .line 201
    move-object/from16 v4, v21

    .line 202
    .line 203
    :goto_ca
    move/from16 v17, v5

    .line 204
    .line 205
    goto :goto_d0

    .line 206
    :cond_cd
    move-object/from16 v4, v17

    .line 207
    .line 208
    goto :goto_ca

    .line 209
    :goto_d0
    invoke-interface {v4}, Ljava/util/Collection;->size()I

    .line 210
    .line 211
    .line 212
    move-result v5

    .line 213
    move/from16 v21, v8

    .line 214
    .line 215
    const/4 v8, 0x0

    .line 216
    :goto_d7
    if-ge v8, v5, :cond_12c

    .line 217
    .line 218
    invoke-interface {v4, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 219
    .line 220
    .line 221
    move-result-object v28

    .line 222
    move-object/from16 v29, v4

    .line 223
    .line 224
    move-object/from16 v4, v28

    .line 225
    .line 226
    check-cast v4, La30;

    .line 227
    .line 228
    move-object/from16 v52, v11

    .line 229
    .line 230
    move-wide/from16 v53, v12

    .line 231
    .line 232
    iget-wide v11, v4, La30;->b:J

    .line 233
    .line 234
    and-long v30, v11, v18

    .line 235
    .line 236
    add-long v30, v30, v22

    .line 237
    .line 238
    and-long v30, v30, v24

    .line 239
    .line 240
    cmp-long v13, v30, v26

    .line 241
    .line 242
    if-nez v13, :cond_11b

    .line 243
    .line 244
    new-instance v30, La30;

    .line 245
    .line 246
    move-object/from16 v55, v14

    .line 247
    .line 248
    iget-wide v13, v4, La30;->a:J

    .line 249
    .line 250
    move/from16 v28, v5

    .line 251
    .line 252
    iget-object v5, v0, Lbm0;->f:Lgm0;

    .line 253
    .line 254
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 255
    .line 256
    .line 257
    invoke-virtual {v5, v2, v11, v12}, Lgm0;->x(Ln90;J)J

    .line 258
    .line 259
    .line 260
    move-result-wide v33

    .line 261
    iget v5, v4, La30;->c:F

    .line 262
    .line 263
    iget-wide v11, v4, La30;->d:J

    .line 264
    .line 265
    move/from16 v35, v5

    .line 266
    .line 267
    iget-wide v4, v4, La30;->e:J

    .line 268
    .line 269
    move-wide/from16 v38, v4

    .line 270
    .line 271
    move-wide/from16 v36, v11

    .line 272
    .line 273
    move-wide/from16 v31, v13

    .line 274
    .line 275
    invoke-direct/range {v30 .. v39}, La30;-><init>(JJFJJ)V

    .line 276
    .line 277
    .line 278
    move-object/from16 v4, v30

    .line 279
    .line 280
    invoke-virtual {v15, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 281
    .line 282
    .line 283
    goto :goto_11f

    .line 284
    :cond_11b
    move/from16 v28, v5

    .line 285
    .line 286
    move-object/from16 v55, v14

    .line 287
    .line 288
    :goto_11f
    add-int/lit8 v8, v8, 0x1

    .line 289
    .line 290
    move/from16 v5, v28

    .line 291
    .line 292
    move-object/from16 v4, v29

    .line 293
    .line 294
    move-object/from16 v11, v52

    .line 295
    .line 296
    move-wide/from16 v12, v53

    .line 297
    .line 298
    move-object/from16 v14, v55

    .line 299
    .line 300
    goto :goto_d7

    .line 301
    :cond_12c
    move-object/from16 v52, v11

    .line 302
    .line 303
    move-wide/from16 v53, v12

    .line 304
    .line 305
    move-object/from16 v55, v14

    .line 306
    .line 307
    iget-object v4, v0, Lbm0;->f:Lgm0;

    .line 308
    .line 309
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 310
    .line 311
    .line 312
    invoke-virtual {v4, v2, v6, v7}, Lgm0;->x(Ln90;J)J

    .line 313
    .line 314
    .line 315
    move-result-wide v39

    .line 316
    iget-object v4, v0, Lbm0;->f:Lgm0;

    .line 317
    .line 318
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 319
    .line 320
    .line 321
    invoke-virtual {v4, v2, v9, v10}, Lgm0;->x(Ln90;J)J

    .line 322
    .line 323
    .line 324
    move-result-wide v33

    .line 325
    iget-wide v4, v14, Ldt0;->a:J

    .line 326
    .line 327
    iget-wide v6, v14, Ldt0;->b:J

    .line 328
    .line 329
    iget-boolean v8, v14, Ldt0;->d:Z

    .line 330
    .line 331
    iget-wide v9, v14, Ldt0;->f:J

    .line 332
    .line 333
    iget-boolean v11, v14, Ldt0;->h:Z

    .line 334
    .line 335
    iget v12, v14, Ldt0;->i:I

    .line 336
    .line 337
    move-wide/from16 v29, v4

    .line 338
    .line 339
    iget-wide v4, v14, Ldt0;->j:J

    .line 340
    .line 341
    iget v13, v14, Ldt0;->e:F

    .line 342
    .line 343
    new-instance v28, Ldt0;

    .line 344
    .line 345
    iget v2, v14, Ldt0;->k:F

    .line 346
    .line 347
    move-wide/from16 v44, v4

    .line 348
    .line 349
    iget-wide v4, v14, Ldt0;->l:J

    .line 350
    .line 351
    move-wide/from16 v47, v4

    .line 352
    .line 353
    iget-wide v4, v14, Ldt0;->n:J

    .line 354
    .line 355
    move/from16 v46, v2

    .line 356
    .line 357
    move-wide/from16 v49, v4

    .line 358
    .line 359
    move-wide/from16 v31, v6

    .line 360
    .line 361
    move/from16 v35, v8

    .line 362
    .line 363
    move-wide/from16 v37, v9

    .line 364
    .line 365
    move/from16 v41, v11

    .line 366
    .line 367
    move/from16 v42, v12

    .line 368
    .line 369
    move/from16 v36, v13

    .line 370
    .line 371
    move-object/from16 v43, v15

    .line 372
    .line 373
    invoke-direct/range {v28 .. v50}, Ldt0;-><init>(JJJZFJJZILjava/util/ArrayList;JFJJ)V

    .line 374
    .line 375
    .line 376
    move-object/from16 v2, v28

    .line 377
    .line 378
    iget-object v4, v14, Ldt0;->q:Ldt0;

    .line 379
    .line 380
    if-nez v4, :cond_17e

    .line 381
    .line 382
    move-object v4, v14

    .line 383
    :cond_17e
    iput-object v4, v2, Ldt0;->q:Ldt0;

    .line 384
    .line 385
    iget-object v4, v14, Ldt0;->q:Ldt0;

    .line 386
    .line 387
    if-nez v4, :cond_185

    .line 388
    .line 389
    goto :goto_186

    .line 390
    :cond_185
    move-object v14, v4

    .line 391
    :goto_186
    iput-object v14, v2, Ldt0;->q:Ldt0;

    .line 392
    .line 393
    move-object/from16 v6, v52

    .line 394
    .line 395
    move-wide/from16 v4, v53

    .line 396
    .line 397
    invoke-virtual {v6, v4, v5, v2}, Lxf0;->b(JLjava/lang/Object;)V

    .line 398
    .line 399
    .line 400
    goto :goto_1a3

    .line 401
    :cond_190
    move/from16 v51, v4

    .line 402
    .line 403
    move/from16 v17, v5

    .line 404
    .line 405
    move/from16 v21, v8

    .line 406
    .line 407
    move/from16 v20, v15

    .line 408
    .line 409
    goto :goto_1a3

    .line 410
    :cond_199
    move/from16 v51, v4

    .line 411
    .line 412
    move/from16 v17, v5

    .line 413
    .line 414
    move/from16 v20, v7

    .line 415
    .line 416
    move/from16 v21, v8

    .line 417
    .line 418
    const/16 v16, 0x0

    .line 419
    .line 420
    :goto_1a3
    add-int/lit8 v8, v21, 0x1

    .line 421
    .line 422
    move-object/from16 v2, p2

    .line 423
    .line 424
    move/from16 v5, v17

    .line 425
    .line 426
    move/from16 v7, v20

    .line 427
    .line 428
    move/from16 v4, v51

    .line 429
    .line 430
    goto/16 :goto_69

    .line 431
    .line 432
    :cond_1af
    move/from16 v51, v4

    .line 433
    .line 434
    move/from16 v20, v7

    .line 435
    .line 436
    move-object v6, v11

    .line 437
    const/16 v16, 0x0

    .line 438
    .line 439
    invoke-virtual {v6}, Lxf0;->d()I

    .line 440
    .line 441
    .line 442
    move-result v2

    .line 443
    if-nez v2, :cond_1c5

    .line 444
    .line 445
    const/4 v2, 0x0

    .line 446
    iput v2, v10, Lzh;->e:I

    .line 447
    .line 448
    iget-object v0, v0, Llm0;->a:Lqk0;

    .line 449
    .line 450
    invoke-virtual {v0}, Lqk0;->g()V

    .line 451
    .line 452
    .line 453
    return v20

    .line 454
    :cond_1c5
    iget v2, v10, Lzh;->e:I

    .line 455
    .line 456
    add-int/lit8 v2, v2, -0x1

    .line 457
    .line 458
    :goto_1c9
    const/4 v4, -0x1

    .line 459
    if-ge v4, v2, :cond_222

    .line 460
    .line 461
    iget-object v5, v10, Lzh;->f:Ljava/lang/Object;

    .line 462
    .line 463
    check-cast v5, [J

    .line 464
    .line 465
    aget-wide v7, v5, v2

    .line 466
    .line 467
    iget-boolean v5, v1, Lxf0;->e:Z

    .line 468
    .line 469
    if-eqz v5, :cond_1fa

    .line 470
    .line 471
    iget v5, v1, Lxf0;->h:I

    .line 472
    .line 473
    iget-object v9, v1, Lxf0;->f:[J

    .line 474
    .line 475
    iget-object v11, v1, Lxf0;->g:[Ljava/lang/Object;

    .line 476
    .line 477
    const/4 v12, 0x0

    .line 478
    const/4 v13, 0x0

    .line 479
    :goto_1de
    if-ge v13, v5, :cond_1f5

    .line 480
    .line 481
    aget-object v14, v11, v13

    .line 482
    .line 483
    sget-object v15, Lk70;->o:Ljava/lang/Object;

    .line 484
    .line 485
    if-eq v14, v15, :cond_1f2

    .line 486
    .line 487
    if-eq v13, v12, :cond_1f0

    .line 488
    .line 489
    aget-wide v17, v9, v13

    .line 490
    .line 491
    aput-wide v17, v9, v12

    .line 492
    .line 493
    aput-object v14, v11, v12

    .line 494
    .line 495
    aput-object v16, v11, v13

    .line 496
    .line 497
    :cond_1f0
    add-int/lit8 v12, v12, 0x1

    .line 498
    .line 499
    :cond_1f2
    add-int/lit8 v13, v13, 0x1

    .line 500
    .line 501
    goto :goto_1de

    .line 502
    :cond_1f5
    const/4 v13, 0x0

    .line 503
    iput-boolean v13, v1, Lxf0;->e:Z

    .line 504
    .line 505
    iput v12, v1, Lxf0;->h:I

    .line 506
    .line 507
    :cond_1fa
    iget-object v5, v1, Lxf0;->f:[J

    .line 508
    .line 509
    iget v9, v1, Lxf0;->h:I

    .line 510
    .line 511
    invoke-static {v5, v9, v7, v8}, Lk70;->s([JIJ)I

    .line 512
    .line 513
    .line 514
    move-result v5

    .line 515
    if-ltz v5, :cond_205

    .line 516
    .line 517
    goto :goto_21f

    .line 518
    :cond_205
    iget v5, v10, Lzh;->e:I

    .line 519
    .line 520
    if-ge v2, v5, :cond_21f

    .line 521
    .line 522
    add-int/lit8 v5, v5, -0x1

    .line 523
    .line 524
    move v7, v2

    .line 525
    :goto_20c
    if-ge v7, v5, :cond_21a

    .line 526
    .line 527
    iget-object v8, v10, Lzh;->f:Ljava/lang/Object;

    .line 528
    .line 529
    check-cast v8, [J

    .line 530
    .line 531
    add-int/lit8 v9, v7, 0x1

    .line 532
    .line 533
    aget-wide v11, v8, v9

    .line 534
    .line 535
    aput-wide v11, v8, v7

    .line 536
    .line 537
    move v7, v9

    .line 538
    goto :goto_20c

    .line 539
    :cond_21a
    iget v5, v10, Lzh;->e:I

    .line 540
    .line 541
    add-int/2addr v5, v4

    .line 542
    iput v5, v10, Lzh;->e:I

    .line 543
    .line 544
    :cond_21f
    :goto_21f
    add-int/lit8 v2, v2, -0x1

    .line 545
    .line 546
    goto :goto_1c9

    .line 547
    :cond_222
    new-instance v1, Ljava/util/ArrayList;

    .line 548
    .line 549
    invoke-virtual {v6}, Lxf0;->d()I

    .line 550
    .line 551
    .line 552
    move-result v2

    .line 553
    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(I)V

    .line 554
    .line 555
    .line 556
    invoke-virtual {v6}, Lxf0;->d()I

    .line 557
    .line 558
    .line 559
    move-result v2

    .line 560
    const/4 v4, 0x0

    .line 561
    :goto_230
    if-ge v4, v2, :cond_23c

    .line 562
    .line 563
    invoke-virtual {v6, v4}, Lxf0;->e(I)Ljava/lang/Object;

    .line 564
    .line 565
    .line 566
    move-result-object v5

    .line 567
    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 568
    .line 569
    .line 570
    add-int/lit8 v4, v4, 0x1

    .line 571
    .line 572
    goto :goto_230

    .line 573
    :cond_23c
    new-instance v2, Lzs0;

    .line 574
    .line 575
    invoke-direct {v2, v1, v3}, Lzs0;-><init>(Ljava/util/List;Le70;)V

    .line 576
    .line 577
    .line 578
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 579
    .line 580
    .line 581
    move-result v4

    .line 582
    const/4 v5, 0x0

    .line 583
    :goto_246
    if-ge v5, v4, :cond_25b

    .line 584
    .line 585
    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 586
    .line 587
    .line 588
    move-result-object v6

    .line 589
    move-object v7, v6

    .line 590
    check-cast v7, Ldt0;

    .line 591
    .line 592
    iget-wide v7, v7, Ldt0;->a:J

    .line 593
    .line 594
    invoke-virtual {v3, v7, v8}, Le70;->a(J)Z

    .line 595
    .line 596
    .line 597
    move-result v7

    .line 598
    if-eqz v7, :cond_258

    .line 599
    .line 600
    goto :goto_25d

    .line 601
    :cond_258
    add-int/lit8 v5, v5, 0x1

    .line 602
    .line 603
    goto :goto_246

    .line 604
    :cond_25b
    move-object/from16 v6, v16

    .line 605
    .line 606
    :goto_25d
    check-cast v6, Ldt0;

    .line 607
    .line 608
    const/4 v1, 0x3

    .line 609
    if-eqz v6, :cond_2ef

    .line 610
    .line 611
    iget-boolean v3, v6, Ldt0;->d:Z

    .line 612
    .line 613
    if-nez p4, :cond_26a

    .line 614
    .line 615
    const/4 v13, 0x0

    .line 616
    iput-boolean v13, v0, Lbm0;->i:Z

    .line 617
    .line 618
    goto :goto_2c1

    .line 619
    :cond_26a
    const/4 v13, 0x0

    .line 620
    iget-boolean v4, v0, Lbm0;->i:Z

    .line 621
    .line 622
    if-nez v4, :cond_2c1

    .line 623
    .line 624
    if-nez v3, :cond_275

    .line 625
    .line 626
    iget-boolean v4, v6, Ldt0;->h:Z

    .line 627
    .line 628
    if-eqz v4, :cond_2c1

    .line 629
    .line 630
    :cond_275
    iget-object v4, v0, Lbm0;->f:Lgm0;

    .line 631
    .line 632
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 633
    .line 634
    .line 635
    iget-wide v4, v4, Lks0;->g:J

    .line 636
    .line 637
    iget-wide v6, v6, Ldt0;->c:J

    .line 638
    .line 639
    const/16 v8, 0x20

    .line 640
    .line 641
    shr-long v9, v6, v8

    .line 642
    .line 643
    long-to-int v9, v9

    .line 644
    invoke-static {v9}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 645
    .line 646
    .line 647
    move-result v9

    .line 648
    const-wide v10, 0xffffffffL

    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    and-long/2addr v6, v10

    .line 654
    long-to-int v6, v6

    .line 655
    invoke-static {v6}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 656
    .line 657
    .line 658
    move-result v6

    .line 659
    shr-long v7, v4, v8

    .line 660
    .line 661
    long-to-int v7, v7

    .line 662
    and-long/2addr v4, v10

    .line 663
    long-to-int v4, v4

    .line 664
    const/4 v5, 0x0

    .line 665
    cmpg-float v8, v9, v5

    .line 666
    .line 667
    if-gez v8, :cond_29f

    .line 668
    .line 669
    move/from16 v8, v20

    .line 670
    .line 671
    goto :goto_2a0

    .line 672
    :cond_29f
    move v8, v13

    .line 673
    :goto_2a0
    int-to-float v7, v7

    .line 674
    cmpl-float v7, v9, v7

    .line 675
    .line 676
    if-lez v7, :cond_2a8

    .line 677
    .line 678
    move/from16 v7, v20

    .line 679
    .line 680
    goto :goto_2a9

    .line 681
    :cond_2a8
    move v7, v13

    .line 682
    :goto_2a9
    or-int/2addr v7, v8

    .line 683
    cmpg-float v5, v6, v5

    .line 684
    .line 685
    if-gez v5, :cond_2b1

    .line 686
    .line 687
    move/from16 v5, v20

    .line 688
    .line 689
    goto :goto_2b2

    .line 690
    :cond_2b1
    move v5, v13

    .line 691
    :goto_2b2
    or-int/2addr v5, v7

    .line 692
    int-to-float v4, v4

    .line 693
    cmpl-float v4, v6, v4

    .line 694
    .line 695
    if-lez v4, :cond_2bb

    .line 696
    .line 697
    move/from16 v4, v20

    .line 698
    .line 699
    goto :goto_2bc

    .line 700
    :cond_2bb
    move v4, v13

    .line 701
    :goto_2bc
    or-int/2addr v4, v5

    .line 702
    xor-int/lit8 v4, v4, 0x1

    .line 703
    .line 704
    iput-boolean v4, v0, Lbm0;->i:Z

    .line 705
    .line 706
    :cond_2c1
    :goto_2c1
    iget-boolean v4, v0, Lbm0;->i:Z

    .line 707
    .line 708
    iget-boolean v5, v0, Lbm0;->h:Z

    .line 709
    .line 710
    const/4 v6, 0x5

    .line 711
    const/4 v7, 0x4

    .line 712
    if-eq v4, v5, :cond_2d9

    .line 713
    .line 714
    iget v8, v2, Lzs0;->c:I

    .line 715
    .line 716
    if-ne v8, v1, :cond_2ce

    .line 717
    .line 718
    goto :goto_2d3

    .line 719
    :cond_2ce
    if-ne v8, v7, :cond_2d1

    .line 720
    .line 721
    goto :goto_2d3

    .line 722
    :cond_2d1
    if-ne v8, v6, :cond_2d9

    .line 723
    .line 724
    :goto_2d3
    if-eqz v4, :cond_2d6

    .line 725
    .line 726
    move v6, v7

    .line 727
    :cond_2d6
    iput v6, v2, Lzs0;->c:I

    .line 728
    .line 729
    goto :goto_2f0

    .line 730
    :cond_2d9
    iget v8, v2, Lzs0;->c:I

    .line 731
    .line 732
    if-ne v8, v7, :cond_2e6

    .line 733
    .line 734
    if-eqz v5, :cond_2e6

    .line 735
    .line 736
    iget-boolean v5, v0, Lbm0;->j:Z

    .line 737
    .line 738
    if-nez v5, :cond_2e6

    .line 739
    .line 740
    iput v1, v2, Lzs0;->c:I

    .line 741
    .line 742
    goto :goto_2f0

    .line 743
    :cond_2e6
    if-ne v8, v6, :cond_2f0

    .line 744
    .line 745
    if-eqz v4, :cond_2f0

    .line 746
    .line 747
    if-eqz v3, :cond_2f0

    .line 748
    .line 749
    iput v1, v2, Lzs0;->c:I

    .line 750
    .line 751
    goto :goto_2f0

    .line 752
    :cond_2ef
    const/4 v13, 0x0

    .line 753
    :cond_2f0
    :goto_2f0
    if-nez v51, :cond_32c

    .line 754
    .line 755
    iget v3, v2, Lzs0;->c:I

    .line 756
    .line 757
    if-ne v3, v1, :cond_32c

    .line 758
    .line 759
    iget-object v1, v0, Lbm0;->g:Lzs0;

    .line 760
    .line 761
    if-eqz v1, :cond_32c

    .line 762
    .line 763
    iget-object v1, v1, Lzs0;->a:Ljava/util/List;

    .line 764
    .line 765
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 766
    .line 767
    .line 768
    move-result v3

    .line 769
    iget-object v4, v2, Lzs0;->a:Ljava/util/List;

    .line 770
    .line 771
    invoke-interface {v4}, Ljava/util/List;->size()I

    .line 772
    .line 773
    .line 774
    move-result v5

    .line 775
    if-eq v3, v5, :cond_309

    .line 776
    .line 777
    goto :goto_32c

    .line 778
    :cond_309
    invoke-interface {v4}, Ljava/util/List;->size()I

    .line 779
    .line 780
    .line 781
    move-result v3

    .line 782
    move v5, v13

    .line 783
    :goto_30e
    if-ge v5, v3, :cond_32a

    .line 784
    .line 785
    invoke-interface {v1, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 786
    .line 787
    .line 788
    move-result-object v6

    .line 789
    check-cast v6, Ldt0;

    .line 790
    .line 791
    invoke-interface {v4, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 792
    .line 793
    .line 794
    move-result-object v7

    .line 795
    check-cast v7, Ldt0;

    .line 796
    .line 797
    iget-wide v8, v6, Ldt0;->c:J

    .line 798
    .line 799
    iget-wide v6, v7, Ldt0;->c:J

    .line 800
    .line 801
    invoke-static {v8, v9, v6, v7}, Lxm0;->b(JJ)Z

    .line 802
    .line 803
    .line 804
    move-result v6

    .line 805
    if-nez v6, :cond_327

    .line 806
    .line 807
    goto :goto_32c

    .line 808
    :cond_327
    add-int/lit8 v5, v5, 0x1

    .line 809
    .line 810
    goto :goto_30e

    .line 811
    :cond_32a
    move v7, v13

    .line 812
    goto :goto_32e

    .line 813
    :cond_32c
    :goto_32c
    move/from16 v7, v20

    .line 814
    .line 815
    :goto_32e
    iput-object v2, v0, Lbm0;->g:Lzs0;

    .line 816
    .line 817
    return v7
.end method

.method public final b(Le70;)V
    .registers 12

    .line 1
    invoke-super {p0, p1}, Llm0;->b(Le70;)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lbm0;->g:Lzs0;

    .line 5
    .line 6
    if-nez v0, :cond_8

    .line 7
    .line 8
    return-void

    .line 9
    :cond_8
    iget-boolean v1, p0, Lbm0;->i:Z

    .line 10
    .line 11
    iput-boolean v1, p0, Lbm0;->h:Z

    .line 12
    .line 13
    iget-object v1, v0, Lzs0;->a:Ljava/util/List;

    .line 14
    .line 15
    invoke-interface {v1}, Ljava/util/Collection;->size()I

    .line 16
    .line 17
    .line 18
    move-result v2

    .line 19
    const/4 v3, 0x0

    .line 20
    move v4, v3

    .line 21
    :goto_14
    if-ge v4, v2, :cond_36

    .line 22
    .line 23
    invoke-interface {v1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object v5

    .line 27
    check-cast v5, Ldt0;

    .line 28
    .line 29
    iget-boolean v6, v5, Ldt0;->d:Z

    .line 30
    .line 31
    iget-wide v7, v5, Ldt0;->a:J

    .line 32
    .line 33
    invoke-virtual {p1, v7, v8}, Le70;->a(J)Z

    .line 34
    .line 35
    .line 36
    move-result v5

    .line 37
    iget-boolean v9, p0, Lbm0;->i:Z

    .line 38
    .line 39
    if-nez v6, :cond_2a

    .line 40
    .line 41
    if-eqz v5, :cond_2e

    .line 42
    .line 43
    :cond_2a
    if-nez v6, :cond_33

    .line 44
    .line 45
    if-nez v9, :cond_33

    .line 46
    .line 47
    :cond_2e
    iget-object v5, p0, Lbm0;->d:Lzh;

    .line 48
    .line 49
    invoke-virtual {v5, v7, v8}, Lzh;->g(J)V

    .line 50
    .line 51
    .line 52
    :cond_33
    add-int/lit8 v4, v4, 0x1

    .line 53
    .line 54
    goto :goto_14

    .line 55
    :cond_36
    iput-boolean v3, p0, Lbm0;->i:Z

    .line 56
    .line 57
    iget p1, v0, Lzs0;->c:I

    .line 58
    .line 59
    const/4 v0, 0x5

    .line 60
    if-ne p1, v0, :cond_3e

    .line 61
    .line 62
    const/4 v3, 0x1

    .line 63
    :cond_3e
    iput-boolean v3, p0, Lbm0;->j:Z

    .line 64
    .line 65
    return-void
.end method

.method public final c()V
    .registers 9

    .line 1
    iget-object v0, p0, Llm0;->a:Lqk0;

    .line 2
    .line 3
    iget-object v1, v0, Lqk0;->e:[Ljava/lang/Object;

    .line 4
    .line 5
    iget v0, v0, Lqk0;->g:I

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    move v3, v2

    .line 9
    :goto_8
    if-ge v3, v0, :cond_14

    .line 10
    .line 11
    aget-object v4, v1, v3

    .line 12
    .line 13
    check-cast v4, Lbm0;

    .line 14
    .line 15
    invoke-virtual {v4}, Lbm0;->c()V

    .line 16
    .line 17
    .line 18
    add-int/lit8 v3, v3, 0x1

    .line 19
    .line 20
    goto :goto_8

    .line 21
    :cond_14
    const/4 v0, 0x0

    .line 22
    iget-object p0, p0, Lbm0;->c:Lli0;

    .line 23
    .line 24
    move-object v1, v0

    .line 25
    :goto_18
    if-eqz p0, :cond_60

    .line 26
    .line 27
    instance-of v3, p0, Lgt0;

    .line 28
    .line 29
    if-eqz v3, :cond_24

    .line 30
    .line 31
    check-cast p0, Lgt0;

    .line 32
    .line 33
    invoke-interface {p0}, Lgt0;->R()V

    .line 34
    .line 35
    .line 36
    goto :goto_5b

    .line 37
    :cond_24
    iget v3, p0, Lli0;->g:I

    .line 38
    .line 39
    const/16 v4, 0x10

    .line 40
    .line 41
    and-int/2addr v3, v4

    .line 42
    if-eqz v3, :cond_5b

    .line 43
    .line 44
    instance-of v3, p0, Ldp;

    .line 45
    .line 46
    if-eqz v3, :cond_5b

    .line 47
    .line 48
    move-object v3, p0

    .line 49
    check-cast v3, Ldp;

    .line 50
    .line 51
    iget-object v3, v3, Ldp;->t:Lli0;

    .line 52
    .line 53
    move v5, v2

    .line 54
    :goto_35
    const/4 v6, 0x1

    .line 55
    if-eqz v3, :cond_58

    .line 56
    .line 57
    iget v7, v3, Lli0;->g:I

    .line 58
    .line 59
    and-int/2addr v7, v4

    .line 60
    if-eqz v7, :cond_55

    .line 61
    .line 62
    add-int/lit8 v5, v5, 0x1

    .line 63
    .line 64
    if-ne v5, v6, :cond_43

    .line 65
    .line 66
    move-object p0, v3

    .line 67
    goto :goto_55

    .line 68
    :cond_43
    if-nez v1, :cond_4c

    .line 69
    .line 70
    new-instance v1, Lqk0;

    .line 71
    .line 72
    new-array v6, v4, [Lli0;

    .line 73
    .line 74
    invoke-direct {v1, v6}, Lqk0;-><init>([Ljava/lang/Object;)V

    .line 75
    .line 76
    .line 77
    :cond_4c
    if-eqz p0, :cond_52

    .line 78
    .line 79
    invoke-virtual {v1, p0}, Lqk0;->b(Ljava/lang/Object;)V

    .line 80
    .line 81
    .line 82
    move-object p0, v0

    .line 83
    :cond_52
    invoke-virtual {v1, v3}, Lqk0;->b(Ljava/lang/Object;)V

    .line 84
    .line 85
    .line 86
    :cond_55
    :goto_55
    iget-object v3, v3, Lli0;->j:Lli0;

    .line 87
    .line 88
    goto :goto_35

    .line 89
    :cond_58
    if-ne v5, v6, :cond_5b

    .line 90
    .line 91
    goto :goto_18

    .line 92
    :cond_5b
    :goto_5b
    invoke-static {v1}, Lk70;->m(Lqk0;)Lli0;

    .line 93
    .line 94
    .line 95
    move-result-object p0

    .line 96
    goto :goto_18

    .line 97
    :cond_60
    return-void
.end method

.method public final d(Le70;)Z
    .registers 16

    .line 1
    iget-object v0, p0, Lbm0;->e:Lxf0;

    .line 2
    .line 3
    invoke-virtual {v0}, Lxf0;->d()I

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    const/4 v2, 0x0

    .line 8
    const/4 v3, 0x0

    .line 9
    if-nez v1, :cond_d

    .line 10
    .line 11
    :goto_a
    move v9, v3

    .line 12
    goto/16 :goto_a3

    .line 13
    .line 14
    :cond_d
    iget-object v1, p0, Lbm0;->c:Lli0;

    .line 15
    .line 16
    iget-boolean v4, v1, Lli0;->r:Z

    .line 17
    .line 18
    if-nez v4, :cond_14

    .line 19
    .line 20
    goto :goto_a

    .line 21
    :cond_14
    iget-object v4, v1, Lli0;->l:Lgm0;

    .line 22
    .line 23
    if-eqz v4, :cond_21

    .line 24
    .line 25
    iget-object v4, v4, Lgm0;->s:Lba0;

    .line 26
    .line 27
    if-eqz v4, :cond_21

    .line 28
    .line 29
    invoke-virtual {v4}, Lba0;->I()Z

    .line 30
    .line 31
    .line 32
    move-result v4

    .line 33
    goto :goto_22

    .line 34
    :cond_21
    move v4, v3

    .line 35
    :goto_22
    if-nez v4, :cond_25

    .line 36
    .line 37
    goto :goto_a

    .line 38
    :cond_25
    iget-object v4, p0, Lbm0;->g:Lzs0;

    .line 39
    .line 40
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 41
    .line 42
    .line 43
    iget-object v5, p0, Lbm0;->f:Lgm0;

    .line 44
    .line 45
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 46
    .line 47
    .line 48
    iget-wide v5, v5, Lks0;->g:J

    .line 49
    .line 50
    move-object v7, v1

    .line 51
    move-object v8, v2

    .line 52
    :goto_33
    const/4 v9, 0x1

    .line 53
    if-eqz v7, :cond_8c

    .line 54
    .line 55
    instance-of v10, v7, Lgt0;

    .line 56
    .line 57
    if-eqz v10, :cond_44

    .line 58
    .line 59
    move-object v10, v7

    .line 60
    check-cast v10, Lgt0;

    .line 61
    .line 62
    sget-object v11, Lat0;->g:Lat0;

    .line 63
    .line 64
    invoke-interface {v10, v4, v11, v5, v6}, Lgt0;->x(Lzs0;Lat0;J)V

    .line 65
    .line 66
    .line 67
    move v10, v3

    .line 68
    goto :goto_45

    .line 69
    :cond_44
    move v10, v9

    .line 70
    :goto_45
    if-eqz v10, :cond_87

    .line 71
    .line 72
    iget v10, v7, Lli0;->g:I

    .line 73
    .line 74
    const/16 v11, 0x10

    .line 75
    .line 76
    and-int/2addr v10, v11

    .line 77
    if-eqz v10, :cond_50

    .line 78
    .line 79
    move v10, v9

    .line 80
    goto :goto_51

    .line 81
    :cond_50
    move v10, v3

    .line 82
    :goto_51
    if-eqz v10, :cond_87

    .line 83
    .line 84
    instance-of v10, v7, Ldp;

    .line 85
    .line 86
    if-eqz v10, :cond_87

    .line 87
    .line 88
    move-object v10, v7

    .line 89
    check-cast v10, Ldp;

    .line 90
    .line 91
    iget-object v10, v10, Ldp;->t:Lli0;

    .line 92
    .line 93
    move v12, v3

    .line 94
    :goto_5d
    if-eqz v10, :cond_84

    .line 95
    .line 96
    iget v13, v10, Lli0;->g:I

    .line 97
    .line 98
    and-int/2addr v13, v11

    .line 99
    if-eqz v13, :cond_66

    .line 100
    .line 101
    move v13, v9

    .line 102
    goto :goto_67

    .line 103
    :cond_66
    move v13, v3

    .line 104
    :goto_67
    if-eqz v13, :cond_81

    .line 105
    .line 106
    add-int/lit8 v12, v12, 0x1

    .line 107
    .line 108
    if-ne v12, v9, :cond_6f

    .line 109
    .line 110
    move-object v7, v10

    .line 111
    goto :goto_81

    .line 112
    :cond_6f
    if-nez v8, :cond_78

    .line 113
    .line 114
    new-instance v8, Lqk0;

    .line 115
    .line 116
    new-array v13, v11, [Lli0;

    .line 117
    .line 118
    invoke-direct {v8, v13}, Lqk0;-><init>([Ljava/lang/Object;)V

    .line 119
    .line 120
    .line 121
    :cond_78
    if-eqz v7, :cond_7e

    .line 122
    .line 123
    invoke-virtual {v8, v7}, Lqk0;->b(Ljava/lang/Object;)V

    .line 124
    .line 125
    .line 126
    move-object v7, v2

    .line 127
    :cond_7e
    invoke-virtual {v8, v10}, Lqk0;->b(Ljava/lang/Object;)V

    .line 128
    .line 129
    .line 130
    :cond_81
    :goto_81
    iget-object v10, v10, Lli0;->j:Lli0;

    .line 131
    .line 132
    goto :goto_5d

    .line 133
    :cond_84
    if-ne v12, v9, :cond_87

    .line 134
    .line 135
    goto :goto_33

    .line 136
    :cond_87
    invoke-static {v8}, Lk70;->m(Lqk0;)Lli0;

    .line 137
    .line 138
    .line 139
    move-result-object v7

    .line 140
    goto :goto_33

    .line 141
    :cond_8c
    iget-boolean v1, v1, Lli0;->r:Z

    .line 142
    .line 143
    if-eqz v1, :cond_a3

    .line 144
    .line 145
    iget-object v1, p0, Llm0;->a:Lqk0;

    .line 146
    .line 147
    iget-object v4, v1, Lqk0;->e:[Ljava/lang/Object;

    .line 148
    .line 149
    iget v1, v1, Lqk0;->g:I

    .line 150
    .line 151
    move v5, v3

    .line 152
    :goto_97
    if-ge v5, v1, :cond_a3

    .line 153
    .line 154
    aget-object v6, v4, v5

    .line 155
    .line 156
    check-cast v6, Lbm0;

    .line 157
    .line 158
    invoke-virtual {v6, p1}, Lbm0;->d(Le70;)Z

    .line 159
    .line 160
    .line 161
    add-int/lit8 v5, v5, 0x1

    .line 162
    .line 163
    goto :goto_97

    .line 164
    :cond_a3
    :goto_a3
    invoke-virtual {p0, p1}, Lbm0;->b(Le70;)V

    .line 165
    .line 166
    .line 167
    iget p1, v0, Lxf0;->h:I

    .line 168
    .line 169
    iget-object v1, v0, Lxf0;->g:[Ljava/lang/Object;

    .line 170
    .line 171
    move v4, v3

    .line 172
    :goto_ab
    if-ge v4, p1, :cond_b2

    .line 173
    .line 174
    aput-object v2, v1, v4

    .line 175
    .line 176
    add-int/lit8 v4, v4, 0x1

    .line 177
    .line 178
    goto :goto_ab

    .line 179
    :cond_b2
    iput v3, v0, Lxf0;->h:I

    .line 180
    .line 181
    iput-boolean v3, v0, Lxf0;->e:Z

    .line 182
    .line 183
    iput-object v2, p0, Lbm0;->f:Lgm0;

    .line 184
    .line 185
    return v9
.end method

.method public final e(Le70;Z)Z
    .registers 16

    .line 1
    iget-object v0, p0, Lbm0;->e:Lxf0;

    .line 2
    .line 3
    invoke-virtual {v0}, Lxf0;->d()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const/4 v1, 0x0

    .line 8
    if-nez v0, :cond_a

    .line 9
    .line 10
    return v1

    .line 11
    :cond_a
    iget-object v0, p0, Lbm0;->c:Lli0;

    .line 12
    .line 13
    iget-boolean v2, v0, Lli0;->r:Z

    .line 14
    .line 15
    if-nez v2, :cond_11

    .line 16
    .line 17
    goto :goto_21

    .line 18
    :cond_11
    iget-object v2, v0, Lli0;->l:Lgm0;

    .line 19
    .line 20
    if-eqz v2, :cond_1e

    .line 21
    .line 22
    iget-object v2, v2, Lgm0;->s:Lba0;

    .line 23
    .line 24
    if-eqz v2, :cond_1e

    .line 25
    .line 26
    invoke-virtual {v2}, Lba0;->I()Z

    .line 27
    .line 28
    .line 29
    move-result v2

    .line 30
    goto :goto_1f

    .line 31
    :cond_1e
    move v2, v1

    .line 32
    :goto_1f
    if-nez v2, :cond_22

    .line 33
    .line 34
    :goto_21
    return v1

    .line 35
    :cond_22
    iget-object v2, p0, Lbm0;->g:Lzs0;

    .line 36
    .line 37
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 38
    .line 39
    .line 40
    iget-object v3, p0, Lbm0;->f:Lgm0;

    .line 41
    .line 42
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 43
    .line 44
    .line 45
    iget-wide v3, v3, Lks0;->g:J

    .line 46
    .line 47
    const/4 v5, 0x0

    .line 48
    move-object v6, v0

    .line 49
    move-object v7, v5

    .line 50
    :goto_31
    const/16 v8, 0x10

    .line 51
    .line 52
    const/4 v9, 0x1

    .line 53
    if-eqz v6, :cond_8a

    .line 54
    .line 55
    instance-of v10, v6, Lgt0;

    .line 56
    .line 57
    if-eqz v10, :cond_44

    .line 58
    .line 59
    move-object v10, v6

    .line 60
    check-cast v10, Lgt0;

    .line 61
    .line 62
    sget-object v11, Lat0;->e:Lat0;

    .line 63
    .line 64
    invoke-interface {v10, v2, v11, v3, v4}, Lgt0;->x(Lzs0;Lat0;J)V

    .line 65
    .line 66
    .line 67
    move v10, v1

    .line 68
    goto :goto_45

    .line 69
    :cond_44
    move v10, v9

    .line 70
    :goto_45
    if-eqz v10, :cond_85

    .line 71
    .line 72
    iget v10, v6, Lli0;->g:I

    .line 73
    .line 74
    and-int/2addr v10, v8

    .line 75
    if-eqz v10, :cond_4e

    .line 76
    .line 77
    move v10, v9

    .line 78
    goto :goto_4f

    .line 79
    :cond_4e
    move v10, v1

    .line 80
    :goto_4f
    if-eqz v10, :cond_85

    .line 81
    .line 82
    instance-of v10, v6, Ldp;

    .line 83
    .line 84
    if-eqz v10, :cond_85

    .line 85
    .line 86
    move-object v10, v6

    .line 87
    check-cast v10, Ldp;

    .line 88
    .line 89
    iget-object v10, v10, Ldp;->t:Lli0;

    .line 90
    .line 91
    move v11, v1

    .line 92
    :goto_5b
    if-eqz v10, :cond_82

    .line 93
    .line 94
    iget v12, v10, Lli0;->g:I

    .line 95
    .line 96
    and-int/2addr v12, v8

    .line 97
    if-eqz v12, :cond_64

    .line 98
    .line 99
    move v12, v9

    .line 100
    goto :goto_65

    .line 101
    :cond_64
    move v12, v1

    .line 102
    :goto_65
    if-eqz v12, :cond_7f

    .line 103
    .line 104
    add-int/lit8 v11, v11, 0x1

    .line 105
    .line 106
    if-ne v11, v9, :cond_6d

    .line 107
    .line 108
    move-object v6, v10

    .line 109
    goto :goto_7f

    .line 110
    :cond_6d
    if-nez v7, :cond_76

    .line 111
    .line 112
    new-instance v7, Lqk0;

    .line 113
    .line 114
    new-array v12, v8, [Lli0;

    .line 115
    .line 116
    invoke-direct {v7, v12}, Lqk0;-><init>([Ljava/lang/Object;)V

    .line 117
    .line 118
    .line 119
    :cond_76
    if-eqz v6, :cond_7c

    .line 120
    .line 121
    invoke-virtual {v7, v6}, Lqk0;->b(Ljava/lang/Object;)V

    .line 122
    .line 123
    .line 124
    move-object v6, v5

    .line 125
    :cond_7c
    invoke-virtual {v7, v10}, Lqk0;->b(Ljava/lang/Object;)V

    .line 126
    .line 127
    .line 128
    :cond_7f
    :goto_7f
    iget-object v10, v10, Lli0;->j:Lli0;

    .line 129
    .line 130
    goto :goto_5b

    .line 131
    :cond_82
    if-ne v11, v9, :cond_85

    .line 132
    .line 133
    goto :goto_31

    .line 134
    :cond_85
    invoke-static {v7}, Lk70;->m(Lqk0;)Lli0;

    .line 135
    .line 136
    .line 137
    move-result-object v6

    .line 138
    goto :goto_31

    .line 139
    :cond_8a
    iget-boolean v6, v0, Lli0;->r:Z

    .line 140
    .line 141
    if-eqz v6, :cond_a6

    .line 142
    .line 143
    iget-object v6, p0, Llm0;->a:Lqk0;

    .line 144
    .line 145
    iget-object v7, v6, Lqk0;->e:[Ljava/lang/Object;

    .line 146
    .line 147
    iget v6, v6, Lqk0;->g:I

    .line 148
    .line 149
    move v10, v1

    .line 150
    :goto_95
    if-ge v10, v6, :cond_a6

    .line 151
    .line 152
    aget-object v11, v7, v10

    .line 153
    .line 154
    check-cast v11, Lbm0;

    .line 155
    .line 156
    iget-object v12, p0, Lbm0;->f:Lgm0;

    .line 157
    .line 158
    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 159
    .line 160
    .line 161
    invoke-virtual {v11, p1, p2}, Lbm0;->e(Le70;Z)Z

    .line 162
    .line 163
    .line 164
    add-int/lit8 v10, v10, 0x1

    .line 165
    .line 166
    goto :goto_95

    .line 167
    :cond_a6
    iget-boolean p0, v0, Lli0;->r:Z

    .line 168
    .line 169
    if-eqz p0, :cond_101

    .line 170
    .line 171
    move-object p0, v5

    .line 172
    :goto_ab
    if-eqz v0, :cond_101

    .line 173
    .line 174
    instance-of p1, v0, Lgt0;

    .line 175
    .line 176
    if-eqz p1, :cond_bb

    .line 177
    .line 178
    move-object p1, v0

    .line 179
    check-cast p1, Lgt0;

    .line 180
    .line 181
    sget-object p2, Lat0;->f:Lat0;

    .line 182
    .line 183
    invoke-interface {p1, v2, p2, v3, v4}, Lgt0;->x(Lzs0;Lat0;J)V

    .line 184
    .line 185
    .line 186
    move p1, v1

    .line 187
    goto :goto_bc

    .line 188
    :cond_bb
    move p1, v9

    .line 189
    :goto_bc
    if-eqz p1, :cond_fc

    .line 190
    .line 191
    iget p1, v0, Lli0;->g:I

    .line 192
    .line 193
    and-int/2addr p1, v8

    .line 194
    if-eqz p1, :cond_c5

    .line 195
    .line 196
    move p1, v9

    .line 197
    goto :goto_c6

    .line 198
    :cond_c5
    move p1, v1

    .line 199
    :goto_c6
    if-eqz p1, :cond_fc

    .line 200
    .line 201
    instance-of p1, v0, Ldp;

    .line 202
    .line 203
    if-eqz p1, :cond_fc

    .line 204
    .line 205
    move-object p1, v0

    .line 206
    check-cast p1, Ldp;

    .line 207
    .line 208
    iget-object p1, p1, Ldp;->t:Lli0;

    .line 209
    .line 210
    move p2, v1

    .line 211
    :goto_d2
    if-eqz p1, :cond_f9

    .line 212
    .line 213
    iget v6, p1, Lli0;->g:I

    .line 214
    .line 215
    and-int/2addr v6, v8

    .line 216
    if-eqz v6, :cond_db

    .line 217
    .line 218
    move v6, v9

    .line 219
    goto :goto_dc

    .line 220
    :cond_db
    move v6, v1

    .line 221
    :goto_dc
    if-eqz v6, :cond_f6

    .line 222
    .line 223
    add-int/lit8 p2, p2, 0x1

    .line 224
    .line 225
    if-ne p2, v9, :cond_e4

    .line 226
    .line 227
    move-object v0, p1

    .line 228
    goto :goto_f6

    .line 229
    :cond_e4
    if-nez p0, :cond_ed

    .line 230
    .line 231
    new-instance p0, Lqk0;

    .line 232
    .line 233
    new-array v6, v8, [Lli0;

    .line 234
    .line 235
    invoke-direct {p0, v6}, Lqk0;-><init>([Ljava/lang/Object;)V

    .line 236
    .line 237
    .line 238
    :cond_ed
    if-eqz v0, :cond_f3

    .line 239
    .line 240
    invoke-virtual {p0, v0}, Lqk0;->b(Ljava/lang/Object;)V

    .line 241
    .line 242
    .line 243
    move-object v0, v5

    .line 244
    :cond_f3
    invoke-virtual {p0, p1}, Lqk0;->b(Ljava/lang/Object;)V

    .line 245
    .line 246
    .line 247
    :cond_f6
    :goto_f6
    iget-object p1, p1, Lli0;->j:Lli0;

    .line 248
    .line 249
    goto :goto_d2

    .line 250
    :cond_f9
    if-ne p2, v9, :cond_fc

    .line 251
    .line 252
    goto :goto_ab

    .line 253
    :cond_fc
    invoke-static {p0}, Lk70;->m(Lqk0;)Lli0;

    .line 254
    .line 255
    .line 256
    move-result-object v0

    .line 257
    goto :goto_ab

    .line 258
    :cond_101
    return v9
.end method

.method public final f(JLak0;)V
    .registers 7

    .line 1
    iget-object v0, p0, Lbm0;->d:Lzh;

    .line 2
    .line 3
    invoke-virtual {v0, p1, p2}, Lzh;->c(J)Z

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    if-eqz v1, :cond_17

    .line 8
    .line 9
    invoke-virtual {p3, p0}, Lak0;->g(Ljava/lang/Object;)I

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    if-ltz v1, :cond_f

    .line 14
    .line 15
    goto :goto_17

    .line 16
    :cond_f
    invoke-virtual {v0, p1, p2}, Lzh;->g(J)V

    .line 17
    .line 18
    .line 19
    iget-object v0, p0, Lbm0;->e:Lxf0;

    .line 20
    .line 21
    invoke-virtual {v0, p1, p2}, Lxf0;->c(J)V

    .line 22
    .line 23
    .line 24
    :cond_17
    :goto_17
    iget-object p0, p0, Llm0;->a:Lqk0;

    .line 25
    .line 26
    iget-object v0, p0, Lqk0;->e:[Ljava/lang/Object;

    .line 27
    .line 28
    iget p0, p0, Lqk0;->g:I

    .line 29
    .line 30
    const/4 v1, 0x0

    .line 31
    :goto_1e
    if-ge v1, p0, :cond_2a

    .line 32
    .line 33
    aget-object v2, v0, v1

    .line 34
    .line 35
    check-cast v2, Lbm0;

    .line 36
    .line 37
    invoke-virtual {v2, p1, p2, p3}, Lbm0;->f(JLak0;)V

    .line 38
    .line 39
    .line 40
    add-int/lit8 v1, v1, 0x1

    .line 41
    .line 42
    goto :goto_1e

    .line 43
    :cond_2a
    return-void
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-string v1, "Node(modifierNode="

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    iget-object v1, p0, Lbm0;->c:Lli0;

    .line 9
    .line 10
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 11
    .line 12
    .line 13
    const-string v1, ", children="

    .line 14
    .line 15
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 16
    .line 17
    .line 18
    iget-object v1, p0, Llm0;->a:Lqk0;

    .line 19
    .line 20
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 21
    .line 22
    .line 23
    const-string v1, ", pointerIds="

    .line 24
    .line 25
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 26
    .line 27
    .line 28
    iget-object p0, p0, Lbm0;->d:Lzh;

    .line 29
    .line 30
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 31
    .line 32
    .line 33
    const/16 p0, 0x29

    .line 34
    .line 35
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 36
    .line 37
    .line 38
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 39
    .line 40
    .line 41
    move-result-object p0

    .line 42
    return-object p0
.end method
