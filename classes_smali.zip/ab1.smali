.class public final Lab1;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# instance fields
.field public final a:Landroid/text/TextPaint;

.field public final b:Landroid/text/TextUtils$TruncateAt;

.field public final c:Z

.field public final d:Z

.field public final e:Landroid/text/Layout;

.field public final f:I

.field public final g:I

.field public final h:I

.field public final i:F

.field public final j:F

.field public final k:Z

.field public final l:Landroid/graphics/Paint$FontMetricsInt;

.field public final m:I

.field public final n:[Lie0;

.field public final o:Landroid/graphics/Rect;

.field public p:Lpa;


# direct methods
.method public constructor <init>(Ljava/lang/CharSequence;FLandroid/text/TextPaint;ILandroid/text/TextUtils$TruncateAt;IZIIIIIILr90;)V
    .registers 36

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p2

    move/from16 v3, p4

    move/from16 v6, p7

    .line 1
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    move-object/from16 v4, p3

    .line 2
    iput-object v4, v0, Lab1;->a:Landroid/text/TextPaint;

    move-object/from16 v7, p5

    .line 3
    iput-object v7, v0, Lab1;->b:Landroid/text/TextUtils$TruncateAt;

    .line 4
    iput-boolean v6, v0, Lab1;->c:Z

    .line 5
    new-instance v5, Landroid/graphics/Rect;

    invoke-direct {v5}, Landroid/graphics/Rect;-><init>()V

    iput-object v5, v0, Lab1;->o:Landroid/graphics/Rect;

    .line 6
    invoke-interface {v1}, Ljava/lang/CharSequence;->length()I

    move-result v5

    .line 7
    invoke-static/range {p6 .. p6}, Ldb1;->b(I)Landroid/text/TextDirectionHeuristic;

    move-result-object v12

    .line 8
    sget-object v8, Loa1;->a:Landroid/text/Layout$Alignment;

    const/4 v13, 0x1

    const/4 v14, 0x2

    if-eqz v3, :cond_45

    if-eq v3, v13, :cond_42

    if-eq v3, v14, :cond_3f

    const/4 v8, 0x3

    if-eq v3, v8, :cond_3c

    const/4 v8, 0x4

    if-eq v3, v8, :cond_39

    .line 9
    sget-object v3, Landroid/text/Layout$Alignment;->ALIGN_NORMAL:Landroid/text/Layout$Alignment;

    goto :goto_47

    .line 10
    :cond_39
    sget-object v3, Loa1;->b:Landroid/text/Layout$Alignment;

    goto :goto_47

    .line 11
    :cond_3c
    sget-object v3, Loa1;->a:Landroid/text/Layout$Alignment;

    goto :goto_47

    .line 12
    :cond_3f
    sget-object v3, Landroid/text/Layout$Alignment;->ALIGN_CENTER:Landroid/text/Layout$Alignment;

    goto :goto_47

    .line 13
    :cond_42
    sget-object v3, Landroid/text/Layout$Alignment;->ALIGN_OPPOSITE:Landroid/text/Layout$Alignment;

    goto :goto_47

    .line 14
    :cond_45
    sget-object v3, Landroid/text/Layout$Alignment;->ALIGN_NORMAL:Landroid/text/Layout$Alignment;

    .line 15
    :goto_47
    instance-of v8, v1, Landroid/text/Spanned;

    if-eqz v8, :cond_59

    .line 16
    move-object v8, v1

    check-cast v8, Landroid/text/Spanned;

    const/4 v9, -0x1

    const-class v10, Lgb;

    invoke-interface {v8, v9, v5, v10}, Landroid/text/Spanned;->nextSpanTransition(IILjava/lang/Class;)I

    move-result v8

    if-ge v8, v5, :cond_59

    move v5, v13

    goto :goto_5a

    :cond_59
    const/4 v5, 0x0

    .line 17
    :goto_5a
    const-string v8, "TextLayout:initLayout"

    invoke-static {v8}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    .line 18
    :try_start_5f
    invoke-virtual/range {p14 .. p14}, Lr90;->a()Landroid/text/BoringLayout$Metrics;

    move-result-object v8

    float-to-double v9, v2

    .line 19
    invoke-static {v9, v10}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v14

    double-to-float v11, v14

    float-to-int v11, v11

    const/16 v14, 0x21

    if-eqz v8, :cond_b4

    .line 20
    invoke-virtual/range {p14 .. p14}, Lr90;->c()F

    move-result v15

    cmpg-float v2, v15, v2

    if-gtz v2, :cond_b4

    if-nez v5, :cond_b4

    .line 21
    iput-boolean v13, v0, Lab1;->k:Z

    if-ltz v11, :cond_7d

    goto :goto_82

    .line 22
    :cond_7d
    const-string v2, "negative width"

    .line 23
    invoke-static {v2}, Lq50;->a(Ljava/lang/String;)V

    :goto_82
    if-ltz v11, :cond_85

    goto :goto_8a

    .line 24
    :cond_85
    const-string v2, "negative ellipsized width"

    .line 25
    invoke-static {v2}, Lq50;->a(Ljava/lang/String;)V

    .line 26
    :goto_8a
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    if-lt v2, v14, :cond_98

    move-object v5, v8

    move v8, v11

    move-object v2, v4

    move-object v4, v3

    move v3, v11

    .line 27
    invoke-static/range {v1 .. v8}, Le1;->e(Ljava/lang/CharSequence;Landroid/text/TextPaint;ILandroid/text/Layout$Alignment;Landroid/text/BoringLayout$Metrics;ZLandroid/text/TextUtils$TruncateAt;I)Landroid/text/BoringLayout;

    move-result-object v2

    goto :goto_b0

    :cond_98
    move-object v4, v3

    move-object v5, v8

    move v3, v11

    .line 28
    new-instance v1, Landroid/text/BoringLayout;

    const/high16 v6, 0x3f800000  # 1.0f

    const/4 v7, 0x0

    move v11, v3

    move-object/from16 v2, p1

    move-object/from16 v10, p5

    move/from16 v9, p7

    move-object v8, v5

    move-object v5, v4

    move v4, v3

    move-object/from16 v3, p3

    invoke-direct/range {v1 .. v11}, Landroid/text/BoringLayout;-><init>(Ljava/lang/CharSequence;Landroid/text/TextPaint;ILandroid/text/Layout$Alignment;FFLandroid/text/BoringLayout$Metrics;ZLandroid/text/TextUtils$TruncateAt;I)V

    move-object v2, v1

    :goto_b0
    move/from16 v7, p8

    move-object v5, v12

    goto :goto_de

    :cond_b4
    move-object v4, v3

    move v3, v11

    const/4 v1, 0x0

    .line 29
    iput-boolean v1, v0, Lab1;->k:Z

    move-object v5, v4

    .line 30
    invoke-interface/range {p1 .. p1}, Ljava/lang/CharSequence;->length()I

    move-result v4

    .line 31
    invoke-static {v9, v10}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v6

    double-to-float v2, v6

    float-to-int v9, v2

    move-object/from16 v1, p1

    move-object/from16 v2, p3

    move-object/from16 v8, p5

    move/from16 v11, p7

    move/from16 v7, p8

    move/from16 v13, p10

    move/from16 v14, p11

    move/from16 v15, p12

    move/from16 v10, p13

    move-object v6, v5

    move-object v5, v12

    move/from16 v12, p9

    .line 32
    invoke-static/range {v1 .. v15}, Lsb0;->j(Ljava/lang/CharSequence;Landroid/text/TextPaint;IILandroid/text/TextDirectionHeuristic;Landroid/text/Layout$Alignment;ILandroid/text/TextUtils$TruncateAt;IIZIIII)Landroid/text/StaticLayout;

    move-result-object v2

    .line 33
    :goto_de
    iput-object v2, v0, Lab1;->e:Landroid/text/Layout;
    :try_end_e0
    .catchall {:try_start_5f .. :try_end_e0} :catchall_34c

    .line 34
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 35
    invoke-virtual {v2}, Landroid/text/Layout;->getLineCount()I

    move-result v1

    invoke-static {v1, v7}, Ljava/lang/Math;->min(II)I

    move-result v1

    iput v1, v0, Lab1;->f:I

    add-int/lit8 v3, v1, -0x1

    if-ge v1, v7, :cond_f3

    :cond_f1
    const/4 v13, 0x0

    goto :goto_104

    .line 36
    :cond_f3
    invoke-virtual {v2, v3}, Landroid/text/Layout;->getEllipsisCount(I)I

    move-result v4

    if-gtz v4, :cond_103

    .line 37
    invoke-virtual {v2, v3}, Landroid/text/Layout;->getLineEnd(I)I

    move-result v4

    invoke-interface/range {p1 .. p1}, Ljava/lang/CharSequence;->length()I

    move-result v6

    if-eq v4, v6, :cond_f1

    :cond_103
    const/4 v13, 0x1

    .line 38
    :goto_104
    iput-boolean v13, v0, Lab1;->d:Z

    .line 39
    invoke-virtual {v2}, Landroid/text/Layout;->getText()Ljava/lang/CharSequence;

    move-result-object v4

    .line 40
    instance-of v4, v4, Landroid/text/Spanned;

    if-nez v4, :cond_10f

    goto :goto_12a

    .line 41
    :cond_10f
    invoke-virtual {v2}, Landroid/text/Layout;->getText()Ljava/lang/CharSequence;

    move-result-object v4

    .line 42
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v4, Landroid/text/Spanned;

    const-class v7, Lie0;

    invoke-static {v4, v7}, Lkb0;->q(Landroid/text/Spanned;Ljava/lang/Class;)Z

    move-result v4

    if-nez v4, :cond_12d

    .line 43
    invoke-virtual {v2}, Landroid/text/Layout;->getText()Ljava/lang/CharSequence;

    move-result-object v4

    .line 44
    invoke-interface {v4}, Ljava/lang/CharSequence;->length()I

    move-result v4

    if-lez v4, :cond_12d

    :goto_12a
    const/4 v4, 0x0

    const/4 v9, 0x0

    goto :goto_145

    .line 45
    :cond_12d
    invoke-virtual {v2}, Landroid/text/Layout;->getText()Ljava/lang/CharSequence;

    move-result-object v4

    .line 46
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v4, Landroid/text/Spanned;

    .line 47
    invoke-virtual {v2}, Landroid/text/Layout;->getText()Ljava/lang/CharSequence;

    move-result-object v8

    .line 48
    invoke-interface {v8}, Ljava/lang/CharSequence;->length()I

    move-result v8

    const/4 v9, 0x0

    invoke-interface {v4, v9, v8, v7}, Landroid/text/Spanned;->getSpans(IILjava/lang/Class;)[Ljava/lang/Object;

    move-result-object v4

    check-cast v4, [Lie0;

    .line 49
    :goto_145
    iput-object v4, v0, Lab1;->n:[Lie0;

    if-eqz v4, :cond_161

    .line 50
    array-length v7, v4

    if-nez v7, :cond_14e

    const/4 v7, 0x0

    goto :goto_150

    :cond_14e
    aget-object v7, v4, v9

    :goto_150
    if-eqz v7, :cond_161

    .line 51
    iget-boolean v8, v7, Lie0;->g:Z

    if-eqz v8, :cond_15d

    .line 52
    iget v7, v7, Lie0;->j:I

    const/4 v8, 0x2

    if-ne v7, v8, :cond_15e

    const/4 v13, 0x1

    goto :goto_15f

    :cond_15d
    const/4 v8, 0x2

    :cond_15e
    move v13, v9

    :goto_15f
    move v15, v13

    goto :goto_163

    :cond_161
    const/4 v8, 0x2

    move v15, v9

    :goto_163
    if-eqz v4, :cond_178

    .line 53
    array-length v7, v4

    if-nez v7, :cond_16a

    const/4 v7, 0x0

    goto :goto_16c

    :cond_16a
    aget-object v7, v4, v9

    :goto_16c
    if-eqz v7, :cond_178

    .line 54
    iget-boolean v10, v7, Lie0;->h:Z

    if-eqz v10, :cond_178

    .line 55
    iget v7, v7, Lie0;->j:I

    if-ne v7, v8, :cond_178

    const/4 v13, 0x1

    goto :goto_179

    :cond_178
    move v13, v9

    :goto_179
    if-eqz v15, :cond_18b

    if-eqz v13, :cond_18b

    .line 56
    sget-wide v1, Ldb1;->b:J

    const/16 p2, 0x20

    const-wide p3, 0xffffffffL

    const/4 v10, 0x1

    const/16 v14, 0x21

    goto/16 :goto_22f

    .line 57
    :cond_18b
    sget-wide v16, Ldb1;->b:J

    if-nez p7, :cond_213

    .line 58
    iget-boolean v8, v0, Lab1;->k:Z

    if-eqz v8, :cond_1a3

    .line 59
    move-object v8, v2

    check-cast v8, Landroid/text/BoringLayout;

    .line 60
    sget v12, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v14, 0x21

    if-lt v12, v14, :cond_1a1

    .line 61
    invoke-static {v8}, Le1;->m(Landroid/text/BoringLayout;)Z

    move-result v8

    goto :goto_1b6

    :cond_1a1
    move v8, v9

    goto :goto_1b6

    :cond_1a3
    const/16 v14, 0x21

    .line 62
    move-object v8, v2

    check-cast v8, Landroid/text/StaticLayout;

    .line 63
    sget v12, Landroid/os/Build$VERSION;->SDK_INT:I

    if-lt v12, v14, :cond_1b1

    .line 64
    invoke-static {v8}, Le1;->n(Landroid/text/StaticLayout;)Z

    move-result v8

    goto :goto_1b6

    :cond_1b1
    const/16 v8, 0x1c

    if-lt v12, v8, :cond_1a1

    const/4 v8, 0x1

    :goto_1b6
    if-eqz v8, :cond_1c1

    const/16 p2, 0x20

    const-wide p3, 0xffffffffL

    const/4 v10, 0x1

    goto :goto_21d

    .line 65
    :cond_1c1
    invoke-virtual {v2}, Landroid/text/Layout;->getPaint()Landroid/text/TextPaint;

    move-result-object v8

    .line 66
    invoke-virtual {v2}, Landroid/text/Layout;->getText()Ljava/lang/CharSequence;

    move-result-object v12

    .line 67
    invoke-virtual {v2, v9}, Landroid/text/Layout;->getLineStart(I)I

    move-result v6

    const/16 p2, 0x20

    invoke-virtual {v2, v9}, Landroid/text/Layout;->getLineEnd(I)I

    move-result v7

    invoke-static {v8, v12, v6, v7}, Lsb0;->n(Landroid/text/TextPaint;Ljava/lang/CharSequence;II)Landroid/graphics/Rect;

    move-result-object v6

    .line 68
    invoke-virtual {v2, v9}, Landroid/text/Layout;->getLineAscent(I)I

    move-result v7

    const-wide p3, 0xffffffffL

    .line 69
    iget v10, v6, Landroid/graphics/Rect;->top:I

    if-ge v10, v7, :cond_1e7

    sub-int/2addr v7, v10

    :goto_1e5
    const/4 v10, 0x1

    goto :goto_1ec

    .line 70
    :cond_1e7
    invoke-virtual {v2}, Landroid/text/Layout;->getTopPadding()I

    move-result v7

    goto :goto_1e5

    :goto_1ec
    if-ne v1, v10, :cond_1ef

    goto :goto_1fb

    .line 71
    :cond_1ef
    invoke-virtual {v2, v3}, Landroid/text/Layout;->getLineStart(I)I

    move-result v1

    invoke-virtual {v2, v3}, Landroid/text/Layout;->getLineEnd(I)I

    move-result v6

    invoke-static {v8, v12, v1, v6}, Lsb0;->n(Landroid/text/TextPaint;Ljava/lang/CharSequence;II)Landroid/graphics/Rect;

    move-result-object v6

    .line 72
    :goto_1fb
    invoke-virtual {v2, v3}, Landroid/text/Layout;->getLineDescent(I)I

    move-result v1

    .line 73
    iget v6, v6, Landroid/graphics/Rect;->bottom:I

    if-le v6, v1, :cond_205

    sub-int/2addr v6, v1

    goto :goto_209

    .line 74
    :cond_205
    invoke-virtual {v2}, Landroid/text/Layout;->getBottomPadding()I

    move-result v6

    :goto_209
    if-nez v7, :cond_20e

    if-nez v6, :cond_20e

    goto :goto_21d

    .line 75
    :cond_20e
    invoke-static {v7, v6}, Ldb1;->a(II)J

    move-result-wide v16

    goto :goto_21d

    :cond_213
    const/16 p2, 0x20

    const-wide p3, 0xffffffffL

    const/4 v10, 0x1

    const/16 v14, 0x21

    :goto_21d
    if-eqz v15, :cond_221

    move v15, v9

    goto :goto_224

    :cond_221
    shr-long v1, v16, p2

    long-to-int v15, v1

    :goto_224
    if-eqz v13, :cond_228

    move v1, v9

    goto :goto_22b

    :cond_228
    and-long v1, v16, p3

    long-to-int v1, v1

    .line 76
    :goto_22b
    invoke-static {v15, v1}, Ldb1;->a(II)J

    move-result-wide v1

    :goto_22f
    if-eqz v4, :cond_260

    .line 77
    array-length v6, v4

    move v7, v9

    move v8, v7

    move v15, v8

    :goto_235
    if-ge v15, v6, :cond_254

    aget-object v11, v4, v15

    .line 78
    iget v12, v11, Lie0;->o:I

    if-gez v12, :cond_245

    .line 79
    invoke-static {v12}, Ljava/lang/Math;->abs(I)I

    move-result v12

    invoke-static {v7, v12}, Ljava/lang/Math;->max(II)I

    move-result v7

    .line 80
    :cond_245
    iget v11, v11, Lie0;->p:I

    if-gez v11, :cond_251

    .line 81
    invoke-static {v11}, Ljava/lang/Math;->abs(I)I

    move-result v8

    invoke-static {v7, v8}, Ljava/lang/Math;->max(II)I

    move-result v8

    :cond_251
    add-int/lit8 v15, v15, 0x1

    goto :goto_235

    :cond_254
    if-nez v7, :cond_25b

    if-nez v8, :cond_25b

    .line 82
    sget-wide v6, Ldb1;->b:J

    goto :goto_262

    .line 83
    :cond_25b
    invoke-static {v7, v8}, Ldb1;->a(II)J

    move-result-wide v6

    goto :goto_262

    .line 84
    :cond_260
    sget-wide v6, Ldb1;->b:J

    :goto_262
    shr-long v11, v1, p2

    long-to-int v4, v11

    shr-long v11, v6, p2

    long-to-int v8, v11

    .line 85
    invoke-static {v4, v8}, Ljava/lang/Math;->max(II)I

    move-result v4

    iput v4, v0, Lab1;->g:I

    and-long v1, v1, p3

    long-to-int v1, v1

    and-long v6, v6, p3

    long-to-int v2, v6

    .line 86
    invoke-static {v1, v2}, Ljava/lang/Math;->max(II)I

    move-result v1

    iput v1, v0, Lab1;->h:I

    .line 87
    iget-object v7, v0, Lab1;->a:Landroid/text/TextPaint;

    iget-object v1, v0, Lab1;->n:[Lie0;

    .line 88
    iget v2, v0, Lab1;->f:I

    sub-int/2addr v2, v10

    .line 89
    iget-object v4, v0, Lab1;->e:Landroid/text/Layout;

    .line 90
    invoke-virtual {v4, v2}, Landroid/text/Layout;->getLineStart(I)I

    move-result v6

    invoke-virtual {v4, v2}, Landroid/text/Layout;->getLineEnd(I)I

    move-result v4

    if-ne v6, v4, :cond_31b

    if-eqz v1, :cond_31b

    .line 91
    array-length v4, v1

    if-nez v4, :cond_294

    goto/16 :goto_31b

    .line 92
    :cond_294
    new-instance v6, Landroid/text/SpannableString;

    const-string v4, "\u200b"

    invoke-direct {v6, v4}, Landroid/text/SpannableString;-><init>(Ljava/lang/CharSequence;)V

    .line 93
    array-length v4, v1

    if-eqz v4, :cond_313

    .line 94
    aget-object v1, v1, v9

    .line 95
    invoke-virtual {v6}, Landroid/text/SpannableString;->length()I

    move-result v4

    if-eqz v2, :cond_2ac

    .line 96
    iget-boolean v2, v1, Lie0;->h:Z

    if-eqz v2, :cond_2ac

    move v15, v9

    goto :goto_2ae

    .line 97
    :cond_2ac
    iget-boolean v15, v1, Lie0;->h:Z

    .line 98
    :goto_2ae
    new-instance v2, Lie0;

    .line 99
    iget v8, v1, Lie0;->e:F

    .line 100
    iget-boolean v10, v1, Lie0;->h:Z

    .line 101
    iget v11, v1, Lie0;->i:F

    .line 102
    iget v1, v1, Lie0;->j:I

    move/from16 p7, v1

    move-object/from16 p1, v2

    move/from16 p3, v4

    move/from16 p2, v8

    move/from16 p5, v10

    move/from16 p6, v11

    move/from16 p4, v15

    .line 103
    invoke-direct/range {p1 .. p7}, Lie0;-><init>(FIZZFI)V

    move-object/from16 v1, p1

    .line 104
    invoke-virtual {v6}, Landroid/text/SpannableString;->length()I

    move-result v2

    invoke-virtual {v6, v1, v9, v2, v14}, Landroid/text/SpannableString;->setSpan(Ljava/lang/Object;III)V

    move v1, v9

    .line 105
    invoke-virtual {v6}, Landroid/text/SpannableString;->length()I

    move-result v9

    .line 106
    iget-boolean v2, v0, Lab1;->c:Z

    .line 107
    sget-object v11, Lm90;->a:Landroid/text/Layout$Alignment;

    const/16 v19, 0x0

    const/16 v20, 0x0

    const v8, 0x7fffffff

    const v12, 0x7fffffff

    const/4 v13, 0x0

    const v14, 0x7fffffff

    const/4 v15, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    move/from16 v16, v2

    move-object v10, v5

    .line 108
    invoke-static/range {v6 .. v20}, Lsb0;->j(Ljava/lang/CharSequence;Landroid/text/TextPaint;IILandroid/text/TextDirectionHeuristic;Landroid/text/Layout$Alignment;ILandroid/text/TextUtils$TruncateAt;IIZIIII)Landroid/text/StaticLayout;

    move-result-object v2

    .line 109
    new-instance v6, Landroid/graphics/Paint$FontMetricsInt;

    invoke-direct {v6}, Landroid/graphics/Paint$FontMetricsInt;-><init>()V

    .line 110
    invoke-virtual {v2, v1}, Landroid/text/Layout;->getLineAscent(I)I

    move-result v4

    iput v4, v6, Landroid/graphics/Paint$FontMetricsInt;->ascent:I

    .line 111
    invoke-virtual {v2, v1}, Landroid/text/StaticLayout;->getLineDescent(I)I

    move-result v4

    iput v4, v6, Landroid/graphics/Paint$FontMetricsInt;->descent:I

    .line 112
    invoke-virtual {v2, v1}, Landroid/text/StaticLayout;->getLineTop(I)I

    move-result v4

    iput v4, v6, Landroid/graphics/Paint$FontMetricsInt;->top:I

    .line 113
    invoke-virtual {v2, v1}, Landroid/text/Layout;->getLineBottom(I)I

    move-result v2

    iput v2, v6, Landroid/graphics/Paint$FontMetricsInt;->bottom:I

    goto :goto_31d

    .line 114
    :cond_313
    new-instance v0, Ljava/util/NoSuchElementException;

    const-string v1, "Array is empty."

    invoke-direct {v0, v1}, Ljava/util/NoSuchElementException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_31b
    :goto_31b
    move v1, v9

    const/4 v6, 0x0

    :goto_31d
    if-eqz v6, :cond_32e

    .line 115
    iget v1, v6, Landroid/graphics/Paint$FontMetricsInt;->bottom:I

    .line 116
    invoke-virtual {v0, v3}, Lab1;->d(I)F

    move-result v2

    invoke-virtual {v0, v3}, Lab1;->f(I)F

    move-result v4

    sub-float/2addr v2, v4

    float-to-int v2, v2

    sub-int v15, v1, v2

    goto :goto_32f

    :cond_32e
    move v15, v1

    .line 117
    :goto_32f
    iput v15, v0, Lab1;->m:I

    .line 118
    iput-object v6, v0, Lab1;->l:Landroid/graphics/Paint$FontMetricsInt;

    .line 119
    iget-object v1, v0, Lab1;->e:Landroid/text/Layout;

    .line 120
    invoke-virtual {v1}, Landroid/text/Layout;->getPaint()Landroid/text/TextPaint;

    move-result-object v2

    invoke-static {v1, v3, v2}, Lvn;->w(Landroid/text/Layout;ILandroid/graphics/Paint;)F

    move-result v1

    .line 121
    iput v1, v0, Lab1;->i:F

    .line 122
    iget-object v1, v0, Lab1;->e:Landroid/text/Layout;

    .line 123
    invoke-virtual {v1}, Landroid/text/Layout;->getPaint()Landroid/text/TextPaint;

    move-result-object v2

    invoke-static {v1, v3, v2}, Lvn;->x(Landroid/text/Layout;ILandroid/graphics/Paint;)F

    move-result v1

    .line 124
    iput v1, v0, Lab1;->j:F

    return-void

    :catchall_34c
    move-exception v0

    .line 125
    invoke-static {}, Landroid/os/Trace;->endSection()V

    throw v0
.end method


# virtual methods
.method public final a()I
    .registers 3

    .line 1
    iget-boolean v0, p0, Lab1;->d:Z

    .line 2
    .line 3
    iget-object v1, p0, Lab1;->e:Landroid/text/Layout;

    .line 4
    .line 5
    if-eqz v0, :cond_f

    .line 6
    .line 7
    iget v0, p0, Lab1;->f:I

    .line 8
    .line 9
    add-int/lit8 v0, v0, -0x1

    .line 10
    .line 11
    invoke-virtual {v1, v0}, Landroid/text/Layout;->getLineBottom(I)I

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    goto :goto_13

    .line 16
    :cond_f
    invoke-virtual {v1}, Landroid/text/Layout;->getHeight()I

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    :goto_13
    iget v1, p0, Lab1;->g:I

    .line 21
    .line 22
    add-int/2addr v0, v1

    .line 23
    iget v1, p0, Lab1;->h:I

    .line 24
    .line 25
    add-int/2addr v0, v1

    .line 26
    iget p0, p0, Lab1;->m:I

    .line 27
    .line 28
    add-int/2addr v0, p0

    .line 29
    return v0
.end method

.method public final b()Lpa;
    .registers 3

    .line 1
    iget-object v0, p0, Lab1;->p:Lpa;

    .line 2
    .line 3
    if-nez v0, :cond_d

    .line 4
    .line 5
    new-instance v0, Lpa;

    .line 6
    .line 7
    iget-object v1, p0, Lab1;->e:Landroid/text/Layout;

    .line 8
    .line 9
    invoke-direct {v0, v1}, Lpa;-><init>(Landroid/text/Layout;)V

    .line 10
    .line 11
    .line 12
    iput-object v0, p0, Lab1;->p:Lpa;

    .line 13
    .line 14
    :cond_d
    return-object v0
.end method

.method public final c(I)F
    .registers 4

    .line 1
    iget v0, p0, Lab1;->g:I

    .line 2
    .line 3
    int-to-float v0, v0

    .line 4
    iget v1, p0, Lab1;->f:I

    .line 5
    .line 6
    add-int/lit8 v1, v1, -0x1

    .line 7
    .line 8
    if-ne p1, v1, :cond_16

    .line 9
    .line 10
    iget-object v1, p0, Lab1;->l:Landroid/graphics/Paint$FontMetricsInt;

    .line 11
    .line 12
    if-eqz v1, :cond_16

    .line 13
    .line 14
    invoke-virtual {p0, p1}, Lab1;->f(I)F

    .line 15
    .line 16
    .line 17
    move-result p0

    .line 18
    iget p1, v1, Landroid/graphics/Paint$FontMetricsInt;->ascent:I

    .line 19
    .line 20
    int-to-float p1, p1

    .line 21
    sub-float/2addr p0, p1

    .line 22
    goto :goto_1d

    .line 23
    :cond_16
    iget-object p0, p0, Lab1;->e:Landroid/text/Layout;

    .line 24
    .line 25
    invoke-virtual {p0, p1}, Landroid/text/Layout;->getLineBaseline(I)I

    .line 26
    .line 27
    .line 28
    move-result p0

    .line 29
    int-to-float p0, p0

    .line 30
    :goto_1d
    add-float/2addr v0, p0

    .line 31
    return v0
.end method

.method public final d(I)F
    .registers 5

    .line 1
    iget v0, p0, Lab1;->f:I

    .line 2
    .line 3
    add-int/lit8 v1, v0, -0x1

    .line 4
    .line 5
    iget-object v2, p0, Lab1;->e:Landroid/text/Layout;

    .line 6
    .line 7
    if-ne p1, v1, :cond_18

    .line 8
    .line 9
    iget-object v1, p0, Lab1;->l:Landroid/graphics/Paint$FontMetricsInt;

    .line 10
    .line 11
    if-eqz v1, :cond_18

    .line 12
    .line 13
    add-int/lit8 p1, p1, -0x1

    .line 14
    .line 15
    invoke-virtual {v2, p1}, Landroid/text/Layout;->getLineBottom(I)I

    .line 16
    .line 17
    .line 18
    move-result p0

    .line 19
    int-to-float p0, p0

    .line 20
    iget p1, v1, Landroid/graphics/Paint$FontMetricsInt;->bottom:I

    .line 21
    .line 22
    int-to-float p1, p1

    .line 23
    add-float/2addr p0, p1

    .line 24
    return p0

    .line 25
    :cond_18
    iget v1, p0, Lab1;->g:I

    .line 26
    .line 27
    int-to-float v1, v1

    .line 28
    invoke-virtual {v2, p1}, Landroid/text/Layout;->getLineBottom(I)I

    .line 29
    .line 30
    .line 31
    move-result v2

    .line 32
    int-to-float v2, v2

    .line 33
    add-float/2addr v1, v2

    .line 34
    add-int/lit8 v0, v0, -0x1

    .line 35
    .line 36
    if-ne p1, v0, :cond_28

    .line 37
    .line 38
    iget p0, p0, Lab1;->h:I

    .line 39
    .line 40
    goto :goto_29

    .line 41
    :cond_28
    const/4 p0, 0x0

    .line 42
    :goto_29
    int-to-float p0, p0

    .line 43
    add-float/2addr v1, p0

    .line 44
    return v1
.end method

.method public final e(I)I
    .registers 4

    .line 1
    sget-object v0, Ldb1;->a:Ljava/lang/ThreadLocal;

    .line 2
    .line 3
    iget-object v0, p0, Lab1;->e:Landroid/text/Layout;

    .line 4
    .line 5
    invoke-virtual {v0, p1}, Landroid/text/Layout;->getEllipsisCount(I)I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    if-lez v1, :cond_19

    .line 10
    .line 11
    iget-object p0, p0, Lab1;->b:Landroid/text/TextUtils$TruncateAt;

    .line 12
    .line 13
    sget-object v1, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    .line 14
    .line 15
    if-ne p0, v1, :cond_19

    .line 16
    .line 17
    invoke-virtual {v0}, Landroid/text/Layout;->getText()Ljava/lang/CharSequence;

    .line 18
    .line 19
    .line 20
    move-result-object p0

    .line 21
    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    .line 22
    .line 23
    .line 24
    move-result p0

    .line 25
    return p0

    .line 26
    :cond_19
    invoke-virtual {v0, p1}, Landroid/text/Layout;->getLineEnd(I)I

    .line 27
    .line 28
    .line 29
    move-result p0

    .line 30
    return p0
.end method

.method public final f(I)F
    .registers 3

    .line 1
    iget-object v0, p0, Lab1;->e:Landroid/text/Layout;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Landroid/text/Layout;->getLineTop(I)I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    int-to-float v0, v0

    .line 8
    if-nez p1, :cond_b

    .line 9
    .line 10
    const/4 p0, 0x0

    .line 11
    goto :goto_d

    .line 12
    :cond_b
    iget p0, p0, Lab1;->g:I

    .line 13
    .line 14
    :goto_d
    int-to-float p0, p0

    .line 15
    add-float/2addr v0, p0

    .line 16
    return v0
.end method

.method public final g(IZ)F
    .registers 5

    .line 1
    invoke-virtual {p0}, Lab1;->b()Lpa;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const/4 v1, 0x1

    .line 6
    invoke-virtual {v0, p1, v1, p2}, Lpa;->h(IZZ)F

    .line 7
    .line 8
    .line 9
    move-result p2

    .line 10
    iget-object v0, p0, Lab1;->e:Landroid/text/Layout;

    .line 11
    .line 12
    invoke-virtual {v0, p1}, Landroid/text/Layout;->getLineForOffset(I)I

    .line 13
    .line 14
    .line 15
    move-result p1

    .line 16
    iget v0, p0, Lab1;->f:I

    .line 17
    .line 18
    sub-int/2addr v0, v1

    .line 19
    if-ne p1, v0, :cond_1a

    .line 20
    .line 21
    iget p1, p0, Lab1;->i:F

    .line 22
    .line 23
    iget p0, p0, Lab1;->j:F

    .line 24
    .line 25
    add-float/2addr p1, p0

    .line 26
    goto :goto_1b

    .line 27
    :cond_1a
    const/4 p1, 0x0

    .line 28
    :goto_1b
    add-float/2addr p1, p2

    .line 29
    return p1
.end method

.method public final h(IZ)F
    .registers 5

    .line 1
    invoke-virtual {p0}, Lab1;->b()Lpa;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const/4 v1, 0x0

    .line 6
    invoke-virtual {v0, p1, v1, p2}, Lpa;->h(IZZ)F

    .line 7
    .line 8
    .line 9
    move-result p2

    .line 10
    iget-object v0, p0, Lab1;->e:Landroid/text/Layout;

    .line 11
    .line 12
    invoke-virtual {v0, p1}, Landroid/text/Layout;->getLineForOffset(I)I

    .line 13
    .line 14
    .line 15
    move-result p1

    .line 16
    iget v0, p0, Lab1;->f:I

    .line 17
    .line 18
    add-int/lit8 v0, v0, -0x1

    .line 19
    .line 20
    if-ne p1, v0, :cond_1b

    .line 21
    .line 22
    iget p1, p0, Lab1;->i:F

    .line 23
    .line 24
    iget p0, p0, Lab1;->j:F

    .line 25
    .line 26
    add-float/2addr p1, p0

    .line 27
    goto :goto_1c

    .line 28
    :cond_1b
    const/4 p1, 0x0

    .line 29
    :goto_1c
    add-float/2addr p1, p2

    .line 30
    return p1
.end method
