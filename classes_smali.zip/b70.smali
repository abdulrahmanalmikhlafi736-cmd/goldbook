.class public abstract Lb70;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# static fields
.field public static final a:Lh30;

.field public static final b:Lng1;

.field public static final c:Lk81;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Lh30;

    .line 2
    .line 3
    sget-object v1, La70;->l:La70;

    .line 4
    .line 5
    invoke-direct {v0, v1}, Lf3;-><init>(Lm00;)V

    .line 6
    .line 7
    .line 8
    sput-object v0, Lb70;->a:Lh30;

    .line 9
    .line 10
    new-instance v0, Lng1;

    .line 11
    .line 12
    sget-object v1, Lz60;->l:Lz60;

    .line 13
    .line 14
    invoke-direct {v0, v1}, Lf3;-><init>(Lm00;)V

    .line 15
    .line 16
    .line 17
    sput-object v0, Lb70;->b:Lng1;

    .line 18
    .line 19
    new-instance v0, Li2;

    .line 20
    .line 21
    const/16 v1, 0xf

    .line 22
    .line 23
    invoke-direct {v0, v1}, Li2;-><init>(I)V

    .line 24
    .line 25
    .line 26
    invoke-static {v0}, Lwa0;->s(Lxz;)Lda1;

    .line 27
    .line 28
    .line 29
    new-instance v0, Li2;

    .line 30
    .line 31
    const/16 v1, 0x10

    .line 32
    .line 33
    invoke-direct {v0, v1}, Li2;-><init>(I)V

    .line 34
    .line 35
    .line 36
    new-instance v1, Lk81;

    .line 37
    .line 38
    invoke-direct {v1, v0}, Llv0;-><init>(Lxz;)V

    .line 39
    .line 40
    .line 41
    sput-object v1, Lb70;->c:Lk81;

    .line 42
    .line 43
    return-void
.end method
