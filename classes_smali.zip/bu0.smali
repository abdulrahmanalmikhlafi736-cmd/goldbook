.class public final Lbu0;
.super Ll10;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# static fields
.field private static final DEFAULT_INSTANCE:Lbu0;

.field private static volatile PARSER:Loq0; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Loq0;"
        }
    .end annotation
.end field

.field public static final PREFERENCES_FIELD_NUMBER:I = 0x1


# instance fields
.field private preferences_:Lyg0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lyg0;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Lbu0;

    .line 2
    .line 3
    invoke-direct {v0}, Lbu0;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lbu0;->DEFAULT_INSTANCE:Lbu0;

    .line 7
    .line 8
    const-class v1, Lbu0;

    .line 9
    .line 10
    invoke-static {v1, v0}, Ll10;->j(Ljava/lang/Class;Ll10;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, Ll10;-><init>()V

    .line 2
    .line 3
    .line 4
    sget-object v0, Lyg0;->f:Lyg0;

    .line 5
    .line 6
    iput-object v0, p0, Lbu0;->preferences_:Lyg0;

    .line 7
    .line 8
    return-void
.end method

.method public static l(Lbu0;)Lyg0;
    .registers 3

    .line 1
    iget-object v0, p0, Lbu0;->preferences_:Lyg0;

    .line 2
    .line 3
    iget-boolean v1, v0, Lyg0;->e:Z

    .line 4
    .line 5
    if-nez v1, :cond_c

    .line 6
    .line 7
    invoke-virtual {v0}, Lyg0;->b()Lyg0;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    iput-object v0, p0, Lbu0;->preferences_:Lyg0;

    .line 12
    .line 13
    :cond_c
    iget-object p0, p0, Lbu0;->preferences_:Lyg0;

    .line 14
    .line 15
    return-object p0
.end method

.method public static n()Lzt0;
    .registers 2

    .line 1
    sget-object v0, Lbu0;->DEFAULT_INSTANCE:Lbu0;

    .line 2
    .line 3
    const/4 v1, 0x5

    .line 4
    invoke-virtual {v0, v1}, Lbu0;->c(I)Ljava/lang/Object;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    check-cast v0, Lj10;

    .line 9
    .line 10
    check-cast v0, Lzt0;

    .line 11
    .line 12
    return-object v0
.end method

.method public static o(Ljava/io/FileInputStream;)Lbu0;
    .registers 5

    .line 1
    sget-object v0, Lbu0;->DEFAULT_INSTANCE:Lbu0;

    .line 2
    .line 3
    new-instance v1, Lng;

    .line 4
    .line 5
    invoke-direct {v1, p0}, Lng;-><init>(Ljava/io/FileInputStream;)V

    .line 6
    .line 7
    .line 8
    invoke-static {}, Lyu;->a()Lyu;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    invoke-virtual {v0}, Ll10;->i()Ll10;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    :try_start_f
    sget-object v2, Ljv0;->c:Ljv0;

    .line 17
    .line 18
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 19
    .line 20
    .line 21
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    .line 23
    .line 24
    move-result-object v3

    .line 25
    invoke-virtual {v2, v3}, Ljv0;->a(Ljava/lang/Class;)Lq01;

    .line 26
    .line 27
    .line 28
    move-result-object v2

    .line 29
    iget-object v3, v1, Log;->f:Ljava/lang/Object;

    .line 30
    .line 31
    check-cast v3, Lpg;

    .line 32
    .line 33
    if-eqz v3, :cond_23

    .line 34
    .line 35
    goto :goto_28

    .line 36
    :cond_23
    new-instance v3, Lpg;

    .line 37
    .line 38
    invoke-direct {v3, v1}, Lpg;-><init>(Log;)V

    .line 39
    .line 40
    .line 41
    :goto_28
    invoke-interface {v2, v0, v3, p0}, Lq01;->h(Ljava/lang/Object;Lpg;Lyu;)V

    .line 42
    .line 43
    .line 44
    invoke-interface {v2, v0}, Lq01;->c(Ljava/lang/Object;)V
    :try_end_2e
    .catch Ls70; {:try_start_f .. :try_end_2e} :catch_7d
    .catch Lue1; {:try_start_f .. :try_end_2e} :catch_72
    .catch Ljava/io/IOException; {:try_start_f .. :try_end_2e} :catch_58
    .catch Ljava/lang/RuntimeException; {:try_start_f .. :try_end_2e} :catch_47

    .line 45
    .line 46
    .line 47
    const/4 p0, 0x1

    .line 48
    invoke-static {v0, p0}, Ll10;->f(Ll10;Z)Z

    .line 49
    .line 50
    .line 51
    move-result p0

    .line 52
    if-eqz p0, :cond_38

    .line 53
    .line 54
    check-cast v0, Lbu0;

    .line 55
    .line 56
    return-object v0

    .line 57
    :cond_38
    new-instance p0, Lue1;

    .line 58
    .line 59
    invoke-direct {p0}, Lue1;-><init>()V

    .line 60
    .line 61
    .line 62
    new-instance v0, Ls70;

    .line 63
    .line 64
    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 65
    .line 66
    .line 67
    move-result-object p0

    .line 68
    invoke-direct {v0, p0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 69
    .line 70
    .line 71
    throw v0

    .line 72
    :catch_47
    move-exception p0

    .line 73
    invoke-virtual {p0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    instance-of v0, v0, Ls70;

    .line 78
    .line 79
    if-eqz v0, :cond_57

    .line 80
    .line 81
    invoke-virtual {p0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    .line 82
    .line 83
    .line 84
    move-result-object p0

    .line 85
    check-cast p0, Ls70;

    .line 86
    .line 87
    throw p0

    .line 88
    :cond_57
    throw p0

    .line 89
    :catch_58
    move-exception p0

    .line 90
    invoke-virtual {p0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    .line 91
    .line 92
    .line 93
    move-result-object v0

    .line 94
    instance-of v0, v0, Ls70;

    .line 95
    .line 96
    if-eqz v0, :cond_68

    .line 97
    .line 98
    invoke-virtual {p0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    .line 99
    .line 100
    .line 101
    move-result-object p0

    .line 102
    check-cast p0, Ls70;

    .line 103
    .line 104
    throw p0

    .line 105
    :cond_68
    new-instance v0, Ls70;

    .line 106
    .line 107
    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 108
    .line 109
    .line 110
    move-result-object v1

    .line 111
    invoke-direct {v0, v1, p0}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 112
    .line 113
    .line 114
    throw v0

    .line 115
    :catch_72
    move-exception p0

    .line 116
    new-instance v0, Ls70;

    .line 117
    .line 118
    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 119
    .line 120
    .line 121
    move-result-object p0

    .line 122
    invoke-direct {v0, p0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 123
    .line 124
    .line 125
    throw v0

    .line 126
    :catch_7d
    move-exception p0

    .line 127
    iget-boolean v0, p0, Ls70;->e:Z

    .line 128
    .line 129
    if-eqz v0, :cond_8c

    .line 130
    .line 131
    new-instance v0, Ls70;

    .line 132
    .line 133
    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 134
    .line 135
    .line 136
    move-result-object v1

    .line 137
    invoke-direct {v0, v1, p0}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 138
    .line 139
    .line 140
    move-object p0, v0

    .line 141
    :cond_8c
    throw p0
.end method


# virtual methods
.method public final c(I)Ljava/lang/Object;
    .registers 4

    .line 1
    invoke-static {p1}, Lfu0;->N(I)I

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    const/4 p1, 0x1

    .line 6
    packed-switch p0, :pswitch_data_56

    .line 7
    .line 8
    .line 9
    new-instance p0, Ljava/lang/UnsupportedOperationException;

    .line 10
    .line 11
    invoke-direct {p0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    .line 12
    .line 13
    .line 14
    throw p0

    .line 15
    :pswitch_e  #0x6
    sget-object p0, Lbu0;->PARSER:Loq0;

    .line 16
    .line 17
    if-nez p0, :cond_27

    .line 18
    .line 19
    const-class p1, Lbu0;

    .line 20
    .line 21
    monitor-enter p1

    .line 22
    :try_start_15
    sget-object p0, Lbu0;->PARSER:Loq0;

    .line 23
    .line 24
    if-nez p0, :cond_23

    .line 25
    .line 26
    new-instance p0, Lk10;

    .line 27
    .line 28
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 29
    .line 30
    .line 31
    sput-object p0, Lbu0;->PARSER:Loq0;

    .line 32
    .line 33
    goto :goto_23

    .line 34
    :catchall_21
    move-exception p0

    .line 35
    goto :goto_25

    .line 36
    :cond_23
    :goto_23
    monitor-exit p1

    .line 37
    return-object p0

    .line 38
    :goto_25
    monitor-exit p1
    :try_end_26
    .catchall {:try_start_15 .. :try_end_26} :catchall_21

    .line 39
    throw p0

    .line 40
    :cond_27
    return-object p0

    .line 41
    :pswitch_28  #0x5
    sget-object p0, Lbu0;->DEFAULT_INSTANCE:Lbu0;

    .line 42
    .line 43
    return-object p0

    .line 44
    :pswitch_2b  #0x4
    new-instance p0, Lzt0;

    .line 45
    .line 46
    sget-object p1, Lbu0;->DEFAULT_INSTANCE:Lbu0;

    .line 47
    .line 48
    invoke-direct {p0, p1}, Lj10;-><init>(Ll10;)V

    .line 49
    .line 50
    .line 51
    return-object p0

    .line 52
    :pswitch_33  #0x3
    new-instance p0, Lbu0;

    .line 53
    .line 54
    invoke-direct {p0}, Lbu0;-><init>()V

    .line 55
    .line 56
    .line 57
    return-object p0

    .line 58
    :pswitch_39  #0x2
    const/4 p0, 0x2

    .line 59
    new-array p0, p0, [Ljava/lang/Object;

    .line 60
    .line 61
    const-string v0, "preferences_"

    .line 62
    .line 63
    const/4 v1, 0x0

    .line 64
    aput-object v0, p0, v1

    .line 65
    .line 66
    sget-object v0, Lau0;->a:Lxg0;

    .line 67
    .line 68
    aput-object v0, p0, p1

    .line 69
    .line 70
    const-string p1, "\u0001\u0001\u0000\u0000\u0001\u0001\u0001\u0001\u0000\u0000\u00012"

    .line 71
    .line 72
    sget-object v0, Lbu0;->DEFAULT_INSTANCE:Lbu0;

    .line 73
    .line 74
    new-instance v1, Lrv0;

    .line 75
    .line 76
    invoke-direct {v1, v0, p1, p0}, Lrv0;-><init>(Ll10;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 77
    .line 78
    .line 79
    return-object v1

    .line 80
    :pswitch_4f  #0x1
    const/4 p0, 0x0

    .line 81
    return-object p0

    .line 82
    :pswitch_51  #0x0
    invoke-static {p1}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    .line 83
    .line 84
    .line 85
    move-result-object p0

    .line 86
    return-object p0

    .line 87
    :pswitch_data_56
    .packed-switch 0x0
        :pswitch_51  #00000000
        :pswitch_4f  #00000001
        :pswitch_39  #00000002
        :pswitch_33  #00000003
        :pswitch_2b  #00000004
        :pswitch_28  #00000005
        :pswitch_e  #00000006
    .end packed-switch
.end method

.method public final m()Ljava/util/Map;
    .registers 1

    .line 1
    iget-object p0, p0, Lbu0;->preferences_:Lyg0;

    .line 2
    .line 3
    invoke-static {p0}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    return-object p0
.end method
