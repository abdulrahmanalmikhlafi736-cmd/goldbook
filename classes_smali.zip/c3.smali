.class public final synthetic Lc3;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lm00;


# instance fields
.field public final synthetic e:I

.field public final synthetic f:Lm00;


# direct methods
.method public synthetic constructor <init>(ILm00;)V
    .registers 3

    .line 1
    iput p1, p0, Lc3;->e:I

    .line 2
    .line 3
    iput-object p2, p0, Lc3;->f:Lm00;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 12

    .line 1
    iget v0, p0, Lc3;->e:I

    .line 2
    .line 3
    sget-object v1, Lji0;->a:Lji0;

    .line 4
    .line 5
    sget-object v2, Lwe1;->a:Lwe1;

    .line 6
    .line 7
    const/16 v3, 0x20

    .line 8
    .line 9
    const/4 v4, 0x2

    .line 10
    const/4 v5, 0x1

    .line 11
    const/4 v6, 0x0

    .line 12
    iget-object p0, p0, Lc3;->f:Lm00;

    .line 13
    .line 14
    packed-switch v0, :pswitch_data_236

    .line 15
    .line 16
    .line 17
    check-cast p1, Ld10;

    .line 18
    .line 19
    check-cast p2, Ljava/lang/Integer;

    .line 20
    .line 21
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 22
    .line 23
    .line 24
    move-result p2

    .line 25
    and-int/lit8 v0, p2, 0x3

    .line 26
    .line 27
    if-eq v0, v4, :cond_1e

    .line 28
    .line 29
    move v0, v5

    .line 30
    goto :goto_1f

    .line 31
    :cond_1e
    move v0, v6

    .line 32
    :goto_1f
    and-int/2addr p2, v5

    .line 33
    invoke-virtual {p1, p2, v0}, Ld10;->O(IZ)Z

    .line 34
    .line 35
    .line 36
    move-result p2

    .line 37
    if-eqz p2, :cond_77

    .line 38
    .line 39
    sget-object p2, Le3;->f:Lnb;

    .line 40
    .line 41
    invoke-static {p2, v6}, Lic;->d(Lnb;Z)Lmh0;

    .line 42
    .line 43
    .line 44
    move-result-object p2

    .line 45
    iget-wide v7, p1, Ld10;->T:J

    .line 46
    .line 47
    ushr-long v3, v7, v3

    .line 48
    .line 49
    xor-long/2addr v3, v7

    .line 50
    long-to-int v0, v3

    .line 51
    invoke-virtual {p1}, Ld10;->l()Lqr0;

    .line 52
    .line 53
    .line 54
    move-result-object v3

    .line 55
    invoke-static {p1, v1}, Lvn;->I(Ld10;Lmi0;)Lmi0;

    .line 56
    .line 57
    .line 58
    move-result-object v1

    .line 59
    sget-object v4, Lij;->c:Lhj;

    .line 60
    .line 61
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 62
    .line 63
    .line 64
    sget-object v4, Lhj;->b:Ldk;

    .line 65
    .line 66
    invoke-virtual {p1}, Ld10;->Z()V

    .line 67
    .line 68
    .line 69
    iget-boolean v7, p1, Ld10;->S:Z

    .line 70
    .line 71
    if-eqz v7, :cond_4c

    .line 72
    .line 73
    invoke-virtual {p1, v4}, Ld10;->k(Lxz;)V

    .line 74
    .line 75
    .line 76
    goto :goto_4f

    .line 77
    :cond_4c
    invoke-virtual {p1}, Ld10;->j0()V

    .line 78
    .line 79
    .line 80
    :goto_4f
    sget-object v4, Lhj;->f:Ls7;

    .line 81
    .line 82
    invoke-static {v4, p1, p2}, Lmc0;->B(Lm00;Ld10;Ljava/lang/Object;)V

    .line 83
    .line 84
    .line 85
    sget-object p2, Lhj;->e:Ls7;

    .line 86
    .line 87
    invoke-static {p2, p1, v3}, Lmc0;->B(Lm00;Ld10;Ljava/lang/Object;)V

    .line 88
    .line 89
    .line 90
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 91
    .line 92
    .line 93
    move-result-object p2

    .line 94
    sget-object v0, Lhj;->g:Ls7;

    .line 95
    .line 96
    invoke-static {p1, p2, v0}, Lmc0;->p(Ld10;Ljava/lang/Integer;Lm00;)V

    .line 97
    .line 98
    .line 99
    sget-object p2, Lhj;->h:Li4;

    .line 100
    .line 101
    invoke-static {p1, p2}, Lmc0;->w(Ld10;Li00;)V

    .line 102
    .line 103
    .line 104
    sget-object p2, Lhj;->d:Ls7;

    .line 105
    .line 106
    invoke-static {p2, p1, v1}, Lmc0;->B(Lm00;Ld10;Ljava/lang/Object;)V

    .line 107
    .line 108
    .line 109
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 110
    .line 111
    .line 112
    move-result-object p2

    .line 113
    invoke-interface {p0, p1, p2}, Lm00;->f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 114
    .line 115
    .line 116
    invoke-virtual {p1, v5}, Ld10;->p(Z)V

    .line 117
    .line 118
    .line 119
    goto :goto_7a

    .line 120
    :cond_77
    invoke-virtual {p1}, Ld10;->R()V

    .line 121
    .line 122
    .line 123
    :goto_7a
    return-object v2

    .line 124
    :pswitch_7b  #0x3
    check-cast p1, Ld10;

    .line 125
    .line 126
    check-cast p2, Ljava/lang/Integer;

    .line 127
    .line 128
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 129
    .line 130
    .line 131
    move-result p2

    .line 132
    and-int/lit8 v0, p2, 0x3

    .line 133
    .line 134
    if-eq v0, v4, :cond_89

    .line 135
    .line 136
    move v0, v5

    .line 137
    goto :goto_8a

    .line 138
    :cond_89
    move v0, v6

    .line 139
    :goto_8a
    and-int/2addr p2, v5

    .line 140
    invoke-virtual {p1, p2, v0}, Ld10;->O(IZ)Z

    .line 141
    .line 142
    .line 143
    move-result p2

    .line 144
    if-eqz p2, :cond_e2

    .line 145
    .line 146
    sget-object p2, Le3;->f:Lnb;

    .line 147
    .line 148
    invoke-static {p2, v6}, Lic;->d(Lnb;Z)Lmh0;

    .line 149
    .line 150
    .line 151
    move-result-object p2

    .line 152
    iget-wide v7, p1, Ld10;->T:J

    .line 153
    .line 154
    ushr-long v3, v7, v3

    .line 155
    .line 156
    xor-long/2addr v3, v7

    .line 157
    long-to-int v0, v3

    .line 158
    invoke-virtual {p1}, Ld10;->l()Lqr0;

    .line 159
    .line 160
    .line 161
    move-result-object v3

    .line 162
    invoke-static {p1, v1}, Lvn;->I(Ld10;Lmi0;)Lmi0;

    .line 163
    .line 164
    .line 165
    move-result-object v1

    .line 166
    sget-object v4, Lij;->c:Lhj;

    .line 167
    .line 168
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 169
    .line 170
    .line 171
    sget-object v4, Lhj;->b:Ldk;

    .line 172
    .line 173
    invoke-virtual {p1}, Ld10;->Z()V

    .line 174
    .line 175
    .line 176
    iget-boolean v7, p1, Ld10;->S:Z

    .line 177
    .line 178
    if-eqz v7, :cond_b7

    .line 179
    .line 180
    invoke-virtual {p1, v4}, Ld10;->k(Lxz;)V

    .line 181
    .line 182
    .line 183
    goto :goto_ba

    .line 184
    :cond_b7
    invoke-virtual {p1}, Ld10;->j0()V

    .line 185
    .line 186
    .line 187
    :goto_ba
    sget-object v4, Lhj;->f:Ls7;

    .line 188
    .line 189
    invoke-static {v4, p1, p2}, Lmc0;->B(Lm00;Ld10;Ljava/lang/Object;)V

    .line 190
    .line 191
    .line 192
    sget-object p2, Lhj;->e:Ls7;

    .line 193
    .line 194
    invoke-static {p2, p1, v3}, Lmc0;->B(Lm00;Ld10;Ljava/lang/Object;)V

    .line 195
    .line 196
    .line 197
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 198
    .line 199
    .line 200
    move-result-object p2

    .line 201
    sget-object v0, Lhj;->g:Ls7;

    .line 202
    .line 203
    invoke-static {p1, p2, v0}, Lmc0;->p(Ld10;Ljava/lang/Integer;Lm00;)V

    .line 204
    .line 205
    .line 206
    sget-object p2, Lhj;->h:Li4;

    .line 207
    .line 208
    invoke-static {p1, p2}, Lmc0;->w(Ld10;Li00;)V

    .line 209
    .line 210
    .line 211
    sget-object p2, Lhj;->d:Ls7;

    .line 212
    .line 213
    invoke-static {p2, p1, v1}, Lmc0;->B(Lm00;Ld10;Ljava/lang/Object;)V

    .line 214
    .line 215
    .line 216
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 217
    .line 218
    .line 219
    move-result-object p2

    .line 220
    invoke-interface {p0, p1, p2}, Lm00;->f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 221
    .line 222
    .line 223
    invoke-virtual {p1, v5}, Ld10;->p(Z)V

    .line 224
    .line 225
    .line 226
    goto :goto_e5

    .line 227
    :cond_e2
    invoke-virtual {p1}, Ld10;->R()V

    .line 228
    .line 229
    .line 230
    :goto_e5
    return-object v2

    .line 231
    :pswitch_e6  #0x2
    check-cast p1, Liz0;

    .line 232
    .line 233
    invoke-interface {p0, p1, p2}, Lm00;->f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 234
    .line 235
    .line 236
    move-result-object p0

    .line 237
    check-cast p0, Ljava/util/List;

    .line 238
    .line 239
    invoke-interface {p0}, Ljava/util/Collection;->size()I

    .line 240
    .line 241
    .line 242
    move-result p2

    .line 243
    :goto_f2
    if-ge v6, p2, :cond_128

    .line 244
    .line 245
    invoke-interface {p0, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 246
    .line 247
    .line 248
    move-result-object v0

    .line 249
    if-eqz v0, :cond_125

    .line 250
    .line 251
    iget-object v1, p1, Liz0;->f:Lmz0;

    .line 252
    .line 253
    if-eqz v1, :cond_125

    .line 254
    .line 255
    invoke-interface {v1, v0}, Lmz0;->d(Ljava/lang/Object;)Z

    .line 256
    .line 257
    .line 258
    move-result v1

    .line 259
    if-eqz v1, :cond_105

    .line 260
    .line 261
    goto :goto_125

    .line 262
    :cond_105
    new-instance p0, Ljava/lang/StringBuilder;

    .line 263
    .line 264
    const-string p1, "item at index "

    .line 265
    .line 266
    invoke-direct {p0, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 267
    .line 268
    .line 269
    invoke-virtual {p0, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 270
    .line 271
    .line 272
    const-string p1, " can\'t be saved: "

    .line 273
    .line 274
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 275
    .line 276
    .line 277
    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 278
    .line 279
    .line 280
    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 281
    .line 282
    .line 283
    move-result-object p0

    .line 284
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 285
    .line 286
    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 287
    .line 288
    .line 289
    move-result-object p0

    .line 290
    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 291
    .line 292
    .line 293
    throw p1

    .line 294
    :cond_125
    :goto_125
    add-int/lit8 v6, v6, 0x1

    .line 295
    .line 296
    goto :goto_f2

    .line 297
    :cond_128
    invoke-interface {p0}, Ljava/util/Collection;->isEmpty()Z

    .line 298
    .line 299
    .line 300
    move-result p1

    .line 301
    if-nez p1, :cond_134

    .line 302
    .line 303
    new-instance p1, Ljava/util/ArrayList;

    .line 304
    .line 305
    invoke-direct {p1, p0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 306
    .line 307
    .line 308
    goto :goto_135

    .line 309
    :cond_134
    const/4 p1, 0x0

    .line 310
    :goto_135
    return-object p1

    .line 311
    :pswitch_136  #0x1
    check-cast p1, Ld10;

    .line 312
    .line 313
    check-cast p2, Ljava/lang/Integer;

    .line 314
    .line 315
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 316
    .line 317
    .line 318
    move-result p2

    .line 319
    and-int/lit8 v0, p2, 0x3

    .line 320
    .line 321
    if-eq v0, v4, :cond_144

    .line 322
    .line 323
    move v0, v5

    .line 324
    goto :goto_145

    .line 325
    :cond_144
    move v0, v6

    .line 326
    :goto_145
    and-int/2addr p2, v5

    .line 327
    invoke-virtual {p1, p2, v0}, Ld10;->O(IZ)Z

    .line 328
    .line 329
    .line 330
    move-result p2

    .line 331
    if-eqz p2, :cond_1b5

    .line 332
    .line 333
    new-instance p2, Lra0;

    .line 334
    .line 335
    const/high16 v0, 0x3f800000  # 1.0f

    .line 336
    .line 337
    invoke-direct {p2, v0, v6}, Lra0;-><init>(FZ)V

    .line 338
    .line 339
    .line 340
    sget-object v0, Ld3;->c:Lup0;

    .line 341
    .line 342
    invoke-static {p2, v0}, Lac;->C(Lmi0;Lsp0;)Lmi0;

    .line 343
    .line 344
    .line 345
    move-result-object p2

    .line 346
    sget-object v0, Le3;->q:Llb;

    .line 347
    .line 348
    new-instance v1, Lf30;

    .line 349
    .line 350
    invoke-direct {v1, v0}, Lf30;-><init>(Llb;)V

    .line 351
    .line 352
    .line 353
    invoke-interface {p2, v1}, Lmi0;->b(Lmi0;)Lmi0;

    .line 354
    .line 355
    .line 356
    move-result-object p2

    .line 357
    sget-object v0, Le3;->f:Lnb;

    .line 358
    .line 359
    invoke-static {v0, v6}, Lic;->d(Lnb;Z)Lmh0;

    .line 360
    .line 361
    .line 362
    move-result-object v0

    .line 363
    iget-wide v7, p1, Ld10;->T:J

    .line 364
    .line 365
    ushr-long v3, v7, v3

    .line 366
    .line 367
    xor-long/2addr v3, v7

    .line 368
    long-to-int v1, v3

    .line 369
    invoke-virtual {p1}, Ld10;->l()Lqr0;

    .line 370
    .line 371
    .line 372
    move-result-object v3

    .line 373
    invoke-static {p1, p2}, Lvn;->I(Ld10;Lmi0;)Lmi0;

    .line 374
    .line 375
    .line 376
    move-result-object p2

    .line 377
    sget-object v4, Lij;->c:Lhj;

    .line 378
    .line 379
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 380
    .line 381
    .line 382
    sget-object v4, Lhj;->b:Ldk;

    .line 383
    .line 384
    invoke-virtual {p1}, Ld10;->Z()V

    .line 385
    .line 386
    .line 387
    iget-boolean v7, p1, Ld10;->S:Z

    .line 388
    .line 389
    if-eqz v7, :cond_18a

    .line 390
    .line 391
    invoke-virtual {p1, v4}, Ld10;->k(Lxz;)V

    .line 392
    .line 393
    .line 394
    goto :goto_18d

    .line 395
    :cond_18a
    invoke-virtual {p1}, Ld10;->j0()V

    .line 396
    .line 397
    .line 398
    :goto_18d
    sget-object v4, Lhj;->f:Ls7;

    .line 399
    .line 400
    invoke-static {v4, p1, v0}, Lmc0;->B(Lm00;Ld10;Ljava/lang/Object;)V

    .line 401
    .line 402
    .line 403
    sget-object v0, Lhj;->e:Ls7;

    .line 404
    .line 405
    invoke-static {v0, p1, v3}, Lmc0;->B(Lm00;Ld10;Ljava/lang/Object;)V

    .line 406
    .line 407
    .line 408
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 409
    .line 410
    .line 411
    move-result-object v0

    .line 412
    sget-object v1, Lhj;->g:Ls7;

    .line 413
    .line 414
    invoke-static {p1, v0, v1}, Lmc0;->p(Ld10;Ljava/lang/Integer;Lm00;)V

    .line 415
    .line 416
    .line 417
    sget-object v0, Lhj;->h:Li4;

    .line 418
    .line 419
    invoke-static {p1, v0}, Lmc0;->w(Ld10;Li00;)V

    .line 420
    .line 421
    .line 422
    sget-object v0, Lhj;->d:Ls7;

    .line 423
    .line 424
    invoke-static {v0, p1, p2}, Lmc0;->B(Lm00;Ld10;Ljava/lang/Object;)V

    .line 425
    .line 426
    .line 427
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 428
    .line 429
    .line 430
    move-result-object p2

    .line 431
    invoke-interface {p0, p1, p2}, Lm00;->f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 432
    .line 433
    .line 434
    invoke-virtual {p1, v5}, Ld10;->p(Z)V

    .line 435
    .line 436
    .line 437
    goto :goto_1b8

    .line 438
    :cond_1b5
    invoke-virtual {p1}, Ld10;->R()V

    .line 439
    .line 440
    .line 441
    :goto_1b8
    return-object v2

    .line 442
    :pswitch_1b9  #0x0
    check-cast p1, Ld10;

    .line 443
    .line 444
    check-cast p2, Ljava/lang/Integer;

    .line 445
    .line 446
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 447
    .line 448
    .line 449
    move-result p2

    .line 450
    and-int/lit8 v0, p2, 0x3

    .line 451
    .line 452
    if-eq v0, v4, :cond_1c7

    .line 453
    .line 454
    move v0, v5

    .line 455
    goto :goto_1c8

    .line 456
    :cond_1c7
    move v0, v6

    .line 457
    :goto_1c8
    and-int/2addr p2, v5

    .line 458
    invoke-virtual {p1, p2, v0}, Ld10;->O(IZ)Z

    .line 459
    .line 460
    .line 461
    move-result p2

    .line 462
    if-eqz p2, :cond_231

    .line 463
    .line 464
    sget-object p2, Ld3;->b:Lup0;

    .line 465
    .line 466
    invoke-static {v1, p2}, Lac;->C(Lmi0;Lsp0;)Lmi0;

    .line 467
    .line 468
    .line 469
    move-result-object p2

    .line 470
    sget-object v0, Le3;->q:Llb;

    .line 471
    .line 472
    new-instance v1, Lf30;

    .line 473
    .line 474
    invoke-direct {v1, v0}, Lf30;-><init>(Llb;)V

    .line 475
    .line 476
    .line 477
    invoke-interface {p2, v1}, Lmi0;->b(Lmi0;)Lmi0;

    .line 478
    .line 479
    .line 480
    move-result-object p2

    .line 481
    sget-object v0, Le3;->f:Lnb;

    .line 482
    .line 483
    invoke-static {v0, v6}, Lic;->d(Lnb;Z)Lmh0;

    .line 484
    .line 485
    .line 486
    move-result-object v0

    .line 487
    iget-wide v7, p1, Ld10;->T:J

    .line 488
    .line 489
    ushr-long v3, v7, v3

    .line 490
    .line 491
    xor-long/2addr v3, v7

    .line 492
    long-to-int v1, v3

    .line 493
    invoke-virtual {p1}, Ld10;->l()Lqr0;

    .line 494
    .line 495
    .line 496
    move-result-object v3

    .line 497
    invoke-static {p1, p2}, Lvn;->I(Ld10;Lmi0;)Lmi0;

    .line 498
    .line 499
    .line 500
    move-result-object p2

    .line 501
    sget-object v4, Lij;->c:Lhj;

    .line 502
    .line 503
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 504
    .line 505
    .line 506
    sget-object v4, Lhj;->b:Ldk;

    .line 507
    .line 508
    invoke-virtual {p1}, Ld10;->Z()V

    .line 509
    .line 510
    .line 511
    iget-boolean v7, p1, Ld10;->S:Z

    .line 512
    .line 513
    if-eqz v7, :cond_206

    .line 514
    .line 515
    invoke-virtual {p1, v4}, Ld10;->k(Lxz;)V

    .line 516
    .line 517
    .line 518
    goto :goto_209

    .line 519
    :cond_206
    invoke-virtual {p1}, Ld10;->j0()V

    .line 520
    .line 521
    .line 522
    :goto_209
    sget-object v4, Lhj;->f:Ls7;

    .line 523
    .line 524
    invoke-static {v4, p1, v0}, Lmc0;->B(Lm00;Ld10;Ljava/lang/Object;)V

    .line 525
    .line 526
    .line 527
    sget-object v0, Lhj;->e:Ls7;

    .line 528
    .line 529
    invoke-static {v0, p1, v3}, Lmc0;->B(Lm00;Ld10;Ljava/lang/Object;)V

    .line 530
    .line 531
    .line 532
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 533
    .line 534
    .line 535
    move-result-object v0

    .line 536
    sget-object v1, Lhj;->g:Ls7;

    .line 537
    .line 538
    invoke-static {p1, v0, v1}, Lmc0;->p(Ld10;Ljava/lang/Integer;Lm00;)V

    .line 539
    .line 540
    .line 541
    sget-object v0, Lhj;->h:Li4;

    .line 542
    .line 543
    invoke-static {p1, v0}, Lmc0;->w(Ld10;Li00;)V

    .line 544
    .line 545
    .line 546
    sget-object v0, Lhj;->d:Ls7;

    .line 547
    .line 548
    invoke-static {v0, p1, p2}, Lmc0;->B(Lm00;Ld10;Ljava/lang/Object;)V

    .line 549
    .line 550
    .line 551
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 552
    .line 553
    .line 554
    move-result-object p2

    .line 555
    invoke-interface {p0, p1, p2}, Lm00;->f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 556
    .line 557
    .line 558
    invoke-virtual {p1, v5}, Ld10;->p(Z)V

    .line 559
    .line 560
    .line 561
    goto :goto_234

    .line 562
    :cond_231
    invoke-virtual {p1}, Ld10;->R()V

    .line 563
    .line 564
    .line 565
    :goto_234
    return-object v2

    .line 566
    nop

    .line 567
    :pswitch_data_236
    .packed-switch 0x0
        :pswitch_1b9  #00000000
        :pswitch_136  #00000001
        :pswitch_e6  #00000002
        :pswitch_7b  #00000003
    .end packed-switch
.end method
