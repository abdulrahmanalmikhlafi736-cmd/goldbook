.class public final Len;
.super Lu91;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Ln00;


# instance fields
.field public final synthetic i:I

.field public j:I

.field public synthetic k:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILml;)V
    .registers 4

    .line 11
    const/4 v0, 0x1

    iput v0, p0, Len;->i:I

    invoke-direct {p0, p1, p2}, Lu91;-><init>(ILml;)V

    return-void
.end method

.method public constructor <init>(Ltn;Lml;)V
    .registers 4

    .line 1
    const/4 v0, 0x0

    .line 2
    iput v0, p0, Len;->i:I

    .line 3
    .line 4
    iput-object p1, p0, Len;->k:Ljava/lang/Object;

    .line 5
    .line 6
    const/4 p1, 0x3

    .line 7
    invoke-direct {p0, p1, p2}, Lu91;-><init>(ILml;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final c(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    .line 1
    iget v0, p0, Len;->i:I

    .line 2
    .line 3
    sget-object v1, Lwe1;->a:Lwe1;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_32

    .line 6
    .line 7
    .line 8
    check-cast p1, Lmv;

    .line 9
    .line 10
    check-cast p2, Ljava/lang/Boolean;

    .line 11
    .line 12
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13
    .line 14
    .line 15
    check-cast p3, Lml;

    .line 16
    .line 17
    new-instance p0, Len;

    .line 18
    .line 19
    const/4 p2, 0x3

    .line 20
    invoke-direct {p0, p2, p3}, Len;-><init>(ILml;)V

    .line 21
    .line 22
    .line 23
    iput-object p1, p0, Len;->k:Ljava/lang/Object;

    .line 24
    .line 25
    invoke-virtual {p0, v1}, Len;->p(Ljava/lang/Object;)Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object p0

    .line 29
    return-object p0

    .line 30
    :pswitch_1d  #0x0
    check-cast p1, Luw;

    .line 31
    .line 32
    check-cast p2, Ljava/lang/Throwable;

    .line 33
    .line 34
    check-cast p3, Lml;

    .line 35
    .line 36
    new-instance p1, Len;

    .line 37
    .line 38
    iget-object p0, p0, Len;->k:Ljava/lang/Object;

    .line 39
    .line 40
    check-cast p0, Ltn;

    .line 41
    .line 42
    invoke-direct {p1, p0, p3}, Len;-><init>(Ltn;Lml;)V

    .line 43
    .line 44
    .line 45
    invoke-virtual {p1, v1}, Len;->p(Ljava/lang/Object;)Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object p0

    .line 49
    return-object p0

    .line 50
    nop

    .line 51
    :pswitch_data_32
    .packed-switch 0x0
        :pswitch_1d  #00000000
    .end packed-switch
.end method

.method public final p(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 7

    .line 1
    iget v0, p0, Len;->i:I

    .line 2
    .line 3
    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 4
    .line 5
    sget-object v2, Lcm;->e:Lcm;

    .line 6
    .line 7
    const/4 v3, 0x1

    .line 8
    const/4 v4, 0x0

    .line 9
    packed-switch v0, :pswitch_data_64

    .line 10
    .line 11
    .line 12
    iget v0, p0, Len;->j:I

    .line 13
    .line 14
    if-eqz v0, :cond_1a

    .line 15
    .line 16
    if-ne v0, v3, :cond_15

    .line 17
    .line 18
    invoke-static {p1}, Lnb0;->t(Ljava/lang/Object;)V

    .line 19
    .line 20
    .line 21
    goto :goto_40

    .line 22
    :cond_15
    invoke-static {v1}, Lod;->p(Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    :goto_18
    move-object p1, v4

    .line 26
    goto :goto_40

    .line 27
    :cond_1a
    invoke-static {p1}, Lnb0;->t(Ljava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    iget-object p1, p0, Len;->k:Ljava/lang/Object;

    .line 31
    .line 32
    check-cast p1, Lmv;

    .line 33
    .line 34
    iput v3, p0, Len;->j:I

    .line 35
    .line 36
    iget-object v0, p1, Lmv;->b:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 37
    .line 38
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    if-nez v0, :cond_3a

    .line 43
    .line 44
    iget-object v0, p1, Lmv;->a:Ljava/io/File;

    .line 45
    .line 46
    new-instance v1, Lnn;

    .line 47
    .line 48
    invoke-direct {v1, p1, v4, v3}, Lnn;-><init>(Ljava/lang/Object;Lml;I)V

    .line 49
    .line 50
    .line 51
    invoke-static {v0, v1, p0}, Lvd1;->c(Ljava/io/File;Li00;Lnl;)Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    move-result-object p1

    .line 55
    if-ne p1, v2, :cond_40

    .line 56
    .line 57
    move-object p1, v2

    .line 58
    goto :goto_40

    .line 59
    :cond_3a
    const-string p0, "This scope has already been closed."

    .line 60
    .line 61
    invoke-static {p0}, Lod;->p(Ljava/lang/String;)V

    .line 62
    .line 63
    .line 64
    goto :goto_18

    .line 65
    :cond_40
    :goto_40
    return-object p1

    .line 66
    :pswitch_41  #0x0
    iget v0, p0, Len;->j:I

    .line 67
    .line 68
    if-eqz v0, :cond_50

    .line 69
    .line 70
    if-ne v0, v3, :cond_4b

    .line 71
    .line 72
    invoke-static {p1}, Lnb0;->t(Ljava/lang/Object;)V

    .line 73
    .line 74
    .line 75
    goto :goto_60

    .line 76
    :cond_4b
    invoke-static {v1}, Lod;->p(Ljava/lang/String;)V

    .line 77
    .line 78
    .line 79
    move-object v2, v4

    .line 80
    goto :goto_62

    .line 81
    :cond_50
    invoke-static {p1}, Lnb0;->t(Ljava/lang/Object;)V

    .line 82
    .line 83
    .line 84
    iget-object p1, p0, Len;->k:Ljava/lang/Object;

    .line 85
    .line 86
    check-cast p1, Ltn;

    .line 87
    .line 88
    iput v3, p0, Len;->j:I

    .line 89
    .line 90
    invoke-static {p1, p0}, Ltn;->a(Ltn;Lnl;)Ljava/lang/Object;

    .line 91
    .line 92
    .line 93
    move-result-object p0

    .line 94
    if-ne p0, v2, :cond_60

    .line 95
    .line 96
    goto :goto_62

    .line 97
    :cond_60
    :goto_60
    sget-object v2, Lwe1;->a:Lwe1;

    .line 98
    .line 99
    :goto_62
    return-object v2

    .line 100
    nop

    .line 101
    :pswitch_data_64
    .packed-switch 0x0
        :pswitch_41  #00000000
    .end packed-switch
.end method
