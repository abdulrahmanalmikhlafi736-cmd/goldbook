.class public final Lcg0;
.super Ljs0;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# instance fields
.field public final synthetic f:I

.field public final g:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    .line 1
    iput p1, p0, Lcg0;->f:I

    .line 2
    .line 3
    iput-object p2, p0, Lcg0;->g:Ljava/lang/Object;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final a()F
    .registers 2

    .line 1
    iget v0, p0, Lcg0;->f:I

    .line 2
    .line 3
    iget-object p0, p0, Lcg0;->g:Ljava/lang/Object;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_1a

    .line 6
    .line 7
    .line 8
    check-cast p0, Ln4;

    .line 9
    .line 10
    invoke-virtual {p0}, Ln4;->getDensity()Ljp;

    .line 11
    .line 12
    .line 13
    move-result-object p0

    .line 14
    invoke-interface {p0}, Ljp;->a()F

    .line 15
    .line 16
    .line 17
    move-result p0

    .line 18
    return p0

    .line 19
    :pswitch_12  #0x0
    check-cast p0, Lbg0;

    .line 20
    .line 21
    invoke-interface {p0}, Ljp;->a()F

    .line 22
    .line 23
    .line 24
    move-result p0

    .line 25
    return p0

    .line 26
    nop

    .line 27
    :pswitch_data_1a
    .packed-switch 0x0
        :pswitch_12  #00000000
    .end packed-switch
.end method

.method public d(Lj30;)F
    .registers 10

    .line 1
    iget v0, p0, Lcg0;->f:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_b8

    .line 4
    .line 5
    .line 6
    invoke-super {p0, p1}, Ljs0;->d(Lj30;)F

    .line 7
    .line 8
    .line 9
    move-result p0

    .line 10
    return p0

    .line 11
    :pswitch_a  #0x0
    iget-object v0, p1, Lj30;->a:Lm00;

    .line 12
    .line 13
    const/high16 v1, 0x7fc00000  # Float.NaN

    .line 14
    .line 15
    if-eqz v0, :cond_20

    .line 16
    .line 17
    invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 18
    .line 19
    .line 20
    move-result-object p1

    .line 21
    invoke-interface {v0, p0, p1}, Lm00;->f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object p0

    .line 25
    check-cast p0, Ljava/lang/Number;

    .line 26
    .line 27
    invoke-virtual {p0}, Ljava/lang/Number;->floatValue()F

    .line 28
    .line 29
    .line 30
    move-result v1

    .line 31
    goto/16 :goto_b3

    .line 32
    .line 33
    :cond_20
    iget-object p0, p0, Lcg0;->g:Ljava/lang/Object;

    .line 34
    .line 35
    check-cast p0, Lbg0;

    .line 36
    .line 37
    iget-boolean v0, p0, Lbg0;->o:Z

    .line 38
    .line 39
    if-eqz v0, :cond_2a

    .line 40
    .line 41
    goto/16 :goto_b3

    .line 42
    .line 43
    :cond_2a
    move-object v0, p0

    .line 44
    :goto_2b
    iget-object v2, v0, Lbg0;->q:Lwy0;

    .line 45
    .line 46
    if-eqz v2, :cond_41

    .line 47
    .line 48
    iget-object v3, v2, Lwy0;->b:Ljava/lang/Object;

    .line 49
    .line 50
    check-cast v3, [Lj30;

    .line 51
    .line 52
    invoke-static {v3, p1}, Lba;->f0([Ljava/lang/Object;Ljava/lang/Object;)I

    .line 53
    .line 54
    .line 55
    move-result v3

    .line 56
    if-gez v3, :cond_3a

    .line 57
    .line 58
    goto :goto_41

    .line 59
    :cond_3a
    iget-object v2, v2, Lwy0;->c:Ljava/io/Serializable;

    .line 60
    .line 61
    check-cast v2, [F

    .line 62
    .line 63
    aget v2, v2, v3

    .line 64
    .line 65
    goto :goto_42

    .line 66
    :cond_41
    :goto_41
    move v2, v1

    .line 67
    :goto_42
    invoke-static {v2}, Ljava/lang/Float;->isNaN(F)Z

    .line 68
    .line 69
    .line 70
    move-result v3

    .line 71
    if-nez v3, :cond_a6

    .line 72
    .line 73
    invoke-virtual {p0}, Lbg0;->f0()Lba0;

    .line 74
    .line 75
    .line 76
    move-result-object v1

    .line 77
    invoke-virtual {v0, v1, p1}, Lbg0;->U(Lba0;Lj30;)V

    .line 78
    .line 79
    .line 80
    invoke-virtual {v0}, Lbg0;->d0()Ln90;

    .line 81
    .line 82
    .line 83
    move-result-object v0

    .line 84
    invoke-virtual {p0}, Lbg0;->d0()Ln90;

    .line 85
    .line 86
    .line 87
    move-result-object p0

    .line 88
    iget p1, p1, Lj30;->b:I

    .line 89
    .line 90
    const/16 v1, 0x20

    .line 91
    .line 92
    const/high16 v3, 0x40000000  # 2.0f

    .line 93
    .line 94
    const-wide v4, 0xffffffffL

    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    packed-switch p1, :pswitch_data_be

    .line 100
    .line 101
    .line 102
    invoke-interface {v0}, Ln90;->A()J

    .line 103
    .line 104
    .line 105
    move-result-wide v6

    .line 106
    and-long/2addr v6, v4

    .line 107
    long-to-int p1, v6

    .line 108
    int-to-float p1, p1

    .line 109
    div-float/2addr p1, v3

    .line 110
    invoke-static {v2}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 111
    .line 112
    .line 113
    move-result v2

    .line 114
    int-to-long v2, v2

    .line 115
    invoke-static {p1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 116
    .line 117
    .line 118
    move-result p1

    .line 119
    int-to-long v6, p1

    .line 120
    shl-long/2addr v2, v1

    .line 121
    and-long/2addr v4, v6

    .line 122
    or-long/2addr v2, v4

    .line 123
    invoke-interface {p0, v0, v2, v3}, Ln90;->v(Ln90;J)J

    .line 124
    .line 125
    .line 126
    move-result-wide p0

    .line 127
    shr-long/2addr p0, v1

    .line 128
    long-to-int p0, p0

    .line 129
    invoke-static {p0}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 130
    .line 131
    .line 132
    move-result p0

    .line 133
    :goto_84
    move v1, p0

    .line 134
    goto :goto_b3

    .line 135
    :pswitch_86  #0x0
    invoke-interface {v0}, Ln90;->A()J

    .line 136
    .line 137
    .line 138
    move-result-wide v6

    .line 139
    shr-long/2addr v6, v1

    .line 140
    long-to-int p1, v6

    .line 141
    int-to-float p1, p1

    .line 142
    div-float/2addr p1, v3

    .line 143
    invoke-static {p1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 144
    .line 145
    .line 146
    move-result p1

    .line 147
    int-to-long v6, p1

    .line 148
    invoke-static {v2}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 149
    .line 150
    .line 151
    move-result p1

    .line 152
    int-to-long v2, p1

    .line 153
    shl-long/2addr v6, v1

    .line 154
    and-long/2addr v2, v4

    .line 155
    or-long/2addr v2, v6

    .line 156
    invoke-interface {p0, v0, v2, v3}, Ln90;->v(Ln90;J)J

    .line 157
    .line 158
    .line 159
    move-result-wide p0

    .line 160
    and-long/2addr p0, v4

    .line 161
    long-to-int p0, p0

    .line 162
    invoke-static {p0}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 163
    .line 164
    .line 165
    move-result p0

    .line 166
    goto :goto_84

    .line 167
    :cond_a6
    invoke-virtual {v0}, Lbg0;->h0()Lbg0;

    .line 168
    .line 169
    .line 170
    move-result-object v2

    .line 171
    if-nez v2, :cond_b4

    .line 172
    .line 173
    invoke-virtual {p0}, Lbg0;->f0()Lba0;

    .line 174
    .line 175
    .line 176
    move-result-object p0

    .line 177
    invoke-virtual {v0, p0, p1}, Lbg0;->U(Lba0;Lj30;)V

    .line 178
    .line 179
    .line 180
    :goto_b3
    return v1

    .line 181
    :cond_b4
    move-object v0, v2

    .line 182
    goto/16 :goto_2b

    .line 183
    .line 184
    nop

    .line 185
    :pswitch_data_b8
    .packed-switch 0x0
        :pswitch_a  #00000000
    .end packed-switch

    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    :pswitch_data_be
    .packed-switch 0x0
        :pswitch_86  #00000000
    .end packed-switch
.end method

.method public final e()Lo90;
    .registers 2

    .line 1
    iget v0, p0, Lcg0;->f:I

    .line 2
    .line 3
    iget-object p0, p0, Lcg0;->g:Ljava/lang/Object;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_16

    .line 6
    .line 7
    .line 8
    check-cast p0, Ln4;

    .line 9
    .line 10
    invoke-virtual {p0}, Ln4;->getLayoutDirection()Lo90;

    .line 11
    .line 12
    .line 13
    move-result-object p0

    .line 14
    return-object p0

    .line 15
    :pswitch_e  #0x0
    check-cast p0, Lbg0;

    .line 16
    .line 17
    invoke-interface {p0}, Lg70;->getLayoutDirection()Lo90;

    .line 18
    .line 19
    .line 20
    move-result-object p0

    .line 21
    return-object p0

    .line 22
    nop

    .line 23
    :pswitch_data_16
    .packed-switch 0x0
        :pswitch_e  #00000000
    .end packed-switch
.end method

.method public final f()I
    .registers 2

    .line 1
    iget v0, p0, Lcg0;->f:I

    .line 2
    .line 3
    iget-object p0, p0, Lcg0;->g:Ljava/lang/Object;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_1c

    .line 6
    .line 7
    .line 8
    check-cast p0, Ln4;

    .line 9
    .line 10
    invoke-virtual {p0}, Ln4;->getRoot()Lba0;

    .line 11
    .line 12
    .line 13
    move-result-object p0

    .line 14
    iget-object p0, p0, Lba0;->K:Lfa0;

    .line 15
    .line 16
    iget-object p0, p0, Lfa0;->p:Llh0;

    .line 17
    .line 18
    iget p0, p0, Lks0;->e:I

    .line 19
    .line 20
    return p0

    .line 21
    :pswitch_14  #0x0
    check-cast p0, Lbg0;

    .line 22
    .line 23
    invoke-virtual {p0}, Lks0;->P()I

    .line 24
    .line 25
    .line 26
    move-result p0

    .line 27
    return p0

    .line 28
    nop

    .line 29
    :pswitch_data_1c
    .packed-switch 0x0
        :pswitch_14  #00000000
    .end packed-switch
.end method

.method public final g()F
    .registers 2

    .line 1
    iget v0, p0, Lcg0;->f:I

    .line 2
    .line 3
    iget-object p0, p0, Lcg0;->g:Ljava/lang/Object;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_1a

    .line 6
    .line 7
    .line 8
    check-cast p0, Ln4;

    .line 9
    .line 10
    invoke-virtual {p0}, Ln4;->getDensity()Ljp;

    .line 11
    .line 12
    .line 13
    move-result-object p0

    .line 14
    invoke-interface {p0}, Ljp;->g()F

    .line 15
    .line 16
    .line 17
    move-result p0

    .line 18
    return p0

    .line 19
    :pswitch_12  #0x0
    check-cast p0, Lbg0;

    .line 20
    .line 21
    invoke-interface {p0}, Ljp;->g()F

    .line 22
    .line 23
    .line 24
    move-result p0

    .line 25
    return p0

    .line 26
    nop

    .line 27
    :pswitch_data_1a
    .packed-switch 0x0
        :pswitch_12  #00000000
    .end packed-switch
.end method
