.class public final Le91;
.super Lh90;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lm00;


# instance fields
.field public final synthetic f:I

.field public final synthetic g:Lf91;


# direct methods
.method public synthetic constructor <init>(Lf91;I)V
    .registers 3

    .line 1
    iput p2, p0, Le91;->f:I

    .line 2
    .line 3
    iput-object p1, p0, Le91;->g:Lf91;

    .line 4
    .line 5
    const/4 p1, 0x2

    .line 6
    invoke-direct {p0, p1}, Lh90;-><init>(I)V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    .line 1
    iget v0, p0, Le91;->f:I

    .line 2
    .line 3
    sget-object v1, Lwe1;->a:Lwe1;

    .line 4
    .line 5
    iget-object p0, p0, Le91;->g:Lf91;

    .line 6
    .line 7
    packed-switch v0, :pswitch_data_56

    .line 8
    .line 9
    .line 10
    check-cast p1, Lba0;

    .line 11
    .line 12
    check-cast p2, Lf91;

    .line 13
    .line 14
    iget-object p2, p0, Lf91;->a:Li91;

    .line 15
    .line 16
    iget-object v0, p1, Lba0;->L:Lpa0;

    .line 17
    .line 18
    if-nez v0, :cond_1a

    .line 19
    .line 20
    new-instance v0, Lpa0;

    .line 21
    .line 22
    invoke-direct {v0, p1, p2}, Lpa0;-><init>(Lba0;Li91;)V

    .line 23
    .line 24
    .line 25
    iput-object v0, p1, Lba0;->L:Lpa0;

    .line 26
    .line 27
    :cond_1a
    iput-object v0, p0, Lf91;->b:Lpa0;

    .line 28
    .line 29
    invoke-virtual {p0}, Lf91;->a()Lpa0;

    .line 30
    .line 31
    .line 32
    move-result-object p1

    .line 33
    invoke-virtual {p1}, Lpa0;->h()V

    .line 34
    .line 35
    .line 36
    invoke-virtual {p0}, Lf91;->a()Lpa0;

    .line 37
    .line 38
    .line 39
    move-result-object p0

    .line 40
    iget-object p1, p0, Lpa0;->g:Li91;

    .line 41
    .line 42
    if-eq p1, p2, :cond_37

    .line 43
    .line 44
    iput-object p2, p0, Lpa0;->g:Li91;

    .line 45
    .line 46
    const/4 p1, 0x0

    .line 47
    invoke-virtual {p0, p1}, Lpa0;->i(Z)V

    .line 48
    .line 49
    .line 50
    iget-object p0, p0, Lpa0;->e:Lba0;

    .line 51
    .line 52
    const/4 p2, 0x7

    .line 53
    invoke-static {p0, p1, p2}, Lba0;->V(Lba0;ZI)V

    .line 54
    .line 55
    .line 56
    :cond_37
    return-object v1

    .line 57
    :pswitch_38  #0x1
    check-cast p1, Lba0;

    .line 58
    .line 59
    check-cast p2, Lm00;

    .line 60
    .line 61
    invoke-virtual {p0}, Lf91;->a()Lpa0;

    .line 62
    .line 63
    .line 64
    move-result-object p0

    .line 65
    iget-object v0, p0, Lpa0;->t:Ljava/lang/String;

    .line 66
    .line 67
    new-instance v2, Lla0;

    .line 68
    .line 69
    invoke-direct {v2, p0, p2, v0}, Lla0;-><init>(Lpa0;Lm00;Ljava/lang/String;)V

    .line 70
    .line 71
    .line 72
    invoke-virtual {p1, v2}, Lba0;->c0(Lmh0;)V

    .line 73
    .line 74
    .line 75
    return-object v1

    .line 76
    :pswitch_4b  #0x0
    check-cast p1, Lba0;

    .line 77
    .line 78
    check-cast p2, Lsj;

    .line 79
    .line 80
    invoke-virtual {p0}, Lf91;->a()Lpa0;

    .line 81
    .line 82
    .line 83
    move-result-object p0

    .line 84
    iput-object p2, p0, Lpa0;->f:Lsj;

    .line 85
    .line 86
    return-object v1

    .line 87
    :pswitch_data_56
    .packed-switch 0x0
        :pswitch_4b  #00000000
        :pswitch_38  #00000001
    .end packed-switch
.end method
