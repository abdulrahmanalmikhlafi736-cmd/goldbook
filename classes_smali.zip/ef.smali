.class public final Lef;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Luw;


# instance fields
.field public final synthetic e:I

.field public final synthetic f:Ljava/io/Serializable;

.field public final synthetic g:Ljava/lang/Object;

.field public final synthetic h:Ljava/lang/Object;

.field public final synthetic i:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/io/Serializable;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V
    .registers 6

    .line 1
    iput p5, p0, Lef;->e:I

    .line 2
    .line 3
    iput-object p1, p0, Lef;->f:Ljava/io/Serializable;

    .line 4
    .line 5
    iput-object p2, p0, Lef;->g:Ljava/lang/Object;

    .line 6
    .line 7
    iput-object p3, p0, Lef;->h:Ljava/lang/Object;

    .line 8
    .line 9
    iput-object p4, p0, Lef;->i:Ljava/lang/Object;

    .line 10
    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 12
    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final k(Ljava/lang/Object;Lml;)Ljava/lang/Object;
    .registers 11

    .line 1
    iget v0, p0, Lef;->e:I

    .line 2
    .line 3
    sget-object v1, Lwe1;->a:Lwe1;

    .line 4
    .line 5
    const/4 v2, 0x1

    .line 6
    iget-object v3, p0, Lef;->f:Ljava/io/Serializable;

    .line 7
    .line 8
    const/4 v4, 0x0

    .line 9
    packed-switch v0, :pswitch_data_106

    .line 10
    .line 11
    .line 12
    check-cast p1, Ly60;

    .line 13
    .line 14
    iget-object p2, p0, Lef;->h:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast p2, Llw0;

    .line 17
    .line 18
    iget-object v0, p0, Lef;->g:Ljava/lang/Object;

    .line 19
    .line 20
    check-cast v0, Llw0;

    .line 21
    .line 22
    check-cast v3, Llw0;

    .line 23
    .line 24
    instance-of v5, p1, Lou0;

    .line 25
    .line 26
    if-eqz v5, :cond_21

    .line 27
    .line 28
    iget p1, v3, Llw0;->e:I

    .line 29
    .line 30
    add-int/2addr p1, v2

    .line 31
    iput p1, v3, Llw0;->e:I

    .line 32
    .line 33
    goto :goto_60

    .line 34
    :cond_21
    instance-of v5, p1, Lpu0;

    .line 35
    .line 36
    if-eqz v5, :cond_2c

    .line 37
    .line 38
    iget p1, v3, Llw0;->e:I

    .line 39
    .line 40
    add-int/lit8 p1, p1, -0x1

    .line 41
    .line 42
    iput p1, v3, Llw0;->e:I

    .line 43
    .line 44
    goto :goto_60

    .line 45
    :cond_2c
    instance-of v5, p1, Lnu0;

    .line 46
    .line 47
    if-eqz v5, :cond_37

    .line 48
    .line 49
    iget p1, v3, Llw0;->e:I

    .line 50
    .line 51
    add-int/lit8 p1, p1, -0x1

    .line 52
    .line 53
    iput p1, v3, Llw0;->e:I

    .line 54
    .line 55
    goto :goto_60

    .line 56
    :cond_37
    instance-of v5, p1, Lm30;

    .line 57
    .line 58
    if-eqz v5, :cond_41

    .line 59
    .line 60
    iget p1, v0, Llw0;->e:I

    .line 61
    .line 62
    add-int/2addr p1, v2

    .line 63
    iput p1, v0, Llw0;->e:I

    .line 64
    .line 65
    goto :goto_60

    .line 66
    :cond_41
    instance-of v5, p1, Ln30;

    .line 67
    .line 68
    if-eqz v5, :cond_4c

    .line 69
    .line 70
    iget p1, v0, Llw0;->e:I

    .line 71
    .line 72
    add-int/lit8 p1, p1, -0x1

    .line 73
    .line 74
    iput p1, v0, Llw0;->e:I

    .line 75
    .line 76
    goto :goto_60

    .line 77
    :cond_4c
    instance-of v5, p1, Lyx;

    .line 78
    .line 79
    if-eqz v5, :cond_56

    .line 80
    .line 81
    iget p1, p2, Llw0;->e:I

    .line 82
    .line 83
    add-int/2addr p1, v2

    .line 84
    iput p1, p2, Llw0;->e:I

    .line 85
    .line 86
    goto :goto_60

    .line 87
    :cond_56
    instance-of p1, p1, Lzx;

    .line 88
    .line 89
    if-eqz p1, :cond_60

    .line 90
    .line 91
    iget p1, p2, Llw0;->e:I

    .line 92
    .line 93
    add-int/lit8 p1, p1, -0x1

    .line 94
    .line 95
    iput p1, p2, Llw0;->e:I

    .line 96
    .line 97
    :cond_60
    :goto_60
    iget p1, v3, Llw0;->e:I

    .line 98
    .line 99
    if-lez p1, :cond_66

    .line 100
    .line 101
    move p1, v2

    .line 102
    goto :goto_67

    .line 103
    :cond_66
    move p1, v4

    .line 104
    :goto_67
    iget v0, v0, Llw0;->e:I

    .line 105
    .line 106
    if-lez v0, :cond_6d

    .line 107
    .line 108
    move v0, v2

    .line 109
    goto :goto_6e

    .line 110
    :cond_6d
    move v0, v4

    .line 111
    :goto_6e
    iget p2, p2, Llw0;->e:I

    .line 112
    .line 113
    if-lez p2, :cond_74

    .line 114
    .line 115
    move p2, v2

    .line 116
    goto :goto_75

    .line 117
    :cond_74
    move p2, v4

    .line 118
    :goto_75
    iget-object p0, p0, Lef;->i:Ljava/lang/Object;

    .line 119
    .line 120
    check-cast p0, Lbo;

    .line 121
    .line 122
    iget-boolean v3, p0, Lbo;->t:Z

    .line 123
    .line 124
    if-eq v3, p1, :cond_80

    .line 125
    .line 126
    iput-boolean p1, p0, Lbo;->t:Z

    .line 127
    .line 128
    move v4, v2

    .line 129
    :cond_80
    iget-boolean p1, p0, Lbo;->u:Z

    .line 130
    .line 131
    if-eq p1, v0, :cond_87

    .line 132
    .line 133
    iput-boolean v0, p0, Lbo;->u:Z

    .line 134
    .line 135
    move v4, v2

    .line 136
    :cond_87
    iget-boolean p1, p0, Lbo;->v:Z

    .line 137
    .line 138
    if-eq p1, p2, :cond_8e

    .line 139
    .line 140
    iput-boolean p2, p0, Lbo;->v:Z

    .line 141
    .line 142
    goto :goto_8f

    .line 143
    :cond_8e
    move v2, v4

    .line 144
    :goto_8f
    if-eqz v2, :cond_94

    .line 145
    .line 146
    invoke-static {p0}, La5;->x(Lds;)V

    .line 147
    .line 148
    .line 149
    :cond_94
    return-object v1

    .line 150
    :pswitch_95  #0x0
    instance-of v0, p2, Ldf;

    .line 151
    .line 152
    if-eqz v0, :cond_a8

    .line 153
    .line 154
    move-object v0, p2

    .line 155
    check-cast v0, Ldf;

    .line 156
    .line 157
    iget v5, v0, Ldf;->l:I

    .line 158
    .line 159
    const/high16 v6, -0x80000000

    .line 160
    .line 161
    and-int v7, v5, v6

    .line 162
    .line 163
    if-eqz v7, :cond_a8

    .line 164
    .line 165
    sub-int/2addr v5, v6

    .line 166
    iput v5, v0, Ldf;->l:I

    .line 167
    .line 168
    goto :goto_ad

    .line 169
    :cond_a8
    new-instance v0, Ldf;

    .line 170
    .line 171
    invoke-direct {v0, p0, p2}, Ldf;-><init>(Lef;Lml;)V

    .line 172
    .line 173
    .line 174
    :goto_ad
    iget-object p2, v0, Ldf;->j:Ljava/lang/Object;

    .line 175
    .line 176
    iget v5, v0, Ldf;->l:I

    .line 177
    .line 178
    const/4 v6, 0x0

    .line 179
    if-eqz v5, :cond_c5

    .line 180
    .line 181
    if-ne v5, v2, :cond_be

    .line 182
    .line 183
    iget-object p1, v0, Ldf;->i:Ljava/lang/Object;

    .line 184
    .line 185
    iget-object p0, v0, Ldf;->h:Lef;

    .line 186
    .line 187
    invoke-static {p2}, Lnb0;->t(Ljava/lang/Object;)V

    .line 188
    .line 189
    .line 190
    goto :goto_ea

    .line 191
    :cond_be
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 192
    .line 193
    invoke-static {p0}, Lod;->p(Ljava/lang/String;)V

    .line 194
    .line 195
    .line 196
    move-object v1, v6

    .line 197
    goto :goto_105

    .line 198
    :cond_c5
    invoke-static {p2}, Lnb0;->t(Ljava/lang/Object;)V

    .line 199
    .line 200
    .line 201
    check-cast v3, Lnw0;

    .line 202
    .line 203
    iget-object p2, v3, Lnw0;->e:Ljava/lang/Object;

    .line 204
    .line 205
    check-cast p2, La80;

    .line 206
    .line 207
    if-eqz p2, :cond_ea

    .line 208
    .line 209
    new-instance v3, Lnf;

    .line 210
    .line 211
    const-string v5, "Child of the scoped flow was cancelled"

    .line 212
    .line 213
    invoke-direct {v3, v5, v4}, Lnf;-><init>(Ljava/lang/String;I)V

    .line 214
    .line 215
    .line 216
    invoke-interface {p2, v3}, La80;->a(Ljava/util/concurrent/CancellationException;)V

    .line 217
    .line 218
    .line 219
    iput-object p0, v0, Ldf;->h:Lef;

    .line 220
    .line 221
    iput-object p1, v0, Ldf;->i:Ljava/lang/Object;

    .line 222
    .line 223
    iput v2, v0, Ldf;->l:I

    .line 224
    .line 225
    invoke-interface {p2, v0}, La80;->v(Lnl;)Ljava/lang/Object;

    .line 226
    .line 227
    .line 228
    move-result-object p2

    .line 229
    sget-object v0, Lcm;->e:Lcm;

    .line 230
    .line 231
    if-ne p2, v0, :cond_ea

    .line 232
    .line 233
    move-object v1, v0

    .line 234
    goto :goto_105

    .line 235
    :cond_ea
    :goto_ea
    iget-object p2, p0, Lef;->f:Ljava/io/Serializable;

    .line 236
    .line 237
    check-cast p2, Lnw0;

    .line 238
    .line 239
    iget-object v0, p0, Lef;->g:Ljava/lang/Object;

    .line 240
    .line 241
    check-cast v0, Lbm;

    .line 242
    .line 243
    new-instance v3, Lcf;

    .line 244
    .line 245
    iget-object v4, p0, Lef;->h:Ljava/lang/Object;

    .line 246
    .line 247
    check-cast v4, Lff;

    .line 248
    .line 249
    iget-object p0, p0, Lef;->i:Ljava/lang/Object;

    .line 250
    .line 251
    check-cast p0, Luw;

    .line 252
    .line 253
    invoke-direct {v3, v4, p0, p1, v6}, Lcf;-><init>(Lff;Luw;Ljava/lang/Object;Lml;)V

    .line 254
    .line 255
    .line 256
    invoke-static {v0, v6, v3, v2}, Lwl1;->B(Lbm;Lsl;Lm00;I)Ls71;

    .line 257
    .line 258
    .line 259
    move-result-object p0

    .line 260
    iput-object p0, p2, Lnw0;->e:Ljava/lang/Object;

    .line 261
    .line 262
    :goto_105
    return-object v1

    .line 263
    :pswitch_data_106
    .packed-switch 0x0
        :pswitch_95  #00000000
    .end packed-switch
.end method
