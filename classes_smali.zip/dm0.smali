.class public final Ldm0;
.super Lli0;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 1

    .line 1
    const-string p0, "<Head>"

    .line 2
    .line 3
    return-object p0
.end method
