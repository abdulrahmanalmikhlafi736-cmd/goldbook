.class public final Lcn;
.super Lu91;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lm00;


# instance fields
.field public final synthetic i:I

.field public synthetic j:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILml;I)V
    .registers 4

    .line 1
    iput p3, p0, Lcn;->i:I

    .line 2
    .line 3
    invoke-direct {p0, p1, p2}, Lu91;-><init>(ILml;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 1
    iget v0, p0, Lcn;->i:I

    .line 2
    .line 3
    sget-object v1, Lwe1;->a:Lwe1;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_34

    .line 6
    .line 7
    .line 8
    check-cast p1, Li51;

    .line 9
    .line 10
    check-cast p2, Lml;

    .line 11
    .line 12
    invoke-virtual {p0, p2, p1}, Lcn;->n(Lml;Ljava/lang/Object;)Lml;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    check-cast p0, Lcn;

    .line 17
    .line 18
    invoke-virtual {p0, v1}, Lcn;->p(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    return-object p0

    .line 23
    :pswitch_16  #0x1
    check-cast p1, Law0;

    .line 24
    .line 25
    check-cast p2, Lml;

    .line 26
    .line 27
    invoke-virtual {p0, p2, p1}, Lcn;->n(Lml;Ljava/lang/Object;)Lml;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    check-cast p0, Lcn;

    .line 32
    .line 33
    invoke-virtual {p0, v1}, Lcn;->p(Ljava/lang/Object;)Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object p0

    .line 37
    return-object p0

    .line 38
    :pswitch_25  #0x0
    check-cast p1, Lz71;

    .line 39
    .line 40
    check-cast p2, Lml;

    .line 41
    .line 42
    invoke-virtual {p0, p2, p1}, Lcn;->n(Lml;Ljava/lang/Object;)Lml;

    .line 43
    .line 44
    .line 45
    move-result-object p0

    .line 46
    check-cast p0, Lcn;

    .line 47
    .line 48
    invoke-virtual {p0, v1}, Lcn;->p(Ljava/lang/Object;)Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    move-result-object p0

    .line 52
    return-object p0

    .line 53
    :pswitch_data_34
    .packed-switch 0x0
        :pswitch_25  #00000000
        :pswitch_16  #00000001
    .end packed-switch
.end method

.method public final n(Lml;Ljava/lang/Object;)Lml;
    .registers 5

    .line 1
    iget p0, p0, Lcn;->i:I

    .line 2
    .line 3
    packed-switch p0, :pswitch_data_24

    .line 4
    .line 5
    .line 6
    new-instance p0, Lcn;

    .line 7
    .line 8
    const/4 v0, 0x2

    .line 9
    const/4 v1, 0x2

    .line 10
    invoke-direct {p0, v0, p1, v1}, Lcn;-><init>(ILml;I)V

    .line 11
    .line 12
    .line 13
    iput-object p2, p0, Lcn;->j:Ljava/lang/Object;

    .line 14
    .line 15
    return-object p0

    .line 16
    :pswitch_f  #0x1
    new-instance p0, Lcn;

    .line 17
    .line 18
    const/4 v0, 0x2

    .line 19
    const/4 v1, 0x1

    .line 20
    invoke-direct {p0, v0, p1, v1}, Lcn;-><init>(ILml;I)V

    .line 21
    .line 22
    .line 23
    iput-object p2, p0, Lcn;->j:Ljava/lang/Object;

    .line 24
    .line 25
    return-object p0

    .line 26
    :pswitch_19  #0x0
    new-instance p0, Lcn;

    .line 27
    .line 28
    const/4 v0, 0x2

    .line 29
    const/4 v1, 0x0

    .line 30
    invoke-direct {p0, v0, p1, v1}, Lcn;-><init>(ILml;I)V

    .line 31
    .line 32
    .line 33
    iput-object p2, p0, Lcn;->j:Ljava/lang/Object;

    .line 34
    .line 35
    return-object p0

    .line 36
    nop

    .line 37
    :pswitch_data_24
    .packed-switch 0x0
        :pswitch_19  #00000000
        :pswitch_f  #00000001
    .end packed-switch
.end method

.method public final p(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 1
    iget v0, p0, Lcn;->i:I

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x1

    .line 5
    packed-switch v0, :pswitch_data_38

    .line 6
    .line 7
    .line 8
    invoke-static {p1}, Lnb0;->t(Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    iget-object p0, p0, Lcn;->j:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast p0, Li51;

    .line 14
    .line 15
    sget-object p1, Li51;->e:Li51;

    .line 16
    .line 17
    if-eq p0, p1, :cond_13

    .line 18
    .line 19
    move v1, v2

    .line 20
    :cond_13
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 21
    .line 22
    .line 23
    move-result-object p0

    .line 24
    return-object p0

    .line 25
    :pswitch_18  #0x1
    invoke-static {p1}, Lnb0;->t(Ljava/lang/Object;)V

    .line 26
    .line 27
    .line 28
    iget-object p0, p0, Lcn;->j:Ljava/lang/Object;

    .line 29
    .line 30
    check-cast p0, Law0;

    .line 31
    .line 32
    sget-object p1, Law0;->e:Law0;

    .line 33
    .line 34
    if-ne p0, p1, :cond_24

    .line 35
    .line 36
    move v1, v2

    .line 37
    :cond_24
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 38
    .line 39
    .line 40
    move-result-object p0

    .line 41
    return-object p0

    .line 42
    :pswitch_29  #0x0
    invoke-static {p1}, Lnb0;->t(Ljava/lang/Object;)V

    .line 43
    .line 44
    .line 45
    iget-object p0, p0, Lcn;->j:Ljava/lang/Object;

    .line 46
    .line 47
    check-cast p0, Lz71;

    .line 48
    .line 49
    instance-of p0, p0, Lxv;

    .line 50
    .line 51
    xor-int/2addr p0, v2

    .line 52
    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 53
    .line 54
    .line 55
    move-result-object p0

    .line 56
    return-object p0

    .line 57
    :pswitch_data_38
    .packed-switch 0x0
        :pswitch_29  #00000000
        :pswitch_18  #00000001
    .end packed-switch
.end method
