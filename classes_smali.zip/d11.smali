.class final Ld11;
.super Lqi0;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lqi0;"
    }
.end annotation


# instance fields
.field public final a:Lr11;

.field public final b:Lbp0;

.field public final c:Z

.field public final d:Ljo;

.field public final e:Luj0;

.field public final f:Z

.field public final g:Lx5;


# direct methods
.method public constructor <init>(Lx5;Ljo;Luj0;Lbp0;Lr11;ZZ)V
    .registers 8

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p5, p0, Ld11;->a:Lr11;

    .line 5
    .line 6
    iput-object p4, p0, Ld11;->b:Lbp0;

    .line 7
    .line 8
    iput-boolean p6, p0, Ld11;->c:Z

    .line 9
    .line 10
    iput-object p2, p0, Ld11;->d:Ljo;

    .line 11
    .line 12
    iput-object p3, p0, Ld11;->e:Luj0;

    .line 13
    .line 14
    iput-boolean p7, p0, Ld11;->f:Z

    .line 15
    .line 16
    iput-object p1, p0, Ld11;->g:Lx5;

    .line 17
    .line 18
    return-void
.end method


# virtual methods
.method public final e()Lli0;
    .registers 3

    .line 1
    new-instance v0, Le11;

    .line 2
    .line 3
    invoke-direct {v0}, Ldp;-><init>()V

    .line 4
    .line 5
    .line 6
    iget-object v1, p0, Ld11;->a:Lr11;

    .line 7
    .line 8
    iput-object v1, v0, Le11;->u:Lr11;

    .line 9
    .line 10
    iget-object v1, p0, Ld11;->b:Lbp0;

    .line 11
    .line 12
    iput-object v1, v0, Le11;->v:Lbp0;

    .line 13
    .line 14
    iget-boolean v1, p0, Ld11;->c:Z

    .line 15
    .line 16
    iput-boolean v1, v0, Le11;->w:Z

    .line 17
    .line 18
    iget-object v1, p0, Ld11;->d:Ljo;

    .line 19
    .line 20
    iput-object v1, v0, Le11;->x:Ljo;

    .line 21
    .line 22
    iget-object v1, p0, Ld11;->e:Luj0;

    .line 23
    .line 24
    iput-object v1, v0, Le11;->y:Luj0;

    .line 25
    .line 26
    iget-boolean v1, p0, Ld11;->f:Z

    .line 27
    .line 28
    iput-boolean v1, v0, Le11;->z:Z

    .line 29
    .line 30
    iget-object p0, p0, Ld11;->g:Lx5;

    .line 31
    .line 32
    iput-object p0, v0, Le11;->A:Lx5;

    .line 33
    .line 34
    return-object v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 4

    .line 1
    if-ne p0, p1, :cond_3

    .line 2
    .line 3
    goto :goto_51

    .line 4
    :cond_3
    if-eqz p1, :cond_53

    .line 5
    .line 6
    const-class v0, Ld11;

    .line 7
    .line 8
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    if-eq v0, v1, :cond_e

    .line 13
    .line 14
    goto :goto_53

    .line 15
    :cond_e
    check-cast p1, Ld11;

    .line 16
    .line 17
    iget-object v0, p0, Ld11;->a:Lr11;

    .line 18
    .line 19
    iget-object v1, p1, Ld11;->a:Lr11;

    .line 20
    .line 21
    invoke-static {v0, v1}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    if-nez v0, :cond_1b

    .line 26
    .line 27
    goto :goto_53

    .line 28
    :cond_1b
    iget-object v0, p0, Ld11;->b:Lbp0;

    .line 29
    .line 30
    iget-object v1, p1, Ld11;->b:Lbp0;

    .line 31
    .line 32
    if-eq v0, v1, :cond_22

    .line 33
    .line 34
    goto :goto_53

    .line 35
    :cond_22
    iget-boolean v0, p0, Ld11;->c:Z

    .line 36
    .line 37
    iget-boolean v1, p1, Ld11;->c:Z

    .line 38
    .line 39
    if-eq v0, v1, :cond_29

    .line 40
    .line 41
    goto :goto_53

    .line 42
    :cond_29
    iget-object v0, p0, Ld11;->d:Ljo;

    .line 43
    .line 44
    iget-object v1, p1, Ld11;->d:Ljo;

    .line 45
    .line 46
    invoke-static {v0, v1}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    if-nez v0, :cond_34

    .line 51
    .line 52
    goto :goto_53

    .line 53
    :cond_34
    iget-object v0, p0, Ld11;->e:Luj0;

    .line 54
    .line 55
    iget-object v1, p1, Ld11;->e:Luj0;

    .line 56
    .line 57
    invoke-static {v0, v1}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 58
    .line 59
    .line 60
    move-result v0

    .line 61
    if-nez v0, :cond_3f

    .line 62
    .line 63
    goto :goto_53

    .line 64
    :cond_3f
    iget-boolean v0, p0, Ld11;->f:Z

    .line 65
    .line 66
    iget-boolean v1, p1, Ld11;->f:Z

    .line 67
    .line 68
    if-eq v0, v1, :cond_46

    .line 69
    .line 70
    goto :goto_53

    .line 71
    :cond_46
    iget-object p0, p0, Ld11;->g:Lx5;

    .line 72
    .line 73
    iget-object p1, p1, Ld11;->g:Lx5;

    .line 74
    .line 75
    invoke-static {p0, p1}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 76
    .line 77
    .line 78
    move-result p0

    .line 79
    if-nez p0, :cond_51

    .line 80
    .line 81
    goto :goto_53

    .line 82
    :cond_51
    :goto_51
    const/4 p0, 0x1

    .line 83
    return p0

    .line 84
    :cond_53
    :goto_53
    const/4 p0, 0x0

    .line 85
    return p0
.end method

.method public final f(Lli0;)V
    .registers 10

    .line 1
    move-object v0, p1

    .line 2
    check-cast v0, Le11;

    .line 3
    .line 4
    iget-object v2, p0, Ld11;->d:Ljo;

    .line 5
    .line 6
    iget-object v3, p0, Ld11;->e:Luj0;

    .line 7
    .line 8
    iget-object v1, p0, Ld11;->g:Lx5;

    .line 9
    .line 10
    iget-object v4, p0, Ld11;->b:Lbp0;

    .line 11
    .line 12
    iget-object v5, p0, Ld11;->a:Lr11;

    .line 13
    .line 14
    iget-boolean v6, p0, Ld11;->f:Z

    .line 15
    .line 16
    iget-boolean v7, p0, Ld11;->c:Z

    .line 17
    .line 18
    invoke-virtual/range {v0 .. v7}, Le11;->w0(Lx5;Ljo;Luj0;Lbp0;Lr11;ZZ)V

    .line 19
    .line 20
    .line 21
    return-void
.end method

.method public final hashCode()I
    .registers 6

    .line 1
    iget-object v0, p0, Ld11;->a:Lr11;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    mul-int/lit8 v0, v0, 0x1f

    .line 8
    .line 9
    iget-object v1, p0, Ld11;->b:Lbp0;

    .line 10
    .line 11
    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    add-int/2addr v1, v0

    .line 16
    mul-int/lit8 v1, v1, 0x1f

    .line 17
    .line 18
    iget-boolean v0, p0, Ld11;->c:Z

    .line 19
    .line 20
    const/16 v2, 0x4d5

    .line 21
    .line 22
    const/16 v3, 0x4cf

    .line 23
    .line 24
    if-eqz v0, :cond_1b

    .line 25
    .line 26
    move v0, v3

    .line 27
    goto :goto_1c

    .line 28
    :cond_1b
    move v0, v2

    .line 29
    :goto_1c
    add-int/2addr v1, v0

    .line 30
    mul-int/lit8 v1, v1, 0x1f

    .line 31
    .line 32
    add-int/2addr v1, v2

    .line 33
    mul-int/lit8 v1, v1, 0x1f

    .line 34
    .line 35
    const/4 v0, 0x0

    .line 36
    iget-object v4, p0, Ld11;->d:Ljo;

    .line 37
    .line 38
    if-eqz v4, :cond_2c

    .line 39
    .line 40
    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    .line 41
    .line 42
    .line 43
    move-result v4

    .line 44
    goto :goto_2d

    .line 45
    :cond_2c
    move v4, v0

    .line 46
    :goto_2d
    add-int/2addr v1, v4

    .line 47
    mul-int/lit8 v1, v1, 0x1f

    .line 48
    .line 49
    iget-object v4, p0, Ld11;->e:Luj0;

    .line 50
    .line 51
    if-eqz v4, :cond_39

    .line 52
    .line 53
    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    .line 54
    .line 55
    .line 56
    move-result v4

    .line 57
    goto :goto_3a

    .line 58
    :cond_39
    move v4, v0

    .line 59
    :goto_3a
    add-int/2addr v1, v4

    .line 60
    mul-int/lit16 v1, v1, 0x3c1

    .line 61
    .line 62
    iget-boolean v4, p0, Ld11;->f:Z

    .line 63
    .line 64
    if-eqz v4, :cond_42

    .line 65
    .line 66
    move v2, v3

    .line 67
    :cond_42
    add-int/2addr v1, v2

    .line 68
    mul-int/lit8 v1, v1, 0x1f

    .line 69
    .line 70
    iget-object p0, p0, Ld11;->g:Lx5;

    .line 71
    .line 72
    if-eqz p0, :cond_4d

    .line 73
    .line 74
    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    .line 75
    .line 76
    .line 77
    move-result v0

    .line 78
    :cond_4d
    add-int/2addr v1, v0

    .line 79
    return v1
.end method
