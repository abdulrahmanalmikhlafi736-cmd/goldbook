.class public final Lcj;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Landroid/view/ScrollCaptureCallback;


# instance fields
.field public final a:Li21;

.field public final b:Lr60;

.field public final c:Lbd0;

.field public final d:Ln4;

.field public final e:Lll;

.field public final f:Ltw0;


# direct methods
.method public constructor <init>(Li21;Lr60;Lll;Lbd0;Ln4;)V
    .registers 6

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lcj;->a:Li21;

    .line 5
    .line 6
    iput-object p2, p0, Lcj;->b:Lr60;

    .line 7
    .line 8
    iput-object p4, p0, Lcj;->c:Lbd0;

    .line 9
    .line 10
    iput-object p5, p0, Lcj;->d:Ln4;

    .line 11
    .line 12
    new-instance p1, Lll;

    .line 13
    .line 14
    iget-object p3, p3, Lll;->e:Lsl;

    .line 15
    .line 16
    sget-object p4, Leq;->f:Leq;

    .line 17
    .line 18
    invoke-interface {p3, p4}, Lsl;->i(Lsl;)Lsl;

    .line 19
    .line 20
    .line 21
    move-result-object p3

    .line 22
    invoke-direct {p1, p3}, Lll;-><init>(Lsl;)V

    .line 23
    .line 24
    .line 25
    iput-object p1, p0, Lcj;->e:Lll;

    .line 26
    .line 27
    new-instance p1, Ltw0;

    .line 28
    .line 29
    iget p3, p2, Lr60;->d:I

    .line 30
    .line 31
    iget p2, p2, Lr60;->b:I

    .line 32
    .line 33
    sub-int/2addr p3, p2

    .line 34
    new-instance p2, Lgc1;

    .line 35
    .line 36
    const/4 p4, 0x0

    .line 37
    invoke-direct {p2, p0, p4}, Lgc1;-><init>(Lcj;Lml;)V

    .line 38
    .line 39
    .line 40
    invoke-direct {p1, p3, p2}, Ltw0;-><init>(ILgc1;)V

    .line 41
    .line 42
    .line 43
    iput-object p1, p0, Lcj;->f:Ltw0;

    .line 44
    .line 45
    return-void
.end method

.method public static final a(Lcj;Landroid/view/ScrollCaptureSession;Lr60;Lnl;)Ljava/lang/Object;
    .registers 15

    .line 1
    instance-of v0, p3, Lbj;

    .line 2
    .line 3
    if-eqz v0, :cond_13

    .line 4
    .line 5
    move-object v0, p3

    .line 6
    check-cast v0, Lbj;

    .line 7
    .line 8
    iget v1, v0, Lbj;->n:I

    .line 9
    .line 10
    const/high16 v2, -0x80000000

    .line 11
    .line 12
    and-int v3, v1, v2

    .line 13
    .line 14
    if-eqz v3, :cond_13

    .line 15
    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, Lbj;->n:I

    .line 18
    .line 19
    goto :goto_18

    .line 20
    :cond_13
    new-instance v0, Lbj;

    .line 21
    .line 22
    invoke-direct {v0, p0, p3}, Lbj;-><init>(Lcj;Lnl;)V

    .line 23
    .line 24
    .line 25
    :goto_18
    iget-object p3, v0, Lbj;->l:Ljava/lang/Object;

    .line 26
    .line 27
    iget v1, v0, Lbj;->n:I

    .line 28
    .line 29
    const/4 v2, 0x1

    .line 30
    const/4 v3, 0x2

    .line 31
    sget-object v4, Lcm;->e:Lcm;

    .line 32
    .line 33
    if-eqz v1, :cond_52

    .line 34
    .line 35
    if-eq v1, v2, :cond_3e

    .line 36
    .line 37
    if-ne v1, v3, :cond_37

    .line 38
    .line 39
    iget p1, v0, Lbj;->k:I

    .line 40
    .line 41
    iget p2, v0, Lbj;->j:I

    .line 42
    .line 43
    iget-object v1, v0, Lbj;->i:Lr60;

    .line 44
    .line 45
    iget-object v0, v0, Lbj;->h:Ljava/lang/Object;

    .line 46
    .line 47
    invoke-static {v0}, Lx3;->h(Ljava/lang/Object;)Landroid/view/ScrollCaptureSession;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    invoke-static {p3}, Lnb0;->t(Ljava/lang/Object;)V

    .line 52
    .line 53
    .line 54
    goto/16 :goto_b2

    .line 55
    .line 56
    :cond_37
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 57
    .line 58
    invoke-static {p0}, Lod;->p(Ljava/lang/String;)V

    .line 59
    .line 60
    .line 61
    const/4 p0, 0x0

    .line 62
    return-object p0

    .line 63
    :cond_3e
    iget p1, v0, Lbj;->k:I

    .line 64
    .line 65
    iget p2, v0, Lbj;->j:I

    .line 66
    .line 67
    iget-object v1, v0, Lbj;->i:Lr60;

    .line 68
    .line 69
    iget-object v2, v0, Lbj;->h:Ljava/lang/Object;

    .line 70
    .line 71
    invoke-static {v2}, Lx3;->h(Ljava/lang/Object;)Landroid/view/ScrollCaptureSession;

    .line 72
    .line 73
    .line 74
    move-result-object v2

    .line 75
    invoke-static {p3}, Lnb0;->t(Ljava/lang/Object;)V

    .line 76
    .line 77
    .line 78
    move p3, p2

    .line 79
    move-object p2, v1

    .line 80
    move v1, p1

    .line 81
    move-object p1, v2

    .line 82
    goto :goto_92

    .line 83
    :cond_52
    invoke-static {p3}, Lnb0;->t(Ljava/lang/Object;)V

    .line 84
    .line 85
    .line 86
    iget p3, p2, Lr60;->b:I

    .line 87
    .line 88
    iget v1, p2, Lr60;->d:I

    .line 89
    .line 90
    iget-object v5, p0, Lcj;->f:Ltw0;

    .line 91
    .line 92
    iput-object p1, v0, Lbj;->h:Ljava/lang/Object;

    .line 93
    .line 94
    iput-object p2, v0, Lbj;->i:Lr60;

    .line 95
    .line 96
    iput p3, v0, Lbj;->j:I

    .line 97
    .line 98
    iput v1, v0, Lbj;->k:I

    .line 99
    .line 100
    iput v2, v0, Lbj;->n:I

    .line 101
    .line 102
    iget v2, v5, Ltw0;->a:I

    .line 103
    .line 104
    if-gt p3, v1, :cond_134

    .line 105
    .line 106
    sub-int v6, v1, p3

    .line 107
    .line 108
    if-gt v6, v2, :cond_122

    .line 109
    .line 110
    int-to-float v7, p3

    .line 111
    iget v8, v5, Ltw0;->c:F

    .line 112
    .line 113
    cmpl-float v7, v7, v8

    .line 114
    .line 115
    sget-object v9, Lwe1;->a:Lwe1;

    .line 116
    .line 117
    if-ltz v7, :cond_7e

    .line 118
    .line 119
    int-to-float v7, v1

    .line 120
    int-to-float v10, v2

    .line 121
    add-float/2addr v10, v8

    .line 122
    cmpg-float v7, v7, v10

    .line 123
    .line 124
    if-gtz v7, :cond_7e

    .line 125
    .line 126
    goto :goto_8f

    .line 127
    :cond_7e
    div-int/2addr v6, v3

    .line 128
    add-int/2addr v6, p3

    .line 129
    div-int/2addr v2, v3

    .line 130
    sub-int/2addr v6, v2

    .line 131
    int-to-float v2, v6

    .line 132
    sub-float/2addr v2, v8

    .line 133
    invoke-virtual {v5, v2, v0}, Ltw0;->a(FLnl;)Ljava/lang/Object;

    .line 134
    .line 135
    .line 136
    move-result-object v2

    .line 137
    if-ne v2, v4, :cond_8b

    .line 138
    .line 139
    goto :goto_8c

    .line 140
    :cond_8b
    move-object v2, v9

    .line 141
    :goto_8c
    if-ne v2, v4, :cond_8f

    .line 142
    .line 143
    move-object v9, v2

    .line 144
    :cond_8f
    :goto_8f
    if-ne v9, v4, :cond_92

    .line 145
    .line 146
    goto :goto_ad

    .line 147
    :cond_92
    :goto_92
    sget-object v2, Li4;->s:Li4;

    .line 148
    .line 149
    iput-object p1, v0, Lbj;->h:Ljava/lang/Object;

    .line 150
    .line 151
    iput-object p2, v0, Lbj;->i:Lr60;

    .line 152
    .line 153
    iput p3, v0, Lbj;->j:I

    .line 154
    .line 155
    iput v1, v0, Lbj;->k:I

    .line 156
    .line 157
    iput v3, v0, Lbj;->n:I

    .line 158
    .line 159
    iget-object v3, v0, Lnl;->f:Lsl;

    .line 160
    .line 161
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 162
    .line 163
    .line 164
    invoke-static {v3}, Lsb0;->o(Lsl;)Lg7;

    .line 165
    .line 166
    .line 167
    move-result-object v3

    .line 168
    invoke-virtual {v3, v2, v0}, Lg7;->c(Li00;Lnl;)Ljava/lang/Object;

    .line 169
    .line 170
    .line 171
    move-result-object v0

    .line 172
    if-ne v0, v4, :cond_ae

    .line 173
    .line 174
    :goto_ad
    return-object v4

    .line 175
    :cond_ae
    move-object v0, p1

    .line 176
    move p1, v1

    .line 177
    move-object v1, p2

    .line 178
    move p2, p3

    .line 179
    :goto_b2
    iget-object p3, p0, Lcj;->f:Ltw0;

    .line 180
    .line 181
    iget v2, p3, Ltw0;->c:F

    .line 182
    .line 183
    invoke-static {v2}, Lgh0;->P(F)I

    .line 184
    .line 185
    .line 186
    move-result v2

    .line 187
    sub-int/2addr p2, v2

    .line 188
    iget p3, p3, Ltw0;->a:I

    .line 189
    .line 190
    const/4 v2, 0x0

    .line 191
    invoke-static {p2, v2, p3}, Lsb0;->h(III)I

    .line 192
    .line 193
    .line 194
    move-result p2

    .line 195
    iget-object p3, p0, Lcj;->f:Ltw0;

    .line 196
    .line 197
    iget v3, p3, Ltw0;->c:F

    .line 198
    .line 199
    invoke-static {v3}, Lgh0;->P(F)I

    .line 200
    .line 201
    .line 202
    move-result v3

    .line 203
    sub-int/2addr p1, v3

    .line 204
    iget p3, p3, Ltw0;->a:I

    .line 205
    .line 206
    invoke-static {p1, v2, p3}, Lsb0;->h(III)I

    .line 207
    .line 208
    .line 209
    move-result p1

    .line 210
    iget p3, v1, Lr60;->a:I

    .line 211
    .line 212
    iget v1, v1, Lr60;->c:I

    .line 213
    .line 214
    if-ne p2, p1, :cond_da

    .line 215
    .line 216
    sget-object p0, Lr60;->e:Lr60;

    .line 217
    .line 218
    return-object p0

    .line 219
    :cond_da
    invoke-static {v0}, Lx3;->j(Landroid/view/ScrollCaptureSession;)Landroid/view/Surface;

    .line 220
    .line 221
    .line 222
    move-result-object v2

    .line 223
    invoke-virtual {v2}, Landroid/view/Surface;->lockHardwareCanvas()Landroid/graphics/Canvas;

    .line 224
    .line 225
    .line 226
    move-result-object v2

    .line 227
    :try_start_e2
    invoke-virtual {v2}, Landroid/graphics/Canvas;->save()I

    .line 228
    .line 229
    .line 230
    int-to-float v3, p3

    .line 231
    neg-float v3, v3

    .line 232
    int-to-float v4, p2

    .line 233
    neg-float v4, v4

    .line 234
    invoke-virtual {v2, v3, v4}, Landroid/graphics/Canvas;->translate(FF)V

    .line 235
    .line 236
    .line 237
    iget-object v3, p0, Lcj;->b:Lr60;

    .line 238
    .line 239
    iget v4, v3, Lr60;->a:I

    .line 240
    .line 241
    int-to-float v4, v4

    .line 242
    neg-float v4, v4

    .line 243
    iget v3, v3, Lr60;->b:I

    .line 244
    .line 245
    int-to-float v3, v3

    .line 246
    neg-float v3, v3

    .line 247
    invoke-virtual {v2, v4, v3}, Landroid/graphics/Canvas;->translate(FF)V

    .line 248
    .line 249
    .line 250
    iget-object v3, p0, Lcj;->d:Ln4;

    .line 251
    .line 252
    invoke-virtual {v3}, Landroid/view/View;->getRootView()Landroid/view/View;

    .line 253
    .line 254
    .line 255
    move-result-object v3

    .line 256
    invoke-virtual {v3, v2}, Landroid/view/View;->draw(Landroid/graphics/Canvas;)V
    :try_end_102
    .catchall {:try_start_e2 .. :try_end_102} :catchall_119

    .line 257
    .line 258
    .line 259
    invoke-static {v0}, Lx3;->z(Landroid/view/ScrollCaptureSession;)Landroid/view/Surface;

    .line 260
    .line 261
    .line 262
    move-result-object v0

    .line 263
    invoke-virtual {v0, v2}, Landroid/view/Surface;->unlockCanvasAndPost(Landroid/graphics/Canvas;)V

    .line 264
    .line 265
    .line 266
    iget-object p0, p0, Lcj;->f:Ltw0;

    .line 267
    .line 268
    iget p0, p0, Ltw0;->c:F

    .line 269
    .line 270
    invoke-static {p0}, Lgh0;->P(F)I

    .line 271
    .line 272
    .line 273
    move-result p0

    .line 274
    new-instance v0, Lr60;

    .line 275
    .line 276
    add-int/2addr p2, p0

    .line 277
    add-int/2addr p1, p0

    .line 278
    invoke-direct {v0, p3, p2, v1, p1}, Lr60;-><init>(IIII)V

    .line 279
    .line 280
    .line 281
    return-object v0

    .line 282
    :catchall_119
    move-exception p0

    .line 283
    invoke-static {v0}, Lx3;->z(Landroid/view/ScrollCaptureSession;)Landroid/view/Surface;

    .line 284
    .line 285
    .line 286
    move-result-object p1

    .line 287
    invoke-virtual {p1, v2}, Landroid/view/Surface;->unlockCanvasAndPost(Landroid/graphics/Canvas;)V

    .line 288
    .line 289
    .line 290
    throw p0

    .line 291
    :cond_122
    const-string p0, "Expected range ("

    .line 292
    .line 293
    const-string p1, ") to be ≤ viewportSize="

    .line 294
    .line 295
    invoke-static {v6, v2, p0, p1}, Lfu0;->D(IILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 296
    .line 297
    .line 298
    move-result-object p0

    .line 299
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 300
    .line 301
    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 302
    .line 303
    .line 304
    move-result-object p0

    .line 305
    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 306
    .line 307
    .line 308
    throw p1

    .line 309
    :cond_134
    const-string p0, "Expected min="

    .line 310
    .line 311
    const-string p1, " ≤ max="

    .line 312
    .line 313
    invoke-static {p3, v1, p0, p1}, Lfu0;->D(IILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 314
    .line 315
    .line 316
    move-result-object p0

    .line 317
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 318
    .line 319
    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 320
    .line 321
    .line 322
    move-result-object p0

    .line 323
    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 324
    .line 325
    .line 326
    throw p1
.end method


# virtual methods
.method public final onScrollCaptureEnd(Ljava/lang/Runnable;)V
    .registers 6

    .line 1
    sget-object v0, Lmm0;->f:Lmm0;

    .line 2
    .line 3
    new-instance v1, Ld;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    const/4 v3, 0x5

    .line 7
    invoke-direct {v1, p0, p1, v2, v3}, Ld;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lml;I)V

    .line 8
    .line 9
    .line 10
    const/4 p1, 0x2

    .line 11
    iget-object p0, p0, Lcj;->e:Lll;

    .line 12
    .line 13
    invoke-static {p0, v0, v1, p1}, Lwl1;->B(Lbm;Lsl;Lm00;I)Ls71;

    .line 14
    .line 15
    .line 16
    return-void
.end method

.method public final onScrollCaptureImageRequest(Landroid/view/ScrollCaptureSession;Landroid/os/CancellationSignal;Landroid/graphics/Rect;Ljava/util/function/Consumer;)V
    .registers 12

    .line 1
    new-instance v0, Laj;

    .line 2
    .line 3
    const/4 v5, 0x0

    .line 4
    const/4 v6, 0x0

    .line 5
    move-object v1, p0

    .line 6
    move-object v2, p1

    .line 7
    move-object v3, p3

    .line 8
    move-object v4, p4

    .line 9
    invoke-direct/range {v0 .. v6}, Laj;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lml;I)V

    .line 10
    .line 11
    .line 12
    const/4 p0, 0x0

    .line 13
    const/4 p1, 0x3

    .line 14
    iget-object p3, v1, Lcj;->e:Lll;

    .line 15
    .line 16
    invoke-static {p3, p0, v0, p1}, Lwl1;->B(Lbm;Lsl;Lm00;I)Ls71;

    .line 17
    .line 18
    .line 19
    move-result-object p0

    .line 20
    new-instance p1, Lj3;

    .line 21
    .line 22
    const/16 p3, 0x8

    .line 23
    .line 24
    invoke-direct {p1, p3, p2}, Lj3;-><init>(ILjava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    invoke-virtual {p0, p1}, Lh80;->r(Li00;)Lsq;

    .line 28
    .line 29
    .line 30
    new-instance p1, Ldj;

    .line 31
    .line 32
    invoke-direct {p1, p0}, Ldj;-><init>(Ls71;)V

    .line 33
    .line 34
    .line 35
    invoke-virtual {p2, p1}, Landroid/os/CancellationSignal;->setOnCancelListener(Landroid/os/CancellationSignal$OnCancelListener;)V

    .line 36
    .line 37
    .line 38
    return-void
.end method

.method public final onScrollCaptureSearch(Landroid/os/CancellationSignal;Ljava/util/function/Consumer;)V
    .registers 3

    .line 1
    iget-object p0, p0, Lcj;->b:Lr60;

    .line 2
    .line 3
    invoke-static {p0}, Ldd0;->x(Lr60;)Landroid/graphics/Rect;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    invoke-static {p2, p0}, Ly0;->p(Ljava/util/function/Consumer;Landroid/graphics/Rect;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public final onScrollCaptureStart(Landroid/view/ScrollCaptureSession;Landroid/os/CancellationSignal;Ljava/lang/Runnable;)V
    .registers 4

    .line 1
    iget-object p1, p0, Lcj;->f:Ltw0;

    .line 2
    .line 3
    const/4 p2, 0x0

    .line 4
    iput p2, p1, Ltw0;->c:F

    .line 5
    .line 6
    iget-object p0, p0, Lcj;->c:Lbd0;

    .line 7
    .line 8
    iget-object p0, p0, Lbd0;->a:Llq0;

    .line 9
    .line 10
    sget-object p1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 11
    .line 12
    invoke-virtual {p0, p1}, Llq0;->setValue(Ljava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    invoke-interface {p3}, Ljava/lang/Runnable;->run()V

    .line 16
    .line 17
    .line 18
    return-void
.end method
