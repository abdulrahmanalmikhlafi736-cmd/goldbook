.class public final Lb8;
.super Lu91;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Li00;


# instance fields
.field public final synthetic i:Lc8;

.field public final synthetic j:Lbr;


# direct methods
.method public constructor <init>(Lc8;Lbr;Lml;)V
    .registers 4

    .line 1
    iput-object p1, p0, Lb8;->i:Lc8;

    .line 2
    .line 3
    iput-object p2, p0, Lb8;->j:Lbr;

    .line 4
    .line 5
    const/4 p1, 0x1

    .line 6
    invoke-direct {p0, p1, p3}, Lu91;-><init>(ILml;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final i(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 1
    check-cast p1, Lml;

    .line 2
    .line 3
    new-instance v0, Lb8;

    .line 4
    .line 5
    iget-object v1, p0, Lb8;->i:Lc8;

    .line 6
    .line 7
    iget-object p0, p0, Lb8;->j:Lbr;

    .line 8
    .line 9
    invoke-direct {v0, v1, p0, p1}, Lb8;-><init>(Lc8;Lbr;Lml;)V

    .line 10
    .line 11
    .line 12
    sget-object p0, Lwe1;->a:Lwe1;

    .line 13
    .line 14
    invoke-virtual {v0, p0}, Lb8;->p(Ljava/lang/Object;)Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    return-object p0
.end method

.method public final p(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 1
    invoke-static {p1}, Lnb0;->t(Ljava/lang/Object;)V

    .line 2
    .line 3
    .line 4
    iget-object p1, p0, Lb8;->i:Lc8;

    .line 5
    .line 6
    invoke-static {p1}, Lc8;->b(Lc8;)V

    .line 7
    .line 8
    .line 9
    iget-object p0, p0, Lb8;->j:Lbr;

    .line 10
    .line 11
    invoke-static {p1, p0}, Lc8;->a(Lc8;Ljava/lang/Object;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object p0

    .line 15
    iget-object v0, p1, Lc8;->c:Lp8;

    .line 16
    .line 17
    iget-object v0, v0, Lp8;->f:Llq0;

    .line 18
    .line 19
    invoke-virtual {v0, p0}, Llq0;->setValue(Ljava/lang/Object;)V

    .line 20
    .line 21
    .line 22
    iget-object p1, p1, Lc8;->e:Llq0;

    .line 23
    .line 24
    invoke-virtual {p1, p0}, Llq0;->setValue(Ljava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    sget-object p0, Lwe1;->a:Lwe1;

    .line 28
    .line 29
    return-object p0
.end method
