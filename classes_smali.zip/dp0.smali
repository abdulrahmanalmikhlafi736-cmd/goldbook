.class public final Ldp0;
.super Ljb0;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# instance fields
.field public final b:Lr6;


# direct methods
.method public constructor <init>(Lr6;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Ldp0;->b:Lr6;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final k()Lgw0;
    .registers 1

    .line 1
    iget-object p0, p0, Ldp0;->b:Lr6;

    .line 2
    .line 3
    invoke-virtual {p0}, Lr6;->a()Lgw0;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    return-object p0
.end method
