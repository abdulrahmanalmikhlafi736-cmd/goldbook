.class public final Le3;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Ldc;
.implements Lrl;
.implements Lkp;
.implements Lvb0;
.implements Lnd;
.implements Lrx0;
.implements Lvi1;
.implements Lt61;
.implements Li91;


# static fields
.field public static final A:Li5;

.field public static final synthetic B:Le3;

.field public static final synthetic C:Le3;

.field public static final D:Le3;

.field public static final E:Le3;

.field public static final F:Le3;

.field public static final G:Le3;

.field public static final H:Le3;

.field public static final I:Lo90;

.field public static final J:Lmp;

.field public static final K:Le3;

.field public static final L:Le3;

.field public static final M:Le3;

.field public static final N:Lgw0;

.field public static final O:Le3;

.field public static final synthetic P:Le3;

.field public static final Q:[Ljava/lang/String;

.field public static final synthetic R:Le3;

.field public static final synthetic S:Le3;

.field public static final T:Le3;

.field public static final synthetic U:Le3;

.field public static final synthetic V:Le3;

.field public static final W:Le3;

.field public static final X:Le3;

.field public static final Y:Le3;

.field public static final f:Lnb;

.field public static final g:Lnb;

.field public static final h:Lnb;

.field public static final i:Lnb;

.field public static final j:Lnb;

.field public static final k:Lnb;

.field public static final l:Lnb;

.field public static final m:Lnb;

.field public static final n:Lnb;

.field public static final o:Lmb;

.field public static final p:Lmb;

.field public static final q:Llb;

.field public static final r:Llb;

.field public static final s:Llb;

.field public static final t:Le3;

.field public static final u:Le3;

.field public static final v:Le3;

.field public static final w:Le3;

.field public static final x:Le3;

.field public static final y:Lod;

.field public static final z:Li5;


# instance fields
.field public final synthetic e:I


# direct methods
.method static synthetic constructor <clinit>()V
    .registers 5

    .line 1
    new-instance v0, Lnb;

    .line 2
    .line 3
    const/high16 v1, -0x40800000  # -1.0f

    .line 4
    .line 5
    invoke-direct {v0, v1, v1}, Lnb;-><init>(FF)V

    .line 6
    .line 7
    .line 8
    sput-object v0, Le3;->f:Lnb;

    .line 9
    .line 10
    new-instance v0, Lnb;

    .line 11
    .line 12
    const/4 v2, 0x0

    .line 13
    invoke-direct {v0, v2, v1}, Lnb;-><init>(FF)V

    .line 14
    .line 15
    .line 16
    sput-object v0, Le3;->g:Lnb;

    .line 17
    .line 18
    new-instance v0, Lnb;

    .line 19
    .line 20
    const/high16 v3, 0x3f800000  # 1.0f

    .line 21
    .line 22
    invoke-direct {v0, v3, v1}, Lnb;-><init>(FF)V

    .line 23
    .line 24
    .line 25
    sput-object v0, Le3;->h:Lnb;

    .line 26
    .line 27
    new-instance v0, Lnb;

    .line 28
    .line 29
    invoke-direct {v0, v1, v2}, Lnb;-><init>(FF)V

    .line 30
    .line 31
    .line 32
    sput-object v0, Le3;->i:Lnb;

    .line 33
    .line 34
    new-instance v0, Lnb;

    .line 35
    .line 36
    invoke-direct {v0, v2, v2}, Lnb;-><init>(FF)V

    .line 37
    .line 38
    .line 39
    sput-object v0, Le3;->j:Lnb;

    .line 40
    .line 41
    new-instance v0, Lnb;

    .line 42
    .line 43
    invoke-direct {v0, v3, v2}, Lnb;-><init>(FF)V

    .line 44
    .line 45
    .line 46
    sput-object v0, Le3;->k:Lnb;

    .line 47
    .line 48
    new-instance v0, Lnb;

    .line 49
    .line 50
    invoke-direct {v0, v1, v3}, Lnb;-><init>(FF)V

    .line 51
    .line 52
    .line 53
    sput-object v0, Le3;->l:Lnb;

    .line 54
    .line 55
    new-instance v0, Lnb;

    .line 56
    .line 57
    invoke-direct {v0, v2, v3}, Lnb;-><init>(FF)V

    .line 58
    .line 59
    .line 60
    sput-object v0, Le3;->m:Lnb;

    .line 61
    .line 62
    new-instance v0, Lnb;

    .line 63
    .line 64
    invoke-direct {v0, v3, v3}, Lnb;-><init>(FF)V

    .line 65
    .line 66
    .line 67
    sput-object v0, Le3;->n:Lnb;

    .line 68
    .line 69
    new-instance v0, Lmb;

    .line 70
    .line 71
    invoke-direct {v0, v1}, Lmb;-><init>(F)V

    .line 72
    .line 73
    .line 74
    sput-object v0, Le3;->o:Lmb;

    .line 75
    .line 76
    new-instance v0, Lmb;

    .line 77
    .line 78
    invoke-direct {v0, v2}, Lmb;-><init>(F)V

    .line 79
    .line 80
    .line 81
    sput-object v0, Le3;->p:Lmb;

    .line 82
    .line 83
    new-instance v0, Llb;

    .line 84
    .line 85
    invoke-direct {v0, v1}, Llb;-><init>(F)V

    .line 86
    .line 87
    .line 88
    sput-object v0, Le3;->q:Llb;

    .line 89
    .line 90
    new-instance v0, Llb;

    .line 91
    .line 92
    invoke-direct {v0, v2}, Llb;-><init>(F)V

    .line 93
    .line 94
    .line 95
    sput-object v0, Le3;->r:Llb;

    .line 96
    .line 97
    new-instance v0, Llb;

    .line 98
    .line 99
    invoke-direct {v0, v3}, Llb;-><init>(F)V

    .line 100
    .line 101
    .line 102
    sput-object v0, Le3;->s:Llb;

    .line 103
    .line 104
    new-instance v0, Le3;

    .line 105
    .line 106
    const/4 v1, 0x1

    .line 107
    invoke-direct {v0, v1}, Le3;-><init>(I)V

    .line 108
    .line 109
    .line 110
    sput-object v0, Le3;->t:Le3;

    .line 111
    .line 112
    new-instance v0, Le3;

    .line 113
    .line 114
    const/4 v2, 0x2

    .line 115
    invoke-direct {v0, v2}, Le3;-><init>(I)V

    .line 116
    .line 117
    .line 118
    sput-object v0, Le3;->u:Le3;

    .line 119
    .line 120
    new-instance v0, Le3;

    .line 121
    .line 122
    const/4 v4, 0x3

    .line 123
    invoke-direct {v0, v4}, Le3;-><init>(I)V

    .line 124
    .line 125
    .line 126
    sput-object v0, Le3;->v:Le3;

    .line 127
    .line 128
    new-instance v0, Le3;

    .line 129
    .line 130
    const/4 v4, 0x4

    .line 131
    invoke-direct {v0, v4}, Le3;-><init>(I)V

    .line 132
    .line 133
    .line 134
    sput-object v0, Le3;->w:Le3;

    .line 135
    .line 136
    new-instance v0, Le3;

    .line 137
    .line 138
    const/4 v4, 0x5

    .line 139
    invoke-direct {v0, v4}, Le3;-><init>(I)V

    .line 140
    .line 141
    .line 142
    sput-object v0, Le3;->x:Le3;

    .line 143
    .line 144
    new-instance v0, Lod;

    .line 145
    .line 146
    invoke-direct {v0, v1}, Lod;-><init>(I)V

    .line 147
    .line 148
    .line 149
    sput-object v0, Le3;->y:Lod;

    .line 150
    .line 151
    new-instance v0, Li5;

    .line 152
    .line 153
    invoke-direct {v0, v1}, Li5;-><init>(I)V

    .line 154
    .line 155
    .line 156
    sput-object v0, Le3;->z:Li5;

    .line 157
    .line 158
    new-instance v0, Li5;

    .line 159
    .line 160
    invoke-direct {v0, v2}, Li5;-><init>(I)V

    .line 161
    .line 162
    .line 163
    sput-object v0, Le3;->A:Li5;

    .line 164
    .line 165
    new-instance v0, Le3;

    .line 166
    .line 167
    const/16 v1, 0x8

    .line 168
    .line 169
    invoke-direct {v0, v1}, Le3;-><init>(I)V

    .line 170
    .line 171
    .line 172
    sput-object v0, Le3;->B:Le3;

    .line 173
    .line 174
    new-instance v0, Le3;

    .line 175
    .line 176
    const/16 v1, 0x9

    .line 177
    .line 178
    invoke-direct {v0, v1}, Le3;-><init>(I)V

    .line 179
    .line 180
    .line 181
    sput-object v0, Le3;->C:Le3;

    .line 182
    .line 183
    new-instance v0, Le3;

    .line 184
    .line 185
    const/16 v1, 0xa

    .line 186
    .line 187
    invoke-direct {v0, v1}, Le3;-><init>(I)V

    .line 188
    .line 189
    .line 190
    sput-object v0, Le3;->D:Le3;

    .line 191
    .line 192
    new-instance v0, Le3;

    .line 193
    .line 194
    const/16 v1, 0xb

    .line 195
    .line 196
    invoke-direct {v0, v1}, Le3;-><init>(I)V

    .line 197
    .line 198
    .line 199
    sput-object v0, Le3;->E:Le3;

    .line 200
    .line 201
    new-instance v0, Le3;

    .line 202
    .line 203
    const/16 v1, 0xc

    .line 204
    .line 205
    invoke-direct {v0, v1}, Le3;-><init>(I)V

    .line 206
    .line 207
    .line 208
    sput-object v0, Le3;->F:Le3;

    .line 209
    .line 210
    new-instance v0, Le3;

    .line 211
    .line 212
    const/16 v1, 0xd

    .line 213
    .line 214
    invoke-direct {v0, v1}, Le3;-><init>(I)V

    .line 215
    .line 216
    .line 217
    sput-object v0, Le3;->G:Le3;

    .line 218
    .line 219
    new-instance v0, Le3;

    .line 220
    .line 221
    const/16 v1, 0xe

    .line 222
    .line 223
    invoke-direct {v0, v1}, Le3;-><init>(I)V

    .line 224
    .line 225
    .line 226
    sput-object v0, Le3;->H:Le3;

    .line 227
    .line 228
    sget-object v0, Lo90;->e:Lo90;

    .line 229
    .line 230
    sput-object v0, Le3;->I:Lo90;

    .line 231
    .line 232
    new-instance v0, Lmp;

    .line 233
    .line 234
    invoke-direct {v0, v3, v3}, Lmp;-><init>(FF)V

    .line 235
    .line 236
    .line 237
    sput-object v0, Le3;->J:Lmp;

    .line 238
    .line 239
    new-instance v0, Le3;

    .line 240
    .line 241
    const/16 v1, 0xf

    .line 242
    .line 243
    invoke-direct {v0, v1}, Le3;-><init>(I)V

    .line 244
    .line 245
    .line 246
    sput-object v0, Le3;->K:Le3;

    .line 247
    .line 248
    new-instance v0, Le3;

    .line 249
    .line 250
    const/16 v1, 0x10

    .line 251
    .line 252
    invoke-direct {v0, v1}, Le3;-><init>(I)V

    .line 253
    .line 254
    .line 255
    sput-object v0, Le3;->L:Le3;

    .line 256
    .line 257
    new-instance v0, Le3;

    .line 258
    .line 259
    const/16 v1, 0x11

    .line 260
    .line 261
    invoke-direct {v0, v1}, Le3;-><init>(I)V

    .line 262
    .line 263
    .line 264
    sput-object v0, Le3;->M:Le3;

    .line 265
    .line 266
    new-instance v0, Lgw0;

    .line 267
    .line 268
    const/high16 v1, 0x7fc00000  # Float.NaN

    .line 269
    .line 270
    invoke-direct {v0, v1, v1, v1, v1}, Lgw0;-><init>(FFFF)V

    .line 271
    .line 272
    .line 273
    sput-object v0, Le3;->N:Lgw0;

    .line 274
    .line 275
    new-instance v0, Le3;

    .line 276
    .line 277
    const/16 v1, 0x13

    .line 278
    .line 279
    invoke-direct {v0, v1}, Le3;-><init>(I)V

    .line 280
    .line 281
    .line 282
    sput-object v0, Le3;->O:Le3;

    .line 283
    .line 284
    new-instance v0, Le3;

    .line 285
    .line 286
    const/16 v1, 0x14

    .line 287
    .line 288
    invoke-direct {v0, v1}, Le3;-><init>(I)V

    .line 289
    .line 290
    .line 291
    sput-object v0, Le3;->P:Le3;

    .line 292
    .line 293
    const/4 v0, 0x0

    .line 294
    new-array v0, v0, [Ljava/lang/String;

    .line 295
    .line 296
    sput-object v0, Le3;->Q:[Ljava/lang/String;

    .line 297
    .line 298
    new-instance v0, Le3;

    .line 299
    .line 300
    const/16 v1, 0x16

    .line 301
    .line 302
    invoke-direct {v0, v1}, Le3;-><init>(I)V

    .line 303
    .line 304
    .line 305
    sput-object v0, Le3;->R:Le3;

    .line 306
    .line 307
    new-instance v0, Le3;

    .line 308
    .line 309
    const/16 v1, 0x17

    .line 310
    .line 311
    invoke-direct {v0, v1}, Le3;-><init>(I)V

    .line 312
    .line 313
    .line 314
    sput-object v0, Le3;->S:Le3;

    .line 315
    .line 316
    new-instance v0, Le3;

    .line 317
    .line 318
    const/16 v1, 0x18

    .line 319
    .line 320
    invoke-direct {v0, v1}, Le3;-><init>(I)V

    .line 321
    .line 322
    .line 323
    sput-object v0, Le3;->T:Le3;

    .line 324
    .line 325
    new-instance v0, Le3;

    .line 326
    .line 327
    const/16 v1, 0x19

    .line 328
    .line 329
    invoke-direct {v0, v1}, Le3;-><init>(I)V

    .line 330
    .line 331
    .line 332
    sput-object v0, Le3;->U:Le3;

    .line 333
    .line 334
    new-instance v0, Le3;

    .line 335
    .line 336
    const/16 v1, 0x1a

    .line 337
    .line 338
    invoke-direct {v0, v1}, Le3;-><init>(I)V

    .line 339
    .line 340
    .line 341
    sput-object v0, Le3;->V:Le3;

    .line 342
    .line 343
    new-instance v0, Le3;

    .line 344
    .line 345
    const/16 v1, 0x1b

    .line 346
    .line 347
    invoke-direct {v0, v1}, Le3;-><init>(I)V

    .line 348
    .line 349
    .line 350
    sput-object v0, Le3;->W:Le3;

    .line 351
    .line 352
    new-instance v0, Le3;

    .line 353
    .line 354
    const/16 v1, 0x1c

    .line 355
    .line 356
    invoke-direct {v0, v1}, Le3;-><init>(I)V

    .line 357
    .line 358
    .line 359
    sput-object v0, Le3;->X:Le3;

    .line 360
    .line 361
    new-instance v0, Le3;

    .line 362
    .line 363
    const/16 v1, 0x1d

    .line 364
    .line 365
    invoke-direct {v0, v1}, Le3;-><init>(I)V

    .line 366
    .line 367
    .line 368
    sput-object v0, Le3;->Y:Le3;

    .line 369
    .line 370
    return-void
.end method

.method public synthetic constructor <init>(I)V
    .registers 2

    .line 1
    iput p1, p0, Le3;->e:I

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public a()Ljp;
    .registers 1

    .line 1
    sget-object p0, Le3;->J:Lmp;

    .line 2
    .line 3
    return-object p0
.end method

.method public b()J
    .registers 3

    .line 1
    const-wide v0, 0x7fc000007fc00000L  # 2.247117487993712E307

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    return-wide v0
.end method

.method public c(Ljava/lang/Object;Ljava/lang/Object;)Z
    .registers 3

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public cancel()V
    .registers 1

    .line 1
    return-void
.end method

.method public d()V
    .registers 1

    .line 1
    return-void
.end method

.method public e()[Ljava/lang/String;
    .registers 1

    .line 1
    sget-object p0, Le3;->Q:[Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method

.method public f(Lh91;)V
    .registers 2

    .line 1
    invoke-virtual {p1}, Lh91;->clear()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public g(Landroid/app/Activity;)Landroid/graphics/Rect;
    .registers 13

    .line 1
    iget p0, p0, Le3;->e:I

    .line 2
    .line 3
    const-string v0, "android"

    .line 4
    .line 5
    const-string v1, "dimen"

    .line 6
    .line 7
    const-string v2, "navigation_bar_height"

    .line 8
    .line 9
    sget-object v3, Ldc;->a:Lcc;

    .line 10
    .line 11
    const-string v4, "getBounds"

    .line 12
    .line 13
    const-string v5, "windowConfiguration"

    .line 14
    .line 15
    const-class v6, Landroid/content/res/Configuration;

    .line 16
    .line 17
    const/4 v7, 0x0

    .line 18
    const/4 v8, 0x0

    .line 19
    const/4 v9, 0x1

    .line 20
    packed-switch p0, :pswitch_data_23e

    .line 21
    .line 22
    .line 23
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 24
    .line 25
    .line 26
    move-result-object p0

    .line 27
    invoke-virtual {p0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    :try_start_1e
    invoke-virtual {v6, v5}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    invoke-virtual {v0, v9}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    .line 36
    .line 37
    .line 38
    invoke-virtual {v0, p0}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object p0

    .line 42
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    invoke-virtual {v0, v4, v7}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    new-instance v1, Landroid/graphics/Rect;

    .line 51
    .line 52
    invoke-virtual {v0, p0, v7}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    move-result-object p0

    .line 56
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 57
    .line 58
    .line 59
    check-cast p0, Landroid/graphics/Rect;

    .line 60
    .line 61
    invoke-direct {v1, p0}, Landroid/graphics/Rect;-><init>(Landroid/graphics/Rect;)V
    :try_end_3f
    .catch Ljava/lang/Exception; {:try_start_1e .. :try_end_3f} :catch_40

    .line 62
    .line 63
    .line 64
    goto :goto_61

    .line 65
    :catch_40
    move-exception p0

    .line 66
    instance-of v0, p0, Ljava/lang/NoSuchFieldException;

    .line 67
    .line 68
    if-nez v0, :cond_53

    .line 69
    .line 70
    instance-of v0, p0, Ljava/lang/NoSuchMethodException;

    .line 71
    .line 72
    if-nez v0, :cond_53

    .line 73
    .line 74
    instance-of v0, p0, Ljava/lang/IllegalAccessException;

    .line 75
    .line 76
    if-nez v0, :cond_53

    .line 77
    .line 78
    instance-of v0, p0, Ljava/lang/reflect/InvocationTargetException;

    .line 79
    .line 80
    if-eqz v0, :cond_52

    .line 81
    .line 82
    goto :goto_53

    .line 83
    :cond_52
    throw p0

    .line 84
    :cond_53
    :goto_53
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 85
    .line 86
    .line 87
    sget-object v0, Lcc;->b:Ljava/lang/String;

    .line 88
    .line 89
    invoke-static {v0, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 90
    .line 91
    .line 92
    sget-object p0, Le3;->v:Le3;

    .line 93
    .line 94
    invoke-virtual {p0, p1}, Le3;->g(Landroid/app/Activity;)Landroid/graphics/Rect;

    .line 95
    .line 96
    .line 97
    move-result-object v1

    .line 98
    :goto_61
    return-object v1

    .line 99
    :pswitch_62  #0x3
    new-instance p0, Landroid/graphics/Rect;

    .line 100
    .line 101
    invoke-direct {p0}, Landroid/graphics/Rect;-><init>()V

    .line 102
    .line 103
    .line 104
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 105
    .line 106
    .line 107
    move-result-object v10

    .line 108
    invoke-virtual {v10}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    .line 109
    .line 110
    .line 111
    move-result-object v10

    .line 112
    :try_start_6f
    invoke-virtual {v6, v5}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    .line 113
    .line 114
    .line 115
    move-result-object v5

    .line 116
    invoke-virtual {v5, v9}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    .line 117
    .line 118
    .line 119
    invoke-virtual {v5, v10}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 120
    .line 121
    .line 122
    move-result-object v5

    .line 123
    invoke-static {p1}, Ly0;->r(Landroid/app/Activity;)Z

    .line 124
    .line 125
    .line 126
    move-result v6

    .line 127
    if-eqz v6, :cond_97

    .line 128
    .line 129
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 130
    .line 131
    .line 132
    move-result-object v6

    .line 133
    invoke-virtual {v6, v4, v7}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 134
    .line 135
    .line 136
    move-result-object v4

    .line 137
    invoke-virtual {v4, v5, v7}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 138
    .line 139
    .line 140
    move-result-object v4

    .line 141
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 142
    .line 143
    .line 144
    check-cast v4, Landroid/graphics/Rect;

    .line 145
    .line 146
    invoke-virtual {p0, v4}, Landroid/graphics/Rect;->set(Landroid/graphics/Rect;)V

    .line 147
    .line 148
    .line 149
    goto :goto_d3

    .line 150
    :catch_95
    move-exception v4

    .line 151
    goto :goto_ae

    .line 152
    :cond_97
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 153
    .line 154
    .line 155
    move-result-object v4

    .line 156
    const-string v6, "getAppBounds"

    .line 157
    .line 158
    invoke-virtual {v4, v6, v7}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 159
    .line 160
    .line 161
    move-result-object v4

    .line 162
    invoke-virtual {v4, v5, v7}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 163
    .line 164
    .line 165
    move-result-object v4

    .line 166
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 167
    .line 168
    .line 169
    check-cast v4, Landroid/graphics/Rect;

    .line 170
    .line 171
    invoke-virtual {p0, v4}, Landroid/graphics/Rect;->set(Landroid/graphics/Rect;)V
    :try_end_ad
    .catch Ljava/lang/Exception; {:try_start_6f .. :try_end_ad} :catch_95

    .line 172
    .line 173
    .line 174
    goto :goto_d3

    .line 175
    :goto_ae
    instance-of v5, v4, Ljava/lang/NoSuchFieldException;

    .line 176
    .line 177
    if-nez v5, :cond_c0

    .line 178
    .line 179
    instance-of v5, v4, Ljava/lang/NoSuchMethodException;

    .line 180
    .line 181
    if-nez v5, :cond_c0

    .line 182
    .line 183
    instance-of v5, v4, Ljava/lang/IllegalAccessException;

    .line 184
    .line 185
    if-nez v5, :cond_c0

    .line 186
    .line 187
    instance-of v5, v4, Ljava/lang/reflect/InvocationTargetException;

    .line 188
    .line 189
    if-eqz v5, :cond_bf

    .line 190
    .line 191
    goto :goto_c0

    .line 192
    :cond_bf
    throw v4

    .line 193
    :cond_c0
    :goto_c0
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 194
    .line 195
    .line 196
    sget-object v5, Lcc;->b:Ljava/lang/String;

    .line 197
    .line 198
    invoke-static {v5, v4}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 199
    .line 200
    .line 201
    invoke-virtual {p1}, Landroid/app/Activity;->getWindowManager()Landroid/view/WindowManager;

    .line 202
    .line 203
    .line 204
    move-result-object v4

    .line 205
    invoke-interface {v4}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    .line 206
    .line 207
    .line 208
    move-result-object v4

    .line 209
    invoke-virtual {v4, p0}, Landroid/view/Display;->getRectSize(Landroid/graphics/Rect;)V

    .line 210
    .line 211
    .line 212
    :goto_d3
    invoke-virtual {p1}, Landroid/app/Activity;->getWindowManager()Landroid/view/WindowManager;

    .line 213
    .line 214
    .line 215
    move-result-object v4

    .line 216
    invoke-interface {v4}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    .line 217
    .line 218
    .line 219
    move-result-object v4

    .line 220
    new-instance v5, Landroid/graphics/Point;

    .line 221
    .line 222
    invoke-direct {v5}, Landroid/graphics/Point;-><init>()V

    .line 223
    .line 224
    .line 225
    invoke-virtual {v4, v5}, Landroid/view/Display;->getRealSize(Landroid/graphics/Point;)V

    .line 226
    .line 227
    .line 228
    invoke-static {p1}, Ly0;->r(Landroid/app/Activity;)Z

    .line 229
    .line 230
    .line 231
    move-result v6

    .line 232
    if-nez v6, :cond_113

    .line 233
    .line 234
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 235
    .line 236
    .line 237
    move-result-object v6

    .line 238
    invoke-virtual {v6, v2, v1, v0}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    .line 239
    .line 240
    .line 241
    move-result v0

    .line 242
    if-lez v0, :cond_f8

    .line 243
    .line 244
    invoke-virtual {v6, v0}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 245
    .line 246
    .line 247
    move-result v0

    .line 248
    goto :goto_f9

    .line 249
    :cond_f8
    move v0, v8

    .line 250
    :goto_f9
    iget v1, p0, Landroid/graphics/Rect;->bottom:I

    .line 251
    .line 252
    add-int/2addr v1, v0

    .line 253
    iget v2, v5, Landroid/graphics/Point;->y:I

    .line 254
    .line 255
    if-ne v1, v2, :cond_103

    .line 256
    .line 257
    iput v1, p0, Landroid/graphics/Rect;->bottom:I

    .line 258
    .line 259
    goto :goto_113

    .line 260
    :cond_103
    iget v1, p0, Landroid/graphics/Rect;->right:I

    .line 261
    .line 262
    add-int/2addr v1, v0

    .line 263
    iget v2, v5, Landroid/graphics/Point;->x:I

    .line 264
    .line 265
    if-ne v1, v2, :cond_10d

    .line 266
    .line 267
    iput v1, p0, Landroid/graphics/Rect;->right:I

    .line 268
    .line 269
    goto :goto_113

    .line 270
    :cond_10d
    iget v1, p0, Landroid/graphics/Rect;->left:I

    .line 271
    .line 272
    if-ne v1, v0, :cond_113

    .line 273
    .line 274
    iput v8, p0, Landroid/graphics/Rect;->left:I

    .line 275
    .line 276
    :cond_113
    :goto_113
    invoke-virtual {p0}, Landroid/graphics/Rect;->width()I

    .line 277
    .line 278
    .line 279
    move-result v0

    .line 280
    iget v1, v5, Landroid/graphics/Point;->x:I

    .line 281
    .line 282
    if-lt v0, v1, :cond_123

    .line 283
    .line 284
    invoke-virtual {p0}, Landroid/graphics/Rect;->height()I

    .line 285
    .line 286
    .line 287
    move-result v0

    .line 288
    iget v1, v5, Landroid/graphics/Point;->y:I

    .line 289
    .line 290
    if-ge v0, v1, :cond_1d3

    .line 291
    .line 292
    :cond_123
    invoke-static {p1}, Ly0;->r(Landroid/app/Activity;)Z

    .line 293
    .line 294
    .line 295
    move-result p1

    .line 296
    if-nez p1, :cond_1d3

    .line 297
    .line 298
    :try_start_129
    const-string p1, "android.view.DisplayInfo"

    .line 299
    .line 300
    invoke-static {p1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    .line 301
    .line 302
    .line 303
    move-result-object p1

    .line 304
    invoke-virtual {p1, v7}, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    .line 305
    .line 306
    .line 307
    move-result-object p1

    .line 308
    invoke-virtual {p1, v9}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    .line 309
    .line 310
    .line 311
    invoke-virtual {p1, v7}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    .line 312
    .line 313
    .line 314
    move-result-object p1

    .line 315
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 316
    .line 317
    .line 318
    move-result-object v0

    .line 319
    const-string v1, "getDisplayInfo"

    .line 320
    .line 321
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 322
    .line 323
    .line 324
    move-result-object v2

    .line 325
    new-array v6, v9, [Ljava/lang/Class;

    .line 326
    .line 327
    aput-object v2, v6, v8

    .line 328
    .line 329
    invoke-virtual {v0, v1, v6}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 330
    .line 331
    .line 332
    move-result-object v0

    .line 333
    invoke-virtual {v0, v9}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    .line 334
    .line 335
    .line 336
    new-array v1, v9, [Ljava/lang/Object;

    .line 337
    .line 338
    aput-object p1, v1, v8

    .line 339
    .line 340
    invoke-virtual {v0, v4, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 341
    .line 342
    .line 343
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 344
    .line 345
    .line 346
    move-result-object v0

    .line 347
    const-string v1, "displayCutout"

    .line 348
    .line 349
    invoke-virtual {v0, v1}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    .line 350
    .line 351
    .line 352
    move-result-object v0

    .line 353
    invoke-virtual {v0, v9}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    .line 354
    .line 355
    .line 356
    invoke-virtual {v0, p1}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 357
    .line 358
    .line 359
    move-result-object p1

    .line 360
    invoke-static {p1}, Lz0;->r(Ljava/lang/Object;)Z

    .line 361
    .line 362
    .line 363
    move-result v0

    .line 364
    if-eqz v0, :cond_195

    .line 365
    .line 366
    invoke-static {p1}, Lz0;->e(Ljava/lang/Object;)Landroid/view/DisplayCutout;

    .line 367
    .line 368
    .line 369
    move-result-object v7
    :try_end_171
    .catch Ljava/lang/Exception; {:try_start_129 .. :try_end_171} :catch_172

    .line 370
    goto :goto_195

    .line 371
    :catch_172
    move-exception p1

    .line 372
    instance-of v0, p1, Ljava/lang/ClassNotFoundException;

    .line 373
    .line 374
    if-nez v0, :cond_18d

    .line 375
    .line 376
    instance-of v0, p1, Ljava/lang/NoSuchMethodException;

    .line 377
    .line 378
    if-nez v0, :cond_18d

    .line 379
    .line 380
    instance-of v0, p1, Ljava/lang/NoSuchFieldException;

    .line 381
    .line 382
    if-nez v0, :cond_18d

    .line 383
    .line 384
    instance-of v0, p1, Ljava/lang/IllegalAccessException;

    .line 385
    .line 386
    if-nez v0, :cond_18d

    .line 387
    .line 388
    instance-of v0, p1, Ljava/lang/reflect/InvocationTargetException;

    .line 389
    .line 390
    if-nez v0, :cond_18d

    .line 391
    .line 392
    instance-of v0, p1, Ljava/lang/InstantiationException;

    .line 393
    .line 394
    if-eqz v0, :cond_18c

    .line 395
    .line 396
    goto :goto_18d

    .line 397
    :cond_18c
    throw p1

    .line 398
    :cond_18d
    :goto_18d
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 399
    .line 400
    .line 401
    sget-object v0, Lcc;->b:Ljava/lang/String;

    .line 402
    .line 403
    invoke-static {v0, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 404
    .line 405
    .line 406
    :cond_195
    :goto_195
    if-eqz v7, :cond_1d3

    .line 407
    .line 408
    iget p1, p0, Landroid/graphics/Rect;->left:I

    .line 409
    .line 410
    invoke-static {v7}, Lz0;->s(Landroid/view/DisplayCutout;)I

    .line 411
    .line 412
    .line 413
    move-result v0

    .line 414
    if-ne p1, v0, :cond_1a1

    .line 415
    .line 416
    iput v8, p0, Landroid/graphics/Rect;->left:I

    .line 417
    .line 418
    :cond_1a1
    iget p1, v5, Landroid/graphics/Point;->x:I

    .line 419
    .line 420
    iget v0, p0, Landroid/graphics/Rect;->right:I

    .line 421
    .line 422
    sub-int/2addr p1, v0

    .line 423
    invoke-static {v7}, Lz0;->y(Landroid/view/DisplayCutout;)I

    .line 424
    .line 425
    .line 426
    move-result v0

    .line 427
    if-ne p1, v0, :cond_1b5

    .line 428
    .line 429
    iget p1, p0, Landroid/graphics/Rect;->right:I

    .line 430
    .line 431
    invoke-static {v7}, Lz0;->y(Landroid/view/DisplayCutout;)I

    .line 432
    .line 433
    .line 434
    move-result v0

    .line 435
    add-int/2addr v0, p1

    .line 436
    iput v0, p0, Landroid/graphics/Rect;->right:I

    .line 437
    .line 438
    :cond_1b5
    iget p1, p0, Landroid/graphics/Rect;->top:I

    .line 439
    .line 440
    invoke-static {v7}, Lz0;->a(Landroid/view/DisplayCutout;)I

    .line 441
    .line 442
    .line 443
    move-result v0

    .line 444
    if-ne p1, v0, :cond_1bf

    .line 445
    .line 446
    iput v8, p0, Landroid/graphics/Rect;->top:I

    .line 447
    .line 448
    :cond_1bf
    iget p1, v5, Landroid/graphics/Point;->y:I

    .line 449
    .line 450
    iget v0, p0, Landroid/graphics/Rect;->bottom:I

    .line 451
    .line 452
    sub-int/2addr p1, v0

    .line 453
    invoke-static {v7}, Lz0;->x(Landroid/view/DisplayCutout;)I

    .line 454
    .line 455
    .line 456
    move-result v0

    .line 457
    if-ne p1, v0, :cond_1d3

    .line 458
    .line 459
    iget p1, p0, Landroid/graphics/Rect;->bottom:I

    .line 460
    .line 461
    invoke-static {v7}, Lz0;->x(Landroid/view/DisplayCutout;)I

    .line 462
    .line 463
    .line 464
    move-result v0

    .line 465
    add-int/2addr v0, p1

    .line 466
    iput v0, p0, Landroid/graphics/Rect;->bottom:I

    .line 467
    .line 468
    :cond_1d3
    return-object p0

    .line 469
    :pswitch_1d4  #0x2
    new-instance p0, Landroid/graphics/Rect;

    .line 470
    .line 471
    invoke-direct {p0}, Landroid/graphics/Rect;-><init>()V

    .line 472
    .line 473
    .line 474
    invoke-virtual {p1}, Landroid/app/Activity;->getWindowManager()Landroid/view/WindowManager;

    .line 475
    .line 476
    .line 477
    move-result-object v3

    .line 478
    invoke-interface {v3}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    .line 479
    .line 480
    .line 481
    move-result-object v3

    .line 482
    invoke-virtual {v3, p0}, Landroid/view/Display;->getRectSize(Landroid/graphics/Rect;)V

    .line 483
    .line 484
    .line 485
    invoke-static {p1}, Ly0;->r(Landroid/app/Activity;)Z

    .line 486
    .line 487
    .line 488
    move-result v4

    .line 489
    if-nez v4, :cond_213

    .line 490
    .line 491
    new-instance v4, Landroid/graphics/Point;

    .line 492
    .line 493
    invoke-direct {v4}, Landroid/graphics/Point;-><init>()V

    .line 494
    .line 495
    .line 496
    invoke-virtual {v3, v4}, Landroid/view/Display;->getRealSize(Landroid/graphics/Point;)V

    .line 497
    .line 498
    .line 499
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 500
    .line 501
    .line 502
    move-result-object p1

    .line 503
    invoke-virtual {p1, v2, v1, v0}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    .line 504
    .line 505
    .line 506
    move-result v0

    .line 507
    if-lez v0, :cond_200

    .line 508
    .line 509
    invoke-virtual {p1, v0}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 510
    .line 511
    .line 512
    move-result v8

    .line 513
    :cond_200
    iget p1, p0, Landroid/graphics/Rect;->bottom:I

    .line 514
    .line 515
    add-int/2addr p1, v8

    .line 516
    iget v0, v4, Landroid/graphics/Point;->y:I

    .line 517
    .line 518
    if-ne p1, v0, :cond_20a

    .line 519
    .line 520
    iput p1, p0, Landroid/graphics/Rect;->bottom:I

    .line 521
    .line 522
    goto :goto_213

    .line 523
    :cond_20a
    iget p1, p0, Landroid/graphics/Rect;->right:I

    .line 524
    .line 525
    add-int/2addr p1, v8

    .line 526
    iget v0, v4, Landroid/graphics/Point;->x:I

    .line 527
    .line 528
    if-ne p1, v0, :cond_213

    .line 529
    .line 530
    iput p1, p0, Landroid/graphics/Rect;->right:I

    .line 531
    .line 532
    :cond_213
    :goto_213
    return-object p0

    .line 533
    :pswitch_214  #0x1
    invoke-virtual {p1}, Landroid/app/Activity;->getWindowManager()Landroid/view/WindowManager;

    .line 534
    .line 535
    .line 536
    move-result-object p0

    .line 537
    invoke-interface {p0}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    .line 538
    .line 539
    .line 540
    move-result-object p0

    .line 541
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 542
    .line 543
    .line 544
    new-instance p1, Landroid/graphics/Point;

    .line 545
    .line 546
    invoke-direct {p1}, Landroid/graphics/Point;-><init>()V

    .line 547
    .line 548
    .line 549
    invoke-virtual {p0, p1}, Landroid/view/Display;->getRealSize(Landroid/graphics/Point;)V

    .line 550
    .line 551
    .line 552
    new-instance v0, Landroid/graphics/Rect;

    .line 553
    .line 554
    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    .line 555
    .line 556
    .line 557
    iget v1, p1, Landroid/graphics/Point;->x:I

    .line 558
    .line 559
    if-eqz v1, :cond_23a

    .line 560
    .line 561
    iget p1, p1, Landroid/graphics/Point;->y:I

    .line 562
    .line 563
    if-nez p1, :cond_235

    .line 564
    .line 565
    goto :goto_23a

    .line 566
    :cond_235
    iput v1, v0, Landroid/graphics/Rect;->right:I

    .line 567
    .line 568
    iput p1, v0, Landroid/graphics/Rect;->bottom:I

    .line 569
    .line 570
    goto :goto_23d

    .line 571
    :cond_23a
    :goto_23a
    invoke-virtual {p0, v0}, Landroid/view/Display;->getRectSize(Landroid/graphics/Rect;)V

    .line 572
    .line 573
    .line 574
    :goto_23d
    return-object v0

    .line 575
    :pswitch_data_23e
    .packed-switch 0x1
        :pswitch_214  #00000001
        :pswitch_1d4  #00000002
        :pswitch_62  #00000003
    .end packed-switch
.end method

.method public getLayoutDirection()Lo90;
    .registers 1

    .line 1
    sget-object p0, Le3;->I:Lo90;

    .line 2
    .line 3
    return-object p0
.end method

.method public getStatics()Lorg/chromium/support_lib_boundary/StaticsBoundaryInterface;
    .registers 2

    .line 1
    new-instance p0, Ljava/lang/UnsupportedOperationException;

    .line 2
    .line 3
    const-string v0, "This should never happen, if this method was called it means we\'re trying to reach into WebView APK code on an incompatible device. This most likely means the current method is being called too early, or is being called on start-up rather than lazily"

    .line 4
    .line 5
    invoke-direct {p0, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    throw p0
.end method

.method public getWebkitToCompatConverter()Lorg/chromium/support_lib_boundary/WebkitToCompatConverterBoundaryInterface;
    .registers 2

    .line 1
    new-instance p0, Ljava/lang/UnsupportedOperationException;

    .line 2
    .line 3
    const-string v0, "This should never happen, if this method was called it means we\'re trying to reach into WebView APK code on an incompatible device. This most likely means the current method is being called too early, or is being called on start-up rather than lazily"

    .line 4
    .line 5
    invoke-direct {p0, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    throw p0
.end method

.method public h(Landroid/content/ContextWrapper;)F
    .registers 2

    .line 1
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    invoke-virtual {p0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    iget p0, p0, Landroid/util/DisplayMetrics;->density:F

    .line 10
    .line 11
    return p0
.end method

.method public i(Ljava/lang/Object;Ljava/lang/Object;)Z
    .registers 3

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public j(Lnb;)Lmi0;
    .registers 2

    .line 1
    new-instance p0, Lfc;

    .line 2
    .line 3
    invoke-direct {p0, p1}, Lfc;-><init>(Lnb;)V

    .line 4
    .line 5
    .line 6
    return-object p0
.end method

.method public toString()Ljava/lang/String;
    .registers 2

    .line 1
    iget v0, p0, Le3;->e:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_e

    .line 4
    .line 5
    .line 6
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    return-object p0

    .line 11
    :pswitch_a  #0x1c
    const-string p0, "NeverEqualPolicy"

    .line 12
    .line 13
    return-object p0

    .line 14
    nop

    .line 15
    :pswitch_data_e
    .packed-switch 0x1c
        :pswitch_a  #0000001c
    .end packed-switch
.end method
