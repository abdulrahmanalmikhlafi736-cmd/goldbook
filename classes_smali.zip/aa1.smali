.class public final synthetic Laa1;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lm00;


# instance fields
.field public final synthetic e:Z

.field public final synthetic f:Li00;

.field public final synthetic g:Lmi0;

.field public final synthetic h:Z

.field public final synthetic i:Lz91;


# direct methods
.method public synthetic constructor <init>(ZLi00;Lmi0;ZLz91;I)V
    .registers 7

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-boolean p1, p0, Laa1;->e:Z

    .line 5
    .line 6
    iput-object p2, p0, Laa1;->f:Li00;

    .line 7
    .line 8
    iput-object p3, p0, Laa1;->g:Lmi0;

    .line 9
    .line 10
    iput-boolean p4, p0, Laa1;->h:Z

    .line 11
    .line 12
    iput-object p5, p0, Laa1;->i:Lz91;

    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public final f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 10

    .line 1
    move-object v5, p1

    .line 2
    check-cast v5, Ld10;

    .line 3
    .line 4
    check-cast p2, Ljava/lang/Integer;

    .line 5
    .line 6
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    const/16 p1, 0x181

    .line 10
    .line 11
    invoke-static {p1}, Lwc0;->s(I)I

    .line 12
    .line 13
    .line 14
    move-result v6

    .line 15
    iget-boolean v0, p0, Laa1;->e:Z

    .line 16
    .line 17
    iget-object v1, p0, Laa1;->f:Li00;

    .line 18
    .line 19
    iget-object v2, p0, Laa1;->g:Lmi0;

    .line 20
    .line 21
    iget-boolean v3, p0, Laa1;->h:Z

    .line 22
    .line 23
    iget-object v4, p0, Laa1;->i:Lz91;

    .line 24
    .line 25
    invoke-static/range {v0 .. v6}, Lca1;->a(ZLi00;Lmi0;ZLz91;Ld10;I)V

    .line 26
    .line 27
    .line 28
    sget-object p0, Lwe1;->a:Lwe1;

    .line 29
    .line 30
    return-object p0
.end method
