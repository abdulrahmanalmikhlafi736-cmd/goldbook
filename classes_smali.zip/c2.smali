.class public final synthetic Lc2;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lm00;


# instance fields
.field public final synthetic e:Lwi1;

.field public final synthetic f:Lmi0;

.field public final synthetic g:Z

.field public final synthetic h:Lui1;

.field public final synthetic i:Li00;

.field public final synthetic j:Li00;

.field public final synthetic k:Lw1;

.field public final synthetic l:Lv1;

.field public final synthetic m:Li00;

.field public final synthetic n:I


# direct methods
.method public synthetic constructor <init>(Lwi1;Lmi0;ZLui1;Li00;Li00;Lw1;Lv1;Li00;I)V
    .registers 11

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lc2;->e:Lwi1;

    .line 5
    .line 6
    iput-object p2, p0, Lc2;->f:Lmi0;

    .line 7
    .line 8
    iput-boolean p3, p0, Lc2;->g:Z

    .line 9
    .line 10
    iput-object p4, p0, Lc2;->h:Lui1;

    .line 11
    .line 12
    iput-object p5, p0, Lc2;->i:Li00;

    .line 13
    .line 14
    iput-object p6, p0, Lc2;->j:Li00;

    .line 15
    .line 16
    iput-object p7, p0, Lc2;->k:Lw1;

    .line 17
    .line 18
    iput-object p8, p0, Lc2;->l:Lv1;

    .line 19
    .line 20
    iput-object p9, p0, Lc2;->m:Li00;

    .line 21
    .line 22
    iput p10, p0, Lc2;->n:I

    .line 23
    .line 24
    return-void
.end method


# virtual methods
.method public final f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 14

    .line 1
    move-object v9, p1

    .line 2
    check-cast v9, Ld10;

    .line 3
    .line 4
    check-cast p2, Ljava/lang/Integer;

    .line 5
    .line 6
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    iget p1, p0, Lc2;->n:I

    .line 10
    .line 11
    or-int/lit8 p1, p1, 0x1

    .line 12
    .line 13
    invoke-static {p1}, Lwc0;->s(I)I

    .line 14
    .line 15
    .line 16
    move-result v10

    .line 17
    iget-object v0, p0, Lc2;->e:Lwi1;

    .line 18
    .line 19
    iget-object v1, p0, Lc2;->f:Lmi0;

    .line 20
    .line 21
    iget-boolean v2, p0, Lc2;->g:Z

    .line 22
    .line 23
    iget-object v3, p0, Lc2;->h:Lui1;

    .line 24
    .line 25
    iget-object v4, p0, Lc2;->i:Li00;

    .line 26
    .line 27
    iget-object v5, p0, Lc2;->j:Li00;

    .line 28
    .line 29
    iget-object v6, p0, Lc2;->k:Lw1;

    .line 30
    .line 31
    iget-object v7, p0, Lc2;->l:Lv1;

    .line 32
    .line 33
    iget-object v8, p0, Lc2;->m:Li00;

    .line 34
    .line 35
    invoke-static/range {v0 .. v10}, Lzi1;->a(Lwi1;Lmi0;ZLui1;Li00;Li00;Lw1;Lv1;Li00;Ld10;I)V

    .line 36
    .line 37
    .line 38
    sget-object p0, Lwe1;->a:Lwe1;

    .line 39
    .line 40
    return-object p0
.end method
