.class public final synthetic Ld20;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lm00;


# instance fields
.field public final synthetic e:I

.field public final synthetic f:Ljava/lang/Object;

.field public final synthetic g:Ljava/lang/Object;

.field public final synthetic h:Ljava/lang/Object;

.field public final synthetic i:Ljava/lang/Object;

.field public final synthetic j:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Led1;Lbd1;Ljava/lang/Float;Ljava/lang/Float;Lyv;I)V
    .registers 7

    .line 1
    const/4 p6, 0x1

    .line 2
    iput p6, p0, Ld20;->e:I

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Ld20;->f:Ljava/lang/Object;

    .line 8
    .line 9
    iput-object p2, p0, Ld20;->g:Ljava/lang/Object;

    .line 10
    .line 11
    iput-object p3, p0, Ld20;->h:Ljava/lang/Object;

    .line 12
    .line 13
    iput-object p4, p0, Ld20;->i:Ljava/lang/Object;

    .line 14
    .line 15
    iput-object p5, p0, Ld20;->j:Ljava/lang/Object;

    .line 16
    .line 17
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Lmk0;Ljava/lang/String;Lt41;Landroid/content/Context;)V
    .registers 7

    .line 18
    const/4 v0, 0x0

    iput v0, p0, Ld20;->e:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ld20;->f:Ljava/lang/Object;

    iput-object p2, p0, Ld20;->h:Ljava/lang/Object;

    iput-object p3, p0, Ld20;->g:Ljava/lang/Object;

    iput-object p4, p0, Ld20;->i:Ljava/lang/Object;

    iput-object p5, p0, Ld20;->j:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 17

    .line 1
    iget v0, p0, Ld20;->e:I

    .line 2
    .line 3
    sget-object v1, Lwe1;->a:Lwe1;

    .line 4
    .line 5
    iget-object v2, p0, Ld20;->j:Ljava/lang/Object;

    .line 6
    .line 7
    iget-object v3, p0, Ld20;->i:Ljava/lang/Object;

    .line 8
    .line 9
    iget-object v4, p0, Ld20;->h:Ljava/lang/Object;

    .line 10
    .line 11
    iget-object v5, p0, Ld20;->g:Ljava/lang/Object;

    .line 12
    .line 13
    iget-object p0, p0, Ld20;->f:Ljava/lang/Object;

    .line 14
    .line 15
    const/4 v6, 0x1

    .line 16
    packed-switch v0, :pswitch_data_b2

    .line 17
    .line 18
    .line 19
    move-object v7, p0

    .line 20
    check-cast v7, Led1;

    .line 21
    .line 22
    move-object v8, v5

    .line 23
    check-cast v8, Lbd1;

    .line 24
    .line 25
    move-object v9, v4

    .line 26
    check-cast v9, Ljava/lang/Float;

    .line 27
    .line 28
    move-object v10, v3

    .line 29
    check-cast v10, Ljava/lang/Float;

    .line 30
    .line 31
    move-object v11, v2

    .line 32
    check-cast v11, Lyv;

    .line 33
    .line 34
    move-object v12, p1

    .line 35
    check-cast v12, Ld10;

    .line 36
    .line 37
    move-object/from16 p0, p2

    .line 38
    .line 39
    check-cast p0, Ljava/lang/Integer;

    .line 40
    .line 41
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 42
    .line 43
    .line 44
    invoke-static {v6}, Lwc0;->s(I)I

    .line 45
    .line 46
    .line 47
    move-result v13

    .line 48
    invoke-static/range {v7 .. v13}, Lgd1;->a(Led1;Lbd1;Ljava/lang/Float;Ljava/lang/Float;Lyv;Ld10;I)V

    .line 49
    .line 50
    .line 51
    return-object v1

    .line 52
    :pswitch_33  #0x0
    check-cast p0, Ljava/lang/String;

    .line 53
    .line 54
    check-cast v4, Lmk0;

    .line 55
    .line 56
    check-cast v5, Ljava/lang/String;

    .line 57
    .line 58
    check-cast v3, Lt41;

    .line 59
    .line 60
    check-cast v2, Landroid/content/Context;

    .line 61
    .line 62
    move-object v0, p1

    .line 63
    check-cast v0, Ld10;

    .line 64
    .line 65
    move-object/from16 v7, p2

    .line 66
    .line 67
    check-cast v7, Ljava/lang/Integer;

    .line 68
    .line 69
    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    .line 70
    .line 71
    .line 72
    move-result v7

    .line 73
    and-int/lit8 v8, v7, 0x3

    .line 74
    .line 75
    const/4 v9, 0x2

    .line 76
    const/4 v10, 0x0

    .line 77
    if-eq v8, v9, :cond_50

    .line 78
    .line 79
    move v8, v6

    .line 80
    goto :goto_51

    .line 81
    :cond_50
    move v8, v10

    .line 82
    :goto_51
    and-int/2addr v7, v6

    .line 83
    invoke-virtual {v0, v7, v8}, Ld10;->O(IZ)Z

    .line 84
    .line 85
    .line 86
    move-result v7

    .line 87
    if-eqz v7, :cond_ad

    .line 88
    .line 89
    const-string v7, "messages"

    .line 90
    .line 91
    invoke-static {p0, v7}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 92
    .line 93
    .line 94
    move-result p0

    .line 95
    sget-object v7, Loj;->a:Lnq0;

    .line 96
    .line 97
    if-eqz p0, :cond_85

    .line 98
    .line 99
    const p0, 0x7a5153bf

    .line 100
    .line 101
    .line 102
    invoke-virtual {v0, p0}, Ld10;->W(I)V

    .line 103
    .line 104
    .line 105
    invoke-virtual {v0, v4}, Ld10;->f(Ljava/lang/Object;)Z

    .line 106
    .line 107
    .line 108
    move-result p0

    .line 109
    invoke-virtual {v0}, Ld10;->L()Ljava/lang/Object;

    .line 110
    .line 111
    .line 112
    move-result-object v2

    .line 113
    if-nez p0, :cond_74

    .line 114
    .line 115
    if-ne v2, v7, :cond_7c

    .line 116
    .line 117
    :cond_74
    new-instance v2, La20;

    .line 118
    .line 119
    invoke-direct {v2, v4, v6}, La20;-><init>(Lmk0;I)V

    .line 120
    .line 121
    .line 122
    invoke-virtual {v0, v2}, Ld10;->g0(Ljava/lang/Object;)V

    .line 123
    .line 124
    .line 125
    :cond_7c
    check-cast v2, Lxz;

    .line 126
    .line 127
    invoke-static {v2, v0, v10}, Lzh0;->a(Lxz;Ld10;I)V

    .line 128
    .line 129
    .line 130
    invoke-virtual {v0, v10}, Ld10;->p(Z)V

    .line 131
    .line 132
    .line 133
    goto :goto_b0

    .line 134
    :cond_85
    const p0, 0x7a51658f

    .line 135
    .line 136
    .line 137
    invoke-virtual {v0, p0}, Ld10;->W(I)V

    .line 138
    .line 139
    .line 140
    invoke-virtual {v0, v2}, Ld10;->h(Ljava/lang/Object;)Z

    .line 141
    .line 142
    .line 143
    move-result p0

    .line 144
    invoke-virtual {v0, v4}, Ld10;->f(Ljava/lang/Object;)Z

    .line 145
    .line 146
    .line 147
    move-result v6

    .line 148
    or-int/2addr p0, v6

    .line 149
    invoke-virtual {v0}, Ld10;->L()Ljava/lang/Object;

    .line 150
    .line 151
    .line 152
    move-result-object v6

    .line 153
    if-nez p0, :cond_9c

    .line 154
    .line 155
    if-ne v6, v7, :cond_a4

    .line 156
    .line 157
    :cond_9c
    new-instance v6, Le20;

    .line 158
    .line 159
    invoke-direct {v6, v2, v4, v10}, Le20;-><init>(Landroid/content/Context;Lmk0;I)V

    .line 160
    .line 161
    .line 162
    invoke-virtual {v0, v6}, Ld10;->g0(Ljava/lang/Object;)V

    .line 163
    .line 164
    .line 165
    :cond_a4
    check-cast v6, Lxz;

    .line 166
    .line 167
    invoke-static {v5, v3, v6, v0, v10}, Lj70;->d(Ljava/lang/String;Lt41;Lxz;Ld10;I)V

    .line 168
    .line 169
    .line 170
    invoke-virtual {v0, v10}, Ld10;->p(Z)V

    .line 171
    .line 172
    .line 173
    goto :goto_b0

    .line 174
    :cond_ad
    invoke-virtual {v0}, Ld10;->R()V

    .line 175
    .line 176
    .line 177
    :goto_b0
    return-object v1

    .line 178
    nop

    .line 179
    :pswitch_data_b2
    .packed-switch 0x0
        :pswitch_33  #00000000
    .end packed-switch
.end method
