.class public final La61;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# instance fields
.field public final a:Lx51;

.field public b:[I

.field public c:[Ljava/lang/Object;

.field public d:Ljava/util/ArrayList;

.field public e:Ljava/util/HashMap;

.field public f:Lsj0;

.field public g:I

.field public h:I

.field public i:I

.field public j:I

.field public k:I

.field public l:I

.field public m:I

.field public n:I

.field public o:I

.field public final p:Lw60;

.field public final q:Lw60;

.field public final r:Lw60;

.field public s:Lsj0;

.field public t:I

.field public u:I

.field public v:I

.field public w:Z

.field public x:Lrj0;


# direct methods
.method public constructor <init>(Lx51;)V
    .registers 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, La61;->a:Lx51;

    .line 5
    .line 6
    iget-object v0, p1, Lx51;->e:[I

    .line 7
    .line 8
    iput-object v0, p0, La61;->b:[I

    .line 9
    .line 10
    iget-object v1, p1, Lx51;->g:[Ljava/lang/Object;

    .line 11
    .line 12
    iput-object v1, p0, La61;->c:[Ljava/lang/Object;

    .line 13
    .line 14
    iget-object v2, p1, Lx51;->m:Ljava/util/ArrayList;

    .line 15
    .line 16
    iput-object v2, p0, La61;->d:Ljava/util/ArrayList;

    .line 17
    .line 18
    iget-object v2, p1, Lx51;->n:Ljava/util/HashMap;

    .line 19
    .line 20
    iput-object v2, p0, La61;->e:Ljava/util/HashMap;

    .line 21
    .line 22
    iget-object v2, p1, Lx51;->o:Lsj0;

    .line 23
    .line 24
    iput-object v2, p0, La61;->f:Lsj0;

    .line 25
    .line 26
    iget v2, p1, Lx51;->f:I

    .line 27
    .line 28
    iput v2, p0, La61;->g:I

    .line 29
    .line 30
    array-length v0, v0

    .line 31
    div-int/lit8 v0, v0, 0x5

    .line 32
    .line 33
    sub-int/2addr v0, v2

    .line 34
    iput v0, p0, La61;->h:I

    .line 35
    .line 36
    iget p1, p1, Lx51;->h:I

    .line 37
    .line 38
    iput p1, p0, La61;->k:I

    .line 39
    .line 40
    array-length v0, v1

    .line 41
    sub-int/2addr v0, p1

    .line 42
    iput v0, p0, La61;->l:I

    .line 43
    .line 44
    iput v2, p0, La61;->m:I

    .line 45
    .line 46
    new-instance p1, Lw60;

    .line 47
    .line 48
    invoke-direct {p1}, Lw60;-><init>()V

    .line 49
    .line 50
    .line 51
    iput-object p1, p0, La61;->p:Lw60;

    .line 52
    .line 53
    new-instance p1, Lw60;

    .line 54
    .line 55
    invoke-direct {p1}, Lw60;-><init>()V

    .line 56
    .line 57
    .line 58
    iput-object p1, p0, La61;->q:Lw60;

    .line 59
    .line 60
    new-instance p1, Lw60;

    .line 61
    .line 62
    invoke-direct {p1}, Lw60;-><init>()V

    .line 63
    .line 64
    .line 65
    iput-object p1, p0, La61;->r:Lw60;

    .line 66
    .line 67
    iput v2, p0, La61;->u:I

    .line 68
    .line 69
    const/4 p1, -0x1

    .line 70
    iput p1, p0, La61;->v:I

    .line 71
    .line 72
    return-void
.end method

.method public static i(IIII)I
    .registers 4

    .line 1
    if-le p0, p1, :cond_7

    .line 2
    .line 3
    sub-int/2addr p3, p2

    .line 4
    sub-int/2addr p3, p0

    .line 5
    add-int/lit8 p3, p3, 0x1

    .line 6
    .line 7
    neg-int p0, p3

    .line 8
    :cond_7
    return p0
.end method

.method public static z(La61;)V
    .registers 7

    .line 1
    iget v0, p0, La61;->v:I

    .line 2
    .line 3
    invoke-virtual {p0, v0}, La61;->r(I)I

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    iget-object v2, p0, La61;->b:[I

    .line 8
    .line 9
    mul-int/lit8 v1, v1, 0x5

    .line 10
    .line 11
    add-int/lit8 v1, v1, 0x1

    .line 12
    .line 13
    aget v3, v2, v1

    .line 14
    .line 15
    const/high16 v4, 0x8000000

    .line 16
    .line 17
    and-int v5, v3, v4

    .line 18
    .line 19
    if-eqz v5, :cond_15

    .line 20
    .line 21
    goto :goto_21

    .line 22
    :cond_15
    const v5, -0x8000001

    .line 23
    .line 24
    .line 25
    and-int/2addr v3, v5

    .line 26
    or-int/2addr v3, v4

    .line 27
    aput v3, v2, v1

    .line 28
    .line 29
    const/high16 v1, 0x4000000

    .line 30
    .line 31
    and-int/2addr v1, v3

    .line 32
    if-eqz v1, :cond_22

    .line 33
    .line 34
    :goto_21
    return-void

    .line 35
    :cond_22
    invoke-virtual {p0, v2, v0}, La61;->E([II)I

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    invoke-virtual {p0, v0}, La61;->T(I)V

    .line 40
    .line 41
    .line 42
    return-void
.end method


# virtual methods
.method public final A(Lx51;I)V
    .registers 18

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    iget v1, p0, La61;->n:I

    .line 4
    .line 5
    if-lez v1, :cond_7

    .line 6
    .line 7
    goto :goto_c

    .line 8
    :cond_7
    const-string v1, "Check failed"

    .line 9
    .line 10
    invoke-static {v1}, Lqj;->a(Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    :goto_c
    const/4 v7, 0x0

    .line 14
    if-nez p2, :cond_62

    .line 15
    .line 16
    iget v1, p0, La61;->t:I

    .line 17
    .line 18
    if-nez v1, :cond_62

    .line 19
    .line 20
    iget-object v1, p0, La61;->a:Lx51;

    .line 21
    .line 22
    iget v1, v1, Lx51;->f:I

    .line 23
    .line 24
    if-nez v1, :cond_62

    .line 25
    .line 26
    iget-object v1, v0, Lx51;->e:[I

    .line 27
    .line 28
    mul-int/lit8 v2, p2, 0x5

    .line 29
    .line 30
    add-int/lit8 v2, v2, 0x3

    .line 31
    .line 32
    aget v2, v1, v2

    .line 33
    .line 34
    iget v4, v0, Lx51;->f:I

    .line 35
    .line 36
    if-ne v2, v4, :cond_62

    .line 37
    .line 38
    iget-object v2, p0, La61;->b:[I

    .line 39
    .line 40
    iget-object v5, p0, La61;->c:[Ljava/lang/Object;

    .line 41
    .line 42
    iget-object v6, p0, La61;->d:Ljava/util/ArrayList;

    .line 43
    .line 44
    iget-object v8, p0, La61;->e:Ljava/util/HashMap;

    .line 45
    .line 46
    iget-object v9, p0, La61;->f:Lsj0;

    .line 47
    .line 48
    iget-object v10, v0, Lx51;->g:[Ljava/lang/Object;

    .line 49
    .line 50
    iget v11, v0, Lx51;->h:I

    .line 51
    .line 52
    iget-object v12, v0, Lx51;->n:Ljava/util/HashMap;

    .line 53
    .line 54
    iget-object v13, v0, Lx51;->o:Lsj0;

    .line 55
    .line 56
    iput-object v1, p0, La61;->b:[I

    .line 57
    .line 58
    iput-object v10, p0, La61;->c:[Ljava/lang/Object;

    .line 59
    .line 60
    iget-object v14, v0, Lx51;->m:Ljava/util/ArrayList;

    .line 61
    .line 62
    iput-object v14, p0, La61;->d:Ljava/util/ArrayList;

    .line 63
    .line 64
    iput v4, p0, La61;->g:I

    .line 65
    .line 66
    array-length v1, v1

    .line 67
    div-int/lit8 v1, v1, 0x5

    .line 68
    .line 69
    sub-int/2addr v1, v4

    .line 70
    iput v1, p0, La61;->h:I

    .line 71
    .line 72
    iput v11, p0, La61;->k:I

    .line 73
    .line 74
    array-length v1, v10

    .line 75
    sub-int/2addr v1, v11

    .line 76
    iput v1, p0, La61;->l:I

    .line 77
    .line 78
    iput v4, p0, La61;->m:I

    .line 79
    .line 80
    iput-object v12, p0, La61;->e:Ljava/util/HashMap;

    .line 81
    .line 82
    iput-object v13, p0, La61;->f:Lsj0;

    .line 83
    .line 84
    iput-object v2, v0, Lx51;->e:[I

    .line 85
    .line 86
    iput v7, v0, Lx51;->f:I

    .line 87
    .line 88
    iput-object v5, v0, Lx51;->g:[Ljava/lang/Object;

    .line 89
    .line 90
    iput v7, v0, Lx51;->h:I

    .line 91
    .line 92
    iput-object v6, v0, Lx51;->m:Ljava/util/ArrayList;

    .line 93
    .line 94
    iput-object v8, v0, Lx51;->n:Ljava/util/HashMap;

    .line 95
    .line 96
    iput-object v9, v0, Lx51;->o:Lsj0;

    .line 97
    .line 98
    return-void

    .line 99
    :cond_62
    invoke-virtual {v0}, Lx51;->e()La61;

    .line 100
    .line 101
    .line 102
    move-result-object v1

    .line 103
    const/4 v4, 0x1

    .line 104
    const/4 v5, 0x1

    .line 105
    const/4 v6, 0x0

    .line 106
    move-object v3, p0

    .line 107
    move/from16 v2, p2

    .line 108
    .line 109
    :try_start_6c
    invoke-static/range {v1 .. v6}, Ljb0;->o(La61;ILa61;ZZZ)Ljava/util/List;
    :try_end_6f
    .catchall {:try_start_6c .. :try_end_6f} :catchall_74

    .line 110
    .line 111
    .line 112
    const/4 v0, 0x1

    .line 113
    invoke-virtual {v1, v0}, La61;->e(Z)V

    .line 114
    .line 115
    .line 116
    return-void

    .line 117
    :catchall_74
    move-exception v0

    .line 118
    invoke-virtual {v1, v7}, La61;->e(Z)V

    .line 119
    .line 120
    .line 121
    throw v0
.end method

.method public final B(I)V
    .registers 10

    .line 1
    iget v0, p0, La61;->h:I

    .line 2
    .line 3
    iget v1, p0, La61;->g:I

    .line 4
    .line 5
    if-eq v1, p1, :cond_ab

    .line 6
    .line 7
    iget-object v2, p0, La61;->d:Ljava/util/ArrayList;

    .line 8
    .line 9
    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    .line 10
    .line 11
    .line 12
    move-result v2

    .line 13
    if-nez v2, :cond_59

    .line 14
    .line 15
    iget v2, p0, La61;->h:I

    .line 16
    .line 17
    invoke-virtual {p0}, La61;->o()I

    .line 18
    .line 19
    .line 20
    move-result v3

    .line 21
    sub-int/2addr v3, v2

    .line 22
    iget-object v2, p0, La61;->d:Ljava/util/ArrayList;

    .line 23
    .line 24
    if-ge v1, p1, :cond_39

    .line 25
    .line 26
    invoke-static {v2, v1, v3}, Lz51;->a(Ljava/util/ArrayList;II)I

    .line 27
    .line 28
    .line 29
    move-result v2

    .line 30
    :goto_1d
    iget-object v4, p0, La61;->d:Ljava/util/ArrayList;

    .line 31
    .line 32
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    .line 33
    .line 34
    .line 35
    move-result v4

    .line 36
    if-ge v2, v4, :cond_59

    .line 37
    .line 38
    iget-object v4, p0, La61;->d:Ljava/util/ArrayList;

    .line 39
    .line 40
    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object v4

    .line 44
    check-cast v4, Ly00;

    .line 45
    .line 46
    iget v5, v4, Ly00;->a:I

    .line 47
    .line 48
    if-gez v5, :cond_59

    .line 49
    .line 50
    add-int/2addr v5, v3

    .line 51
    if-ge v5, p1, :cond_59

    .line 52
    .line 53
    iput v5, v4, Ly00;->a:I

    .line 54
    .line 55
    add-int/lit8 v2, v2, 0x1

    .line 56
    .line 57
    goto :goto_1d

    .line 58
    :cond_39
    invoke-static {v2, p1, v3}, Lz51;->a(Ljava/util/ArrayList;II)I

    .line 59
    .line 60
    .line 61
    move-result v2

    .line 62
    :goto_3d
    iget-object v4, p0, La61;->d:Ljava/util/ArrayList;

    .line 63
    .line 64
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    .line 65
    .line 66
    .line 67
    move-result v4

    .line 68
    if-ge v2, v4, :cond_59

    .line 69
    .line 70
    iget-object v4, p0, La61;->d:Ljava/util/ArrayList;

    .line 71
    .line 72
    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 73
    .line 74
    .line 75
    move-result-object v4

    .line 76
    check-cast v4, Ly00;

    .line 77
    .line 78
    iget v5, v4, Ly00;->a:I

    .line 79
    .line 80
    if-ltz v5, :cond_59

    .line 81
    .line 82
    sub-int v5, v3, v5

    .line 83
    .line 84
    neg-int v5, v5

    .line 85
    iput v5, v4, Ly00;->a:I

    .line 86
    .line 87
    add-int/lit8 v2, v2, 0x1

    .line 88
    .line 89
    goto :goto_3d

    .line 90
    :cond_59
    if-lez v0, :cond_70

    .line 91
    .line 92
    iget-object v2, p0, La61;->b:[I

    .line 93
    .line 94
    mul-int/lit8 v3, p1, 0x5

    .line 95
    .line 96
    mul-int/lit8 v4, v0, 0x5

    .line 97
    .line 98
    mul-int/lit8 v5, v1, 0x5

    .line 99
    .line 100
    if-ge p1, v1, :cond_6a

    .line 101
    .line 102
    add-int/2addr v4, v3

    .line 103
    invoke-static {v2, v2, v4, v3, v5}, Lba;->W([I[IIII)V

    .line 104
    .line 105
    .line 106
    goto :goto_70

    .line 107
    :cond_6a
    add-int v6, v5, v4

    .line 108
    .line 109
    add-int/2addr v3, v4

    .line 110
    invoke-static {v2, v2, v5, v6, v3}, Lba;->W([I[IIII)V

    .line 111
    .line 112
    .line 113
    :cond_70
    :goto_70
    if-ge p1, v1, :cond_74

    .line 114
    .line 115
    add-int v1, p1, v0

    .line 116
    .line 117
    :cond_74
    invoke-virtual {p0}, La61;->o()I

    .line 118
    .line 119
    .line 120
    move-result v2

    .line 121
    if-ge v1, v2, :cond_7b

    .line 122
    .line 123
    goto :goto_80

    .line 124
    :cond_7b
    const-string v3, "Check failed"

    .line 125
    .line 126
    invoke-static {v3}, Lqj;->a(Ljava/lang/String;)V

    .line 127
    .line 128
    .line 129
    :cond_80
    :goto_80
    if-ge v1, v2, :cond_ab

    .line 130
    .line 131
    iget-object v3, p0, La61;->b:[I

    .line 132
    .line 133
    mul-int/lit8 v4, v1, 0x5

    .line 134
    .line 135
    add-int/lit8 v4, v4, 0x2

    .line 136
    .line 137
    aget v3, v3, v4

    .line 138
    .line 139
    const/4 v5, -0x2

    .line 140
    if-le v3, v5, :cond_8f

    .line 141
    .line 142
    move v6, v3

    .line 143
    goto :goto_95

    .line 144
    :cond_8f
    invoke-virtual {p0}, La61;->p()I

    .line 145
    .line 146
    .line 147
    move-result v6

    .line 148
    add-int/2addr v6, v3

    .line 149
    sub-int/2addr v6, v5

    .line 150
    :goto_95
    if-ge v6, p1, :cond_98

    .line 151
    .line 152
    goto :goto_9f

    .line 153
    :cond_98
    invoke-virtual {p0}, La61;->p()I

    .line 154
    .line 155
    .line 156
    move-result v7

    .line 157
    sub-int/2addr v7, v6

    .line 158
    sub-int/2addr v7, v5

    .line 159
    neg-int v6, v7

    .line 160
    :goto_9f
    if-eq v6, v3, :cond_a5

    .line 161
    .line 162
    iget-object v3, p0, La61;->b:[I

    .line 163
    .line 164
    aput v6, v3, v4

    .line 165
    .line 166
    :cond_a5
    add-int/lit8 v1, v1, 0x1

    .line 167
    .line 168
    if-ne v1, p1, :cond_80

    .line 169
    .line 170
    add-int/2addr v1, v0

    .line 171
    goto :goto_80

    .line 172
    :cond_ab
    iput p1, p0, La61;->g:I

    .line 173
    .line 174
    return-void
.end method

.method public final C(II)V
    .registers 10

    .line 1
    iget v0, p0, La61;->l:I

    .line 2
    .line 3
    iget v1, p0, La61;->k:I

    .line 4
    .line 5
    iget v2, p0, La61;->m:I

    .line 6
    .line 7
    if-eq v1, p1, :cond_1b

    .line 8
    .line 9
    iget-object v3, p0, La61;->c:[Ljava/lang/Object;

    .line 10
    .line 11
    if-ge p1, v1, :cond_13

    .line 12
    .line 13
    add-int v4, p1, v0

    .line 14
    .line 15
    sub-int/2addr v1, p1

    .line 16
    invoke-static {v3, p1, v3, v4, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 17
    .line 18
    .line 19
    goto :goto_1b

    .line 20
    :cond_13
    add-int v4, v1, v0

    .line 21
    .line 22
    add-int v5, p1, v0

    .line 23
    .line 24
    sub-int/2addr v5, v4

    .line 25
    invoke-static {v3, v4, v3, v1, v5}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 26
    .line 27
    .line 28
    :cond_1b
    :goto_1b
    add-int/lit8 p2, p2, 0x1

    .line 29
    .line 30
    invoke-virtual {p0}, La61;->p()I

    .line 31
    .line 32
    .line 33
    move-result v1

    .line 34
    invoke-static {p2, v1}, Ljava/lang/Math;->min(II)I

    .line 35
    .line 36
    .line 37
    move-result p2

    .line 38
    if-eq v2, p2, :cond_87

    .line 39
    .line 40
    iget-object v1, p0, La61;->c:[Ljava/lang/Object;

    .line 41
    .line 42
    array-length v1, v1

    .line 43
    sub-int/2addr v1, v0

    .line 44
    if-ge p2, v2, :cond_5a

    .line 45
    .line 46
    invoke-virtual {p0, p2}, La61;->r(I)I

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    invoke-virtual {p0, v2}, La61;->r(I)I

    .line 51
    .line 52
    .line 53
    move-result v2

    .line 54
    iget v3, p0, La61;->g:I

    .line 55
    .line 56
    :cond_37
    :goto_37
    if-ge v0, v2, :cond_85

    .line 57
    .line 58
    iget-object v4, p0, La61;->b:[I

    .line 59
    .line 60
    mul-int/lit8 v5, v0, 0x5

    .line 61
    .line 62
    add-int/lit8 v5, v5, 0x4

    .line 63
    .line 64
    aget v4, v4, v5

    .line 65
    .line 66
    if-ltz v4, :cond_44

    .line 67
    .line 68
    goto :goto_49

    .line 69
    :cond_44
    const-string v6, "Unexpected anchor value, expected a positive anchor"

    .line 70
    .line 71
    invoke-static {v6}, Lqj;->a(Ljava/lang/String;)V

    .line 72
    .line 73
    .line 74
    :goto_49
    iget-object v6, p0, La61;->b:[I

    .line 75
    .line 76
    sub-int v4, v1, v4

    .line 77
    .line 78
    add-int/lit8 v4, v4, 0x1

    .line 79
    .line 80
    neg-int v4, v4

    .line 81
    aput v4, v6, v5

    .line 82
    .line 83
    add-int/lit8 v0, v0, 0x1

    .line 84
    .line 85
    if-ne v0, v3, :cond_37

    .line 86
    .line 87
    iget v4, p0, La61;->h:I

    .line 88
    .line 89
    add-int/2addr v0, v4

    .line 90
    goto :goto_37

    .line 91
    :cond_5a
    invoke-virtual {p0, v2}, La61;->r(I)I

    .line 92
    .line 93
    .line 94
    move-result v0

    .line 95
    invoke-virtual {p0, p2}, La61;->r(I)I

    .line 96
    .line 97
    .line 98
    move-result v2

    .line 99
    :cond_62
    :goto_62
    if-ge v0, v2, :cond_85

    .line 100
    .line 101
    iget-object v3, p0, La61;->b:[I

    .line 102
    .line 103
    mul-int/lit8 v4, v0, 0x5

    .line 104
    .line 105
    add-int/lit8 v4, v4, 0x4

    .line 106
    .line 107
    aget v3, v3, v4

    .line 108
    .line 109
    if-gez v3, :cond_6f

    .line 110
    .line 111
    goto :goto_74

    .line 112
    :cond_6f
    const-string v5, "Unexpected anchor value, expected a negative anchor"

    .line 113
    .line 114
    invoke-static {v5}, Lqj;->a(Ljava/lang/String;)V

    .line 115
    .line 116
    .line 117
    :goto_74
    iget-object v5, p0, La61;->b:[I

    .line 118
    .line 119
    add-int/2addr v3, v1

    .line 120
    add-int/lit8 v3, v3, 0x1

    .line 121
    .line 122
    aput v3, v5, v4

    .line 123
    .line 124
    add-int/lit8 v0, v0, 0x1

    .line 125
    .line 126
    iget v3, p0, La61;->g:I

    .line 127
    .line 128
    if-ne v0, v3, :cond_62

    .line 129
    .line 130
    iget v3, p0, La61;->h:I

    .line 131
    .line 132
    add-int/2addr v0, v3

    .line 133
    goto :goto_62

    .line 134
    :cond_85
    iput p2, p0, La61;->m:I

    .line 135
    .line 136
    :cond_87
    iput p1, p0, La61;->k:I

    .line 137
    .line 138
    return-void
.end method

.method public final D(I)Ljava/lang/Object;
    .registers 5

    .line 1
    invoke-virtual {p0, p1}, La61;->r(I)I

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    iget-object v0, p0, La61;->b:[I

    .line 6
    .line 7
    mul-int/lit8 v1, p1, 0x5

    .line 8
    .line 9
    add-int/lit8 v1, v1, 0x1

    .line 10
    .line 11
    aget v1, v0, v1

    .line 12
    .line 13
    const/high16 v2, 0x40000000  # 2.0f

    .line 14
    .line 15
    and-int/2addr v1, v2

    .line 16
    if-eqz v1, :cond_1e

    .line 17
    .line 18
    iget-object v1, p0, La61;->c:[Ljava/lang/Object;

    .line 19
    .line 20
    invoke-virtual {p0, v0, p1}, La61;->g([II)I

    .line 21
    .line 22
    .line 23
    move-result p1

    .line 24
    invoke-virtual {p0, p1}, La61;->h(I)I

    .line 25
    .line 26
    .line 27
    move-result p0

    .line 28
    aget-object p0, v1, p0

    .line 29
    .line 30
    return-object p0

    .line 31
    :cond_1e
    const/4 p0, 0x0

    .line 32
    return-object p0
.end method

.method public final E([II)I
    .registers 3

    .line 1
    invoke-virtual {p0, p2}, La61;->r(I)I

    .line 2
    .line 3
    .line 4
    move-result p2

    .line 5
    mul-int/lit8 p2, p2, 0x5

    .line 6
    .line 7
    add-int/lit8 p2, p2, 0x2

    .line 8
    .line 9
    aget p1, p1, p2

    .line 10
    .line 11
    const/4 p2, -0x2

    .line 12
    if-le p1, p2, :cond_e

    .line 13
    .line 14
    return p1

    .line 15
    :cond_e
    invoke-virtual {p0}, La61;->p()I

    .line 16
    .line 17
    .line 18
    move-result p0

    .line 19
    add-int/2addr p0, p1

    .line 20
    sub-int/2addr p0, p2

    .line 21
    return p0
.end method

.method public final F(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    .line 1
    iget v0, p0, La61;->n:I

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-lez v0, :cond_a

    .line 5
    .line 6
    iget v0, p0, La61;->v:I

    .line 7
    .line 8
    invoke-virtual {p0, v1, v0}, La61;->x(II)V

    .line 9
    .line 10
    .line 11
    :cond_a
    iget-object v0, p0, La61;->c:[Ljava/lang/Object;

    .line 12
    .line 13
    iget v2, p0, La61;->i:I

    .line 14
    .line 15
    add-int/lit8 v3, v2, 0x1

    .line 16
    .line 17
    iput v3, p0, La61;->i:I

    .line 18
    .line 19
    invoke-virtual {p0, v2}, La61;->h(I)I

    .line 20
    .line 21
    .line 22
    move-result v2

    .line 23
    aget-object v0, v0, v2

    .line 24
    .line 25
    iget v2, p0, La61;->i:I

    .line 26
    .line 27
    iget v3, p0, La61;->j:I

    .line 28
    .line 29
    if-gt v2, v3, :cond_1f

    .line 30
    .line 31
    goto :goto_24

    .line 32
    :cond_1f
    const-string v2, "Writing to an invalid slot"

    .line 33
    .line 34
    invoke-static {v2}, Lqj;->a(Ljava/lang/String;)V

    .line 35
    .line 36
    .line 37
    :goto_24
    iget-object v2, p0, La61;->c:[Ljava/lang/Object;

    .line 38
    .line 39
    iget v3, p0, La61;->i:I

    .line 40
    .line 41
    sub-int/2addr v3, v1

    .line 42
    invoke-virtual {p0, v3}, La61;->h(I)I

    .line 43
    .line 44
    .line 45
    move-result p0

    .line 46
    aput-object p1, v2, p0

    .line 47
    .line 48
    return-object v0
.end method

.method public final G()V
    .registers 10

    .line 1
    iget-object v0, p0, La61;->x:Lrj0;

    .line 2
    .line 3
    if-eqz v0, :cond_56

    .line 4
    .line 5
    :cond_4
    :goto_4
    iget v1, v0, Lrj0;->b:I

    .line 6
    .line 7
    if-eqz v1, :cond_56

    .line 8
    .line 9
    invoke-static {v0}, Ljb0;->A(Lrj0;)I

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    invoke-virtual {p0, v1}, La61;->r(I)I

    .line 14
    .line 15
    .line 16
    move-result v2

    .line 17
    add-int/lit8 v3, v1, 0x1

    .line 18
    .line 19
    invoke-virtual {p0, v1}, La61;->u(I)I

    .line 20
    .line 21
    .line 22
    move-result v4

    .line 23
    add-int/2addr v4, v1

    .line 24
    :goto_17
    const/4 v5, 0x0

    .line 25
    const/4 v6, 0x1

    .line 26
    if-ge v3, v4, :cond_33

    .line 27
    .line 28
    iget-object v7, p0, La61;->b:[I

    .line 29
    .line 30
    invoke-virtual {p0, v3}, La61;->r(I)I

    .line 31
    .line 32
    .line 33
    move-result v8

    .line 34
    mul-int/lit8 v8, v8, 0x5

    .line 35
    .line 36
    add-int/2addr v8, v6

    .line 37
    aget v7, v7, v8

    .line 38
    .line 39
    const/high16 v8, 0xc000000

    .line 40
    .line 41
    and-int/2addr v7, v8

    .line 42
    if-eqz v7, :cond_2d

    .line 43
    .line 44
    move v3, v6

    .line 45
    goto :goto_34

    .line 46
    :cond_2d
    invoke-virtual {p0, v3}, La61;->u(I)I

    .line 47
    .line 48
    .line 49
    move-result v5

    .line 50
    add-int/2addr v3, v5

    .line 51
    goto :goto_17

    .line 52
    :cond_33
    move v3, v5

    .line 53
    :goto_34
    iget-object v4, p0, La61;->b:[I

    .line 54
    .line 55
    mul-int/lit8 v2, v2, 0x5

    .line 56
    .line 57
    add-int/2addr v2, v6

    .line 58
    aget v7, v4, v2

    .line 59
    .line 60
    const/high16 v8, 0x4000000

    .line 61
    .line 62
    and-int/2addr v8, v7

    .line 63
    if-eqz v8, :cond_41

    .line 64
    .line 65
    move v5, v6

    .line 66
    :cond_41
    if-eq v5, v3, :cond_4

    .line 67
    .line 68
    const v5, -0x4000001

    .line 69
    .line 70
    .line 71
    and-int/2addr v5, v7

    .line 72
    shl-int/lit8 v3, v3, 0x1a

    .line 73
    .line 74
    or-int/2addr v3, v5

    .line 75
    aput v3, v4, v2

    .line 76
    .line 77
    invoke-virtual {p0, v4, v1}, La61;->E([II)I

    .line 78
    .line 79
    .line 80
    move-result v1

    .line 81
    if-ltz v1, :cond_4

    .line 82
    .line 83
    invoke-static {v0, v1}, Ljb0;->d(Lrj0;I)V

    .line 84
    .line 85
    .line 86
    goto :goto_4

    .line 87
    :cond_56
    return-void
.end method

.method public final H()Z
    .registers 8

    .line 1
    iget v0, p0, La61;->n:I

    .line 2
    .line 3
    if-nez v0, :cond_5

    .line 4
    .line 5
    goto :goto_a

    .line 6
    :cond_5
    const-string v0, "Cannot remove group while inserting"

    .line 7
    .line 8
    invoke-static {v0}, Lqj;->a(Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    :goto_a
    iget v0, p0, La61;->t:I

    .line 12
    .line 13
    iget v1, p0, La61;->i:I

    .line 14
    .line 15
    iget-object v2, p0, La61;->b:[I

    .line 16
    .line 17
    invoke-virtual {p0, v0}, La61;->r(I)I

    .line 18
    .line 19
    .line 20
    move-result v3

    .line 21
    invoke-virtual {p0, v2, v3}, La61;->g([II)I

    .line 22
    .line 23
    .line 24
    move-result v2

    .line 25
    invoke-virtual {p0}, La61;->L()I

    .line 26
    .line 27
    .line 28
    move-result v3

    .line 29
    iget v4, p0, La61;->v:I

    .line 30
    .line 31
    invoke-virtual {p0, v4}, La61;->O(I)Lf10;

    .line 32
    .line 33
    .line 34
    iget-object v4, p0, La61;->x:Lrj0;

    .line 35
    .line 36
    if-eqz v4, :cond_3e

    .line 37
    .line 38
    :goto_25
    iget v5, v4, Lrj0;->b:I

    .line 39
    .line 40
    if-eqz v5, :cond_3e

    .line 41
    .line 42
    if-eqz v5, :cond_36

    .line 43
    .line 44
    iget-object v5, v4, Lrj0;->a:[I

    .line 45
    .line 46
    const/4 v6, 0x0

    .line 47
    aget v5, v5, v6

    .line 48
    .line 49
    if-lt v5, v0, :cond_3e

    .line 50
    .line 51
    invoke-static {v4}, Ljb0;->A(Lrj0;)I

    .line 52
    .line 53
    .line 54
    goto :goto_25

    .line 55
    :cond_36
    new-instance p0, Ljava/util/NoSuchElementException;

    .line 56
    .line 57
    const-string v0, "IntList is empty."

    .line 58
    .line 59
    invoke-direct {p0, v0}, Ljava/util/NoSuchElementException;-><init>(Ljava/lang/String;)V

    .line 60
    .line 61
    .line 62
    throw p0

    .line 63
    :cond_3e
    iget v4, p0, La61;->t:I

    .line 64
    .line 65
    sub-int/2addr v4, v0

    .line 66
    invoke-virtual {p0, v0, v4}, La61;->I(II)Z

    .line 67
    .line 68
    .line 69
    move-result v4

    .line 70
    iget v5, p0, La61;->i:I

    .line 71
    .line 72
    sub-int/2addr v5, v2

    .line 73
    add-int/lit8 v6, v0, -0x1

    .line 74
    .line 75
    invoke-virtual {p0, v2, v5, v6}, La61;->J(III)V

    .line 76
    .line 77
    .line 78
    iput v0, p0, La61;->t:I

    .line 79
    .line 80
    iput v1, p0, La61;->i:I

    .line 81
    .line 82
    iget v0, p0, La61;->o:I

    .line 83
    .line 84
    sub-int/2addr v0, v3

    .line 85
    iput v0, p0, La61;->o:I

    .line 86
    .line 87
    return v4
.end method

.method public final I(II)Z
    .registers 12

    .line 1
    const/4 v0, 0x0

    .line 2
    if-lez p2, :cond_93

    .line 3
    .line 4
    iget-object v1, p0, La61;->d:Ljava/util/ArrayList;

    .line 5
    .line 6
    invoke-virtual {p0, p1}, La61;->B(I)V

    .line 7
    .line 8
    .line 9
    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    const/4 v2, 0x1

    .line 14
    if-nez v1, :cond_61

    .line 15
    .line 16
    iget-object v1, p0, La61;->e:Ljava/util/HashMap;

    .line 17
    .line 18
    iget v3, p0, La61;->h:I

    .line 19
    .line 20
    add-int v4, p1, p2

    .line 21
    .line 22
    invoke-virtual {p0}, La61;->o()I

    .line 23
    .line 24
    .line 25
    move-result v5

    .line 26
    sub-int/2addr v5, v3

    .line 27
    iget-object v3, p0, La61;->d:Ljava/util/ArrayList;

    .line 28
    .line 29
    invoke-static {v3, v4, v5}, Lz51;->a(Ljava/util/ArrayList;II)I

    .line 30
    .line 31
    .line 32
    move-result v3

    .line 33
    iget-object v5, p0, La61;->d:Ljava/util/ArrayList;

    .line 34
    .line 35
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    .line 36
    .line 37
    .line 38
    move-result v5

    .line 39
    if-lt v3, v5, :cond_2a

    .line 40
    .line 41
    add-int/lit8 v3, v3, -0x1

    .line 42
    .line 43
    :cond_2a
    add-int/lit8 v5, v3, 0x1

    .line 44
    .line 45
    move v6, v0

    .line 46
    :goto_2d
    if-ltz v3, :cond_53

    .line 47
    .line 48
    iget-object v7, p0, La61;->d:Ljava/util/ArrayList;

    .line 49
    .line 50
    invoke-virtual {v7, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object v7

    .line 54
    check-cast v7, Ly00;

    .line 55
    .line 56
    invoke-virtual {p0, v7}, La61;->c(Ly00;)I

    .line 57
    .line 58
    .line 59
    move-result v8

    .line 60
    if-lt v8, p1, :cond_53

    .line 61
    .line 62
    if-ge v8, v4, :cond_50

    .line 63
    .line 64
    const/high16 v5, -0x80000000

    .line 65
    .line 66
    iput v5, v7, Ly00;->a:I

    .line 67
    .line 68
    if-eqz v1, :cond_4b

    .line 69
    .line 70
    invoke-virtual {v1, v7}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 71
    .line 72
    .line 73
    move-result-object v5

    .line 74
    check-cast v5, Lf10;

    .line 75
    .line 76
    :cond_4b
    if-nez v6, :cond_4f

    .line 77
    .line 78
    add-int/lit8 v6, v3, 0x1

    .line 79
    .line 80
    :cond_4f
    move v5, v3

    .line 81
    :cond_50
    add-int/lit8 v3, v3, -0x1

    .line 82
    .line 83
    goto :goto_2d

    .line 84
    :cond_53
    if-ge v5, v6, :cond_56

    .line 85
    .line 86
    move v0, v2

    .line 87
    :cond_56
    if-eqz v0, :cond_61

    .line 88
    .line 89
    iget-object v1, p0, La61;->d:Ljava/util/ArrayList;

    .line 90
    .line 91
    invoke-virtual {v1, v5, v6}, Ljava/util/ArrayList;->subList(II)Ljava/util/List;

    .line 92
    .line 93
    .line 94
    move-result-object v1

    .line 95
    invoke-interface {v1}, Ljava/util/List;->clear()V

    .line 96
    .line 97
    .line 98
    :cond_61
    iput p1, p0, La61;->g:I

    .line 99
    .line 100
    iget v1, p0, La61;->h:I

    .line 101
    .line 102
    add-int/2addr v1, p2

    .line 103
    iput v1, p0, La61;->h:I

    .line 104
    .line 105
    iget v1, p0, La61;->m:I

    .line 106
    .line 107
    if-le v1, p1, :cond_73

    .line 108
    .line 109
    sub-int/2addr v1, p2

    .line 110
    invoke-static {p1, v1}, Ljava/lang/Math;->max(II)I

    .line 111
    .line 112
    .line 113
    move-result p1

    .line 114
    iput p1, p0, La61;->m:I

    .line 115
    .line 116
    :cond_73
    iget p1, p0, La61;->u:I

    .line 117
    .line 118
    iget v1, p0, La61;->g:I

    .line 119
    .line 120
    if-lt p1, v1, :cond_7c

    .line 121
    .line 122
    sub-int/2addr p1, p2

    .line 123
    iput p1, p0, La61;->u:I

    .line 124
    .line 125
    :cond_7c
    iget p1, p0, La61;->v:I

    .line 126
    .line 127
    if-ltz p1, :cond_93

    .line 128
    .line 129
    iget-object p2, p0, La61;->b:[I

    .line 130
    .line 131
    invoke-virtual {p0, p1}, La61;->r(I)I

    .line 132
    .line 133
    .line 134
    move-result v1

    .line 135
    mul-int/lit8 v1, v1, 0x5

    .line 136
    .line 137
    add-int/2addr v1, v2

    .line 138
    aget p2, p2, v1

    .line 139
    .line 140
    const/high16 v1, 0x4000000

    .line 141
    .line 142
    and-int/2addr p2, v1

    .line 143
    if-eqz p2, :cond_93

    .line 144
    .line 145
    invoke-virtual {p0, p1}, La61;->T(I)V

    .line 146
    .line 147
    .line 148
    :cond_93
    return v0
.end method

.method public final J(III)V
    .registers 6

    .line 1
    if-lez p2, :cond_1b

    .line 2
    .line 3
    iget v0, p0, La61;->l:I

    .line 4
    .line 5
    add-int v1, p1, p2

    .line 6
    .line 7
    invoke-virtual {p0, v1, p3}, La61;->C(II)V

    .line 8
    .line 9
    .line 10
    iput p1, p0, La61;->k:I

    .line 11
    .line 12
    add-int/2addr v0, p2

    .line 13
    iput v0, p0, La61;->l:I

    .line 14
    .line 15
    iget-object p3, p0, La61;->c:[Ljava/lang/Object;

    .line 16
    .line 17
    const/4 v0, 0x0

    .line 18
    invoke-static {p3, p1, v1, v0}, Ljava/util/Arrays;->fill([Ljava/lang/Object;IILjava/lang/Object;)V

    .line 19
    .line 20
    .line 21
    iget p3, p0, La61;->j:I

    .line 22
    .line 23
    if-lt p3, p1, :cond_1b

    .line 24
    .line 25
    sub-int/2addr p3, p2

    .line 26
    iput p3, p0, La61;->j:I

    .line 27
    .line 28
    :cond_1b
    return-void
.end method

.method public final K(IILjava/lang/Object;)Ljava/lang/Object;
    .registers 7

    .line 1
    invoke-virtual {p0, p1}, La61;->r(I)I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    iget-object v1, p0, La61;->b:[I

    .line 6
    .line 7
    invoke-virtual {p0, v1, v0}, La61;->N([II)I

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    iget-object v1, p0, La61;->b:[I

    .line 12
    .line 13
    add-int/lit8 v2, p1, 0x1

    .line 14
    .line 15
    invoke-virtual {p0, v2}, La61;->r(I)I

    .line 16
    .line 17
    .line 18
    move-result v2

    .line 19
    invoke-virtual {p0, v1, v2}, La61;->g([II)I

    .line 20
    .line 21
    .line 22
    move-result v1

    .line 23
    add-int v2, v0, p2

    .line 24
    .line 25
    if-lt v2, v0, :cond_1d

    .line 26
    .line 27
    if-ge v2, v1, :cond_1d

    .line 28
    .line 29
    goto :goto_36

    .line 30
    :cond_1d
    new-instance v0, Ljava/lang/StringBuilder;

    .line 31
    .line 32
    const-string v1, "Write to an invalid slot index "

    .line 33
    .line 34
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 35
    .line 36
    .line 37
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 38
    .line 39
    .line 40
    const-string p2, " for group "

    .line 41
    .line 42
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 43
    .line 44
    .line 45
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 46
    .line 47
    .line 48
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 49
    .line 50
    .line 51
    move-result-object p1

    .line 52
    invoke-static {p1}, Lqj;->a(Ljava/lang/String;)V

    .line 53
    .line 54
    .line 55
    :goto_36
    invoke-virtual {p0, v2}, La61;->h(I)I

    .line 56
    .line 57
    .line 58
    move-result p1

    .line 59
    iget-object p0, p0, La61;->c:[Ljava/lang/Object;

    .line 60
    .line 61
    aget-object p2, p0, p1

    .line 62
    .line 63
    aput-object p3, p0, p1

    .line 64
    .line 65
    return-object p2
.end method

.method public final L()I
    .registers 5

    .line 1
    iget v0, p0, La61;->t:I

    .line 2
    .line 3
    invoke-virtual {p0, v0}, La61;->r(I)I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    iget v1, p0, La61;->t:I

    .line 8
    .line 9
    iget-object v2, p0, La61;->b:[I

    .line 10
    .line 11
    mul-int/lit8 v0, v0, 0x5

    .line 12
    .line 13
    add-int/lit8 v3, v0, 0x3

    .line 14
    .line 15
    aget v3, v2, v3

    .line 16
    .line 17
    add-int/2addr v3, v1

    .line 18
    iput v3, p0, La61;->t:I

    .line 19
    .line 20
    invoke-virtual {p0, v3}, La61;->r(I)I

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    invoke-virtual {p0, v2, v1}, La61;->g([II)I

    .line 25
    .line 26
    .line 27
    move-result v1

    .line 28
    iput v1, p0, La61;->i:I

    .line 29
    .line 30
    iget-object p0, p0, La61;->b:[I

    .line 31
    .line 32
    const/4 v1, 0x1

    .line 33
    add-int/2addr v0, v1

    .line 34
    aget p0, p0, v0

    .line 35
    .line 36
    const/high16 v0, 0x40000000  # 2.0f

    .line 37
    .line 38
    and-int/2addr v0, p0

    .line 39
    if-eqz v0, :cond_29

    .line 40
    .line 41
    return v1

    .line 42
    :cond_29
    const v0, 0x3ffffff

    .line 43
    .line 44
    .line 45
    and-int/2addr p0, v0

    .line 46
    return p0
.end method

.method public final M()V
    .registers 3

    .line 1
    iget v0, p0, La61;->u:I

    .line 2
    .line 3
    iput v0, p0, La61;->t:I

    .line 4
    .line 5
    iget-object v1, p0, La61;->b:[I

    .line 6
    .line 7
    invoke-virtual {p0, v0}, La61;->r(I)I

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    invoke-virtual {p0, v1, v0}, La61;->g([II)I

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    iput v0, p0, La61;->i:I

    .line 16
    .line 17
    return-void
.end method

.method public final N([II)I
    .registers 4

    .line 1
    invoke-virtual {p0}, La61;->o()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-lt p2, v0, :cond_d

    .line 6
    .line 7
    iget-object p1, p0, La61;->c:[Ljava/lang/Object;

    .line 8
    .line 9
    array-length p1, p1

    .line 10
    iget p0, p0, La61;->l:I

    .line 11
    .line 12
    sub-int/2addr p1, p0

    .line 13
    return p1

    .line 14
    :cond_d
    invoke-static {p1, p2}, Lz51;->b([II)I

    .line 15
    .line 16
    .line 17
    move-result p1

    .line 18
    iget p2, p0, La61;->l:I

    .line 19
    .line 20
    iget-object p0, p0, La61;->c:[Ljava/lang/Object;

    .line 21
    .line 22
    array-length p0, p0

    .line 23
    if-gez p1, :cond_1d

    .line 24
    .line 25
    sub-int/2addr p0, p2

    .line 26
    add-int/2addr p0, p1

    .line 27
    add-int/lit8 p0, p0, 0x1

    .line 28
    .line 29
    return p0

    .line 30
    :cond_1d
    return p1
.end method

.method public final O(I)Lf10;
    .registers 4

    .line 1
    iget-object v0, p0, La61;->e:Ljava/util/HashMap;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_12

    .line 5
    .line 6
    invoke-virtual {p0, p1}, La61;->R(I)Ly00;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    if-eqz p0, :cond_12

    .line 11
    .line 12
    invoke-virtual {v0, p0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    check-cast p0, Lf10;

    .line 17
    .line 18
    return-object p0

    .line 19
    :cond_12
    return-object v1
.end method

.method public final P()V
    .registers 3

    .line 1
    iget v0, p0, La61;->n:I

    .line 2
    .line 3
    if-nez v0, :cond_5

    .line 4
    .line 5
    goto :goto_a

    .line 6
    :cond_5
    const-string v0, "Key must be supplied when inserting"

    .line 7
    .line 8
    invoke-static {v0}, Lqj;->a(Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    :goto_a
    sget-object v0, Loj;->a:Lnq0;

    .line 12
    .line 13
    const/4 v1, 0x0

    .line 14
    invoke-virtual {p0, v1, v0, v1, v0}, La61;->Q(ILjava/lang/Object;ZLjava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    return-void
.end method

.method public final Q(ILjava/lang/Object;ZLjava/lang/Object;)V
    .registers 16

    .line 1
    iget v0, p0, La61;->v:I

    .line 2
    .line 3
    iget v1, p0, La61;->n:I

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    const/4 v3, 0x1

    .line 7
    if-lez v1, :cond_a

    .line 8
    .line 9
    move v1, v3

    .line 10
    goto :goto_b

    .line 11
    :cond_a
    move v1, v2

    .line 12
    :goto_b
    iget-object v4, p0, La61;->r:Lw60;

    .line 13
    .line 14
    iget v5, p0, La61;->o:I

    .line 15
    .line 16
    invoke-virtual {v4, v5}, Lw60;->c(I)V

    .line 17
    .line 18
    .line 19
    sget-object v4, Loj;->a:Lnq0;

    .line 20
    .line 21
    if-eqz v1, :cond_a4

    .line 22
    .line 23
    iget v1, p0, La61;->t:I

    .line 24
    .line 25
    iget-object v5, p0, La61;->b:[I

    .line 26
    .line 27
    invoke-virtual {p0, v1}, La61;->r(I)I

    .line 28
    .line 29
    .line 30
    move-result v6

    .line 31
    invoke-virtual {p0, v5, v6}, La61;->g([II)I

    .line 32
    .line 33
    .line 34
    move-result v5

    .line 35
    invoke-virtual {p0, v3}, La61;->w(I)V

    .line 36
    .line 37
    .line 38
    iput v5, p0, La61;->i:I

    .line 39
    .line 40
    iput v5, p0, La61;->j:I

    .line 41
    .line 42
    invoke-virtual {p0, v1}, La61;->r(I)I

    .line 43
    .line 44
    .line 45
    move-result v6

    .line 46
    if-eq p2, v4, :cond_31

    .line 47
    .line 48
    move v7, v3

    .line 49
    goto :goto_32

    .line 50
    :cond_31
    move v7, v2

    .line 51
    :goto_32
    if-nez p3, :cond_38

    .line 52
    .line 53
    if-eq p4, v4, :cond_38

    .line 54
    .line 55
    move v4, v3

    .line 56
    goto :goto_39

    .line 57
    :cond_38
    move v4, v2

    .line 58
    :goto_39
    iget v8, p0, La61;->l:I

    .line 59
    .line 60
    iget v9, p0, La61;->k:I

    .line 61
    .line 62
    iget-object v10, p0, La61;->c:[Ljava/lang/Object;

    .line 63
    .line 64
    array-length v10, v10

    .line 65
    invoke-static {v5, v9, v8, v10}, La61;->i(IIII)I

    .line 66
    .line 67
    .line 68
    move-result v5

    .line 69
    if-ltz v5, :cond_53

    .line 70
    .line 71
    iget v8, p0, La61;->m:I

    .line 72
    .line 73
    if-ge v8, v1, :cond_53

    .line 74
    .line 75
    iget-object v8, p0, La61;->c:[Ljava/lang/Object;

    .line 76
    .line 77
    array-length v8, v8

    .line 78
    iget v9, p0, La61;->l:I

    .line 79
    .line 80
    sub-int/2addr v8, v9

    .line 81
    sub-int/2addr v8, v5

    .line 82
    add-int/2addr v8, v3

    .line 83
    neg-int v5, v8

    .line 84
    :cond_53
    iget-object v3, p0, La61;->b:[I

    .line 85
    .line 86
    iget v8, p0, La61;->v:I

    .line 87
    .line 88
    mul-int/lit8 v6, v6, 0x5

    .line 89
    .line 90
    aput p1, v3, v6

    .line 91
    .line 92
    add-int/lit8 p1, v6, 0x1

    .line 93
    .line 94
    shl-int/lit8 v9, p3, 0x1e

    .line 95
    .line 96
    shl-int/lit8 v10, v7, 0x1d

    .line 97
    .line 98
    or-int/2addr v9, v10

    .line 99
    shl-int/lit8 v10, v4, 0x1c

    .line 100
    .line 101
    or-int/2addr v9, v10

    .line 102
    aput v9, v3, p1

    .line 103
    .line 104
    add-int/lit8 p1, v6, 0x2

    .line 105
    .line 106
    aput v8, v3, p1

    .line 107
    .line 108
    add-int/lit8 p1, v6, 0x3

    .line 109
    .line 110
    aput v2, v3, p1

    .line 111
    .line 112
    add-int/lit8 v6, v6, 0x4

    .line 113
    .line 114
    aput v5, v3, v6

    .line 115
    .line 116
    add-int p1, p3, v7

    .line 117
    .line 118
    add-int/2addr p1, v4

    .line 119
    if-lez p1, :cond_96

    .line 120
    .line 121
    invoke-virtual {p0, p1, v1}, La61;->x(II)V

    .line 122
    .line 123
    .line 124
    iget-object p1, p0, La61;->c:[Ljava/lang/Object;

    .line 125
    .line 126
    iget v3, p0, La61;->i:I

    .line 127
    .line 128
    if-eqz p3, :cond_86

    .line 129
    .line 130
    add-int/lit8 p3, v3, 0x1

    .line 131
    .line 132
    aput-object p4, p1, v3

    .line 133
    .line 134
    move v3, p3

    .line 135
    :cond_86
    if-eqz v7, :cond_8d

    .line 136
    .line 137
    add-int/lit8 p3, v3, 0x1

    .line 138
    .line 139
    aput-object p2, p1, v3

    .line 140
    .line 141
    move v3, p3

    .line 142
    :cond_8d
    if-eqz v4, :cond_94

    .line 143
    .line 144
    add-int/lit8 p2, v3, 0x1

    .line 145
    .line 146
    aput-object p4, p1, v3

    .line 147
    .line 148
    move v3, p2

    .line 149
    :cond_94
    iput v3, p0, La61;->i:I

    .line 150
    .line 151
    :cond_96
    iput v2, p0, La61;->o:I

    .line 152
    .line 153
    add-int/lit8 p1, v1, 0x1

    .line 154
    .line 155
    iput v1, p0, La61;->v:I

    .line 156
    .line 157
    iput p1, p0, La61;->t:I

    .line 158
    .line 159
    if-ltz v0, :cond_ff

    .line 160
    .line 161
    invoke-virtual {p0, v0}, La61;->O(I)Lf10;

    .line 162
    .line 163
    .line 164
    goto :goto_ff

    .line 165
    :cond_a4
    iget-object p1, p0, La61;->p:Lw60;

    .line 166
    .line 167
    invoke-virtual {p1, v0}, Lw60;->c(I)V

    .line 168
    .line 169
    .line 170
    invoke-virtual {p0}, La61;->o()I

    .line 171
    .line 172
    .line 173
    move-result p1

    .line 174
    iget p2, p0, La61;->h:I

    .line 175
    .line 176
    sub-int/2addr p1, p2

    .line 177
    iget p2, p0, La61;->u:I

    .line 178
    .line 179
    sub-int/2addr p1, p2

    .line 180
    iget-object p2, p0, La61;->q:Lw60;

    .line 181
    .line 182
    invoke-virtual {p2, p1}, Lw60;->c(I)V

    .line 183
    .line 184
    .line 185
    iget p1, p0, La61;->t:I

    .line 186
    .line 187
    invoke-virtual {p0, p1}, La61;->r(I)I

    .line 188
    .line 189
    .line 190
    move-result p2

    .line 191
    invoke-static {p4, v4}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 192
    .line 193
    .line 194
    move-result v0

    .line 195
    if-nez v0, :cond_cf

    .line 196
    .line 197
    if-eqz p3, :cond_cc

    .line 198
    .line 199
    iget p3, p0, La61;->t:I

    .line 200
    .line 201
    invoke-virtual {p0, p3, p4}, La61;->U(ILjava/lang/Object;)V

    .line 202
    .line 203
    .line 204
    goto :goto_cf

    .line 205
    :cond_cc
    invoke-virtual {p0, p4}, La61;->S(Ljava/lang/Object;)V

    .line 206
    .line 207
    .line 208
    :cond_cf
    :goto_cf
    iget-object p3, p0, La61;->b:[I

    .line 209
    .line 210
    invoke-virtual {p0, p3, p2}, La61;->N([II)I

    .line 211
    .line 212
    .line 213
    move-result p3

    .line 214
    iput p3, p0, La61;->i:I

    .line 215
    .line 216
    iget-object p3, p0, La61;->b:[I

    .line 217
    .line 218
    iget p4, p0, La61;->t:I

    .line 219
    .line 220
    add-int/2addr p4, v3

    .line 221
    invoke-virtual {p0, p4}, La61;->r(I)I

    .line 222
    .line 223
    .line 224
    move-result p4

    .line 225
    invoke-virtual {p0, p3, p4}, La61;->g([II)I

    .line 226
    .line 227
    .line 228
    move-result p3

    .line 229
    iput p3, p0, La61;->j:I

    .line 230
    .line 231
    iget-object p3, p0, La61;->b:[I

    .line 232
    .line 233
    mul-int/lit8 p2, p2, 0x5

    .line 234
    .line 235
    add-int/lit8 p4, p2, 0x1

    .line 236
    .line 237
    aget p4, p3, p4

    .line 238
    .line 239
    const v0, 0x3ffffff

    .line 240
    .line 241
    .line 242
    and-int/2addr p4, v0

    .line 243
    iput p4, p0, La61;->o:I

    .line 244
    .line 245
    iput p1, p0, La61;->v:I

    .line 246
    .line 247
    add-int/lit8 p4, p1, 0x1

    .line 248
    .line 249
    iput p4, p0, La61;->t:I

    .line 250
    .line 251
    add-int/lit8 p2, p2, 0x3

    .line 252
    .line 253
    aget p2, p3, p2

    .line 254
    .line 255
    add-int/2addr p1, p2

    .line 256
    :cond_ff
    :goto_ff
    iput p1, p0, La61;->u:I

    .line 257
    .line 258
    return-void
.end method

.method public final R(I)Ly00;
    .registers 4

    .line 1
    const/4 v0, 0x0

    .line 2
    if-ltz p1, :cond_1c

    .line 3
    .line 4
    invoke-virtual {p0}, La61;->p()I

    .line 5
    .line 6
    .line 7
    move-result v1

    .line 8
    if-ge p1, v1, :cond_1c

    .line 9
    .line 10
    iget-object v1, p0, La61;->d:Ljava/util/ArrayList;

    .line 11
    .line 12
    invoke-virtual {p0}, La61;->p()I

    .line 13
    .line 14
    .line 15
    move-result p0

    .line 16
    invoke-static {v1, p1, p0}, Lz51;->e(Ljava/util/ArrayList;II)I

    .line 17
    .line 18
    .line 19
    move-result p0

    .line 20
    if-ltz p0, :cond_1c

    .line 21
    .line 22
    invoke-virtual {v1, p0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object p0

    .line 26
    check-cast p0, Ly00;

    .line 27
    .line 28
    return-object p0

    .line 29
    :cond_1c
    return-object v0
.end method

.method public final S(Ljava/lang/Object;)V
    .registers 6

    .line 1
    iget v0, p0, La61;->t:I

    .line 2
    .line 3
    invoke-virtual {p0, v0}, La61;->r(I)I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    iget-object v1, p0, La61;->b:[I

    .line 8
    .line 9
    mul-int/lit8 v2, v0, 0x5

    .line 10
    .line 11
    add-int/lit8 v2, v2, 0x1

    .line 12
    .line 13
    aget v1, v1, v2

    .line 14
    .line 15
    const/high16 v3, 0x10000000

    .line 16
    .line 17
    and-int/2addr v1, v3

    .line 18
    if-eqz v1, :cond_14

    .line 19
    .line 20
    goto :goto_19

    .line 21
    :cond_14
    const-string v1, "Updating the data of a group that was not created with a data slot"

    .line 22
    .line 23
    invoke-static {v1}, Lqj;->a(Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    :goto_19
    iget-object v1, p0, La61;->c:[Ljava/lang/Object;

    .line 27
    .line 28
    iget-object v3, p0, La61;->b:[I

    .line 29
    .line 30
    invoke-virtual {p0, v3, v0}, La61;->g([II)I

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    aget v2, v3, v2

    .line 35
    .line 36
    shr-int/lit8 v2, v2, 0x1d

    .line 37
    .line 38
    invoke-static {v2}, Ljava/lang/Integer;->bitCount(I)I

    .line 39
    .line 40
    .line 41
    move-result v2

    .line 42
    add-int/2addr v2, v0

    .line 43
    invoke-virtual {p0, v2}, La61;->h(I)I

    .line 44
    .line 45
    .line 46
    move-result p0

    .line 47
    aput-object p1, v1, p0

    .line 48
    .line 49
    return-void
.end method

.method public final T(I)V
    .registers 3

    .line 1
    if-ltz p1, :cond_10

    .line 2
    .line 3
    iget-object v0, p0, La61;->x:Lrj0;

    .line 4
    .line 5
    if-nez v0, :cond_d

    .line 6
    .line 7
    new-instance v0, Lrj0;

    .line 8
    .line 9
    invoke-direct {v0}, Lrj0;-><init>()V

    .line 10
    .line 11
    .line 12
    iput-object v0, p0, La61;->x:Lrj0;

    .line 13
    .line 14
    :cond_d
    invoke-static {v0, p1}, Ljb0;->d(Lrj0;I)V

    .line 15
    .line 16
    .line 17
    :cond_10
    return-void
.end method

.method public final U(ILjava/lang/Object;)V
    .registers 6

    .line 1
    invoke-virtual {p0, p1}, La61;->r(I)I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    iget-object v1, p0, La61;->b:[I

    .line 6
    .line 7
    array-length v2, v1

    .line 8
    if-ge v0, v2, :cond_15

    .line 9
    .line 10
    mul-int/lit8 v2, v0, 0x5

    .line 11
    .line 12
    add-int/lit8 v2, v2, 0x1

    .line 13
    .line 14
    aget v1, v1, v2

    .line 15
    .line 16
    const/high16 v2, 0x40000000  # 2.0f

    .line 17
    .line 18
    and-int/2addr v1, v2

    .line 19
    if-eqz v1, :cond_15

    .line 20
    .line 21
    goto :goto_2b

    .line 22
    :cond_15
    new-instance v1, Ljava/lang/StringBuilder;

    .line 23
    .line 24
    const-string v2, "Updating the node of a group at "

    .line 25
    .line 26
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 27
    .line 28
    .line 29
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 30
    .line 31
    .line 32
    const-string p1, " that was not created with as a node group"

    .line 33
    .line 34
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 35
    .line 36
    .line 37
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 38
    .line 39
    .line 40
    move-result-object p1

    .line 41
    invoke-static {p1}, Lqj;->a(Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    :goto_2b
    iget-object p1, p0, La61;->c:[Ljava/lang/Object;

    .line 45
    .line 46
    iget-object v1, p0, La61;->b:[I

    .line 47
    .line 48
    invoke-virtual {p0, v1, v0}, La61;->g([II)I

    .line 49
    .line 50
    .line 51
    move-result v0

    .line 52
    invoke-virtual {p0, v0}, La61;->h(I)I

    .line 53
    .line 54
    .line 55
    move-result p0

    .line 56
    aput-object p2, p1, p0

    .line 57
    .line 58
    return-void
.end method

.method public final a(I)V
    .registers 4

    .line 1
    if-ltz p1, :cond_3

    .line 2
    .line 3
    goto :goto_8

    .line 4
    :cond_3
    const-string v0, "Cannot seek backwards"

    .line 5
    .line 6
    invoke-static {v0}, Lqj;->a(Ljava/lang/String;)V

    .line 7
    .line 8
    .line 9
    :goto_8
    iget v0, p0, La61;->n:I

    .line 10
    .line 11
    if-gtz v0, :cond_d

    .line 12
    .line 13
    goto :goto_12

    .line 14
    :cond_d
    const-string v0, "Cannot call seek() while inserting"

    .line 15
    .line 16
    invoke-static {v0}, Lrt0;->b(Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    :goto_12
    if-nez p1, :cond_15

    .line 20
    .line 21
    return-void

    .line 22
    :cond_15
    iget v0, p0, La61;->t:I

    .line 23
    .line 24
    add-int/2addr v0, p1

    .line 25
    iget p1, p0, La61;->v:I

    .line 26
    .line 27
    if-lt v0, p1, :cond_21

    .line 28
    .line 29
    iget p1, p0, La61;->u:I

    .line 30
    .line 31
    if-gt v0, p1, :cond_21

    .line 32
    .line 33
    goto :goto_43

    .line 34
    :cond_21
    new-instance p1, Ljava/lang/StringBuilder;

    .line 35
    .line 36
    const-string v1, "Cannot seek outside the current group ("

    .line 37
    .line 38
    invoke-direct {p1, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    iget v1, p0, La61;->v:I

    .line 42
    .line 43
    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 44
    .line 45
    .line 46
    const/16 v1, 0x2d

    .line 47
    .line 48
    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 49
    .line 50
    .line 51
    iget v1, p0, La61;->u:I

    .line 52
    .line 53
    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 54
    .line 55
    .line 56
    const/16 v1, 0x29

    .line 57
    .line 58
    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 59
    .line 60
    .line 61
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 62
    .line 63
    .line 64
    move-result-object p1

    .line 65
    invoke-static {p1}, Lqj;->a(Ljava/lang/String;)V

    .line 66
    .line 67
    .line 68
    :goto_43
    iput v0, p0, La61;->t:I

    .line 69
    .line 70
    iget-object p1, p0, La61;->b:[I

    .line 71
    .line 72
    invoke-virtual {p0, v0}, La61;->r(I)I

    .line 73
    .line 74
    .line 75
    move-result v0

    .line 76
    invoke-virtual {p0, p1, v0}, La61;->g([II)I

    .line 77
    .line 78
    .line 79
    move-result p1

    .line 80
    iput p1, p0, La61;->i:I

    .line 81
    .line 82
    iput p1, p0, La61;->j:I

    .line 83
    .line 84
    return-void
.end method

.method public final b(I)Ly00;
    .registers 6

    .line 1
    iget-object v0, p0, La61;->d:Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-virtual {p0}, La61;->p()I

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    invoke-static {v0, p1, v1}, Lz51;->e(Ljava/util/ArrayList;II)I

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    if-gez v1, :cond_23

    .line 12
    .line 13
    new-instance v2, Ly00;

    .line 14
    .line 15
    iget v3, p0, La61;->g:I

    .line 16
    .line 17
    if-gt p1, v3, :cond_13

    .line 18
    .line 19
    goto :goto_19

    .line 20
    :cond_13
    invoke-virtual {p0}, La61;->p()I

    .line 21
    .line 22
    .line 23
    move-result p0

    .line 24
    sub-int/2addr p0, p1

    .line 25
    neg-int p1, p0

    .line 26
    :goto_19
    invoke-direct {v2, p1}, Ly00;-><init>(I)V

    .line 27
    .line 28
    .line 29
    add-int/lit8 v1, v1, 0x1

    .line 30
    .line 31
    neg-int p0, v1

    .line 32
    invoke-virtual {v0, p0, v2}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    return-object v2

    .line 36
    :cond_23
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object p0

    .line 40
    check-cast p0, Ly00;

    .line 41
    .line 42
    return-object p0
.end method

.method public final c(Ly00;)I
    .registers 2

    .line 1
    iget p1, p1, Ly00;->a:I

    .line 2
    .line 3
    if-gez p1, :cond_a

    .line 4
    .line 5
    invoke-virtual {p0}, La61;->p()I

    .line 6
    .line 7
    .line 8
    move-result p0

    .line 9
    add-int/2addr p0, p1

    .line 10
    return p0

    .line 11
    :cond_a
    return p1
.end method

.method public final d()V
    .registers 3

    .line 1
    iget v0, p0, La61;->n:I

    .line 2
    .line 3
    add-int/lit8 v1, v0, 0x1

    .line 4
    .line 5
    iput v1, p0, La61;->n:I

    .line 6
    .line 7
    if-nez v0, :cond_17

    .line 8
    .line 9
    invoke-virtual {p0}, La61;->o()I

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    iget v1, p0, La61;->h:I

    .line 14
    .line 15
    sub-int/2addr v0, v1

    .line 16
    iget v1, p0, La61;->u:I

    .line 17
    .line 18
    sub-int/2addr v0, v1

    .line 19
    iget-object p0, p0, La61;->q:Lw60;

    .line 20
    .line 21
    invoke-virtual {p0, v0}, Lw60;->c(I)V

    .line 22
    .line 23
    .line 24
    :cond_17
    return-void
.end method

.method public final e(Z)V
    .registers 9

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, La61;->w:Z

    .line 3
    .line 4
    if-eqz p1, :cond_2b

    .line 5
    .line 6
    iget-object p1, p0, La61;->p:Lw60;

    .line 7
    .line 8
    iget p1, p1, Lw60;->b:I

    .line 9
    .line 10
    if-nez p1, :cond_2b

    .line 11
    .line 12
    invoke-virtual {p0}, La61;->p()I

    .line 13
    .line 14
    .line 15
    move-result p1

    .line 16
    invoke-virtual {p0, p1}, La61;->B(I)V

    .line 17
    .line 18
    .line 19
    iget-object p1, p0, La61;->c:[Ljava/lang/Object;

    .line 20
    .line 21
    array-length p1, p1

    .line 22
    iget v0, p0, La61;->l:I

    .line 23
    .line 24
    sub-int/2addr p1, v0

    .line 25
    iget v0, p0, La61;->g:I

    .line 26
    .line 27
    invoke-virtual {p0, p1, v0}, La61;->C(II)V

    .line 28
    .line 29
    .line 30
    iget p1, p0, La61;->k:I

    .line 31
    .line 32
    iget v0, p0, La61;->l:I

    .line 33
    .line 34
    add-int/2addr v0, p1

    .line 35
    iget-object v1, p0, La61;->c:[Ljava/lang/Object;

    .line 36
    .line 37
    const/4 v2, 0x0

    .line 38
    invoke-static {v1, p1, v0, v2}, Ljava/util/Arrays;->fill([Ljava/lang/Object;IILjava/lang/Object;)V

    .line 39
    .line 40
    .line 41
    invoke-virtual {p0}, La61;->G()V

    .line 42
    .line 43
    .line 44
    :cond_2b
    iget-object p1, p0, La61;->b:[I

    .line 45
    .line 46
    iget v0, p0, La61;->g:I

    .line 47
    .line 48
    iget-object v1, p0, La61;->c:[Ljava/lang/Object;

    .line 49
    .line 50
    iget v2, p0, La61;->k:I

    .line 51
    .line 52
    iget-object v3, p0, La61;->d:Ljava/util/ArrayList;

    .line 53
    .line 54
    iget-object v4, p0, La61;->e:Ljava/util/HashMap;

    .line 55
    .line 56
    iget-object v5, p0, La61;->f:Lsj0;

    .line 57
    .line 58
    iget-object p0, p0, La61;->a:Lx51;

    .line 59
    .line 60
    iget-boolean v6, p0, Lx51;->k:Z

    .line 61
    .line 62
    if-eqz v6, :cond_40

    .line 63
    .line 64
    goto :goto_45

    .line 65
    :cond_40
    const-string v6, "Unexpected writer close()"

    .line 66
    .line 67
    invoke-static {v6}, Lrt0;->a(Ljava/lang/String;)V

    .line 68
    .line 69
    .line 70
    :goto_45
    const/4 v6, 0x0

    .line 71
    iput-boolean v6, p0, Lx51;->k:Z

    .line 72
    .line 73
    iput-object p1, p0, Lx51;->e:[I

    .line 74
    .line 75
    iput v0, p0, Lx51;->f:I

    .line 76
    .line 77
    iput-object v1, p0, Lx51;->g:[Ljava/lang/Object;

    .line 78
    .line 79
    iput v2, p0, Lx51;->h:I

    .line 80
    .line 81
    iput-object v3, p0, Lx51;->m:Ljava/util/ArrayList;

    .line 82
    .line 83
    iput-object v4, p0, Lx51;->n:Ljava/util/HashMap;

    .line 84
    .line 85
    iput-object v5, p0, Lx51;->o:Lsj0;

    .line 86
    .line 87
    return-void
.end method

.method public final f(I)I
    .registers 3

    .line 1
    iget-object v0, p0, La61;->b:[I

    .line 2
    .line 3
    invoke-virtual {p0, p1}, La61;->r(I)I

    .line 4
    .line 5
    .line 6
    move-result p1

    .line 7
    invoke-virtual {p0, v0, p1}, La61;->g([II)I

    .line 8
    .line 9
    .line 10
    move-result p0

    .line 11
    return p0
.end method

.method public final g([II)I
    .registers 4

    .line 1
    invoke-virtual {p0}, La61;->o()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-lt p2, v0, :cond_d

    .line 6
    .line 7
    iget-object p1, p0, La61;->c:[Ljava/lang/Object;

    .line 8
    .line 9
    array-length p1, p1

    .line 10
    iget p0, p0, La61;->l:I

    .line 11
    .line 12
    sub-int/2addr p1, p0

    .line 13
    return p1

    .line 14
    :cond_d
    mul-int/lit8 p2, p2, 0x5

    .line 15
    .line 16
    add-int/lit8 p2, p2, 0x4

    .line 17
    .line 18
    aget p1, p1, p2

    .line 19
    .line 20
    iget p2, p0, La61;->l:I

    .line 21
    .line 22
    iget-object p0, p0, La61;->c:[Ljava/lang/Object;

    .line 23
    .line 24
    array-length p0, p0

    .line 25
    if-gez p1, :cond_1f

    .line 26
    .line 27
    sub-int/2addr p0, p2

    .line 28
    add-int/2addr p0, p1

    .line 29
    add-int/lit8 p0, p0, 0x1

    .line 30
    .line 31
    return p0

    .line 32
    :cond_1f
    return p1
.end method

.method public final h(I)I
    .registers 3

    .line 1
    iget v0, p0, La61;->l:I

    .line 2
    .line 3
    iget p0, p0, La61;->k:I

    .line 4
    .line 5
    if-ge p1, p0, :cond_8

    .line 6
    .line 7
    const/4 p0, 0x0

    .line 8
    goto :goto_9

    .line 9
    :cond_8
    const/4 p0, 0x1

    .line 10
    :goto_9
    mul-int/2addr v0, p0

    .line 11
    add-int/2addr v0, p1

    .line 12
    return v0
.end method

.method public final j()V
    .registers 15

    .line 1
    iget v0, p0, La61;->n:I

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x1

    .line 5
    if-lez v0, :cond_8

    .line 6
    .line 7
    move v0, v2

    .line 8
    goto :goto_9

    .line 9
    :cond_8
    move v0, v1

    .line 10
    :goto_9
    iget v3, p0, La61;->t:I

    .line 11
    .line 12
    iget v4, p0, La61;->u:I

    .line 13
    .line 14
    iget v5, p0, La61;->v:I

    .line 15
    .line 16
    invoke-virtual {p0, v5}, La61;->r(I)I

    .line 17
    .line 18
    .line 19
    move-result v6

    .line 20
    iget v7, p0, La61;->o:I

    .line 21
    .line 22
    sub-int v8, v3, v5

    .line 23
    .line 24
    iget-object v9, p0, La61;->b:[I

    .line 25
    .line 26
    mul-int/lit8 v10, v6, 0x5

    .line 27
    .line 28
    add-int/lit8 v11, v10, 0x1

    .line 29
    .line 30
    aget v9, v9, v11

    .line 31
    .line 32
    const/high16 v12, 0x40000000  # 2.0f

    .line 33
    .line 34
    and-int/2addr v9, v12

    .line 35
    if-eqz v9, :cond_26

    .line 36
    .line 37
    move v9, v2

    .line 38
    goto :goto_27

    .line 39
    :cond_26
    move v9, v1

    .line 40
    :goto_27
    iget-object v13, p0, La61;->r:Lw60;

    .line 41
    .line 42
    if-eqz v0, :cond_81

    .line 43
    .line 44
    iget-object v0, p0, La61;->s:Lsj0;

    .line 45
    .line 46
    if-eqz v0, :cond_4c

    .line 47
    .line 48
    invoke-virtual {v0, v5}, Ll60;->b(I)Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    move-result-object v3

    .line 52
    check-cast v3, Lak0;

    .line 53
    .line 54
    if-eqz v3, :cond_4c

    .line 55
    .line 56
    iget-object v4, v3, Lak0;->a:[Ljava/lang/Object;

    .line 57
    .line 58
    iget v3, v3, Lak0;->b:I

    .line 59
    .line 60
    move v11, v1

    .line 61
    :goto_3c
    if-ge v11, v3, :cond_46

    .line 62
    .line 63
    aget-object v12, v4, v11

    .line 64
    .line 65
    invoke-virtual {p0, v12}, La61;->F(Ljava/lang/Object;)Ljava/lang/Object;

    .line 66
    .line 67
    .line 68
    add-int/lit8 v11, v11, 0x1

    .line 69
    .line 70
    goto :goto_3c

    .line 71
    :cond_46
    invoke-virtual {v0, v5}, Lsj0;->g(I)Ljava/lang/Object;

    .line 72
    .line 73
    .line 74
    move-result-object v0

    .line 75
    check-cast v0, Lak0;

    .line 76
    .line 77
    :cond_4c
    iget-object v0, p0, La61;->b:[I

    .line 78
    .line 79
    add-int/lit8 v10, v10, 0x3

    .line 80
    .line 81
    aput v8, v0, v10

    .line 82
    .line 83
    invoke-static {v0, v6, v7}, Lz51;->c([III)V

    .line 84
    .line 85
    .line 86
    invoke-virtual {v13}, Lw60;->b()I

    .line 87
    .line 88
    .line 89
    move-result v0

    .line 90
    if-eqz v9, :cond_5c

    .line 91
    .line 92
    move v7, v2

    .line 93
    :cond_5c
    add-int/2addr v0, v7

    .line 94
    iput v0, p0, La61;->o:I

    .line 95
    .line 96
    iget-object v0, p0, La61;->b:[I

    .line 97
    .line 98
    invoke-virtual {p0, v0, v5}, La61;->E([II)I

    .line 99
    .line 100
    .line 101
    move-result v0

    .line 102
    iput v0, p0, La61;->v:I

    .line 103
    .line 104
    if-gez v0, :cond_6e

    .line 105
    .line 106
    invoke-virtual {p0}, La61;->p()I

    .line 107
    .line 108
    .line 109
    move-result v0

    .line 110
    goto :goto_73

    .line 111
    :cond_6e
    add-int/2addr v0, v2

    .line 112
    invoke-virtual {p0, v0}, La61;->r(I)I

    .line 113
    .line 114
    .line 115
    move-result v0

    .line 116
    :goto_73
    if-gez v0, :cond_76

    .line 117
    .line 118
    goto :goto_7c

    .line 119
    :cond_76
    iget-object v1, p0, La61;->b:[I

    .line 120
    .line 121
    invoke-virtual {p0, v1, v0}, La61;->g([II)I

    .line 122
    .line 123
    .line 124
    move-result v1

    .line 125
    :goto_7c
    iput v1, p0, La61;->i:I

    .line 126
    .line 127
    iput v1, p0, La61;->j:I

    .line 128
    .line 129
    return-void

    .line 130
    :cond_81
    if-ne v3, v4, :cond_84

    .line 131
    .line 132
    goto :goto_89

    .line 133
    :cond_84
    const-string v0, "Expected to be at the end of a group"

    .line 134
    .line 135
    invoke-static {v0}, Lqj;->a(Ljava/lang/String;)V

    .line 136
    .line 137
    .line 138
    :goto_89
    iget-object v0, p0, La61;->b:[I

    .line 139
    .line 140
    add-int/lit8 v10, v10, 0x3

    .line 141
    .line 142
    aget v3, v0, v10

    .line 143
    .line 144
    aget v4, v0, v11

    .line 145
    .line 146
    const v11, 0x3ffffff

    .line 147
    .line 148
    .line 149
    and-int/2addr v4, v11

    .line 150
    aput v8, v0, v10

    .line 151
    .line 152
    invoke-static {v0, v6, v7}, Lz51;->c([III)V

    .line 153
    .line 154
    .line 155
    iget-object v0, p0, La61;->p:Lw60;

    .line 156
    .line 157
    invoke-virtual {v0}, Lw60;->b()I

    .line 158
    .line 159
    .line 160
    move-result v0

    .line 161
    invoke-virtual {p0}, La61;->o()I

    .line 162
    .line 163
    .line 164
    move-result v6

    .line 165
    iget v10, p0, La61;->h:I

    .line 166
    .line 167
    sub-int/2addr v6, v10

    .line 168
    iget-object v10, p0, La61;->q:Lw60;

    .line 169
    .line 170
    invoke-virtual {v10}, Lw60;->b()I

    .line 171
    .line 172
    .line 173
    move-result v10

    .line 174
    sub-int/2addr v6, v10

    .line 175
    iput v6, p0, La61;->u:I

    .line 176
    .line 177
    iput v0, p0, La61;->v:I

    .line 178
    .line 179
    iget-object v6, p0, La61;->b:[I

    .line 180
    .line 181
    invoke-virtual {p0, v6, v5}, La61;->E([II)I

    .line 182
    .line 183
    .line 184
    move-result v5

    .line 185
    invoke-virtual {v13}, Lw60;->b()I

    .line 186
    .line 187
    .line 188
    move-result v6

    .line 189
    iput v6, p0, La61;->o:I

    .line 190
    .line 191
    if-ne v5, v0, :cond_c9

    .line 192
    .line 193
    if-eqz v9, :cond_c3

    .line 194
    .line 195
    goto :goto_c5

    .line 196
    :cond_c3
    sub-int v1, v7, v4

    .line 197
    .line 198
    :goto_c5
    add-int/2addr v6, v1

    .line 199
    iput v6, p0, La61;->o:I

    .line 200
    .line 201
    return-void

    .line 202
    :cond_c9
    sub-int/2addr v8, v3

    .line 203
    if-eqz v9, :cond_ce

    .line 204
    .line 205
    move v7, v1

    .line 206
    goto :goto_cf

    .line 207
    :cond_ce
    sub-int/2addr v7, v4

    .line 208
    :goto_cf
    if-nez v8, :cond_d3

    .line 209
    .line 210
    if-eqz v7, :cond_10a

    .line 211
    .line 212
    :cond_d3
    :goto_d3
    if-eqz v5, :cond_10a

    .line 213
    .line 214
    if-eq v5, v0, :cond_10a

    .line 215
    .line 216
    if-nez v7, :cond_db

    .line 217
    .line 218
    if-eqz v8, :cond_10a

    .line 219
    .line 220
    :cond_db
    invoke-virtual {p0, v5}, La61;->r(I)I

    .line 221
    .line 222
    .line 223
    move-result v3

    .line 224
    if-eqz v8, :cond_ec

    .line 225
    .line 226
    iget-object v4, p0, La61;->b:[I

    .line 227
    .line 228
    mul-int/lit8 v6, v3, 0x5

    .line 229
    .line 230
    add-int/lit8 v6, v6, 0x3

    .line 231
    .line 232
    aget v9, v4, v6

    .line 233
    .line 234
    add-int/2addr v9, v8

    .line 235
    aput v9, v4, v6

    .line 236
    .line 237
    :cond_ec
    if-eqz v7, :cond_fa

    .line 238
    .line 239
    iget-object v4, p0, La61;->b:[I

    .line 240
    .line 241
    mul-int/lit8 v6, v3, 0x5

    .line 242
    .line 243
    add-int/2addr v6, v2

    .line 244
    aget v6, v4, v6

    .line 245
    .line 246
    and-int/2addr v6, v11

    .line 247
    add-int/2addr v6, v7

    .line 248
    invoke-static {v4, v3, v6}, Lz51;->c([III)V

    .line 249
    .line 250
    .line 251
    :cond_fa
    iget-object v4, p0, La61;->b:[I

    .line 252
    .line 253
    mul-int/lit8 v3, v3, 0x5

    .line 254
    .line 255
    add-int/2addr v3, v2

    .line 256
    aget v3, v4, v3

    .line 257
    .line 258
    and-int/2addr v3, v12

    .line 259
    if-eqz v3, :cond_105

    .line 260
    .line 261
    move v7, v1

    .line 262
    :cond_105
    invoke-virtual {p0, v4, v5}, La61;->E([II)I

    .line 263
    .line 264
    .line 265
    move-result v5

    .line 266
    goto :goto_d3

    .line 267
    :cond_10a
    iget v0, p0, La61;->o:I

    .line 268
    .line 269
    add-int/2addr v0, v7

    .line 270
    iput v0, p0, La61;->o:I

    .line 271
    .line 272
    return-void
.end method

.method public final k()V
    .registers 3

    .line 1
    iget v0, p0, La61;->n:I

    .line 2
    .line 3
    if-lez v0, :cond_5

    .line 4
    .line 5
    goto :goto_a

    .line 6
    :cond_5
    const-string v0, "Unbalanced begin/end insert"

    .line 7
    .line 8
    invoke-static {v0}, Lrt0;->b(Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    :goto_a
    iget v0, p0, La61;->n:I

    .line 12
    .line 13
    add-int/lit8 v0, v0, -0x1

    .line 14
    .line 15
    iput v0, p0, La61;->n:I

    .line 16
    .line 17
    if-nez v0, :cond_32

    .line 18
    .line 19
    iget-object v0, p0, La61;->r:Lw60;

    .line 20
    .line 21
    iget v0, v0, Lw60;->b:I

    .line 22
    .line 23
    iget-object v1, p0, La61;->p:Lw60;

    .line 24
    .line 25
    iget v1, v1, Lw60;->b:I

    .line 26
    .line 27
    if-ne v0, v1, :cond_1d

    .line 28
    .line 29
    goto :goto_22

    .line 30
    :cond_1d
    const-string v0, "startGroup/endGroup mismatch while inserting"

    .line 31
    .line 32
    invoke-static {v0}, Lqj;->a(Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    :goto_22
    invoke-virtual {p0}, La61;->o()I

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    iget v1, p0, La61;->h:I

    .line 40
    .line 41
    sub-int/2addr v0, v1

    .line 42
    iget-object v1, p0, La61;->q:Lw60;

    .line 43
    .line 44
    invoke-virtual {v1}, Lw60;->b()I

    .line 45
    .line 46
    .line 47
    move-result v1

    .line 48
    sub-int/2addr v0, v1

    .line 49
    iput v0, p0, La61;->u:I

    .line 50
    .line 51
    :cond_32
    return-void
.end method

.method public final l(I)V
    .registers 6

    .line 1
    iget v0, p0, La61;->n:I

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x1

    .line 5
    if-gtz v0, :cond_8

    .line 6
    .line 7
    move v0, v2

    .line 8
    goto :goto_9

    .line 9
    :cond_8
    move v0, v1

    .line 10
    :goto_9
    if-nez v0, :cond_10

    .line 11
    .line 12
    const-string v0, "Cannot call ensureStarted() while inserting"

    .line 13
    .line 14
    invoke-static {v0}, Lqj;->a(Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    :cond_10
    iget v0, p0, La61;->v:I

    .line 18
    .line 19
    if-eq v0, p1, :cond_47

    .line 20
    .line 21
    if-lt p1, v0, :cond_1b

    .line 22
    .line 23
    iget v3, p0, La61;->u:I

    .line 24
    .line 25
    if-ge p1, v3, :cond_1b

    .line 26
    .line 27
    move v1, v2

    .line 28
    :cond_1b
    if-nez v1, :cond_36

    .line 29
    .line 30
    new-instance v1, Ljava/lang/StringBuilder;

    .line 31
    .line 32
    const-string v2, "Started group at "

    .line 33
    .line 34
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 35
    .line 36
    .line 37
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 38
    .line 39
    .line 40
    const-string v2, " must be a subgroup of the group at "

    .line 41
    .line 42
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 43
    .line 44
    .line 45
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 46
    .line 47
    .line 48
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    invoke-static {v0}, Lqj;->a(Ljava/lang/String;)V

    .line 53
    .line 54
    .line 55
    :cond_36
    iget v0, p0, La61;->t:I

    .line 56
    .line 57
    iget v1, p0, La61;->i:I

    .line 58
    .line 59
    iget v2, p0, La61;->j:I

    .line 60
    .line 61
    iput p1, p0, La61;->t:I

    .line 62
    .line 63
    invoke-virtual {p0}, La61;->P()V

    .line 64
    .line 65
    .line 66
    iput v0, p0, La61;->t:I

    .line 67
    .line 68
    iput v1, p0, La61;->i:I

    .line 69
    .line 70
    iput v2, p0, La61;->j:I

    .line 71
    .line 72
    :cond_47
    return-void
.end method

.method public final m(III)V
    .registers 6

    .line 1
    iget v0, p0, La61;->g:I

    .line 2
    .line 3
    if-ge p1, v0, :cond_5

    .line 4
    .line 5
    goto :goto_d

    .line 6
    :cond_5
    invoke-virtual {p0}, La61;->p()I

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    sub-int/2addr v0, p1

    .line 11
    add-int/lit8 v0, v0, 0x2

    .line 12
    .line 13
    neg-int p1, v0

    .line 14
    :goto_d
    if-ge p3, p2, :cond_2f

    .line 15
    .line 16
    iget-object v0, p0, La61;->b:[I

    .line 17
    .line 18
    invoke-virtual {p0, p3}, La61;->r(I)I

    .line 19
    .line 20
    .line 21
    move-result v1

    .line 22
    mul-int/lit8 v1, v1, 0x5

    .line 23
    .line 24
    add-int/lit8 v1, v1, 0x2

    .line 25
    .line 26
    aput p1, v0, v1

    .line 27
    .line 28
    iget-object v0, p0, La61;->b:[I

    .line 29
    .line 30
    invoke-virtual {p0, p3}, La61;->r(I)I

    .line 31
    .line 32
    .line 33
    move-result v1

    .line 34
    mul-int/lit8 v1, v1, 0x5

    .line 35
    .line 36
    add-int/lit8 v1, v1, 0x3

    .line 37
    .line 38
    aget v0, v0, v1

    .line 39
    .line 40
    add-int/2addr v0, p3

    .line 41
    add-int/lit8 v1, p3, 0x1

    .line 42
    .line 43
    invoke-virtual {p0, p3, v0, v1}, La61;->m(III)V

    .line 44
    .line 45
    .line 46
    move p3, v0

    .line 47
    goto :goto_d

    .line 48
    :cond_2f
    return-void
.end method

.method public final n(ILm00;)V
    .registers 22

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move/from16 v1, p1

    .line 4
    .line 5
    move-object/from16 v2, p2

    .line 6
    .line 7
    iget-object v3, v0, La61;->b:[I

    .line 8
    .line 9
    invoke-virtual {v0, v3, v1}, La61;->E([II)I

    .line 10
    .line 11
    .line 12
    move-result v3

    .line 13
    invoke-virtual {v0}, La61;->p()I

    .line 14
    .line 15
    .line 16
    move-result v4

    .line 17
    invoke-virtual/range {p0 .. p1}, La61;->u(I)I

    .line 18
    .line 19
    .line 20
    move-result v5

    .line 21
    add-int/2addr v5, v1

    .line 22
    const/4 v6, 0x0

    .line 23
    move v8, v1

    .line 24
    move-object v7, v6

    .line 25
    :goto_18
    if-ge v8, v5, :cond_13a

    .line 26
    .line 27
    invoke-virtual {v0, v8}, La61;->f(I)I

    .line 28
    .line 29
    .line 30
    move-result v9

    .line 31
    add-int/lit8 v10, v8, 0x1

    .line 32
    .line 33
    invoke-virtual {v0, v10}, La61;->f(I)I

    .line 34
    .line 35
    .line 36
    move-result v11

    .line 37
    :goto_24
    if-ge v9, v11, :cond_92

    .line 38
    .line 39
    invoke-virtual {v0, v9}, La61;->h(I)I

    .line 40
    .line 41
    .line 42
    move-result v13

    .line 43
    iget-object v14, v0, La61;->c:[Ljava/lang/Object;

    .line 44
    .line 45
    aget-object v13, v14, v13

    .line 46
    .line 47
    instance-of v14, v13, Lxw0;

    .line 48
    .line 49
    if-eqz v14, :cond_84

    .line 50
    .line 51
    move-object v14, v13

    .line 52
    check-cast v14, Lxw0;

    .line 53
    .line 54
    iget v14, v14, Lxw0;->b:I

    .line 55
    .line 56
    if-ltz v14, :cond_84

    .line 57
    .line 58
    invoke-virtual {v0, v8}, La61;->u(I)I

    .line 59
    .line 60
    .line 61
    move-result v13

    .line 62
    add-int/2addr v13, v8

    .line 63
    move v15, v10

    .line 64
    const/4 v12, 0x0

    .line 65
    :goto_40
    if-ge v15, v13, :cond_66

    .line 66
    .line 67
    if-ge v12, v14, :cond_66

    .line 68
    .line 69
    invoke-virtual {v0, v15}, La61;->r(I)I

    .line 70
    .line 71
    .line 72
    move-result v16

    .line 73
    move/from16 v17, v3

    .line 74
    .line 75
    iget-object v3, v0, La61;->b:[I

    .line 76
    .line 77
    mul-int/lit8 v16, v16, 0x5

    .line 78
    .line 79
    add-int/lit8 v18, v16, 0x3

    .line 80
    .line 81
    aget v18, v3, v18

    .line 82
    .line 83
    add-int v15, v18, v15

    .line 84
    .line 85
    if-ge v15, v13, :cond_63

    .line 86
    .line 87
    add-int/lit8 v16, v16, 0x1

    .line 88
    .line 89
    aget v3, v3, v16

    .line 90
    .line 91
    const/high16 v16, 0x20000000

    .line 92
    .line 93
    and-int v3, v3, v16

    .line 94
    .line 95
    if-eqz v3, :cond_61

    .line 96
    .line 97
    goto :goto_63

    .line 98
    :cond_61
    add-int/lit8 v12, v12, 0x1

    .line 99
    .line 100
    :cond_63
    :goto_63
    move/from16 v3, v17

    .line 101
    .line 102
    goto :goto_40

    .line 103
    :cond_66
    move/from16 v17, v3

    .line 104
    .line 105
    if-nez v6, :cond_72

    .line 106
    .line 107
    sget-object v3, Lu60;->a:[I

    .line 108
    .line 109
    new-instance v3, Ltj0;

    .line 110
    .line 111
    invoke-direct {v3}, Ltj0;-><init>()V

    .line 112
    .line 113
    .line 114
    move-object v6, v3

    .line 115
    :cond_72
    if-nez v7, :cond_7a

    .line 116
    .line 117
    new-instance v3, Lrj0;

    .line 118
    .line 119
    invoke-direct {v3}, Lrj0;-><init>()V

    .line 120
    .line 121
    .line 122
    move-object v7, v3

    .line 123
    :cond_7a
    invoke-virtual {v6, v15}, Ltj0;->a(I)Z

    .line 124
    .line 125
    .line 126
    invoke-virtual {v7, v15}, Lrj0;->a(I)V

    .line 127
    .line 128
    .line 129
    invoke-virtual {v7, v9}, Lrj0;->a(I)V

    .line 130
    .line 131
    .line 132
    goto :goto_8d

    .line 133
    :cond_84
    move/from16 v17, v3

    .line 134
    .line 135
    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 136
    .line 137
    .line 138
    move-result-object v3

    .line 139
    invoke-interface {v2, v3, v13}, Lm00;->f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 140
    .line 141
    .line 142
    :goto_8d
    add-int/lit8 v9, v9, 0x1

    .line 143
    .line 144
    move/from16 v3, v17

    .line 145
    .line 146
    goto :goto_24

    .line 147
    :cond_92
    move/from16 v17, v3

    .line 148
    .line 149
    if-ge v10, v4, :cond_9d

    .line 150
    .line 151
    iget-object v3, v0, La61;->b:[I

    .line 152
    .line 153
    invoke-virtual {v0, v3, v10}, La61;->E([II)I

    .line 154
    .line 155
    .line 156
    move-result v3

    .line 157
    goto :goto_9e

    .line 158
    :cond_9d
    const/4 v3, -0x1

    .line 159
    :goto_9e
    if-eq v3, v8, :cond_131

    .line 160
    .line 161
    move v9, v8

    .line 162
    move/from16 v8, v17

    .line 163
    .line 164
    :goto_a3
    if-eqz v7, :cond_11d

    .line 165
    .line 166
    if-eqz v6, :cond_11d

    .line 167
    .line 168
    invoke-virtual {v6, v9}, Ltj0;->e(I)Z

    .line 169
    .line 170
    .line 171
    move-result v11

    .line 172
    if-eqz v11, :cond_11d

    .line 173
    .line 174
    iget v11, v7, Lrj0;->b:I

    .line 175
    .line 176
    div-int/lit8 v13, v11, 0x2

    .line 177
    .line 178
    const/4 v14, 0x0

    .line 179
    const/4 v15, 0x0

    .line 180
    :goto_b3
    if-ge v14, v13, :cond_f1

    .line 181
    .line 182
    mul-int/lit8 v12, v14, 0x2

    .line 183
    .line 184
    move/from16 v17, v4

    .line 185
    .line 186
    invoke-virtual {v7, v12}, Lrj0;->b(I)I

    .line 187
    .line 188
    .line 189
    move-result v4

    .line 190
    if-ne v4, v9, :cond_d5

    .line 191
    .line 192
    add-int/lit8 v12, v12, 0x1

    .line 193
    .line 194
    invoke-virtual {v7, v12}, Lrj0;->b(I)I

    .line 195
    .line 196
    .line 197
    move-result v4

    .line 198
    iget-object v12, v0, La61;->c:[Ljava/lang/Object;

    .line 199
    .line 200
    invoke-virtual {v0, v4}, La61;->h(I)I

    .line 201
    .line 202
    .line 203
    move-result v18

    .line 204
    aget-object v12, v12, v18

    .line 205
    .line 206
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 207
    .line 208
    .line 209
    move-result-object v4

    .line 210
    invoke-interface {v2, v4, v12}, Lm00;->f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 211
    .line 212
    .line 213
    goto :goto_ea

    .line 214
    :cond_d5
    if-eq v12, v15, :cond_e8

    .line 215
    .line 216
    add-int/lit8 v2, v15, 0x1

    .line 217
    .line 218
    invoke-virtual {v7, v15, v4}, Lrj0;->e(II)V

    .line 219
    .line 220
    .line 221
    add-int/lit8 v15, v15, 0x2

    .line 222
    .line 223
    add-int/lit8 v12, v12, 0x1

    .line 224
    .line 225
    invoke-virtual {v7, v12}, Lrj0;->b(I)I

    .line 226
    .line 227
    .line 228
    move-result v4

    .line 229
    invoke-virtual {v7, v2, v4}, Lrj0;->e(II)V

    .line 230
    .line 231
    .line 232
    goto :goto_ea

    .line 233
    :cond_e8
    add-int/lit8 v15, v15, 0x2

    .line 234
    .line 235
    :goto_ea
    add-int/lit8 v14, v14, 0x1

    .line 236
    .line 237
    move-object/from16 v2, p2

    .line 238
    .line 239
    move/from16 v4, v17

    .line 240
    .line 241
    goto :goto_b3

    .line 242
    :cond_f1
    move/from16 v17, v4

    .line 243
    .line 244
    if-eq v15, v11, :cond_11f

    .line 245
    .line 246
    if-ltz v15, :cond_117

    .line 247
    .line 248
    iget v2, v7, Lrj0;->b:I

    .line 249
    .line 250
    if-gt v15, v2, :cond_117

    .line 251
    .line 252
    if-ltz v11, :cond_117

    .line 253
    .line 254
    if-gt v11, v2, :cond_117

    .line 255
    .line 256
    if-lt v11, v15, :cond_111

    .line 257
    .line 258
    if-eq v11, v15, :cond_11f

    .line 259
    .line 260
    if-ge v11, v2, :cond_10a

    .line 261
    .line 262
    iget-object v4, v7, Lrj0;->a:[I

    .line 263
    .line 264
    invoke-static {v4, v4, v15, v11, v2}, Lba;->W([I[IIII)V

    .line 265
    .line 266
    .line 267
    :cond_10a
    iget v2, v7, Lrj0;->b:I

    .line 268
    .line 269
    sub-int/2addr v11, v15

    .line 270
    sub-int/2addr v2, v11

    .line 271
    iput v2, v7, Lrj0;->b:I

    .line 272
    .line 273
    goto :goto_11f

    .line 274
    :cond_111
    const-string v0, "The end index must be < start index"

    .line 275
    .line 276
    invoke-static {v0}, Lod;->m(Ljava/lang/String;)V

    .line 277
    .line 278
    .line 279
    return-void

    .line 280
    :cond_117
    const-string v0, "Index must be between 0 and size"

    .line 281
    .line 282
    invoke-static {v0}, Lod;->f(Ljava/lang/String;)V

    .line 283
    .line 284
    .line 285
    return-void

    .line 286
    :cond_11d
    move/from16 v17, v4

    .line 287
    .line 288
    :cond_11f
    :goto_11f
    if-eq v9, v1, :cond_133

    .line 289
    .line 290
    if-eq v8, v3, :cond_133

    .line 291
    .line 292
    iget-object v2, v0, La61;->b:[I

    .line 293
    .line 294
    invoke-virtual {v0, v2, v8}, La61;->E([II)I

    .line 295
    .line 296
    .line 297
    move-result v2

    .line 298
    move v9, v8

    .line 299
    move/from16 v4, v17

    .line 300
    .line 301
    move v8, v2

    .line 302
    move-object/from16 v2, p2

    .line 303
    .line 304
    goto/16 :goto_a3

    .line 305
    .line 306
    :cond_131
    move/from16 v17, v4

    .line 307
    .line 308
    :cond_133
    move-object/from16 v2, p2

    .line 309
    .line 310
    move v8, v10

    .line 311
    move/from16 v4, v17

    .line 312
    .line 313
    goto/16 :goto_18

    .line 314
    .line 315
    :cond_13a
    return-void
.end method

.method public final o()I
    .registers 1

    .line 1
    iget-object p0, p0, La61;->b:[I

    .line 2
    .line 3
    array-length p0, p0

    .line 4
    div-int/lit8 p0, p0, 0x5

    .line 5
    .line 6
    return p0
.end method

.method public final p()I
    .registers 2

    .line 1
    invoke-virtual {p0}, La61;->o()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    iget p0, p0, La61;->h:I

    .line 6
    .line 7
    sub-int/2addr v0, p0

    .line 8
    return v0
.end method

.method public final q(I)Ljava/lang/Object;
    .registers 6

    .line 1
    invoke-virtual {p0, p1}, La61;->r(I)I

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    iget-object v0, p0, La61;->b:[I

    .line 6
    .line 7
    mul-int/lit8 v1, p1, 0x5

    .line 8
    .line 9
    add-int/lit8 v1, v1, 0x1

    .line 10
    .line 11
    aget v2, v0, v1

    .line 12
    .line 13
    const/high16 v3, 0x10000000

    .line 14
    .line 15
    and-int/2addr v2, v3

    .line 16
    if-eqz v2, :cond_23

    .line 17
    .line 18
    iget-object v2, p0, La61;->c:[Ljava/lang/Object;

    .line 19
    .line 20
    invoke-virtual {p0, v0, p1}, La61;->g([II)I

    .line 21
    .line 22
    .line 23
    move-result p0

    .line 24
    aget p1, v0, v1

    .line 25
    .line 26
    shr-int/lit8 p1, p1, 0x1d

    .line 27
    .line 28
    invoke-static {p1}, Ljava/lang/Integer;->bitCount(I)I

    .line 29
    .line 30
    .line 31
    move-result p1

    .line 32
    add-int/2addr p1, p0

    .line 33
    aget-object p0, v2, p1

    .line 34
    .line 35
    return-object p0

    .line 36
    :cond_23
    sget-object p0, Loj;->a:Lnq0;

    .line 37
    .line 38
    return-object p0
.end method

.method public final r(I)I
    .registers 3

    .line 1
    iget v0, p0, La61;->h:I

    .line 2
    .line 3
    iget p0, p0, La61;->g:I

    .line 4
    .line 5
    if-ge p1, p0, :cond_8

    .line 6
    .line 7
    const/4 p0, 0x0

    .line 8
    goto :goto_9

    .line 9
    :cond_8
    const/4 p0, 0x1

    .line 10
    :goto_9
    mul-int/2addr v0, p0

    .line 11
    add-int/2addr v0, p1

    .line 12
    return v0
.end method

.method public final s(I)I
    .registers 3

    .line 1
    iget-object v0, p0, La61;->b:[I

    .line 2
    .line 3
    invoke-virtual {p0, p1}, La61;->r(I)I

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    mul-int/lit8 p0, p0, 0x5

    .line 8
    .line 9
    aget p0, v0, p0

    .line 10
    .line 11
    return p0
.end method

.method public final t(I)Ljava/lang/Object;
    .registers 5

    .line 1
    invoke-virtual {p0, p1}, La61;->r(I)I

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    iget-object v0, p0, La61;->b:[I

    .line 6
    .line 7
    mul-int/lit8 p1, p1, 0x5

    .line 8
    .line 9
    add-int/lit8 v1, p1, 0x1

    .line 10
    .line 11
    aget v1, v0, v1

    .line 12
    .line 13
    const/high16 v2, 0x20000000

    .line 14
    .line 15
    and-int/2addr v2, v1

    .line 16
    if-eqz v2, :cond_21

    .line 17
    .line 18
    iget-object p0, p0, La61;->c:[Ljava/lang/Object;

    .line 19
    .line 20
    add-int/lit8 p1, p1, 0x4

    .line 21
    .line 22
    aget p1, v0, p1

    .line 23
    .line 24
    shr-int/lit8 v0, v1, 0x1e

    .line 25
    .line 26
    invoke-static {v0}, Ljava/lang/Integer;->bitCount(I)I

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    add-int/2addr v0, p1

    .line 31
    aget-object p0, p0, v0

    .line 32
    .line 33
    return-object p0

    .line 34
    :cond_21
    const/4 p0, 0x0

    .line 35
    return-object p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-string v1, "SlotWriter(current = "

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    iget v1, p0, La61;->t:I

    .line 9
    .line 10
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 11
    .line 12
    .line 13
    const-string v1, " end="

    .line 14
    .line 15
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 16
    .line 17
    .line 18
    iget v1, p0, La61;->u:I

    .line 19
    .line 20
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 21
    .line 22
    .line 23
    const-string v1, " size = "

    .line 24
    .line 25
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 26
    .line 27
    .line 28
    invoke-virtual {p0}, La61;->p()I

    .line 29
    .line 30
    .line 31
    move-result v1

    .line 32
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 33
    .line 34
    .line 35
    const-string v1, " gap="

    .line 36
    .line 37
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 38
    .line 39
    .line 40
    iget v1, p0, La61;->g:I

    .line 41
    .line 42
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 43
    .line 44
    .line 45
    const/16 v1, 0x2d

    .line 46
    .line 47
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 48
    .line 49
    .line 50
    iget v1, p0, La61;->g:I

    .line 51
    .line 52
    iget p0, p0, La61;->h:I

    .line 53
    .line 54
    add-int/2addr v1, p0

    .line 55
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 56
    .line 57
    .line 58
    const/16 p0, 0x29

    .line 59
    .line 60
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 61
    .line 62
    .line 63
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 64
    .line 65
    .line 66
    move-result-object p0

    .line 67
    return-object p0
.end method

.method public final u(I)I
    .registers 3

    .line 1
    iget-object v0, p0, La61;->b:[I

    .line 2
    .line 3
    invoke-virtual {p0, p1}, La61;->r(I)I

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    mul-int/lit8 p0, p0, 0x5

    .line 8
    .line 9
    add-int/lit8 p0, p0, 0x3

    .line 10
    .line 11
    aget p0, v0, p0

    .line 12
    .line 13
    return p0
.end method

.method public final v(II)Z
    .registers 8

    .line 1
    iget v0, p0, La61;->v:I

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-ne p2, v0, :cond_8

    .line 5
    .line 6
    iget p0, p0, La61;->u:I

    .line 7
    .line 8
    goto :goto_41

    .line 9
    :cond_8
    iget-object v0, p0, La61;->p:Lw60;

    .line 10
    .line 11
    invoke-virtual {v0, v1}, Lw60;->a(I)I

    .line 12
    .line 13
    .line 14
    move-result v2

    .line 15
    if-le p2, v2, :cond_16

    .line 16
    .line 17
    invoke-virtual {p0, p2}, La61;->u(I)I

    .line 18
    .line 19
    .line 20
    move-result p0

    .line 21
    :goto_14
    add-int/2addr p0, p2

    .line 22
    goto :goto_41

    .line 23
    :cond_16
    iget-object v2, v0, Lw60;->a:[I

    .line 24
    .line 25
    array-length v3, v2

    .line 26
    iget v0, v0, Lw60;->b:I

    .line 27
    .line 28
    invoke-static {v3, v0}, Ljava/lang/Math;->min(II)I

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    move v3, v1

    .line 33
    :goto_20
    if-ge v3, v0, :cond_2a

    .line 34
    .line 35
    aget v4, v2, v3

    .line 36
    .line 37
    if-ne v4, p2, :cond_27

    .line 38
    .line 39
    goto :goto_2b

    .line 40
    :cond_27
    add-int/lit8 v3, v3, 0x1

    .line 41
    .line 42
    goto :goto_20

    .line 43
    :cond_2a
    const/4 v3, -0x1

    .line 44
    :goto_2b
    if-gez v3, :cond_32

    .line 45
    .line 46
    invoke-virtual {p0, p2}, La61;->u(I)I

    .line 47
    .line 48
    .line 49
    move-result p0

    .line 50
    goto :goto_14

    .line 51
    :cond_32
    invoke-virtual {p0}, La61;->o()I

    .line 52
    .line 53
    .line 54
    move-result v0

    .line 55
    iget v2, p0, La61;->h:I

    .line 56
    .line 57
    sub-int/2addr v0, v2

    .line 58
    iget-object p0, p0, La61;->q:Lw60;

    .line 59
    .line 60
    iget-object p0, p0, Lw60;->a:[I

    .line 61
    .line 62
    aget p0, p0, v3

    .line 63
    .line 64
    sub-int p0, v0, p0

    .line 65
    .line 66
    :goto_41
    if-le p1, p2, :cond_47

    .line 67
    .line 68
    if-ge p1, p0, :cond_47

    .line 69
    .line 70
    const/4 p0, 0x1

    .line 71
    return p0

    .line 72
    :cond_47
    return v1
.end method

.method public final w(I)V
    .registers 13

    .line 1
    if-lez p1, :cond_78

    .line 2
    .line 3
    iget v0, p0, La61;->t:I

    .line 4
    .line 5
    invoke-virtual {p0, v0}, La61;->B(I)V

    .line 6
    .line 7
    .line 8
    iget v1, p0, La61;->g:I

    .line 9
    .line 10
    iget v2, p0, La61;->h:I

    .line 11
    .line 12
    iget-object v3, p0, La61;->b:[I

    .line 13
    .line 14
    array-length v4, v3

    .line 15
    div-int/lit8 v4, v4, 0x5

    .line 16
    .line 17
    sub-int v5, v4, v2

    .line 18
    .line 19
    const/4 v6, 0x0

    .line 20
    if-ge v2, p1, :cond_3c

    .line 21
    .line 22
    mul-int/lit8 v7, v4, 0x2

    .line 23
    .line 24
    add-int v8, v5, p1

    .line 25
    .line 26
    invoke-static {v7, v8}, Ljava/lang/Math;->max(II)I

    .line 27
    .line 28
    .line 29
    move-result v7

    .line 30
    const/16 v8, 0x20

    .line 31
    .line 32
    invoke-static {v7, v8}, Ljava/lang/Math;->max(II)I

    .line 33
    .line 34
    .line 35
    move-result v7

    .line 36
    mul-int/lit8 v8, v7, 0x5

    .line 37
    .line 38
    new-array v8, v8, [I

    .line 39
    .line 40
    sub-int/2addr v7, v5

    .line 41
    add-int/2addr v2, v1

    .line 42
    add-int v9, v1, v7

    .line 43
    .line 44
    mul-int/lit8 v10, v1, 0x5

    .line 45
    .line 46
    invoke-static {v3, v8, v6, v6, v10}, Lba;->W([I[IIII)V

    .line 47
    .line 48
    .line 49
    mul-int/lit8 v9, v9, 0x5

    .line 50
    .line 51
    mul-int/lit8 v2, v2, 0x5

    .line 52
    .line 53
    mul-int/lit8 v4, v4, 0x5

    .line 54
    .line 55
    invoke-static {v3, v8, v9, v2, v4}, Lba;->W([I[IIII)V

    .line 56
    .line 57
    .line 58
    iput-object v8, p0, La61;->b:[I

    .line 59
    .line 60
    move v2, v7

    .line 61
    :cond_3c
    iget v3, p0, La61;->u:I

    .line 62
    .line 63
    if-lt v3, v1, :cond_43

    .line 64
    .line 65
    add-int/2addr v3, p1

    .line 66
    iput v3, p0, La61;->u:I

    .line 67
    .line 68
    :cond_43
    add-int v3, v1, p1

    .line 69
    .line 70
    iput v3, p0, La61;->g:I

    .line 71
    .line 72
    sub-int/2addr v2, p1

    .line 73
    iput v2, p0, La61;->h:I

    .line 74
    .line 75
    if-lez v5, :cond_52

    .line 76
    .line 77
    add-int/2addr v0, p1

    .line 78
    invoke-virtual {p0, v0}, La61;->f(I)I

    .line 79
    .line 80
    .line 81
    move-result v0

    .line 82
    goto :goto_53

    .line 83
    :cond_52
    move v0, v6

    .line 84
    :goto_53
    iget v2, p0, La61;->m:I

    .line 85
    .line 86
    if-ge v2, v1, :cond_58

    .line 87
    .line 88
    goto :goto_5a

    .line 89
    :cond_58
    iget v6, p0, La61;->k:I

    .line 90
    .line 91
    :goto_5a
    iget v2, p0, La61;->l:I

    .line 92
    .line 93
    iget-object v4, p0, La61;->c:[Ljava/lang/Object;

    .line 94
    .line 95
    array-length v4, v4

    .line 96
    invoke-static {v0, v6, v2, v4}, La61;->i(IIII)I

    .line 97
    .line 98
    .line 99
    move-result v0

    .line 100
    move v2, v1

    .line 101
    :goto_64
    if-ge v2, v3, :cond_71

    .line 102
    .line 103
    iget-object v4, p0, La61;->b:[I

    .line 104
    .line 105
    mul-int/lit8 v5, v2, 0x5

    .line 106
    .line 107
    add-int/lit8 v5, v5, 0x4

    .line 108
    .line 109
    aput v0, v4, v5

    .line 110
    .line 111
    add-int/lit8 v2, v2, 0x1

    .line 112
    .line 113
    goto :goto_64

    .line 114
    :cond_71
    iget v0, p0, La61;->m:I

    .line 115
    .line 116
    if-lt v0, v1, :cond_78

    .line 117
    .line 118
    add-int/2addr v0, p1

    .line 119
    iput v0, p0, La61;->m:I

    .line 120
    .line 121
    :cond_78
    return-void
.end method

.method public final x(II)V
    .registers 12

    .line 1
    if-lez p1, :cond_47

    .line 2
    .line 3
    iget v0, p0, La61;->i:I

    .line 4
    .line 5
    invoke-virtual {p0, v0, p2}, La61;->C(II)V

    .line 6
    .line 7
    .line 8
    iget p2, p0, La61;->k:I

    .line 9
    .line 10
    iget v0, p0, La61;->l:I

    .line 11
    .line 12
    if-ge v0, p1, :cond_3a

    .line 13
    .line 14
    iget-object v1, p0, La61;->c:[Ljava/lang/Object;

    .line 15
    .line 16
    array-length v2, v1

    .line 17
    sub-int v3, v2, v0

    .line 18
    .line 19
    mul-int/lit8 v4, v2, 0x2

    .line 20
    .line 21
    add-int v5, v3, p1

    .line 22
    .line 23
    invoke-static {v4, v5}, Ljava/lang/Math;->max(II)I

    .line 24
    .line 25
    .line 26
    move-result v4

    .line 27
    const/16 v5, 0x20

    .line 28
    .line 29
    invoke-static {v4, v5}, Ljava/lang/Math;->max(II)I

    .line 30
    .line 31
    .line 32
    move-result v4

    .line 33
    new-array v5, v4, [Ljava/lang/Object;

    .line 34
    .line 35
    const/4 v6, 0x0

    .line 36
    move v7, v6

    .line 37
    :goto_24
    if-ge v7, v4, :cond_2c

    .line 38
    .line 39
    const/4 v8, 0x0

    .line 40
    aput-object v8, v5, v7

    .line 41
    .line 42
    add-int/lit8 v7, v7, 0x1

    .line 43
    .line 44
    goto :goto_24

    .line 45
    :cond_2c
    sub-int/2addr v4, v3

    .line 46
    add-int/2addr v0, p2

    .line 47
    add-int v3, p2, v4

    .line 48
    .line 49
    invoke-static {v1, v6, v5, v6, p2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 50
    .line 51
    .line 52
    sub-int/2addr v2, v0

    .line 53
    invoke-static {v1, v0, v5, v3, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 54
    .line 55
    .line 56
    iput-object v5, p0, La61;->c:[Ljava/lang/Object;

    .line 57
    .line 58
    move v0, v4

    .line 59
    :cond_3a
    iget v1, p0, La61;->j:I

    .line 60
    .line 61
    if-lt v1, p2, :cond_41

    .line 62
    .line 63
    add-int/2addr v1, p1

    .line 64
    iput v1, p0, La61;->j:I

    .line 65
    .line 66
    :cond_41
    add-int/2addr p2, p1

    .line 67
    iput p2, p0, La61;->k:I

    .line 68
    .line 69
    sub-int/2addr v0, p1

    .line 70
    iput v0, p0, La61;->l:I

    .line 71
    .line 72
    :cond_47
    return-void
.end method

.method public final y(I)Z
    .registers 3

    .line 1
    iget-object v0, p0, La61;->b:[I

    .line 2
    .line 3
    invoke-virtual {p0, p1}, La61;->r(I)I

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    mul-int/lit8 p0, p0, 0x5

    .line 8
    .line 9
    const/4 p1, 0x1

    .line 10
    add-int/2addr p0, p1

    .line 11
    aget p0, v0, p0

    .line 12
    .line 13
    const/high16 v0, 0x40000000  # 2.0f

    .line 14
    .line 15
    and-int/2addr p0, v0

    .line 16
    if-eqz p0, :cond_12

    .line 17
    .line 18
    return p1

    .line 19
    :cond_12
    const/4 p0, 0x0

    .line 20
    return p0
.end method
