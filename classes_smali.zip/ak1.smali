.class public Lak1;
.super Lzj1;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# direct methods
.method public constructor <init>(Lhk1;Lak1;)V
    .registers 3

    .line 5
    invoke-direct {p0, p1, p2}, Lzj1;-><init>(Lhk1;Lzj1;)V

    return-void
.end method

.method public constructor <init>(Lhk1;Landroid/view/WindowInsets;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1, p2}, Lzj1;-><init>(Lhk1;Landroid/view/WindowInsets;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method
