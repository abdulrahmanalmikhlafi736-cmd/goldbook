.class public interface abstract Lcg1;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# virtual methods
.method public abstract a()Z
.end method

.method public abstract f(JLu8;Lu8;Lu8;)Lu8;
.end method

.method public abstract i(JLu8;Lu8;Lu8;)Lu8;
.end method

.method public abstract j(Lu8;Lu8;Lu8;)Lu8;
.end method

.method public abstract k(Lu8;Lu8;Lu8;)J
.end method
