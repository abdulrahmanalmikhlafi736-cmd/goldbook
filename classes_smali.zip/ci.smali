.class public final synthetic Lci;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lqd0;


# instance fields
.field public final synthetic e:I

.field public final synthetic f:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    .line 1
    iput p1, p0, Lci;->e:I

    .line 2
    .line 3
    iput-object p2, p0, Lci;->f:Ljava/lang/Object;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final h(Lsd0;Lid0;)V
    .registers 4

    .line 1
    iget p1, p0, Lci;->e:I

    .line 2
    .line 3
    iget-object p0, p0, Lci;->f:Ljava/lang/Object;

    .line 4
    .line 5
    packed-switch p1, :pswitch_data_80

    .line 6
    .line 7
    .line 8
    check-cast p0, Lwz0;

    .line 9
    .line 10
    sget-object p1, Lid0;->ON_START:Lid0;

    .line 11
    .line 12
    if-ne p2, p1, :cond_11

    .line 13
    .line 14
    const/4 p1, 0x1

    .line 15
    iput-boolean p1, p0, Lwz0;->h:Z

    .line 16
    .line 17
    goto :goto_18

    .line 18
    :cond_11
    sget-object p1, Lid0;->ON_STOP:Lid0;

    .line 19
    .line 20
    if-ne p2, p1, :cond_18

    .line 21
    .line 22
    const/4 p1, 0x0

    .line 23
    iput-boolean p1, p0, Lwz0;->h:Z

    .line 24
    .line 25
    :cond_18
    :goto_18
    return-void

    .line 26
    :pswitch_19  #0x1
    check-cast p0, Lcom/almekhlafi/goldbook/MainActivity;

    .line 27
    .line 28
    sget-object p1, Lid0;->ON_DESTROY:Lid0;

    .line 29
    .line 30
    if-ne p2, p1, :cond_69

    .line 31
    .line 32
    iget-object p1, p0, Lki;->f:Lkl;

    .line 33
    .line 34
    const/4 p2, 0x0

    .line 35
    iput-object p2, p1, Lkl;->b:Lki;

    .line 36
    .line 37
    invoke-virtual {p0}, Landroid/app/Activity;->isChangingConfigurations()Z

    .line 38
    .line 39
    .line 40
    move-result p1

    .line 41
    if-nez p1, :cond_4b

    .line 42
    .line 43
    invoke-virtual {p0}, Lki;->f()Ljg0;

    .line 44
    .line 45
    .line 46
    move-result-object p1

    .line 47
    iget-object p1, p1, Ljg0;->a:Ljava/util/LinkedHashMap;

    .line 48
    .line 49
    invoke-virtual {p1}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    .line 50
    .line 51
    .line 52
    move-result-object p2

    .line 53
    invoke-interface {p2}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    .line 54
    .line 55
    .line 56
    move-result-object p2

    .line 57
    :goto_38
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    .line 58
    .line 59
    .line 60
    move-result v0

    .line 61
    if-eqz v0, :cond_48

    .line 62
    .line 63
    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    check-cast v0, Lfh1;

    .line 68
    .line 69
    invoke-virtual {v0}, Lfh1;->b()V

    .line 70
    .line 71
    .line 72
    goto :goto_38

    .line 73
    :cond_48
    invoke-virtual {p1}, Ljava/util/LinkedHashMap;->clear()V

    .line 74
    .line 75
    .line 76
    :cond_4b
    iget-object p0, p0, Lki;->j:Lgi;

    .line 77
    .line 78
    iget-object p1, p0, Lgi;->h:Lcom/almekhlafi/goldbook/MainActivity;

    .line 79
    .line 80
    invoke-virtual {p1}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 81
    .line 82
    .line 83
    move-result-object p2

    .line 84
    invoke-virtual {p2}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 85
    .line 86
    .line 87
    move-result-object p2

    .line 88
    invoke-virtual {p2, p0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 89
    .line 90
    .line 91
    invoke-virtual {p1}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 92
    .line 93
    .line 94
    move-result-object p1

    .line 95
    invoke-virtual {p1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 96
    .line 97
    .line 98
    move-result-object p1

    .line 99
    invoke-virtual {p1}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    .line 100
    .line 101
    .line 102
    move-result-object p1

    .line 103
    invoke-virtual {p1, p0}, Landroid/view/ViewTreeObserver;->removeOnDrawListener(Landroid/view/ViewTreeObserver$OnDrawListener;)V

    .line 104
    .line 105
    .line 106
    :cond_69
    return-void

    .line 107
    :pswitch_6a  #0x0
    check-cast p0, Lcom/almekhlafi/goldbook/MainActivity;

    .line 108
    .line 109
    sget-object p1, Lid0;->ON_STOP:Lid0;

    .line 110
    .line 111
    if-ne p2, p1, :cond_7f

    .line 112
    .line 113
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 114
    .line 115
    .line 116
    move-result-object p0

    .line 117
    if-eqz p0, :cond_7f

    .line 118
    .line 119
    invoke-virtual {p0}, Landroid/view/Window;->peekDecorView()Landroid/view/View;

    .line 120
    .line 121
    .line 122
    move-result-object p0

    .line 123
    if-eqz p0, :cond_7f

    .line 124
    .line 125
    invoke-virtual {p0}, Landroid/view/View;->cancelPendingInputEvents()V

    .line 126
    .line 127
    .line 128
    :cond_7f
    return-void

    .line 129
    :pswitch_data_80
    .packed-switch 0x0
        :pswitch_6a  #00000000
        :pswitch_19  #00000001
    .end packed-switch
.end method
