.class public abstract Laz0;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# static fields
.field public static final a:Ln00;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    sget-object v0, Lzy0;->l:Lzy0;

    .line 2
    .line 3
    const/4 v1, 0x3

    .line 4
    invoke-static {v1, v0}, Lvd1;->e(ILjava/lang/Object;)V

    .line 5
    .line 6
    .line 7
    sput-object v0, Laz0;->a:Ln00;

    .line 8
    .line 9
    return-void
.end method
