.class public final Lbo;
.super Lli0;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lds;


# instance fields
.field public final s:Luj0;

.field public t:Z

.field public u:Z

.field public v:Z


# direct methods
.method public constructor <init>(Luj0;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Lli0;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lbo;->s:Luj0;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final C(Lda0;)V
    .registers 9

    .line 1
    invoke-virtual {p1}, Lda0;->c()V

    .line 2
    .line 3
    .line 4
    iget-object v2, p1, Lda0;->e:Lte;

    .line 5
    .line 6
    iget-boolean v3, p0, Lbo;->t:Z

    .line 7
    .line 8
    if-eqz v3, :cond_21

    .line 9
    .line 10
    sget-wide v3, Lzg;->b:J

    .line 11
    .line 12
    const v0, 0x3e99999a

    .line 13
    .line 14
    .line 15
    invoke-static {v3, v4, v0}, Lzg;->b(JF)J

    .line 16
    .line 17
    .line 18
    move-result-wide v3

    .line 19
    iget-object v0, v2, Lte;->f:Lk9;

    .line 20
    .line 21
    invoke-virtual {v0}, Lk9;->t()J

    .line 22
    .line 23
    .line 24
    move-result-wide v5

    .line 25
    move-wide v1, v3

    .line 26
    move-wide v3, v5

    .line 27
    const/16 v5, 0x7a

    .line 28
    .line 29
    move-object v0, p1

    .line 30
    invoke-static/range {v0 .. v5}, Lfu0;->x(Les;JJI)V

    .line 31
    .line 32
    .line 33
    return-void

    .line 34
    :cond_21
    iget-boolean v1, p0, Lbo;->u:Z

    .line 35
    .line 36
    if-nez v1, :cond_2b

    .line 37
    .line 38
    iget-boolean v0, p0, Lbo;->v:Z

    .line 39
    .line 40
    if-eqz v0, :cond_2a

    .line 41
    .line 42
    goto :goto_2b

    .line 43
    :cond_2a
    return-void

    .line 44
    :cond_2b
    :goto_2b
    sget-wide v0, Lzg;->b:J

    .line 45
    .line 46
    const v3, 0x3dcccccd

    .line 47
    .line 48
    .line 49
    invoke-static {v0, v1, v3}, Lzg;->b(JF)J

    .line 50
    .line 51
    .line 52
    move-result-wide v0

    .line 53
    iget-object v2, v2, Lte;->f:Lk9;

    .line 54
    .line 55
    invoke-virtual {v2}, Lk9;->t()J

    .line 56
    .line 57
    .line 58
    move-result-wide v3

    .line 59
    const/16 v5, 0x7a

    .line 60
    .line 61
    move-wide v1, v0

    .line 62
    move-object v0, p1

    .line 63
    invoke-static/range {v0 .. v5}, Lfu0;->x(Les;JJI)V

    .line 64
    .line 65
    .line 66
    return-void
.end method

.method public final synthetic Z()V
    .registers 1

    .line 1
    return-void
.end method

.method public final h0()V
    .registers 5

    .line 1
    invoke-virtual {p0}, Lli0;->d0()Lbm;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    new-instance v1, Lao;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    const/4 v3, 0x0

    .line 9
    invoke-direct {v1, p0, v3, v2}, Lao;-><init>(Ljava/lang/Object;Lml;I)V

    .line 10
    .line 11
    .line 12
    const/4 p0, 0x3

    .line 13
    invoke-static {v0, v3, v1, p0}, Lwl1;->B(Lbm;Lsl;Lm00;I)Ls71;

    .line 14
    .line 15
    .line 16
    return-void
.end method
