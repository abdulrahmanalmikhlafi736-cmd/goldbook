.class public final Ldn0;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Landroid/window/OnBackAnimationCallback;


# instance fields
.field public final synthetic a:Lbn0;


# direct methods
.method public constructor <init>(Lbn0;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Ldn0;->a:Lbn0;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onBackCancelled()V
    .registers 6

    .line 1
    iget-object p0, p0, Ldn0;->a:Lbn0;

    .line 2
    .line 3
    iget-object v0, p0, Lhl0;->a:Lp3;

    .line 4
    .line 5
    if-eqz v0, :cond_44

    .line 6
    .line 7
    iget-boolean v1, p0, Lhl0;->b:Z

    .line 8
    .line 9
    const/4 v2, 0x0

    .line 10
    if-nez v1, :cond_e

    .line 11
    .line 12
    invoke-virtual {v0, p0, v2}, Lp3;->g(Lhl0;Ldl0;)V

    .line 13
    .line 14
    .line 15
    :cond_e
    iget-object v0, v0, Lp3;->f:Ljava/lang/Object;

    .line 16
    .line 17
    check-cast v0, Lil0;

    .line 18
    .line 19
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 20
    .line 21
    .line 22
    iget-object v1, v0, Lil0;->h:Lhl0;

    .line 23
    .line 24
    invoke-virtual {p0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v1

    .line 28
    const/4 v3, 0x0

    .line 29
    if-eqz v1, :cond_41

    .line 30
    .line 31
    iget v1, v0, Lil0;->g:I

    .line 32
    .line 33
    const/4 v4, -0x1

    .line 34
    if-eq v4, v1, :cond_24

    .line 35
    .line 36
    goto :goto_41

    .line 37
    :cond_24
    iget-object v1, v0, Lil0;->f:Lfl0;

    .line 38
    .line 39
    if-nez v1, :cond_2c

    .line 40
    .line 41
    invoke-virtual {v0, v4}, Lil0;->c(I)Lfl0;

    .line 42
    .line 43
    .line 44
    move-result-object v1

    .line 45
    :cond_2c
    iput-object v2, v0, Lil0;->f:Lfl0;

    .line 46
    .line 47
    iput v3, v0, Lil0;->g:I

    .line 48
    .line 49
    iput-object v2, v0, Lil0;->h:Lhl0;

    .line 50
    .line 51
    if-eqz v1, :cond_37

    .line 52
    .line 53
    invoke-virtual {v1}, Lfl0;->a()V

    .line 54
    .line 55
    .line 56
    :cond_37
    iget-object v0, v0, Lil0;->a:Ld81;

    .line 57
    .line 58
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 59
    .line 60
    .line 61
    sget-object v1, Ljl0;->b:Ljl0;

    .line 62
    .line 63
    invoke-virtual {v0, v2, v1}, Ld81;->i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 64
    .line 65
    .line 66
    :cond_41
    :goto_41
    iput-boolean v3, p0, Lhl0;->b:Z

    .line 67
    .line 68
    return-void

    .line 69
    :cond_44
    const-string p0, "This input is not added to any dispatcher."

    .line 70
    .line 71
    invoke-static {p0}, Lod;->p(Ljava/lang/String;)V

    .line 72
    .line 73
    .line 74
    return-void
.end method

.method public final onBackInvoked()V
    .registers 1

    .line 1
    iget-object p0, p0, Ldn0;->a:Lbn0;

    .line 2
    .line 3
    invoke-virtual {p0}, Lhl0;->a()V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final onBackProgressed(Landroid/window/BackEvent;)V
    .registers 4

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-static {p1}, Ljb0;->a(Landroid/window/BackEvent;)Ldl0;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    iget-object p0, p0, Ldn0;->a:Lbn0;

    .line 9
    .line 10
    iget-object v0, p0, Lhl0;->a:Lp3;

    .line 11
    .line 12
    if-eqz v0, :cond_42

    .line 13
    .line 14
    iget-boolean v1, p0, Lhl0;->b:Z

    .line 15
    .line 16
    if-eqz v1, :cond_41

    .line 17
    .line 18
    iget-object v0, v0, Lp3;->f:Ljava/lang/Object;

    .line 19
    .line 20
    check-cast v0, Lil0;

    .line 21
    .line 22
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 23
    .line 24
    .line 25
    iget-object v1, v0, Lil0;->h:Lhl0;

    .line 26
    .line 27
    invoke-virtual {p0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 28
    .line 29
    .line 30
    move-result p0

    .line 31
    if-eqz p0, :cond_41

    .line 32
    .line 33
    iget p0, v0, Lil0;->g:I

    .line 34
    .line 35
    const/4 v1, -0x1

    .line 36
    if-eq v1, p0, :cond_26

    .line 37
    .line 38
    goto :goto_41

    .line 39
    :cond_26
    iget-object p0, v0, Lil0;->f:Lfl0;

    .line 40
    .line 41
    if-nez p0, :cond_2e

    .line 42
    .line 43
    invoke-virtual {v0, v1}, Lil0;->c(I)Lfl0;

    .line 44
    .line 45
    .line 46
    move-result-object p0

    .line 47
    :cond_2e
    if-eqz p0, :cond_33

    .line 48
    .line 49
    invoke-virtual {p0, p1}, Lfl0;->c(Ldl0;)V

    .line 50
    .line 51
    .line 52
    :cond_33
    iget-object p0, v0, Lil0;->a:Ld81;

    .line 53
    .line 54
    new-instance v0, Lkl0;

    .line 55
    .line 56
    invoke-direct {v0, p1}, Lkl0;-><init>(Ldl0;)V

    .line 57
    .line 58
    .line 59
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 60
    .line 61
    .line 62
    const/4 p1, 0x0

    .line 63
    invoke-virtual {p0, p1, v0}, Ld81;->i(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 64
    .line 65
    .line 66
    :cond_41
    :goto_41
    return-void

    .line 67
    :cond_42
    const-string p0, "This input is not added to any dispatcher."

    .line 68
    .line 69
    invoke-static {p0}, Lod;->p(Ljava/lang/String;)V

    .line 70
    .line 71
    .line 72
    return-void
.end method

.method public final onBackStarted(Landroid/window/BackEvent;)V
    .registers 4

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-static {p1}, Ljb0;->a(Landroid/window/BackEvent;)Ldl0;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    iget-object p0, p0, Ldn0;->a:Lbn0;

    .line 9
    .line 10
    iget-object v0, p0, Lhl0;->a:Lp3;

    .line 11
    .line 12
    if-eqz v0, :cond_18

    .line 13
    .line 14
    iget-boolean v1, p0, Lhl0;->b:Z

    .line 15
    .line 16
    if-nez v1, :cond_17

    .line 17
    .line 18
    invoke-virtual {v0, p0, p1}, Lp3;->g(Lhl0;Ldl0;)V

    .line 19
    .line 20
    .line 21
    const/4 p1, 0x1

    .line 22
    iput-boolean p1, p0, Lhl0;->b:Z

    .line 23
    .line 24
    :cond_17
    return-void

    .line 25
    :cond_18
    const-string p0, "This input is not added to any dispatcher."

    .line 26
    .line 27
    invoke-static {p0}, Lod;->p(Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    return-void
.end method
