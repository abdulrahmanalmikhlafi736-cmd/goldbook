.class public final synthetic Lb2;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lm00;


# instance fields
.field public final synthetic e:I

.field public final synthetic f:Z

.field public final synthetic g:Li00;

.field public final synthetic h:Ljava/lang/Object;

.field public final synthetic i:Ljava/lang/Object;

.field public final synthetic j:Ljava/lang/Object;

.field public final synthetic k:Ljava/lang/Object;

.field public final synthetic l:Ljava/lang/Object;

.field public final synthetic m:Ljava/lang/Object;

.field public final synthetic n:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Lmi0;Lsc0;Lup0;Lp9;Lmb;Ljo;ZLx5;Li00;I)V
    .registers 11

    .line 1
    const/4 p10, 0x1

    .line 2
    iput p10, p0, Lb2;->e:I

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lb2;->h:Ljava/lang/Object;

    .line 8
    .line 9
    iput-object p2, p0, Lb2;->i:Ljava/lang/Object;

    .line 10
    .line 11
    iput-object p3, p0, Lb2;->j:Ljava/lang/Object;

    .line 12
    .line 13
    iput-object p4, p0, Lb2;->k:Ljava/lang/Object;

    .line 14
    .line 15
    iput-object p5, p0, Lb2;->l:Ljava/lang/Object;

    .line 16
    .line 17
    iput-object p6, p0, Lb2;->m:Ljava/lang/Object;

    .line 18
    .line 19
    iput-boolean p7, p0, Lb2;->f:Z

    .line 20
    .line 21
    iput-object p8, p0, Lb2;->n:Ljava/lang/Object;

    .line 22
    .line 23
    iput-object p9, p0, Lb2;->g:Li00;

    .line 24
    .line 25
    return-void
.end method

.method public synthetic constructor <init>(Lwi1;Landroid/widget/FrameLayout$LayoutParams;ZLui1;Li00;Li00;Lw1;Lv1;Li00;I)V
    .registers 11

    .line 26
    const/4 p10, 0x0

    iput p10, p0, Lb2;->e:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lb2;->h:Ljava/lang/Object;

    iput-object p2, p0, Lb2;->i:Ljava/lang/Object;

    iput-boolean p3, p0, Lb2;->f:Z

    iput-object p4, p0, Lb2;->j:Ljava/lang/Object;

    iput-object p5, p0, Lb2;->g:Li00;

    iput-object p6, p0, Lb2;->k:Ljava/lang/Object;

    iput-object p7, p0, Lb2;->m:Ljava/lang/Object;

    iput-object p8, p0, Lb2;->n:Ljava/lang/Object;

    iput-object p9, p0, Lb2;->l:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 35

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget v1, v0, Lb2;->e:I

    .line 4
    .line 5
    sget-object v2, Lwe1;->a:Lwe1;

    .line 6
    .line 7
    iget-object v3, v0, Lb2;->n:Ljava/lang/Object;

    .line 8
    .line 9
    iget-object v4, v0, Lb2;->m:Ljava/lang/Object;

    .line 10
    .line 11
    iget-object v5, v0, Lb2;->l:Ljava/lang/Object;

    .line 12
    .line 13
    iget-object v6, v0, Lb2;->k:Ljava/lang/Object;

    .line 14
    .line 15
    iget-object v7, v0, Lb2;->j:Ljava/lang/Object;

    .line 16
    .line 17
    iget-object v8, v0, Lb2;->i:Ljava/lang/Object;

    .line 18
    .line 19
    iget-object v9, v0, Lb2;->h:Ljava/lang/Object;

    .line 20
    .line 21
    packed-switch v1, :pswitch_data_84

    .line 22
    .line 23
    .line 24
    move-object v10, v9

    .line 25
    check-cast v10, Lmi0;

    .line 26
    .line 27
    move-object v11, v8

    .line 28
    check-cast v11, Lsc0;

    .line 29
    .line 30
    move-object v12, v7

    .line 31
    check-cast v12, Lup0;

    .line 32
    .line 33
    move-object v13, v6

    .line 34
    check-cast v13, Lp9;

    .line 35
    .line 36
    move-object v14, v5

    .line 37
    check-cast v14, Lmb;

    .line 38
    .line 39
    move-object v15, v4

    .line 40
    check-cast v15, Ljo;

    .line 41
    .line 42
    move-object/from16 v17, v3

    .line 43
    .line 44
    check-cast v17, Lx5;

    .line 45
    .line 46
    move-object/from16 v19, p1

    .line 47
    .line 48
    check-cast v19, Ld10;

    .line 49
    .line 50
    move-object/from16 v1, p2

    .line 51
    .line 52
    check-cast v1, Ljava/lang/Integer;

    .line 53
    .line 54
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 55
    .line 56
    .line 57
    const/16 v1, 0x6181

    .line 58
    .line 59
    invoke-static {v1}, Lwc0;->s(I)I

    .line 60
    .line 61
    .line 62
    move-result v20

    .line 63
    iget-boolean v1, v0, Lb2;->f:Z

    .line 64
    .line 65
    iget-object v0, v0, Lb2;->g:Li00;

    .line 66
    .line 67
    move-object/from16 v18, v0

    .line 68
    .line 69
    move/from16 v16, v1

    .line 70
    .line 71
    invoke-static/range {v10 .. v20}, Lua0;->a(Lmi0;Lsc0;Lup0;Lp9;Lmb;Ljo;ZLx5;Li00;Ld10;I)V

    .line 72
    .line 73
    .line 74
    return-object v2

    .line 75
    :pswitch_4a  #0x0
    move-object/from16 v21, v9

    .line 76
    .line 77
    check-cast v21, Lwi1;

    .line 78
    .line 79
    move-object/from16 v22, v8

    .line 80
    .line 81
    check-cast v22, Landroid/widget/FrameLayout$LayoutParams;

    .line 82
    .line 83
    move-object/from16 v24, v7

    .line 84
    .line 85
    check-cast v24, Lui1;

    .line 86
    .line 87
    move-object/from16 v26, v6

    .line 88
    .line 89
    check-cast v26, Li00;

    .line 90
    .line 91
    move-object/from16 v27, v4

    .line 92
    .line 93
    check-cast v27, Lw1;

    .line 94
    .line 95
    move-object/from16 v28, v3

    .line 96
    .line 97
    check-cast v28, Lv1;

    .line 98
    .line 99
    move-object/from16 v29, v5

    .line 100
    .line 101
    check-cast v29, Li00;

    .line 102
    .line 103
    move-object/from16 v30, p1

    .line 104
    .line 105
    check-cast v30, Ld10;

    .line 106
    .line 107
    move-object/from16 v1, p2

    .line 108
    .line 109
    check-cast v1, Ljava/lang/Integer;

    .line 110
    .line 111
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 112
    .line 113
    .line 114
    const/16 v1, 0x181

    .line 115
    .line 116
    invoke-static {v1}, Lwc0;->s(I)I

    .line 117
    .line 118
    .line 119
    move-result v31

    .line 120
    iget-boolean v1, v0, Lb2;->f:Z

    .line 121
    .line 122
    iget-object v0, v0, Lb2;->g:Li00;

    .line 123
    .line 124
    move-object/from16 v25, v0

    .line 125
    .line 126
    move/from16 v23, v1

    .line 127
    .line 128
    invoke-static/range {v21 .. v31}, Lzi1;->b(Lwi1;Landroid/widget/FrameLayout$LayoutParams;ZLui1;Li00;Li00;Lw1;Lv1;Li00;Ld10;I)V

    .line 129
    .line 130
    .line 131
    return-object v2

    .line 132
    nop

    .line 133
    :pswitch_data_84
    .packed-switch 0x0
        :pswitch_4a  #00000000
    .end packed-switch
.end method
