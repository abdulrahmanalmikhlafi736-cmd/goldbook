.class public final synthetic Lbi;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lqd0;


# instance fields
.field public final synthetic e:Ljn0;

.field public final synthetic f:Lki;


# direct methods
.method public synthetic constructor <init>(Ljn0;Lki;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lbi;->e:Ljn0;

    .line 5
    .line 6
    iput-object p2, p0, Lbi;->f:Lki;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final h(Lsd0;Lid0;)V
    .registers 3

    .line 1
    sget-object p1, Lid0;->ON_CREATE:Lid0;

    .line 2
    .line 3
    if-ne p2, p1, :cond_12

    .line 4
    .line 5
    iget-object p1, p0, Lbi;->f:Lki;

    .line 6
    .line 7
    invoke-static {p1}, Le1;->g(Lki;)Landroid/window/OnBackInvokedDispatcher;

    .line 8
    .line 9
    .line 10
    move-result-object p1

    .line 11
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    iget-object p0, p0, Lbi;->e:Ljn0;

    .line 15
    .line 16
    invoke-virtual {p0, p1}, Ljn0;->b(Landroid/window/OnBackInvokedDispatcher;)V

    .line 17
    .line 18
    .line 19
    :cond_12
    return-void
.end method
