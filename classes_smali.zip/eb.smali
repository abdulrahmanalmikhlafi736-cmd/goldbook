.class public abstract Leb;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# static fields
.field public static final a:Lu41;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    sget-object v0, Lu41;->e:Lu41;

    .line 2
    .line 3
    sput-object v0, Leb;->a:Lu41;

    .line 4
    .line 5
    return-void
.end method
