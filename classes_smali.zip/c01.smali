.class public final synthetic Lc01;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lm00;


# instance fields
.field public final synthetic e:I


# direct methods
.method public synthetic constructor <init>(I)V
    .registers 2

    .line 1
    iput p1, p0, Lc01;->e:I

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 27

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    move-object/from16 v1, p0

    .line 4
    .line 5
    iget v1, v1, Lc01;->e:I

    .line 6
    .line 7
    const/16 v2, 0x9

    .line 8
    .line 9
    const/4 v7, 0x0

    .line 10
    const/4 v8, 0x4

    .line 11
    const/4 v9, 0x3

    .line 12
    const/4 v10, 0x2

    .line 13
    const/4 v11, 0x1

    .line 14
    const/4 v12, 0x0

    .line 15
    packed-switch v1, :pswitch_data_528

    .line 16
    .line 17
    .line 18
    check-cast v0, Luc1;

    .line 19
    .line 20
    move-object/from16 v0, p2

    .line 21
    .line 22
    check-cast v0, Lql;

    .line 23
    .line 24
    instance-of v1, v0, Luc1;

    .line 25
    .line 26
    if-eqz v1, :cond_1e

    .line 27
    .line 28
    move-object v7, v0

    .line 29
    check-cast v7, Luc1;

    .line 30
    .line 31
    :cond_1e
    return-object v7

    .line 32
    :pswitch_1f  #0x1c
    move-object/from16 v1, p2

    .line 33
    .line 34
    check-cast v1, Lql;

    .line 35
    .line 36
    instance-of v2, v1, Luc1;

    .line 37
    .line 38
    if-eqz v2, :cond_3f

    .line 39
    .line 40
    instance-of v2, v0, Ljava/lang/Integer;

    .line 41
    .line 42
    if-eqz v2, :cond_2e

    .line 43
    .line 44
    move-object v7, v0

    .line 45
    check-cast v7, Ljava/lang/Integer;

    .line 46
    .line 47
    :cond_2e
    if-eqz v7, :cond_35

    .line 48
    .line 49
    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    .line 50
    .line 51
    .line 52
    move-result v0

    .line 53
    goto :goto_36

    .line 54
    :cond_35
    move v0, v11

    .line 55
    :goto_36
    if-nez v0, :cond_3a

    .line 56
    .line 57
    move-object v0, v1

    .line 58
    goto :goto_3f

    .line 59
    :cond_3a
    add-int/2addr v0, v11

    .line 60
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 61
    .line 62
    .line 63
    move-result-object v0

    .line 64
    :cond_3f
    :goto_3f
    return-object v0

    .line 65
    :pswitch_40  #0x1b
    check-cast v0, Liz0;

    .line 66
    .line 67
    move-object/from16 v0, p2

    .line 68
    .line 69
    check-cast v0, Lc11;

    .line 70
    .line 71
    iget-object v0, v0, Lc11;->a:Liq0;

    .line 72
    .line 73
    invoke-virtual {v0}, Liq0;->g()I

    .line 74
    .line 75
    .line 76
    move-result v0

    .line 77
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 78
    .line 79
    .line 80
    move-result-object v0

    .line 81
    return-object v0

    .line 82
    :pswitch_51  #0x1a
    check-cast v0, Liz0;

    .line 83
    .line 84
    move-object/from16 v0, p2

    .line 85
    .line 86
    check-cast v0, Lfb1;

    .line 87
    .line 88
    iget v0, v0, Lfb1;->a:I

    .line 89
    .line 90
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 91
    .line 92
    .line 93
    move-result-object v0

    .line 94
    return-object v0

    .line 95
    :pswitch_5e  #0x19
    check-cast v0, Liz0;

    .line 96
    .line 97
    move-object/from16 v1, p2

    .line 98
    .line 99
    check-cast v1, Lgb1;

    .line 100
    .line 101
    iget v2, v1, Lgb1;->a:I

    .line 102
    .line 103
    new-instance v3, Lfb1;

    .line 104
    .line 105
    invoke-direct {v3, v2}, Lfb1;-><init>(I)V

    .line 106
    .line 107
    .line 108
    sget-object v2, Lvd1;->q:Lal;

    .line 109
    .line 110
    invoke-static {v3, v2, v0}, Le01;->a(Ljava/lang/Object;La01;Liz0;)Ljava/lang/Object;

    .line 111
    .line 112
    .line 113
    move-result-object v0

    .line 114
    iget-boolean v1, v1, Lgb1;->b:Z

    .line 115
    .line 116
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 117
    .line 118
    .line 119
    move-result-object v1

    .line 120
    new-array v2, v10, [Ljava/lang/Object;

    .line 121
    .line 122
    aput-object v0, v2, v12

    .line 123
    .line 124
    aput-object v1, v2, v11

    .line 125
    .line 126
    invoke-static {v2}, Lzi1;->m([Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 127
    .line 128
    .line 129
    move-result-object v0

    .line 130
    return-object v0

    .line 131
    :pswitch_82  #0x18
    check-cast v0, Liz0;

    .line 132
    .line 133
    move-object/from16 v0, p2

    .line 134
    .line 135
    check-cast v0, Lce0;

    .line 136
    .line 137
    iget v0, v0, Lce0;->a:I

    .line 138
    .line 139
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 140
    .line 141
    .line 142
    move-result-object v0

    .line 143
    return-object v0

    .line 144
    :pswitch_8f  #0x17
    check-cast v0, Liz0;

    .line 145
    .line 146
    move-object/from16 v0, p2

    .line 147
    .line 148
    check-cast v0, Lot;

    .line 149
    .line 150
    iget v0, v0, Lot;->a:I

    .line 151
    .line 152
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 153
    .line 154
    .line 155
    move-result-object v0

    .line 156
    return-object v0

    .line 157
    :pswitch_9c  #0x16
    check-cast v0, Liz0;

    .line 158
    .line 159
    move-object/from16 v1, p2

    .line 160
    .line 161
    check-cast v1, Lss0;

    .line 162
    .line 163
    iget-boolean v2, v1, Lss0;->a:Z

    .line 164
    .line 165
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 166
    .line 167
    .line 168
    move-result-object v2

    .line 169
    sget-object v3, Le01;->a:Lal;

    .line 170
    .line 171
    iget v1, v1, Lss0;->b:I

    .line 172
    .line 173
    new-instance v3, Lot;

    .line 174
    .line 175
    invoke-direct {v3, v1}, Lot;-><init>(I)V

    .line 176
    .line 177
    .line 178
    sget-object v1, Lvd1;->n:Lal;

    .line 179
    .line 180
    invoke-static {v3, v1, v0}, Le01;->a(Ljava/lang/Object;La01;Liz0;)Ljava/lang/Object;

    .line 181
    .line 182
    .line 183
    move-result-object v0

    .line 184
    new-array v1, v10, [Ljava/lang/Object;

    .line 185
    .line 186
    aput-object v2, v1, v12

    .line 187
    .line 188
    aput-object v0, v1, v11

    .line 189
    .line 190
    invoke-static {v1}, Lzi1;->m([Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 191
    .line 192
    .line 193
    move-result-object v0

    .line 194
    return-object v0

    .line 195
    :pswitch_c2  #0x15
    check-cast v0, Liz0;

    .line 196
    .line 197
    move-object/from16 v1, p2

    .line 198
    .line 199
    check-cast v1, Leb1;

    .line 200
    .line 201
    iget-object v2, v1, Leb1;->a:Li71;

    .line 202
    .line 203
    sget-object v3, Le01;->h:Lal;

    .line 204
    .line 205
    invoke-static {v2, v3, v0}, Le01;->a(Ljava/lang/Object;La01;Liz0;)Ljava/lang/Object;

    .line 206
    .line 207
    .line 208
    move-result-object v2

    .line 209
    iget-object v4, v1, Leb1;->b:Li71;

    .line 210
    .line 211
    invoke-static {v4, v3, v0}, Le01;->a(Ljava/lang/Object;La01;Liz0;)Ljava/lang/Object;

    .line 212
    .line 213
    .line 214
    move-result-object v4

    .line 215
    iget-object v5, v1, Leb1;->c:Li71;

    .line 216
    .line 217
    invoke-static {v5, v3, v0}, Le01;->a(Ljava/lang/Object;La01;Liz0;)Ljava/lang/Object;

    .line 218
    .line 219
    .line 220
    move-result-object v5

    .line 221
    iget-object v1, v1, Leb1;->d:Li71;

    .line 222
    .line 223
    invoke-static {v1, v3, v0}, Le01;->a(Ljava/lang/Object;La01;Liz0;)Ljava/lang/Object;

    .line 224
    .line 225
    .line 226
    move-result-object v0

    .line 227
    new-array v1, v8, [Ljava/lang/Object;

    .line 228
    .line 229
    aput-object v2, v1, v12

    .line 230
    .line 231
    aput-object v4, v1, v11

    .line 232
    .line 233
    aput-object v5, v1, v10

    .line 234
    .line 235
    aput-object v0, v1, v9

    .line 236
    .line 237
    invoke-static {v1}, Lzi1;->m([Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 238
    .line 239
    .line 240
    move-result-object v0

    .line 241
    return-object v0

    .line 242
    :pswitch_f1  #0x14
    check-cast v0, Liz0;

    .line 243
    .line 244
    move-object/from16 v1, p2

    .line 245
    .line 246
    check-cast v1, Li71;

    .line 247
    .line 248
    iget-object v7, v1, Li71;->a:Lua1;

    .line 249
    .line 250
    invoke-interface {v7}, Lua1;->b()J

    .line 251
    .line 252
    .line 253
    move-result-wide v13

    .line 254
    new-instance v7, Lzg;

    .line 255
    .line 256
    invoke-direct {v7, v13, v14}, Lzg;-><init>(J)V

    .line 257
    .line 258
    .line 259
    sget-object v13, Le01;->p:Ld01;

    .line 260
    .line 261
    invoke-static {v7, v13, v0}, Le01;->a(Ljava/lang/Object;La01;Liz0;)Ljava/lang/Object;

    .line 262
    .line 263
    .line 264
    move-result-object v7

    .line 265
    iget-wide v14, v1, Li71;->b:J

    .line 266
    .line 267
    const/16 p0, 0x8

    .line 268
    .line 269
    new-instance v3, Lqb1;

    .line 270
    .line 271
    invoke-direct {v3, v14, v15}, Lqb1;-><init>(J)V

    .line 272
    .line 273
    .line 274
    sget-object v14, Le01;->v:Ld01;

    .line 275
    .line 276
    invoke-static {v3, v14, v0}, Le01;->a(Ljava/lang/Object;La01;Liz0;)Ljava/lang/Object;

    .line 277
    .line 278
    .line 279
    move-result-object v3

    .line 280
    iget-object v15, v1, Li71;->c:Lpz;

    .line 281
    .line 282
    sget-object v16, Lpz;->f:Lpz;

    .line 283
    .line 284
    const/16 v16, 0x7

    .line 285
    .line 286
    sget-object v4, Le01;->m:Lal;

    .line 287
    .line 288
    invoke-static {v15, v4, v0}, Le01;->a(Ljava/lang/Object;La01;Liz0;)Ljava/lang/Object;

    .line 289
    .line 290
    .line 291
    move-result-object v4

    .line 292
    iget-object v15, v1, Li71;->d:Lnz;

    .line 293
    .line 294
    const/16 v17, 0x6

    .line 295
    .line 296
    sget-object v5, Le01;->t:Lal;

    .line 297
    .line 298
    invoke-static {v15, v5, v0}, Le01;->a(Ljava/lang/Object;La01;Liz0;)Ljava/lang/Object;

    .line 299
    .line 300
    .line 301
    move-result-object v5

    .line 302
    iget-object v15, v1, Li71;->e:Loz;

    .line 303
    .line 304
    move/from16 v18, v8

    .line 305
    .line 306
    sget-object v8, Le01;->u:Lal;

    .line 307
    .line 308
    invoke-static {v15, v8, v0}, Le01;->a(Ljava/lang/Object;La01;Liz0;)Ljava/lang/Object;

    .line 309
    .line 310
    .line 311
    move-result-object v8

    .line 312
    const/4 v15, -0x1

    .line 313
    invoke-static {v15}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 314
    .line 315
    .line 316
    move-result-object v15

    .line 317
    move/from16 v19, v11

    .line 318
    .line 319
    iget-object v11, v1, Li71;->g:Ljava/lang/String;

    .line 320
    .line 321
    move/from16 v20, v10

    .line 322
    .line 323
    move-object/from16 p1, v11

    .line 324
    .line 325
    iget-wide v10, v1, Li71;->h:J

    .line 326
    .line 327
    move/from16 v21, v12

    .line 328
    .line 329
    new-instance v12, Lqb1;

    .line 330
    .line 331
    invoke-direct {v12, v10, v11}, Lqb1;-><init>(J)V

    .line 332
    .line 333
    .line 334
    invoke-static {v12, v14, v0}, Le01;->a(Ljava/lang/Object;La01;Liz0;)Ljava/lang/Object;

    .line 335
    .line 336
    .line 337
    move-result-object v10

    .line 338
    iget-object v11, v1, Li71;->i:Lfb;

    .line 339
    .line 340
    sget-object v12, Le01;->n:Lal;

    .line 341
    .line 342
    invoke-static {v11, v12, v0}, Le01;->a(Ljava/lang/Object;La01;Liz0;)Ljava/lang/Object;

    .line 343
    .line 344
    .line 345
    move-result-object v11

    .line 346
    iget-object v12, v1, Li71;->j:Lva1;

    .line 347
    .line 348
    sget-object v14, Le01;->k:Lal;

    .line 349
    .line 350
    invoke-static {v12, v14, v0}, Le01;->a(Ljava/lang/Object;La01;Liz0;)Ljava/lang/Object;

    .line 351
    .line 352
    .line 353
    move-result-object v12

    .line 354
    iget-object v14, v1, Li71;->k:Lif0;

    .line 355
    .line 356
    sget-object v22, Lif0;->g:Lif0;

    .line 357
    .line 358
    const/16 v22, 0x5

    .line 359
    .line 360
    sget-object v6, Le01;->y:Lal;

    .line 361
    .line 362
    invoke-static {v14, v6, v0}, Le01;->a(Ljava/lang/Object;La01;Liz0;)Ljava/lang/Object;

    .line 363
    .line 364
    .line 365
    move-result-object v6

    .line 366
    move v14, v9

    .line 367
    move-object/from16 p2, v10

    .line 368
    .line 369
    iget-wide v9, v1, Li71;->l:J

    .line 370
    .line 371
    move/from16 v23, v14

    .line 372
    .line 373
    new-instance v14, Lzg;

    .line 374
    .line 375
    invoke-direct {v14, v9, v10}, Lzg;-><init>(J)V

    .line 376
    .line 377
    .line 378
    invoke-static {v14, v13, v0}, Le01;->a(Ljava/lang/Object;La01;Liz0;)Ljava/lang/Object;

    .line 379
    .line 380
    .line 381
    move-result-object v9

    .line 382
    iget-object v10, v1, Li71;->m:Lqa1;

    .line 383
    .line 384
    sget-object v13, Le01;->j:Lal;

    .line 385
    .line 386
    invoke-static {v10, v13, v0}, Le01;->a(Ljava/lang/Object;La01;Liz0;)Ljava/lang/Object;

    .line 387
    .line 388
    .line 389
    move-result-object v10

    .line 390
    iget-object v1, v1, Li71;->n:Lw41;

    .line 391
    .line 392
    sget-object v13, Lw41;->d:Lw41;

    .line 393
    .line 394
    sget-object v13, Le01;->o:Lal;

    .line 395
    .line 396
    invoke-static {v1, v13, v0}, Le01;->a(Ljava/lang/Object;La01;Liz0;)Ljava/lang/Object;

    .line 397
    .line 398
    .line 399
    move-result-object v0

    .line 400
    const/16 v1, 0xe

    .line 401
    .line 402
    new-array v1, v1, [Ljava/lang/Object;

    .line 403
    .line 404
    aput-object v7, v1, v21

    .line 405
    .line 406
    aput-object v3, v1, v19

    .line 407
    .line 408
    aput-object v4, v1, v20

    .line 409
    .line 410
    aput-object v5, v1, v23

    .line 411
    .line 412
    aput-object v8, v1, v18

    .line 413
    .line 414
    aput-object v15, v1, v22

    .line 415
    .line 416
    aput-object p1, v1, v17

    .line 417
    .line 418
    aput-object p2, v1, v16

    .line 419
    .line 420
    aput-object v11, v1, p0

    .line 421
    .line 422
    aput-object v12, v1, v2

    .line 423
    .line 424
    const/16 v2, 0xa

    .line 425
    .line 426
    aput-object v6, v1, v2

    .line 427
    .line 428
    const/16 v2, 0xb

    .line 429
    .line 430
    aput-object v9, v1, v2

    .line 431
    .line 432
    const/16 v2, 0xc

    .line 433
    .line 434
    aput-object v10, v1, v2

    .line 435
    .line 436
    const/16 v2, 0xd

    .line 437
    .line 438
    aput-object v0, v1, v2

    .line 439
    .line 440
    invoke-static {v1}, Lzi1;->m([Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 441
    .line 442
    .line 443
    move-result-object v0

    .line 444
    return-object v0

    .line 445
    :pswitch_1bc  #0x13
    check-cast v0, Liz0;

    .line 446
    .line 447
    move-object/from16 v0, p2

    .line 448
    .line 449
    check-cast v0, Lof1;

    .line 450
    .line 451
    iget-object v0, v0, Lof1;->a:Ljava/lang/String;

    .line 452
    .line 453
    return-object v0

    .line 454
    :pswitch_1c5  #0x12
    move/from16 v18, v8

    .line 455
    .line 456
    move/from16 v23, v9

    .line 457
    .line 458
    move/from16 v20, v10

    .line 459
    .line 460
    move/from16 v19, v11

    .line 461
    .line 462
    move/from16 v21, v12

    .line 463
    .line 464
    const/16 p0, 0x8

    .line 465
    .line 466
    const/16 v16, 0x7

    .line 467
    .line 468
    const/16 v17, 0x6

    .line 469
    .line 470
    const/16 v22, 0x5

    .line 471
    .line 472
    check-cast v0, Liz0;

    .line 473
    .line 474
    move-object/from16 v1, p2

    .line 475
    .line 476
    check-cast v1, Lfq0;

    .line 477
    .line 478
    iget v3, v1, Lfq0;->a:I

    .line 479
    .line 480
    new-instance v4, Lna1;

    .line 481
    .line 482
    invoke-direct {v4, v3}, Lna1;-><init>(I)V

    .line 483
    .line 484
    .line 485
    sget-object v3, Le01;->q:Ld01;

    .line 486
    .line 487
    invoke-static {v4, v3, v0}, Le01;->a(Ljava/lang/Object;La01;Liz0;)Ljava/lang/Object;

    .line 488
    .line 489
    .line 490
    move-result-object v3

    .line 491
    iget v4, v1, Lfq0;->b:I

    .line 492
    .line 493
    new-instance v5, Lsa1;

    .line 494
    .line 495
    invoke-direct {v5, v4}, Lsa1;-><init>(I)V

    .line 496
    .line 497
    .line 498
    sget-object v4, Le01;->r:Ld01;

    .line 499
    .line 500
    invoke-static {v5, v4, v0}, Le01;->a(Ljava/lang/Object;La01;Liz0;)Ljava/lang/Object;

    .line 501
    .line 502
    .line 503
    move-result-object v4

    .line 504
    iget-wide v5, v1, Lfq0;->c:J

    .line 505
    .line 506
    new-instance v7, Lqb1;

    .line 507
    .line 508
    invoke-direct {v7, v5, v6}, Lqb1;-><init>(J)V

    .line 509
    .line 510
    .line 511
    sget-object v5, Le01;->v:Ld01;

    .line 512
    .line 513
    invoke-static {v7, v5, v0}, Le01;->a(Ljava/lang/Object;La01;Liz0;)Ljava/lang/Object;

    .line 514
    .line 515
    .line 516
    move-result-object v5

    .line 517
    iget-object v6, v1, Lfq0;->d:Lwa1;

    .line 518
    .line 519
    sget-object v7, Lwa1;->c:Lwa1;

    .line 520
    .line 521
    sget-object v7, Le01;->l:Lal;

    .line 522
    .line 523
    invoke-static {v6, v7, v0}, Le01;->a(Ljava/lang/Object;La01;Liz0;)Ljava/lang/Object;

    .line 524
    .line 525
    .line 526
    move-result-object v6

    .line 527
    iget-object v7, v1, Lfq0;->e:Lss0;

    .line 528
    .line 529
    sget-object v8, Lvd1;->m:Lal;

    .line 530
    .line 531
    invoke-static {v7, v8, v0}, Le01;->a(Ljava/lang/Object;La01;Liz0;)Ljava/lang/Object;

    .line 532
    .line 533
    .line 534
    move-result-object v7

    .line 535
    iget-object v8, v1, Lfq0;->f:Lhe0;

    .line 536
    .line 537
    sget-object v9, Lhe0;->d:Lhe0;

    .line 538
    .line 539
    sget-object v9, Le01;->A:Lal;

    .line 540
    .line 541
    invoke-static {v8, v9, v0}, Le01;->a(Ljava/lang/Object;La01;Liz0;)Ljava/lang/Object;

    .line 542
    .line 543
    .line 544
    move-result-object v8

    .line 545
    iget v9, v1, Lfq0;->g:I

    .line 546
    .line 547
    new-instance v10, Lce0;

    .line 548
    .line 549
    invoke-direct {v10, v9}, Lce0;-><init>(I)V

    .line 550
    .line 551
    .line 552
    sget-object v9, Lvd1;->o:Lal;

    .line 553
    .line 554
    invoke-static {v10, v9, v0}, Le01;->a(Ljava/lang/Object;La01;Liz0;)Ljava/lang/Object;

    .line 555
    .line 556
    .line 557
    move-result-object v9

    .line 558
    iget v10, v1, Lfq0;->h:I

    .line 559
    .line 560
    new-instance v11, Lo30;

    .line 561
    .line 562
    invoke-direct {v11, v10}, Lo30;-><init>(I)V

    .line 563
    .line 564
    .line 565
    sget-object v10, Le01;->s:Ld01;

    .line 566
    .line 567
    invoke-static {v11, v10, v0}, Le01;->a(Ljava/lang/Object;La01;Liz0;)Ljava/lang/Object;

    .line 568
    .line 569
    .line 570
    move-result-object v10

    .line 571
    iget-object v1, v1, Lfq0;->i:Lgb1;

    .line 572
    .line 573
    sget-object v11, Lvd1;->p:Lal;

    .line 574
    .line 575
    invoke-static {v1, v11, v0}, Le01;->a(Ljava/lang/Object;La01;Liz0;)Ljava/lang/Object;

    .line 576
    .line 577
    .line 578
    move-result-object v0

    .line 579
    new-array v1, v2, [Ljava/lang/Object;

    .line 580
    .line 581
    aput-object v3, v1, v21

    .line 582
    .line 583
    aput-object v4, v1, v19

    .line 584
    .line 585
    aput-object v5, v1, v20

    .line 586
    .line 587
    aput-object v6, v1, v23

    .line 588
    .line 589
    aput-object v7, v1, v18

    .line 590
    .line 591
    aput-object v8, v1, v22

    .line 592
    .line 593
    aput-object v9, v1, v17

    .line 594
    .line 595
    aput-object v10, v1, v16

    .line 596
    .line 597
    aput-object v0, v1, p0

    .line 598
    .line 599
    invoke-static {v1}, Lzi1;->m([Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 600
    .line 601
    .line 602
    move-result-object v0

    .line 603
    return-object v0

    .line 604
    :pswitch_25b  #0x11
    check-cast v0, Liz0;

    .line 605
    .line 606
    move-object/from16 v0, p2

    .line 607
    .line 608
    check-cast v0, Ljg1;

    .line 609
    .line 610
    iget-object v0, v0, Ljg1;->a:Ljava/lang/String;

    .line 611
    .line 612
    return-object v0

    .line 613
    :pswitch_264  #0x10
    check-cast v0, Liz0;

    .line 614
    .line 615
    move-object/from16 v0, p2

    .line 616
    .line 617
    check-cast v0, Lfe0;

    .line 618
    .line 619
    iget v0, v0, Lfe0;->a:I

    .line 620
    .line 621
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 622
    .line 623
    .line 624
    move-result-object v0

    .line 625
    return-object v0

    .line 626
    :pswitch_271  #0xf
    check-cast v0, Liz0;

    .line 627
    .line 628
    move-object/from16 v0, p2

    .line 629
    .line 630
    check-cast v0, Lge0;

    .line 631
    .line 632
    iget v0, v0, Lge0;->a:I

    .line 633
    .line 634
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 635
    .line 636
    .line 637
    move-result-object v0

    .line 638
    return-object v0

    .line 639
    :pswitch_27e  #0xe
    check-cast v0, Liz0;

    .line 640
    .line 641
    move-object/from16 v0, p2

    .line 642
    .line 643
    check-cast v0, Lee0;

    .line 644
    .line 645
    iget v0, v0, Lee0;->a:F

    .line 646
    .line 647
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 648
    .line 649
    .line 650
    move-result-object v0

    .line 651
    return-object v0

    .line 652
    :pswitch_28b  #0xd
    move/from16 v23, v9

    .line 653
    .line 654
    move/from16 v20, v10

    .line 655
    .line 656
    move/from16 v19, v11

    .line 657
    .line 658
    move/from16 v21, v12

    .line 659
    .line 660
    check-cast v0, Liz0;

    .line 661
    .line 662
    move-object/from16 v1, p2

    .line 663
    .line 664
    check-cast v1, Lhe0;

    .line 665
    .line 666
    iget v2, v1, Lhe0;->a:F

    .line 667
    .line 668
    new-instance v3, Lee0;

    .line 669
    .line 670
    invoke-direct {v3, v2}, Lee0;-><init>(F)V

    .line 671
    .line 672
    .line 673
    sget-object v2, Le01;->B:Ld01;

    .line 674
    .line 675
    invoke-static {v3, v2, v0}, Le01;->a(Ljava/lang/Object;La01;Liz0;)Ljava/lang/Object;

    .line 676
    .line 677
    .line 678
    move-result-object v2

    .line 679
    iget v3, v1, Lhe0;->b:I

    .line 680
    .line 681
    new-instance v4, Lge0;

    .line 682
    .line 683
    invoke-direct {v4, v3}, Lge0;-><init>(I)V

    .line 684
    .line 685
    .line 686
    sget-object v3, Le01;->C:Ld01;

    .line 687
    .line 688
    invoke-static {v4, v3, v0}, Le01;->a(Ljava/lang/Object;La01;Liz0;)Ljava/lang/Object;

    .line 689
    .line 690
    .line 691
    move-result-object v3

    .line 692
    iget v1, v1, Lhe0;->c:I

    .line 693
    .line 694
    new-instance v4, Lfe0;

    .line 695
    .line 696
    invoke-direct {v4, v1}, Lfe0;-><init>(I)V

    .line 697
    .line 698
    .line 699
    sget-object v1, Le01;->D:Ld01;

    .line 700
    .line 701
    invoke-static {v4, v1, v0}, Le01;->a(Ljava/lang/Object;La01;Liz0;)Ljava/lang/Object;

    .line 702
    .line 703
    .line 704
    move-result-object v0

    .line 705
    move/from16 v14, v23

    .line 706
    .line 707
    new-array v1, v14, [Ljava/lang/Object;

    .line 708
    .line 709
    aput-object v2, v1, v21

    .line 710
    .line 711
    aput-object v3, v1, v19

    .line 712
    .line 713
    aput-object v0, v1, v20

    .line 714
    .line 715
    invoke-static {v1}, Lzi1;->m([Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 716
    .line 717
    .line 718
    move-result-object v0

    .line 719
    return-object v0

    .line 720
    :pswitch_2cf  #0xc
    check-cast v0, Liz0;

    .line 721
    .line 722
    move-object/from16 v0, p2

    .line 723
    .line 724
    check-cast v0, Lhf0;

    .line 725
    .line 726
    iget-object v0, v0, Lhf0;->a:Ljava/util/Locale;

    .line 727
    .line 728
    invoke-virtual {v0}, Ljava/util/Locale;->toLanguageTag()Ljava/lang/String;

    .line 729
    .line 730
    .line 731
    move-result-object v0

    .line 732
    return-object v0

    .line 733
    :pswitch_2dc  #0xb
    move/from16 v21, v12

    .line 734
    .line 735
    check-cast v0, Liz0;

    .line 736
    .line 737
    move-object/from16 v1, p2

    .line 738
    .line 739
    check-cast v1, Lif0;

    .line 740
    .line 741
    iget-object v1, v1, Lif0;->e:Ljava/util/List;

    .line 742
    .line 743
    new-instance v2, Ljava/util/ArrayList;

    .line 744
    .line 745
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 746
    .line 747
    .line 748
    move-result v3

    .line 749
    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    .line 750
    .line 751
    .line 752
    invoke-interface {v1}, Ljava/util/Collection;->size()I

    .line 753
    .line 754
    .line 755
    move-result v3

    .line 756
    :goto_2f3
    if-ge v12, v3, :cond_307

    .line 757
    .line 758
    invoke-interface {v1, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 759
    .line 760
    .line 761
    move-result-object v4

    .line 762
    check-cast v4, Lhf0;

    .line 763
    .line 764
    sget-object v5, Le01;->z:Lal;

    .line 765
    .line 766
    invoke-static {v4, v5, v0}, Le01;->a(Ljava/lang/Object;La01;Liz0;)Ljava/lang/Object;

    .line 767
    .line 768
    .line 769
    move-result-object v4

    .line 770
    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 771
    .line 772
    .line 773
    add-int/lit8 v12, v12, 0x1

    .line 774
    .line 775
    goto :goto_2f3

    .line 776
    :cond_307
    return-object v2

    .line 777
    :pswitch_308  #0xa
    move/from16 v18, v8

    .line 778
    .line 779
    move/from16 v20, v10

    .line 780
    .line 781
    move/from16 v19, v11

    .line 782
    .line 783
    move/from16 v21, v12

    .line 784
    .line 785
    const/16 v22, 0x5

    .line 786
    .line 787
    check-cast v0, Liz0;

    .line 788
    .line 789
    move-object/from16 v1, p2

    .line 790
    .line 791
    check-cast v1, Lw8;

    .line 792
    .line 793
    iget-object v2, v1, Lw8;->a:Ljava/lang/Object;

    .line 794
    .line 795
    instance-of v3, v2, Lfq0;

    .line 796
    .line 797
    if-eqz v3, :cond_321

    .line 798
    .line 799
    sget-object v3, Lz8;->e:Lz8;

    .line 800
    .line 801
    goto :goto_34a

    .line 802
    :cond_321
    instance-of v3, v2, Li71;

    .line 803
    .line 804
    if-eqz v3, :cond_328

    .line 805
    .line 806
    sget-object v3, Lz8;->f:Lz8;

    .line 807
    .line 808
    goto :goto_34a

    .line 809
    :cond_328
    instance-of v3, v2, Ljg1;

    .line 810
    .line 811
    if-eqz v3, :cond_32f

    .line 812
    .line 813
    sget-object v3, Lz8;->g:Lz8;

    .line 814
    .line 815
    goto :goto_34a

    .line 816
    :cond_32f
    instance-of v3, v2, Lof1;

    .line 817
    .line 818
    if-eqz v3, :cond_336

    .line 819
    .line 820
    sget-object v3, Lz8;->h:Lz8;

    .line 821
    .line 822
    goto :goto_34a

    .line 823
    :cond_336
    instance-of v3, v2, Lme0;

    .line 824
    .line 825
    if-eqz v3, :cond_33d

    .line 826
    .line 827
    sget-object v3, Lz8;->i:Lz8;

    .line 828
    .line 829
    goto :goto_34a

    .line 830
    :cond_33d
    instance-of v3, v2, Lle0;

    .line 831
    .line 832
    if-eqz v3, :cond_344

    .line 833
    .line 834
    sget-object v3, Lz8;->j:Lz8;

    .line 835
    .line 836
    goto :goto_34a

    .line 837
    :cond_344
    instance-of v3, v2, Ln81;

    .line 838
    .line 839
    if-eqz v3, :cond_3c7

    .line 840
    .line 841
    sget-object v3, Lz8;->k:Lz8;

    .line 842
    .line 843
    :goto_34a
    invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I

    .line 844
    .line 845
    .line 846
    move-result v4

    .line 847
    packed-switch v4, :pswitch_data_566

    .line 848
    .line 849
    .line 850
    invoke-static {}, Lod;->k()V

    .line 851
    .line 852
    .line 853
    goto/16 :goto_3c6

    .line 854
    .line 855
    :pswitch_356  #0x6
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 856
    .line 857
    .line 858
    check-cast v2, Ln81;

    .line 859
    .line 860
    iget-object v0, v2, Ln81;->a:Ljava/lang/String;

    .line 861
    .line 862
    goto :goto_3a5

    .line 863
    :pswitch_35e  #0x5
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 864
    .line 865
    .line 866
    check-cast v2, Lle0;

    .line 867
    .line 868
    sget-object v4, Le01;->f:Lal;

    .line 869
    .line 870
    invoke-static {v2, v4, v0}, Le01;->a(Ljava/lang/Object;La01;Liz0;)Ljava/lang/Object;

    .line 871
    .line 872
    .line 873
    move-result-object v0

    .line 874
    goto :goto_3a5

    .line 875
    :pswitch_36a  #0x4
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 876
    .line 877
    .line 878
    check-cast v2, Lme0;

    .line 879
    .line 880
    sget-object v4, Le01;->e:Lal;

    .line 881
    .line 882
    invoke-static {v2, v4, v0}, Le01;->a(Ljava/lang/Object;La01;Liz0;)Ljava/lang/Object;

    .line 883
    .line 884
    .line 885
    move-result-object v0

    .line 886
    goto :goto_3a5

    .line 887
    :pswitch_376  #0x3
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 888
    .line 889
    .line 890
    check-cast v2, Lof1;

    .line 891
    .line 892
    sget-object v4, Le01;->d:Lal;

    .line 893
    .line 894
    invoke-static {v2, v4, v0}, Le01;->a(Ljava/lang/Object;La01;Liz0;)Ljava/lang/Object;

    .line 895
    .line 896
    .line 897
    move-result-object v0

    .line 898
    goto :goto_3a5

    .line 899
    :pswitch_382  #0x2
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 900
    .line 901
    .line 902
    check-cast v2, Ljg1;

    .line 903
    .line 904
    sget-object v4, Le01;->c:Lal;

    .line 905
    .line 906
    invoke-static {v2, v4, v0}, Le01;->a(Ljava/lang/Object;La01;Liz0;)Ljava/lang/Object;

    .line 907
    .line 908
    .line 909
    move-result-object v0

    .line 910
    goto :goto_3a5

    .line 911
    :pswitch_38e  #0x1
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 912
    .line 913
    .line 914
    check-cast v2, Li71;

    .line 915
    .line 916
    sget-object v4, Le01;->h:Lal;

    .line 917
    .line 918
    invoke-static {v2, v4, v0}, Le01;->a(Ljava/lang/Object;La01;Liz0;)Ljava/lang/Object;

    .line 919
    .line 920
    .line 921
    move-result-object v0

    .line 922
    goto :goto_3a5

    .line 923
    :pswitch_39a  #0x0
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 924
    .line 925
    .line 926
    check-cast v2, Lfq0;

    .line 927
    .line 928
    sget-object v4, Le01;->g:Lal;

    .line 929
    .line 930
    invoke-static {v2, v4, v0}, Le01;->a(Ljava/lang/Object;La01;Liz0;)Ljava/lang/Object;

    .line 931
    .line 932
    .line 933
    move-result-object v0

    .line 934
    :goto_3a5
    iget v2, v1, Lw8;->b:I

    .line 935
    .line 936
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 937
    .line 938
    .line 939
    move-result-object v2

    .line 940
    iget v4, v1, Lw8;->c:I

    .line 941
    .line 942
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 943
    .line 944
    .line 945
    move-result-object v4

    .line 946
    iget-object v1, v1, Lw8;->d:Ljava/lang/String;

    .line 947
    .line 948
    move/from16 v5, v22

    .line 949
    .line 950
    new-array v5, v5, [Ljava/lang/Object;

    .line 951
    .line 952
    aput-object v3, v5, v21

    .line 953
    .line 954
    aput-object v0, v5, v19

    .line 955
    .line 956
    aput-object v2, v5, v20

    .line 957
    .line 958
    const/4 v14, 0x3

    .line 959
    aput-object v4, v5, v14

    .line 960
    .line 961
    aput-object v1, v5, v18

    .line 962
    .line 963
    invoke-static {v5}, Lzi1;->m([Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 964
    .line 965
    .line 966
    move-result-object v7

    .line 967
    :goto_3c6
    return-object v7

    .line 968
    :cond_3c7
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    .line 969
    .line 970
    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    .line 971
    .line 972
    .line 973
    throw v0

    .line 974
    :pswitch_3cd  #0x9
    move/from16 v20, v10

    .line 975
    .line 976
    move/from16 v19, v11

    .line 977
    .line 978
    move/from16 v21, v12

    .line 979
    .line 980
    check-cast v0, Liz0;

    .line 981
    .line 982
    move-object/from16 v0, p2

    .line 983
    .line 984
    check-cast v0, Lxm0;

    .line 985
    .line 986
    if-nez v0, :cond_3de

    .line 987
    .line 988
    move/from16 v1, v21

    .line 989
    .line 990
    goto :goto_3e9

    .line 991
    :cond_3de
    iget-wide v1, v0, Lxm0;->a:J

    .line 992
    .line 993
    const-wide v3, 0x7fc000007fc00000L  # 2.247117487993712E307

    .line 994
    .line 995
    .line 996
    .line 997
    .line 998
    invoke-static {v1, v2, v3, v4}, Lxm0;->b(JJ)Z

    .line 999
    .line 1000
    .line 1001
    move-result v1

    .line 1002
    :goto_3e9
    if-eqz v1, :cond_3ee

    .line 1003
    .line 1004
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 1005
    .line 1006
    goto :goto_419

    .line 1007
    :cond_3ee
    iget-wide v1, v0, Lxm0;->a:J

    .line 1008
    .line 1009
    const/16 v3, 0x20

    .line 1010
    .line 1011
    shr-long/2addr v1, v3

    .line 1012
    long-to-int v1, v1

    .line 1013
    invoke-static {v1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 1014
    .line 1015
    .line 1016
    move-result v1

    .line 1017
    invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 1018
    .line 1019
    .line 1020
    move-result-object v1

    .line 1021
    iget-wide v2, v0, Lxm0;->a:J

    .line 1022
    .line 1023
    const-wide v4, 0xffffffffL

    .line 1024
    .line 1025
    .line 1026
    .line 1027
    .line 1028
    and-long/2addr v2, v4

    .line 1029
    long-to-int v0, v2

    .line 1030
    invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 1031
    .line 1032
    .line 1033
    move-result v0

    .line 1034
    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 1035
    .line 1036
    .line 1037
    move-result-object v0

    .line 1038
    move/from16 v2, v20

    .line 1039
    .line 1040
    new-array v2, v2, [Ljava/lang/Float;

    .line 1041
    .line 1042
    aput-object v1, v2, v21

    .line 1043
    .line 1044
    aput-object v0, v2, v19

    .line 1045
    .line 1046
    invoke-static {v2}, Lzi1;->m([Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 1047
    .line 1048
    .line 1049
    move-result-object v0

    .line 1050
    :goto_419
    return-object v0

    .line 1051
    :pswitch_41a  #0x8
    move/from16 v19, v11

    .line 1052
    .line 1053
    move/from16 v21, v12

    .line 1054
    .line 1055
    check-cast v0, Liz0;

    .line 1056
    .line 1057
    move-object/from16 v0, p2

    .line 1058
    .line 1059
    check-cast v0, Lrb1;

    .line 1060
    .line 1061
    iget-wide v0, v0, Lrb1;->a:J

    .line 1062
    .line 1063
    const-wide v2, 0x200000000L

    .line 1064
    .line 1065
    .line 1066
    .line 1067
    .line 1068
    invoke-static {v0, v1, v2, v3}, Lrb1;->a(JJ)Z

    .line 1069
    .line 1070
    .line 1071
    move-result v2

    .line 1072
    if-eqz v2, :cond_436

    .line 1073
    .line 1074
    invoke-static/range {v21 .. v21}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1075
    .line 1076
    .line 1077
    move-result-object v0

    .line 1078
    goto :goto_448

    .line 1079
    :cond_436
    const-wide v2, 0x100000000L

    .line 1080
    .line 1081
    .line 1082
    .line 1083
    .line 1084
    invoke-static {v0, v1, v2, v3}, Lrb1;->a(JJ)Z

    .line 1085
    .line 1086
    .line 1087
    move-result v0

    .line 1088
    if-eqz v0, :cond_446

    .line 1089
    .line 1090
    invoke-static/range {v19 .. v19}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1091
    .line 1092
    .line 1093
    move-result-object v0

    .line 1094
    goto :goto_448

    .line 1095
    :cond_446
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 1096
    .line 1097
    :goto_448
    return-object v0

    .line 1098
    :pswitch_449  #0x7
    move/from16 v19, v11

    .line 1099
    .line 1100
    move/from16 v21, v12

    .line 1101
    .line 1102
    check-cast v0, Liz0;

    .line 1103
    .line 1104
    move-object/from16 v1, p2

    .line 1105
    .line 1106
    check-cast v1, Lle0;

    .line 1107
    .line 1108
    iget-object v2, v1, Lle0;->a:Ljava/lang/String;

    .line 1109
    .line 1110
    iget-object v1, v1, Lle0;->b:Leb1;

    .line 1111
    .line 1112
    sget-object v3, Le01;->i:Lal;

    .line 1113
    .line 1114
    invoke-static {v1, v3, v0}, Le01;->a(Ljava/lang/Object;La01;Liz0;)Ljava/lang/Object;

    .line 1115
    .line 1116
    .line 1117
    move-result-object v0

    .line 1118
    const/4 v1, 0x2

    .line 1119
    new-array v1, v1, [Ljava/lang/Object;

    .line 1120
    .line 1121
    aput-object v2, v1, v21

    .line 1122
    .line 1123
    aput-object v0, v1, v19

    .line 1124
    .line 1125
    invoke-static {v1}, Lzi1;->m([Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 1126
    .line 1127
    .line 1128
    move-result-object v0

    .line 1129
    return-object v0

    .line 1130
    :pswitch_469  #0x6
    move/from16 v19, v11

    .line 1131
    .line 1132
    move/from16 v21, v12

    .line 1133
    .line 1134
    check-cast v0, Liz0;

    .line 1135
    .line 1136
    move-object/from16 v1, p2

    .line 1137
    .line 1138
    check-cast v1, Lqb1;

    .line 1139
    .line 1140
    sget-wide v2, Lqb1;->c:J

    .line 1141
    .line 1142
    if-nez v1, :cond_47a

    .line 1143
    .line 1144
    move/from16 v2, v21

    .line 1145
    .line 1146
    goto :goto_480

    .line 1147
    :cond_47a
    iget-wide v4, v1, Lqb1;->a:J

    .line 1148
    .line 1149
    invoke-static {v4, v5, v2, v3}, Lqb1;->a(JJ)Z

    .line 1150
    .line 1151
    .line 1152
    move-result v2

    .line 1153
    :goto_480
    if-eqz v2, :cond_485

    .line 1154
    .line 1155
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 1156
    .line 1157
    goto :goto_4ab

    .line 1158
    :cond_485
    iget-wide v2, v1, Lqb1;->a:J

    .line 1159
    .line 1160
    invoke-static {v2, v3}, Lqb1;->c(J)F

    .line 1161
    .line 1162
    .line 1163
    move-result v2

    .line 1164
    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 1165
    .line 1166
    .line 1167
    move-result-object v2

    .line 1168
    iget-wide v3, v1, Lqb1;->a:J

    .line 1169
    .line 1170
    invoke-static {v3, v4}, Lqb1;->b(J)J

    .line 1171
    .line 1172
    .line 1173
    move-result-wide v3

    .line 1174
    new-instance v1, Lrb1;

    .line 1175
    .line 1176
    invoke-direct {v1, v3, v4}, Lrb1;-><init>(J)V

    .line 1177
    .line 1178
    .line 1179
    sget-object v3, Le01;->w:Ld01;

    .line 1180
    .line 1181
    invoke-static {v1, v3, v0}, Le01;->a(Ljava/lang/Object;La01;Liz0;)Ljava/lang/Object;

    .line 1182
    .line 1183
    .line 1184
    move-result-object v0

    .line 1185
    const/4 v1, 0x2

    .line 1186
    new-array v1, v1, [Ljava/lang/Object;

    .line 1187
    .line 1188
    aput-object v2, v1, v21

    .line 1189
    .line 1190
    aput-object v0, v1, v19

    .line 1191
    .line 1192
    invoke-static {v1}, Lzi1;->m([Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 1193
    .line 1194
    .line 1195
    move-result-object v0

    .line 1196
    :goto_4ab
    return-object v0

    .line 1197
    :pswitch_4ac  #0x5
    check-cast v0, Liz0;

    .line 1198
    .line 1199
    move-object/from16 v0, p2

    .line 1200
    .line 1201
    check-cast v0, Loz;

    .line 1202
    .line 1203
    iget v0, v0, Loz;->a:I

    .line 1204
    .line 1205
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1206
    .line 1207
    .line 1208
    move-result-object v0

    .line 1209
    return-object v0

    .line 1210
    :pswitch_4b9  #0x4
    check-cast v0, Liz0;

    .line 1211
    .line 1212
    move-object/from16 v0, p2

    .line 1213
    .line 1214
    check-cast v0, Lnz;

    .line 1215
    .line 1216
    iget v0, v0, Lnz;->a:I

    .line 1217
    .line 1218
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1219
    .line 1220
    .line 1221
    move-result-object v0

    .line 1222
    return-object v0

    .line 1223
    :pswitch_4c6  #0x3
    check-cast v0, Liz0;

    .line 1224
    .line 1225
    move-object/from16 v0, p2

    .line 1226
    .line 1227
    check-cast v0, Lo30;

    .line 1228
    .line 1229
    iget v0, v0, Lo30;->a:I

    .line 1230
    .line 1231
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1232
    .line 1233
    .line 1234
    move-result-object v0

    .line 1235
    return-object v0

    .line 1236
    :pswitch_4d3  #0x2
    check-cast v0, Liz0;

    .line 1237
    .line 1238
    move-object/from16 v0, p2

    .line 1239
    .line 1240
    check-cast v0, Lsa1;

    .line 1241
    .line 1242
    iget v0, v0, Lsa1;->a:I

    .line 1243
    .line 1244
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1245
    .line 1246
    .line 1247
    move-result-object v0

    .line 1248
    return-object v0

    .line 1249
    :pswitch_4e0  #0x1
    check-cast v0, Liz0;

    .line 1250
    .line 1251
    move-object/from16 v0, p2

    .line 1252
    .line 1253
    check-cast v0, Lna1;

    .line 1254
    .line 1255
    iget v0, v0, Lna1;->a:I

    .line 1256
    .line 1257
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1258
    .line 1259
    .line 1260
    move-result-object v0

    .line 1261
    return-object v0

    .line 1262
    :pswitch_4ed  #0x0
    move/from16 v19, v11

    .line 1263
    .line 1264
    move/from16 v21, v12

    .line 1265
    .line 1266
    check-cast v0, Liz0;

    .line 1267
    .line 1268
    move-object/from16 v1, p2

    .line 1269
    .line 1270
    check-cast v1, Lw41;

    .line 1271
    .line 1272
    iget-wide v2, v1, Lw41;->a:J

    .line 1273
    .line 1274
    new-instance v4, Lzg;

    .line 1275
    .line 1276
    invoke-direct {v4, v2, v3}, Lzg;-><init>(J)V

    .line 1277
    .line 1278
    .line 1279
    sget-object v2, Le01;->p:Ld01;

    .line 1280
    .line 1281
    invoke-static {v4, v2, v0}, Le01;->a(Ljava/lang/Object;La01;Liz0;)Ljava/lang/Object;

    .line 1282
    .line 1283
    .line 1284
    move-result-object v2

    .line 1285
    iget-wide v3, v1, Lw41;->b:J

    .line 1286
    .line 1287
    new-instance v5, Lxm0;

    .line 1288
    .line 1289
    invoke-direct {v5, v3, v4}, Lxm0;-><init>(J)V

    .line 1290
    .line 1291
    .line 1292
    sget-object v3, Le01;->x:Ld01;

    .line 1293
    .line 1294
    invoke-static {v5, v3, v0}, Le01;->a(Ljava/lang/Object;La01;Liz0;)Ljava/lang/Object;

    .line 1295
    .line 1296
    .line 1297
    move-result-object v0

    .line 1298
    iget v1, v1, Lw41;->c:F

    .line 1299
    .line 1300
    invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 1301
    .line 1302
    .line 1303
    move-result-object v1

    .line 1304
    const/4 v14, 0x3

    .line 1305
    new-array v3, v14, [Ljava/lang/Object;

    .line 1306
    .line 1307
    aput-object v2, v3, v21

    .line 1308
    .line 1309
    aput-object v0, v3, v19

    .line 1310
    .line 1311
    const/16 v20, 0x2

    .line 1312
    .line 1313
    aput-object v1, v3, v20

    .line 1314
    .line 1315
    invoke-static {v3}, Lzi1;->m([Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 1316
    .line 1317
    .line 1318
    move-result-object v0

    .line 1319
    return-object v0

    .line 1320
    nop

    .line 1321
    :pswitch_data_528
    .packed-switch 0x0
        :pswitch_4ed  #00000000
        :pswitch_4e0  #00000001
        :pswitch_4d3  #00000002
        :pswitch_4c6  #00000003
        :pswitch_4b9  #00000004
        :pswitch_4ac  #00000005
        :pswitch_469  #00000006
        :pswitch_449  #00000007
        :pswitch_41a  #00000008
        :pswitch_3cd  #00000009
        :pswitch_308  #0000000a
        :pswitch_2dc  #0000000b
        :pswitch_2cf  #0000000c
        :pswitch_28b  #0000000d
        :pswitch_27e  #0000000e
        :pswitch_271  #0000000f
        :pswitch_264  #00000010
        :pswitch_25b  #00000011
        :pswitch_1c5  #00000012
        :pswitch_1bc  #00000013
        :pswitch_f1  #00000014
        :pswitch_c2  #00000015
        :pswitch_9c  #00000016
        :pswitch_8f  #00000017
        :pswitch_82  #00000018
        :pswitch_5e  #00000019
        :pswitch_51  #0000001a
        :pswitch_40  #0000001b
        :pswitch_1f  #0000001c
    .end packed-switch

    .line 1322
    .line 1323
    .line 1324
    .line 1325
    .line 1326
    .line 1327
    .line 1328
    .line 1329
    .line 1330
    .line 1331
    .line 1332
    .line 1333
    .line 1334
    .line 1335
    .line 1336
    .line 1337
    .line 1338
    .line 1339
    .line 1340
    .line 1341
    .line 1342
    .line 1343
    .line 1344
    .line 1345
    .line 1346
    .line 1347
    .line 1348
    .line 1349
    .line 1350
    .line 1351
    .line 1352
    .line 1353
    .line 1354
    .line 1355
    .line 1356
    .line 1357
    .line 1358
    .line 1359
    .line 1360
    .line 1361
    .line 1362
    .line 1363
    .line 1364
    .line 1365
    .line 1366
    .line 1367
    .line 1368
    .line 1369
    .line 1370
    .line 1371
    .line 1372
    .line 1373
    .line 1374
    .line 1375
    .line 1376
    .line 1377
    .line 1378
    .line 1379
    .line 1380
    .line 1381
    .line 1382
    .line 1383
    :pswitch_data_566
    .packed-switch 0x0
        :pswitch_39a  #00000000
        :pswitch_38e  #00000001
        :pswitch_382  #00000002
        :pswitch_376  #00000003
        :pswitch_36a  #00000004
        :pswitch_35e  #00000005
        :pswitch_356  #00000006
    .end packed-switch
.end method
