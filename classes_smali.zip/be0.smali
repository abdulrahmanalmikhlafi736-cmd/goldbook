.class public final Lbe0;
.super Lul;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lbp;


# static fields
.field public static final synthetic l:Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;


# instance fields
.field public final synthetic g:Lbp;

.field public final h:Lul;

.field public final i:I

.field public final j:Lpf0;

.field public final k:Ljava/lang/Object;

.field private volatile synthetic runningWorkers$volatile:I


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    const-class v0, Lbe0;

    .line 2
    .line 3
    const-string v1, "runningWorkers$volatile"

    .line 4
    .line 5
    invoke-static {v0, v1}, Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;->newUpdater(Ljava/lang/Class;Ljava/lang/String;)Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    sput-object v0, Lbe0;->l:Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

    .line 10
    .line 11
    return-void
.end method

.method public constructor <init>(Lul;I)V
    .registers 4

    .line 1
    invoke-direct {p0}, Lul;-><init>()V

    .line 2
    .line 3
    .line 4
    instance-of v0, p1, Lbp;

    .line 5
    .line 6
    if-eqz v0, :cond_b

    .line 7
    .line 8
    move-object v0, p1

    .line 9
    check-cast v0, Lbp;

    .line 10
    .line 11
    goto :goto_c

    .line 12
    :cond_b
    const/4 v0, 0x0

    .line 13
    :goto_c
    if-nez v0, :cond_10

    .line 14
    .line 15
    sget-object v0, Lgo;->a:Lbp;

    .line 16
    .line 17
    :cond_10
    iput-object v0, p0, Lbe0;->g:Lbp;

    .line 18
    .line 19
    iput-object p1, p0, Lbe0;->h:Lul;

    .line 20
    .line 21
    iput p2, p0, Lbe0;->i:I

    .line 22
    .line 23
    new-instance p1, Lpf0;

    .line 24
    .line 25
    invoke-direct {p1}, Lpf0;-><init>()V

    .line 26
    .line 27
    .line 28
    iput-object p1, p0, Lbe0;->j:Lpf0;

    .line 29
    .line 30
    new-instance p1, Ljava/lang/Object;

    .line 31
    .line 32
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 33
    .line 34
    .line 35
    iput-object p1, p0, Lbe0;->k:Ljava/lang/Object;

    .line 36
    .line 37
    return-void
.end method


# virtual methods
.method public final c(JLjc1;Lsl;)Lsq;
    .registers 5

    .line 1
    iget-object p0, p0, Lbe0;->g:Lbp;

    .line 2
    .line 3
    invoke-interface {p0, p1, p2, p3, p4}, Lbp;->c(JLjc1;Lsl;)Lsq;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    return-object p0
.end method

.method public final d(JLne;)V
    .registers 4

    .line 1
    iget-object p0, p0, Lbe0;->g:Lbp;

    .line 2
    .line 3
    invoke-interface {p0, p1, p2, p3}, Lbp;->d(JLne;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final e(Lsl;Ljava/lang/Runnable;)V
    .registers 6

    .line 1
    iget-object p1, p0, Lbe0;->j:Lpf0;

    .line 2
    .line 3
    invoke-virtual {p1, p2}, Lpf0;->a(Ljava/lang/Runnable;)Z

    .line 4
    .line 5
    .line 6
    sget-object p1, Lbe0;->l:Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

    .line 7
    .line 8
    invoke-virtual {p1, p0}, Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;->get(Ljava/lang/Object;)I

    .line 9
    .line 10
    .line 11
    move-result p2

    .line 12
    iget v0, p0, Lbe0;->i:I

    .line 13
    .line 14
    if-ge p2, v0, :cond_40

    .line 15
    .line 16
    iget-object p2, p0, Lbe0;->k:Ljava/lang/Object;

    .line 17
    .line 18
    monitor-enter p2

    .line 19
    :try_start_12
    sget-object v0, Lbe0;->l:Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

    .line 20
    .line 21
    invoke-virtual {v0, p0}, Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;->get(Ljava/lang/Object;)I

    .line 22
    .line 23
    .line 24
    move-result v1

    .line 25
    iget v2, p0, Lbe0;->i:I
    :try_end_1a
    .catchall {:try_start_12 .. :try_end_1a} :catchall_3d

    .line 26
    .line 27
    if-lt v1, v2, :cond_1f

    .line 28
    .line 29
    monitor-exit p2

    .line 30
    const/4 p2, 0x0

    .line 31
    goto :goto_24

    .line 32
    :cond_1f
    :try_start_1f
    invoke-virtual {v0, p0}, Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;->incrementAndGet(Ljava/lang/Object;)I
    :try_end_22
    .catchall {:try_start_1f .. :try_end_22} :catchall_3d

    .line 33
    .line 34
    .line 35
    monitor-exit p2

    .line 36
    const/4 p2, 0x1

    .line 37
    :goto_24
    if-eqz p2, :cond_40

    .line 38
    .line 39
    invoke-virtual {p0}, Lbe0;->j()Ljava/lang/Runnable;

    .line 40
    .line 41
    .line 42
    move-result-object p2

    .line 43
    if-nez p2, :cond_2d

    .line 44
    .line 45
    goto :goto_40

    .line 46
    :cond_2d
    :try_start_2d
    new-instance v0, Lae0;

    .line 47
    .line 48
    invoke-direct {v0, p0, p2}, Lae0;-><init>(Lbe0;Ljava/lang/Runnable;)V

    .line 49
    .line 50
    .line 51
    iget-object p2, p0, Lbe0;->h:Lul;

    .line 52
    .line 53
    invoke-static {p2, p0, v0}, Lwl1;->H(Lul;Lsl;Ljava/lang/Runnable;)V
    :try_end_37
    .catchall {:try_start_2d .. :try_end_37} :catchall_38

    .line 54
    .line 55
    .line 56
    return-void

    .line 57
    :catchall_38
    move-exception p2

    .line 58
    invoke-virtual {p1, p0}, Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;->decrementAndGet(Ljava/lang/Object;)I

    .line 59
    .line 60
    .line 61
    throw p2

    .line 62
    :catchall_3d
    move-exception p0

    .line 63
    monitor-exit p2

    .line 64
    throw p0

    .line 65
    :cond_40
    :goto_40
    return-void
.end method

.method public final j()Ljava/lang/Runnable;
    .registers 4

    .line 1
    :goto_0
    iget-object v0, p0, Lbe0;->j:Lpf0;

    .line 2
    .line 3
    invoke-virtual {v0}, Lpf0;->d()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Ljava/lang/Runnable;

    .line 8
    .line 9
    if-nez v0, :cond_25

    .line 10
    .line 11
    iget-object v0, p0, Lbe0;->k:Ljava/lang/Object;

    .line 12
    .line 13
    monitor-enter v0

    .line 14
    :try_start_d
    sget-object v1, Lbe0;->l:Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

    .line 15
    .line 16
    invoke-virtual {v1, p0}, Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;->decrementAndGet(Ljava/lang/Object;)I

    .line 17
    .line 18
    .line 19
    iget-object v2, p0, Lbe0;->j:Lpf0;

    .line 20
    .line 21
    invoke-virtual {v2}, Lpf0;->c()I

    .line 22
    .line 23
    .line 24
    move-result v2
    :try_end_18
    .catchall {:try_start_d .. :try_end_18} :catchall_22

    .line 25
    if-nez v2, :cond_1d

    .line 26
    .line 27
    monitor-exit v0

    .line 28
    const/4 p0, 0x0

    .line 29
    return-object p0

    .line 30
    :cond_1d
    :try_start_1d
    invoke-virtual {v1, p0}, Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;->incrementAndGet(Ljava/lang/Object;)I
    :try_end_20
    .catchall {:try_start_1d .. :try_end_20} :catchall_22

    .line 31
    .line 32
    .line 33
    monitor-exit v0

    .line 34
    goto :goto_0

    .line 35
    :catchall_22
    move-exception p0

    .line 36
    monitor-exit v0

    .line 37
    throw p0

    .line 38
    :cond_25
    return-object v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 4
    .line 5
    .line 6
    iget-object v1, p0, Lbe0;->h:Lul;

    .line 7
    .line 8
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 9
    .line 10
    .line 11
    const-string v1, ".limitedParallelism("

    .line 12
    .line 13
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 14
    .line 15
    .line 16
    iget p0, p0, Lbe0;->i:I

    .line 17
    .line 18
    const/16 v1, 0x29

    .line 19
    .line 20
    invoke-static {v0, p0, v1}, Lfu0;->G(Ljava/lang/StringBuilder;IC)Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object p0

    .line 24
    return-object p0
.end method
