.class public final Ldu;
.super Lh90;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Li00;


# instance fields
.field public final synthetic f:Z

.field public final synthetic g:Lxz;


# direct methods
.method public constructor <init>(ZLxz;)V
    .registers 3

    .line 1
    iput-boolean p1, p0, Ldu;->f:Z

    .line 2
    .line 3
    iput-object p2, p0, Ldu;->g:Lxz;

    .line 4
    .line 5
    const/4 p1, 0x1

    .line 6
    invoke-direct {p0, p1}, Lh90;-><init>(I)V

    .line 7
    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final i(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 1
    check-cast p1, Lsx0;

    .line 2
    .line 3
    iget-boolean v0, p0, Ldu;->f:Z

    .line 4
    .line 5
    if-nez v0, :cond_16

    .line 6
    .line 7
    iget-object p0, p0, Ldu;->g:Lxz;

    .line 8
    .line 9
    invoke-interface {p0}, Lxz;->a()Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    check-cast p0, Ljava/lang/Boolean;

    .line 14
    .line 15
    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 16
    .line 17
    .line 18
    move-result p0

    .line 19
    if-eqz p0, :cond_16

    .line 20
    .line 21
    const/4 p0, 0x1

    .line 22
    goto :goto_17

    .line 23
    :cond_16
    const/4 p0, 0x0

    .line 24
    :goto_17
    iget-boolean v0, p1, Lsx0;->o:Z

    .line 25
    .line 26
    if-eq v0, p0, :cond_23

    .line 27
    .line 28
    iget v0, p1, Lsx0;->e:I

    .line 29
    .line 30
    or-int/lit16 v0, v0, 0x4000

    .line 31
    .line 32
    iput v0, p1, Lsx0;->e:I

    .line 33
    .line 34
    iput-boolean p0, p1, Lsx0;->o:Z

    .line 35
    .line 36
    :cond_23
    sget-object p0, Lwe1;->a:Lwe1;

    .line 37
    .line 38
    return-object p0
.end method
