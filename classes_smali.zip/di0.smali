.class public final Ldi0;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# static fields
.field public static h:Ldi0;


# instance fields
.field public final a:Lo90;

.field public final b:Lob1;

.field public final c:Lmp;

.field public final d:Lyy;

.field public final e:Lob1;

.field public f:F

.field public g:F


# direct methods
.method public constructor <init>(Lo90;Lob1;Lmp;Lyy;)V
    .registers 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Ldi0;->a:Lo90;

    .line 5
    .line 6
    iput-object p2, p0, Ldi0;->b:Lob1;

    .line 7
    .line 8
    iput-object p3, p0, Ldi0;->c:Lmp;

    .line 9
    .line 10
    iput-object p4, p0, Ldi0;->d:Lyy;

    .line 11
    .line 12
    invoke-static {p2, p1}, Lwa0;->v(Lob1;Lo90;)Lob1;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    iput-object p1, p0, Ldi0;->e:Lob1;

    .line 17
    .line 18
    const/high16 p1, 0x7fc00000  # Float.NaN

    .line 19
    .line 20
    iput p1, p0, Ldi0;->f:F

    .line 21
    .line 22
    iput p1, p0, Ldi0;->g:F

    .line 23
    .line 24
    return-void
.end method
