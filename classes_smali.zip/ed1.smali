.class public final Led1;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# instance fields
.field public final a:Lal;

.field public final b:Led1;

.field public final c:Ljava/lang/String;

.field public final d:Llq0;

.field public final e:Llq0;

.field public final f:Ljq0;

.field public final g:Ljq0;

.field public final h:Llq0;

.field public final i:Lz61;

.field public final j:Lz61;

.field public final k:Llq0;


# direct methods
.method public constructor <init>(Lal;Led1;Ljava/lang/String;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Led1;->a:Lal;

    .line 5
    .line 6
    iput-object p2, p0, Led1;->b:Led1;

    .line 7
    .line 8
    iput-object p3, p0, Led1;->c:Ljava/lang/String;

    .line 9
    .line 10
    invoke-virtual {p0}, Led1;->c()Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    invoke-static {p1}, Lmc0;->t(Ljava/lang/Object;)Llq0;

    .line 15
    .line 16
    .line 17
    move-result-object p1

    .line 18
    iput-object p1, p0, Led1;->d:Llq0;

    .line 19
    .line 20
    new-instance p1, Lad1;

    .line 21
    .line 22
    invoke-virtual {p0}, Led1;->c()Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object p2

    .line 26
    invoke-virtual {p0}, Led1;->c()Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object p3

    .line 30
    invoke-direct {p1, p2, p3}, Lad1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    invoke-static {p1}, Lmc0;->t(Ljava/lang/Object;)Llq0;

    .line 34
    .line 35
    .line 36
    move-result-object p1

    .line 37
    iput-object p1, p0, Led1;->e:Llq0;

    .line 38
    .line 39
    new-instance p1, Ljq0;

    .line 40
    .line 41
    const-wide/16 p2, 0x0

    .line 42
    .line 43
    invoke-direct {p1, p2, p3}, Ljq0;-><init>(J)V

    .line 44
    .line 45
    .line 46
    iput-object p1, p0, Led1;->f:Ljq0;

    .line 47
    .line 48
    new-instance p1, Ljq0;

    .line 49
    .line 50
    const-wide/high16 p2, -0x8000000000000000L

    .line 51
    .line 52
    invoke-direct {p1, p2, p3}, Ljq0;-><init>(J)V

    .line 53
    .line 54
    .line 55
    iput-object p1, p0, Led1;->g:Ljq0;

    .line 56
    .line 57
    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 58
    .line 59
    invoke-static {p1}, Lmc0;->t(Ljava/lang/Object;)Llq0;

    .line 60
    .line 61
    .line 62
    move-result-object p2

    .line 63
    iput-object p2, p0, Led1;->h:Llq0;

    .line 64
    .line 65
    new-instance p2, Lz61;

    .line 66
    .line 67
    invoke-direct {p2}, Lz61;-><init>()V

    .line 68
    .line 69
    .line 70
    iput-object p2, p0, Led1;->i:Lz61;

    .line 71
    .line 72
    new-instance p2, Lz61;

    .line 73
    .line 74
    invoke-direct {p2}, Lz61;-><init>()V

    .line 75
    .line 76
    .line 77
    iput-object p2, p0, Led1;->j:Lz61;

    .line 78
    .line 79
    invoke-static {p1}, Lmc0;->t(Ljava/lang/Object;)Llq0;

    .line 80
    .line 81
    .line 82
    move-result-object p1

    .line 83
    iput-object p1, p0, Led1;->k:Llq0;

    .line 84
    .line 85
    new-instance p1, Lxc1;

    .line 86
    .line 87
    const/4 p2, 0x1

    .line 88
    invoke-direct {p1, p0, p2}, Lxc1;-><init>(Led1;I)V

    .line 89
    .line 90
    .line 91
    invoke-static {p1}, Lmc0;->j(Lxz;)Lsp;

    .line 92
    .line 93
    .line 94
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;Ld10;I)V
    .registers 12

    .line 1
    const v0, -0x59064cff

    .line 2
    .line 3
    .line 4
    invoke-virtual {p2, v0}, Ld10;->X(I)Ld10;

    .line 5
    .line 6
    .line 7
    and-int/lit8 v0, p3, 0x6

    .line 8
    .line 9
    const/4 v1, 0x4

    .line 10
    if-nez v0, :cond_1f

    .line 11
    .line 12
    and-int/lit8 v0, p3, 0x8

    .line 13
    .line 14
    if-nez v0, :cond_14

    .line 15
    .line 16
    invoke-virtual {p2, p1}, Ld10;->f(Ljava/lang/Object;)Z

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    goto :goto_18

    .line 21
    :cond_14
    invoke-virtual {p2, p1}, Ld10;->h(Ljava/lang/Object;)Z

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    :goto_18
    if-eqz v0, :cond_1c

    .line 26
    .line 27
    move v0, v1

    .line 28
    goto :goto_1d

    .line 29
    :cond_1c
    const/4 v0, 0x2

    .line 30
    :goto_1d
    or-int/2addr v0, p3

    .line 31
    goto :goto_20

    .line 32
    :cond_1f
    move v0, p3

    .line 33
    :goto_20
    and-int/lit8 v2, p3, 0x30

    .line 34
    .line 35
    const/16 v3, 0x20

    .line 36
    .line 37
    if-nez v2, :cond_31

    .line 38
    .line 39
    invoke-virtual {p2, p0}, Ld10;->f(Ljava/lang/Object;)Z

    .line 40
    .line 41
    .line 42
    move-result v2

    .line 43
    if-eqz v2, :cond_2e

    .line 44
    .line 45
    move v2, v3

    .line 46
    goto :goto_30

    .line 47
    :cond_2e
    const/16 v2, 0x10

    .line 48
    .line 49
    :goto_30
    or-int/2addr v0, v2

    .line 50
    :cond_31
    and-int/lit8 v2, v0, 0x13

    .line 51
    .line 52
    const/16 v4, 0x12

    .line 53
    .line 54
    const/4 v5, 0x1

    .line 55
    const/4 v6, 0x0

    .line 56
    if-eq v2, v4, :cond_3b

    .line 57
    .line 58
    move v2, v5

    .line 59
    goto :goto_3c

    .line 60
    :cond_3b
    move v2, v6

    .line 61
    :goto_3c
    and-int/lit8 v4, v0, 0x1

    .line 62
    .line 63
    invoke-virtual {p2, v4, v2}, Ld10;->O(IZ)Z

    .line 64
    .line 65
    .line 66
    move-result v2

    .line 67
    if-eqz v2, :cond_cf

    .line 68
    .line 69
    invoke-virtual {p0}, Led1;->g()Z

    .line 70
    .line 71
    .line 72
    move-result v2

    .line 73
    if-nez v2, :cond_c5

    .line 74
    .line 75
    const v2, 0x1bc78ba1

    .line 76
    .line 77
    .line 78
    invoke-virtual {p2, v2}, Ld10;->W(I)V

    .line 79
    .line 80
    .line 81
    invoke-virtual {p0, p1}, Led1;->k(Ljava/lang/Object;)V

    .line 82
    .line 83
    .line 84
    and-int/lit8 v0, v0, 0x70

    .line 85
    .line 86
    if-ne v0, v3, :cond_59

    .line 87
    .line 88
    move v2, v5

    .line 89
    goto :goto_5a

    .line 90
    :cond_59
    move v2, v6

    .line 91
    :goto_5a
    invoke-virtual {p2}, Ld10;->L()Ljava/lang/Object;

    .line 92
    .line 93
    .line 94
    move-result-object v4

    .line 95
    sget-object v7, Loj;->a:Lnq0;

    .line 96
    .line 97
    if-nez v2, :cond_64

    .line 98
    .line 99
    if-ne v4, v7, :cond_70

    .line 100
    .line 101
    :cond_64
    new-instance v2, Lxc1;

    .line 102
    .line 103
    invoke-direct {v2, p0, v6}, Lxc1;-><init>(Led1;I)V

    .line 104
    .line 105
    .line 106
    invoke-static {v2}, Lmc0;->j(Lxz;)Lsp;

    .line 107
    .line 108
    .line 109
    move-result-object v4

    .line 110
    invoke-virtual {p2, v4}, Ld10;->g0(Ljava/lang/Object;)V

    .line 111
    .line 112
    .line 113
    :cond_70
    check-cast v4, La81;

    .line 114
    .line 115
    invoke-interface {v4}, La81;->getValue()Ljava/lang/Object;

    .line 116
    .line 117
    .line 118
    move-result-object v2

    .line 119
    check-cast v2, Ljava/lang/Boolean;

    .line 120
    .line 121
    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 122
    .line 123
    .line 124
    move-result v2

    .line 125
    if-eqz v2, :cond_b8

    .line 126
    .line 127
    const v2, 0x1bcdc5d4

    .line 128
    .line 129
    .line 130
    invoke-virtual {p2, v2}, Ld10;->W(I)V

    .line 131
    .line 132
    .line 133
    invoke-virtual {p2}, Ld10;->L()Ljava/lang/Object;

    .line 134
    .line 135
    .line 136
    move-result-object v2

    .line 137
    if-ne v2, v7, :cond_91

    .line 138
    .line 139
    invoke-static {p2}, Lj70;->y(Ld10;)Lbm;

    .line 140
    .line 141
    .line 142
    move-result-object v2

    .line 143
    invoke-virtual {p2, v2}, Ld10;->g0(Ljava/lang/Object;)V

    .line 144
    .line 145
    .line 146
    :cond_91
    check-cast v2, Lbm;

    .line 147
    .line 148
    invoke-virtual {p2, v2}, Ld10;->h(Ljava/lang/Object;)Z

    .line 149
    .line 150
    .line 151
    move-result v4

    .line 152
    if-ne v0, v3, :cond_9a

    .line 153
    .line 154
    goto :goto_9b

    .line 155
    :cond_9a
    move v5, v6

    .line 156
    :goto_9b
    or-int v0, v4, v5

    .line 157
    .line 158
    invoke-virtual {p2}, Ld10;->L()Ljava/lang/Object;

    .line 159
    .line 160
    .line 161
    move-result-object v3

    .line 162
    if-nez v0, :cond_a5

    .line 163
    .line 164
    if-ne v3, v7, :cond_af

    .line 165
    .line 166
    :cond_a5
    new-instance v3, Lc;

    .line 167
    .line 168
    const/16 v0, 0x18

    .line 169
    .line 170
    invoke-direct {v3, v0, v2, p0}, Lc;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 171
    .line 172
    .line 173
    invoke-virtual {p2, v3}, Ld10;->g0(Ljava/lang/Object;)V

    .line 174
    .line 175
    .line 176
    :cond_af
    check-cast v3, Li00;

    .line 177
    .line 178
    invoke-static {v2, p0, v3, p2}, Lj70;->c(Ljava/lang/Object;Ljava/lang/Object;Li00;Ld10;)V

    .line 179
    .line 180
    .line 181
    invoke-virtual {p2, v6}, Ld10;->p(Z)V

    .line 182
    .line 183
    .line 184
    goto :goto_c1

    .line 185
    :cond_b8
    const v0, 0x1be0bba1

    .line 186
    .line 187
    .line 188
    invoke-virtual {p2, v0}, Ld10;->W(I)V

    .line 189
    .line 190
    .line 191
    invoke-virtual {p2, v6}, Ld10;->p(Z)V

    .line 192
    .line 193
    .line 194
    :goto_c1
    invoke-virtual {p2, v6}, Ld10;->p(Z)V

    .line 195
    .line 196
    .line 197
    goto :goto_d2

    .line 198
    :cond_c5
    const v0, 0x1be0e261

    .line 199
    .line 200
    .line 201
    invoke-virtual {p2, v0}, Ld10;->W(I)V

    .line 202
    .line 203
    .line 204
    invoke-virtual {p2, v6}, Ld10;->p(Z)V

    .line 205
    .line 206
    .line 207
    goto :goto_d2

    .line 208
    :cond_cf
    invoke-virtual {p2}, Ld10;->R()V

    .line 209
    .line 210
    .line 211
    :goto_d2
    invoke-virtual {p2}, Ld10;->r()Lxv0;

    .line 212
    .line 213
    .line 214
    move-result-object p2

    .line 215
    if-eqz p2, :cond_df

    .line 216
    .line 217
    new-instance v0, Lni;

    .line 218
    .line 219
    invoke-direct {v0, p3, v1, p0, p1}, Lni;-><init>(IILjava/lang/Object;Ljava/lang/Object;)V

    .line 220
    .line 221
    .line 222
    iput-object v0, p2, Lxv0;->d:Lm00;

    .line 223
    .line 224
    :cond_df
    return-void
.end method

.method public final b()J
    .registers 9

    .line 1
    iget-object v0, p0, Led1;->i:Lz61;

    .line 2
    .line 3
    invoke-virtual {v0}, Lz61;->size()I

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    const-wide/16 v2, 0x0

    .line 8
    .line 9
    const/4 v4, 0x0

    .line 10
    move v5, v4

    .line 11
    :goto_a
    if-ge v5, v1, :cond_1f

    .line 12
    .line 13
    invoke-virtual {v0, v5}, Lz61;->get(I)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v6

    .line 17
    check-cast v6, Lbd1;

    .line 18
    .line 19
    iget-object v6, v6, Lbd1;->n:Ljq0;

    .line 20
    .line 21
    invoke-virtual {v6}, Ljq0;->g()J

    .line 22
    .line 23
    .line 24
    move-result-wide v6

    .line 25
    invoke-static {v2, v3, v6, v7}, Ljava/lang/Math;->max(JJ)J

    .line 26
    .line 27
    .line 28
    move-result-wide v2

    .line 29
    add-int/lit8 v5, v5, 0x1

    .line 30
    .line 31
    goto :goto_a

    .line 32
    :cond_1f
    iget-object p0, p0, Led1;->j:Lz61;

    .line 33
    .line 34
    invoke-virtual {p0}, Lz61;->size()I

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    :goto_25
    if-ge v4, v0, :cond_38

    .line 39
    .line 40
    invoke-virtual {p0, v4}, Lz61;->get(I)Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object v1

    .line 44
    check-cast v1, Led1;

    .line 45
    .line 46
    invoke-virtual {v1}, Led1;->b()J

    .line 47
    .line 48
    .line 49
    move-result-wide v5

    .line 50
    invoke-static {v2, v3, v5, v6}, Ljava/lang/Math;->max(JJ)J

    .line 51
    .line 52
    .line 53
    move-result-wide v2

    .line 54
    add-int/lit8 v4, v4, 0x1

    .line 55
    .line 56
    goto :goto_25

    .line 57
    :cond_38
    return-wide v2
.end method

.method public final c()Ljava/lang/Object;
    .registers 1

    .line 1
    iget-object p0, p0, Led1;->a:Lal;

    .line 2
    .line 3
    iget-object p0, p0, Lal;->g:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast p0, Llq0;

    .line 6
    .line 7
    invoke-virtual {p0}, Llq0;->getValue()Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object p0

    .line 11
    return-object p0
.end method

.method public final d()Z
    .registers 6

    .line 1
    iget-object v0, p0, Led1;->i:Lz61;

    .line 2
    .line 3
    invoke-interface {v0}, Ljava/util/Collection;->size()I

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    const/4 v2, 0x0

    .line 8
    move v3, v2

    .line 9
    :goto_8
    if-ge v3, v1, :cond_16

    .line 10
    .line 11
    invoke-interface {v0, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v4

    .line 15
    check-cast v4, Lbd1;

    .line 16
    .line 17
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 18
    .line 19
    .line 20
    add-int/lit8 v3, v3, 0x1

    .line 21
    .line 22
    goto :goto_8

    .line 23
    :cond_16
    iget-object p0, p0, Led1;->j:Lz61;

    .line 24
    .line 25
    invoke-interface {p0}, Ljava/util/Collection;->size()I

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    move v1, v2

    .line 30
    :goto_1d
    if-ge v1, v0, :cond_30

    .line 31
    .line 32
    invoke-interface {p0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    move-result-object v3

    .line 36
    check-cast v3, Led1;

    .line 37
    .line 38
    invoke-virtual {v3}, Led1;->d()Z

    .line 39
    .line 40
    .line 41
    move-result v3

    .line 42
    if-eqz v3, :cond_2d

    .line 43
    .line 44
    const/4 p0, 0x1

    .line 45
    return p0

    .line 46
    :cond_2d
    add-int/lit8 v1, v1, 0x1

    .line 47
    .line 48
    goto :goto_1d

    .line 49
    :cond_30
    return v2
.end method

.method public final e()J
    .registers 3

    .line 1
    iget-object v0, p0, Led1;->b:Led1;

    .line 2
    .line 3
    if-eqz v0, :cond_9

    .line 4
    .line 5
    invoke-virtual {v0}, Led1;->e()J

    .line 6
    .line 7
    .line 8
    move-result-wide v0

    .line 9
    return-wide v0

    .line 10
    :cond_9
    iget-object p0, p0, Led1;->f:Ljq0;

    .line 11
    .line 12
    invoke-virtual {p0}, Ljq0;->g()J

    .line 13
    .line 14
    .line 15
    move-result-wide v0

    .line 16
    return-wide v0
.end method

.method public final f()Lad1;
    .registers 1

    .line 1
    iget-object p0, p0, Led1;->e:Llq0;

    .line 2
    .line 3
    invoke-virtual {p0}, Llq0;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Lad1;

    .line 8
    .line 9
    return-object p0
.end method

.method public final g()Z
    .registers 1

    .line 1
    iget-object p0, p0, Led1;->k:Llq0;

    .line 2
    .line 3
    invoke-virtual {p0}, Llq0;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Ljava/lang/Boolean;

    .line 8
    .line 9
    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 10
    .line 11
    .line 12
    move-result p0

    .line 13
    return p0
.end method

.method public final h(JZ)V
    .registers 15

    .line 1
    iget-object v0, p0, Led1;->a:Lal;

    .line 2
    .line 3
    iget-object v1, v0, Lal;->f:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v1, Llq0;

    .line 6
    .line 7
    iget-object v2, p0, Led1;->g:Ljq0;

    .line 8
    .line 9
    invoke-virtual {v2}, Ljq0;->g()J

    .line 10
    .line 11
    .line 12
    move-result-wide v3

    .line 13
    const-wide/high16 v5, -0x8000000000000000L

    .line 14
    .line 15
    cmp-long v3, v3, v5

    .line 16
    .line 17
    if-nez v3, :cond_1f

    .line 18
    .line 19
    invoke-virtual {v2, p1, p2}, Ljq0;->h(J)V

    .line 20
    .line 21
    .line 22
    iget-object v0, v0, Lal;->f:Ljava/lang/Object;

    .line 23
    .line 24
    check-cast v0, Llq0;

    .line 25
    .line 26
    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 27
    .line 28
    invoke-virtual {v0, v1}, Llq0;->setValue(Ljava/lang/Object;)V

    .line 29
    .line 30
    .line 31
    goto :goto_30

    .line 32
    :cond_1f
    invoke-virtual {v1}, Llq0;->getValue()Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    check-cast v0, Ljava/lang/Boolean;

    .line 37
    .line 38
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    if-nez v0, :cond_30

    .line 43
    .line 44
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 45
    .line 46
    invoke-virtual {v1, v0}, Llq0;->setValue(Ljava/lang/Object;)V

    .line 47
    .line 48
    .line 49
    :cond_30
    :goto_30
    iget-object v0, p0, Led1;->h:Llq0;

    .line 50
    .line 51
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 52
    .line 53
    invoke-virtual {v0, v1}, Llq0;->setValue(Ljava/lang/Object;)V

    .line 54
    .line 55
    .line 56
    iget-object v0, p0, Led1;->i:Lz61;

    .line 57
    .line 58
    invoke-virtual {v0}, Lz61;->size()I

    .line 59
    .line 60
    .line 61
    move-result v1

    .line 62
    const/4 v2, 0x0

    .line 63
    const/4 v3, 0x1

    .line 64
    move v4, v2

    .line 65
    :goto_40
    if-ge v4, v1, :cond_9d

    .line 66
    .line 67
    invoke-virtual {v0, v4}, Lz61;->get(I)Ljava/lang/Object;

    .line 68
    .line 69
    .line 70
    move-result-object v5

    .line 71
    check-cast v5, Lbd1;

    .line 72
    .line 73
    iget-object v6, v5, Lbd1;->i:Llq0;

    .line 74
    .line 75
    iget-object v7, v5, Lbd1;->i:Llq0;

    .line 76
    .line 77
    invoke-virtual {v6}, Llq0;->getValue()Ljava/lang/Object;

    .line 78
    .line 79
    .line 80
    move-result-object v6

    .line 81
    check-cast v6, Ljava/lang/Boolean;

    .line 82
    .line 83
    invoke-virtual {v6}, Ljava/lang/Boolean;->booleanValue()Z

    .line 84
    .line 85
    .line 86
    move-result v6

    .line 87
    if-nez v6, :cond_8d

    .line 88
    .line 89
    if-eqz p3, :cond_63

    .line 90
    .line 91
    invoke-virtual {v5}, Lbd1;->a()Lja1;

    .line 92
    .line 93
    .line 94
    move-result-object v6

    .line 95
    invoke-virtual {v6}, Lja1;->c()J

    .line 96
    .line 97
    .line 98
    move-result-wide v8

    .line 99
    goto :goto_64

    .line 100
    :cond_63
    move-wide v8, p1

    .line 101
    :goto_64
    invoke-virtual {v5}, Lbd1;->a()Lja1;

    .line 102
    .line 103
    .line 104
    move-result-object v6

    .line 105
    invoke-virtual {v6, v8, v9}, Lja1;->b(J)Ljava/lang/Object;

    .line 106
    .line 107
    .line 108
    move-result-object v6

    .line 109
    iget-object v10, v5, Lbd1;->l:Llq0;

    .line 110
    .line 111
    invoke-virtual {v10, v6}, Llq0;->setValue(Ljava/lang/Object;)V

    .line 112
    .line 113
    .line 114
    invoke-virtual {v5}, Lbd1;->a()Lja1;

    .line 115
    .line 116
    .line 117
    move-result-object v6

    .line 118
    invoke-virtual {v6, v8, v9}, Lja1;->f(J)Lu8;

    .line 119
    .line 120
    .line 121
    move-result-object v6

    .line 122
    iput-object v6, v5, Lbd1;->m:Lu8;

    .line 123
    .line 124
    invoke-virtual {v5}, Lbd1;->a()Lja1;

    .line 125
    .line 126
    .line 127
    move-result-object v5

    .line 128
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 129
    .line 130
    .line 131
    invoke-static {v5, v8, v9}, Lfu0;->a(Lk8;J)Z

    .line 132
    .line 133
    .line 134
    move-result v5

    .line 135
    if-eqz v5, :cond_8d

    .line 136
    .line 137
    sget-object v5, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 138
    .line 139
    invoke-virtual {v7, v5}, Llq0;->setValue(Ljava/lang/Object;)V

    .line 140
    .line 141
    .line 142
    :cond_8d
    invoke-virtual {v7}, Llq0;->getValue()Ljava/lang/Object;

    .line 143
    .line 144
    .line 145
    move-result-object v5

    .line 146
    check-cast v5, Ljava/lang/Boolean;

    .line 147
    .line 148
    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    .line 149
    .line 150
    .line 151
    move-result v5

    .line 152
    if-nez v5, :cond_9a

    .line 153
    .line 154
    move v3, v2

    .line 155
    :cond_9a
    add-int/lit8 v4, v4, 0x1

    .line 156
    .line 157
    goto :goto_40

    .line 158
    :cond_9d
    iget-object v0, p0, Led1;->j:Lz61;

    .line 159
    .line 160
    invoke-virtual {v0}, Lz61;->size()I

    .line 161
    .line 162
    .line 163
    move-result v1

    .line 164
    move v4, v2

    .line 165
    :goto_a4
    if-ge v4, v1, :cond_d3

    .line 166
    .line 167
    invoke-virtual {v0, v4}, Lz61;->get(I)Ljava/lang/Object;

    .line 168
    .line 169
    .line 170
    move-result-object v5

    .line 171
    check-cast v5, Led1;

    .line 172
    .line 173
    iget-object v6, v5, Led1;->d:Llq0;

    .line 174
    .line 175
    invoke-virtual {v6}, Llq0;->getValue()Ljava/lang/Object;

    .line 176
    .line 177
    .line 178
    move-result-object v6

    .line 179
    invoke-virtual {v5}, Led1;->c()Ljava/lang/Object;

    .line 180
    .line 181
    .line 182
    move-result-object v7

    .line 183
    invoke-static {v6, v7}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 184
    .line 185
    .line 186
    move-result v6

    .line 187
    if-nez v6, :cond_bf

    .line 188
    .line 189
    invoke-virtual {v5, p1, p2, p3}, Led1;->h(JZ)V

    .line 190
    .line 191
    .line 192
    :cond_bf
    iget-object v6, v5, Led1;->d:Llq0;

    .line 193
    .line 194
    invoke-virtual {v6}, Llq0;->getValue()Ljava/lang/Object;

    .line 195
    .line 196
    .line 197
    move-result-object v6

    .line 198
    invoke-virtual {v5}, Led1;->c()Ljava/lang/Object;

    .line 199
    .line 200
    .line 201
    move-result-object v5

    .line 202
    invoke-static {v6, v5}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 203
    .line 204
    .line 205
    move-result v5

    .line 206
    if-nez v5, :cond_d0

    .line 207
    .line 208
    move v3, v2

    .line 209
    :cond_d0
    add-int/lit8 v4, v4, 0x1

    .line 210
    .line 211
    goto :goto_a4

    .line 212
    :cond_d3
    if-eqz v3, :cond_d8

    .line 213
    .line 214
    invoke-virtual {p0}, Led1;->i()V

    .line 215
    .line 216
    .line 217
    :cond_d8
    return-void
.end method

.method public final i()V
    .registers 5

    .line 1
    const-wide/high16 v0, -0x8000000000000000L

    .line 2
    .line 3
    iget-object v2, p0, Led1;->g:Ljq0;

    .line 4
    .line 5
    invoke-virtual {v2, v0, v1}, Ljq0;->h(J)V

    .line 6
    .line 7
    .line 8
    iget-object v0, p0, Led1;->d:Llq0;

    .line 9
    .line 10
    invoke-virtual {v0}, Llq0;->getValue()Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    iget-object v1, p0, Led1;->a:Lal;

    .line 15
    .line 16
    iget-object v2, v1, Lal;->g:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast v2, Llq0;

    .line 19
    .line 20
    invoke-virtual {v2, v0}, Llq0;->setValue(Ljava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    iget-object v0, p0, Led1;->b:Led1;

    .line 24
    .line 25
    if-nez v0, :cond_21

    .line 26
    .line 27
    iget-object v0, p0, Led1;->f:Ljq0;

    .line 28
    .line 29
    const-wide/16 v2, 0x0

    .line 30
    .line 31
    invoke-virtual {v0, v2, v3}, Ljq0;->h(J)V

    .line 32
    .line 33
    .line 34
    :cond_21
    iget-object v0, v1, Lal;->f:Ljava/lang/Object;

    .line 35
    .line 36
    check-cast v0, Llq0;

    .line 37
    .line 38
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 39
    .line 40
    invoke-virtual {v0, v1}, Llq0;->setValue(Ljava/lang/Object;)V

    .line 41
    .line 42
    .line 43
    iget-object p0, p0, Led1;->j:Lz61;

    .line 44
    .line 45
    invoke-virtual {p0}, Lz61;->size()I

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    const/4 v1, 0x0

    .line 50
    :goto_31
    if-ge v1, v0, :cond_3f

    .line 51
    .line 52
    invoke-virtual {p0, v1}, Lz61;->get(I)Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    move-result-object v2

    .line 56
    check-cast v2, Led1;

    .line 57
    .line 58
    invoke-virtual {v2}, Led1;->i()V

    .line 59
    .line 60
    .line 61
    add-int/lit8 v1, v1, 0x1

    .line 62
    .line 63
    goto :goto_31

    .line 64
    :cond_3f
    return-void
.end method

.method public final j(Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 8

    .line 1
    const-wide/high16 v0, -0x8000000000000000L

    .line 2
    .line 3
    iget-object v2, p0, Led1;->g:Ljq0;

    .line 4
    .line 5
    invoke-virtual {v2, v0, v1}, Ljq0;->h(J)V

    .line 6
    .line 7
    .line 8
    iget-object v0, p0, Led1;->a:Lal;

    .line 9
    .line 10
    iget-object v1, v0, Lal;->f:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v1, Llq0;

    .line 13
    .line 14
    sget-object v2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 15
    .line 16
    invoke-virtual {v1, v2}, Llq0;->setValue(Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    invoke-virtual {p0}, Led1;->g()Z

    .line 20
    .line 21
    .line 22
    move-result v1

    .line 23
    iget-object v2, p0, Led1;->d:Llq0;

    .line 24
    .line 25
    if-eqz v1, :cond_2e

    .line 26
    .line 27
    invoke-virtual {p0}, Led1;->c()Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    invoke-static {v1, p1}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 32
    .line 33
    .line 34
    move-result v1

    .line 35
    if-eqz v1, :cond_2e

    .line 36
    .line 37
    invoke-virtual {v2}, Llq0;->getValue()Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    move-result-object v1

    .line 41
    invoke-static {v1, p2}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 42
    .line 43
    .line 44
    move-result v1

    .line 45
    if-nez v1, :cond_53

    .line 46
    .line 47
    :cond_2e
    invoke-virtual {p0}, Led1;->c()Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object v1

    .line 51
    invoke-static {v1, p1}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 52
    .line 53
    .line 54
    move-result v1

    .line 55
    if-nez v1, :cond_3f

    .line 56
    .line 57
    iget-object v0, v0, Lal;->g:Ljava/lang/Object;

    .line 58
    .line 59
    check-cast v0, Llq0;

    .line 60
    .line 61
    invoke-virtual {v0, p1}, Llq0;->setValue(Ljava/lang/Object;)V

    .line 62
    .line 63
    .line 64
    :cond_3f
    invoke-virtual {v2, p2}, Llq0;->setValue(Ljava/lang/Object;)V

    .line 65
    .line 66
    .line 67
    iget-object v0, p0, Led1;->k:Llq0;

    .line 68
    .line 69
    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 70
    .line 71
    invoke-virtual {v0, v1}, Llq0;->setValue(Ljava/lang/Object;)V

    .line 72
    .line 73
    .line 74
    new-instance v0, Lad1;

    .line 75
    .line 76
    invoke-direct {v0, p1, p2}, Lad1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 77
    .line 78
    .line 79
    iget-object p1, p0, Led1;->e:Llq0;

    .line 80
    .line 81
    invoke-virtual {p1, v0}, Llq0;->setValue(Ljava/lang/Object;)V

    .line 82
    .line 83
    .line 84
    :cond_53
    iget-object p1, p0, Led1;->j:Lz61;

    .line 85
    .line 86
    invoke-virtual {p1}, Lz61;->size()I

    .line 87
    .line 88
    .line 89
    move-result p2

    .line 90
    const/4 v0, 0x0

    .line 91
    move v1, v0

    .line 92
    :goto_5b
    if-ge v1, p2, :cond_7c

    .line 93
    .line 94
    invoke-virtual {p1, v1}, Lz61;->get(I)Ljava/lang/Object;

    .line 95
    .line 96
    .line 97
    move-result-object v2

    .line 98
    check-cast v2, Led1;

    .line 99
    .line 100
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 101
    .line 102
    .line 103
    invoke-virtual {v2}, Led1;->g()Z

    .line 104
    .line 105
    .line 106
    move-result v3

    .line 107
    if-eqz v3, :cond_79

    .line 108
    .line 109
    invoke-virtual {v2}, Led1;->c()Ljava/lang/Object;

    .line 110
    .line 111
    .line 112
    move-result-object v3

    .line 113
    iget-object v4, v2, Led1;->d:Llq0;

    .line 114
    .line 115
    invoke-virtual {v4}, Llq0;->getValue()Ljava/lang/Object;

    .line 116
    .line 117
    .line 118
    move-result-object v4

    .line 119
    invoke-virtual {v2, v3, v4}, Led1;->j(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 120
    .line 121
    .line 122
    :cond_79
    add-int/lit8 v1, v1, 0x1

    .line 123
    .line 124
    goto :goto_5b

    .line 125
    :cond_7c
    iget-object p0, p0, Led1;->i:Lz61;

    .line 126
    .line 127
    invoke-virtual {p0}, Lz61;->size()I

    .line 128
    .line 129
    .line 130
    move-result p1

    .line 131
    :goto_82
    if-ge v0, p1, :cond_90

    .line 132
    .line 133
    invoke-virtual {p0, v0}, Lz61;->get(I)Ljava/lang/Object;

    .line 134
    .line 135
    .line 136
    move-result-object p2

    .line 137
    check-cast p2, Lbd1;

    .line 138
    .line 139
    invoke-virtual {p2}, Lbd1;->c()V

    .line 140
    .line 141
    .line 142
    add-int/lit8 v0, v0, 0x1

    .line 143
    .line 144
    goto :goto_82

    .line 145
    :cond_90
    return-void
.end method

.method public final k(Ljava/lang/Object;)V
    .registers 6

    .line 1
    iget-object v0, p0, Led1;->d:Llq0;

    .line 2
    .line 3
    invoke-virtual {v0}, Llq0;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    invoke-static {v1, p1}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    if-nez v1, :cond_65

    .line 12
    .line 13
    new-instance v1, Lad1;

    .line 14
    .line 15
    invoke-virtual {v0}, Llq0;->getValue()Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v2

    .line 19
    invoke-direct {v1, v2, p1}, Lad1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 20
    .line 21
    .line 22
    iget-object v2, p0, Led1;->e:Llq0;

    .line 23
    .line 24
    invoke-virtual {v2, v1}, Llq0;->setValue(Ljava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    invoke-virtual {p0}, Led1;->c()Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    invoke-virtual {v0}, Llq0;->getValue()Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    move-result-object v2

    .line 35
    invoke-static {v1, v2}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 36
    .line 37
    .line 38
    move-result v1

    .line 39
    if-nez v1, :cond_35

    .line 40
    .line 41
    invoke-virtual {v0}, Llq0;->getValue()Ljava/lang/Object;

    .line 42
    .line 43
    .line 44
    move-result-object v1

    .line 45
    iget-object v2, p0, Led1;->a:Lal;

    .line 46
    .line 47
    iget-object v2, v2, Lal;->g:Ljava/lang/Object;

    .line 48
    .line 49
    check-cast v2, Llq0;

    .line 50
    .line 51
    invoke-virtual {v2, v1}, Llq0;->setValue(Ljava/lang/Object;)V

    .line 52
    .line 53
    .line 54
    :cond_35
    invoke-virtual {v0, p1}, Llq0;->setValue(Ljava/lang/Object;)V

    .line 55
    .line 56
    .line 57
    iget-object p1, p0, Led1;->g:Ljq0;

    .line 58
    .line 59
    invoke-virtual {p1}, Ljq0;->g()J

    .line 60
    .line 61
    .line 62
    move-result-wide v0

    .line 63
    const-wide/high16 v2, -0x8000000000000000L

    .line 64
    .line 65
    cmp-long p1, v0, v2

    .line 66
    .line 67
    if-eqz p1, :cond_45

    .line 68
    .line 69
    goto :goto_4c

    .line 70
    :cond_45
    iget-object p1, p0, Led1;->h:Llq0;

    .line 71
    .line 72
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 73
    .line 74
    invoke-virtual {p1, v0}, Llq0;->setValue(Ljava/lang/Object;)V

    .line 75
    .line 76
    .line 77
    :goto_4c
    iget-object p0, p0, Led1;->i:Lz61;

    .line 78
    .line 79
    invoke-virtual {p0}, Lz61;->size()I

    .line 80
    .line 81
    .line 82
    move-result p1

    .line 83
    const/4 v0, 0x0

    .line 84
    :goto_53
    if-ge v0, p1, :cond_65

    .line 85
    .line 86
    invoke-virtual {p0, v0}, Lz61;->get(I)Ljava/lang/Object;

    .line 87
    .line 88
    .line 89
    move-result-object v1

    .line 90
    check-cast v1, Lbd1;

    .line 91
    .line 92
    const/high16 v2, -0x40000000  # -2.0f

    .line 93
    .line 94
    iget-object v1, v1, Lbd1;->j:Lhq0;

    .line 95
    .line 96
    invoke-virtual {v1, v2}, Lhq0;->h(F)V

    .line 97
    .line 98
    .line 99
    add-int/lit8 v0, v0, 0x1

    .line 100
    .line 101
    goto :goto_53

    .line 102
    :cond_65
    return-void
.end method

.method public final toString()Ljava/lang/String;
    .registers 6

    .line 1
    iget-object p0, p0, Led1;->i:Lz61;

    .line 2
    .line 3
    invoke-interface {p0}, Ljava/util/Collection;->size()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const-string v1, "Transition animation values: "

    .line 8
    .line 9
    const/4 v2, 0x0

    .line 10
    :goto_9
    if-ge v2, v0, :cond_28

    .line 11
    .line 12
    invoke-virtual {p0, v2}, Lz61;->get(I)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v3

    .line 16
    check-cast v3, Lbd1;

    .line 17
    .line 18
    new-instance v4, Ljava/lang/StringBuilder;

    .line 19
    .line 20
    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    .line 21
    .line 22
    .line 23
    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 24
    .line 25
    .line 26
    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 27
    .line 28
    .line 29
    const-string v1, ", "

    .line 30
    .line 31
    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 32
    .line 33
    .line 34
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object v1

    .line 38
    add-int/lit8 v2, v2, 0x1

    .line 39
    .line 40
    goto :goto_9

    .line 41
    :cond_28
    return-object v1
.end method
