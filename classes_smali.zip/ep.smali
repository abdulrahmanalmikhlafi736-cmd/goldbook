.class public final synthetic Lep;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lxz;


# instance fields
.field public final synthetic e:I

.field public final synthetic f:Lfp;


# direct methods
.method public synthetic constructor <init>(Lfp;I)V
    .registers 3

    .line 1
    iput p2, p0, Lep;->e:I

    .line 2
    .line 3
    iput-object p1, p0, Lep;->f:Lfp;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .registers 8

    .line 1
    iget v0, p0, Lep;->e:I

    .line 2
    .line 3
    iget-object p0, p0, Lep;->f:Lfp;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_4c

    .line 6
    .line 7
    .line 8
    sget-object v0, Lfy0;->a:Lgk;

    .line 9
    .line 10
    invoke-static {p0, v0}, Lj70;->z(Lak;Llv0;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    check-cast v0, Lcy0;

    .line 15
    .line 16
    iget-object v1, p0, Lfp;->y:Ly6;

    .line 17
    .line 18
    if-nez v0, :cond_1c

    .line 19
    .line 20
    if-eqz v1, :cond_18

    .line 21
    .line 22
    invoke-virtual {p0, v1}, Ldp;->s0(Lcp;)V

    .line 23
    .line 24
    .line 25
    :cond_18
    const/4 v0, 0x0

    .line 26
    iput-object v0, p0, Lfp;->y:Ly6;

    .line 27
    .line 28
    goto :goto_3d

    .line 29
    :cond_1c
    if-nez v1, :cond_3d

    .line 30
    .line 31
    new-instance v5, Lpg0;

    .line 32
    .line 33
    const/16 v0, 0xd

    .line 34
    .line 35
    invoke-direct {v5, v0, p0}, Lpg0;-><init>(ILjava/lang/Object;)V

    .line 36
    .line 37
    .line 38
    new-instance v6, Lep;

    .line 39
    .line 40
    const/4 v0, 0x0

    .line 41
    invoke-direct {v6, p0, v0}, Lep;-><init>(Lfp;I)V

    .line 42
    .line 43
    .line 44
    iget-object v2, p0, Lfp;->u:Luj0;

    .line 45
    .line 46
    iget-boolean v3, p0, Lfp;->v:Z

    .line 47
    .line 48
    iget v4, p0, Lfp;->w:F

    .line 49
    .line 50
    sget-object v0, Lgy0;->a:Ltd1;

    .line 51
    .line 52
    new-instance v1, Ly6;

    .line 53
    .line 54
    invoke-direct/range {v1 .. v6}, Ly6;-><init>(Luj0;ZFLpg0;Lep;)V

    .line 55
    .line 56
    .line 57
    invoke-virtual {p0, v1}, Ldp;->r0(Lcp;)Lcp;

    .line 58
    .line 59
    .line 60
    iput-object v1, p0, Lfp;->y:Ly6;

    .line 61
    .line 62
    :cond_3d
    :goto_3d
    sget-object p0, Lwe1;->a:Lwe1;

    .line 63
    .line 64
    return-object p0

    .line 65
    :pswitch_40  #0x0
    sget-object v0, Lfy0;->a:Lgk;

    .line 66
    .line 67
    invoke-static {p0, v0}, Lj70;->z(Lak;Llv0;)Ljava/lang/Object;

    .line 68
    .line 69
    .line 70
    move-result-object p0

    .line 71
    check-cast p0, Lcy0;

    .line 72
    .line 73
    sget-object p0, Lj70;->e:Lby0;

    .line 74
    .line 75
    return-object p0

    .line 76
    nop

    .line 77
    :pswitch_data_4c
    .packed-switch 0x0
        :pswitch_40  #00000000
    .end packed-switch
.end method
