.class public final Lar;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lsl;


# instance fields
.field public final synthetic e:Lsl;

.field public final f:Ljava/lang/Throwable;


# direct methods
.method public constructor <init>(Lsl;Ljava/lang/Throwable;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lar;->e:Lsl;

    .line 5
    .line 6
    iput-object p2, p0, Lar;->f:Ljava/lang/Throwable;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final i(Lsl;)Lsl;
    .registers 2

    .line 1
    iget-object p0, p0, Lar;->e:Lsl;

    .line 2
    .line 3
    invoke-interface {p0, p1}, Lsl;->i(Lsl;)Lsl;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    return-object p0
.end method

.method public final k(Lrl;)Lql;
    .registers 2

    .line 1
    iget-object p0, p0, Lar;->e:Lsl;

    .line 2
    .line 3
    invoke-interface {p0, p1}, Lsl;->k(Lrl;)Lql;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    return-object p0
.end method

.method public final p(Lm00;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 1
    iget-object p0, p0, Lar;->e:Lsl;

    .line 2
    .line 3
    invoke-interface {p0, p1, p2}, Lsl;->p(Lm00;Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    return-object p0
.end method

.method public final t(Lrl;)Lsl;
    .registers 2

    .line 1
    iget-object p0, p0, Lar;->e:Lsl;

    .line 2
    .line 3
    invoke-interface {p0, p1}, Lsl;->t(Lrl;)Lsl;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    return-object p0
.end method
