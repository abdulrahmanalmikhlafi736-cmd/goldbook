.class public final Ldd;
.super Lzi1;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# instance fields
.field public G:Lcz0;

.field public H:J

.field public final synthetic I:Landroid/graphics/Shader;


# direct methods
.method public constructor <init>(Landroid/graphics/Shader;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Ldd;->I:Landroid/graphics/Shader;

    .line 5
    .line 6
    const-wide v0, 0x7fc000007fc00000L  # 2.247117487993712E307

    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    iput-wide v0, p0, Ldd;->H:J

    .line 12
    .line 13
    return-void
.end method


# virtual methods
.method public final l(FJLk6;)V
    .registers 10

    .line 1
    iget-object v0, p4, Lk6;->a:Landroid/graphics/Paint;

    .line 2
    .line 3
    iget-object v1, p0, Ldd;->G:Lcz0;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v1, :cond_f

    .line 7
    .line 8
    iget-wide v3, p0, Ldd;->H:J

    .line 9
    .line 10
    invoke-static {v3, v4, p2, p3}, Ls51;->a(JJ)Z

    .line 11
    .line 12
    .line 13
    move-result v3

    .line 14
    if-nez v3, :cond_35

    .line 15
    .line 16
    :cond_f
    invoke-static {p2, p3}, Ls51;->c(J)Z

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    if-eqz v1, :cond_20

    .line 21
    .line 22
    iput-object v2, p0, Ldd;->G:Lcz0;

    .line 23
    .line 24
    const-wide p2, 0x7fc000007fc00000L  # 2.247117487993712E307

    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    iput-wide p2, p0, Ldd;->H:J

    .line 30
    .line 31
    move-object v1, v2

    .line 32
    goto :goto_35

    .line 33
    :cond_20
    iget-object v1, p0, Ldd;->G:Lcz0;

    .line 34
    .line 35
    if-nez v1, :cond_2d

    .line 36
    .line 37
    new-instance v1, Lcz0;

    .line 38
    .line 39
    const/4 v3, 0x6

    .line 40
    const/4 v4, 0x0

    .line 41
    invoke-direct {v1, v3, v4}, Lcz0;-><init>(IZ)V

    .line 42
    .line 43
    .line 44
    iput-object v1, p0, Ldd;->G:Lcz0;

    .line 45
    .line 46
    :cond_2d
    iget-object v3, p0, Ldd;->I:Landroid/graphics/Shader;

    .line 47
    .line 48
    iput-object v3, v1, Lcz0;->f:Ljava/lang/Object;

    .line 49
    .line 50
    iput-object v1, p0, Ldd;->G:Lcz0;

    .line 51
    .line 52
    iput-wide p2, p0, Ldd;->H:J

    .line 53
    .line 54
    :cond_35
    :goto_35
    invoke-virtual {v0}, Landroid/graphics/Paint;->getColor()I

    .line 55
    .line 56
    .line 57
    move-result p0

    .line 58
    invoke-static {p0}, Lwl1;->d(I)J

    .line 59
    .line 60
    .line 61
    move-result-wide p2

    .line 62
    sget-wide v3, Lzg;->b:J

    .line 63
    .line 64
    invoke-static {p2, p3, v3, v4}, Lzg;->c(JJ)Z

    .line 65
    .line 66
    .line 67
    move-result p0

    .line 68
    if-nez p0, :cond_48

    .line 69
    .line 70
    invoke-virtual {p4, v3, v4}, Lk6;->c(J)V

    .line 71
    .line 72
    .line 73
    :cond_48
    iget-object p0, p4, Lk6;->c:Landroid/graphics/Shader;

    .line 74
    .line 75
    if-eqz v1, :cond_51

    .line 76
    .line 77
    iget-object p2, v1, Lcz0;->f:Ljava/lang/Object;

    .line 78
    .line 79
    check-cast p2, Landroid/graphics/Shader;

    .line 80
    .line 81
    goto :goto_52

    .line 82
    :cond_51
    move-object p2, v2

    .line 83
    :goto_52
    invoke-static {p0, p2}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 84
    .line 85
    .line 86
    move-result p0

    .line 87
    if-nez p0, :cond_64

    .line 88
    .line 89
    if-eqz v1, :cond_5f

    .line 90
    .line 91
    iget-object p0, v1, Lcz0;->f:Ljava/lang/Object;

    .line 92
    .line 93
    move-object v2, p0

    .line 94
    check-cast v2, Landroid/graphics/Shader;

    .line 95
    .line 96
    :cond_5f
    iput-object v2, p4, Lk6;->c:Landroid/graphics/Shader;

    .line 97
    .line 98
    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 99
    .line 100
    .line 101
    :cond_64
    invoke-virtual {v0}, Landroid/graphics/Paint;->getAlpha()I

    .line 102
    .line 103
    .line 104
    move-result p0

    .line 105
    int-to-float p0, p0

    .line 106
    const/high16 p2, 0x437f0000  # 255.0f

    .line 107
    .line 108
    div-float/2addr p0, p2

    .line 109
    cmpg-float p0, p0, p1

    .line 110
    .line 111
    if-nez p0, :cond_71

    .line 112
    .line 113
    return-void

    .line 114
    :cond_71
    invoke-virtual {p4, p1}, Lk6;->a(F)V

    .line 115
    .line 116
    .line 117
    return-void
.end method
