.class public final Lel;
.super Lu91;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lm00;


# instance fields
.field public i:I

.field public synthetic j:Ljava/lang/Object;

.field public final synthetic k:Lmf1;

.field public final synthetic l:Lgl;

.field public final synthetic m:Lyc;

.field public final synthetic n:J

.field public final synthetic o:La80;


# direct methods
.method public constructor <init>(Lmf1;Lgl;Lyc;JLa80;Lml;)V
    .registers 8

    .line 1
    iput-object p1, p0, Lel;->k:Lmf1;

    .line 2
    .line 3
    iput-object p2, p0, Lel;->l:Lgl;

    .line 4
    .line 5
    iput-object p3, p0, Lel;->m:Lyc;

    .line 6
    .line 7
    iput-wide p4, p0, Lel;->n:J

    .line 8
    .line 9
    iput-object p6, p0, Lel;->o:La80;

    .line 10
    .line 11
    const/4 p1, 0x2

    .line 12
    invoke-direct {p0, p1, p7}, Lu91;-><init>(ILml;)V

    .line 13
    .line 14
    .line 15
    return-void
.end method


# virtual methods
.method public final f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 1
    check-cast p1, Lw11;

    .line 2
    .line 3
    check-cast p2, Lml;

    .line 4
    .line 5
    invoke-virtual {p0, p2, p1}, Lel;->n(Lml;Ljava/lang/Object;)Lml;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    check-cast p0, Lel;

    .line 10
    .line 11
    sget-object p1, Lwe1;->a:Lwe1;

    .line 12
    .line 13
    invoke-virtual {p0, p1}, Lel;->p(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method

.method public final n(Lml;Ljava/lang/Object;)Lml;
    .registers 11

    .line 1
    new-instance v0, Lel;

    .line 2
    .line 3
    iget-wide v4, p0, Lel;->n:J

    .line 4
    .line 5
    iget-object v6, p0, Lel;->o:La80;

    .line 6
    .line 7
    iget-object v1, p0, Lel;->k:Lmf1;

    .line 8
    .line 9
    iget-object v2, p0, Lel;->l:Lgl;

    .line 10
    .line 11
    iget-object v3, p0, Lel;->m:Lyc;

    .line 12
    .line 13
    move-object v7, p1

    .line 14
    invoke-direct/range {v0 .. v7}, Lel;-><init>(Lmf1;Lgl;Lyc;JLa80;Lml;)V

    .line 15
    .line 16
    .line 17
    iput-object p2, v0, Lel;->j:Ljava/lang/Object;

    .line 18
    .line 19
    return-object v0
.end method

.method public final p(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 8

    .line 1
    iget v0, p0, Lel;->i:I

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-eqz v0, :cond_12

    .line 5
    .line 6
    if-ne v0, v1, :cond_b

    .line 7
    .line 8
    invoke-static {p1}, Lnb0;->t(Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    goto :goto_3f

    .line 12
    :cond_b
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 13
    .line 14
    invoke-static {p0}, Lod;->p(Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    const/4 p0, 0x0

    .line 18
    return-object p0

    .line 19
    :cond_12
    invoke-static {p1}, Lnb0;->t(Ljava/lang/Object;)V

    .line 20
    .line 21
    .line 22
    iget-object p1, p0, Lel;->j:Ljava/lang/Object;

    .line 23
    .line 24
    check-cast p1, Lw11;

    .line 25
    .line 26
    iget-wide v2, p0, Lel;->n:J

    .line 27
    .line 28
    iget-object v0, p0, Lel;->l:Lgl;

    .line 29
    .line 30
    iget-object v4, p0, Lel;->m:Lyc;

    .line 31
    .line 32
    invoke-static {v0, v4, v2, v3}, Lgl;->r0(Lgl;Lyc;J)F

    .line 33
    .line 34
    .line 35
    move-result v2

    .line 36
    iget-object v3, p0, Lel;->k:Lmf1;

    .line 37
    .line 38
    iput v2, v3, Lmf1;->e:F

    .line 39
    .line 40
    new-instance v2, Lz7;

    .line 41
    .line 42
    iget-object v5, p0, Lel;->o:La80;

    .line 43
    .line 44
    invoke-direct {v2, v0, v3, v5, p1}, Lz7;-><init>(Lgl;Lmf1;La80;Lw11;)V

    .line 45
    .line 46
    .line 47
    new-instance p1, Lna;

    .line 48
    .line 49
    const/4 v5, 0x2

    .line 50
    invoke-direct {p1, v0, v3, v4, v5}, Lna;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 51
    .line 52
    .line 53
    iput v1, p0, Lel;->i:I

    .line 54
    .line 55
    invoke-virtual {v3, v2, p1, p0}, Lmf1;->a(Lz7;Lna;Lnl;)Ljava/lang/Object;

    .line 56
    .line 57
    .line 58
    move-result-object p0

    .line 59
    sget-object p1, Lcm;->e:Lcm;

    .line 60
    .line 61
    if-ne p0, p1, :cond_3f

    .line 62
    .line 63
    return-object p1

    .line 64
    :cond_3f
    :goto_3f
    sget-object p0, Lwe1;->a:Lwe1;

    .line 65
    .line 66
    return-object p0
.end method
