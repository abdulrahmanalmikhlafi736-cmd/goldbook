.class public final synthetic Le20;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lxz;


# instance fields
.field public final synthetic e:I

.field public final synthetic f:Landroid/content/Context;

.field public final synthetic g:Lmk0;


# direct methods
.method public synthetic constructor <init>(Landroid/content/Context;Lmk0;I)V
    .registers 4

    .line 1
    iput p3, p0, Le20;->e:I

    .line 2
    .line 3
    iput-object p1, p0, Le20;->f:Landroid/content/Context;

    .line 4
    .line 5
    iput-object p2, p0, Le20;->g:Lmk0;

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .registers 8

    .line 1
    iget v0, p0, Le20;->e:I

    .line 2
    .line 3
    const-string v1, ".LauncherAlias"

    .line 4
    .line 5
    const/4 v2, 0x1

    .line 6
    sget-object v3, Lwe1;->a:Lwe1;

    .line 7
    .line 8
    iget-object v4, p0, Le20;->g:Lmk0;

    .line 9
    .line 10
    iget-object p0, p0, Le20;->f:Landroid/content/Context;

    .line 11
    .line 12
    packed-switch v0, :pswitch_data_a0

    .line 13
    .line 14
    .line 15
    invoke-static {p0}, Lmc0;->q(Landroid/content/Context;)Z

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    if-eqz v0, :cond_47

    .line 20
    .line 21
    :try_start_14
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    new-instance v4, Landroid/content/ComponentName;

    .line 26
    .line 27
    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object v5

    .line 31
    new-instance v6, Ljava/lang/StringBuilder;

    .line 32
    .line 33
    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    .line 34
    .line 35
    .line 36
    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 37
    .line 38
    .line 39
    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 40
    .line 41
    .line 42
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 43
    .line 44
    .line 45
    move-result-object v1

    .line 46
    invoke-direct {v4, p0, v1}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    .line 47
    .line 48
    .line 49
    invoke-virtual {v0, v4, v2, v2}, Landroid/content/pm/PackageManager;->setComponentEnabledSetting(Landroid/content/ComponentName;II)V

    .line 50
    .line 51
    .line 52
    sget-object p0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;
    :try_end_35
    .catchall {:try_start_14 .. :try_end_35} :catchall_36

    .line 53
    .line 54
    goto :goto_3d

    .line 55
    :catchall_36
    move-exception p0

    .line 56
    new-instance v0, Lpx0;

    .line 57
    .line 58
    invoke-direct {v0, p0}, Lpx0;-><init>(Ljava/lang/Throwable;)V

    .line 59
    .line 60
    .line 61
    move-object p0, v0

    .line 62
    :goto_3d
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 63
    .line 64
    instance-of v1, p0, Lpx0;

    .line 65
    .line 66
    if-eqz v1, :cond_44

    .line 67
    .line 68
    move-object p0, v0

    .line 69
    :cond_44
    check-cast p0, Ljava/lang/Boolean;

    .line 70
    .line 71
    goto :goto_4c

    .line 72
    :cond_47
    sget-object p0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 73
    .line 74
    invoke-interface {v4, p0}, Lmk0;->setValue(Ljava/lang/Object;)V

    .line 75
    .line 76
    .line 77
    :goto_4c
    return-object v3

    .line 78
    :pswitch_4d  #0x1
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 79
    .line 80
    invoke-interface {v4, v0}, Lmk0;->setValue(Ljava/lang/Object;)V

    .line 81
    .line 82
    .line 83
    :try_start_52
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 84
    .line 85
    .line 86
    move-result-object v0

    .line 87
    new-instance v4, Landroid/content/ComponentName;

    .line 88
    .line 89
    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 90
    .line 91
    .line 92
    move-result-object v5

    .line 93
    new-instance v6, Ljava/lang/StringBuilder;

    .line 94
    .line 95
    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    .line 96
    .line 97
    .line 98
    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 99
    .line 100
    .line 101
    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 102
    .line 103
    .line 104
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 105
    .line 106
    .line 107
    move-result-object v1

    .line 108
    invoke-direct {v4, p0, v1}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    .line 109
    .line 110
    .line 111
    const/4 p0, 0x2

    .line 112
    invoke-virtual {v0, v4, p0, v2}, Landroid/content/pm/PackageManager;->setComponentEnabledSetting(Landroid/content/ComponentName;II)V

    .line 113
    .line 114
    .line 115
    sget-object p0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;
    :try_end_74
    .catchall {:try_start_52 .. :try_end_74} :catchall_75

    .line 116
    .line 117
    goto :goto_7c

    .line 118
    :catchall_75
    move-exception p0

    .line 119
    new-instance v0, Lpx0;

    .line 120
    .line 121
    invoke-direct {v0, p0}, Lpx0;-><init>(Ljava/lang/Throwable;)V

    .line 122
    .line 123
    .line 124
    move-object p0, v0

    .line 125
    :goto_7c
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 126
    .line 127
    instance-of v1, p0, Lpx0;

    .line 128
    .line 129
    if-eqz v1, :cond_83

    .line 130
    .line 131
    move-object p0, v0

    .line 132
    :cond_83
    check-cast p0, Ljava/lang/Boolean;

    .line 133
    .line 134
    return-object v3

    .line 135
    :pswitch_86  #0x0
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 136
    .line 137
    .line 138
    move-result-object v0

    .line 139
    const v1, 0x7f0a0093

    .line 140
    .line 141
    .line 142
    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 143
    .line 144
    .line 145
    move-result-object v0

    .line 146
    const/4 v1, 0x0

    .line 147
    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 148
    .line 149
    .line 150
    move-result-object p0

    .line 151
    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    .line 152
    .line 153
    .line 154
    const-string p0, "messages"

    .line 155
    .line 156
    invoke-interface {v4, p0}, Lmk0;->setValue(Ljava/lang/Object;)V

    .line 157
    .line 158
    .line 159
    return-object v3

    .line 160
    nop

    .line 161
    :pswitch_data_a0
    .packed-switch 0x0
        :pswitch_86  #00000000
        :pswitch_4d  #00000001
    .end packed-switch
.end method
