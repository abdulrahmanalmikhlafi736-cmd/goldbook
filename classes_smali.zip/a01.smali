.class public interface abstract La01;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# virtual methods
.method public abstract e(Ljava/lang/Object;)Ljava/lang/Object;
.end method

.method public abstract j(Liz0;Ljava/lang/Object;)Ljava/lang/Object;
.end method
