.class public final Lc11;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lr11;


# static fields
.field public static final j:Lal;


# instance fields
.field public final a:Liq0;

.field public final b:Liq0;

.field public final c:Liq0;

.field public final d:Luj0;

.field public final e:Liq0;

.field public f:F

.field public final g:Lwo;

.field public final h:Lsp;

.field public final i:Lsp;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 1
    new-instance v0, Lc01;

    .line 2
    .line 3
    const/16 v1, 0x1b

    .line 4
    .line 5
    invoke-direct {v0, v1}, Lc01;-><init>(I)V

    .line 6
    .line 7
    .line 8
    new-instance v1, Lb01;

    .line 9
    .line 10
    const/16 v2, 0x1d

    .line 11
    .line 12
    invoke-direct {v1, v2}, Lb01;-><init>(I)V

    .line 13
    .line 14
    .line 15
    new-instance v2, Lal;

    .line 16
    .line 17
    const/16 v3, 0x15

    .line 18
    .line 19
    invoke-direct {v2, v3, v0, v1}, Lal;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 20
    .line 21
    .line 22
    sput-object v2, Lc11;->j:Lal;

    .line 23
    .line 24
    return-void
.end method

.method public constructor <init>(I)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Liq0;

    .line 5
    .line 6
    invoke-direct {v0, p1}, Liq0;-><init>(I)V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, Lc11;->a:Liq0;

    .line 10
    .line 11
    new-instance p1, Liq0;

    .line 12
    .line 13
    const/4 v0, 0x0

    .line 14
    invoke-direct {p1, v0}, Liq0;-><init>(I)V

    .line 15
    .line 16
    .line 17
    iput-object p1, p0, Lc11;->b:Liq0;

    .line 18
    .line 19
    new-instance p1, Liq0;

    .line 20
    .line 21
    invoke-direct {p1, v0}, Liq0;-><init>(I)V

    .line 22
    .line 23
    .line 24
    iput-object p1, p0, Lc11;->c:Liq0;

    .line 25
    .line 26
    new-instance p1, Luj0;

    .line 27
    .line 28
    invoke-direct {p1}, Luj0;-><init>()V

    .line 29
    .line 30
    .line 31
    iput-object p1, p0, Lc11;->d:Luj0;

    .line 32
    .line 33
    new-instance p1, Liq0;

    .line 34
    .line 35
    const v1, 0x7fffffff

    .line 36
    .line 37
    .line 38
    invoke-direct {p1, v1}, Liq0;-><init>(I)V

    .line 39
    .line 40
    .line 41
    iput-object p1, p0, Lc11;->e:Liq0;

    .line 42
    .line 43
    new-instance p1, Ll;

    .line 44
    .line 45
    const/16 v1, 0x14

    .line 46
    .line 47
    invoke-direct {p1, v1, p0}, Ll;-><init>(ILjava/lang/Object;)V

    .line 48
    .line 49
    .line 50
    new-instance v1, Lwo;

    .line 51
    .line 52
    invoke-direct {v1, p1}, Lwo;-><init>(Li00;)V

    .line 53
    .line 54
    .line 55
    iput-object v1, p0, Lc11;->g:Lwo;

    .line 56
    .line 57
    new-instance p1, Lb11;

    .line 58
    .line 59
    invoke-direct {p1, p0, v0}, Lb11;-><init>(Lc11;I)V

    .line 60
    .line 61
    .line 62
    invoke-static {p1}, Lmc0;->j(Lxz;)Lsp;

    .line 63
    .line 64
    .line 65
    move-result-object p1

    .line 66
    iput-object p1, p0, Lc11;->h:Lsp;

    .line 67
    .line 68
    new-instance p1, Lb11;

    .line 69
    .line 70
    const/4 v0, 0x1

    .line 71
    invoke-direct {p1, p0, v0}, Lb11;-><init>(Lc11;I)V

    .line 72
    .line 73
    .line 74
    invoke-static {p1}, Lmc0;->j(Lxz;)Lsp;

    .line 75
    .line 76
    .line 77
    move-result-object p1

    .line 78
    iput-object p1, p0, Lc11;->i:Lsp;

    .line 79
    .line 80
    return-void
.end method


# virtual methods
.method public final a()Z
    .registers 1

    .line 1
    iget-object p0, p0, Lc11;->i:Lsp;

    .line 2
    .line 3
    invoke-virtual {p0}, Lsp;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Ljava/lang/Boolean;

    .line 8
    .line 9
    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 10
    .line 11
    .line 12
    move-result p0

    .line 13
    return p0
.end method

.method public final b()Z
    .registers 1

    .line 1
    iget-object p0, p0, Lc11;->g:Lwo;

    .line 2
    .line 3
    invoke-virtual {p0}, Lwo;->b()Z

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public final c()Z
    .registers 1

    .line 1
    iget-object p0, p0, Lc11;->h:Lsp;

    .line 2
    .line 3
    invoke-virtual {p0}, Lsp;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Ljava/lang/Boolean;

    .line 8
    .line 9
    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 10
    .line 11
    .line 12
    move-result p0

    .line 13
    return p0
.end method

.method public final d(Ltk0;Lm00;Lnl;)Ljava/lang/Object;
    .registers 4

    .line 1
    iget-object p0, p0, Lc11;->g:Lwo;

    .line 2
    .line 3
    invoke-virtual {p0, p1, p2, p3}, Lwo;->d(Ltk0;Lm00;Lnl;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    sget-object p1, Lcm;->e:Lcm;

    .line 8
    .line 9
    if-ne p0, p1, :cond_b

    .line 10
    .line 11
    return-object p0

    .line 12
    :cond_b
    sget-object p0, Lwe1;->a:Lwe1;

    .line 13
    .line 14
    return-object p0
.end method

.method public final e(F)F
    .registers 2

    .line 1
    iget-object p0, p0, Lc11;->g:Lwo;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Lwo;->e(F)F

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method
