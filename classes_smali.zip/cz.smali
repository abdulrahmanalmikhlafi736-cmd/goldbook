.class public final Lcz;
.super Lq;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lvl;


# virtual methods
.method public final n(Lsl;Ljava/lang/Throwable;)V
    .registers 3

    .line 1
    return-void
.end method
