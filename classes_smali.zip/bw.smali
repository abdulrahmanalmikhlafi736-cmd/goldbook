.class public final Lbw;
.super Lua0;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# instance fields
.field public final b:Lzo0;

.field public final c:Lzo0;


# direct methods
.method public constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Lzo0;

    .line 5
    .line 6
    invoke-direct {v0}, Lzo0;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, Lbw;->b:Lzo0;

    .line 10
    .line 11
    new-instance v0, Lzo0;

    .line 12
    .line 13
    invoke-direct {v0}, Lzo0;-><init>()V

    .line 14
    .line 15
    .line 16
    iput-object v0, p0, Lbw;->c:Lzo0;

    .line 17
    .line 18
    return-void
.end method
