.class public interface abstract Lds;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lcp;


# virtual methods
.method public abstract C(Lda0;)V
.end method

.method public abstract Z()V
.end method
