.class public final Lab0;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lkb;


# instance fields
.field public final synthetic a:Lbb0;

.field public final synthetic b:Lnw0;

.field public final synthetic c:I


# direct methods
.method public constructor <init>(Lbb0;Lnw0;I)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lab0;->a:Lbb0;

    .line 5
    .line 6
    iput-object p2, p0, Lab0;->b:Lnw0;

    .line 7
    .line 8
    iput p3, p0, Lab0;->c:I

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final a()Z
    .registers 3

    .line 1
    iget-object v0, p0, Lab0;->b:Lnw0;

    .line 2
    .line 3
    iget-object v0, v0, Lnw0;->e:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v0, Lxa0;

    .line 6
    .line 7
    iget v1, p0, Lab0;->c:I

    .line 8
    .line 9
    iget-object p0, p0, Lab0;->a:Lbb0;

    .line 10
    .line 11
    invoke-virtual {p0, v0, v1}, Lbb0;->r0(Lxa0;I)Z

    .line 12
    .line 13
    .line 14
    move-result p0

    .line 15
    return p0
.end method
