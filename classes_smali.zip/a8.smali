.class public final La8;
.super Lu91;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Li00;


# instance fields
.field public i:Lp8;

.field public j:Ljw0;

.field public k:I

.field public final synthetic l:Lc8;

.field public final synthetic m:Ljava/lang/Object;

.field public final synthetic n:Lja1;

.field public final synthetic o:J


# direct methods
.method public constructor <init>(Lc8;Ljava/lang/Object;Lja1;JLml;)V
    .registers 7

    .line 1
    iput-object p1, p0, La8;->l:Lc8;

    .line 2
    .line 3
    iput-object p2, p0, La8;->m:Ljava/lang/Object;

    .line 4
    .line 5
    iput-object p3, p0, La8;->n:Lja1;

    .line 6
    .line 7
    iput-wide p4, p0, La8;->o:J

    .line 8
    .line 9
    const/4 p1, 0x1

    .line 10
    invoke-direct {p0, p1, p6}, Lu91;-><init>(ILml;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method


# virtual methods
.method public final i(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 9

    .line 1
    move-object v6, p1

    .line 2
    check-cast v6, Lml;

    .line 3
    .line 4
    new-instance v0, La8;

    .line 5
    .line 6
    iget-object v3, p0, La8;->n:Lja1;

    .line 7
    .line 8
    iget-wide v4, p0, La8;->o:J

    .line 9
    .line 10
    iget-object v1, p0, La8;->l:Lc8;

    .line 11
    .line 12
    iget-object v2, p0, La8;->m:Ljava/lang/Object;

    .line 13
    .line 14
    invoke-direct/range {v0 .. v6}, La8;-><init>(Lc8;Ljava/lang/Object;Lja1;JLml;)V

    .line 15
    .line 16
    .line 17
    sget-object p0, Lwe1;->a:Lwe1;

    .line 18
    .line 19
    invoke-virtual {v0, p0}, La8;->p(Ljava/lang/Object;)Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object p0

    .line 23
    return-object p0
.end method

.method public final p(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 18

    .line 1
    move-object/from16 v5, p0

    .line 2
    .line 3
    iget-object v1, v5, La8;->n:Lja1;

    .line 4
    .line 5
    iget v0, v5, La8;->k:I

    .line 6
    .line 7
    const/4 v2, 0x1

    .line 8
    iget-object v6, v5, La8;->l:Lc8;

    .line 9
    .line 10
    if-eqz v0, :cond_1f

    .line 11
    .line 12
    if-ne v0, v2, :cond_18

    .line 13
    .line 14
    iget-object v0, v5, La8;->j:Ljw0;

    .line 15
    .line 16
    iget-object v1, v5, La8;->i:Lp8;

    .line 17
    .line 18
    :try_start_11
    invoke-static/range {p1 .. p1}, Lnb0;->t(Ljava/lang/Object;)V
    :try_end_14
    .catch Ljava/util/concurrent/CancellationException; {:try_start_11 .. :try_end_14} :catch_15

    .line 19
    .line 20
    .line 21
    goto :goto_7c

    .line 22
    :catch_15
    move-exception v0

    .line 23
    goto/16 :goto_8e

    .line 24
    .line 25
    :cond_18
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 26
    .line 27
    invoke-static {v0}, Lod;->p(Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    const/4 v0, 0x0

    .line 31
    return-object v0

    .line 32
    :cond_1f
    invoke-static/range {p1 .. p1}, Lnb0;->t(Ljava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    :try_start_22
    iget-object v0, v6, Lc8;->c:Lp8;

    .line 36
    .line 37
    iget-object v3, v6, Lc8;->a:Lud1;

    .line 38
    .line 39
    iget-object v3, v3, Lud1;->a:Li00;

    .line 40
    .line 41
    iget-object v4, v5, La8;->m:Ljava/lang/Object;

    .line 42
    .line 43
    invoke-interface {v3, v4}, Li00;->i(Ljava/lang/Object;)Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object v3

    .line 47
    check-cast v3, Lu8;

    .line 48
    .line 49
    iput-object v3, v0, Lp8;->g:Lu8;

    .line 50
    .line 51
    iget-object v0, v1, Lja1;->c:Ljava/lang/Object;

    .line 52
    .line 53
    iget-object v3, v6, Lc8;->e:Llq0;

    .line 54
    .line 55
    invoke-virtual {v3, v0}, Llq0;->setValue(Ljava/lang/Object;)V

    .line 56
    .line 57
    .line 58
    iget-object v0, v6, Lc8;->d:Llq0;

    .line 59
    .line 60
    sget-object v3, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 61
    .line 62
    invoke-virtual {v0, v3}, Llq0;->setValue(Ljava/lang/Object;)V

    .line 63
    .line 64
    .line 65
    iget-object v0, v6, Lc8;->c:Lp8;

    .line 66
    .line 67
    iget-object v3, v0, Lp8;->f:Llq0;

    .line 68
    .line 69
    invoke-virtual {v3}, Llq0;->getValue()Ljava/lang/Object;

    .line 70
    .line 71
    .line 72
    move-result-object v9

    .line 73
    iget-object v3, v0, Lp8;->g:Lu8;

    .line 74
    .line 75
    invoke-static {v3}, La5;->n(Lu8;)Lu8;

    .line 76
    .line 77
    .line 78
    move-result-object v10

    .line 79
    iget-wide v11, v0, Lp8;->h:J

    .line 80
    .line 81
    iget-boolean v15, v0, Lp8;->j:Z

    .line 82
    .line 83
    new-instance v7, Lp8;

    .line 84
    .line 85
    iget-object v8, v0, Lp8;->e:Lud1;

    .line 86
    .line 87
    const-wide/high16 v13, -0x8000000000000000L

    .line 88
    .line 89
    invoke-direct/range {v7 .. v15}, Lp8;-><init>(Lud1;Ljava/lang/Object;Lu8;JJZ)V

    .line 90
    .line 91
    .line 92
    move-object v0, v7

    .line 93
    new-instance v7, Ljw0;

    .line 94
    .line 95
    invoke-direct {v7}, Ljava/lang/Object;-><init>()V

    .line 96
    .line 97
    .line 98
    iget-wide v3, v5, La8;->o:J

    .line 99
    .line 100
    move-wide v8, v3

    .line 101
    new-instance v4, Lz7;

    .line 102
    .line 103
    const/4 v3, 0x0

    .line 104
    invoke-direct {v4, v6, v0, v7, v3}, Lz7;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 105
    .line 106
    .line 107
    iput-object v0, v5, La8;->i:Lp8;

    .line 108
    .line 109
    iput-object v7, v5, La8;->j:Ljw0;

    .line 110
    .line 111
    iput v2, v5, La8;->k:I

    .line 112
    .line 113
    move-wide v2, v8

    .line 114
    invoke-static/range {v0 .. v5}, Lwa0;->b(Lp8;Lk8;JLi00;Lml;)Ljava/lang/Object;

    .line 115
    .line 116
    .line 117
    move-result-object v1
    :try_end_75
    .catch Ljava/util/concurrent/CancellationException; {:try_start_22 .. :try_end_75} :catch_15

    .line 118
    sget-object v2, Lcm;->e:Lcm;

    .line 119
    .line 120
    if-ne v1, v2, :cond_7a

    .line 121
    .line 122
    return-object v2

    .line 123
    :cond_7a
    move-object v1, v0

    .line 124
    move-object v0, v7

    .line 125
    :goto_7c
    :try_start_7c
    iget-boolean v0, v0, Ljw0;->e:Z

    .line 126
    .line 127
    if-eqz v0, :cond_83

    .line 128
    .line 129
    sget-object v0, Ll8;->e:Ll8;

    .line 130
    .line 131
    goto :goto_85

    .line 132
    :cond_83
    sget-object v0, Ll8;->f:Ll8;

    .line 133
    .line 134
    :goto_85
    invoke-static {v6}, Lc8;->b(Lc8;)V

    .line 135
    .line 136
    .line 137
    new-instance v2, Lm8;

    .line 138
    .line 139
    invoke-direct {v2, v1, v0}, Lm8;-><init>(Lp8;Ll8;)V
    :try_end_8d
    .catch Ljava/util/concurrent/CancellationException; {:try_start_7c .. :try_end_8d} :catch_15

    .line 140
    .line 141
    .line 142
    return-object v2

    .line 143
    :goto_8e
    invoke-static {v6}, Lc8;->b(Lc8;)V

    .line 144
    .line 145
    .line 146
    throw v0
.end method
