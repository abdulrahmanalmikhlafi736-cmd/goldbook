.class public abstract Ldg1;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# static fields
.field public static final synthetic a:I


# direct methods
.method static constructor <clinit>()V
    .registers 24

    .line 1
    const/4 v0, 0x2

    .line 2
    new-array v1, v0, [I

    .line 3
    .line 4
    new-array v2, v0, [F

    .line 5
    .line 6
    new-array v3, v0, [F

    .line 7
    .line 8
    new-array v4, v0, [[F

    .line 9
    .line 10
    const/4 v5, 0x0

    .line 11
    aput-object v2, v4, v5

    .line 12
    .line 13
    const/4 v2, 0x1

    .line 14
    aput-object v3, v4, v2

    .line 15
    .line 16
    aget v1, v1, v5

    .line 17
    .line 18
    const/4 v3, 0x5

    .line 19
    const/4 v6, 0x4

    .line 20
    const/4 v7, 0x3

    .line 21
    if-eqz v1, :cond_28

    .line 22
    .line 23
    if-eq v1, v2, :cond_20

    .line 24
    .line 25
    if-eq v1, v0, :cond_26

    .line 26
    .line 27
    if-eq v1, v7, :cond_26

    .line 28
    .line 29
    if-eq v1, v6, :cond_24

    .line 30
    .line 31
    if-eq v1, v3, :cond_22

    .line 32
    .line 33
    :cond_20
    move v1, v2

    .line 34
    goto :goto_29

    .line 35
    :cond_22
    move v1, v3

    .line 36
    goto :goto_29

    .line 37
    :cond_24
    move v1, v6

    .line 38
    goto :goto_29

    .line 39
    :cond_26
    move v1, v0

    .line 40
    goto :goto_29

    .line 41
    :cond_28
    move v1, v7

    .line 42
    :goto_29
    aget-object v8, v4, v5

    .line 43
    .line 44
    aget-object v4, v4, v2

    .line 45
    .line 46
    array-length v9, v8

    .line 47
    div-int/2addr v9, v0

    .line 48
    array-length v10, v8

    .line 49
    rem-int/2addr v10, v0

    .line 50
    add-int/2addr v10, v9

    .line 51
    new-array v0, v10, [Lnq0;

    .line 52
    .line 53
    move v9, v5

    .line 54
    :goto_35
    if-ge v9, v10, :cond_11c

    .line 55
    .line 56
    mul-int/lit8 v11, v9, 0x2

    .line 57
    .line 58
    new-instance v12, Lnq0;

    .line 59
    .line 60
    aget v13, v8, v11

    .line 61
    .line 62
    add-int/lit8 v14, v11, 0x1

    .line 63
    .line 64
    aget v15, v8, v14

    .line 65
    .line 66
    aget v11, v4, v11

    .line 67
    .line 68
    aget v14, v4, v14

    .line 69
    .line 70
    const/16 v5, 0x13

    .line 71
    .line 72
    invoke-direct {v12, v5}, Lnq0;-><init>(I)V

    .line 73
    .line 74
    .line 75
    sub-float/2addr v11, v13

    .line 76
    sub-float v5, v14, v15

    .line 77
    .line 78
    const/16 v13, 0x65

    .line 79
    .line 80
    move/from16 v16, v2

    .line 81
    .line 82
    new-array v2, v13, [F

    .line 83
    .line 84
    if-ne v1, v7, :cond_5c

    .line 85
    .line 86
    :cond_55
    :goto_55
    const/4 v7, 0x0

    .line 87
    move-object/from16 v23, v0

    .line 88
    .line 89
    move/from16 v20, v1

    .line 90
    .line 91
    goto/16 :goto_107

    .line 92
    .line 93
    :cond_5c
    invoke-static {v11}, Ljava/lang/Math;->abs(F)F

    .line 94
    .line 95
    .line 96
    move-result v17

    .line 97
    const v18, 0x3a83126f

    .line 98
    .line 99
    .line 100
    cmpg-float v17, v17, v18

    .line 101
    .line 102
    if-ltz v17, :cond_55

    .line 103
    .line 104
    invoke-static {v5}, Ljava/lang/Math;->abs(F)F

    .line 105
    .line 106
    .line 107
    move-result v17

    .line 108
    cmpg-float v17, v17, v18

    .line 109
    .line 110
    if-gez v17, :cond_70

    .line 111
    .line 112
    goto :goto_55

    .line 113
    :cond_70
    sub-float/2addr v15, v14

    .line 114
    sget-object v5, Lvd1;->a:[F

    .line 115
    .line 116
    move/from16 v20, v15

    .line 117
    .line 118
    move/from16 v3, v16

    .line 119
    .line 120
    const/16 v18, 0x0

    .line 121
    .line 122
    const/16 v19, 0x0

    .line 123
    .line 124
    :goto_7b
    int-to-double v6, v3

    .line 125
    const-wide v21, 0x4056800000000000L  # 90.0

    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    mul-double v6, v6, v21

    .line 131
    .line 132
    div-double v6, v6, v21

    .line 133
    .line 134
    const-wide v21, 0x3f91df46a2529d39L  # 0.017453292519943295

    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    mul-double v6, v6, v21

    .line 140
    .line 141
    double-to-float v6, v6

    .line 142
    float-to-double v6, v6

    .line 143
    move/from16 v21, v15

    .line 144
    .line 145
    const/16 v22, 0x0

    .line 146
    .line 147
    invoke-static {v6, v7}, Ljava/lang/Math;->sin(D)D

    .line 148
    .line 149
    .line 150
    move-result-wide v14

    .line 151
    double-to-float v14, v14

    .line 152
    invoke-static {v6, v7}, Ljava/lang/Math;->cos(D)D

    .line 153
    .line 154
    .line 155
    move-result-wide v6

    .line 156
    double-to-float v6, v6

    .line 157
    mul-float/2addr v14, v11

    .line 158
    mul-float v15, v21, v6

    .line 159
    .line 160
    sub-float v6, v14, v19

    .line 161
    .line 162
    float-to-double v6, v6

    .line 163
    sub-float v13, v15, v20

    .line 164
    .line 165
    move-object/from16 v23, v0

    .line 166
    .line 167
    move/from16 v20, v1

    .line 168
    .line 169
    float-to-double v0, v13

    .line 170
    invoke-static {v6, v7, v0, v1}, Ljava/lang/Math;->hypot(DD)D

    .line 171
    .line 172
    .line 173
    move-result-wide v0

    .line 174
    double-to-float v0, v0

    .line 175
    add-float v18, v18, v0

    .line 176
    .line 177
    aput v18, v5, v3

    .line 178
    .line 179
    const/16 v0, 0x5a

    .line 180
    .line 181
    if-eq v3, v0, :cond_c5

    .line 182
    .line 183
    add-int/lit8 v3, v3, 0x1

    .line 184
    .line 185
    move/from16 v19, v14

    .line 186
    .line 187
    move/from16 v1, v20

    .line 188
    .line 189
    move-object/from16 v0, v23

    .line 190
    .line 191
    const/16 v13, 0x65

    .line 192
    .line 193
    move/from16 v20, v15

    .line 194
    .line 195
    move/from16 v15, v21

    .line 196
    .line 197
    goto :goto_7b

    .line 198
    :cond_c5
    move/from16 v1, v16

    .line 199
    .line 200
    :goto_c7
    aget v3, v5, v1

    .line 201
    .line 202
    div-float v3, v3, v18

    .line 203
    .line 204
    aput v3, v5, v1

    .line 205
    .line 206
    if-eq v1, v0, :cond_d2

    .line 207
    .line 208
    add-int/lit8 v1, v1, 0x1

    .line 209
    .line 210
    goto :goto_c7

    .line 211
    :cond_d2
    const/4 v0, 0x0

    .line 212
    const/16 v1, 0x65

    .line 213
    .line 214
    :goto_d5
    if-ge v0, v1, :cond_105

    .line 215
    .line 216
    int-to-float v3, v0

    .line 217
    const/high16 v6, 0x42c80000  # 100.0f

    .line 218
    .line 219
    div-float/2addr v3, v6

    .line 220
    const/16 v6, 0x5b

    .line 221
    .line 222
    const/4 v7, 0x0

    .line 223
    invoke-static {v5, v7, v6, v3}, Ljava/util/Arrays;->binarySearch([FIIF)I

    .line 224
    .line 225
    .line 226
    move-result v6

    .line 227
    const/high16 v11, 0x42b40000  # 90.0f

    .line 228
    .line 229
    if-ltz v6, :cond_eb

    .line 230
    .line 231
    int-to-float v3, v6

    .line 232
    div-float/2addr v3, v11

    .line 233
    aput v3, v2, v0

    .line 234
    .line 235
    goto :goto_102

    .line 236
    :cond_eb
    const/4 v13, -0x1

    .line 237
    if-ne v6, v13, :cond_f1

    .line 238
    .line 239
    aput v22, v2, v0

    .line 240
    .line 241
    goto :goto_102

    .line 242
    :cond_f1
    neg-int v6, v6

    .line 243
    add-int/lit8 v13, v6, -0x2

    .line 244
    .line 245
    add-int/lit8 v6, v6, -0x1

    .line 246
    .line 247
    int-to-float v14, v13

    .line 248
    aget v13, v5, v13

    .line 249
    .line 250
    sub-float/2addr v3, v13

    .line 251
    aget v6, v5, v6

    .line 252
    .line 253
    sub-float/2addr v6, v13

    .line 254
    div-float/2addr v3, v6

    .line 255
    add-float/2addr v3, v14

    .line 256
    div-float/2addr v3, v11

    .line 257
    aput v3, v2, v0

    .line 258
    .line 259
    :goto_102
    add-int/lit8 v0, v0, 0x1

    .line 260
    .line 261
    goto :goto_d5

    .line 262
    :cond_105
    const/4 v7, 0x0

    .line 263
    goto :goto_10c

    .line 264
    :goto_107
    float-to-double v0, v5

    .line 265
    float-to-double v2, v11

    .line 266
    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->hypot(DD)D

    .line 267
    .line 268
    .line 269
    :goto_10c
    aput-object v12, v23, v9

    .line 270
    .line 271
    add-int/lit8 v9, v9, 0x1

    .line 272
    .line 273
    move v5, v7

    .line 274
    move/from16 v2, v16

    .line 275
    .line 276
    move/from16 v1, v20

    .line 277
    .line 278
    move-object/from16 v0, v23

    .line 279
    .line 280
    const/4 v3, 0x5

    .line 281
    const/4 v6, 0x4

    .line 282
    const/4 v7, 0x3

    .line 283
    goto/16 :goto_35

    .line 284
    .line 285
    :cond_11c
    return-void
.end method
