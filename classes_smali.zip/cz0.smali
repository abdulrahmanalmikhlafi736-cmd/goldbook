.class public Lcz0;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Ltw;
.implements Lcg1;
.implements Lvi1;


# instance fields
.field public final synthetic e:I

.field public f:Ljava/lang/Object;


# direct methods
.method public constructor <init>(FF)V
    .registers 5

    const/16 v0, 0x8

    iput v0, p0, Lcz0;->e:I

    .line 114
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 115
    new-instance v0, Liw;

    const v1, 0x3c23d70a

    .line 116
    invoke-direct {v0, p1, p2, v1}, Liw;-><init>(FFF)V

    .line 117
    iput-object v0, p0, Lcz0;->f:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(FFLu8;)V
    .registers 5

    const/16 v0, 0xa

    iput v0, p0, Lcz0;->e:I

    .line 105
    sget v0, Ldg1;->a:I

    if-eqz p3, :cond_e

    .line 106
    new-instance v0, Lcz0;

    invoke-direct {v0, p3, p1, p2}, Lcz0;-><init>(Lu8;FF)V

    goto :goto_13

    .line 107
    :cond_e
    new-instance v0, Lcz0;

    invoke-direct {v0, p1, p2}, Lcz0;-><init>(FF)V

    .line 108
    :goto_13
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 109
    new-instance p1, Lp3;

    invoke-direct {p1, v0}, Lp3;-><init>(Ljava/lang/Object;)V

    iput-object p1, p0, Lcz0;->f:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(I)V
    .registers 2

    iput p1, p0, Lcz0;->e:I

    packed-switch p1, :pswitch_data_1c

    .line 88
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 89
    new-instance p1, Landroid/graphics/Region;

    invoke-direct {p1}, Landroid/graphics/Region;-><init>()V

    iput-object p1, p0, Lcz0;->f:Ljava/lang/Object;

    return-void

    .line 90
    :pswitch_10  #0xb
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 91
    new-instance p1, Lzo;

    invoke-direct {p1}, Lzo;-><init>()V

    .line 92
    iput-object p1, p0, Lcz0;->f:Ljava/lang/Object;

    return-void

    nop

    :pswitch_data_1c
    .packed-switch 0xb
        :pswitch_10  #0000000b
    .end packed-switch
.end method

.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    .line 104
    iput p1, p0, Lcz0;->e:I

    iput-object p2, p0, Lcz0;->f:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(IZ)V
    .registers 3

    .line 87
    iput p1, p0, Lcz0;->e:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Landroid/view/View;)V
    .registers 4

    const/4 v0, 0x4

    iput v0, p0, Lcz0;->e:I

    .line 97
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 98
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1e

    if-lt v0, v1, :cond_17

    .line 99
    new-instance v0, Le71;

    const/4 v1, 0x1

    .line 100
    invoke-direct {v0, p1, v1}, Lx50;-><init>(Landroid/view/View;I)V

    .line 101
    iput-object p1, v0, Le71;->b:Landroid/view/View;

    .line 102
    iput-object v0, p0, Lcz0;->f:Ljava/lang/Object;

    goto :goto_1f

    .line 103
    :cond_17
    new-instance v0, Lx50;

    const/4 v1, 0x1

    invoke-direct {v0, p1, v1}, Lx50;-><init>(Landroid/view/View;I)V

    iput-object v0, p0, Lcz0;->f:Ljava/lang/Object;

    :goto_1f
    return-void
.end method

.method public constructor <init>(Ljp;)V
    .registers 4

    const/4 v0, 0x5

    iput v0, p0, Lcz0;->e:I

    .line 93
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 94
    new-instance v0, Ldw;

    .line 95
    sget v1, Ln71;->a:F

    .line 96
    invoke-direct {v0, v1, p1}, Ldw;-><init>(FLjp;)V

    iput-object v0, p0, Lcz0;->f:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lu8;FF)V
    .registers 9

    const/4 v0, 0x7

    iput v0, p0, Lcz0;->e:I

    .line 110
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 111
    invoke-virtual {p1}, Lu8;->b()I

    move-result v0

    new-array v1, v0, [Liw;

    const/4 v2, 0x0

    :goto_d
    if-ge v2, v0, :cond_1d

    .line 112
    new-instance v3, Liw;

    invoke-virtual {p1, v2}, Lu8;->a(I)F

    move-result v4

    invoke-direct {v3, p2, p3, v4}, Liw;-><init>(FFF)V

    aput-object v3, v1, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_d

    .line 113
    :cond_1d
    iput-object v1, p0, Lcz0;->f:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>([J)V
    .registers 8

    .line 1
    const/4 v0, 0x3

    .line 2
    iput v0, p0, Lcz0;->e:I

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    if-eqz p1, :cond_4e

    .line 8
    .line 9
    array-length v1, p1

    .line 10
    invoke-static {p1, v1}, Ljava/util/Arrays;->copyOf([JI)[J

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    new-instance v1, Lvj0;

    .line 15
    .line 16
    array-length v2, p1

    .line 17
    invoke-direct {v1, v2}, Lvj0;-><init>(I)V

    .line 18
    .line 19
    .line 20
    iget v2, v1, Lvj0;->b:I

    .line 21
    .line 22
    if-ltz v2, :cond_47

    .line 23
    .line 24
    array-length v3, p1

    .line 25
    if-nez v3, :cond_1b

    .line 26
    .line 27
    goto :goto_53

    .line 28
    :cond_1b
    array-length v3, p1

    .line 29
    add-int/2addr v3, v2

    .line 30
    iget-object v4, v1, Lvj0;->a:[J

    .line 31
    .line 32
    array-length v5, v4

    .line 33
    if-ge v5, v3, :cond_30

    .line 34
    .line 35
    array-length v5, v4

    .line 36
    mul-int/2addr v5, v0

    .line 37
    div-int/lit8 v5, v5, 0x2

    .line 38
    .line 39
    invoke-static {v3, v5}, Ljava/lang/Math;->max(II)I

    .line 40
    .line 41
    .line 42
    move-result v0

    .line 43
    invoke-static {v4, v0}, Ljava/util/Arrays;->copyOf([JI)[J

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    iput-object v0, v1, Lvj0;->a:[J

    .line 48
    .line 49
    :cond_30
    iget-object v0, v1, Lvj0;->a:[J

    .line 50
    .line 51
    iget v3, v1, Lvj0;->b:I

    .line 52
    .line 53
    if-eq v2, v3, :cond_3b

    .line 54
    .line 55
    array-length v4, p1

    .line 56
    add-int/2addr v4, v2

    .line 57
    invoke-static {v0, v0, v4, v2, v3}, Lba;->X([J[JIII)V

    .line 58
    .line 59
    .line 60
    :cond_3b
    array-length v3, p1

    .line 61
    const/4 v4, 0x0

    .line 62
    invoke-static {p1, v0, v2, v4, v3}, Lba;->X([J[JIII)V

    .line 63
    .line 64
    .line 65
    iget v0, v1, Lvj0;->b:I

    .line 66
    .line 67
    array-length p1, p1

    .line 68
    add-int/2addr v0, p1

    .line 69
    iput v0, v1, Lvj0;->b:I

    .line 70
    .line 71
    goto :goto_53

    .line 72
    :cond_47
    const-string p0, ""

    .line 73
    .line 74
    invoke-static {p0}, Lod;->f(Ljava/lang/String;)V

    .line 75
    .line 76
    .line 77
    const/4 p0, 0x0

    .line 78
    throw p0

    .line 79
    :cond_4e
    new-instance v1, Lvj0;

    .line 80
    .line 81
    invoke-direct {v1}, Lvj0;-><init>()V

    .line 82
    .line 83
    .line 84
    :goto_53
    iput-object v1, p0, Lcz0;->f:Ljava/lang/Object;

    .line 85
    .line 86
    return-void
.end method


# virtual methods
.method public a()Z
    .registers 1

    .line 1
    iget-object p0, p0, Lcz0;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Lp3;

    .line 4
    .line 5
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    .line 7
    .line 8
    const/4 p0, 0x0

    .line 9
    return p0
.end method

.method public b(Luw;Lml;)Ljava/lang/Object;
    .registers 7

    .line 1
    instance-of v0, p2, Lr;

    .line 2
    .line 3
    if-eqz v0, :cond_13

    .line 4
    .line 5
    move-object v0, p2

    .line 6
    check-cast v0, Lr;

    .line 7
    .line 8
    iget v1, v0, Lr;->k:I

    .line 9
    .line 10
    const/high16 v2, -0x80000000

    .line 11
    .line 12
    and-int v3, v1, v2

    .line 13
    .line 14
    if-eqz v3, :cond_13

    .line 15
    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, Lr;->k:I

    .line 18
    .line 19
    goto :goto_18

    .line 20
    :cond_13
    new-instance v0, Lr;

    .line 21
    .line 22
    invoke-direct {v0, p0, p2}, Lr;-><init>(Lcz0;Lml;)V

    .line 23
    .line 24
    .line 25
    :goto_18
    iget-object p2, v0, Lr;->i:Ljava/lang/Object;

    .line 26
    .line 27
    iget v1, v0, Lr;->k:I

    .line 28
    .line 29
    sget-object v2, Lwe1;->a:Lwe1;

    .line 30
    .line 31
    const/4 v3, 0x1

    .line 32
    if-eqz v1, :cond_32

    .line 33
    .line 34
    if-ne v1, v3, :cond_2b

    .line 35
    .line 36
    iget-object p0, v0, Lr;->h:Lyy0;

    .line 37
    .line 38
    :try_start_25
    invoke-static {p2}, Lnb0;->t(Ljava/lang/Object;)V
    :try_end_28
    .catchall {:try_start_25 .. :try_end_28} :catchall_29

    .line 39
    .line 40
    .line 41
    goto :goto_55

    .line 42
    :catchall_29
    move-exception p1

    .line 43
    goto :goto_5f

    .line 44
    :cond_2b
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 45
    .line 46
    invoke-static {p0}, Lod;->p(Ljava/lang/String;)V

    .line 47
    .line 48
    .line 49
    const/4 p0, 0x0

    .line 50
    return-object p0

    .line 51
    :cond_32
    invoke-static {p2}, Lnb0;->t(Ljava/lang/Object;)V

    .line 52
    .line 53
    .line 54
    new-instance p2, Lyy0;

    .line 55
    .line 56
    iget-object v1, v0, Lnl;->f:Lsl;

    .line 57
    .line 58
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 59
    .line 60
    .line 61
    invoke-direct {p2, p1, v1}, Lyy0;-><init>(Luw;Lsl;)V

    .line 62
    .line 63
    .line 64
    :try_start_3f
    iput-object p2, v0, Lr;->h:Lyy0;

    .line 65
    .line 66
    iput v3, v0, Lr;->k:I
    :try_end_43
    .catchall {:try_start_3f .. :try_end_43} :catchall_5d

    .line 67
    .line 68
    :try_start_43
    iget-object p0, p0, Lcz0;->f:Ljava/lang/Object;

    .line 69
    .line 70
    check-cast p0, Lm00;

    .line 71
    .line 72
    invoke-interface {p0, p2, v0}, Lm00;->f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 73
    .line 74
    .line 75
    move-result-object p0
    :try_end_4b
    .catchall {:try_start_43 .. :try_end_4b} :catchall_59

    .line 76
    sget-object p1, Lcm;->e:Lcm;

    .line 77
    .line 78
    if-ne p0, p1, :cond_50

    .line 79
    .line 80
    goto :goto_51

    .line 81
    :cond_50
    move-object p0, v2

    .line 82
    :goto_51
    if-ne p0, p1, :cond_54

    .line 83
    .line 84
    return-object p1

    .line 85
    :cond_54
    move-object p0, p2

    .line 86
    :goto_55
    invoke-virtual {p0}, Lnl;->q()V

    .line 87
    .line 88
    .line 89
    return-object v2

    .line 90
    :catchall_59
    move-exception p0

    .line 91
    move-object p1, p0

    .line 92
    :goto_5b
    move-object p0, p2

    .line 93
    goto :goto_5f

    .line 94
    :catchall_5d
    move-exception p1

    .line 95
    goto :goto_5b

    .line 96
    :goto_5f
    invoke-virtual {p0}, Lnl;->q()V

    .line 97
    .line 98
    .line 99
    throw p1
.end method

.method public e()[Ljava/lang/String;
    .registers 1

    .line 1
    iget-object p0, p0, Lcz0;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Lorg/chromium/support_lib_boundary/WebViewProviderFactoryBoundaryInterface;

    .line 4
    .line 5
    invoke-interface {p0}, Lorg/chromium/support_lib_boundary/WebViewProviderFactoryBoundaryInterface;->getSupportedFeatures()[Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    return-object p0
.end method

.method public f(JLu8;Lu8;Lu8;)Lu8;
    .registers 12

    .line 1
    iget-object p0, p0, Lcz0;->f:Ljava/lang/Object;

    .line 2
    .line 3
    move-object v0, p0

    .line 4
    check-cast v0, Lp3;

    .line 5
    .line 6
    move-wide v1, p1

    .line 7
    move-object v3, p3

    .line 8
    move-object v4, p4

    .line 9
    move-object v5, p5

    .line 10
    invoke-virtual/range {v0 .. v5}, Lp3;->f(JLu8;Lu8;Lu8;)Lu8;

    .line 11
    .line 12
    .line 13
    move-result-object p0

    .line 14
    return-object p0
.end method

.method public g(J)J
    .registers 5

    .line 1
    iget-object p0, p0, Lcz0;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Lzo;

    .line 4
    .line 5
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    .line 7
    .line 8
    invoke-static {p1, p2}, Lgg1;->b(J)F

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    const/4 v1, 0x0

    .line 13
    cmpl-float v0, v0, v1

    .line 14
    .line 15
    if-lez v0, :cond_19

    .line 16
    .line 17
    invoke-static {p1, p2}, Lgg1;->c(J)F

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    cmpl-float v0, v0, v1

    .line 22
    .line 23
    if-lez v0, :cond_19

    .line 24
    .line 25
    goto :goto_2e

    .line 26
    :cond_19
    new-instance v0, Ljava/lang/StringBuilder;

    .line 27
    .line 28
    const-string v1, "maximumVelocity should be a positive value. You specified="

    .line 29
    .line 30
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 31
    .line 32
    .line 33
    invoke-static {p1, p2}, Lgg1;->f(J)Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 38
    .line 39
    .line 40
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    invoke-static {v0}, Lp50;->b(Ljava/lang/String;)V

    .line 45
    .line 46
    .line 47
    :goto_2e
    iget-object v0, p0, Lzo;->a:Lig1;

    .line 48
    .line 49
    invoke-static {p1, p2}, Lgg1;->b(J)F

    .line 50
    .line 51
    .line 52
    move-result v1

    .line 53
    invoke-virtual {v0, v1}, Lig1;->b(F)F

    .line 54
    .line 55
    .line 56
    move-result v0

    .line 57
    iget-object p0, p0, Lzo;->b:Lig1;

    .line 58
    .line 59
    invoke-static {p1, p2}, Lgg1;->c(J)F

    .line 60
    .line 61
    .line 62
    move-result p1

    .line 63
    invoke-virtual {p0, p1}, Lig1;->b(F)F

    .line 64
    .line 65
    .line 66
    move-result p0

    .line 67
    invoke-static {v0, p0}, Lkb0;->c(FF)J

    .line 68
    .line 69
    .line 70
    move-result-wide p0

    .line 71
    return-wide p0
.end method

.method public getStatics()Lorg/chromium/support_lib_boundary/StaticsBoundaryInterface;
    .registers 2

    .line 1
    iget-object p0, p0, Lcz0;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Lorg/chromium/support_lib_boundary/WebViewProviderFactoryBoundaryInterface;

    .line 4
    .line 5
    invoke-interface {p0}, Lorg/chromium/support_lib_boundary/WebViewProviderFactoryBoundaryInterface;->getStatics()Ljava/lang/reflect/InvocationHandler;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    const-class v0, Lorg/chromium/support_lib_boundary/StaticsBoundaryInterface;

    .line 10
    .line 11
    invoke-static {v0, p0}, Lac;->k(Ljava/lang/Class;Ljava/lang/reflect/InvocationHandler;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object p0

    .line 15
    check-cast p0, Lorg/chromium/support_lib_boundary/StaticsBoundaryInterface;

    .line 16
    .line 17
    return-object p0
.end method

.method public getWebkitToCompatConverter()Lorg/chromium/support_lib_boundary/WebkitToCompatConverterBoundaryInterface;
    .registers 2

    .line 1
    iget-object p0, p0, Lcz0;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Lorg/chromium/support_lib_boundary/WebViewProviderFactoryBoundaryInterface;

    .line 4
    .line 5
    invoke-interface {p0}, Lorg/chromium/support_lib_boundary/WebViewProviderFactoryBoundaryInterface;->getWebkitToCompatConverter()Ljava/lang/reflect/InvocationHandler;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    const-class v0, Lorg/chromium/support_lib_boundary/WebkitToCompatConverterBoundaryInterface;

    .line 10
    .line 11
    invoke-static {v0, p0}, Lac;->k(Ljava/lang/Class;Ljava/lang/reflect/InvocationHandler;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object p0

    .line 15
    check-cast p0, Lorg/chromium/support_lib_boundary/WebkitToCompatConverterBoundaryInterface;

    .line 16
    .line 17
    return-object p0
.end method

.method public i(JLu8;Lu8;Lu8;)Lu8;
    .registers 12

    .line 1
    iget-object p0, p0, Lcz0;->f:Ljava/lang/Object;

    .line 2
    .line 3
    move-object v0, p0

    .line 4
    check-cast v0, Lp3;

    .line 5
    .line 6
    move-wide v1, p1

    .line 7
    move-object v3, p3

    .line 8
    move-object v4, p4

    .line 9
    move-object v5, p5

    .line 10
    invoke-virtual/range {v0 .. v5}, Lp3;->i(JLu8;Lu8;Lu8;)Lu8;

    .line 11
    .line 12
    .line 13
    move-result-object p0

    .line 14
    return-object p0
.end method

.method public j(Lu8;Lu8;Lu8;)Lu8;
    .registers 4

    .line 1
    iget-object p0, p0, Lcz0;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Lp3;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2, p3}, Lp3;->j(Lu8;Lu8;Lu8;)Lu8;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    return-object p0
.end method

.method public k(Lu8;Lu8;Lu8;)J
    .registers 4

    .line 1
    iget-object p0, p0, Lcz0;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Lp3;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2, p3}, Lp3;->k(Lu8;Lu8;Lu8;)J

    .line 6
    .line 7
    .line 8
    move-result-wide p0

    .line 9
    return-wide p0
.end method

.method public l(I)Lhw;
    .registers 3

    .line 1
    iget v0, p0, Lcz0;->e:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_16

    .line 4
    .line 5
    .line 6
    iget-object p0, p0, Lcz0;->f:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast p0, Lhw;

    .line 9
    .line 10
    return-object p0

    .line 11
    :pswitch_a  #0x8
    iget-object p0, p0, Lcz0;->f:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast p0, Liw;

    .line 14
    .line 15
    return-object p0

    .line 16
    :pswitch_f  #0x7
    iget-object p0, p0, Lcz0;->f:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast p0, [Liw;

    .line 19
    .line 20
    aget-object p0, p0, p1

    .line 21
    .line 22
    return-object p0

    .line 23
    :pswitch_data_16
    .packed-switch 0x7
        :pswitch_f  #00000007
        :pswitch_a  #00000008
    .end packed-switch
.end method

.method public m(Lye;Lxz;)Ljava/lang/Object;
    .registers 23

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    iget-object v2, v0, Lcz0;->f:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v2, Lfj;

    .line 8
    .line 9
    if-eqz v2, :cond_b

    .line 10
    .line 11
    goto :goto_10

    .line 12
    :cond_b
    const-string v2, "Called runAndWatch on a manager that has been disposed of"

    .line 13
    .line 14
    invoke-static {v2}, Lrt0;->b(Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    :goto_10
    iget-object v2, v0, Lcz0;->f:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast v2, Lfj;

    .line 20
    .line 21
    instance-of v3, v2, Lr51;

    .line 22
    .line 23
    if-eqz v3, :cond_a1

    .line 24
    .line 25
    check-cast v2, Lr51;

    .line 26
    .line 27
    iget-object v3, v2, Lr51;->f:Lz21;

    .line 28
    .line 29
    if-eqz v3, :cond_a1

    .line 30
    .line 31
    invoke-virtual {v3, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 32
    .line 33
    .line 34
    move-result v3

    .line 35
    if-nez v3, :cond_a1

    .line 36
    .line 37
    new-instance v3, Lnj0;

    .line 38
    .line 39
    invoke-direct {v3}, Lnj0;-><init>()V

    .line 40
    .line 41
    .line 42
    iget-object v4, v2, Lr51;->f:Lz21;

    .line 43
    .line 44
    if-eqz v4, :cond_2e

    .line 45
    .line 46
    goto :goto_33

    .line 47
    :cond_2e
    const-string v5, "promote must only be called when a manager is managing subscriptions for one channel and needs to start managing them for a second"

    .line 48
    .line 49
    invoke-static {v5}, Lrt0;->b(Ljava/lang/String;)V

    .line 50
    .line 51
    .line 52
    :goto_33
    iget-object v5, v2, Lr51;->d:Lik0;

    .line 53
    .line 54
    iget-object v6, v3, Lnj0;->c:Ljava/util/ArrayList;

    .line 55
    .line 56
    if-nez v5, :cond_47

    .line 57
    .line 58
    iget-object v5, v2, Lr51;->b:Ljava/lang/Object;

    .line 59
    .line 60
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 61
    .line 62
    .line 63
    new-instance v7, Lkj0;

    .line 64
    .line 65
    invoke-direct {v7, v5, v4}, Lkj0;-><init>(Ljava/lang/Object;Lz21;)V

    .line 66
    .line 67
    .line 68
    invoke-virtual {v6, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 69
    .line 70
    .line 71
    goto :goto_99

    .line 72
    :cond_47
    iget-object v7, v5, Lik0;->b:[Ljava/lang/Object;

    .line 73
    .line 74
    iget-object v5, v5, Lik0;->a:[J

    .line 75
    .line 76
    array-length v8, v5

    .line 77
    add-int/lit8 v8, v8, -0x2

    .line 78
    .line 79
    if-ltz v8, :cond_99

    .line 80
    .line 81
    const/4 v10, 0x0

    .line 82
    :goto_51
    aget-wide v11, v5, v10

    .line 83
    .line 84
    not-long v13, v11

    .line 85
    const/4 v15, 0x7

    .line 86
    shl-long/2addr v13, v15

    .line 87
    and-long/2addr v13, v11

    .line 88
    const-wide v15, -0x7f7f7f7f7f7f7f80L  # -2.937446524422997E-306

    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    and-long/2addr v13, v15

    .line 94
    cmp-long v13, v13, v15

    .line 95
    .line 96
    if-eqz v13, :cond_94

    .line 97
    .line 98
    sub-int v13, v10, v8

    .line 99
    .line 100
    not-int v13, v13

    .line 101
    ushr-int/lit8 v13, v13, 0x1f

    .line 102
    .line 103
    const/16 v14, 0x8

    .line 104
    .line 105
    rsub-int/lit8 v13, v13, 0x8

    .line 106
    .line 107
    const/4 v15, 0x0

    .line 108
    :goto_6b
    if-ge v15, v13, :cond_91

    .line 109
    .line 110
    const-wide/16 v16, 0xff

    .line 111
    .line 112
    and-long v16, v11, v16

    .line 113
    .line 114
    const-wide/16 v18, 0x80

    .line 115
    .line 116
    cmp-long v16, v16, v18

    .line 117
    .line 118
    if-gez v16, :cond_88

    .line 119
    .line 120
    shl-int/lit8 v16, v10, 0x3

    .line 121
    .line 122
    add-int v16, v16, v15

    .line 123
    .line 124
    aget-object v9, v7, v16

    .line 125
    .line 126
    move/from16 v16, v14

    .line 127
    .line 128
    new-instance v14, Lkj0;

    .line 129
    .line 130
    invoke-direct {v14, v9, v4}, Lkj0;-><init>(Ljava/lang/Object;Lz21;)V

    .line 131
    .line 132
    .line 133
    invoke-virtual {v6, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 134
    .line 135
    .line 136
    goto :goto_8a

    .line 137
    :cond_88
    move/from16 v16, v14

    .line 138
    .line 139
    :goto_8a
    shr-long v11, v11, v16

    .line 140
    .line 141
    add-int/lit8 v15, v15, 0x1

    .line 142
    .line 143
    move/from16 v14, v16

    .line 144
    .line 145
    goto :goto_6b

    .line 146
    :cond_91
    move v9, v14

    .line 147
    if-ne v13, v9, :cond_99

    .line 148
    .line 149
    :cond_94
    if-eq v10, v8, :cond_99

    .line 150
    .line 151
    add-int/lit8 v10, v10, 0x1

    .line 152
    .line 153
    goto :goto_51

    .line 154
    :cond_99
    :goto_99
    invoke-virtual {v3}, Lnj0;->d()V

    .line 155
    .line 156
    .line 157
    invoke-virtual {v2}, Lr51;->e()V

    .line 158
    .line 159
    .line 160
    iput-object v3, v0, Lcz0;->f:Ljava/lang/Object;

    .line 161
    .line 162
    :cond_a1
    iget-object v0, v0, Lcz0;->f:Ljava/lang/Object;

    .line 163
    .line 164
    check-cast v0, Lfj;

    .line 165
    .line 166
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 167
    .line 168
    .line 169
    invoke-virtual {v0, v1}, Lfj;->g(Lz21;)Li00;

    .line 170
    .line 171
    .line 172
    move-result-object v2

    .line 173
    invoke-static {}, Ln61;->j()Lg61;

    .line 174
    .line 175
    .line 176
    move-result-object v3

    .line 177
    invoke-virtual {v3, v2}, Lg61;->u(Li00;)Lg61;

    .line 178
    .line 179
    .line 180
    move-result-object v2

    .line 181
    invoke-virtual {v0, v1}, Lfj;->c(Lz21;)V

    .line 182
    .line 183
    .line 184
    :try_start_b7
    invoke-virtual {v2}, Lg61;->j()Lg61;

    .line 185
    .line 186
    .line 187
    move-result-object v1
    :try_end_bb
    .catchall {:try_start_b7 .. :try_end_bb} :catchall_c9

    .line 188
    :try_start_bb
    invoke-interface/range {p2 .. p2}, Lxz;->a()Ljava/lang/Object;

    .line 189
    .line 190
    .line 191
    move-result-object v3
    :try_end_bf
    .catchall {:try_start_bb .. :try_end_bf} :catchall_cb

    .line 192
    :try_start_bf
    invoke-static {v1}, Lg61;->q(Lg61;)V
    :try_end_c2
    .catchall {:try_start_bf .. :try_end_c2} :catchall_c9

    .line 193
    .line 194
    .line 195
    invoke-virtual {v2}, Lg61;->c()V

    .line 196
    .line 197
    .line 198
    invoke-virtual {v0}, Lfj;->d()V

    .line 199
    .line 200
    .line 201
    return-object v3

    .line 202
    :catchall_c9
    move-exception v0

    .line 203
    goto :goto_d0

    .line 204
    :catchall_cb
    move-exception v0

    .line 205
    :try_start_cc
    invoke-static {v1}, Lg61;->q(Lg61;)V

    .line 206
    .line 207
    .line 208
    throw v0
    :try_end_d0
    .catchall {:try_start_cc .. :try_end_d0} :catchall_c9

    .line 209
    :goto_d0
    invoke-virtual {v2}, Lg61;->c()V

    .line 210
    .line 211
    .line 212
    throw v0
.end method

.method public n(Lr60;)V
    .registers 5

    .line 1
    iget-object p0, p0, Lcz0;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Landroid/graphics/Region;

    .line 4
    .line 5
    iget v0, p1, Lr60;->a:I

    .line 6
    .line 7
    iget v1, p1, Lr60;->b:I

    .line 8
    .line 9
    iget v2, p1, Lr60;->c:I

    .line 10
    .line 11
    iget p1, p1, Lr60;->d:I

    .line 12
    .line 13
    invoke-virtual {p0, v0, v1, v2, p1}, Landroid/graphics/Region;->set(IIII)Z

    .line 14
    .line 15
    .line 16
    return-void
.end method

.method public o(I)V
    .registers 2

    .line 1
    iget-object p0, p0, Lcz0;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Lorg/chromium/support_lib_boundary/WebSettingsBoundaryInterface;

    .line 4
    .line 5
    invoke-interface {p0, p1}, Lorg/chromium/support_lib_boundary/WebSettingsBoundaryInterface;->setForceDark(I)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public p()V
    .registers 2

    .line 1
    iget-object p0, p0, Lcz0;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Lorg/chromium/support_lib_boundary/WebSettingsBoundaryInterface;

    .line 4
    .line 5
    const/4 v0, 0x1

    .line 6
    invoke-interface {p0, v0}, Lorg/chromium/support_lib_boundary/WebSettingsBoundaryInterface;->setForceDarkBehavior(I)V

    .line 7
    .line 8
    .line 9
    return-void
.end method
