.class public final Lbs;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# instance fields
.field public a:Lh6;

.field public b:Lt3;

.field public c:J

.field public d:I

.field public final e:Lte;


# direct methods
.method public constructor <init>()V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const-wide/16 v0, 0x0

    .line 5
    .line 6
    iput-wide v0, p0, Lbs;->c:J

    .line 7
    .line 8
    const/4 v0, 0x0

    .line 9
    iput v0, p0, Lbs;->d:I

    .line 10
    .line 11
    new-instance v0, Lte;

    .line 12
    .line 13
    invoke-direct {v0}, Lte;-><init>()V

    .line 14
    .line 15
    .line 16
    iput-object v0, p0, Lbs;->e:Lte;

    .line 17
    .line 18
    return-void
.end method
