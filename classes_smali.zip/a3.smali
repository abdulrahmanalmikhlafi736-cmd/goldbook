.class public final synthetic La3;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lm00;


# instance fields
.field public final synthetic e:Lm00;

.field public final synthetic f:Lm00;

.field public final synthetic g:J

.field public final synthetic h:J

.field public final synthetic i:J

.field public final synthetic j:Lpi;


# direct methods
.method public synthetic constructor <init>(Lm00;Lm00;JJJJLpi;)V
    .registers 12

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, La3;->e:Lm00;

    .line 5
    .line 6
    iput-object p2, p0, La3;->f:Lm00;

    .line 7
    .line 8
    iput-wide p5, p0, La3;->g:J

    .line 9
    .line 10
    iput-wide p7, p0, La3;->h:J

    .line 11
    .line 12
    iput-wide p9, p0, La3;->i:J

    .line 13
    .line 14
    iput-object p11, p0, La3;->j:Lpi;

    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public final f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 19

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v5, p1

    .line 4
    .line 5
    check-cast v5, Ld10;

    .line 6
    .line 7
    move-object/from16 v1, p2

    .line 8
    .line 9
    check-cast v1, Ljava/lang/Integer;

    .line 10
    .line 11
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    and-int/lit8 v2, v1, 0x3

    .line 16
    .line 17
    const/4 v3, 0x2

    .line 18
    const/4 v7, 0x1

    .line 19
    const/4 v8, 0x0

    .line 20
    if-eq v2, v3, :cond_17

    .line 21
    .line 22
    move v2, v7

    .line 23
    goto :goto_18

    .line 24
    :cond_17
    move v2, v8

    .line 25
    :goto_18
    and-int/2addr v1, v7

    .line 26
    invoke-virtual {v5, v1, v2}, Ld10;->O(IZ)Z

    .line 27
    .line 28
    .line 29
    move-result v1

    .line 30
    if-eqz v1, :cond_12e

    .line 31
    .line 32
    sget-object v1, Lji0;->a:Lji0;

    .line 33
    .line 34
    sget-object v2, Ld3;->a:Lup0;

    .line 35
    .line 36
    invoke-static {v1, v2}, Lac;->C(Lmi0;Lsp0;)Lmi0;

    .line 37
    .line 38
    .line 39
    move-result-object v1

    .line 40
    sget-object v2, Lzi1;->b:Lnq0;

    .line 41
    .line 42
    sget-object v3, Le3;->q:Llb;

    .line 43
    .line 44
    invoke-static {v2, v3, v5, v8}, Lnh;->a(Lr9;Llb;Ld10;I)Lph;

    .line 45
    .line 46
    .line 47
    move-result-object v2

    .line 48
    iget-wide v3, v5, Ld10;->T:J

    .line 49
    .line 50
    const/16 v9, 0x20

    .line 51
    .line 52
    ushr-long v10, v3, v9

    .line 53
    .line 54
    xor-long/2addr v3, v10

    .line 55
    long-to-int v3, v3

    .line 56
    invoke-virtual {v5}, Ld10;->l()Lqr0;

    .line 57
    .line 58
    .line 59
    move-result-object v4

    .line 60
    invoke-static {v5, v1}, Lvn;->I(Ld10;Lmi0;)Lmi0;

    .line 61
    .line 62
    .line 63
    move-result-object v1

    .line 64
    sget-object v6, Lij;->c:Lhj;

    .line 65
    .line 66
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 67
    .line 68
    .line 69
    sget-object v10, Lhj;->b:Ldk;

    .line 70
    .line 71
    invoke-virtual {v5}, Ld10;->Z()V

    .line 72
    .line 73
    .line 74
    iget-boolean v6, v5, Ld10;->S:Z

    .line 75
    .line 76
    if-eqz v6, :cond_51

    .line 77
    .line 78
    invoke-virtual {v5, v10}, Ld10;->k(Lxz;)V

    .line 79
    .line 80
    .line 81
    goto :goto_54

    .line 82
    :cond_51
    invoke-virtual {v5}, Ld10;->j0()V

    .line 83
    .line 84
    .line 85
    :goto_54
    sget-object v11, Lhj;->f:Ls7;

    .line 86
    .line 87
    invoke-static {v11, v5, v2}, Lmc0;->B(Lm00;Ld10;Ljava/lang/Object;)V

    .line 88
    .line 89
    .line 90
    sget-object v12, Lhj;->e:Ls7;

    .line 91
    .line 92
    invoke-static {v12, v5, v4}, Lmc0;->B(Lm00;Ld10;Ljava/lang/Object;)V

    .line 93
    .line 94
    .line 95
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 96
    .line 97
    .line 98
    move-result-object v2

    .line 99
    sget-object v13, Lhj;->g:Ls7;

    .line 100
    .line 101
    invoke-static {v5, v2, v13}, Lmc0;->p(Ld10;Ljava/lang/Integer;Lm00;)V

    .line 102
    .line 103
    .line 104
    sget-object v14, Lhj;->h:Li4;

    .line 105
    .line 106
    invoke-static {v5, v14}, Lmc0;->w(Ld10;Li00;)V

    .line 107
    .line 108
    .line 109
    sget-object v15, Lhj;->d:Ls7;

    .line 110
    .line 111
    invoke-static {v15, v5, v1}, Lmc0;->B(Lm00;Ld10;Ljava/lang/Object;)V

    .line 112
    .line 113
    .line 114
    const v1, 0x14a0f326

    .line 115
    .line 116
    .line 117
    invoke-virtual {v5, v1}, Ld10;->W(I)V

    .line 118
    .line 119
    .line 120
    invoke-virtual {v5, v8}, Ld10;->p(Z)V

    .line 121
    .line 122
    .line 123
    iget-object v1, v0, La3;->e:Lm00;

    .line 124
    .line 125
    if-nez v1, :cond_88

    .line 126
    .line 127
    const v1, 0x14a59771

    .line 128
    .line 129
    .line 130
    invoke-virtual {v5, v1}, Ld10;->W(I)V

    .line 131
    .line 132
    .line 133
    invoke-virtual {v5, v8}, Ld10;->p(Z)V

    .line 134
    .line 135
    .line 136
    goto :goto_aa

    .line 137
    :cond_88
    const v2, 0x14a59772

    .line 138
    .line 139
    .line 140
    invoke-virtual {v5, v2}, Ld10;->W(I)V

    .line 141
    .line 142
    .line 143
    sget-object v2, Lzi1;->k:Lle1;

    .line 144
    .line 145
    invoke-static {v2, v5}, Lme1;->a(Lle1;Ld10;)Lob1;

    .line 146
    .line 147
    .line 148
    move-result-object v3

    .line 149
    new-instance v2, Lc3;

    .line 150
    .line 151
    invoke-direct {v2, v8, v1}, Lc3;-><init>(ILm00;)V

    .line 152
    .line 153
    .line 154
    const v1, 0x43fb671

    .line 155
    .line 156
    .line 157
    invoke-static {v1, v2, v5}, Lvd1;->A(ILu00;Ld10;)Lpi;

    .line 158
    .line 159
    .line 160
    move-result-object v4

    .line 161
    const/16 v6, 0x180

    .line 162
    .line 163
    iget-wide v1, v0, La3;->g:J

    .line 164
    .line 165
    invoke-static/range {v1 .. v6}, Lnb0;->b(JLob1;Lpi;Ld10;I)V

    .line 166
    .line 167
    .line 168
    invoke-virtual {v5, v8}, Ld10;->p(Z)V

    .line 169
    .line 170
    .line 171
    :goto_aa
    iget-object v1, v0, La3;->f:Lm00;

    .line 172
    .line 173
    if-nez v1, :cond_b8

    .line 174
    .line 175
    const v1, 0x14b17479

    .line 176
    .line 177
    .line 178
    invoke-virtual {v5, v1}, Ld10;->W(I)V

    .line 179
    .line 180
    .line 181
    invoke-virtual {v5, v8}, Ld10;->p(Z)V

    .line 182
    .line 183
    .line 184
    goto :goto_da

    .line 185
    :cond_b8
    const v2, 0x14b1747a

    .line 186
    .line 187
    .line 188
    invoke-virtual {v5, v2}, Ld10;->W(I)V

    .line 189
    .line 190
    .line 191
    sget-object v2, Lzi1;->m:Lle1;

    .line 192
    .line 193
    invoke-static {v2, v5}, Lme1;->a(Lle1;Ld10;)Lob1;

    .line 194
    .line 195
    .line 196
    move-result-object v3

    .line 197
    new-instance v2, Lc3;

    .line 198
    .line 199
    invoke-direct {v2, v7, v1}, Lc3;-><init>(ILm00;)V

    .line 200
    .line 201
    .line 202
    const v1, 0x2a0e58f2

    .line 203
    .line 204
    .line 205
    invoke-static {v1, v2, v5}, Lvd1;->A(ILu00;Ld10;)Lpi;

    .line 206
    .line 207
    .line 208
    move-result-object v4

    .line 209
    const/16 v6, 0x180

    .line 210
    .line 211
    iget-wide v1, v0, La3;->h:J

    .line 212
    .line 213
    invoke-static/range {v1 .. v6}, Lnb0;->b(JLob1;Lpi;Ld10;I)V

    .line 214
    .line 215
    .line 216
    invoke-virtual {v5, v8}, Ld10;->p(Z)V

    .line 217
    .line 218
    .line 219
    :goto_da
    sget-object v1, Le3;->s:Llb;

    .line 220
    .line 221
    new-instance v2, Lf30;

    .line 222
    .line 223
    invoke-direct {v2, v1}, Lf30;-><init>(Llb;)V

    .line 224
    .line 225
    .line 226
    sget-object v1, Le3;->f:Lnb;

    .line 227
    .line 228
    invoke-static {v1, v8}, Lic;->d(Lnb;Z)Lmh0;

    .line 229
    .line 230
    .line 231
    move-result-object v1

    .line 232
    iget-wide v3, v5, Ld10;->T:J

    .line 233
    .line 234
    ushr-long v8, v3, v9

    .line 235
    .line 236
    xor-long/2addr v3, v8

    .line 237
    long-to-int v3, v3

    .line 238
    invoke-virtual {v5}, Ld10;->l()Lqr0;

    .line 239
    .line 240
    .line 241
    move-result-object v4

    .line 242
    invoke-static {v5, v2}, Lvn;->I(Ld10;Lmi0;)Lmi0;

    .line 243
    .line 244
    .line 245
    move-result-object v2

    .line 246
    invoke-virtual {v5}, Ld10;->Z()V

    .line 247
    .line 248
    .line 249
    iget-boolean v6, v5, Ld10;->S:Z

    .line 250
    .line 251
    if-eqz v6, :cond_100

    .line 252
    .line 253
    invoke-virtual {v5, v10}, Ld10;->k(Lxz;)V

    .line 254
    .line 255
    .line 256
    goto :goto_103

    .line 257
    :cond_100
    invoke-virtual {v5}, Ld10;->j0()V

    .line 258
    .line 259
    .line 260
    :goto_103
    invoke-static {v11, v5, v1}, Lmc0;->B(Lm00;Ld10;Ljava/lang/Object;)V

    .line 261
    .line 262
    .line 263
    invoke-static {v12, v5, v4}, Lmc0;->B(Lm00;Ld10;Ljava/lang/Object;)V

    .line 264
    .line 265
    .line 266
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 267
    .line 268
    .line 269
    move-result-object v1

    .line 270
    invoke-static {v5, v1, v13}, Lmc0;->p(Ld10;Ljava/lang/Integer;Lm00;)V

    .line 271
    .line 272
    .line 273
    invoke-static {v5, v14}, Lmc0;->w(Ld10;Li00;)V

    .line 274
    .line 275
    .line 276
    invoke-static {v15, v5, v2}, Lmc0;->B(Lm00;Ld10;Ljava/lang/Object;)V

    .line 277
    .line 278
    .line 279
    sget-object v1, Lzi1;->g:Lle1;

    .line 280
    .line 281
    invoke-static {v1, v5}, Lme1;->a(Lle1;Ld10;)Lob1;

    .line 282
    .line 283
    .line 284
    move-result-object v2

    .line 285
    move-object v4, v5

    .line 286
    const/4 v5, 0x0

    .line 287
    iget-wide v8, v0, La3;->i:J

    .line 288
    .line 289
    iget-object v3, v0, La3;->j:Lpi;

    .line 290
    .line 291
    move-wide v0, v8

    .line 292
    invoke-static/range {v0 .. v5}, Lnb0;->b(JLob1;Lpi;Ld10;I)V

    .line 293
    .line 294
    .line 295
    move-object v5, v4

    .line 296
    invoke-virtual {v5, v7}, Ld10;->p(Z)V

    .line 297
    .line 298
    .line 299
    invoke-virtual {v5, v7}, Ld10;->p(Z)V

    .line 300
    .line 301
    .line 302
    goto :goto_131

    .line 303
    :cond_12e
    invoke-virtual {v5}, Ld10;->R()V

    .line 304
    .line 305
    .line 306
    :goto_131
    sget-object v0, Lwe1;->a:Lwe1;

    .line 307
    .line 308
    return-object v0
.end method
