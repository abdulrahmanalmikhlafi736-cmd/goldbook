.class public final synthetic Lai;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lxz;


# instance fields
.field public final synthetic e:I

.field public final synthetic f:Lcom/almekhlafi/goldbook/MainActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/almekhlafi/goldbook/MainActivity;I)V
    .registers 3

    .line 1
    iput p2, p0, Lai;->e:I

    .line 2
    .line 3
    iput-object p1, p0, Lai;->f:Lcom/almekhlafi/goldbook/MainActivity;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .registers 5

    .line 1
    iget v0, p0, Lai;->e:I

    .line 2
    .line 3
    iget-object p0, p0, Lai;->f:Lcom/almekhlafi/goldbook/MainActivity;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_84

    .line 6
    .line 7
    .line 8
    invoke-static {p0}, Lk70;->E(Lkh1;)Ltz0;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0

    .line 13
    :pswitch_c  #0x4
    new-instance v0, Ljn0;

    .line 14
    .line 15
    new-instance v1, Lo4;

    .line 16
    .line 17
    const/4 v2, 0x2

    .line 18
    invoke-direct {v1, v2, p0}, Lo4;-><init>(ILjava/lang/Object;)V

    .line 19
    .line 20
    .line 21
    invoke-direct {v0, v1}, Ljn0;-><init>(Ljava/lang/Runnable;)V

    .line 22
    .line 23
    .line 24
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 25
    .line 26
    const/16 v2, 0x21

    .line 27
    .line 28
    if-lt v1, v2, :cond_48

    .line 29
    .line 30
    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    .line 31
    .line 32
    .line 33
    move-result-object v1

    .line 34
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 35
    .line 36
    .line 37
    move-result-object v2

    .line 38
    invoke-static {v1, v2}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 39
    .line 40
    .line 41
    move-result v1

    .line 42
    if-nez v1, :cond_3e

    .line 43
    .line 44
    new-instance v1, Landroid/os/Handler;

    .line 45
    .line 46
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 47
    .line 48
    .line 49
    move-result-object v2

    .line 50
    invoke-direct {v1, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 51
    .line 52
    .line 53
    new-instance v2, Le5;

    .line 54
    .line 55
    const/4 v3, 0x1

    .line 56
    invoke-direct {v2, v3, p0, v0}, Le5;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 57
    .line 58
    .line 59
    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 60
    .line 61
    .line 62
    goto :goto_48

    .line 63
    :cond_3e
    iget-object v1, p0, Lji;->e:Lud0;

    .line 64
    .line 65
    new-instance v2, Lbi;

    .line 66
    .line 67
    invoke-direct {v2, v0, p0}, Lbi;-><init>(Ljn0;Lki;)V

    .line 68
    .line 69
    .line 70
    invoke-virtual {v1, v2}, Lud0;->a(Lrd0;)V

    .line 71
    .line 72
    .line 73
    :cond_48
    :goto_48
    return-object v0

    .line 74
    :pswitch_49  #0x3
    new-instance v0, Lyz0;

    .line 75
    .line 76
    invoke-virtual {p0}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    .line 77
    .line 78
    .line 79
    move-result-object v1

    .line 80
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 81
    .line 82
    .line 83
    move-result-object v2

    .line 84
    if-eqz v2, :cond_5e

    .line 85
    .line 86
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 87
    .line 88
    .line 89
    move-result-object v2

    .line 90
    invoke-virtual {v2}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    .line 91
    .line 92
    .line 93
    move-result-object v2

    .line 94
    goto :goto_5f

    .line 95
    :cond_5e
    const/4 v2, 0x0

    .line 96
    :goto_5f
    invoke-direct {v0, v1, p0, v2}, Lyz0;-><init>(Landroid/app/Application;Lcom/almekhlafi/goldbook/MainActivity;Landroid/os/Bundle;)V

    .line 97
    .line 98
    .line 99
    return-object v0

    .line 100
    :pswitch_63  #0x2
    new-instance v0, Lcq;

    .line 101
    .line 102
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 103
    .line 104
    .line 105
    invoke-virtual {p0}, Lki;->a()Lp3;

    .line 106
    .line 107
    .line 108
    move-result-object p0

    .line 109
    invoke-virtual {p0, v0}, Lp3;->c(Lhl0;)V

    .line 110
    .line 111
    .line 112
    return-object v0

    .line 113
    :pswitch_70  #0x1
    new-instance v0, Lwz;

    .line 114
    .line 115
    iget-object v1, p0, Lki;->j:Lgi;

    .line 116
    .line 117
    new-instance v2, Lai;

    .line 118
    .line 119
    const/4 v3, 0x0

    .line 120
    invoke-direct {v2, p0, v3}, Lai;-><init>(Lcom/almekhlafi/goldbook/MainActivity;I)V

    .line 121
    .line 122
    .line 123
    invoke-direct {v0, v1, v2}, Lwz;-><init>(Ljava/util/concurrent/Executor;Lai;)V

    .line 124
    .line 125
    .line 126
    return-object v0

    .line 127
    :pswitch_7e  #0x0
    invoke-virtual {p0}, Lki;->reportFullyDrawn()V

    .line 128
    .line 129
    .line 130
    sget-object p0, Lwe1;->a:Lwe1;

    .line 131
    .line 132
    return-object p0

    .line 133
    :pswitch_data_84
    .packed-switch 0x0
        :pswitch_7e  #00000000
        :pswitch_70  #00000001
        :pswitch_63  #00000002
        :pswitch_49  #00000003
        :pswitch_c  #00000004
    .end packed-switch
.end method
