.class public final Lb91;
.super Lh90;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lm00;


# instance fields
.field public final synthetic f:Lmi0;

.field public final synthetic g:Lm00;

.field public final synthetic h:I

.field public final synthetic i:I


# direct methods
.method public constructor <init>(Lmi0;Lm00;II)V
    .registers 5

    .line 1
    iput-object p1, p0, Lb91;->f:Lmi0;

    .line 2
    .line 3
    iput-object p2, p0, Lb91;->g:Lm00;

    .line 4
    .line 5
    iput p3, p0, Lb91;->h:I

    .line 6
    .line 7
    iput p4, p0, Lb91;->i:I

    .line 8
    .line 9
    const/4 p1, 0x2

    .line 10
    invoke-direct {p0, p1}, Lh90;-><init>(I)V

    .line 11
    .line 12
    .line 13
    return-void
.end method


# virtual methods
.method public final f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 1
    check-cast p1, Ld10;

    .line 2
    .line 3
    check-cast p2, Ljava/lang/Number;

    .line 4
    .line 5
    invoke-virtual {p2}, Ljava/lang/Number;->intValue()I

    .line 6
    .line 7
    .line 8
    iget p2, p0, Lb91;->h:I

    .line 9
    .line 10
    or-int/lit8 p2, p2, 0x1

    .line 11
    .line 12
    invoke-static {p2}, Lwc0;->s(I)I

    .line 13
    .line 14
    .line 15
    move-result p2

    .line 16
    iget v0, p0, Lb91;->i:I

    .line 17
    .line 18
    iget-object v1, p0, Lb91;->f:Lmi0;

    .line 19
    .line 20
    iget-object p0, p0, Lb91;->g:Lm00;

    .line 21
    .line 22
    invoke-static {v1, p0, p1, p2, v0}, Lvn;->b(Lmi0;Lm00;Ld10;II)V

    .line 23
    .line 24
    .line 25
    sget-object p0, Lwe1;->a:Lwe1;

    .line 26
    .line 27
    return-object p0
.end method
