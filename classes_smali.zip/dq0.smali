.class public interface abstract Ldq0;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# virtual methods
.method public abstract a()F
.end method

.method public abstract b()Z
.end method

.method public abstract c()F
.end method
