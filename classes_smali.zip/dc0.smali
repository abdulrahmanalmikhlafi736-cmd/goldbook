.class public final Ldc0;
.super Lli0;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lg21;


# instance fields
.field public s:Lxz;

.field public t:Lyb0;

.field public u:Lbp0;

.field public v:Z

.field public w:Lu01;

.field public final x:Lac0;

.field public y:Lac0;


# direct methods
.method public constructor <init>(Lxz;Lyb0;Lbp0;Z)V
    .registers 5

    .line 1
    invoke-direct {p0}, Lli0;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Ldc0;->s:Lxz;

    .line 5
    .line 6
    iput-object p2, p0, Ldc0;->t:Lyb0;

    .line 7
    .line 8
    iput-object p3, p0, Ldc0;->u:Lbp0;

    .line 9
    .line 10
    iput-boolean p4, p0, Ldc0;->v:Z

    .line 11
    .line 12
    new-instance p1, Lac0;

    .line 13
    .line 14
    const/4 p2, 0x0

    .line 15
    invoke-direct {p1, p0, p2}, Lac0;-><init>(Ldc0;I)V

    .line 16
    .line 17
    .line 18
    iput-object p1, p0, Ldc0;->x:Lac0;

    .line 19
    .line 20
    invoke-virtual {p0}, Ldc0;->r0()V

    .line 21
    .line 22
    .line 23
    return-void
.end method


# virtual methods
.method public final Q(Lr21;)V
    .registers 9

    .line 1
    sget-object v0, Lp21;->a:[La90;

    .line 2
    .line 3
    sget-object v0, Ln21;->n:Lq21;

    .line 4
    .line 5
    sget-object v1, Lp21;->a:[La90;

    .line 6
    .line 7
    const/4 v2, 0x6

    .line 8
    aget-object v2, v1, v2

    .line 9
    .line 10
    sget-object v2, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 11
    .line 12
    invoke-interface {p1, v0, v2}, Lr21;->a(Lq21;Ljava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    iget-object v0, p0, Ldc0;->x:Lac0;

    .line 16
    .line 17
    sget-object v2, Ln21;->L:Lq21;

    .line 18
    .line 19
    invoke-interface {p1, v2, v0}, Lr21;->a(Lq21;Ljava/lang/Object;)V

    .line 20
    .line 21
    .line 22
    iget-object v0, p0, Ldc0;->u:Lbp0;

    .line 23
    .line 24
    iget-object v2, p0, Ldc0;->w:Lu01;

    .line 25
    .line 26
    const-string v3, "scrollAxisRange"

    .line 27
    .line 28
    const/4 v4, 0x0

    .line 29
    sget-object v5, Lbp0;->e:Lbp0;

    .line 30
    .line 31
    if-ne v0, v5, :cond_30

    .line 32
    .line 33
    if-eqz v2, :cond_2c

    .line 34
    .line 35
    sget-object v0, Ln21;->w:Lq21;

    .line 36
    .line 37
    const/16 v3, 0xd

    .line 38
    .line 39
    aget-object v3, v1, v3

    .line 40
    .line 41
    invoke-interface {p1, v0, v2}, Lr21;->a(Lq21;Ljava/lang/Object;)V

    .line 42
    .line 43
    .line 44
    goto :goto_3b

    .line 45
    :cond_2c
    invoke-static {v3}, Lk70;->T(Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    throw v4

    .line 49
    :cond_30
    if-eqz v2, :cond_81

    .line 50
    .line 51
    sget-object v0, Ln21;->v:Lq21;

    .line 52
    .line 53
    const/16 v3, 0xc

    .line 54
    .line 55
    aget-object v3, v1, v3

    .line 56
    .line 57
    invoke-interface {p1, v0, v2}, Lr21;->a(Lq21;Ljava/lang/Object;)V

    .line 58
    .line 59
    .line 60
    :goto_3b
    iget-object v0, p0, Ldc0;->y:Lac0;

    .line 61
    .line 62
    if-eqz v0, :cond_49

    .line 63
    .line 64
    sget-object v2, Lc21;->f:Lq21;

    .line 65
    .line 66
    new-instance v3, Lo0;

    .line 67
    .line 68
    invoke-direct {v3, v4, v0}, Lo0;-><init>(Ljava/lang/String;Lu00;)V

    .line 69
    .line 70
    .line 71
    invoke-interface {p1, v2, v3}, Lr21;->a(Lq21;Ljava/lang/Object;)V

    .line 72
    .line 73
    .line 74
    :cond_49
    new-instance v0, Lbc0;

    .line 75
    .line 76
    const/4 v2, 0x2

    .line 77
    invoke-direct {v0, p0, v2}, Lbc0;-><init>(Ldc0;I)V

    .line 78
    .line 79
    .line 80
    sget-object v2, Lc21;->B:Lq21;

    .line 81
    .line 82
    new-instance v3, Lo0;

    .line 83
    .line 84
    new-instance v5, Lj3;

    .line 85
    .line 86
    const/16 v6, 0x16

    .line 87
    .line 88
    invoke-direct {v5, v6, v0}, Lj3;-><init>(ILjava/lang/Object;)V

    .line 89
    .line 90
    .line 91
    invoke-direct {v3, v4, v5}, Lo0;-><init>(Ljava/lang/String;Lu00;)V

    .line 92
    .line 93
    .line 94
    invoke-interface {p1, v2, v3}, Lr21;->a(Lq21;Ljava/lang/Object;)V

    .line 95
    .line 96
    .line 97
    iget-object p0, p0, Ldc0;->t:Lyb0;

    .line 98
    .line 99
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 100
    .line 101
    .line 102
    new-instance v0, Lsg;

    .line 103
    .line 104
    iget-object p0, p0, Lyb0;->a:Lsp;

    .line 105
    .line 106
    invoke-virtual {p0}, Lsp;->getValue()Ljava/lang/Object;

    .line 107
    .line 108
    .line 109
    move-result-object p0

    .line 110
    check-cast p0, Ljava/lang/Number;

    .line 111
    .line 112
    invoke-virtual {p0}, Ljava/lang/Number;->intValue()I

    .line 113
    .line 114
    .line 115
    move-result p0

    .line 116
    const/4 v2, 0x1

    .line 117
    invoke-direct {v0, v2, p0}, Lsg;-><init>(II)V

    .line 118
    .line 119
    .line 120
    sget-object p0, Ln21;->f:Lq21;

    .line 121
    .line 122
    const/16 v2, 0x17

    .line 123
    .line 124
    aget-object v1, v1, v2

    .line 125
    .line 126
    invoke-interface {p1, p0, v0}, Lr21;->a(Lq21;Ljava/lang/Object;)V

    .line 127
    .line 128
    .line 129
    return-void

    .line 130
    :cond_81
    invoke-static {v3}, Lk70;->T(Ljava/lang/String;)V

    .line 131
    .line 132
    .line 133
    throw v4
.end method

.method public final synthetic S()Z
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public final synthetic T()Z
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public final synthetic e()Z
    .registers 1

    .line 1
    const/4 p0, 0x1

    .line 2
    return p0
.end method

.method public final e0()Z
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public final r0()V
    .registers 5

    .line 1
    new-instance v0, Lu01;

    .line 2
    .line 3
    new-instance v1, Lbc0;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    invoke-direct {v1, p0, v2}, Lbc0;-><init>(Ldc0;I)V

    .line 7
    .line 8
    .line 9
    new-instance v2, Lbc0;

    .line 10
    .line 11
    const/4 v3, 0x1

    .line 12
    invoke-direct {v2, p0, v3}, Lbc0;-><init>(Ldc0;I)V

    .line 13
    .line 14
    .line 15
    invoke-direct {v0, v1, v2}, Lu01;-><init>(Lxz;Lxz;)V

    .line 16
    .line 17
    .line 18
    iput-object v0, p0, Ldc0;->w:Lu01;

    .line 19
    .line 20
    iget-boolean v0, p0, Ldc0;->v:Z

    .line 21
    .line 22
    if-eqz v0, :cond_1e

    .line 23
    .line 24
    new-instance v0, Lac0;

    .line 25
    .line 26
    const/4 v1, 0x1

    .line 27
    invoke-direct {v0, p0, v1}, Lac0;-><init>(Ldc0;I)V

    .line 28
    .line 29
    .line 30
    goto :goto_1f

    .line 31
    :cond_1e
    const/4 v0, 0x0

    .line 32
    :goto_1f
    iput-object v0, p0, Ldc0;->y:Lac0;

    .line 33
    .line 34
    return-void
.end method
