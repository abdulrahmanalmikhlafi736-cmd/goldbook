.class public abstract Le01;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# static fields
.field public static final A:Lal;

.field public static final B:Ld01;

.field public static final C:Ld01;

.field public static final D:Ld01;

.field public static final a:Lal;

.field public static final b:Lal;

.field public static final c:Lal;

.field public static final d:Lal;

.field public static final e:Lal;

.field public static final f:Lal;

.field public static final g:Lal;

.field public static final h:Lal;

.field public static final i:Lal;

.field public static final j:Lal;

.field public static final k:Lal;

.field public static final l:Lal;

.field public static final m:Lal;

.field public static final n:Lal;

.field public static final o:Lal;

.field public static final p:Ld01;

.field public static final q:Ld01;

.field public static final r:Ld01;

.field public static final s:Ld01;

.field public static final t:Lal;

.field public static final u:Lal;

.field public static final v:Ld01;

.field public static final w:Ld01;

.field public static final x:Ld01;

.field public static final y:Lal;

.field public static final z:Lal;


# direct methods
.method static constructor <clinit>()V
    .registers 16

    .line 1
    new-instance v0, Lo9;

    .line 2
    .line 3
    const/16 v1, 0x15

    .line 4
    .line 5
    invoke-direct {v0, v1}, Lo9;-><init>(I)V

    .line 6
    .line 7
    .line 8
    new-instance v2, Lz1;

    .line 9
    .line 10
    const/16 v3, 0x18

    .line 11
    .line 12
    invoke-direct {v2, v3}, Lz1;-><init>(I)V

    .line 13
    .line 14
    .line 15
    new-instance v4, Lal;

    .line 16
    .line 17
    invoke-direct {v4, v1, v0, v2}, Lal;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 18
    .line 19
    .line 20
    new-instance v0, Lo9;

    .line 21
    .line 22
    const/16 v2, 0x1c

    .line 23
    .line 24
    invoke-direct {v0, v2}, Lo9;-><init>(I)V

    .line 25
    .line 26
    .line 27
    new-instance v4, Lb01;

    .line 28
    .line 29
    const/4 v5, 0x6

    .line 30
    invoke-direct {v4, v5}, Lb01;-><init>(I)V

    .line 31
    .line 32
    .line 33
    new-instance v6, Lal;

    .line 34
    .line 35
    invoke-direct {v6, v1, v0, v4}, Lal;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 36
    .line 37
    .line 38
    sput-object v6, Le01;->a:Lal;

    .line 39
    .line 40
    new-instance v0, Lc01;

    .line 41
    .line 42
    const/16 v4, 0xa

    .line 43
    .line 44
    invoke-direct {v0, v4}, Lc01;-><init>(I)V

    .line 45
    .line 46
    .line 47
    new-instance v6, Lb01;

    .line 48
    .line 49
    const/16 v7, 0x12

    .line 50
    .line 51
    invoke-direct {v6, v7}, Lb01;-><init>(I)V

    .line 52
    .line 53
    .line 54
    new-instance v8, Lal;

    .line 55
    .line 56
    invoke-direct {v8, v1, v0, v6}, Lal;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 57
    .line 58
    .line 59
    sput-object v8, Le01;->b:Lal;

    .line 60
    .line 61
    new-instance v0, Lc01;

    .line 62
    .line 63
    const/16 v6, 0x11

    .line 64
    .line 65
    invoke-direct {v0, v6}, Lc01;-><init>(I)V

    .line 66
    .line 67
    .line 68
    new-instance v8, Lb01;

    .line 69
    .line 70
    const/16 v9, 0x14

    .line 71
    .line 72
    invoke-direct {v8, v9}, Lb01;-><init>(I)V

    .line 73
    .line 74
    .line 75
    new-instance v10, Lal;

    .line 76
    .line 77
    invoke-direct {v10, v1, v0, v8}, Lal;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 78
    .line 79
    .line 80
    sput-object v10, Le01;->c:Lal;

    .line 81
    .line 82
    new-instance v0, Lc01;

    .line 83
    .line 84
    const/16 v8, 0x13

    .line 85
    .line 86
    invoke-direct {v0, v8}, Lc01;-><init>(I)V

    .line 87
    .line 88
    .line 89
    new-instance v10, Lb01;

    .line 90
    .line 91
    invoke-direct {v10, v1}, Lb01;-><init>(I)V

    .line 92
    .line 93
    .line 94
    new-instance v11, Lal;

    .line 95
    .line 96
    invoke-direct {v11, v1, v0, v10}, Lal;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 97
    .line 98
    .line 99
    sput-object v11, Le01;->d:Lal;

    .line 100
    .line 101
    new-instance v0, Lo9;

    .line 102
    .line 103
    const/16 v10, 0x1a

    .line 104
    .line 105
    invoke-direct {v0, v10}, Lo9;-><init>(I)V

    .line 106
    .line 107
    .line 108
    new-instance v11, Lb01;

    .line 109
    .line 110
    const/4 v12, 0x3

    .line 111
    invoke-direct {v11, v12}, Lb01;-><init>(I)V

    .line 112
    .line 113
    .line 114
    new-instance v13, Lal;

    .line 115
    .line 116
    invoke-direct {v13, v1, v0, v11}, Lal;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 117
    .line 118
    .line 119
    sput-object v13, Le01;->e:Lal;

    .line 120
    .line 121
    new-instance v0, Lc01;

    .line 122
    .line 123
    const/4 v11, 0x7

    .line 124
    invoke-direct {v0, v11}, Lc01;-><init>(I)V

    .line 125
    .line 126
    .line 127
    new-instance v13, Lb01;

    .line 128
    .line 129
    const/16 v14, 0xe

    .line 130
    .line 131
    invoke-direct {v13, v14}, Lb01;-><init>(I)V

    .line 132
    .line 133
    .line 134
    new-instance v15, Lal;

    .line 135
    .line 136
    invoke-direct {v15, v1, v0, v13}, Lal;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 137
    .line 138
    .line 139
    sput-object v15, Le01;->f:Lal;

    .line 140
    .line 141
    new-instance v0, Lc01;

    .line 142
    .line 143
    invoke-direct {v0, v7}, Lc01;-><init>(I)V

    .line 144
    .line 145
    .line 146
    new-instance v7, Lb01;

    .line 147
    .line 148
    const/16 v13, 0x16

    .line 149
    .line 150
    invoke-direct {v7, v13}, Lb01;-><init>(I)V

    .line 151
    .line 152
    .line 153
    new-instance v15, Lal;

    .line 154
    .line 155
    invoke-direct {v15, v1, v0, v7}, Lal;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 156
    .line 157
    .line 158
    sput-object v15, Le01;->g:Lal;

    .line 159
    .line 160
    new-instance v0, Lc01;

    .line 161
    .line 162
    invoke-direct {v0, v9}, Lc01;-><init>(I)V

    .line 163
    .line 164
    .line 165
    new-instance v7, Lb01;

    .line 166
    .line 167
    const/16 v9, 0x17

    .line 168
    .line 169
    invoke-direct {v7, v9}, Lb01;-><init>(I)V

    .line 170
    .line 171
    .line 172
    new-instance v15, Lal;

    .line 173
    .line 174
    invoke-direct {v15, v1, v0, v7}, Lal;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 175
    .line 176
    .line 177
    sput-object v15, Le01;->h:Lal;

    .line 178
    .line 179
    new-instance v0, Lc01;

    .line 180
    .line 181
    invoke-direct {v0, v1}, Lc01;-><init>(I)V

    .line 182
    .line 183
    .line 184
    new-instance v7, Lz1;

    .line 185
    .line 186
    invoke-direct {v7, v9}, Lz1;-><init>(I)V

    .line 187
    .line 188
    .line 189
    new-instance v15, Lal;

    .line 190
    .line 191
    invoke-direct {v15, v1, v0, v7}, Lal;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 192
    .line 193
    .line 194
    sput-object v15, Le01;->i:Lal;

    .line 195
    .line 196
    new-instance v0, Lo9;

    .line 197
    .line 198
    invoke-direct {v0, v13}, Lo9;-><init>(I)V

    .line 199
    .line 200
    .line 201
    new-instance v7, Lz1;

    .line 202
    .line 203
    const/16 v13, 0x19

    .line 204
    .line 205
    invoke-direct {v7, v13}, Lz1;-><init>(I)V

    .line 206
    .line 207
    .line 208
    new-instance v15, Lal;

    .line 209
    .line 210
    invoke-direct {v15, v1, v0, v7}, Lal;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 211
    .line 212
    .line 213
    sput-object v15, Le01;->j:Lal;

    .line 214
    .line 215
    new-instance v0, Lo9;

    .line 216
    .line 217
    invoke-direct {v0, v9}, Lo9;-><init>(I)V

    .line 218
    .line 219
    .line 220
    new-instance v7, Lz1;

    .line 221
    .line 222
    invoke-direct {v7, v10}, Lz1;-><init>(I)V

    .line 223
    .line 224
    .line 225
    new-instance v9, Lal;

    .line 226
    .line 227
    invoke-direct {v9, v1, v0, v7}, Lal;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 228
    .line 229
    .line 230
    sput-object v9, Le01;->k:Lal;

    .line 231
    .line 232
    new-instance v0, Lo9;

    .line 233
    .line 234
    invoke-direct {v0, v3}, Lo9;-><init>(I)V

    .line 235
    .line 236
    .line 237
    new-instance v3, Lz1;

    .line 238
    .line 239
    const/16 v7, 0x1b

    .line 240
    .line 241
    invoke-direct {v3, v7}, Lz1;-><init>(I)V

    .line 242
    .line 243
    .line 244
    new-instance v9, Lal;

    .line 245
    .line 246
    invoke-direct {v9, v1, v0, v3}, Lal;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 247
    .line 248
    .line 249
    sput-object v9, Le01;->l:Lal;

    .line 250
    .line 251
    new-instance v0, Lo9;

    .line 252
    .line 253
    invoke-direct {v0, v13}, Lo9;-><init>(I)V

    .line 254
    .line 255
    .line 256
    new-instance v3, Lz1;

    .line 257
    .line 258
    invoke-direct {v3, v2}, Lz1;-><init>(I)V

    .line 259
    .line 260
    .line 261
    new-instance v2, Lal;

    .line 262
    .line 263
    invoke-direct {v2, v1, v0, v3}, Lal;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 264
    .line 265
    .line 266
    sput-object v2, Le01;->m:Lal;

    .line 267
    .line 268
    new-instance v0, Lo9;

    .line 269
    .line 270
    invoke-direct {v0, v7}, Lo9;-><init>(I)V

    .line 271
    .line 272
    .line 273
    new-instance v2, Lz1;

    .line 274
    .line 275
    const/16 v3, 0x1d

    .line 276
    .line 277
    invoke-direct {v2, v3}, Lz1;-><init>(I)V

    .line 278
    .line 279
    .line 280
    new-instance v7, Lal;

    .line 281
    .line 282
    invoke-direct {v7, v1, v0, v2}, Lal;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 283
    .line 284
    .line 285
    sput-object v7, Le01;->n:Lal;

    .line 286
    .line 287
    new-instance v0, Lo9;

    .line 288
    .line 289
    invoke-direct {v0, v3}, Lo9;-><init>(I)V

    .line 290
    .line 291
    .line 292
    new-instance v2, Lb01;

    .line 293
    .line 294
    const/4 v3, 0x0

    .line 295
    invoke-direct {v2, v3}, Lb01;-><init>(I)V

    .line 296
    .line 297
    .line 298
    new-instance v7, Lal;

    .line 299
    .line 300
    invoke-direct {v7, v1, v0, v2}, Lal;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 301
    .line 302
    .line 303
    new-instance v0, Lc01;

    .line 304
    .line 305
    invoke-direct {v0, v3}, Lc01;-><init>(I)V

    .line 306
    .line 307
    .line 308
    new-instance v2, Lb01;

    .line 309
    .line 310
    const/4 v3, 0x1

    .line 311
    invoke-direct {v2, v3}, Lb01;-><init>(I)V

    .line 312
    .line 313
    .line 314
    new-instance v7, Lal;

    .line 315
    .line 316
    invoke-direct {v7, v1, v0, v2}, Lal;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 317
    .line 318
    .line 319
    sput-object v7, Le01;->o:Lal;

    .line 320
    .line 321
    sget-object v0, Lxh0;->g:Lxh0;

    .line 322
    .line 323
    sget-object v2, Lyh0;->g:Lyh0;

    .line 324
    .line 325
    new-instance v7, Ld01;

    .line 326
    .line 327
    invoke-direct {v7, v0, v2}, Ld01;-><init>(Lm00;Li00;)V

    .line 328
    .line 329
    .line 330
    sput-object v7, Le01;->p:Ld01;

    .line 331
    .line 332
    new-instance v0, Lc01;

    .line 333
    .line 334
    invoke-direct {v0, v3}, Lc01;-><init>(I)V

    .line 335
    .line 336
    .line 337
    new-instance v2, Lb01;

    .line 338
    .line 339
    const/4 v3, 0x2

    .line 340
    invoke-direct {v2, v3}, Lb01;-><init>(I)V

    .line 341
    .line 342
    .line 343
    new-instance v7, Ld01;

    .line 344
    .line 345
    invoke-direct {v7, v0, v2}, Ld01;-><init>(Lm00;Li00;)V

    .line 346
    .line 347
    .line 348
    sput-object v7, Le01;->q:Ld01;

    .line 349
    .line 350
    new-instance v0, Lc01;

    .line 351
    .line 352
    invoke-direct {v0, v3}, Lc01;-><init>(I)V

    .line 353
    .line 354
    .line 355
    new-instance v2, Lb01;

    .line 356
    .line 357
    const/4 v3, 0x4

    .line 358
    invoke-direct {v2, v3}, Lb01;-><init>(I)V

    .line 359
    .line 360
    .line 361
    new-instance v7, Ld01;

    .line 362
    .line 363
    invoke-direct {v7, v0, v2}, Ld01;-><init>(Lm00;Li00;)V

    .line 364
    .line 365
    .line 366
    sput-object v7, Le01;->r:Ld01;

    .line 367
    .line 368
    new-instance v0, Lc01;

    .line 369
    .line 370
    invoke-direct {v0, v12}, Lc01;-><init>(I)V

    .line 371
    .line 372
    .line 373
    new-instance v2, Lb01;

    .line 374
    .line 375
    const/4 v7, 0x5

    .line 376
    invoke-direct {v2, v7}, Lb01;-><init>(I)V

    .line 377
    .line 378
    .line 379
    new-instance v7, Ld01;

    .line 380
    .line 381
    invoke-direct {v7, v0, v2}, Ld01;-><init>(Lm00;Li00;)V

    .line 382
    .line 383
    .line 384
    sput-object v7, Le01;->s:Ld01;

    .line 385
    .line 386
    new-instance v0, Lc01;

    .line 387
    .line 388
    invoke-direct {v0, v3}, Lc01;-><init>(I)V

    .line 389
    .line 390
    .line 391
    new-instance v2, Lb01;

    .line 392
    .line 393
    invoke-direct {v2, v11}, Lb01;-><init>(I)V

    .line 394
    .line 395
    .line 396
    new-instance v3, Lal;

    .line 397
    .line 398
    invoke-direct {v3, v1, v0, v2}, Lal;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 399
    .line 400
    .line 401
    sput-object v3, Le01;->t:Lal;

    .line 402
    .line 403
    new-instance v0, Lc01;

    .line 404
    .line 405
    const/4 v2, 0x5

    .line 406
    invoke-direct {v0, v2}, Lc01;-><init>(I)V

    .line 407
    .line 408
    .line 409
    new-instance v2, Lb01;

    .line 410
    .line 411
    const/16 v3, 0x8

    .line 412
    .line 413
    invoke-direct {v2, v3}, Lb01;-><init>(I)V

    .line 414
    .line 415
    .line 416
    new-instance v3, Lal;

    .line 417
    .line 418
    invoke-direct {v3, v1, v0, v2}, Lal;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 419
    .line 420
    .line 421
    sput-object v3, Le01;->u:Lal;

    .line 422
    .line 423
    new-instance v0, Lc01;

    .line 424
    .line 425
    invoke-direct {v0, v5}, Lc01;-><init>(I)V

    .line 426
    .line 427
    .line 428
    new-instance v2, Lb01;

    .line 429
    .line 430
    const/16 v3, 0x9

    .line 431
    .line 432
    invoke-direct {v2, v3}, Lb01;-><init>(I)V

    .line 433
    .line 434
    .line 435
    new-instance v3, Ld01;

    .line 436
    .line 437
    invoke-direct {v3, v0, v2}, Ld01;-><init>(Lm00;Li00;)V

    .line 438
    .line 439
    .line 440
    sput-object v3, Le01;->v:Ld01;

    .line 441
    .line 442
    new-instance v0, Lc01;

    .line 443
    .line 444
    const/16 v2, 0x8

    .line 445
    .line 446
    invoke-direct {v0, v2}, Lc01;-><init>(I)V

    .line 447
    .line 448
    .line 449
    new-instance v2, Lb01;

    .line 450
    .line 451
    invoke-direct {v2, v4}, Lb01;-><init>(I)V

    .line 452
    .line 453
    .line 454
    new-instance v3, Ld01;

    .line 455
    .line 456
    invoke-direct {v3, v0, v2}, Ld01;-><init>(Lm00;Li00;)V

    .line 457
    .line 458
    .line 459
    sput-object v3, Le01;->w:Ld01;

    .line 460
    .line 461
    new-instance v0, Lc01;

    .line 462
    .line 463
    const/16 v2, 0x9

    .line 464
    .line 465
    invoke-direct {v0, v2}, Lc01;-><init>(I)V

    .line 466
    .line 467
    .line 468
    new-instance v2, Lb01;

    .line 469
    .line 470
    const/16 v3, 0xb

    .line 471
    .line 472
    invoke-direct {v2, v3}, Lb01;-><init>(I)V

    .line 473
    .line 474
    .line 475
    new-instance v3, Ld01;

    .line 476
    .line 477
    invoke-direct {v3, v0, v2}, Ld01;-><init>(Lm00;Li00;)V

    .line 478
    .line 479
    .line 480
    sput-object v3, Le01;->x:Ld01;

    .line 481
    .line 482
    new-instance v0, Lc01;

    .line 483
    .line 484
    const/16 v2, 0xb

    .line 485
    .line 486
    invoke-direct {v0, v2}, Lc01;-><init>(I)V

    .line 487
    .line 488
    .line 489
    new-instance v2, Lb01;

    .line 490
    .line 491
    const/16 v3, 0xc

    .line 492
    .line 493
    invoke-direct {v2, v3}, Lb01;-><init>(I)V

    .line 494
    .line 495
    .line 496
    new-instance v3, Lal;

    .line 497
    .line 498
    invoke-direct {v3, v1, v0, v2}, Lal;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 499
    .line 500
    .line 501
    sput-object v3, Le01;->y:Lal;

    .line 502
    .line 503
    new-instance v0, Lc01;

    .line 504
    .line 505
    const/16 v2, 0xc

    .line 506
    .line 507
    invoke-direct {v0, v2}, Lc01;-><init>(I)V

    .line 508
    .line 509
    .line 510
    new-instance v2, Lb01;

    .line 511
    .line 512
    const/16 v3, 0xd

    .line 513
    .line 514
    invoke-direct {v2, v3}, Lb01;-><init>(I)V

    .line 515
    .line 516
    .line 517
    new-instance v3, Lal;

    .line 518
    .line 519
    invoke-direct {v3, v1, v0, v2}, Lal;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 520
    .line 521
    .line 522
    sput-object v3, Le01;->z:Lal;

    .line 523
    .line 524
    new-instance v0, Lc01;

    .line 525
    .line 526
    const/16 v2, 0xd

    .line 527
    .line 528
    invoke-direct {v0, v2}, Lc01;-><init>(I)V

    .line 529
    .line 530
    .line 531
    new-instance v2, Lb01;

    .line 532
    .line 533
    const/16 v3, 0xf

    .line 534
    .line 535
    invoke-direct {v2, v3}, Lb01;-><init>(I)V

    .line 536
    .line 537
    .line 538
    new-instance v3, Lal;

    .line 539
    .line 540
    invoke-direct {v3, v1, v0, v2}, Lal;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 541
    .line 542
    .line 543
    sput-object v3, Le01;->A:Lal;

    .line 544
    .line 545
    new-instance v0, Lc01;

    .line 546
    .line 547
    invoke-direct {v0, v14}, Lc01;-><init>(I)V

    .line 548
    .line 549
    .line 550
    new-instance v1, Lb01;

    .line 551
    .line 552
    const/16 v2, 0x10

    .line 553
    .line 554
    invoke-direct {v1, v2}, Lb01;-><init>(I)V

    .line 555
    .line 556
    .line 557
    new-instance v2, Ld01;

    .line 558
    .line 559
    invoke-direct {v2, v0, v1}, Ld01;-><init>(Lm00;Li00;)V

    .line 560
    .line 561
    .line 562
    sput-object v2, Le01;->B:Ld01;

    .line 563
    .line 564
    new-instance v0, Lc01;

    .line 565
    .line 566
    const/16 v1, 0xf

    .line 567
    .line 568
    invoke-direct {v0, v1}, Lc01;-><init>(I)V

    .line 569
    .line 570
    .line 571
    new-instance v1, Lb01;

    .line 572
    .line 573
    invoke-direct {v1, v6}, Lb01;-><init>(I)V

    .line 574
    .line 575
    .line 576
    new-instance v2, Ld01;

    .line 577
    .line 578
    invoke-direct {v2, v0, v1}, Ld01;-><init>(Lm00;Li00;)V

    .line 579
    .line 580
    .line 581
    sput-object v2, Le01;->C:Ld01;

    .line 582
    .line 583
    new-instance v0, Lc01;

    .line 584
    .line 585
    const/16 v1, 0x10

    .line 586
    .line 587
    invoke-direct {v0, v1}, Lc01;-><init>(I)V

    .line 588
    .line 589
    .line 590
    new-instance v1, Lb01;

    .line 591
    .line 592
    invoke-direct {v1, v8}, Lb01;-><init>(I)V

    .line 593
    .line 594
    .line 595
    new-instance v2, Ld01;

    .line 596
    .line 597
    invoke-direct {v2, v0, v1}, Ld01;-><init>(Lm00;Li00;)V

    .line 598
    .line 599
    .line 600
    sput-object v2, Le01;->D:Ld01;

    .line 601
    .line 602
    return-void
.end method

.method public static final a(Ljava/lang/Object;La01;Liz0;)Ljava/lang/Object;
    .registers 3

    .line 1
    if-eqz p0, :cond_a

    .line 2
    .line 3
    invoke-interface {p1, p2, p0}, La01;->j(Liz0;Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    if-nez p0, :cond_9

    .line 8
    .line 9
    goto :goto_a

    .line 10
    :cond_9
    return-object p0

    .line 11
    :cond_a
    :goto_a
    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 12
    .line 13
    return-object p0
.end method
