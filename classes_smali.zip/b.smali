.class public final synthetic Lb;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lxz;


# instance fields
.field public final synthetic e:I

.field public final synthetic f:Ldg;


# direct methods
.method public synthetic constructor <init>(Ldg;I)V
    .registers 3

    .line 1
    iput p2, p0, Lb;->e:I

    .line 2
    .line 3
    iput-object p1, p0, Lb;->f:Ldg;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .registers 4

    .line 1
    iget v0, p0, Lb;->e:I

    .line 2
    .line 3
    iget-object p0, p0, Lb;->f:Ldg;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_4e

    .line 6
    .line 7
    .line 8
    iget-object p0, p0, Ldg;->z:Lxz;

    .line 9
    .line 10
    invoke-interface {p0}, Lxz;->a()Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    sget-object p0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 14
    .line 15
    return-object p0

    .line 16
    :pswitch_f  #0x0
    sget-object v0, Lp40;->a:Lgk;

    .line 17
    .line 18
    invoke-static {p0, v0}, Lj70;->z(Lak;Llv0;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    check-cast v0, Lt40;

    .line 23
    .line 24
    if-eqz v0, :cond_1a

    .line 25
    .line 26
    goto :goto_2b

    .line 27
    :cond_1a
    new-instance v1, Ljava/lang/StringBuilder;

    .line 28
    .line 29
    const-string v2, "clickable only supports IndicationNodeFactory instances provided to LocalIndication, but Indication was provided instead. Either migrate the Indication implementation to implement IndicationNodeFactory, or use the other clickable overload that takes an Indication parameter, and explicitly pass LocalIndication.current there. The Indication instance provided here was: "

    .line 30
    .line 31
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 32
    .line 33
    .line 34
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 35
    .line 36
    .line 37
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 38
    .line 39
    .line 40
    move-result-object v1

    .line 41
    invoke-static {v1}, Ls50;->a(Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    :goto_2b
    iget-object v1, p0, Ldg;->B:Lt40;

    .line 45
    .line 46
    iput-object v0, p0, Ldg;->B:Lt40;

    .line 47
    .line 48
    if-eqz v1, :cond_4a

    .line 49
    .line 50
    invoke-static {v0, v1}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    if-nez v0, :cond_4a

    .line 55
    .line 56
    iget-object v0, p0, Ldg;->D:Lcp;

    .line 57
    .line 58
    if-nez v0, :cond_3f

    .line 59
    .line 60
    iget-boolean v1, p0, Ldg;->K:Z

    .line 61
    .line 62
    if-nez v1, :cond_4a

    .line 63
    .line 64
    :cond_3f
    if-eqz v0, :cond_44

    .line 65
    .line 66
    invoke-virtual {p0, v0}, Ldp;->s0(Lcp;)V

    .line 67
    .line 68
    .line 69
    :cond_44
    const/4 v0, 0x0

    .line 70
    iput-object v0, p0, Ldg;->D:Lcp;

    .line 71
    .line 72
    invoke-virtual {p0}, Ldg;->y0()V

    .line 73
    .line 74
    .line 75
    :cond_4a
    sget-object p0, Lwe1;->a:Lwe1;

    .line 76
    .line 77
    return-object p0

    .line 78
    nop

    .line 79
    :pswitch_data_4e
    .packed-switch 0x0
        :pswitch_f  #00000000
    .end packed-switch
.end method
