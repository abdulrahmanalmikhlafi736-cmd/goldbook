.class public abstract Laz;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# static fields
.field public static final a:Lal;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Lal;

    .line 2
    .line 3
    const/16 v1, 0x17

    .line 4
    .line 5
    invoke-direct {v0, v1}, Lal;-><init>(I)V

    .line 6
    .line 7
    .line 8
    sput-object v0, Laz;->a:Lal;

    .line 9
    .line 10
    new-instance v0, Lnq0;

    .line 11
    .line 12
    invoke-direct {v0}, Lnq0;-><init>()V

    .line 13
    .line 14
    .line 15
    return-void
.end method
