.class public abstract Lcj1;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lbj1;


# static fields
.field public static final a:Llq0;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Lkt0;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Lkt0;-><init>(I)V

    .line 5
    .line 6
    .line 7
    invoke-static {v0}, Lmc0;->t(Ljava/lang/Object;)Llq0;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    sput-object v0, Lcj1;->a:Llq0;

    .line 12
    .line 13
    return-void
.end method
