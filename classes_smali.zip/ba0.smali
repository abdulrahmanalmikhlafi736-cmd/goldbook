.class public final Lba0;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lwi;
.implements Lmp0;
.implements Lij;


# static fields
.field public static final V:Lly0;

.field public static final W:Lw90;

.field public static final X:Lv6;


# instance fields
.field public A:Lmh0;

.field public B:Lal;

.field public C:Ljp;

.field public D:Lo90;

.field public E:Lyg1;

.field public F:Lck;

.field public G:Lz90;

.field public H:Lz90;

.field public I:Z

.field public final J:Lem0;

.field public final K:Lfa0;

.field public L:Lpa0;

.field public M:Lgm0;

.field public N:Z

.field public O:Lmi0;

.field public P:Lmi0;

.field public Q:Lk7;

.field public R:Ll7;

.field public S:Z

.field public T:I

.field public U:Z

.field public final e:Z

.field public f:I

.field public g:Z

.field public h:J

.field public i:Z

.field public j:Z

.field public k:Z

.field public l:Lba0;

.field public m:I

.field public final n:Lal;

.field public o:Lqk0;

.field public p:Z

.field public q:Lba0;

.field public r:Llp0;

.field public s:Lah1;

.field public t:I

.field public u:Z

.field public v:Z

.field public w:Ld21;

.field public x:Z

.field public final y:Lqk0;

.field public z:Z


# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 1
    new-instance v0, Lly0;

    .line 2
    .line 3
    const-string v1, "Undefined intrinsics block and it is required"

    .line 4
    .line 5
    const/4 v2, 0x1

    .line 6
    invoke-direct {v0, v1, v2}, Lly0;-><init>(Ljava/lang/String;I)V

    .line 7
    .line 8
    .line 9
    sput-object v0, Lba0;->V:Lly0;

    .line 10
    .line 11
    new-instance v0, Lw90;

    .line 12
    .line 13
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 14
    .line 15
    .line 16
    sput-object v0, Lba0;->W:Lw90;

    .line 17
    .line 18
    new-instance v0, Lv6;

    .line 19
    .line 20
    const/4 v1, 0x4

    .line 21
    invoke-direct {v0, v1}, Lv6;-><init>(I)V

    .line 22
    .line 23
    .line 24
    sput-object v0, Lba0;->X:Lv6;

    .line 25
    .line 26
    return-void
.end method

.method public constructor <init>(I)V
    .registers 4

    const/4 v0, 0x1

    and-int/2addr p1, v0

    if-eqz p1, :cond_6

    const/4 p1, 0x0

    goto :goto_7

    :cond_6
    move p1, v0

    .line 107
    :goto_7
    sget-object v1, Lf21;->a:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v1, v0}, Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I

    move-result v0

    .line 108
    invoke-direct {p0, v0, p1}, Lba0;-><init>(IZ)V

    return-void
.end method

.method public constructor <init>(IZ)V
    .registers 7

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-boolean p2, p0, Lba0;->e:Z

    .line 5
    .line 6
    iput p1, p0, Lba0;->f:I

    .line 7
    .line 8
    const-wide p1, 0x7fffffff7fffffffL

    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    iput-wide p1, p0, Lba0;->h:J

    .line 14
    .line 15
    const/4 p1, 0x1

    .line 16
    iput-boolean p1, p0, Lba0;->i:Z

    .line 17
    .line 18
    iput-boolean p1, p0, Lba0;->j:Z

    .line 19
    .line 20
    new-instance p2, Lal;

    .line 21
    .line 22
    new-instance v0, Lqk0;

    .line 23
    .line 24
    const/16 v1, 0x10

    .line 25
    .line 26
    new-array v2, v1, [Lba0;

    .line 27
    .line 28
    invoke-direct {v0, v2}, Lqk0;-><init>([Ljava/lang/Object;)V

    .line 29
    .line 30
    .line 31
    new-instance v2, Lf8;

    .line 32
    .line 33
    const/4 v3, 0x5

    .line 34
    invoke-direct {v2, v3, p0}, Lf8;-><init>(ILjava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    const/16 v3, 0xc

    .line 38
    .line 39
    invoke-direct {p2, v3, v0, v2}, Lal;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 40
    .line 41
    .line 42
    iput-object p2, p0, Lba0;->n:Lal;

    .line 43
    .line 44
    new-instance p2, Lqk0;

    .line 45
    .line 46
    new-array v0, v1, [Lba0;

    .line 47
    .line 48
    invoke-direct {p2, v0}, Lqk0;-><init>([Ljava/lang/Object;)V

    .line 49
    .line 50
    .line 51
    iput-object p2, p0, Lba0;->y:Lqk0;

    .line 52
    .line 53
    iput-boolean p1, p0, Lba0;->z:Z

    .line 54
    .line 55
    sget-object p2, Lba0;->V:Lly0;

    .line 56
    .line 57
    iput-object p2, p0, Lba0;->A:Lmh0;

    .line 58
    .line 59
    sget-object p2, Lea0;->a:Lmp;

    .line 60
    .line 61
    iput-object p2, p0, Lba0;->C:Ljp;

    .line 62
    .line 63
    sget-object p2, Lo90;->e:Lo90;

    .line 64
    .line 65
    iput-object p2, p0, Lba0;->D:Lo90;

    .line 66
    .line 67
    sget-object p2, Lba0;->W:Lw90;

    .line 68
    .line 69
    iput-object p2, p0, Lba0;->E:Lyg1;

    .line 70
    .line 71
    sget-object p2, Lck;->d:Lbk;

    .line 72
    .line 73
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 74
    .line 75
    .line 76
    sget-object p2, Lbk;->b:Lqr0;

    .line 77
    .line 78
    iput-object p2, p0, Lba0;->F:Lck;

    .line 79
    .line 80
    sget-object p2, Lz90;->g:Lz90;

    .line 81
    .line 82
    iput-object p2, p0, Lba0;->G:Lz90;

    .line 83
    .line 84
    iput-object p2, p0, Lba0;->H:Lz90;

    .line 85
    .line 86
    new-instance p2, Lem0;

    .line 87
    .line 88
    invoke-direct {p2, p0}, Lem0;-><init>(Lba0;)V

    .line 89
    .line 90
    .line 91
    iput-object p2, p0, Lba0;->J:Lem0;

    .line 92
    .line 93
    new-instance p2, Lfa0;

    .line 94
    .line 95
    invoke-direct {p2, p0}, Lfa0;-><init>(Lba0;)V

    .line 96
    .line 97
    .line 98
    iput-object p2, p0, Lba0;->K:Lfa0;

    .line 99
    .line 100
    iput-boolean p1, p0, Lba0;->N:Z

    .line 101
    .line 102
    sget-object p1, Lji0;->a:Lji0;

    .line 103
    .line 104
    iput-object p1, p0, Lba0;->O:Lmi0;

    .line 105
    .line 106
    return-void
.end method

.method public static T(Lba0;ZI)V
    .registers 7

    .line 1
    and-int/lit8 v0, p2, 0x1

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_6

    .line 5
    .line 6
    move p1, v1

    .line 7
    :cond_6
    and-int/lit8 v0, p2, 0x2

    .line 8
    .line 9
    const/4 v2, 0x1

    .line 10
    if-eqz v0, :cond_d

    .line 11
    .line 12
    move v0, v2

    .line 13
    goto :goto_e

    .line 14
    :cond_d
    move v0, v1

    .line 15
    :goto_e
    and-int/lit8 p2, p2, 0x4

    .line 16
    .line 17
    if-eqz p2, :cond_13

    .line 18
    .line 19
    move v1, v2

    .line 20
    :cond_13
    iget-object p2, p0, Lba0;->l:Lba0;

    .line 21
    .line 22
    if-eqz p2, :cond_18

    .line 23
    .line 24
    goto :goto_1d

    .line 25
    :cond_18
    const-string p2, "Lookahead measure cannot be requested on a node that is not a part of the LookaheadScope"

    .line 26
    .line 27
    invoke-static {p2}, Lp50;->b(Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    :goto_1d
    iget-object p2, p0, Lba0;->r:Llp0;

    .line 31
    .line 32
    if-nez p2, :cond_22

    .line 33
    .line 34
    goto :goto_7d

    .line 35
    :cond_22
    iget-boolean v3, p0, Lba0;->u:Z

    .line 36
    .line 37
    if-nez v3, :cond_7d

    .line 38
    .line 39
    iget-boolean v3, p0, Lba0;->e:Z

    .line 40
    .line 41
    if-nez v3, :cond_7d

    .line 42
    .line 43
    check-cast p2, Ln4;

    .line 44
    .line 45
    invoke-virtual {p2, p0, v2, p1, v0}, Ln4;->C(Lba0;ZZZ)V

    .line 46
    .line 47
    .line 48
    if-eqz v1, :cond_7d

    .line 49
    .line 50
    iget-object p0, p0, Lba0;->K:Lfa0;

    .line 51
    .line 52
    iget-object p0, p0, Lfa0;->q:Lhg0;

    .line 53
    .line 54
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 55
    .line 56
    .line 57
    iget-object p0, p0, Lhg0;->j:Lfa0;

    .line 58
    .line 59
    iget-object p2, p0, Lfa0;->a:Lba0;

    .line 60
    .line 61
    invoke-virtual {p2}, Lba0;->v()Lba0;

    .line 62
    .line 63
    .line 64
    move-result-object p2

    .line 65
    iget-object p0, p0, Lfa0;->a:Lba0;

    .line 66
    .line 67
    iget-object p0, p0, Lba0;->G:Lz90;

    .line 68
    .line 69
    if-eqz p2, :cond_7d

    .line 70
    .line 71
    sget-object v0, Lz90;->g:Lz90;

    .line 72
    .line 73
    if-eq p0, v0, :cond_7d

    .line 74
    .line 75
    :goto_4a
    iget-object v0, p2, Lba0;->G:Lz90;

    .line 76
    .line 77
    if-ne v0, p0, :cond_57

    .line 78
    .line 79
    invoke-virtual {p2}, Lba0;->v()Lba0;

    .line 80
    .line 81
    .line 82
    move-result-object v0

    .line 83
    if-nez v0, :cond_55

    .line 84
    .line 85
    goto :goto_57

    .line 86
    :cond_55
    move-object p2, v0

    .line 87
    goto :goto_4a

    .line 88
    :cond_57
    :goto_57
    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    .line 89
    .line 90
    .line 91
    move-result p0

    .line 92
    if-eqz p0, :cond_71

    .line 93
    .line 94
    if-ne p0, v2, :cond_6b

    .line 95
    .line 96
    iget-object p0, p2, Lba0;->l:Lba0;

    .line 97
    .line 98
    if-eqz p0, :cond_67

    .line 99
    .line 100
    invoke-virtual {p2, p1}, Lba0;->S(Z)V

    .line 101
    .line 102
    .line 103
    return-void

    .line 104
    :cond_67
    invoke-virtual {p2, p1}, Lba0;->U(Z)V

    .line 105
    .line 106
    .line 107
    return-void

    .line 108
    :cond_6b
    const-string p0, "Intrinsics isn\'t used by the parent"

    .line 109
    .line 110
    invoke-static {p0}, Lod;->p(Ljava/lang/String;)V

    .line 111
    .line 112
    .line 113
    return-void

    .line 114
    :cond_71
    iget-object p0, p2, Lba0;->l:Lba0;

    .line 115
    .line 116
    const/4 v0, 0x6

    .line 117
    if-eqz p0, :cond_7a

    .line 118
    .line 119
    invoke-static {p2, p1, v0}, Lba0;->T(Lba0;ZI)V

    .line 120
    .line 121
    .line 122
    return-void

    .line 123
    :cond_7a
    invoke-static {p2, p1, v0}, Lba0;->V(Lba0;ZI)V

    .line 124
    .line 125
    .line 126
    :cond_7d
    :goto_7d
    return-void
.end method

.method public static V(Lba0;ZI)V
    .registers 7

    .line 1
    and-int/lit8 v0, p2, 0x1

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_6

    .line 5
    .line 6
    move p1, v1

    .line 7
    :cond_6
    and-int/lit8 v0, p2, 0x2

    .line 8
    .line 9
    const/4 v2, 0x1

    .line 10
    if-eqz v0, :cond_d

    .line 11
    .line 12
    move v0, v2

    .line 13
    goto :goto_e

    .line 14
    :cond_d
    move v0, v1

    .line 15
    :goto_e
    and-int/lit8 p2, p2, 0x4

    .line 16
    .line 17
    if-eqz p2, :cond_14

    .line 18
    .line 19
    move p2, v2

    .line 20
    goto :goto_15

    .line 21
    :cond_14
    move p2, v1

    .line 22
    :goto_15
    iget-boolean v3, p0, Lba0;->u:Z

    .line 23
    .line 24
    if-nez v3, :cond_62

    .line 25
    .line 26
    iget-boolean v3, p0, Lba0;->e:Z

    .line 27
    .line 28
    if-nez v3, :cond_62

    .line 29
    .line 30
    iget-object v3, p0, Lba0;->r:Llp0;

    .line 31
    .line 32
    if-nez v3, :cond_22

    .line 33
    .line 34
    goto :goto_62

    .line 35
    :cond_22
    check-cast v3, Ln4;

    .line 36
    .line 37
    invoke-virtual {v3, p0, v1, p1, v0}, Ln4;->C(Lba0;ZZZ)V

    .line 38
    .line 39
    .line 40
    if-eqz p2, :cond_62

    .line 41
    .line 42
    iget-object p0, p0, Lba0;->K:Lfa0;

    .line 43
    .line 44
    iget-object p0, p0, Lfa0;->p:Llh0;

    .line 45
    .line 46
    iget-object p0, p0, Llh0;->j:Lfa0;

    .line 47
    .line 48
    iget-object p2, p0, Lfa0;->a:Lba0;

    .line 49
    .line 50
    invoke-virtual {p2}, Lba0;->v()Lba0;

    .line 51
    .line 52
    .line 53
    move-result-object p2

    .line 54
    iget-object p0, p0, Lfa0;->a:Lba0;

    .line 55
    .line 56
    iget-object p0, p0, Lba0;->G:Lz90;

    .line 57
    .line 58
    if-eqz p2, :cond_62

    .line 59
    .line 60
    sget-object v0, Lz90;->g:Lz90;

    .line 61
    .line 62
    if-eq p0, v0, :cond_62

    .line 63
    .line 64
    :goto_3f
    iget-object v0, p2, Lba0;->G:Lz90;

    .line 65
    .line 66
    if-ne v0, p0, :cond_4c

    .line 67
    .line 68
    invoke-virtual {p2}, Lba0;->v()Lba0;

    .line 69
    .line 70
    .line 71
    move-result-object v0

    .line 72
    if-nez v0, :cond_4a

    .line 73
    .line 74
    goto :goto_4c

    .line 75
    :cond_4a
    move-object p2, v0

    .line 76
    goto :goto_3f

    .line 77
    :cond_4c
    :goto_4c
    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    .line 78
    .line 79
    .line 80
    move-result p0

    .line 81
    if-eqz p0, :cond_5e

    .line 82
    .line 83
    if-ne p0, v2, :cond_58

    .line 84
    .line 85
    invoke-virtual {p2, p1}, Lba0;->U(Z)V

    .line 86
    .line 87
    .line 88
    return-void

    .line 89
    :cond_58
    const-string p0, "Intrinsics isn\'t used by the parent"

    .line 90
    .line 91
    invoke-static {p0}, Lod;->p(Ljava/lang/String;)V

    .line 92
    .line 93
    .line 94
    return-void

    .line 95
    :cond_5e
    const/4 p0, 0x6

    .line 96
    invoke-static {p2, p1, p0}, Lba0;->V(Lba0;ZI)V

    .line 97
    .line 98
    .line 99
    :cond_62
    :goto_62
    return-void
.end method

.method public static W(Lba0;)V
    .registers 5

    .line 1
    iget-object v0, p0, Lba0;->K:Lfa0;

    .line 2
    .line 3
    iget-object v0, v0, Lfa0;->d:Lx90;

    .line 4
    .line 5
    sget-object v1, Laa0;->a:[I

    .line 6
    .line 7
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    aget v0, v1, v0

    .line 12
    .line 13
    iget-object v1, p0, Lba0;->K:Lfa0;

    .line 14
    .line 15
    const/4 v2, 0x1

    .line 16
    if-ne v0, v2, :cond_35

    .line 17
    .line 18
    iget-boolean v0, v1, Lfa0;->e:Z

    .line 19
    .line 20
    const/4 v3, 0x6

    .line 21
    if-eqz v0, :cond_1a

    .line 22
    .line 23
    invoke-static {p0, v2, v3}, Lba0;->T(Lba0;ZI)V

    .line 24
    .line 25
    .line 26
    return-void

    .line 27
    :cond_1a
    iget-boolean v0, v1, Lfa0;->f:Z

    .line 28
    .line 29
    if-eqz v0, :cond_21

    .line 30
    .line 31
    invoke-virtual {p0, v2}, Lba0;->S(Z)V

    .line 32
    .line 33
    .line 34
    :cond_21
    invoke-virtual {p0}, Lba0;->q()Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-eqz v0, :cond_2b

    .line 39
    .line 40
    invoke-static {p0, v2, v3}, Lba0;->V(Lba0;ZI)V

    .line 41
    .line 42
    .line 43
    return-void

    .line 44
    :cond_2b
    invoke-virtual {p0}, Lba0;->p()Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-eqz v0, :cond_34

    .line 49
    .line 50
    invoke-virtual {p0, v2}, Lba0;->U(Z)V

    .line 51
    .line 52
    .line 53
    :cond_34
    return-void

    .line 54
    :cond_35
    const-string p0, "Unexpected state "

    .line 55
    .line 56
    iget-object v0, v1, Lfa0;->d:Lx90;

    .line 57
    .line 58
    invoke-static {v0, p0}, Lod;->o(Ljava/lang/Object;Ljava/lang/String;)V

    .line 59
    .line 60
    .line 61
    return-void
.end method

.method private final j(Lba0;)Ljava/lang/String;
    .registers 4

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-string v1, "Cannot insert "

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 9
    .line 10
    .line 11
    const-string v1, " because it already has a parent or an owner. This tree: "

    .line 12
    .line 13
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 14
    .line 15
    .line 16
    const/4 v1, 0x0

    .line 17
    invoke-virtual {p0, v1}, Lba0;->g(I)Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object p0

    .line 21
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 22
    .line 23
    .line 24
    const-string p0, " Other tree: "

    .line 25
    .line 26
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 27
    .line 28
    .line 29
    iget-object p0, p1, Lba0;->q:Lba0;

    .line 30
    .line 31
    if-eqz p0, :cond_25

    .line 32
    .line 33
    invoke-virtual {p0, v1}, Lba0;->g(I)Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object p0

    .line 37
    goto :goto_26

    .line 38
    :cond_25
    const/4 p0, 0x0

    .line 39
    :goto_26
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 40
    .line 41
    .line 42
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 43
    .line 44
    .line 45
    move-result-object p0

    .line 46
    return-object p0
.end method


# virtual methods
.method public final A(JLe30;IZ)V
    .registers 15

    .line 1
    iget-object p0, p0, Lba0;->J:Lem0;

    .line 2
    .line 3
    iget-object v0, p0, Lem0;->d:Lgm0;

    .line 4
    .line 5
    sget-object v1, Lgm0;->Q:Lsx0;

    .line 6
    .line 7
    invoke-virtual {v0, p1, p2}, Lgm0;->v0(J)J

    .line 8
    .line 9
    .line 10
    move-result-wide v4

    .line 11
    iget-object v2, p0, Lem0;->d:Lgm0;

    .line 12
    .line 13
    sget-object v3, Lgm0;->S:Lvj;

    .line 14
    .line 15
    move-object v6, p3

    .line 16
    move v7, p4

    .line 17
    move v8, p5

    .line 18
    invoke-virtual/range {v2 .. v8}, Lgm0;->D0(Lvj;JLe30;IZ)V

    .line 19
    .line 20
    .line 21
    return-void
.end method

.method public final B(ILba0;)V
    .registers 5

    .line 1
    iget-object v0, p2, Lba0;->q:Lba0;

    .line 2
    .line 3
    if-eqz v0, :cond_10

    .line 4
    .line 5
    iget-object v0, p2, Lba0;->r:Llp0;

    .line 6
    .line 7
    if-nez v0, :cond_9

    .line 8
    .line 9
    goto :goto_10

    .line 10
    :cond_9
    invoke-direct {p0, p2}, Lba0;->j(Lba0;)Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    invoke-static {v0}, Lp50;->b(Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    :cond_10
    :goto_10
    iput-object p0, p2, Lba0;->q:Lba0;

    .line 18
    .line 19
    iget-object v0, p0, Lba0;->n:Lal;

    .line 20
    .line 21
    iget-object v1, v0, Lal;->f:Ljava/lang/Object;

    .line 22
    .line 23
    check-cast v1, Lqk0;

    .line 24
    .line 25
    invoke-virtual {v1, p1, p2}, Lqk0;->a(ILjava/lang/Object;)V

    .line 26
    .line 27
    .line 28
    iget-object p1, v0, Lal;->g:Ljava/lang/Object;

    .line 29
    .line 30
    check-cast p1, Lf8;

    .line 31
    .line 32
    invoke-virtual {p1}, Lf8;->a()Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    invoke-virtual {p0}, Lba0;->O()V

    .line 36
    .line 37
    .line 38
    iget-boolean p1, p2, Lba0;->e:Z

    .line 39
    .line 40
    if-eqz p1, :cond_2f

    .line 41
    .line 42
    iget p1, p0, Lba0;->m:I

    .line 43
    .line 44
    add-int/lit8 p1, p1, 0x1

    .line 45
    .line 46
    iput p1, p0, Lba0;->m:I

    .line 47
    .line 48
    :cond_2f
    invoke-virtual {p0}, Lba0;->G()V

    .line 49
    .line 50
    .line 51
    iget-object p1, p0, Lba0;->r:Llp0;

    .line 52
    .line 53
    if-eqz p1, :cond_39

    .line 54
    .line 55
    invoke-virtual {p2, p1}, Lba0;->d(Llp0;)V

    .line 56
    .line 57
    .line 58
    :cond_39
    iget-object p1, p2, Lba0;->K:Lfa0;

    .line 59
    .line 60
    iget p1, p1, Lfa0;->l:I

    .line 61
    .line 62
    if-lez p1, :cond_48

    .line 63
    .line 64
    iget-object p1, p0, Lba0;->K:Lfa0;

    .line 65
    .line 66
    iget v0, p1, Lfa0;->l:I

    .line 67
    .line 68
    add-int/lit8 v0, v0, 0x1

    .line 69
    .line 70
    invoke-virtual {p1, v0}, Lfa0;->d(I)V

    .line 71
    .line 72
    .line 73
    :cond_48
    iget p1, p2, Lba0;->T:I

    .line 74
    .line 75
    if-lez p1, :cond_53

    .line 76
    .line 77
    iget p1, p0, Lba0;->T:I

    .line 78
    .line 79
    add-int/lit8 p1, p1, 0x1

    .line 80
    .line 81
    invoke-virtual {p0, p1}, Lba0;->a0(I)V

    .line 82
    .line 83
    .line 84
    :cond_53
    return-void
.end method

.method public final C()V
    .registers 5

    .line 1
    iget-boolean v0, p0, Lba0;->N:Z

    .line 2
    .line 3
    if-eqz v0, :cond_2a

    .line 4
    .line 5
    iget-object v0, p0, Lba0;->J:Lem0;

    .line 6
    .line 7
    iget-object v1, v0, Lem0;->c:Lv50;

    .line 8
    .line 9
    iget-object v0, v0, Lem0;->d:Lgm0;

    .line 10
    .line 11
    iget-object v0, v0, Lgm0;->u:Lgm0;

    .line 12
    .line 13
    const/4 v2, 0x0

    .line 14
    iput-object v2, p0, Lba0;->M:Lgm0;

    .line 15
    .line 16
    :goto_f
    invoke-static {v1, v0}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 17
    .line 18
    .line 19
    move-result v3

    .line 20
    if-nez v3, :cond_27

    .line 21
    .line 22
    if-eqz v1, :cond_1a

    .line 23
    .line 24
    iget-object v3, v1, Lgm0;->P:Lkp0;

    .line 25
    .line 26
    goto :goto_1b

    .line 27
    :cond_1a
    move-object v3, v2

    .line 28
    :goto_1b
    if-eqz v3, :cond_20

    .line 29
    .line 30
    iput-object v1, p0, Lba0;->M:Lgm0;

    .line 31
    .line 32
    goto :goto_27

    .line 33
    :cond_20
    if-eqz v1, :cond_25

    .line 34
    .line 35
    iget-object v1, v1, Lgm0;->u:Lgm0;

    .line 36
    .line 37
    goto :goto_f

    .line 38
    :cond_25
    move-object v1, v2

    .line 39
    goto :goto_f

    .line 40
    :cond_27
    :goto_27
    const/4 v0, 0x0

    .line 41
    iput-boolean v0, p0, Lba0;->N:Z

    .line 42
    .line 43
    :cond_2a
    iget-object v0, p0, Lba0;->M:Lgm0;

    .line 44
    .line 45
    if-eqz v0, :cond_3a

    .line 46
    .line 47
    iget-object v1, v0, Lgm0;->P:Lkp0;

    .line 48
    .line 49
    if-eqz v1, :cond_33

    .line 50
    .line 51
    goto :goto_3a

    .line 52
    :cond_33
    const-string p0, "layer was not set"

    .line 53
    .line 54
    invoke-static {p0}, Lfu0;->C(Ljava/lang/String;)Lyh;

    .line 55
    .line 56
    .line 57
    move-result-object p0

    .line 58
    throw p0

    .line 59
    :cond_3a
    :goto_3a
    if-eqz v0, :cond_40

    .line 60
    .line 61
    invoke-virtual {v0}, Lgm0;->F0()V

    .line 62
    .line 63
    .line 64
    return-void

    .line 65
    :cond_40
    invoke-virtual {p0}, Lba0;->v()Lba0;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    if-eqz v0, :cond_4a

    .line 70
    .line 71
    invoke-virtual {v0}, Lba0;->C()V

    .line 72
    .line 73
    .line 74
    return-void

    .line 75
    :cond_4a
    iget-object p0, p0, Lba0;->r:Llp0;

    .line 76
    .line 77
    if-eqz p0, :cond_53

    .line 78
    .line 79
    check-cast p0, Ln4;

    .line 80
    .line 81
    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    .line 82
    .line 83
    .line 84
    :cond_53
    return-void
.end method

.method public final D()V
    .registers 4

    .line 1
    iget-object p0, p0, Lba0;->J:Lem0;

    .line 2
    .line 3
    iget-object v0, p0, Lem0;->d:Lgm0;

    .line 4
    .line 5
    iget-object v1, p0, Lem0;->c:Lv50;

    .line 6
    .line 7
    :goto_6
    if-eq v0, v1, :cond_19

    .line 8
    .line 9
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    check-cast v0, Lv90;

    .line 13
    .line 14
    iget-object v2, v0, Lgm0;->P:Lkp0;

    .line 15
    .line 16
    if-eqz v2, :cond_16

    .line 17
    .line 18
    check-cast v2, Ll20;

    .line 19
    .line 20
    invoke-virtual {v2}, Ll20;->c()V

    .line 21
    .line 22
    .line 23
    :cond_16
    iget-object v0, v0, Lgm0;->t:Lgm0;

    .line 24
    .line 25
    goto :goto_6

    .line 26
    :cond_19
    iget-object p0, p0, Lem0;->c:Lv50;

    .line 27
    .line 28
    iget-object p0, p0, Lgm0;->P:Lkp0;

    .line 29
    .line 30
    if-eqz p0, :cond_24

    .line 31
    .line 32
    check-cast p0, Ll20;

    .line 33
    .line 34
    invoke-virtual {p0}, Ll20;->c()V

    .line 35
    .line 36
    .line 37
    :cond_24
    return-void
.end method

.method public final E()V
    .registers 4

    .line 1
    iget-boolean v0, p0, Lba0;->e:Z

    .line 2
    .line 3
    if-eqz v0, :cond_e

    .line 4
    .line 5
    invoke-virtual {p0}, Lba0;->v()Lba0;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    if-eqz p0, :cond_d

    .line 10
    .line 11
    invoke-virtual {p0}, Lba0;->E()V

    .line 12
    .line 13
    .line 14
    :cond_d
    return-void

    .line 15
    :cond_e
    iget-object v0, p0, Lba0;->l:Lba0;

    .line 16
    .line 17
    const/4 v1, 0x7

    .line 18
    const/4 v2, 0x0

    .line 19
    if-eqz v0, :cond_18

    .line 20
    .line 21
    invoke-static {p0, v2, v1}, Lba0;->T(Lba0;ZI)V

    .line 22
    .line 23
    .line 24
    return-void

    .line 25
    :cond_18
    invoke-static {p0, v2, v1}, Lba0;->V(Lba0;ZI)V

    .line 26
    .line 27
    .line 28
    return-void
.end method

.method public final F()V
    .registers 6

    .line 1
    iget-boolean v0, p0, Lba0;->x:Z

    .line 2
    .line 3
    if-eqz v0, :cond_5

    .line 4
    .line 5
    return-void

    .line 6
    :cond_5
    iget-object v0, p0, Lba0;->J:Lem0;

    .line 7
    .line 8
    iget-object v0, v0, Lem0;->b:Ldm0;

    .line 9
    .line 10
    iget-object v0, v0, Lli0;->j:Lli0;

    .line 11
    .line 12
    const/4 v1, 0x1

    .line 13
    if-eqz v0, :cond_f

    .line 14
    .line 15
    goto :goto_13

    .line 16
    :cond_f
    iget-object v0, p0, Lba0;->P:Lmi0;

    .line 17
    .line 18
    if-eqz v0, :cond_16

    .line 19
    .line 20
    :goto_13
    iput-boolean v1, p0, Lba0;->v:Z

    .line 21
    .line 22
    return-void

    .line 23
    :cond_16
    iget-object v0, p0, Lba0;->w:Ld21;

    .line 24
    .line 25
    iput-boolean v1, p0, Lba0;->x:Z

    .line 26
    .line 27
    new-instance v1, Lnw0;

    .line 28
    .line 29
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 30
    .line 31
    .line 32
    new-instance v2, Ld21;

    .line 33
    .line 34
    invoke-direct {v2}, Ld21;-><init>()V

    .line 35
    .line 36
    .line 37
    iput-object v2, v1, Lnw0;->e:Ljava/lang/Object;

    .line 38
    .line 39
    invoke-static {p0}, Lea0;->a(Lba0;)Llp0;

    .line 40
    .line 41
    .line 42
    move-result-object v2

    .line 43
    check-cast v2, Ln4;

    .line 44
    .line 45
    invoke-virtual {v2}, Ln4;->getSnapshotObserver()Lop0;

    .line 46
    .line 47
    .line 48
    move-result-object v2

    .line 49
    new-instance v3, Lg4;

    .line 50
    .line 51
    const/4 v4, 0x7

    .line 52
    invoke-direct {v3, v4, p0, v1}, Lg4;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 53
    .line 54
    .line 55
    iget-object v4, v2, Lop0;->d:Lnp0;

    .line 56
    .line 57
    iget-object v2, v2, Lop0;->a:Lb71;

    .line 58
    .line 59
    invoke-virtual {v2, p0, v4, v3}, Lb71;->b(Ljava/lang/Object;Li00;Lxz;)V

    .line 60
    .line 61
    .line 62
    const/4 v2, 0x0

    .line 63
    iput-boolean v2, p0, Lba0;->x:Z

    .line 64
    .line 65
    iget-object v1, v1, Lnw0;->e:Ljava/lang/Object;

    .line 66
    .line 67
    check-cast v1, Ld21;

    .line 68
    .line 69
    iput-object v1, p0, Lba0;->w:Ld21;

    .line 70
    .line 71
    iput-boolean v2, p0, Lba0;->v:Z

    .line 72
    .line 73
    invoke-static {p0}, Lea0;->a(Lba0;)Llp0;

    .line 74
    .line 75
    .line 76
    move-result-object v1

    .line 77
    check-cast v1, Ln4;

    .line 78
    .line 79
    invoke-virtual {v1}, Ln4;->getSemanticsOwner()Ll21;

    .line 80
    .line 81
    .line 82
    move-result-object v2

    .line 83
    invoke-virtual {v2, p0, v0}, Ll21;->b(Lba0;Ld21;)V

    .line 84
    .line 85
    .line 86
    invoke-virtual {v1}, Ln4;->E()V

    .line 87
    .line 88
    .line 89
    return-void
.end method

.method public final G()V
    .registers 2

    .line 1
    iget v0, p0, Lba0;->m:I

    .line 2
    .line 3
    if-lez v0, :cond_7

    .line 4
    .line 5
    const/4 v0, 0x1

    .line 6
    iput-boolean v0, p0, Lba0;->p:Z

    .line 7
    .line 8
    :cond_7
    iget-boolean v0, p0, Lba0;->e:Z

    .line 9
    .line 10
    if-eqz v0, :cond_12

    .line 11
    .line 12
    iget-object p0, p0, Lba0;->q:Lba0;

    .line 13
    .line 14
    if-eqz p0, :cond_12

    .line 15
    .line 16
    invoke-virtual {p0}, Lba0;->G()V

    .line 17
    .line 18
    .line 19
    :cond_12
    return-void
.end method

.method public final H()Z
    .registers 1

    .line 1
    iget-object p0, p0, Lba0;->r:Llp0;

    .line 2
    .line 3
    if-eqz p0, :cond_6

    .line 4
    .line 5
    const/4 p0, 0x1

    .line 6
    return p0

    .line 7
    :cond_6
    const/4 p0, 0x0

    .line 8
    return p0
.end method

.method public final I()Z
    .registers 1

    .line 1
    iget-object p0, p0, Lba0;->K:Lfa0;

    .line 2
    .line 3
    iget-object p0, p0, Lfa0;->p:Llh0;

    .line 4
    .line 5
    iget-boolean p0, p0, Llh0;->v:Z

    .line 6
    .line 7
    return p0
.end method

.method public final J()Ljava/lang/Boolean;
    .registers 2

    .line 1
    iget-object p0, p0, Lba0;->K:Lfa0;

    .line 2
    .line 3
    iget-object p0, p0, Lfa0;->q:Lhg0;

    .line 4
    .line 5
    if-eqz p0, :cond_14

    .line 6
    .line 7
    iget-object p0, p0, Lhg0;->t:Lfg0;

    .line 8
    .line 9
    sget-object v0, Lfg0;->g:Lfg0;

    .line 10
    .line 11
    if-eq p0, v0, :cond_e

    .line 12
    .line 13
    const/4 p0, 0x1

    .line 14
    goto :goto_f

    .line 15
    :cond_e
    const/4 p0, 0x0

    .line 16
    :goto_f
    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 17
    .line 18
    .line 19
    move-result-object p0

    .line 20
    return-object p0

    .line 21
    :cond_14
    const/4 p0, 0x0

    .line 22
    return-object p0
.end method

.method public final K()V
    .registers 6

    .line 1
    iget-object v0, p0, Lba0;->G:Lz90;

    .line 2
    .line 3
    sget-object v1, Lz90;->g:Lz90;

    .line 4
    .line 5
    if-ne v0, v1, :cond_9

    .line 6
    .line 7
    invoke-virtual {p0}, Lba0;->f()V

    .line 8
    .line 9
    .line 10
    :cond_9
    iget-object p0, p0, Lba0;->K:Lfa0;

    .line 11
    .line 12
    iget-object p0, p0, Lfa0;->q:Lhg0;

    .line 13
    .line 14
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    const/4 v0, 0x1

    .line 18
    const/4 v1, 0x0

    .line 19
    :try_start_12
    iput-boolean v0, p0, Lhg0;->k:Z

    .line 20
    .line 21
    iget-boolean v2, p0, Lhg0;->o:Z

    .line 22
    .line 23
    if-nez v2, :cond_20

    .line 24
    .line 25
    const-string v2, "replace() called on item that was not placed"

    .line 26
    .line 27
    invoke-static {v2}, Lp50;->b(Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    goto :goto_20

    .line 31
    :catchall_1e
    move-exception v0

    .line 32
    goto :goto_47

    .line 33
    :cond_20
    :goto_20
    iput-boolean v1, p0, Lhg0;->E:Z

    .line 34
    .line 35
    iget-object v2, p0, Lhg0;->t:Lfg0;

    .line 36
    .line 37
    sget-object v3, Lfg0;->g:Lfg0;

    .line 38
    .line 39
    if-eq v2, v3, :cond_29

    .line 40
    .line 41
    goto :goto_2a

    .line 42
    :cond_29
    move v0, v1

    .line 43
    :goto_2a
    iget-wide v2, p0, Lhg0;->r:J

    .line 44
    .line 45
    iget-object v4, p0, Lhg0;->s:Li00;

    .line 46
    .line 47
    invoke-virtual {p0, v2, v3, v4}, Lhg0;->d0(JLi00;)V

    .line 48
    .line 49
    .line 50
    if-eqz v0, :cond_44

    .line 51
    .line 52
    iget-boolean v0, p0, Lhg0;->E:Z

    .line 53
    .line 54
    if-nez v0, :cond_44

    .line 55
    .line 56
    iget-object v0, p0, Lhg0;->j:Lfa0;

    .line 57
    .line 58
    iget-object v0, v0, Lfa0;->a:Lba0;

    .line 59
    .line 60
    invoke-virtual {v0}, Lba0;->v()Lba0;

    .line 61
    .line 62
    .line 63
    move-result-object v0

    .line 64
    if-eqz v0, :cond_44

    .line 65
    .line 66
    invoke-virtual {v0, v1}, Lba0;->S(Z)V
    :try_end_44
    .catchall {:try_start_12 .. :try_end_44} :catchall_1e

    .line 67
    .line 68
    .line 69
    :cond_44
    iput-boolean v1, p0, Lhg0;->k:Z

    .line 70
    .line 71
    return-void

    .line 72
    :goto_47
    iput-boolean v1, p0, Lhg0;->k:Z

    .line 73
    .line 74
    throw v0
.end method

.method public final L(III)V
    .registers 10

    .line 1
    if-ne p1, p2, :cond_3

    .line 2
    .line 3
    return-void

    .line 4
    :cond_3
    const/4 v0, 0x0

    .line 5
    :goto_4
    if-ge v0, p3, :cond_35

    .line 6
    .line 7
    if-le p1, p2, :cond_b

    .line 8
    .line 9
    add-int v1, p1, v0

    .line 10
    .line 11
    goto :goto_c

    .line 12
    :cond_b
    move v1, p1

    .line 13
    :goto_c
    if-le p1, p2, :cond_11

    .line 14
    .line 15
    add-int v2, p2, v0

    .line 16
    .line 17
    goto :goto_15

    .line 18
    :cond_11
    add-int v2, p2, p3

    .line 19
    .line 20
    add-int/lit8 v2, v2, -0x2

    .line 21
    .line 22
    :goto_15
    iget-object v3, p0, Lba0;->n:Lal;

    .line 23
    .line 24
    iget-object v4, v3, Lal;->f:Ljava/lang/Object;

    .line 25
    .line 26
    check-cast v4, Lqk0;

    .line 27
    .line 28
    iget-object v5, v3, Lal;->g:Ljava/lang/Object;

    .line 29
    .line 30
    check-cast v5, Lf8;

    .line 31
    .line 32
    invoke-virtual {v4, v1}, Lqk0;->k(I)Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    move-result-object v1

    .line 36
    invoke-virtual {v5}, Lf8;->a()Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    check-cast v1, Lba0;

    .line 40
    .line 41
    iget-object v3, v3, Lal;->f:Ljava/lang/Object;

    .line 42
    .line 43
    check-cast v3, Lqk0;

    .line 44
    .line 45
    invoke-virtual {v3, v2, v1}, Lqk0;->a(ILjava/lang/Object;)V

    .line 46
    .line 47
    .line 48
    invoke-virtual {v5}, Lf8;->a()Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    add-int/lit8 v0, v0, 0x1

    .line 52
    .line 53
    goto :goto_4

    .line 54
    :cond_35
    invoke-virtual {p0}, Lba0;->O()V

    .line 55
    .line 56
    .line 57
    invoke-virtual {p0}, Lba0;->G()V

    .line 58
    .line 59
    .line 60
    invoke-virtual {p0}, Lba0;->E()V

    .line 61
    .line 62
    .line 63
    return-void
.end method

.method public final M(Lba0;)V
    .registers 6

    .line 1
    iget-object v0, p1, Lba0;->K:Lfa0;

    .line 2
    .line 3
    iget v0, v0, Lfa0;->l:I

    .line 4
    .line 5
    if-lez v0, :cond_f

    .line 6
    .line 7
    iget-object v0, p0, Lba0;->K:Lfa0;

    .line 8
    .line 9
    iget v1, v0, Lfa0;->l:I

    .line 10
    .line 11
    add-int/lit8 v1, v1, -0x1

    .line 12
    .line 13
    invoke-virtual {v0, v1}, Lfa0;->d(I)V

    .line 14
    .line 15
    .line 16
    :cond_f
    iget-object v0, p0, Lba0;->r:Llp0;

    .line 17
    .line 18
    if-eqz v0, :cond_16

    .line 19
    .line 20
    invoke-virtual {p1}, Lba0;->h()V

    .line 21
    .line 22
    .line 23
    :cond_16
    const/4 v0, 0x0

    .line 24
    iput-object v0, p1, Lba0;->q:Lba0;

    .line 25
    .line 26
    iget v1, p1, Lba0;->T:I

    .line 27
    .line 28
    if-lez v1, :cond_24

    .line 29
    .line 30
    iget v1, p0, Lba0;->T:I

    .line 31
    .line 32
    add-int/lit8 v1, v1, -0x1

    .line 33
    .line 34
    invoke-virtual {p0, v1}, Lba0;->a0(I)V

    .line 35
    .line 36
    .line 37
    :cond_24
    iget-object v1, p1, Lba0;->J:Lem0;

    .line 38
    .line 39
    iget-object v1, v1, Lem0;->d:Lgm0;

    .line 40
    .line 41
    iput-object v0, v1, Lgm0;->u:Lgm0;

    .line 42
    .line 43
    iget-boolean v1, p1, Lba0;->e:Z

    .line 44
    .line 45
    if-eqz v1, :cond_4e

    .line 46
    .line 47
    iget v1, p0, Lba0;->m:I

    .line 48
    .line 49
    add-int/lit8 v1, v1, -0x1

    .line 50
    .line 51
    iput v1, p0, Lba0;->m:I

    .line 52
    .line 53
    iget-object p1, p1, Lba0;->n:Lal;

    .line 54
    .line 55
    iget-object p1, p1, Lal;->f:Ljava/lang/Object;

    .line 56
    .line 57
    check-cast p1, Lqk0;

    .line 58
    .line 59
    iget-object v1, p1, Lqk0;->e:[Ljava/lang/Object;

    .line 60
    .line 61
    iget p1, p1, Lqk0;->g:I

    .line 62
    .line 63
    const/4 v2, 0x0

    .line 64
    :goto_3f
    if-ge v2, p1, :cond_4e

    .line 65
    .line 66
    aget-object v3, v1, v2

    .line 67
    .line 68
    check-cast v3, Lba0;

    .line 69
    .line 70
    iget-object v3, v3, Lba0;->J:Lem0;

    .line 71
    .line 72
    iget-object v3, v3, Lem0;->d:Lgm0;

    .line 73
    .line 74
    iput-object v0, v3, Lgm0;->u:Lgm0;

    .line 75
    .line 76
    add-int/lit8 v2, v2, 0x1

    .line 77
    .line 78
    goto :goto_3f

    .line 79
    :cond_4e
    invoke-virtual {p0}, Lba0;->G()V

    .line 80
    .line 81
    .line 82
    invoke-virtual {p0}, Lba0;->O()V

    .line 83
    .line 84
    .line 85
    return-void
.end method

.method public final N(Lgm0;)V
    .registers 12

    .line 1
    iget-object v0, p0, Lba0;->r:Llp0;

    .line 2
    .line 3
    if-eqz v0, :cond_b

    .line 4
    .line 5
    check-cast v0, Ln4;

    .line 6
    .line 7
    invoke-virtual {v0}, Ln4;->getRectManager()Liw0;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    goto :goto_c

    .line 12
    :cond_b
    const/4 v0, 0x0

    .line 13
    :goto_c
    iget-object v1, p0, Lba0;->K:Lfa0;

    .line 14
    .line 15
    iget-object v2, v1, Lfa0;->d:Lx90;

    .line 16
    .line 17
    sget-object v3, Lx90;->i:Lx90;

    .line 18
    .line 19
    const/4 v4, 0x0

    .line 20
    const/4 v5, 0x1

    .line 21
    if-ne v2, v3, :cond_25

    .line 22
    .line 23
    invoke-virtual {p0}, Lba0;->q()Z

    .line 24
    .line 25
    .line 26
    move-result v2

    .line 27
    if-nez v2, :cond_25

    .line 28
    .line 29
    invoke-virtual {p0}, Lba0;->p()Z

    .line 30
    .line 31
    .line 32
    move-result v2

    .line 33
    if-eqz v2, :cond_23

    .line 34
    .line 35
    goto :goto_25

    .line 36
    :cond_23
    move v2, v4

    .line 37
    goto :goto_26

    .line 38
    :cond_25
    :goto_25
    move v2, v5

    .line 39
    :goto_26
    iget-boolean v3, p0, Lba0;->k:Z

    .line 40
    .line 41
    if-eqz v3, :cond_8c

    .line 42
    .line 43
    if-eqz v0, :cond_8c

    .line 44
    .line 45
    iget-object v3, p0, Lba0;->J:Lem0;

    .line 46
    .line 47
    iget-object v3, v3, Lem0;->d:Lgm0;

    .line 48
    .line 49
    if-ne p1, v3, :cond_3a

    .line 50
    .line 51
    iput-boolean v5, p0, Lba0;->j:Z

    .line 52
    .line 53
    if-nez v2, :cond_8c

    .line 54
    .line 55
    invoke-virtual {v0, p0}, Liw0;->f(Lba0;)V

    .line 56
    .line 57
    .line 58
    goto :goto_8c

    .line 59
    :cond_3a
    iput-boolean v5, p0, Lba0;->i:Z

    .line 60
    .line 61
    invoke-virtual {p0}, Lba0;->z()Lqk0;

    .line 62
    .line 63
    .line 64
    move-result-object p1

    .line 65
    iget-object v3, p1, Lqk0;->e:[Ljava/lang/Object;

    .line 66
    .line 67
    iget p1, p1, Lqk0;->g:I

    .line 68
    .line 69
    move v6, v4

    .line 70
    :goto_45
    if-ge v6, p1, :cond_55

    .line 71
    .line 72
    aget-object v7, v3, v6

    .line 73
    .line 74
    check-cast v7, Lba0;

    .line 75
    .line 76
    iput-boolean v5, v7, Lba0;->j:Z

    .line 77
    .line 78
    if-nez v2, :cond_52

    .line 79
    .line 80
    invoke-virtual {v0, v7}, Liw0;->f(Lba0;)V

    .line 81
    .line 82
    .line 83
    :cond_52
    add-int/lit8 v6, v6, 0x1

    .line 84
    .line 85
    goto :goto_45

    .line 86
    :cond_55
    iget-boolean p1, p0, Lba0;->k:Z

    .line 87
    .line 88
    if-eqz p1, :cond_89

    .line 89
    .line 90
    iput-boolean v5, v0, Liw0;->d:Z

    .line 91
    .line 92
    iget-object p1, v0, Liw0;->a:Li6;

    .line 93
    .line 94
    iget p0, p0, Lba0;->f:I

    .line 95
    .line 96
    const v2, 0x1ffffff

    .line 97
    .line 98
    .line 99
    and-int/2addr p0, v2

    .line 100
    iget-object v3, p1, Li6;->c:Ljava/lang/Object;

    .line 101
    .line 102
    check-cast v3, [J

    .line 103
    .line 104
    iget p1, p1, Li6;->b:I

    .line 105
    .line 106
    :goto_69
    array-length v5, v3

    .line 107
    add-int/lit8 v5, v5, -0x2

    .line 108
    .line 109
    if-ge v4, v5, :cond_89

    .line 110
    .line 111
    if-ge v4, p1, :cond_89

    .line 112
    .line 113
    add-int/lit8 v5, v4, 0x2

    .line 114
    .line 115
    aget-wide v6, v3, v5

    .line 116
    .line 117
    long-to-int v8, v6

    .line 118
    and-int/2addr v8, v2

    .line 119
    if-ne v8, p0, :cond_86

    .line 120
    .line 121
    const/16 p0, 0x3f

    .line 122
    .line 123
    shr-long p0, v6, p0

    .line 124
    .line 125
    const-wide/16 v8, 0x1

    .line 126
    .line 127
    and-long/2addr p0, v8

    .line 128
    const/16 v2, 0x3c

    .line 129
    .line 130
    shl-long/2addr p0, v2

    .line 131
    or-long/2addr p0, v6

    .line 132
    aput-wide p0, v3, v5

    .line 133
    .line 134
    goto :goto_89

    .line 135
    :cond_86
    add-int/lit8 v4, v4, 0x3

    .line 136
    .line 137
    goto :goto_69

    .line 138
    :cond_89
    :goto_89
    invoke-virtual {v0}, Liw0;->i()V

    .line 139
    .line 140
    .line 141
    :cond_8c
    :goto_8c
    iget-object p0, v1, Lfa0;->p:Llh0;

    .line 142
    .line 143
    invoke-virtual {p0}, Llh0;->e0()V

    .line 144
    .line 145
    .line 146
    return-void
.end method

.method public final O()V
    .registers 2

    .line 1
    iget-boolean v0, p0, Lba0;->e:Z

    .line 2
    .line 3
    if-eqz v0, :cond_e

    .line 4
    .line 5
    invoke-virtual {p0}, Lba0;->v()Lba0;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    if-eqz p0, :cond_d

    .line 10
    .line 11
    invoke-virtual {p0}, Lba0;->O()V

    .line 12
    .line 13
    .line 14
    :cond_d
    return-void

    .line 15
    :cond_e
    const/4 v0, 0x1

    .line 16
    iput-boolean v0, p0, Lba0;->z:Z

    .line 17
    .line 18
    return-void
.end method

.method public final P()V
    .registers 5

    .line 1
    iget-object v0, p0, Lba0;->n:Lal;

    .line 2
    .line 3
    iget-object v1, v0, Lal;->f:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v1, Lqk0;

    .line 6
    .line 7
    iget v1, v1, Lqk0;->g:I

    .line 8
    .line 9
    add-int/lit8 v1, v1, -0x1

    .line 10
    .line 11
    :goto_a
    iget-object v2, v0, Lal;->f:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v2, Lqk0;

    .line 14
    .line 15
    const/4 v3, -0x1

    .line 16
    if-ge v3, v1, :cond_1d

    .line 17
    .line 18
    iget-object v2, v2, Lqk0;->e:[Ljava/lang/Object;

    .line 19
    .line 20
    aget-object v2, v2, v1

    .line 21
    .line 22
    check-cast v2, Lba0;

    .line 23
    .line 24
    invoke-virtual {p0, v2}, Lba0;->M(Lba0;)V

    .line 25
    .line 26
    .line 27
    add-int/lit8 v1, v1, -0x1

    .line 28
    .line 29
    goto :goto_a

    .line 30
    :cond_1d
    invoke-virtual {v2}, Lqk0;->g()V

    .line 31
    .line 32
    .line 33
    iget-object p0, v0, Lal;->g:Ljava/lang/Object;

    .line 34
    .line 35
    check-cast p0, Lf8;

    .line 36
    .line 37
    invoke-virtual {p0}, Lf8;->a()Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    return-void
.end method

.method public final Q(II)V
    .registers 5

    .line 1
    if-ltz p2, :cond_3

    .line 2
    .line 3
    goto :goto_19

    .line 4
    :cond_3
    new-instance v0, Ljava/lang/StringBuilder;

    .line 5
    .line 6
    const-string v1, "count ("

    .line 7
    .line 8
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 12
    .line 13
    .line 14
    const-string v1, ") must be greater than 0"

    .line 15
    .line 16
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 17
    .line 18
    .line 19
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    invoke-static {v0}, Lp50;->a(Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    :goto_19
    add-int/2addr p2, p1

    .line 27
    add-int/lit8 p2, p2, -0x1

    .line 28
    .line 29
    if-gt p1, p2, :cond_43

    .line 30
    .line 31
    :goto_1e
    iget-object v0, p0, Lba0;->n:Lal;

    .line 32
    .line 33
    iget-object v1, v0, Lal;->f:Ljava/lang/Object;

    .line 34
    .line 35
    check-cast v1, Lqk0;

    .line 36
    .line 37
    iget-object v1, v1, Lqk0;->e:[Ljava/lang/Object;

    .line 38
    .line 39
    aget-object v1, v1, p2

    .line 40
    .line 41
    check-cast v1, Lba0;

    .line 42
    .line 43
    invoke-virtual {p0, v1}, Lba0;->M(Lba0;)V

    .line 44
    .line 45
    .line 46
    iget-object v1, v0, Lal;->f:Ljava/lang/Object;

    .line 47
    .line 48
    check-cast v1, Lqk0;

    .line 49
    .line 50
    invoke-virtual {v1, p2}, Lqk0;->k(I)Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object v1

    .line 54
    iget-object v0, v0, Lal;->g:Ljava/lang/Object;

    .line 55
    .line 56
    check-cast v0, Lf8;

    .line 57
    .line 58
    invoke-virtual {v0}, Lf8;->a()Ljava/lang/Object;

    .line 59
    .line 60
    .line 61
    check-cast v1, Lba0;

    .line 62
    .line 63
    if-eq p2, p1, :cond_43

    .line 64
    .line 65
    add-int/lit8 p2, p2, -0x1

    .line 66
    .line 67
    goto :goto_1e

    .line 68
    :cond_43
    return-void
.end method

.method public final R()V
    .registers 8

    .line 1
    iget-object v0, p0, Lba0;->G:Lz90;

    .line 2
    .line 3
    sget-object v1, Lz90;->g:Lz90;

    .line 4
    .line 5
    if-ne v0, v1, :cond_9

    .line 6
    .line 7
    invoke-virtual {p0}, Lba0;->f()V

    .line 8
    .line 9
    .line 10
    :cond_9
    iget-object p0, p0, Lba0;->K:Lfa0;

    .line 11
    .line 12
    iget-object p0, p0, Lfa0;->p:Llh0;

    .line 13
    .line 14
    iget-object v0, p0, Llh0;->j:Lfa0;

    .line 15
    .line 16
    const/4 v1, 0x0

    .line 17
    const/4 v2, 0x1

    .line 18
    :try_start_11
    iput-boolean v2, p0, Llh0;->k:Z

    .line 19
    .line 20
    iget-boolean v2, p0, Llh0;->o:Z

    .line 21
    .line 22
    if-nez v2, :cond_1f

    .line 23
    .line 24
    const-string v2, "replace called on unplaced item"

    .line 25
    .line 26
    invoke-static {v2}, Lp50;->b(Ljava/lang/String;)V

    .line 27
    .line 28
    .line 29
    goto :goto_1f

    .line 30
    :catchall_1d
    move-exception v2

    .line 31
    goto :goto_3e

    .line 32
    :cond_1f
    :goto_1f
    iget-boolean v2, p0, Llh0;->v:Z

    .line 33
    .line 34
    iget-wide v3, p0, Llh0;->q:J

    .line 35
    .line 36
    iget v5, p0, Llh0;->s:F

    .line 37
    .line 38
    iget-object v6, p0, Llh0;->r:Li00;

    .line 39
    .line 40
    invoke-virtual {p0, v3, v4, v5, v6}, Llh0;->a0(JFLi00;)V

    .line 41
    .line 42
    .line 43
    if-eqz v2, :cond_3b

    .line 44
    .line 45
    iget-boolean v2, p0, Llh0;->I:Z

    .line 46
    .line 47
    if-nez v2, :cond_3b

    .line 48
    .line 49
    iget-object v2, v0, Lfa0;->a:Lba0;

    .line 50
    .line 51
    invoke-virtual {v2}, Lba0;->v()Lba0;

    .line 52
    .line 53
    .line 54
    move-result-object v2

    .line 55
    if-eqz v2, :cond_3b

    .line 56
    .line 57
    invoke-virtual {v2, v1}, Lba0;->U(Z)V
    :try_end_3b
    .catchall {:try_start_11 .. :try_end_3b} :catchall_1d

    .line 58
    .line 59
    .line 60
    :cond_3b
    iput-boolean v1, p0, Llh0;->k:Z

    .line 61
    .line 62
    return-void

    .line 63
    :goto_3e
    :try_start_3e
    iget-object v0, v0, Lfa0;->a:Lba0;

    .line 64
    .line 65
    invoke-virtual {v0, v2}, Lba0;->Y(Ljava/lang/Throwable;)V

    .line 66
    .line 67
    .line 68
    const/4 v0, 0x0

    .line 69
    throw v0
    :try_end_45
    .catchall {:try_start_3e .. :try_end_45} :catchall_45

    .line 70
    :catchall_45
    move-exception v0

    .line 71
    iput-boolean v1, p0, Llh0;->k:Z

    .line 72
    .line 73
    throw v0
.end method

.method public final S(Z)V
    .registers 4

    .line 1
    iget-boolean v0, p0, Lba0;->e:Z

    .line 2
    .line 3
    if-nez v0, :cond_e

    .line 4
    .line 5
    iget-object v0, p0, Lba0;->r:Llp0;

    .line 6
    .line 7
    if-eqz v0, :cond_e

    .line 8
    .line 9
    const/4 v1, 0x1

    .line 10
    check-cast v0, Ln4;

    .line 11
    .line 12
    invoke-virtual {v0, p0, v1, p1}, Ln4;->D(Lba0;ZZ)V

    .line 13
    .line 14
    .line 15
    :cond_e
    return-void
.end method

.method public final U(Z)V
    .registers 4

    .line 1
    iget-boolean v0, p0, Lba0;->e:Z

    .line 2
    .line 3
    if-nez v0, :cond_e

    .line 4
    .line 5
    iget-object v0, p0, Lba0;->r:Llp0;

    .line 6
    .line 7
    if-eqz v0, :cond_e

    .line 8
    .line 9
    const/4 v1, 0x0

    .line 10
    check-cast v0, Ln4;

    .line 11
    .line 12
    invoke-virtual {v0, p0, v1, p1}, Ln4;->D(Lba0;ZZ)V

    .line 13
    .line 14
    .line 15
    :cond_e
    return-void
.end method

.method public final X()V
    .registers 6

    .line 1
    invoke-virtual {p0}, Lba0;->z()Lqk0;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    iget-object v0, p0, Lqk0;->e:[Ljava/lang/Object;

    .line 6
    .line 7
    iget p0, p0, Lqk0;->g:I

    .line 8
    .line 9
    const/4 v1, 0x0

    .line 10
    :goto_9
    if-ge v1, p0, :cond_1d

    .line 11
    .line 12
    aget-object v2, v0, v1

    .line 13
    .line 14
    check-cast v2, Lba0;

    .line 15
    .line 16
    iget-object v3, v2, Lba0;->H:Lz90;

    .line 17
    .line 18
    iput-object v3, v2, Lba0;->G:Lz90;

    .line 19
    .line 20
    sget-object v4, Lz90;->g:Lz90;

    .line 21
    .line 22
    if-eq v3, v4, :cond_1a

    .line 23
    .line 24
    invoke-virtual {v2}, Lba0;->X()V

    .line 25
    .line 26
    .line 27
    :cond_1a
    add-int/lit8 v1, v1, 0x1

    .line 28
    .line 29
    goto :goto_9

    .line 30
    :cond_1d
    return-void
.end method

.method public final Y(Ljava/lang/Throwable;)V
    .registers 5

    .line 1
    iget-object v0, p0, Lba0;->F:Lck;

    .line 2
    .line 3
    sget-object v1, Lxj;->a:Lk81;

    .line 4
    .line 5
    check-cast v0, Lqr0;

    .line 6
    .line 7
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    .line 9
    .line 10
    invoke-static {v0, v1}, Lgh0;->L(Lqr0;Llv0;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    check-cast v0, Lwj;

    .line 15
    .line 16
    if-eqz v0, :cond_1a

    .line 17
    .line 18
    new-instance v1, Lva;

    .line 19
    .line 20
    const/4 v2, 0x2

    .line 21
    invoke-direct {v1, v2, v0, p0}, Lva;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 22
    .line 23
    .line 24
    invoke-static {p1, v1}, La5;->P(Ljava/lang/Throwable;Lxz;)Z

    .line 25
    .line 26
    .line 27
    :cond_1a
    throw p1
.end method

.method public final Z(Ljp;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lba0;->C:Ljp;

    .line 2
    .line 3
    invoke-static {v0, p1}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-nez v0, :cond_2f

    .line 8
    .line 9
    iput-object p1, p0, Lba0;->C:Ljp;

    .line 10
    .line 11
    invoke-virtual {p0}, Lba0;->E()V

    .line 12
    .line 13
    .line 14
    invoke-virtual {p0}, Lba0;->v()Lba0;

    .line 15
    .line 16
    .line 17
    move-result-object p1

    .line 18
    if-eqz p1, :cond_17

    .line 19
    .line 20
    invoke-virtual {p1}, Lba0;->C()V

    .line 21
    .line 22
    .line 23
    goto :goto_20

    .line 24
    :cond_17
    iget-object p1, p0, Lba0;->r:Llp0;

    .line 25
    .line 26
    if-eqz p1, :cond_20

    .line 27
    .line 28
    check-cast p1, Ln4;

    .line 29
    .line 30
    invoke-virtual {p1}, Landroid/view/View;->invalidate()V

    .line 31
    .line 32
    .line 33
    :cond_20
    :goto_20
    invoke-virtual {p0}, Lba0;->D()V

    .line 34
    .line 35
    .line 36
    iget-object p0, p0, Lba0;->J:Lem0;

    .line 37
    .line 38
    iget-object p0, p0, Lem0;->f:Lli0;

    .line 39
    .line 40
    :goto_27
    if-eqz p0, :cond_2f

    .line 41
    .line 42
    invoke-virtual {p0}, Lli0;->i0()V

    .line 43
    .line 44
    .line 45
    iget-object p0, p0, Lli0;->j:Lli0;

    .line 46
    .line 47
    goto :goto_27

    .line 48
    :cond_2f
    return-void
.end method

.method public final a()V
    .registers 3

    .line 1
    iget-object v0, p0, Lba0;->s:Lah1;

    .line 2
    .line 3
    if-eqz v0, :cond_7

    .line 4
    .line 5
    invoke-virtual {v0}, Lq7;->a()V

    .line 6
    .line 7
    .line 8
    :cond_7
    iget-object v0, p0, Lba0;->L:Lpa0;

    .line 9
    .line 10
    if-eqz v0, :cond_e

    .line 11
    .line 12
    invoke-virtual {v0}, Lpa0;->a()V

    .line 13
    .line 14
    .line 15
    :cond_e
    iget-object p0, p0, Lba0;->J:Lem0;

    .line 16
    .line 17
    iget-object v0, p0, Lem0;->d:Lgm0;

    .line 18
    .line 19
    iget-object p0, p0, Lem0;->c:Lv50;

    .line 20
    .line 21
    iget-object p0, p0, Lgm0;->t:Lgm0;

    .line 22
    .line 23
    :goto_16
    invoke-static {v0, p0}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 24
    .line 25
    .line 26
    move-result v1

    .line 27
    if-nez v1, :cond_24

    .line 28
    .line 29
    if-eqz v0, :cond_24

    .line 30
    .line 31
    invoke-virtual {v0}, Lgm0;->K0()V

    .line 32
    .line 33
    .line 34
    iget-object v0, v0, Lgm0;->t:Lgm0;

    .line 35
    .line 36
    goto :goto_16

    .line 37
    :cond_24
    return-void
.end method

.method public final a0(I)V
    .registers 4

    .line 1
    iget v0, p0, Lba0;->T:I

    .line 2
    .line 3
    if-eq v0, p1, :cond_2a

    .line 4
    .line 5
    if-lez p1, :cond_15

    .line 6
    .line 7
    if-nez v0, :cond_15

    .line 8
    .line 9
    invoke-virtual {p0}, Lba0;->v()Lba0;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    if-eqz v0, :cond_15

    .line 14
    .line 15
    iget v1, v0, Lba0;->T:I

    .line 16
    .line 17
    add-int/lit8 v1, v1, 0x1

    .line 18
    .line 19
    invoke-virtual {v0, v1}, Lba0;->a0(I)V

    .line 20
    .line 21
    .line 22
    :cond_15
    if-nez p1, :cond_28

    .line 23
    .line 24
    iget v0, p0, Lba0;->T:I

    .line 25
    .line 26
    if-lez v0, :cond_28

    .line 27
    .line 28
    invoke-virtual {p0}, Lba0;->v()Lba0;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    if-eqz v0, :cond_28

    .line 33
    .line 34
    iget v1, v0, Lba0;->T:I

    .line 35
    .line 36
    add-int/lit8 v1, v1, -0x1

    .line 37
    .line 38
    invoke-virtual {v0, v1}, Lba0;->a0(I)V

    .line 39
    .line 40
    .line 41
    :cond_28
    iput p1, p0, Lba0;->T:I

    .line 42
    .line 43
    :cond_2a
    return-void
.end method

.method public final b(Lmi0;)V
    .registers 21

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    iget-object v2, v0, Lba0;->J:Lem0;

    .line 6
    .line 7
    const/16 v7, 0x10

    .line 8
    .line 9
    invoke-virtual {v2, v7}, Lem0;->d(I)Z

    .line 10
    .line 11
    .line 12
    move-result v8

    .line 13
    iget-object v9, v2, Lem0;->e:Lha1;

    .line 14
    .line 15
    const/16 v10, 0x400

    .line 16
    .line 17
    invoke-virtual {v2, v10}, Lem0;->d(I)Z

    .line 18
    .line 19
    .line 20
    move-result v11

    .line 21
    iput-object v1, v0, Lba0;->O:Lmi0;

    .line 22
    .line 23
    iget-object v3, v2, Lem0;->c:Lv50;

    .line 24
    .line 25
    iget-object v4, v2, Lem0;->a:Lba0;

    .line 26
    .line 27
    iget-object v5, v2, Lem0;->f:Lli0;

    .line 28
    .line 29
    iget-object v12, v2, Lem0;->b:Ldm0;

    .line 30
    .line 31
    if-eq v5, v12, :cond_21

    .line 32
    .line 33
    goto :goto_26

    .line 34
    :cond_21
    const-string v5, "padChain called on already padded chain"

    .line 35
    .line 36
    invoke-static {v5}, Lp50;->b(Ljava/lang/String;)V

    .line 37
    .line 38
    .line 39
    :goto_26
    iget-object v5, v2, Lem0;->f:Lli0;

    .line 40
    .line 41
    iput-object v12, v5, Lli0;->i:Lli0;

    .line 42
    .line 43
    iput-object v5, v12, Lli0;->j:Lli0;

    .line 44
    .line 45
    move-object v5, v3

    .line 46
    iget-object v3, v2, Lem0;->g:Lqk0;

    .line 47
    .line 48
    if-eqz v3, :cond_34

    .line 49
    .line 50
    iget v6, v3, Lqk0;->g:I

    .line 51
    .line 52
    goto :goto_35

    .line 53
    :cond_34
    const/4 v6, 0x0

    .line 54
    :goto_35
    iget-object v14, v2, Lem0;->h:Lqk0;

    .line 55
    .line 56
    if-nez v14, :cond_40

    .line 57
    .line 58
    new-instance v14, Lqk0;

    .line 59
    .line 60
    new-array v15, v7, [Lki0;

    .line 61
    .line 62
    invoke-direct {v14, v15}, Lqk0;-><init>([Ljava/lang/Object;)V

    .line 63
    .line 64
    .line 65
    :cond_40
    iget-object v15, v2, Lem0;->i:Lqk0;

    .line 66
    .line 67
    invoke-virtual {v15, v1}, Lqk0;->b(Ljava/lang/Object;)V

    .line 68
    .line 69
    .line 70
    const/16 v16, 0x0

    .line 71
    .line 72
    :goto_47
    iget v1, v15, Lqk0;->g:I

    .line 73
    .line 74
    if-eqz v1, :cond_80

    .line 75
    .line 76
    add-int/lit8 v1, v1, -0x1

    .line 77
    .line 78
    invoke-virtual {v15, v1}, Lqk0;->k(I)Ljava/lang/Object;

    .line 79
    .line 80
    .line 81
    move-result-object v1

    .line 82
    check-cast v1, Lmi0;

    .line 83
    .line 84
    instance-of v13, v1, Lrh;

    .line 85
    .line 86
    if-eqz v13, :cond_64

    .line 87
    .line 88
    check-cast v1, Lrh;

    .line 89
    .line 90
    iget-object v13, v1, Lrh;->b:Lmi0;

    .line 91
    .line 92
    invoke-virtual {v15, v13}, Lqk0;->b(Ljava/lang/Object;)V

    .line 93
    .line 94
    .line 95
    iget-object v1, v1, Lrh;->a:Lmi0;

    .line 96
    .line 97
    invoke-virtual {v15, v1}, Lqk0;->b(Ljava/lang/Object;)V

    .line 98
    .line 99
    .line 100
    goto :goto_7d

    .line 101
    :cond_64
    instance-of v13, v1, Lki0;

    .line 102
    .line 103
    if-eqz v13, :cond_6c

    .line 104
    .line 105
    invoke-virtual {v14, v1}, Lqk0;->b(Ljava/lang/Object;)V

    .line 106
    .line 107
    .line 108
    goto :goto_7d

    .line 109
    :cond_6c
    if-nez v16, :cond_78

    .line 110
    .line 111
    new-instance v13, Lj3;

    .line 112
    .line 113
    const/16 v10, 0x12

    .line 114
    .line 115
    invoke-direct {v13, v10, v14}, Lj3;-><init>(ILjava/lang/Object;)V

    .line 116
    .line 117
    .line 118
    move-object/from16 v16, v13

    .line 119
    .line 120
    goto :goto_7a

    .line 121
    :cond_78
    move-object/from16 v13, v16

    .line 122
    .line 123
    :goto_7a
    invoke-interface {v1, v13}, Lmi0;->d(Li00;)Z

    .line 124
    .line 125
    .line 126
    :goto_7d
    const/16 v10, 0x400

    .line 127
    .line 128
    goto :goto_47

    .line 129
    :cond_80
    iget v1, v14, Lqk0;->g:I

    .line 130
    .line 131
    const-string v13, "expected prior modifier list to be non-empty"

    .line 132
    .line 133
    if-ne v1, v6, :cond_108

    .line 134
    .line 135
    iget-object v1, v12, Lli0;->j:Lli0;

    .line 136
    .line 137
    move-object v5, v2

    .line 138
    const/4 v2, 0x0

    .line 139
    :goto_8a
    if-eqz v1, :cond_d2

    .line 140
    .line 141
    if-ge v2, v6, :cond_d2

    .line 142
    .line 143
    if-eqz v3, :cond_cd

    .line 144
    .line 145
    const/16 v16, 0x2

    .line 146
    .line 147
    iget-object v10, v3, Lqk0;->e:[Ljava/lang/Object;

    .line 148
    .line 149
    aget-object v10, v10, v2

    .line 150
    .line 151
    check-cast v10, Lki0;

    .line 152
    .line 153
    iget-object v7, v14, Lqk0;->e:[Ljava/lang/Object;

    .line 154
    .line 155
    aget-object v7, v7, v2

    .line 156
    .line 157
    check-cast v7, Lki0;

    .line 158
    .line 159
    invoke-static {v10, v7}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 160
    .line 161
    .line 162
    move-result v17

    .line 163
    if-eqz v17, :cond_a9

    .line 164
    .line 165
    move-object/from16 v18, v3

    .line 166
    .line 167
    move/from16 v3, v16

    .line 168
    .line 169
    goto :goto_b8

    .line 170
    :cond_a9
    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 171
    .line 172
    .line 173
    move-result-object v15

    .line 174
    move-object/from16 v18, v3

    .line 175
    .line 176
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 177
    .line 178
    .line 179
    move-result-object v3

    .line 180
    if-ne v15, v3, :cond_b7

    .line 181
    .line 182
    const/4 v3, 0x1

    .line 183
    goto :goto_b8

    .line 184
    :cond_b7
    const/4 v3, 0x0

    .line 185
    :goto_b8
    if-eqz v3, :cond_ca

    .line 186
    .line 187
    const/4 v15, 0x1

    .line 188
    if-eq v3, v15, :cond_be

    .line 189
    .line 190
    goto :goto_c1

    .line 191
    :cond_be
    invoke-static {v10, v7, v1}, Lem0;->h(Lki0;Lki0;Lli0;)V

    .line 192
    .line 193
    .line 194
    :goto_c1
    iget-object v1, v1, Lli0;->j:Lli0;

    .line 195
    .line 196
    add-int/lit8 v2, v2, 0x1

    .line 197
    .line 198
    move-object/from16 v3, v18

    .line 199
    .line 200
    const/16 v7, 0x10

    .line 201
    .line 202
    goto :goto_8a

    .line 203
    :cond_ca
    iget-object v1, v1, Lli0;->i:Lli0;

    .line 204
    .line 205
    goto :goto_d6

    .line 206
    :cond_cd
    invoke-static {v13}, Lfu0;->C(Ljava/lang/String;)Lyh;

    .line 207
    .line 208
    .line 209
    move-result-object v0

    .line 210
    throw v0

    .line 211
    :cond_d2
    move-object/from16 v18, v3

    .line 212
    .line 213
    const/16 v16, 0x2

    .line 214
    .line 215
    :goto_d6
    if-ge v2, v6, :cond_103

    .line 216
    .line 217
    if-eqz v18, :cond_fe

    .line 218
    .line 219
    if-eqz v1, :cond_f7

    .line 220
    .line 221
    iget-object v3, v4, Lba0;->P:Lmi0;

    .line 222
    .line 223
    if-eqz v3, :cond_e4

    .line 224
    .line 225
    const/16 v17, 0x1

    .line 226
    .line 227
    :goto_e2
    const/4 v15, 0x1

    .line 228
    goto :goto_e7

    .line 229
    :cond_e4
    const/16 v17, 0x0

    .line 230
    .line 231
    goto :goto_e2

    .line 232
    :goto_e7
    xor-int/lit8 v6, v17, 0x1

    .line 233
    .line 234
    move-object v3, v5

    .line 235
    move-object v5, v1

    .line 236
    move-object v1, v3

    .line 237
    move-object v4, v14

    .line 238
    move-object/from16 v3, v18

    .line 239
    .line 240
    const/4 v7, 0x0

    .line 241
    invoke-virtual/range {v1 .. v6}, Lem0;->f(ILqk0;Lqk0;Lli0;Z)V

    .line 242
    .line 243
    .line 244
    move-object v5, v12

    .line 245
    :goto_f4
    const/4 v15, 0x1

    .line 246
    goto/16 :goto_185

    .line 247
    .line 248
    :cond_f7
    const-string v0, "structuralUpdate requires a non-null tail"

    .line 249
    .line 250
    invoke-static {v0}, Lfu0;->C(Ljava/lang/String;)Lyh;

    .line 251
    .line 252
    .line 253
    move-result-object v0

    .line 254
    throw v0

    .line 255
    :cond_fe
    invoke-static {v13}, Lfu0;->C(Ljava/lang/String;)Lyh;

    .line 256
    .line 257
    .line 258
    move-result-object v0

    .line 259
    throw v0

    .line 260
    :cond_103
    move-object v2, v5

    .line 261
    move-object/from16 v3, v18

    .line 262
    .line 263
    const/4 v7, 0x0

    .line 264
    goto :goto_15d

    .line 265
    :cond_108
    const/4 v7, 0x0

    .line 266
    const/16 v16, 0x2

    .line 267
    .line 268
    iget-object v10, v4, Lba0;->P:Lmi0;

    .line 269
    .line 270
    if-eqz v10, :cond_137

    .line 271
    .line 272
    if-nez v6, :cond_137

    .line 273
    .line 274
    move-object v4, v12

    .line 275
    const/4 v1, 0x0

    .line 276
    :goto_113
    iget v5, v14, Lqk0;->g:I

    .line 277
    .line 278
    if-ge v1, v5, :cond_124

    .line 279
    .line 280
    iget-object v5, v14, Lqk0;->e:[Ljava/lang/Object;

    .line 281
    .line 282
    aget-object v5, v5, v1

    .line 283
    .line 284
    check-cast v5, Lki0;

    .line 285
    .line 286
    invoke-static {v5, v4}, Lem0;->b(Lki0;Lli0;)Lli0;

    .line 287
    .line 288
    .line 289
    move-result-object v4

    .line 290
    add-int/lit8 v1, v1, 0x1

    .line 291
    .line 292
    goto :goto_113

    .line 293
    :cond_124
    iget-object v1, v9, Lli0;->i:Lli0;

    .line 294
    .line 295
    const/4 v4, 0x0

    .line 296
    :goto_127
    if-eqz v1, :cond_133

    .line 297
    .line 298
    if-eq v1, v12, :cond_133

    .line 299
    .line 300
    iget v5, v1, Lli0;->g:I

    .line 301
    .line 302
    or-int/2addr v4, v5

    .line 303
    iput v4, v1, Lli0;->h:I

    .line 304
    .line 305
    iget-object v1, v1, Lli0;->i:Lli0;

    .line 306
    .line 307
    goto :goto_127

    .line 308
    :cond_133
    move-object v1, v2

    .line 309
    move-object v5, v12

    .line 310
    move-object v4, v14

    .line 311
    goto :goto_f4

    .line 312
    :cond_137
    if-nez v1, :cond_167

    .line 313
    .line 314
    if-eqz v3, :cond_162

    .line 315
    .line 316
    iget-object v1, v12, Lli0;->j:Lli0;

    .line 317
    .line 318
    const/4 v6, 0x0

    .line 319
    :goto_13e
    if-eqz v1, :cond_14d

    .line 320
    .line 321
    iget v10, v3, Lqk0;->g:I

    .line 322
    .line 323
    if-ge v6, v10, :cond_14d

    .line 324
    .line 325
    invoke-static {v1}, Lem0;->c(Lli0;)Lli0;

    .line 326
    .line 327
    .line 328
    move-result-object v1

    .line 329
    iget-object v1, v1, Lli0;->j:Lli0;

    .line 330
    .line 331
    add-int/lit8 v6, v6, 0x1

    .line 332
    .line 333
    goto :goto_13e

    .line 334
    :cond_14d
    invoke-virtual {v4}, Lba0;->v()Lba0;

    .line 335
    .line 336
    .line 337
    move-result-object v1

    .line 338
    if-eqz v1, :cond_158

    .line 339
    .line 340
    iget-object v1, v1, Lba0;->J:Lem0;

    .line 341
    .line 342
    iget-object v1, v1, Lem0;->c:Lv50;

    .line 343
    .line 344
    goto :goto_159

    .line 345
    :cond_158
    move-object v1, v7

    .line 346
    :goto_159
    iput-object v1, v5, Lgm0;->u:Lgm0;

    .line 347
    .line 348
    iput-object v5, v2, Lem0;->d:Lgm0;

    .line 349
    .line 350
    :goto_15d
    move-object v1, v2

    .line 351
    move-object v5, v12

    .line 352
    move-object v4, v14

    .line 353
    const/4 v15, 0x0

    .line 354
    goto :goto_185

    .line 355
    :cond_162
    invoke-static {v13}, Lfu0;->C(Ljava/lang/String;)Lyh;

    .line 356
    .line 357
    .line 358
    move-result-object v0

    .line 359
    throw v0

    .line 360
    :cond_167
    if-nez v3, :cond_172

    .line 361
    .line 362
    new-instance v3, Lqk0;

    .line 363
    .line 364
    const/16 v1, 0x10

    .line 365
    .line 366
    new-array v4, v1, [Lki0;

    .line 367
    .line 368
    invoke-direct {v3, v4}, Lqk0;-><init>([Ljava/lang/Object;)V

    .line 369
    .line 370
    .line 371
    :cond_172
    if-eqz v10, :cond_178

    .line 372
    .line 373
    const/4 v15, 0x1

    .line 374
    :goto_175
    const/16 v17, 0x1

    .line 375
    .line 376
    goto :goto_17a

    .line 377
    :cond_178
    const/4 v15, 0x0

    .line 378
    goto :goto_175

    .line 379
    :goto_17a
    xor-int/lit8 v6, v15, 0x1

    .line 380
    .line 381
    move-object v1, v2

    .line 382
    const/4 v2, 0x0

    .line 383
    move-object v5, v12

    .line 384
    move-object v4, v14

    .line 385
    invoke-virtual/range {v1 .. v6}, Lem0;->f(ILqk0;Lqk0;Lli0;Z)V

    .line 386
    .line 387
    .line 388
    move/from16 v15, v17

    .line 389
    .line 390
    :goto_185
    iput-object v4, v1, Lem0;->g:Lqk0;

    .line 391
    .line 392
    if-eqz v3, :cond_18d

    .line 393
    .line 394
    invoke-virtual {v3}, Lqk0;->g()V

    .line 395
    .line 396
    .line 397
    goto :goto_18e

    .line 398
    :cond_18d
    move-object v3, v7

    .line 399
    :goto_18e
    iput-object v3, v1, Lem0;->h:Lqk0;

    .line 400
    .line 401
    iget-object v2, v5, Lli0;->j:Lli0;

    .line 402
    .line 403
    if-nez v2, :cond_195

    .line 404
    .line 405
    goto :goto_196

    .line 406
    :cond_195
    move-object v9, v2

    .line 407
    :goto_196
    iput-object v7, v9, Lli0;->i:Lli0;

    .line 408
    .line 409
    iput-object v7, v5, Lli0;->j:Lli0;

    .line 410
    .line 411
    const/4 v2, -0x1

    .line 412
    iput v2, v5, Lli0;->h:I

    .line 413
    .line 414
    iput-object v7, v5, Lli0;->l:Lgm0;

    .line 415
    .line 416
    if-eq v9, v5, :cond_1a2

    .line 417
    .line 418
    goto :goto_1a7

    .line 419
    :cond_1a2
    const-string v2, "trimChain did not update the head"

    .line 420
    .line 421
    invoke-static {v2}, Lp50;->b(Ljava/lang/String;)V

    .line 422
    .line 423
    .line 424
    :goto_1a7
    iput-object v9, v1, Lem0;->f:Lli0;

    .line 425
    .line 426
    if-eqz v15, :cond_1ae

    .line 427
    .line 428
    invoke-virtual {v1}, Lem0;->g()V

    .line 429
    .line 430
    .line 431
    :cond_1ae
    const/16 v2, 0x10

    .line 432
    .line 433
    invoke-virtual {v1, v2}, Lem0;->d(I)Z

    .line 434
    .line 435
    .line 436
    move-result v2

    .line 437
    const/16 v3, 0x400

    .line 438
    .line 439
    invoke-virtual {v1, v3}, Lem0;->d(I)Z

    .line 440
    .line 441
    .line 442
    move-result v3

    .line 443
    iget-object v4, v0, Lba0;->K:Lfa0;

    .line 444
    .line 445
    invoke-virtual {v4}, Lfa0;->j()V

    .line 446
    .line 447
    .line 448
    iget-object v4, v0, Lba0;->l:Lba0;

    .line 449
    .line 450
    if-nez v4, :cond_1ce

    .line 451
    .line 452
    const/16 v4, 0x200

    .line 453
    .line 454
    invoke-virtual {v1, v4}, Lem0;->d(I)Z

    .line 455
    .line 456
    .line 457
    move-result v1

    .line 458
    if-eqz v1, :cond_1ce

    .line 459
    .line 460
    invoke-virtual {v0, v0}, Lba0;->b0(Lba0;)V

    .line 461
    .line 462
    .line 463
    :cond_1ce
    if-ne v8, v2, :cond_1d2

    .line 464
    .line 465
    if-eq v11, v3, :cond_219

    .line 466
    .line 467
    :cond_1d2
    invoke-static {v0}, Lea0;->a(Lba0;)Llp0;

    .line 468
    .line 469
    .line 470
    move-result-object v1

    .line 471
    check-cast v1, Ln4;

    .line 472
    .line 473
    invoke-virtual {v1}, Ln4;->getRectManager()Liw0;

    .line 474
    .line 475
    .line 476
    move-result-object v1

    .line 477
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 478
    .line 479
    .line 480
    invoke-virtual {v0}, Lba0;->H()Z

    .line 481
    .line 482
    .line 483
    move-result v4

    .line 484
    if-eqz v4, :cond_219

    .line 485
    .line 486
    iget-object v1, v1, Liw0;->a:Li6;

    .line 487
    .line 488
    iget v0, v0, Lba0;->f:I

    .line 489
    .line 490
    const v4, 0x1ffffff

    .line 491
    .line 492
    .line 493
    and-int/2addr v0, v4

    .line 494
    iget-object v5, v1, Li6;->c:Ljava/lang/Object;

    .line 495
    .line 496
    check-cast v5, [J

    .line 497
    .line 498
    iget v1, v1, Li6;->b:I

    .line 499
    .line 500
    const/4 v13, 0x0

    .line 501
    :goto_1f4
    array-length v6, v5

    .line 502
    add-int/lit8 v6, v6, -0x2

    .line 503
    .line 504
    if-ge v13, v6, :cond_219

    .line 505
    .line 506
    if-ge v13, v1, :cond_219

    .line 507
    .line 508
    add-int/lit8 v6, v13, 0x2

    .line 509
    .line 510
    aget-wide v7, v5, v6

    .line 511
    .line 512
    long-to-int v9, v7

    .line 513
    and-int/2addr v9, v4

    .line 514
    if-ne v9, v0, :cond_216

    .line 515
    .line 516
    const-wide v0, -0x6000000000000001L

    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    and-long/2addr v0, v7

    .line 522
    const-wide/high16 v7, 0x2000000000000000L

    .line 523
    .line 524
    int-to-long v3, v3

    .line 525
    mul-long/2addr v3, v7

    .line 526
    or-long/2addr v0, v3

    .line 527
    const-wide/high16 v3, 0x4000000000000000L  # 2.0

    .line 528
    .line 529
    int-to-long v7, v2

    .line 530
    mul-long/2addr v7, v3

    .line 531
    or-long/2addr v0, v7

    .line 532
    aput-wide v0, v5, v6

    .line 533
    .line 534
    return-void

    .line 535
    :cond_216
    add-int/lit8 v13, v13, 0x3

    .line 536
    .line 537
    goto :goto_1f4

    .line 538
    :cond_219
    return-void
.end method

.method public final b0(Lba0;)V
    .registers 4

    .line 1
    iget-object v0, p0, Lba0;->l:Lba0;

    .line 2
    .line 3
    invoke-static {p1, v0}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-nez v0, :cond_3a

    .line 8
    .line 9
    iput-object p1, p0, Lba0;->l:Lba0;

    .line 10
    .line 11
    iget-object v0, p0, Lba0;->K:Lfa0;

    .line 12
    .line 13
    if-eqz p1, :cond_2f

    .line 14
    .line 15
    iget-object p1, v0, Lfa0;->q:Lhg0;

    .line 16
    .line 17
    if-nez p1, :cond_19

    .line 18
    .line 19
    new-instance p1, Lhg0;

    .line 20
    .line 21
    invoke-direct {p1, v0}, Lhg0;-><init>(Lfa0;)V

    .line 22
    .line 23
    .line 24
    iput-object p1, v0, Lfa0;->q:Lhg0;

    .line 25
    .line 26
    :cond_19
    iget-object p1, p0, Lba0;->J:Lem0;

    .line 27
    .line 28
    iget-object v0, p1, Lem0;->d:Lgm0;

    .line 29
    .line 30
    iget-object p1, p1, Lem0;->c:Lv50;

    .line 31
    .line 32
    iget-object p1, p1, Lgm0;->t:Lgm0;

    .line 33
    .line 34
    :goto_21
    invoke-static {v0, p1}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v1

    .line 38
    if-nez v1, :cond_37

    .line 39
    .line 40
    if-eqz v0, :cond_37

    .line 41
    .line 42
    invoke-virtual {v0}, Lgm0;->t0()V

    .line 43
    .line 44
    .line 45
    iget-object v0, v0, Lgm0;->t:Lgm0;

    .line 46
    .line 47
    goto :goto_21

    .line 48
    :cond_2f
    const/4 p1, 0x0

    .line 49
    iput-object p1, v0, Lfa0;->q:Lhg0;

    .line 50
    .line 51
    const/4 p1, 0x0

    .line 52
    iput-boolean p1, v0, Lfa0;->f:Z

    .line 53
    .line 54
    iput-boolean p1, v0, Lfa0;->e:Z

    .line 55
    .line 56
    :cond_37
    invoke-virtual {p0}, Lba0;->E()V

    .line 57
    .line 58
    .line 59
    :cond_3a
    return-void
.end method

.method public final c()V
    .registers 5

    .line 1
    iget-object v0, p0, Lba0;->s:Lah1;

    .line 2
    .line 3
    if-eqz v0, :cond_7

    .line 4
    .line 5
    invoke-virtual {v0}, Lq7;->c()V

    .line 6
    .line 7
    .line 8
    :cond_7
    iget-object v0, p0, Lba0;->L:Lpa0;

    .line 9
    .line 10
    const/4 v1, 0x1

    .line 11
    if-eqz v0, :cond_f

    .line 12
    .line 13
    invoke-virtual {v0, v1}, Lpa0;->i(Z)V

    .line 14
    .line 15
    .line 16
    :cond_f
    iput-boolean v1, p0, Lba0;->U:Z

    .line 17
    .line 18
    iget-object v0, p0, Lba0;->J:Lem0;

    .line 19
    .line 20
    iget-object v0, v0, Lem0;->e:Lha1;

    .line 21
    .line 22
    move-object v1, v0

    .line 23
    :goto_16
    if-eqz v1, :cond_22

    .line 24
    .line 25
    iget-boolean v2, v1, Lli0;->r:Z

    .line 26
    .line 27
    if-eqz v2, :cond_1f

    .line 28
    .line 29
    invoke-virtual {v1}, Lli0;->m0()V

    .line 30
    .line 31
    .line 32
    :cond_1f
    iget-object v1, v1, Lli0;->i:Lli0;

    .line 33
    .line 34
    goto :goto_16

    .line 35
    :cond_22
    move-object v1, v0

    .line 36
    :goto_23
    if-eqz v1, :cond_2f

    .line 37
    .line 38
    iget-boolean v2, v1, Lli0;->r:Z

    .line 39
    .line 40
    if-eqz v2, :cond_2c

    .line 41
    .line 42
    invoke-virtual {v1}, Lli0;->o0()V

    .line 43
    .line 44
    .line 45
    :cond_2c
    iget-object v1, v1, Lli0;->i:Lli0;

    .line 46
    .line 47
    goto :goto_23

    .line 48
    :cond_2f
    :goto_2f
    if-eqz v0, :cond_3b

    .line 49
    .line 50
    iget-boolean v1, v0, Lli0;->r:Z

    .line 51
    .line 52
    if-eqz v1, :cond_38

    .line 53
    .line 54
    invoke-virtual {v0}, Lli0;->g0()V

    .line 55
    .line 56
    .line 57
    :cond_38
    iget-object v0, v0, Lli0;->i:Lli0;

    .line 58
    .line 59
    goto :goto_2f

    .line 60
    :cond_3b
    invoke-virtual {p0}, Lba0;->H()Z

    .line 61
    .line 62
    .line 63
    move-result v0

    .line 64
    const/4 v1, 0x0

    .line 65
    if-eqz v0, :cond_47

    .line 66
    .line 67
    const/4 v0, 0x0

    .line 68
    iput-object v0, p0, Lba0;->w:Ld21;

    .line 69
    .line 70
    iput-boolean v1, p0, Lba0;->v:Z

    .line 71
    .line 72
    :cond_47
    iget-object v0, p0, Lba0;->r:Llp0;

    .line 73
    .line 74
    if-eqz v0, :cond_6a

    .line 75
    .line 76
    check-cast v0, Ln4;

    .line 77
    .line 78
    invoke-static {}, Ln4;->l()Z

    .line 79
    .line 80
    .line 81
    move-result v2

    .line 82
    if-eqz v2, :cond_6a

    .line 83
    .line 84
    iget-object v0, v0, Ln4;->S:Lr3;

    .line 85
    .line 86
    if-eqz v0, :cond_6a

    .line 87
    .line 88
    iget-object v2, v0, Lr3;->k:Ltj0;

    .line 89
    .line 90
    iget v3, p0, Lba0;->f:I

    .line 91
    .line 92
    invoke-virtual {v2, v3}, Ltj0;->e(I)Z

    .line 93
    .line 94
    .line 95
    move-result v2

    .line 96
    if-eqz v2, :cond_6a

    .line 97
    .line 98
    iget-object v2, v0, Lr3;->e:Lpg0;

    .line 99
    .line 100
    iget-object v0, v0, Lr3;->g:Ln4;

    .line 101
    .line 102
    iget p0, p0, Lba0;->f:I

    .line 103
    .line 104
    invoke-virtual {v2, v0, p0, v1}, Lpg0;->x(Landroid/view/View;IZ)V

    .line 105
    .line 106
    .line 107
    :cond_6a
    return-void
.end method

.method public final c0(Lmh0;)V
    .registers 3

    .line 1
    iget-object v0, p0, Lba0;->A:Lmh0;

    .line 2
    .line 3
    invoke-static {v0, p1}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-nez v0, :cond_18

    .line 8
    .line 9
    iput-object p1, p0, Lba0;->A:Lmh0;

    .line 10
    .line 11
    iget-object v0, p0, Lba0;->B:Lal;

    .line 12
    .line 13
    if-eqz v0, :cond_15

    .line 14
    .line 15
    iget-object v0, v0, Lal;->g:Ljava/lang/Object;

    .line 16
    .line 17
    check-cast v0, Llq0;

    .line 18
    .line 19
    invoke-virtual {v0, p1}, Llq0;->setValue(Ljava/lang/Object;)V

    .line 20
    .line 21
    .line 22
    :cond_15
    invoke-virtual {p0}, Lba0;->E()V

    .line 23
    .line 24
    .line 25
    :cond_18
    return-void
.end method

.method public final d(Llp0;)V
    .registers 10

    .line 1
    iget-object v0, p0, Lba0;->r:Llp0;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-nez v0, :cond_6

    .line 5
    .line 6
    goto :goto_23

    .line 7
    :cond_6
    new-instance v0, Ljava/lang/StringBuilder;

    .line 8
    .line 9
    const-string v2, "Cannot attach "

    .line 10
    .line 11
    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 15
    .line 16
    .line 17
    const-string v2, " as it already is attached.  Tree: "

    .line 18
    .line 19
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 20
    .line 21
    .line 22
    invoke-virtual {p0, v1}, Lba0;->g(I)Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object v2

    .line 26
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 27
    .line 28
    .line 29
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    invoke-static {v0}, Lp50;->b(Ljava/lang/String;)V

    .line 34
    .line 35
    .line 36
    :goto_23
    iget-object v0, p0, Lba0;->q:Lba0;

    .line 37
    .line 38
    const/4 v2, 0x0

    .line 39
    if-eqz v0, :cond_72

    .line 40
    .line 41
    iget-object v0, v0, Lba0;->r:Llp0;

    .line 42
    .line 43
    invoke-static {v0, p1}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 44
    .line 45
    .line 46
    move-result v0

    .line 47
    if-eqz v0, :cond_31

    .line 48
    .line 49
    goto :goto_72

    .line 50
    :cond_31
    new-instance v0, Ljava/lang/StringBuilder;

    .line 51
    .line 52
    const-string v3, "Attaching to a different owner("

    .line 53
    .line 54
    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 55
    .line 56
    .line 57
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 58
    .line 59
    .line 60
    const-string v3, ") than the parent\'s owner("

    .line 61
    .line 62
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 63
    .line 64
    .line 65
    invoke-virtual {p0}, Lba0;->v()Lba0;

    .line 66
    .line 67
    .line 68
    move-result-object v3

    .line 69
    if-eqz v3, :cond_49

    .line 70
    .line 71
    iget-object v3, v3, Lba0;->r:Llp0;

    .line 72
    .line 73
    goto :goto_4a

    .line 74
    :cond_49
    move-object v3, v2

    .line 75
    :goto_4a
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 76
    .line 77
    .line 78
    const-string v3, "). This tree: "

    .line 79
    .line 80
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 81
    .line 82
    .line 83
    invoke-virtual {p0, v1}, Lba0;->g(I)Ljava/lang/String;

    .line 84
    .line 85
    .line 86
    move-result-object v3

    .line 87
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 88
    .line 89
    .line 90
    const-string v3, " Parent tree: "

    .line 91
    .line 92
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 93
    .line 94
    .line 95
    iget-object v3, p0, Lba0;->q:Lba0;

    .line 96
    .line 97
    if-eqz v3, :cond_67

    .line 98
    .line 99
    invoke-virtual {v3, v1}, Lba0;->g(I)Ljava/lang/String;

    .line 100
    .line 101
    .line 102
    move-result-object v3

    .line 103
    goto :goto_68

    .line 104
    :cond_67
    move-object v3, v2

    .line 105
    :goto_68
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 106
    .line 107
    .line 108
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 109
    .line 110
    .line 111
    move-result-object v0

    .line 112
    invoke-static {v0}, Lp50;->b(Ljava/lang/String;)V

    .line 113
    .line 114
    .line 115
    :cond_72
    :goto_72
    invoke-virtual {p0}, Lba0;->v()Lba0;

    .line 116
    .line 117
    .line 118
    move-result-object v0

    .line 119
    iget-object v3, p0, Lba0;->K:Lfa0;

    .line 120
    .line 121
    const/4 v4, 0x1

    .line 122
    if-nez v0, :cond_91

    .line 123
    .line 124
    iget-object v5, v3, Lfa0;->p:Llh0;

    .line 125
    .line 126
    iput-boolean v4, v5, Llh0;->v:Z

    .line 127
    .line 128
    move-object v5, p1

    .line 129
    check-cast v5, Ln4;

    .line 130
    .line 131
    invoke-virtual {v5}, Ln4;->getRectManager()Liw0;

    .line 132
    .line 133
    .line 134
    move-result-object v5

    .line 135
    invoke-virtual {v5, p0}, Liw0;->f(Lba0;)V

    .line 136
    .line 137
    .line 138
    iget-object v5, v3, Lfa0;->q:Lhg0;

    .line 139
    .line 140
    if-eqz v5, :cond_91

    .line 141
    .line 142
    sget-object v6, Lfg0;->e:Lfg0;

    .line 143
    .line 144
    iput-object v6, v5, Lhg0;->t:Lfg0;

    .line 145
    .line 146
    :cond_91
    iget-object v5, p0, Lba0;->J:Lem0;

    .line 147
    .line 148
    iget-object v6, v5, Lem0;->d:Lgm0;

    .line 149
    .line 150
    if-eqz v0, :cond_9c

    .line 151
    .line 152
    iget-object v7, v0, Lba0;->J:Lem0;

    .line 153
    .line 154
    iget-object v7, v7, Lem0;->c:Lv50;

    .line 155
    .line 156
    goto :goto_9d

    .line 157
    :cond_9c
    move-object v7, v2

    .line 158
    :goto_9d
    iput-object v7, v6, Lgm0;->u:Lgm0;

    .line 159
    .line 160
    iput-object p1, p0, Lba0;->r:Llp0;

    .line 161
    .line 162
    if-eqz v0, :cond_a6

    .line 163
    .line 164
    iget v6, v0, Lba0;->t:I

    .line 165
    .line 166
    goto :goto_a7

    .line 167
    :cond_a6
    const/4 v6, -0x1

    .line 168
    :goto_a7
    add-int/2addr v6, v4

    .line 169
    iput v6, p0, Lba0;->t:I

    .line 170
    .line 171
    iget-object v6, p0, Lba0;->P:Lmi0;

    .line 172
    .line 173
    if-eqz v6, :cond_b1

    .line 174
    .line 175
    invoke-virtual {p0, v6}, Lba0;->b(Lmi0;)V

    .line 176
    .line 177
    .line 178
    :cond_b1
    iput-object v2, p0, Lba0;->P:Lmi0;

    .line 179
    .line 180
    move-object v2, p1

    .line 181
    check-cast v2, Ln4;

    .line 182
    .line 183
    invoke-virtual {v2}, Ln4;->getLayoutNodes()Lsj0;

    .line 184
    .line 185
    .line 186
    move-result-object v2

    .line 187
    iget v6, p0, Lba0;->f:I

    .line 188
    .line 189
    invoke-virtual {v2, v6, p0}, Lsj0;->h(ILjava/lang/Object;)V

    .line 190
    .line 191
    .line 192
    iget-object v2, p0, Lba0;->q:Lba0;

    .line 193
    .line 194
    if-eqz v2, :cond_c7

    .line 195
    .line 196
    iget-object v2, v2, Lba0;->l:Lba0;

    .line 197
    .line 198
    if-nez v2, :cond_c9

    .line 199
    .line 200
    :cond_c7
    iget-object v2, p0, Lba0;->l:Lba0;

    .line 201
    .line 202
    :cond_c9
    invoke-virtual {p0, v2}, Lba0;->b0(Lba0;)V

    .line 203
    .line 204
    .line 205
    iget-object v2, p0, Lba0;->l:Lba0;

    .line 206
    .line 207
    if-nez v2, :cond_db

    .line 208
    .line 209
    const/16 v2, 0x200

    .line 210
    .line 211
    invoke-virtual {v5, v2}, Lem0;->d(I)Z

    .line 212
    .line 213
    .line 214
    move-result v2

    .line 215
    if-eqz v2, :cond_db

    .line 216
    .line 217
    invoke-virtual {p0, p0}, Lba0;->b0(Lba0;)V

    .line 218
    .line 219
    .line 220
    :cond_db
    iget-boolean v2, p0, Lba0;->U:Z

    .line 221
    .line 222
    if-nez v2, :cond_e9

    .line 223
    .line 224
    iget-object v2, v5, Lem0;->f:Lli0;

    .line 225
    .line 226
    :goto_e1
    if-eqz v2, :cond_e9

    .line 227
    .line 228
    invoke-virtual {v2}, Lli0;->f0()V

    .line 229
    .line 230
    .line 231
    iget-object v2, v2, Lli0;->j:Lli0;

    .line 232
    .line 233
    goto :goto_e1

    .line 234
    :cond_e9
    iget-object v2, p0, Lba0;->n:Lal;

    .line 235
    .line 236
    iget-object v2, v2, Lal;->f:Ljava/lang/Object;

    .line 237
    .line 238
    check-cast v2, Lqk0;

    .line 239
    .line 240
    iget-object v6, v2, Lqk0;->e:[Ljava/lang/Object;

    .line 241
    .line 242
    iget v2, v2, Lqk0;->g:I

    .line 243
    .line 244
    :goto_f3
    if-ge v1, v2, :cond_ff

    .line 245
    .line 246
    aget-object v7, v6, v1

    .line 247
    .line 248
    check-cast v7, Lba0;

    .line 249
    .line 250
    invoke-virtual {v7, p1}, Lba0;->d(Llp0;)V

    .line 251
    .line 252
    .line 253
    add-int/lit8 v1, v1, 0x1

    .line 254
    .line 255
    goto :goto_f3

    .line 256
    :cond_ff
    iget-boolean v1, p0, Lba0;->U:Z

    .line 257
    .line 258
    if-nez v1, :cond_106

    .line 259
    .line 260
    invoke-virtual {v5}, Lem0;->e()V

    .line 261
    .line 262
    .line 263
    :cond_106
    invoke-virtual {p0}, Lba0;->E()V

    .line 264
    .line 265
    .line 266
    if-eqz v0, :cond_10e

    .line 267
    .line 268
    invoke-virtual {v0}, Lba0;->E()V

    .line 269
    .line 270
    .line 271
    :cond_10e
    iget-object v0, p0, Lba0;->Q:Lk7;

    .line 272
    .line 273
    if-eqz v0, :cond_115

    .line 274
    .line 275
    invoke-virtual {v0, p1}, Lk7;->i(Ljava/lang/Object;)Ljava/lang/Object;

    .line 276
    .line 277
    .line 278
    :cond_115
    invoke-virtual {v3}, Lfa0;->j()V

    .line 279
    .line 280
    .line 281
    iget-boolean v0, p0, Lba0;->U:Z

    .line 282
    .line 283
    if-nez v0, :cond_127

    .line 284
    .line 285
    const/16 v0, 0x8

    .line 286
    .line 287
    invoke-virtual {v5, v0}, Lem0;->d(I)Z

    .line 288
    .line 289
    .line 290
    move-result v0

    .line 291
    if-eqz v0, :cond_127

    .line 292
    .line 293
    invoke-virtual {p0}, Lba0;->F()V

    .line 294
    .line 295
    .line 296
    :cond_127
    check-cast p1, Ln4;

    .line 297
    .line 298
    invoke-static {}, Ln4;->l()Z

    .line 299
    .line 300
    .line 301
    move-result v0

    .line 302
    if-eqz v0, :cond_153

    .line 303
    .line 304
    iget-object p1, p1, Ln4;->S:Lr3;

    .line 305
    .line 306
    if-eqz p1, :cond_153

    .line 307
    .line 308
    invoke-virtual {p0}, Lba0;->x()Ld21;

    .line 309
    .line 310
    .line 311
    move-result-object v0

    .line 312
    if-eqz v0, :cond_153

    .line 313
    .line 314
    iget-object v0, v0, Ld21;->e:Lhk0;

    .line 315
    .line 316
    sget-object v1, Ln21;->r:Lq21;

    .line 317
    .line 318
    invoke-virtual {v0, v1}, Lhk0;->b(Ljava/lang/Object;)Z

    .line 319
    .line 320
    .line 321
    move-result v0

    .line 322
    if-ne v0, v4, :cond_153

    .line 323
    .line 324
    iget-object v0, p1, Lr3;->k:Ltj0;

    .line 325
    .line 326
    iget v1, p0, Lba0;->f:I

    .line 327
    .line 328
    invoke-virtual {v0, v1}, Ltj0;->a(I)Z

    .line 329
    .line 330
    .line 331
    iget-object v0, p1, Lr3;->e:Lpg0;

    .line 332
    .line 333
    iget-object p1, p1, Lr3;->g:Ln4;

    .line 334
    .line 335
    iget p0, p0, Lba0;->f:I

    .line 336
    .line 337
    invoke-virtual {v0, p1, p0, v4}, Lpg0;->x(Landroid/view/View;IZ)V

    .line 338
    .line 339
    .line 340
    :cond_153
    return-void
.end method

.method public final d0(Lmi0;)V
    .registers 4

    .line 1
    iget-boolean v0, p0, Lba0;->e:Z

    .line 2
    .line 3
    if-eqz v0, :cond_10

    .line 4
    .line 5
    iget-object v0, p0, Lba0;->O:Lmi0;

    .line 6
    .line 7
    sget-object v1, Lji0;->a:Lji0;

    .line 8
    .line 9
    if-ne v0, v1, :cond_b

    .line 10
    .line 11
    goto :goto_10

    .line 12
    :cond_b
    const-string v0, "Modifiers are not supported on virtual LayoutNodes"

    .line 13
    .line 14
    invoke-static {v0}, Lp50;->a(Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    :cond_10
    :goto_10
    iget-boolean v0, p0, Lba0;->U:Z

    .line 18
    .line 19
    if-eqz v0, :cond_19

    .line 20
    .line 21
    const-string v0, "modifier is updated when deactivated"

    .line 22
    .line 23
    invoke-static {v0}, Lp50;->a(Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    :cond_19
    invoke-virtual {p0}, Lba0;->H()Z

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    if-eqz v0, :cond_2a

    .line 31
    .line 32
    invoke-virtual {p0, p1}, Lba0;->b(Lmi0;)V

    .line 33
    .line 34
    .line 35
    iget-boolean p1, p0, Lba0;->v:Z

    .line 36
    .line 37
    if-eqz p1, :cond_29

    .line 38
    .line 39
    invoke-virtual {p0}, Lba0;->F()V

    .line 40
    .line 41
    .line 42
    :cond_29
    return-void

    .line 43
    :cond_2a
    iput-object p1, p0, Lba0;->P:Lmi0;

    .line 44
    .line 45
    return-void
.end method

.method public final e()V
    .registers 6

    .line 1
    iget-object v0, p0, Lba0;->G:Lz90;

    .line 2
    .line 3
    iput-object v0, p0, Lba0;->H:Lz90;

    .line 4
    .line 5
    sget-object v0, Lz90;->g:Lz90;

    .line 6
    .line 7
    iput-object v0, p0, Lba0;->G:Lz90;

    .line 8
    .line 9
    invoke-virtual {p0}, Lba0;->z()Lqk0;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    iget-object v1, p0, Lqk0;->e:[Ljava/lang/Object;

    .line 14
    .line 15
    iget p0, p0, Lqk0;->g:I

    .line 16
    .line 17
    const/4 v2, 0x0

    .line 18
    :goto_11
    if-ge v2, p0, :cond_21

    .line 19
    .line 20
    aget-object v3, v1, v2

    .line 21
    .line 22
    check-cast v3, Lba0;

    .line 23
    .line 24
    iget-object v4, v3, Lba0;->G:Lz90;

    .line 25
    .line 26
    if-eq v4, v0, :cond_1e

    .line 27
    .line 28
    invoke-virtual {v3}, Lba0;->e()V

    .line 29
    .line 30
    .line 31
    :cond_1e
    add-int/lit8 v2, v2, 0x1

    .line 32
    .line 33
    goto :goto_11

    .line 34
    :cond_21
    return-void
.end method

.method public final e0(Lyg1;)V
    .registers 9

    .line 1
    iget-object v0, p0, Lba0;->E:Lyg1;

    .line 2
    .line 3
    invoke-static {v0, p1}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-nez v0, :cond_6d

    .line 8
    .line 9
    iput-object p1, p0, Lba0;->E:Lyg1;

    .line 10
    .line 11
    iget-object p0, p0, Lba0;->J:Lem0;

    .line 12
    .line 13
    iget-object p0, p0, Lem0;->f:Lli0;

    .line 14
    .line 15
    iget p1, p0, Lli0;->h:I

    .line 16
    .line 17
    const/16 v0, 0x10

    .line 18
    .line 19
    and-int/2addr p1, v0

    .line 20
    if-eqz p1, :cond_6d

    .line 21
    .line 22
    :goto_15
    if-eqz p0, :cond_6d

    .line 23
    .line 24
    iget p1, p0, Lli0;->g:I

    .line 25
    .line 26
    and-int/2addr p1, v0

    .line 27
    if-eqz p1, :cond_65

    .line 28
    .line 29
    const/4 p1, 0x0

    .line 30
    move-object v1, p0

    .line 31
    move-object v2, p1

    .line 32
    :goto_1f
    if-eqz v1, :cond_65

    .line 33
    .line 34
    instance-of v3, v1, Lgt0;

    .line 35
    .line 36
    if-eqz v3, :cond_2b

    .line 37
    .line 38
    check-cast v1, Lgt0;

    .line 39
    .line 40
    invoke-interface {v1}, Lgt0;->L()V

    .line 41
    .line 42
    .line 43
    goto :goto_60

    .line 44
    :cond_2b
    iget v3, v1, Lli0;->g:I

    .line 45
    .line 46
    and-int/2addr v3, v0

    .line 47
    if-eqz v3, :cond_60

    .line 48
    .line 49
    instance-of v3, v1, Ldp;

    .line 50
    .line 51
    if-eqz v3, :cond_60

    .line 52
    .line 53
    move-object v3, v1

    .line 54
    check-cast v3, Ldp;

    .line 55
    .line 56
    iget-object v3, v3, Ldp;->t:Lli0;

    .line 57
    .line 58
    const/4 v4, 0x0

    .line 59
    :goto_3a
    const/4 v5, 0x1

    .line 60
    if-eqz v3, :cond_5d

    .line 61
    .line 62
    iget v6, v3, Lli0;->g:I

    .line 63
    .line 64
    and-int/2addr v6, v0

    .line 65
    if-eqz v6, :cond_5a

    .line 66
    .line 67
    add-int/lit8 v4, v4, 0x1

    .line 68
    .line 69
    if-ne v4, v5, :cond_48

    .line 70
    .line 71
    move-object v1, v3

    .line 72
    goto :goto_5a

    .line 73
    :cond_48
    if-nez v2, :cond_51

    .line 74
    .line 75
    new-instance v2, Lqk0;

    .line 76
    .line 77
    new-array v5, v0, [Lli0;

    .line 78
    .line 79
    invoke-direct {v2, v5}, Lqk0;-><init>([Ljava/lang/Object;)V

    .line 80
    .line 81
    .line 82
    :cond_51
    if-eqz v1, :cond_57

    .line 83
    .line 84
    invoke-virtual {v2, v1}, Lqk0;->b(Ljava/lang/Object;)V

    .line 85
    .line 86
    .line 87
    move-object v1, p1

    .line 88
    :cond_57
    invoke-virtual {v2, v3}, Lqk0;->b(Ljava/lang/Object;)V

    .line 89
    .line 90
    .line 91
    :cond_5a
    :goto_5a
    iget-object v3, v3, Lli0;->j:Lli0;

    .line 92
    .line 93
    goto :goto_3a

    .line 94
    :cond_5d
    if-ne v4, v5, :cond_60

    .line 95
    .line 96
    goto :goto_1f

    .line 97
    :cond_60
    :goto_60
    invoke-static {v2}, Lk70;->m(Lqk0;)Lli0;

    .line 98
    .line 99
    .line 100
    move-result-object v1

    .line 101
    goto :goto_1f

    .line 102
    :cond_65
    iget p1, p0, Lli0;->h:I

    .line 103
    .line 104
    and-int/2addr p1, v0

    .line 105
    if-eqz p1, :cond_6d

    .line 106
    .line 107
    iget-object p0, p0, Lli0;->j:Lli0;

    .line 108
    .line 109
    goto :goto_15

    .line 110
    :cond_6d
    return-void
.end method

.method public final f()V
    .registers 6

    .line 1
    iget-object v0, p0, Lba0;->G:Lz90;

    .line 2
    .line 3
    iput-object v0, p0, Lba0;->H:Lz90;

    .line 4
    .line 5
    sget-object v0, Lz90;->g:Lz90;

    .line 6
    .line 7
    iput-object v0, p0, Lba0;->G:Lz90;

    .line 8
    .line 9
    invoke-virtual {p0}, Lba0;->z()Lqk0;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    iget-object v0, p0, Lqk0;->e:[Ljava/lang/Object;

    .line 14
    .line 15
    iget p0, p0, Lqk0;->g:I

    .line 16
    .line 17
    const/4 v1, 0x0

    .line 18
    :goto_11
    if-ge v1, p0, :cond_23

    .line 19
    .line 20
    aget-object v2, v0, v1

    .line 21
    .line 22
    check-cast v2, Lba0;

    .line 23
    .line 24
    iget-object v3, v2, Lba0;->G:Lz90;

    .line 25
    .line 26
    sget-object v4, Lz90;->f:Lz90;

    .line 27
    .line 28
    if-ne v3, v4, :cond_20

    .line 29
    .line 30
    invoke-virtual {v2}, Lba0;->f()V

    .line 31
    .line 32
    .line 33
    :cond_20
    add-int/lit8 v1, v1, 0x1

    .line 34
    .line 35
    goto :goto_11

    .line 36
    :cond_23
    return-void
.end method

.method public final f0()V
    .registers 7

    .line 1
    iget v0, p0, Lba0;->m:I

    .line 2
    .line 3
    if-lez v0, :cond_4e

    .line 4
    .line 5
    iget-boolean v0, p0, Lba0;->p:Z

    .line 6
    .line 7
    if-eqz v0, :cond_4e

    .line 8
    .line 9
    const/4 v0, 0x0

    .line 10
    iput-boolean v0, p0, Lba0;->p:Z

    .line 11
    .line 12
    iget-object v1, p0, Lba0;->o:Lqk0;

    .line 13
    .line 14
    if-nez v1, :cond_1a

    .line 15
    .line 16
    new-instance v1, Lqk0;

    .line 17
    .line 18
    const/16 v2, 0x10

    .line 19
    .line 20
    new-array v2, v2, [Lba0;

    .line 21
    .line 22
    invoke-direct {v1, v2}, Lqk0;-><init>([Ljava/lang/Object;)V

    .line 23
    .line 24
    .line 25
    iput-object v1, p0, Lba0;->o:Lqk0;

    .line 26
    .line 27
    :cond_1a
    invoke-virtual {v1}, Lqk0;->g()V

    .line 28
    .line 29
    .line 30
    iget-object v2, p0, Lba0;->n:Lal;

    .line 31
    .line 32
    iget-object v2, v2, Lal;->f:Ljava/lang/Object;

    .line 33
    .line 34
    check-cast v2, Lqk0;

    .line 35
    .line 36
    iget-object v3, v2, Lqk0;->e:[Ljava/lang/Object;

    .line 37
    .line 38
    iget v2, v2, Lqk0;->g:I

    .line 39
    .line 40
    :goto_27
    if-ge v0, v2, :cond_41

    .line 41
    .line 42
    aget-object v4, v3, v0

    .line 43
    .line 44
    check-cast v4, Lba0;

    .line 45
    .line 46
    iget-boolean v5, v4, Lba0;->e:Z

    .line 47
    .line 48
    if-eqz v5, :cond_3b

    .line 49
    .line 50
    invoke-virtual {v4}, Lba0;->z()Lqk0;

    .line 51
    .line 52
    .line 53
    move-result-object v4

    .line 54
    iget v5, v1, Lqk0;->g:I

    .line 55
    .line 56
    invoke-virtual {v1, v5, v4}, Lqk0;->c(ILqk0;)V

    .line 57
    .line 58
    .line 59
    goto :goto_3e

    .line 60
    :cond_3b
    invoke-virtual {v1, v4}, Lqk0;->b(Ljava/lang/Object;)V

    .line 61
    .line 62
    .line 63
    :goto_3e
    add-int/lit8 v0, v0, 0x1

    .line 64
    .line 65
    goto :goto_27

    .line 66
    :cond_41
    iget-object p0, p0, Lba0;->K:Lfa0;

    .line 67
    .line 68
    iget-object v0, p0, Lfa0;->p:Llh0;

    .line 69
    .line 70
    const/4 v1, 0x1

    .line 71
    iput-boolean v1, v0, Llh0;->C:Z

    .line 72
    .line 73
    iget-object p0, p0, Lfa0;->q:Lhg0;

    .line 74
    .line 75
    if-eqz p0, :cond_4e

    .line 76
    .line 77
    iput-boolean v1, p0, Lhg0;->w:Z

    .line 78
    .line 79
    :cond_4e
    return-void
.end method

.method public final g(I)Ljava/lang/String;
    .registers 8

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 4
    .line 5
    .line 6
    const/4 v1, 0x0

    .line 7
    move v2, v1

    .line 8
    :goto_7
    if-ge v2, p1, :cond_11

    .line 9
    .line 10
    const-string v3, "  "

    .line 11
    .line 12
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 13
    .line 14
    .line 15
    add-int/lit8 v2, v2, 0x1

    .line 16
    .line 17
    goto :goto_7

    .line 18
    :cond_11
    const-string v2, "|-"

    .line 19
    .line 20
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 21
    .line 22
    .line 23
    invoke-virtual {p0}, Lba0;->toString()Ljava/lang/String;

    .line 24
    .line 25
    .line 26
    move-result-object v2

    .line 27
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 28
    .line 29
    .line 30
    const/16 v2, 0xa

    .line 31
    .line 32
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 33
    .line 34
    .line 35
    invoke-virtual {p0}, Lba0;->z()Lqk0;

    .line 36
    .line 37
    .line 38
    move-result-object p0

    .line 39
    iget-object v2, p0, Lqk0;->e:[Ljava/lang/Object;

    .line 40
    .line 41
    iget p0, p0, Lqk0;->g:I

    .line 42
    .line 43
    move v3, v1

    .line 44
    :goto_2b
    if-ge v3, p0, :cond_3d

    .line 45
    .line 46
    aget-object v4, v2, v3

    .line 47
    .line 48
    check-cast v4, Lba0;

    .line 49
    .line 50
    add-int/lit8 v5, p1, 0x1

    .line 51
    .line 52
    invoke-virtual {v4, v5}, Lba0;->g(I)Ljava/lang/String;

    .line 53
    .line 54
    .line 55
    move-result-object v4

    .line 56
    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 57
    .line 58
    .line 59
    add-int/lit8 v3, v3, 0x1

    .line 60
    .line 61
    goto :goto_2b

    .line 62
    :cond_3d
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 63
    .line 64
    .line 65
    move-result-object p0

    .line 66
    if-nez p1, :cond_4d

    .line 67
    .line 68
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 69
    .line 70
    .line 71
    move-result p1

    .line 72
    add-int/lit8 p1, p1, -0x1

    .line 73
    .line 74
    invoke-virtual {p0, v1, p1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 75
    .line 76
    .line 77
    move-result-object p0

    .line 78
    :cond_4d
    return-object p0
.end method

.method public final h()V
    .registers 12

    .line 1
    iget-object v0, p0, Lba0;->r:Llp0;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x0

    .line 5
    if-nez v0, :cond_27

    .line 6
    .line 7
    new-instance v0, Ljava/lang/StringBuilder;

    .line 8
    .line 9
    const-string v3, "Cannot detach node that is already detached!  Tree: "

    .line 10
    .line 11
    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    invoke-virtual {p0}, Lba0;->v()Lba0;

    .line 15
    .line 16
    .line 17
    move-result-object p0

    .line 18
    if-eqz p0, :cond_17

    .line 19
    .line 20
    invoke-virtual {p0, v2}, Lba0;->g(I)Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    :cond_17
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 25
    .line 26
    .line 27
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    invoke-static {p0}, Lp50;->c(Ljava/lang/String;)Ljava/lang/Void;

    .line 32
    .line 33
    .line 34
    new-instance p0, Lyh;

    .line 35
    .line 36
    invoke-direct {p0}, Ljava/lang/RuntimeException;-><init>()V

    .line 37
    .line 38
    .line 39
    throw p0

    .line 40
    :cond_27
    invoke-virtual {p0}, Lba0;->v()Lba0;

    .line 41
    .line 42
    .line 43
    move-result-object v3

    .line 44
    iget-object v4, p0, Lba0;->K:Lfa0;

    .line 45
    .line 46
    if-eqz v3, :cond_41

    .line 47
    .line 48
    invoke-virtual {v3}, Lba0;->C()V

    .line 49
    .line 50
    .line 51
    invoke-virtual {v3}, Lba0;->E()V

    .line 52
    .line 53
    .line 54
    iget-object v3, v4, Lfa0;->p:Llh0;

    .line 55
    .line 56
    sget-object v5, Lz90;->g:Lz90;

    .line 57
    .line 58
    iput-object v5, v3, Llh0;->p:Lz90;

    .line 59
    .line 60
    iget-object v3, v4, Lfa0;->q:Lhg0;

    .line 61
    .line 62
    if-eqz v3, :cond_41

    .line 63
    .line 64
    iput-object v5, v3, Lhg0;->n:Lz90;

    .line 65
    .line 66
    :cond_41
    iget-object v3, v4, Lfa0;->p:Llh0;

    .line 67
    .line 68
    iget-object v3, v3, Llh0;->A:Lca0;

    .line 69
    .line 70
    const/4 v5, 0x1

    .line 71
    iput-boolean v5, v3, Lca0;->b:Z

    .line 72
    .line 73
    iput-boolean v2, v3, Lca0;->c:Z

    .line 74
    .line 75
    iput-boolean v2, v3, Lca0;->d:Z

    .line 76
    .line 77
    iput-boolean v2, v3, Lca0;->e:Z

    .line 78
    .line 79
    iput-object v1, v3, Lca0;->f:Lk3;

    .line 80
    .line 81
    iget-object v3, v4, Lfa0;->q:Lhg0;

    .line 82
    .line 83
    if-eqz v3, :cond_62

    .line 84
    .line 85
    iget-object v3, v3, Lhg0;->u:Lca0;

    .line 86
    .line 87
    if-eqz v3, :cond_62

    .line 88
    .line 89
    iput-boolean v5, v3, Lca0;->b:Z

    .line 90
    .line 91
    iput-boolean v2, v3, Lca0;->c:Z

    .line 92
    .line 93
    iput-boolean v2, v3, Lca0;->d:Z

    .line 94
    .line 95
    iput-boolean v2, v3, Lca0;->e:Z

    .line 96
    .line 97
    iput-object v1, v3, Lca0;->f:Lk3;

    .line 98
    .line 99
    :cond_62
    iget-object v3, p0, Lba0;->J:Lem0;

    .line 100
    .line 101
    iget-object v6, v3, Lem0;->d:Lgm0;

    .line 102
    .line 103
    iget-object v7, v3, Lem0;->e:Lha1;

    .line 104
    .line 105
    iget-object v8, v3, Lem0;->c:Lv50;

    .line 106
    .line 107
    iget-object v8, v8, Lgm0;->t:Lgm0;

    .line 108
    .line 109
    :goto_6c
    invoke-static {v6, v8}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 110
    .line 111
    .line 112
    move-result v9

    .line 113
    if-nez v9, :cond_85

    .line 114
    .line 115
    if-eqz v6, :cond_85

    .line 116
    .line 117
    invoke-virtual {v6}, Lgm0;->Q0()V

    .line 118
    .line 119
    .line 120
    iget-object v9, v6, Lgm0;->s:Lba0;

    .line 121
    .line 122
    invoke-virtual {v9}, Lba0;->I()Z

    .line 123
    .line 124
    .line 125
    move-result v9

    .line 126
    if-eqz v9, :cond_82

    .line 127
    .line 128
    invoke-virtual {v6}, Lgm0;->L0()V

    .line 129
    .line 130
    .line 131
    :cond_82
    iget-object v6, v6, Lgm0;->t:Lgm0;

    .line 132
    .line 133
    goto :goto_6c

    .line 134
    :cond_85
    iget-object v6, p0, Lba0;->R:Ll7;

    .line 135
    .line 136
    if-eqz v6, :cond_8c

    .line 137
    .line 138
    invoke-virtual {v6, v0}, Ll7;->i(Ljava/lang/Object;)Ljava/lang/Object;

    .line 139
    .line 140
    .line 141
    :cond_8c
    move-object v6, v7

    .line 142
    :goto_8d
    if-eqz v6, :cond_99

    .line 143
    .line 144
    iget-boolean v8, v6, Lli0;->r:Z

    .line 145
    .line 146
    if-eqz v8, :cond_96

    .line 147
    .line 148
    invoke-virtual {v6}, Lli0;->o0()V

    .line 149
    .line 150
    .line 151
    :cond_96
    iget-object v6, v6, Lli0;->i:Lli0;

    .line 152
    .line 153
    goto :goto_8d

    .line 154
    :cond_99
    iput-boolean v5, p0, Lba0;->u:Z

    .line 155
    .line 156
    iget-object v6, p0, Lba0;->n:Lal;

    .line 157
    .line 158
    iget-object v6, v6, Lal;->f:Ljava/lang/Object;

    .line 159
    .line 160
    check-cast v6, Lqk0;

    .line 161
    .line 162
    iget-object v8, v6, Lqk0;->e:[Ljava/lang/Object;

    .line 163
    .line 164
    iget v6, v6, Lqk0;->g:I

    .line 165
    .line 166
    move v9, v2

    .line 167
    :goto_a6
    if-ge v9, v6, :cond_b2

    .line 168
    .line 169
    aget-object v10, v8, v9

    .line 170
    .line 171
    check-cast v10, Lba0;

    .line 172
    .line 173
    invoke-virtual {v10}, Lba0;->h()V

    .line 174
    .line 175
    .line 176
    add-int/lit8 v9, v9, 0x1

    .line 177
    .line 178
    goto :goto_a6

    .line 179
    :cond_b2
    iput-boolean v2, p0, Lba0;->u:Z

    .line 180
    .line 181
    :goto_b4
    if-eqz v7, :cond_c0

    .line 182
    .line 183
    iget-boolean v6, v7, Lli0;->r:Z

    .line 184
    .line 185
    if-eqz v6, :cond_bd

    .line 186
    .line 187
    invoke-virtual {v7}, Lli0;->g0()V

    .line 188
    .line 189
    .line 190
    :cond_bd
    iget-object v7, v7, Lli0;->i:Lli0;

    .line 191
    .line 192
    goto :goto_b4

    .line 193
    :cond_c0
    check-cast v0, Ln4;

    .line 194
    .line 195
    invoke-virtual {v0}, Ln4;->getLayoutNodes()Lsj0;

    .line 196
    .line 197
    .line 198
    move-result-object v6

    .line 199
    iget v7, p0, Lba0;->f:I

    .line 200
    .line 201
    invoke-virtual {v6, v7}, Lsj0;->g(I)Ljava/lang/Object;

    .line 202
    .line 203
    .line 204
    iget-object v6, v0, Ln4;->e0:Ljh0;

    .line 205
    .line 206
    iget-object v7, v6, Ljh0;->b:Lk9;

    .line 207
    .line 208
    iget-object v8, v7, Lk9;->f:Ljava/lang/Object;

    .line 209
    .line 210
    check-cast v8, Lpg0;

    .line 211
    .line 212
    invoke-virtual {v8, p0}, Lpg0;->B(Lba0;)Z

    .line 213
    .line 214
    .line 215
    iget-object v8, v7, Lk9;->g:Ljava/lang/Object;

    .line 216
    .line 217
    check-cast v8, Lpg0;

    .line 218
    .line 219
    invoke-virtual {v8, p0}, Lpg0;->B(Lba0;)Z

    .line 220
    .line 221
    .line 222
    iget-object v7, v7, Lk9;->h:Ljava/lang/Object;

    .line 223
    .line 224
    check-cast v7, Lpg0;

    .line 225
    .line 226
    invoke-virtual {v7, p0}, Lpg0;->B(Lba0;)Z

    .line 227
    .line 228
    .line 229
    iget-object v6, v6, Ljh0;->e:Lal;

    .line 230
    .line 231
    iget-object v6, v6, Lal;->f:Ljava/lang/Object;

    .line 232
    .line 233
    check-cast v6, Lqk0;

    .line 234
    .line 235
    invoke-virtual {v6, p0}, Lqk0;->j(Ljava/lang/Object;)Z

    .line 236
    .line 237
    .line 238
    iput-boolean v5, v0, Ln4;->T:Z

    .line 239
    .line 240
    invoke-static {}, Ln4;->l()Z

    .line 241
    .line 242
    .line 243
    move-result v5

    .line 244
    if-eqz v5, :cond_10c

    .line 245
    .line 246
    iget-object v5, v0, Ln4;->S:Lr3;

    .line 247
    .line 248
    if-eqz v5, :cond_10c

    .line 249
    .line 250
    iget-object v6, v5, Lr3;->k:Ltj0;

    .line 251
    .line 252
    iget v7, p0, Lba0;->f:I

    .line 253
    .line 254
    invoke-virtual {v6, v7}, Ltj0;->e(I)Z

    .line 255
    .line 256
    .line 257
    move-result v6

    .line 258
    if-eqz v6, :cond_10c

    .line 259
    .line 260
    iget-object v6, v5, Lr3;->e:Lpg0;

    .line 261
    .line 262
    iget-object v5, v5, Lr3;->g:Ln4;

    .line 263
    .line 264
    iget v7, p0, Lba0;->f:I

    .line 265
    .line 266
    invoke-virtual {v6, v5, v7, v2}, Lpg0;->x(Landroid/view/View;IZ)V

    .line 267
    .line 268
    .line 269
    :cond_10c
    invoke-virtual {v0}, Ln4;->getRectManager()Liw0;

    .line 270
    .line 271
    .line 272
    move-result-object v5

    .line 273
    invoke-virtual {v5, p0}, Liw0;->g(Lba0;)V

    .line 274
    .line 275
    .line 276
    iput-object v1, p0, Lba0;->r:Llp0;

    .line 277
    .line 278
    invoke-virtual {p0, v1}, Lba0;->b0(Lba0;)V

    .line 279
    .line 280
    .line 281
    iput v2, p0, Lba0;->t:I

    .line 282
    .line 283
    iget-object v5, v4, Lfa0;->p:Llh0;

    .line 284
    .line 285
    const v6, 0x7fffffff

    .line 286
    .line 287
    .line 288
    iput v6, v5, Llh0;->m:I

    .line 289
    .line 290
    iput v6, v5, Llh0;->l:I

    .line 291
    .line 292
    iput-boolean v2, v5, Llh0;->v:Z

    .line 293
    .line 294
    iget-object v4, v4, Lfa0;->q:Lhg0;

    .line 295
    .line 296
    if-eqz v4, :cond_131

    .line 297
    .line 298
    iput v6, v4, Lhg0;->m:I

    .line 299
    .line 300
    iput v6, v4, Lhg0;->l:I

    .line 301
    .line 302
    sget-object v5, Lfg0;->g:Lfg0;

    .line 303
    .line 304
    iput-object v5, v4, Lhg0;->t:Lfg0;

    .line 305
    .line 306
    :cond_131
    const/16 v4, 0x8

    .line 307
    .line 308
    invoke-virtual {v3, v4}, Lem0;->d(I)Z

    .line 309
    .line 310
    .line 311
    move-result v3

    .line 312
    if-eqz v3, :cond_149

    .line 313
    .line 314
    iget-object v3, p0, Lba0;->w:Ld21;

    .line 315
    .line 316
    iput-object v1, p0, Lba0;->w:Ld21;

    .line 317
    .line 318
    iput-boolean v2, p0, Lba0;->v:Z

    .line 319
    .line 320
    invoke-virtual {v0}, Ln4;->getSemanticsOwner()Ll21;

    .line 321
    .line 322
    .line 323
    move-result-object v1

    .line 324
    invoke-virtual {v1, p0, v3}, Ll21;->b(Lba0;Ld21;)V

    .line 325
    .line 326
    .line 327
    invoke-virtual {v0}, Ln4;->E()V

    .line 328
    .line 329
    .line 330
    :cond_149
    return-void
.end method

.method public final i(Lre;Li20;)V
    .registers 4

    .line 1
    :try_start_0
    iget-object v0, p0, Lba0;->J:Lem0;

    .line 2
    .line 3
    iget-object v0, v0, Lem0;->d:Lgm0;

    .line 4
    .line 5
    invoke-virtual {v0, p1, p2}, Lgm0;->r0(Lre;Li20;)V
    :try_end_7
    .catchall {:try_start_0 .. :try_end_7} :catchall_8

    .line 6
    .line 7
    .line 8
    return-void

    .line 9
    :catchall_8
    move-exception p1

    .line 10
    invoke-virtual {p0, p1}, Lba0;->Y(Ljava/lang/Throwable;)V

    .line 11
    .line 12
    .line 13
    const/4 p0, 0x0

    .line 14
    throw p0
.end method

.method public final k()V
    .registers 4

    .line 1
    iget-object v0, p0, Lba0;->l:Lba0;

    .line 2
    .line 3
    const/4 v1, 0x5

    .line 4
    const/4 v2, 0x0

    .line 5
    if-eqz v0, :cond_a

    .line 6
    .line 7
    invoke-static {p0, v2, v1}, Lba0;->T(Lba0;ZI)V

    .line 8
    .line 9
    .line 10
    goto :goto_d

    .line 11
    :cond_a
    invoke-static {p0, v2, v1}, Lba0;->V(Lba0;ZI)V

    .line 12
    .line 13
    .line 14
    :goto_d
    iget-object v0, p0, Lba0;->K:Lfa0;

    .line 15
    .line 16
    iget-object v0, v0, Lfa0;->p:Llh0;

    .line 17
    .line 18
    iget-boolean v1, v0, Llh0;->n:Z

    .line 19
    .line 20
    if-eqz v1, :cond_1d

    .line 21
    .line 22
    iget-wide v0, v0, Lks0;->h:J

    .line 23
    .line 24
    new-instance v2, Lsk;

    .line 25
    .line 26
    invoke-direct {v2, v0, v1}, Lsk;-><init>(J)V

    .line 27
    .line 28
    .line 29
    goto :goto_1e

    .line 30
    :cond_1d
    const/4 v2, 0x0

    .line 31
    :goto_1e
    iget-object v0, p0, Lba0;->r:Llp0;

    .line 32
    .line 33
    if-eqz v2, :cond_2c

    .line 34
    .line 35
    if-eqz v0, :cond_34

    .line 36
    .line 37
    iget-wide v1, v2, Lsk;->a:J

    .line 38
    .line 39
    check-cast v0, Ln4;

    .line 40
    .line 41
    invoke-virtual {v0, p0, v1, v2}, Ln4;->y(Lba0;J)V

    .line 42
    .line 43
    .line 44
    return-void

    .line 45
    :cond_2c
    if-eqz v0, :cond_34

    .line 46
    .line 47
    const/4 p0, 0x1

    .line 48
    check-cast v0, Ln4;

    .line 49
    .line 50
    invoke-virtual {v0, p0}, Ln4;->x(Z)V

    .line 51
    .line 52
    .line 53
    :cond_34
    return-void
.end method

.method public final l()Ljava/util/List;
    .registers 10

    .line 1
    iget-object p0, p0, Lba0;->K:Lfa0;

    .line 2
    .line 3
    iget-object p0, p0, Lfa0;->q:Lhg0;

    .line 4
    .line 5
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    .line 7
    .line 8
    iget-object v0, p0, Lhg0;->v:Lqk0;

    .line 9
    .line 10
    iget-object v1, p0, Lhg0;->j:Lfa0;

    .line 11
    .line 12
    iget-object v2, v1, Lfa0;->a:Lba0;

    .line 13
    .line 14
    invoke-virtual {v2}, Lba0;->n()Ljava/util/List;

    .line 15
    .line 16
    .line 17
    iget-boolean v2, p0, Lhg0;->w:Z

    .line 18
    .line 19
    if-nez v2, :cond_19

    .line 20
    .line 21
    invoke-virtual {v0}, Lqk0;->f()Ljava/util/List;

    .line 22
    .line 23
    .line 24
    move-result-object p0

    .line 25
    return-object p0

    .line 26
    :cond_19
    iget-object v1, v1, Lfa0;->a:Lba0;

    .line 27
    .line 28
    invoke-virtual {v1}, Lba0;->z()Lqk0;

    .line 29
    .line 30
    .line 31
    move-result-object v2

    .line 32
    iget-object v3, v2, Lqk0;->e:[Ljava/lang/Object;

    .line 33
    .line 34
    iget v2, v2, Lqk0;->g:I

    .line 35
    .line 36
    const/4 v4, 0x0

    .line 37
    move v5, v4

    .line 38
    :goto_25
    if-ge v5, v2, :cond_4a

    .line 39
    .line 40
    aget-object v6, v3, v5

    .line 41
    .line 42
    check-cast v6, Lba0;

    .line 43
    .line 44
    iget v7, v0, Lqk0;->g:I

    .line 45
    .line 46
    if-gt v7, v5, :cond_3a

    .line 47
    .line 48
    iget-object v6, v6, Lba0;->K:Lfa0;

    .line 49
    .line 50
    iget-object v6, v6, Lfa0;->q:Lhg0;

    .line 51
    .line 52
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 53
    .line 54
    .line 55
    invoke-virtual {v0, v6}, Lqk0;->b(Ljava/lang/Object;)V

    .line 56
    .line 57
    .line 58
    goto :goto_47

    .line 59
    :cond_3a
    iget-object v6, v6, Lba0;->K:Lfa0;

    .line 60
    .line 61
    iget-object v6, v6, Lfa0;->q:Lhg0;

    .line 62
    .line 63
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 64
    .line 65
    .line 66
    iget-object v7, v0, Lqk0;->e:[Ljava/lang/Object;

    .line 67
    .line 68
    aget-object v8, v7, v5

    .line 69
    .line 70
    aput-object v6, v7, v5

    .line 71
    .line 72
    :goto_47
    add-int/lit8 v5, v5, 0x1

    .line 73
    .line 74
    goto :goto_25

    .line 75
    :cond_4a
    invoke-virtual {v1}, Lba0;->n()Ljava/util/List;

    .line 76
    .line 77
    .line 78
    move-result-object v1

    .line 79
    check-cast v1, Lnk0;

    .line 80
    .line 81
    iget-object v1, v1, Lnk0;->e:Lqk0;

    .line 82
    .line 83
    iget v1, v1, Lqk0;->g:I

    .line 84
    .line 85
    iget v2, v0, Lqk0;->g:I

    .line 86
    .line 87
    invoke-virtual {v0, v1, v2}, Lqk0;->l(II)V

    .line 88
    .line 89
    .line 90
    iput-boolean v4, p0, Lhg0;->w:Z

    .line 91
    .line 92
    invoke-virtual {v0}, Lqk0;->f()Ljava/util/List;

    .line 93
    .line 94
    .line 95
    move-result-object p0

    .line 96
    return-object p0
.end method

.method public final m()Ljava/util/List;
    .registers 1

    .line 1
    iget-object p0, p0, Lba0;->K:Lfa0;

    .line 2
    .line 3
    iget-object p0, p0, Lfa0;->p:Llh0;

    .line 4
    .line 5
    invoke-virtual {p0}, Llh0;->U()Ljava/util/List;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    return-object p0
.end method

.method public final n()Ljava/util/List;
    .registers 1

    .line 1
    invoke-virtual {p0}, Lba0;->z()Lqk0;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    invoke-virtual {p0}, Lqk0;->f()Ljava/util/List;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    return-object p0
.end method

.method public final o()Ljava/util/List;
    .registers 1

    .line 1
    iget-object p0, p0, Lba0;->n:Lal;

    .line 2
    .line 3
    iget-object p0, p0, Lal;->f:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast p0, Lqk0;

    .line 6
    .line 7
    invoke-virtual {p0}, Lqk0;->f()Ljava/util/List;

    .line 8
    .line 9
    .line 10
    move-result-object p0

    .line 11
    return-object p0
.end method

.method public final p()Z
    .registers 1

    .line 1
    iget-object p0, p0, Lba0;->K:Lfa0;

    .line 2
    .line 3
    iget-object p0, p0, Lfa0;->p:Llh0;

    .line 4
    .line 5
    iget-boolean p0, p0, Llh0;->y:Z

    .line 6
    .line 7
    return p0
.end method

.method public final q()Z
    .registers 1

    .line 1
    iget-object p0, p0, Lba0;->K:Lfa0;

    .line 2
    .line 3
    iget-object p0, p0, Lfa0;->p:Llh0;

    .line 4
    .line 5
    iget-boolean p0, p0, Llh0;->x:Z

    .line 6
    .line 7
    return p0
.end method

.method public final r()Z
    .registers 1

    .line 1
    invoke-virtual {p0}, Lba0;->H()Z

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    return p0
.end method

.method public final s()Lz90;
    .registers 1

    .line 1
    iget-object p0, p0, Lba0;->K:Lfa0;

    .line 2
    .line 3
    iget-object p0, p0, Lfa0;->p:Llh0;

    .line 4
    .line 5
    iget-object p0, p0, Llh0;->p:Lz90;

    .line 6
    .line 7
    return-object p0
.end method

.method public final t()Lz90;
    .registers 1

    .line 1
    iget-object p0, p0, Lba0;->K:Lfa0;

    .line 2
    .line 3
    iget-object p0, p0, Lfa0;->q:Lhg0;

    .line 4
    .line 5
    if-eqz p0, :cond_c

    .line 6
    .line 7
    iget-object p0, p0, Lhg0;->n:Lz90;

    .line 8
    .line 9
    if-nez p0, :cond_b

    .line 10
    .line 11
    goto :goto_c

    .line 12
    :cond_b
    return-object p0

    .line 13
    :cond_c
    :goto_c
    sget-object p0, Lz90;->g:Lz90;

    .line 14
    .line 15
    return-object p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-static {p0}, Lgh0;->S(Ljava/lang/Object;)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 11
    .line 12
    .line 13
    const-string v1, " children: "

    .line 14
    .line 15
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 16
    .line 17
    .line 18
    invoke-virtual {p0}, Lba0;->n()Ljava/util/List;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    check-cast v1, Lnk0;

    .line 23
    .line 24
    iget-object v1, v1, Lnk0;->e:Lqk0;

    .line 25
    .line 26
    iget v1, v1, Lqk0;->g:I

    .line 27
    .line 28
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 29
    .line 30
    .line 31
    const-string v1, " measurePolicy: "

    .line 32
    .line 33
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 34
    .line 35
    .line 36
    iget-object v1, p0, Lba0;->A:Lmh0;

    .line 37
    .line 38
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 39
    .line 40
    .line 41
    const-string v1, " deactivated: "

    .line 42
    .line 43
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 44
    .line 45
    .line 46
    iget-boolean p0, p0, Lba0;->U:Z

    .line 47
    .line 48
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 49
    .line 50
    .line 51
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object p0

    .line 55
    return-object p0
.end method

.method public final u()Lal;
    .registers 3

    .line 1
    iget-object v0, p0, Lba0;->B:Lal;

    .line 2
    .line 3
    if-nez v0, :cond_d

    .line 4
    .line 5
    new-instance v0, Lal;

    .line 6
    .line 7
    iget-object v1, p0, Lba0;->A:Lmh0;

    .line 8
    .line 9
    invoke-direct {v0, p0, v1}, Lal;-><init>(Lba0;Lmh0;)V

    .line 10
    .line 11
    .line 12
    iput-object v0, p0, Lba0;->B:Lal;

    .line 13
    .line 14
    :cond_d
    return-object v0
.end method

.method public final v()Lba0;
    .registers 3

    .line 1
    iget-object p0, p0, Lba0;->q:Lba0;

    .line 2
    .line 3
    :goto_2
    if-eqz p0, :cond_c

    .line 4
    .line 5
    iget-boolean v0, p0, Lba0;->e:Z

    .line 6
    .line 7
    const/4 v1, 0x1

    .line 8
    if-ne v0, v1, :cond_c

    .line 9
    .line 10
    iget-object p0, p0, Lba0;->q:Lba0;

    .line 11
    .line 12
    goto :goto_2

    .line 13
    :cond_c
    return-object p0
.end method

.method public final w()I
    .registers 1

    .line 1
    iget-object p0, p0, Lba0;->K:Lfa0;

    .line 2
    .line 3
    iget-object p0, p0, Lfa0;->p:Llh0;

    .line 4
    .line 5
    iget p0, p0, Llh0;->m:I

    .line 6
    .line 7
    return p0
.end method

.method public final x()Ld21;
    .registers 3

    .line 1
    invoke-virtual {p0}, Lba0;->H()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_18

    .line 6
    .line 7
    iget-boolean v0, p0, Lba0;->U:Z

    .line 8
    .line 9
    if-nez v0, :cond_18

    .line 10
    .line 11
    iget-object v0, p0, Lba0;->J:Lem0;

    .line 12
    .line 13
    const/16 v1, 0x8

    .line 14
    .line 15
    invoke-virtual {v0, v1}, Lem0;->d(I)Z

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    if-nez v0, :cond_15

    .line 20
    .line 21
    goto :goto_18

    .line 22
    :cond_15
    iget-object p0, p0, Lba0;->w:Ld21;

    .line 23
    .line 24
    return-object p0

    .line 25
    :cond_18
    :goto_18
    const/4 p0, 0x0

    .line 26
    return-object p0
.end method

.method public final y()Lqk0;
    .registers 6

    .line 1
    iget-boolean v0, p0, Lba0;->z:Z

    .line 2
    .line 3
    iget-object v1, p0, Lba0;->y:Lqk0;

    .line 4
    .line 5
    if-eqz v0, :cond_1e

    .line 6
    .line 7
    invoke-virtual {v1}, Lqk0;->g()V

    .line 8
    .line 9
    .line 10
    invoke-virtual {p0}, Lba0;->z()Lqk0;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    iget v2, v1, Lqk0;->g:I

    .line 15
    .line 16
    invoke-virtual {v1, v2, v0}, Lqk0;->c(ILqk0;)V

    .line 17
    .line 18
    .line 19
    iget-object v0, v1, Lqk0;->e:[Ljava/lang/Object;

    .line 20
    .line 21
    iget v2, v1, Lqk0;->g:I

    .line 22
    .line 23
    const/4 v3, 0x0

    .line 24
    sget-object v4, Lba0;->X:Lv6;

    .line 25
    .line 26
    invoke-static {v0, v3, v2, v4}, Ljava/util/Arrays;->sort([Ljava/lang/Object;IILjava/util/Comparator;)V

    .line 27
    .line 28
    .line 29
    iput-boolean v3, p0, Lba0;->z:Z

    .line 30
    .line 31
    :cond_1e
    return-object v1
.end method

.method public final z()Lqk0;
    .registers 2

    .line 1
    invoke-virtual {p0}, Lba0;->f0()V

    .line 2
    .line 3
    .line 4
    iget v0, p0, Lba0;->m:I

    .line 5
    .line 6
    if-nez v0, :cond_e

    .line 7
    .line 8
    iget-object p0, p0, Lba0;->n:Lal;

    .line 9
    .line 10
    iget-object p0, p0, Lal;->f:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast p0, Lqk0;

    .line 13
    .line 14
    return-object p0

    .line 15
    :cond_e
    iget-object p0, p0, Lba0;->o:Lqk0;

    .line 16
    .line 17
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 18
    .line 19
    .line 20
    return-object p0
.end method
