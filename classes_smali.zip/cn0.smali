.class public final synthetic Lcn0;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Landroid/window/OnBackInvokedCallback;


# instance fields
.field public final synthetic a:Lbn0;


# direct methods
.method public synthetic constructor <init>(Lbn0;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lcn0;->a:Lbn0;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onBackInvoked()V
    .registers 1

    .line 1
    iget-object p0, p0, Lcn0;->a:Lbn0;

    .line 2
    .line 3
    invoke-virtual {p0}, Lhl0;->a()V

    .line 4
    .line 5
    .line 6
    return-void
.end method
