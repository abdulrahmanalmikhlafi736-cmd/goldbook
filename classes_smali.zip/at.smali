.class public final Lat;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# instance fields
.field public final a:Ldt;

.field public volatile b:Lk9;

.field public volatile c:Lp3;


# direct methods
.method public constructor <init>(Ldt;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lat;->a:Ldt;

    .line 5
    .line 6
    return-void
.end method
