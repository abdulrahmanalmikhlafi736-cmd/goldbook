.class public final La60;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lz50;


# instance fields
.field public final a:Llq0;


# direct methods
.method public constructor <init>(I)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Ly50;

    .line 5
    .line 6
    invoke-direct {v0, p1}, Ly50;-><init>(I)V

    .line 7
    .line 8
    .line 9
    invoke-static {v0}, Lmc0;->t(Ljava/lang/Object;)Llq0;

    .line 10
    .line 11
    .line 12
    move-result-object p1

    .line 13
    iput-object p1, p0, La60;->a:Llq0;

    .line 14
    .line 15
    return-void
.end method
