.class public final Lek;
.super Lh90;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lm00;


# instance fields
.field public final synthetic f:I

.field public final synthetic g:Lm00;

.field public final synthetic h:Ljava/lang/Object;

.field public final synthetic i:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Llp0;Lnq0;Lm00;I)V
    .registers 5

    .line 1
    const/4 p4, 0x0

    .line 2
    iput p4, p0, Lek;->f:I

    .line 3
    .line 4
    iput-object p1, p0, Lek;->h:Ljava/lang/Object;

    .line 5
    .line 6
    iput-object p2, p0, Lek;->i:Ljava/lang/Object;

    .line 7
    .line 8
    iput-object p3, p0, Lek;->g:Lm00;

    .line 9
    .line 10
    const/4 p1, 0x2

    .line 11
    invoke-direct {p0, p1}, Lh90;-><init>(I)V

    .line 12
    .line 13
    .line 14
    return-void
.end method

.method public constructor <init>(Lpl1;Lmj;Lm00;)V
    .registers 5

    const/4 v0, 0x1

    iput v0, p0, Lek;->f:I

    .line 15
    iput-object p1, p0, Lek;->h:Ljava/lang/Object;

    iput-object p2, p0, Lek;->i:Ljava/lang/Object;

    iput-object p3, p0, Lek;->g:Lm00;

    const/4 p1, 0x2

    invoke-direct {p0, p1}, Lh90;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 12

    .line 1
    iget v0, p0, Lek;->f:I

    .line 2
    .line 3
    sget-object v1, Lwe1;->a:Lwe1;

    .line 4
    .line 5
    iget-object v2, p0, Lek;->g:Lm00;

    .line 6
    .line 7
    iget-object v3, p0, Lek;->i:Ljava/lang/Object;

    .line 8
    .line 9
    iget-object p0, p0, Lek;->h:Ljava/lang/Object;

    .line 10
    .line 11
    const/4 v4, 0x1

    .line 12
    packed-switch v0, :pswitch_data_7c

    .line 13
    .line 14
    .line 15
    check-cast p1, Ld10;

    .line 16
    .line 17
    check-cast p2, Ljava/lang/Number;

    .line 18
    .line 19
    invoke-virtual {p2}, Ljava/lang/Number;->intValue()I

    .line 20
    .line 21
    .line 22
    move-result p2

    .line 23
    check-cast p0, Lpl1;

    .line 24
    .line 25
    and-int/lit8 v0, p2, 0x3

    .line 26
    .line 27
    const/4 v5, 0x2

    .line 28
    const/4 v6, 0x0

    .line 29
    if-eq v0, v5, :cond_20

    .line 30
    .line 31
    move v0, v4

    .line 32
    goto :goto_21

    .line 33
    :cond_20
    move v0, v6

    .line 34
    :goto_21
    and-int/2addr p2, v4

    .line 35
    invoke-virtual {p1, p2, v0}, Ld10;->O(IZ)Z

    .line 36
    .line 37
    .line 38
    move-result p2

    .line 39
    if-eqz p2, :cond_65

    .line 40
    .line 41
    iget-object p2, p0, Lpl1;->e:Ln4;

    .line 42
    .line 43
    invoke-virtual {p1, p0}, Ld10;->h(Ljava/lang/Object;)Z

    .line 44
    .line 45
    .line 46
    move-result v0

    .line 47
    invoke-virtual {p1}, Ld10;->L()Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object v5

    .line 51
    const/4 v7, 0x0

    .line 52
    sget-object v8, Loj;->a:Lnq0;

    .line 53
    .line 54
    if-nez v0, :cond_39

    .line 55
    .line 56
    if-ne v5, v8, :cond_41

    .line 57
    .line 58
    :cond_39
    new-instance v5, Lol1;

    .line 59
    .line 60
    invoke-direct {v5, p0, v7, v6}, Lol1;-><init>(Lpl1;Lml;I)V

    .line 61
    .line 62
    .line 63
    invoke-virtual {p1, v5}, Ld10;->g0(Ljava/lang/Object;)V

    .line 64
    .line 65
    .line 66
    :cond_41
    check-cast v5, Lm00;

    .line 67
    .line 68
    invoke-static {v5, p1, p2}, Lj70;->j(Lm00;Ld10;Ljava/lang/Object;)V

    .line 69
    .line 70
    .line 71
    invoke-virtual {p1, p0}, Ld10;->h(Ljava/lang/Object;)Z

    .line 72
    .line 73
    .line 74
    move-result v0

    .line 75
    invoke-virtual {p1}, Ld10;->L()Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    move-result-object v5

    .line 79
    if-nez v0, :cond_52

    .line 80
    .line 81
    if-ne v5, v8, :cond_5a

    .line 82
    .line 83
    :cond_52
    new-instance v5, Lol1;

    .line 84
    .line 85
    invoke-direct {v5, p0, v7, v4}, Lol1;-><init>(Lpl1;Lml;I)V

    .line 86
    .line 87
    .line 88
    invoke-virtual {p1, v5}, Ld10;->g0(Ljava/lang/Object;)V

    .line 89
    .line 90
    .line 91
    :cond_5a
    check-cast v5, Lm00;

    .line 92
    .line 93
    invoke-static {v5, p1, p2}, Lj70;->j(Lm00;Ld10;Ljava/lang/Object;)V

    .line 94
    .line 95
    .line 96
    check-cast v3, Lmj;

    .line 97
    .line 98
    invoke-virtual {v3, p2, v2, p1, v6}, Lmj;->a(Ln4;Lm00;Ld10;I)V

    .line 99
    .line 100
    .line 101
    goto :goto_68

    .line 102
    :cond_65
    invoke-virtual {p1}, Ld10;->R()V

    .line 103
    .line 104
    .line 105
    :goto_68
    return-object v1

    .line 106
    :pswitch_69  #0x0
    check-cast p1, Ld10;

    .line 107
    .line 108
    check-cast p2, Ljava/lang/Number;

    .line 109
    .line 110
    invoke-virtual {p2}, Ljava/lang/Number;->intValue()I

    .line 111
    .line 112
    .line 113
    check-cast p0, Llp0;

    .line 114
    .line 115
    check-cast v3, Lnq0;

    .line 116
    .line 117
    invoke-static {v4}, Lwc0;->s(I)I

    .line 118
    .line 119
    .line 120
    move-result p2

    .line 121
    invoke-static {p0, v3, v2, p1, p2}, Lfk;->a(Llp0;Lnq0;Lm00;Ld10;I)V

    .line 122
    .line 123
    .line 124
    return-object v1

    .line 125
    :pswitch_data_7c
    .packed-switch 0x0
        :pswitch_69  #00000000
    .end packed-switch
.end method
