.class public final La7;
.super Lu91;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lm00;


# instance fields
.field public final synthetic i:I


# direct methods
.method public synthetic constructor <init>(ILml;I)V
    .registers 4

    .line 1
    iput p3, p0, La7;->i:I

    .line 2
    .line 3
    invoke-direct {p0, p1, p2}, Lu91;-><init>(ILml;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 1
    iget v0, p0, La7;->i:I

    .line 2
    .line 3
    sget-object v1, Lwe1;->a:Lwe1;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_24

    .line 6
    .line 7
    .line 8
    check-cast p1, Luw;

    .line 9
    .line 10
    check-cast p2, Lml;

    .line 11
    .line 12
    invoke-virtual {p0, p2, p1}, La7;->n(Lml;Ljava/lang/Object;)Lml;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    check-cast p0, La7;

    .line 17
    .line 18
    invoke-virtual {p0, v1}, La7;->p(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    return-object v1

    .line 22
    :pswitch_15  #0x0
    check-cast p1, Lbm;

    .line 23
    .line 24
    check-cast p2, Lml;

    .line 25
    .line 26
    invoke-virtual {p0, p2, p1}, La7;->n(Lml;Ljava/lang/Object;)Lml;

    .line 27
    .line 28
    .line 29
    move-result-object p0

    .line 30
    check-cast p0, La7;

    .line 31
    .line 32
    invoke-virtual {p0, v1}, La7;->p(Ljava/lang/Object;)Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    move-result-object p0

    .line 36
    return-object p0

    .line 37
    :pswitch_data_24
    .packed-switch 0x0
        :pswitch_15  #00000000
    .end packed-switch
.end method

.method public final n(Lml;Ljava/lang/Object;)Lml;
    .registers 4

    .line 1
    iget p0, p0, La7;->i:I

    .line 2
    .line 3
    packed-switch p0, :pswitch_data_16

    .line 4
    .line 5
    .line 6
    new-instance p0, La7;

    .line 7
    .line 8
    const/4 p2, 0x2

    .line 9
    const/4 v0, 0x1

    .line 10
    invoke-direct {p0, p2, p1, v0}, La7;-><init>(ILml;I)V

    .line 11
    .line 12
    .line 13
    return-object p0

    .line 14
    :pswitch_d  #0x0
    new-instance p0, La7;

    .line 15
    .line 16
    const/4 p2, 0x2

    .line 17
    const/4 v0, 0x0

    .line 18
    invoke-direct {p0, p2, p1, v0}, La7;-><init>(ILml;I)V

    .line 19
    .line 20
    .line 21
    return-object p0

    .line 22
    nop

    .line 23
    :pswitch_data_16
    .packed-switch 0x0
        :pswitch_d  #00000000
    .end packed-switch
.end method

.method public final p(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 1
    iget p0, p0, La7;->i:I

    .line 2
    .line 3
    packed-switch p0, :pswitch_data_14

    .line 4
    .line 5
    .line 6
    invoke-static {p1}, Lnb0;->t(Ljava/lang/Object;)V

    .line 7
    .line 8
    .line 9
    sget-object p0, Lwe1;->a:Lwe1;

    .line 10
    .line 11
    return-object p0

    .line 12
    :pswitch_b  #0x0
    invoke-static {p1}, Lnb0;->t(Ljava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    invoke-static {}, Landroid/view/Choreographer;->getInstance()Landroid/view/Choreographer;

    .line 16
    .line 17
    .line 18
    move-result-object p0

    .line 19
    return-object p0

    .line 20
    nop

    .line 21
    :pswitch_data_14
    .packed-switch 0x0
        :pswitch_b  #00000000
    .end packed-switch
.end method
