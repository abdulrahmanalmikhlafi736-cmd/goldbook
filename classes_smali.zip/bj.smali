.class public final Lbj;
.super Lnl;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# instance fields
.field public h:Ljava/lang/Object;

.field public i:Lr60;

.field public j:I

.field public k:I

.field public synthetic l:Ljava/lang/Object;

.field public final synthetic m:Lcj;

.field public n:I


# direct methods
.method public constructor <init>(Lcj;Lnl;)V
    .registers 3

    .line 1
    iput-object p1, p0, Lbj;->m:Lcj;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Lnl;-><init>(Lml;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final p(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 1
    iput-object p1, p0, Lbj;->l:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, Lbj;->n:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, Lbj;->n:I

    .line 9
    .line 10
    iget-object p1, p0, Lbj;->m:Lcj;

    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    invoke-static {p1, v0, v0, p0}, Lcj;->a(Lcj;Landroid/view/ScrollCaptureSession;Lr60;Lnl;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method
