.class public final Le50;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Landroid/view/GestureDetector$OnGestureListener;


# instance fields
.field public final synthetic a:Lf50;


# direct methods
.method public constructor <init>(Lf50;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Le50;->a:Lf50;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onDown(Landroid/view/MotionEvent;)Z
    .registers 2

    .line 1
    const/4 p0, 0x1

    .line 2
    return p0
.end method

.method public final onFling(Landroid/view/MotionEvent;Landroid/view/MotionEvent;FF)Z
    .registers 7

    .line 1
    iget-object p0, p0, Le50;->a:Lf50;

    .line 2
    .line 3
    iget-object p1, p0, Lf50;->a:Lj4;

    .line 4
    .line 5
    iget-boolean p2, p0, Lf50;->c:Z

    .line 6
    .line 7
    const/4 v0, 0x1

    .line 8
    if-eqz p2, :cond_a

    .line 9
    .line 10
    goto :goto_45

    .line 11
    :cond_a
    iget p0, p0, Lf50;->b:I

    .line 12
    .line 13
    const/4 p2, 0x0

    .line 14
    const/4 v1, 0x2

    .line 15
    if-ne p0, v0, :cond_2a

    .line 16
    .line 17
    invoke-static {p3}, Ljava/lang/Math;->abs(F)F

    .line 18
    .line 19
    .line 20
    move-result p0

    .line 21
    invoke-static {p4}, Ljava/lang/Math;->abs(F)F

    .line 22
    .line 23
    .line 24
    move-result p4

    .line 25
    cmpl-float p0, p0, p4

    .line 26
    .line 27
    if-lez p0, :cond_45

    .line 28
    .line 29
    cmpl-float p0, p3, p2

    .line 30
    .line 31
    if-lez p0, :cond_21

    .line 32
    .line 33
    move v1, v0

    .line 34
    :cond_21
    new-instance p0, Lux;

    .line 35
    .line 36
    invoke-direct {p0, v1}, Lux;-><init>(I)V

    .line 37
    .line 38
    .line 39
    invoke-virtual {p1, p0}, Lj4;->i(Ljava/lang/Object;)Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    return v0

    .line 43
    :cond_2a
    if-ne p0, v1, :cond_45

    .line 44
    .line 45
    invoke-static {p4}, Ljava/lang/Math;->abs(F)F

    .line 46
    .line 47
    .line 48
    move-result p0

    .line 49
    invoke-static {p3}, Ljava/lang/Math;->abs(F)F

    .line 50
    .line 51
    .line 52
    move-result p3

    .line 53
    cmpl-float p0, p0, p3

    .line 54
    .line 55
    if-lez p0, :cond_45

    .line 56
    .line 57
    cmpl-float p0, p4, p2

    .line 58
    .line 59
    if-lez p0, :cond_3d

    .line 60
    .line 61
    move v1, v0

    .line 62
    :cond_3d
    new-instance p0, Lux;

    .line 63
    .line 64
    invoke-direct {p0, v1}, Lux;-><init>(I)V

    .line 65
    .line 66
    .line 67
    invoke-virtual {p1, p0}, Lj4;->i(Ljava/lang/Object;)Ljava/lang/Object;

    .line 68
    .line 69
    .line 70
    :cond_45
    :goto_45
    return v0
.end method

.method public final onLongPress(Landroid/view/MotionEvent;)V
    .registers 2

    .line 1
    return-void
.end method

.method public final onScroll(Landroid/view/MotionEvent;Landroid/view/MotionEvent;FF)Z
    .registers 5

    .line 1
    const/4 p0, 0x1

    .line 2
    return p0
.end method

.method public final onShowPress(Landroid/view/MotionEvent;)V
    .registers 2

    .line 1
    return-void
.end method

.method public final onSingleTapUp(Landroid/view/MotionEvent;)Z
    .registers 2

    .line 1
    const/4 p0, 0x1

    .line 2
    return p0
.end method
