.class public abstract Lb21;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# static fields
.field public static final a:Lgk;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Lhp0;

    .line 2
    .line 3
    const/4 v1, 0x7

    .line 4
    invoke-direct {v0, v1}, Lhp0;-><init>(I)V

    .line 5
    .line 6
    .line 7
    new-instance v1, Lgk;

    .line 8
    .line 9
    invoke-direct {v1, v0}, Lgk;-><init>(Lxz;)V

    .line 10
    .line 11
    .line 12
    sput-object v1, Lb21;->a:Lgk;

    .line 13
    .line 14
    return-void
.end method
