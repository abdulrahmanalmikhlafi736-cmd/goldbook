.class public final synthetic Lb11;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lxz;


# instance fields
.field public final synthetic e:I

.field public final synthetic f:Lc11;


# direct methods
.method public synthetic constructor <init>(Lc11;I)V
    .registers 3

    .line 1
    iput p2, p0, Lb11;->e:I

    .line 2
    .line 3
    iput-object p1, p0, Lb11;->f:Lc11;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .registers 4

    .line 1
    iget v0, p0, Lb11;->e:I

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    const/4 v2, 0x0

    .line 5
    iget-object p0, p0, Lb11;->f:Lc11;

    .line 6
    .line 7
    packed-switch v0, :pswitch_data_4a

    .line 8
    .line 9
    .line 10
    iget-object v0, p0, Lc11;->e:Liq0;

    .line 11
    .line 12
    invoke-virtual {v0}, Liq0;->g()I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-eqz v0, :cond_21

    .line 17
    .line 18
    iget-object v0, p0, Lc11;->a:Liq0;

    .line 19
    .line 20
    invoke-virtual {v0}, Liq0;->g()I

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    iget-object p0, p0, Lc11;->e:Liq0;

    .line 25
    .line 26
    invoke-virtual {p0}, Liq0;->g()I

    .line 27
    .line 28
    .line 29
    move-result p0

    .line 30
    if-ge v0, p0, :cond_20

    .line 31
    .line 32
    goto :goto_21

    .line 33
    :cond_20
    move v1, v2

    .line 34
    :cond_21
    :goto_21
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 35
    .line 36
    .line 37
    move-result-object p0

    .line 38
    return-object p0

    .line 39
    :pswitch_26  #0x1
    iget-object p0, p0, Lc11;->a:Liq0;

    .line 40
    .line 41
    invoke-virtual {p0}, Liq0;->g()I

    .line 42
    .line 43
    .line 44
    move-result p0

    .line 45
    if-lez p0, :cond_2f

    .line 46
    .line 47
    goto :goto_30

    .line 48
    :cond_2f
    move v1, v2

    .line 49
    :goto_30
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 50
    .line 51
    .line 52
    move-result-object p0

    .line 53
    return-object p0

    .line 54
    :pswitch_35  #0x0
    iget-object v0, p0, Lc11;->a:Liq0;

    .line 55
    .line 56
    invoke-virtual {v0}, Liq0;->g()I

    .line 57
    .line 58
    .line 59
    move-result v0

    .line 60
    iget-object p0, p0, Lc11;->e:Liq0;

    .line 61
    .line 62
    invoke-virtual {p0}, Liq0;->g()I

    .line 63
    .line 64
    .line 65
    move-result p0

    .line 66
    if-ge v0, p0, :cond_44

    .line 67
    .line 68
    goto :goto_45

    .line 69
    :cond_44
    move v1, v2

    .line 70
    :goto_45
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 71
    .line 72
    .line 73
    move-result-object p0

    .line 74
    return-object p0

    .line 75
    :pswitch_data_4a
    .packed-switch 0x0
        :pswitch_35  #00000000
        :pswitch_26  #00000001
    .end packed-switch
.end method
