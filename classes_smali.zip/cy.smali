.class public final Lcy;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# instance fields
.field public final a:Lhy;

.field public final b:Ln4;

.field public final c:Lik0;

.field public final d:Lik0;

.field public e:Z


# direct methods
.method public constructor <init>(Lhy;Ln4;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lcy;->a:Lhy;

    .line 5
    .line 6
    iput-object p2, p0, Lcy;->b:Ln4;

    .line 7
    .line 8
    sget-object p1, Lo01;->a:Lik0;

    .line 9
    .line 10
    new-instance p1, Lik0;

    .line 11
    .line 12
    invoke-direct {p1}, Lik0;-><init>()V

    .line 13
    .line 14
    .line 15
    iput-object p1, p0, Lcy;->c:Lik0;

    .line 16
    .line 17
    new-instance p1, Lik0;

    .line 18
    .line 19
    invoke-direct {p1}, Lik0;-><init>()V

    .line 20
    .line 21
    .line 22
    iput-object p1, p0, Lcy;->d:Lik0;

    .line 23
    .line 24
    return-void
.end method


# virtual methods
.method public final a()V
    .registers 11

    .line 1
    iget-boolean v0, p0, Lcy;->e:Z

    .line 2
    .line 3
    if-nez v0, :cond_25

    .line 4
    .line 5
    new-instance v1, Le4;

    .line 6
    .line 7
    const/4 v8, 0x0

    .line 8
    const/4 v9, 0x1

    .line 9
    const/4 v2, 0x0

    .line 10
    const-class v4, Lcy;

    .line 11
    .line 12
    const-string v5, "invalidateNodes"

    .line 13
    .line 14
    const-string v6, "invalidateNodes()V"

    .line 15
    .line 16
    const/4 v7, 0x0

    .line 17
    move-object v3, p0

    .line 18
    invoke-direct/range {v1 .. v9}, Le4;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;III)V

    .line 19
    .line 20
    .line 21
    iget-object p0, v3, Lcy;->b:Ln4;

    .line 22
    .line 23
    iget-object p0, p0, Ln4;->D0:Lak0;

    .line 24
    .line 25
    invoke-virtual {p0, v1}, Lak0;->g(Ljava/lang/Object;)I

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    if-ltz v0, :cond_1f

    .line 30
    .line 31
    goto :goto_22

    .line 32
    :cond_1f
    invoke-virtual {p0, v1}, Lak0;->a(Ljava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    :goto_22
    const/4 p0, 0x1

    .line 36
    iput-boolean p0, v3, Lcy;->e:Z

    .line 37
    .line 38
    :cond_25
    return-void
.end method
