.class public final Ld2;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Ln00;


# instance fields
.field public final synthetic e:Lwi1;

.field public final synthetic f:Z

.field public final synthetic g:Lui1;

.field public final synthetic h:Li00;

.field public final synthetic i:Li00;

.field public final synthetic j:Lw1;

.field public final synthetic k:Lv1;

.field public final synthetic l:Li00;


# direct methods
.method public constructor <init>(Lwi1;ZLui1;Li00;Li00;Lw1;Lv1;Li00;)V
    .registers 9

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Ld2;->e:Lwi1;

    .line 5
    .line 6
    iput-boolean p2, p0, Ld2;->f:Z

    .line 7
    .line 8
    iput-object p3, p0, Ld2;->g:Lui1;

    .line 9
    .line 10
    iput-object p4, p0, Ld2;->h:Li00;

    .line 11
    .line 12
    iput-object p5, p0, Ld2;->i:Li00;

    .line 13
    .line 14
    iput-object p6, p0, Ld2;->j:Lw1;

    .line 15
    .line 16
    iput-object p7, p0, Ld2;->k:Lv1;

    .line 17
    .line 18
    iput-object p8, p0, Ld2;->l:Li00;

    .line 19
    .line 20
    return-void
.end method


# virtual methods
.method public final c(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 15

    .line 1
    check-cast p1, Loc;

    .line 2
    .line 3
    move-object v9, p2

    .line 4
    check-cast v9, Ld10;

    .line 5
    .line 6
    check-cast p3, Ljava/lang/Number;

    .line 7
    .line 8
    invoke-virtual {p3}, Ljava/lang/Number;->intValue()I

    .line 9
    .line 10
    .line 11
    move-result p2

    .line 12
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13
    .line 14
    .line 15
    iget-wide v0, p1, Loc;->b:J

    .line 16
    .line 17
    and-int/lit8 p3, p2, 0x6

    .line 18
    .line 19
    if-nez p3, :cond_1e

    .line 20
    .line 21
    invoke-virtual {v9, p1}, Ld10;->f(Ljava/lang/Object;)Z

    .line 22
    .line 23
    .line 24
    move-result p1

    .line 25
    if-eqz p1, :cond_1c

    .line 26
    .line 27
    const/4 p1, 0x4

    .line 28
    goto :goto_1d

    .line 29
    :cond_1c
    const/4 p1, 0x2

    .line 30
    :goto_1d
    or-int/2addr p2, p1

    .line 31
    :cond_1e
    and-int/lit8 p1, p2, 0x13

    .line 32
    .line 33
    const/16 p2, 0x12

    .line 34
    .line 35
    if-ne p1, p2, :cond_2f

    .line 36
    .line 37
    invoke-virtual {v9}, Ld10;->A()Z

    .line 38
    .line 39
    .line 40
    move-result p1

    .line 41
    if-nez p1, :cond_2b

    .line 42
    .line 43
    goto :goto_2f

    .line 44
    :cond_2b
    invoke-virtual {v9}, Ld10;->R()V

    .line 45
    .line 46
    .line 47
    goto :goto_5b

    .line 48
    :cond_2f
    :goto_2f
    invoke-static {v0, v1}, Lsk;->f(J)Z

    .line 49
    .line 50
    .line 51
    move-result p1

    .line 52
    const/4 p2, -0x2

    .line 53
    const/4 p3, -0x1

    .line 54
    if-eqz p1, :cond_39

    .line 55
    .line 56
    move p1, p3

    .line 57
    goto :goto_3a

    .line 58
    :cond_39
    move p1, p2

    .line 59
    :goto_3a
    invoke-static {v0, v1}, Lsk;->e(J)Z

    .line 60
    .line 61
    .line 62
    move-result v0

    .line 63
    if-eqz v0, :cond_41

    .line 64
    .line 65
    move p2, p3

    .line 66
    :cond_41
    new-instance v1, Landroid/widget/FrameLayout$LayoutParams;

    .line 67
    .line 68
    invoke-direct {v1, p1, p2}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    .line 69
    .line 70
    .line 71
    iget-object v8, p0, Ld2;->l:Li00;

    .line 72
    .line 73
    const/16 v10, 0x180

    .line 74
    .line 75
    iget-object v0, p0, Ld2;->e:Lwi1;

    .line 76
    .line 77
    iget-boolean v2, p0, Ld2;->f:Z

    .line 78
    .line 79
    iget-object v3, p0, Ld2;->g:Lui1;

    .line 80
    .line 81
    iget-object v4, p0, Ld2;->h:Li00;

    .line 82
    .line 83
    iget-object v5, p0, Ld2;->i:Li00;

    .line 84
    .line 85
    iget-object v6, p0, Ld2;->j:Lw1;

    .line 86
    .line 87
    iget-object v7, p0, Ld2;->k:Lv1;

    .line 88
    .line 89
    invoke-static/range {v0 .. v10}, Lzi1;->b(Lwi1;Landroid/widget/FrameLayout$LayoutParams;ZLui1;Li00;Li00;Lw1;Lv1;Li00;Ld10;I)V

    .line 90
    .line 91
    .line 92
    :goto_5b
    sget-object p0, Lwe1;->a:Lwe1;

    .line 93
    .line 94
    return-object p0
.end method
