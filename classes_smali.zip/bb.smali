.class public final Lbb;
.super Lli0;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lds;
.implements Lvm0;
.implements Lg21;


# instance fields
.field public s:J

.field public t:Ly41;

.field public u:J

.field public v:Lo90;

.field public w:Ljb0;

.field public x:Ly41;

.field public y:Ljb0;


# virtual methods
.method public final C(Lda0;)V
    .registers 30

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    iget-object v2, v1, Lda0;->e:Lte;

    .line 6
    .line 7
    iget-object v3, v0, Lbb;->t:Ly41;

    .line 8
    .line 9
    sget-object v4, Lvn;->j:Lk30;

    .line 10
    .line 11
    if-ne v3, v4, :cond_25

    .line 12
    .line 13
    iget-wide v2, v0, Lbb;->s:J

    .line 14
    .line 15
    sget-wide v4, Lzg;->i:J

    .line 16
    .line 17
    invoke-static {v2, v3, v4, v5}, Lzg;->c(JJ)Z

    .line 18
    .line 19
    .line 20
    move-result v2

    .line 21
    if-nez v2, :cond_22

    .line 22
    .line 23
    iget-wide v1, v0, Lbb;->s:J

    .line 24
    .line 25
    const-wide/16 v3, 0x0

    .line 26
    .line 27
    const/16 v5, 0x7e

    .line 28
    .line 29
    move-object/from16 v0, p1

    .line 30
    .line 31
    invoke-static/range {v0 .. v5}, Lfu0;->x(Les;JJI)V

    .line 32
    .line 33
    .line 34
    move-object v1, v0

    .line 35
    :cond_22
    move-object v0, v1

    .line 36
    goto/16 :goto_165

    .line 37
    .line 38
    :cond_25
    sget-object v7, Ltv;->F:Ltv;

    .line 39
    .line 40
    iget-object v3, v2, Lte;->f:Lk9;

    .line 41
    .line 42
    invoke-virtual {v3}, Lk9;->t()J

    .line 43
    .line 44
    .line 45
    move-result-wide v3

    .line 46
    iget-wide v5, v0, Lbb;->u:J

    .line 47
    .line 48
    invoke-static {v3, v4, v5, v6}, Ls51;->a(JJ)Z

    .line 49
    .line 50
    .line 51
    move-result v3

    .line 52
    if-eqz v3, :cond_4d

    .line 53
    .line 54
    invoke-virtual {v1}, Lda0;->getLayoutDirection()Lo90;

    .line 55
    .line 56
    .line 57
    move-result-object v3

    .line 58
    iget-object v4, v0, Lbb;->v:Lo90;

    .line 59
    .line 60
    if-ne v3, v4, :cond_4d

    .line 61
    .line 62
    iget-object v3, v0, Lbb;->x:Ly41;

    .line 63
    .line 64
    iget-object v4, v0, Lbb;->t:Ly41;

    .line 65
    .line 66
    invoke-static {v3, v4}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 67
    .line 68
    .line 69
    move-result v3

    .line 70
    if-eqz v3, :cond_4d

    .line 71
    .line 72
    iget-object v3, v0, Lbb;->w:Ljb0;

    .line 73
    .line 74
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 75
    .line 76
    .line 77
    goto :goto_5b

    .line 78
    :cond_4d
    new-instance v3, Lva;

    .line 79
    .line 80
    const/4 v4, 0x1

    .line 81
    invoke-direct {v3, v4, v0, v1}, Lva;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 82
    .line 83
    .line 84
    invoke-static {v0, v3}, Lsb0;->r(Lli0;Lxz;)V

    .line 85
    .line 86
    .line 87
    iget-object v3, v0, Lbb;->y:Ljb0;

    .line 88
    .line 89
    const/4 v4, 0x0

    .line 90
    iput-object v4, v0, Lbb;->y:Ljb0;

    .line 91
    .line 92
    :goto_5b
    iput-object v3, v0, Lbb;->w:Ljb0;

    .line 93
    .line 94
    iget-object v4, v2, Lte;->f:Lk9;

    .line 95
    .line 96
    invoke-virtual {v4}, Lk9;->t()J

    .line 97
    .line 98
    .line 99
    move-result-wide v4

    .line 100
    iput-wide v4, v0, Lbb;->u:J

    .line 101
    .line 102
    invoke-virtual {v1}, Lda0;->getLayoutDirection()Lo90;

    .line 103
    .line 104
    .line 105
    move-result-object v4

    .line 106
    iput-object v4, v0, Lbb;->v:Lo90;

    .line 107
    .line 108
    iget-object v4, v0, Lbb;->t:Ly41;

    .line 109
    .line 110
    iput-object v4, v0, Lbb;->x:Ly41;

    .line 111
    .line 112
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 113
    .line 114
    .line 115
    iget-wide v4, v0, Lbb;->s:J

    .line 116
    .line 117
    sget-wide v8, Lzg;->i:J

    .line 118
    .line 119
    invoke-static {v4, v5, v8, v9}, Lzg;->c(JJ)Z

    .line 120
    .line 121
    .line 122
    move-result v4

    .line 123
    if-nez v4, :cond_22

    .line 124
    .line 125
    iget-wide v4, v0, Lbb;->s:J

    .line 126
    .line 127
    instance-of v0, v3, Lep0;

    .line 128
    .line 129
    const/16 v6, 0x20

    .line 130
    .line 131
    const-wide v8, 0xffffffffL

    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    if-eqz v0, :cond_c3

    .line 137
    .line 138
    check-cast v3, Lep0;

    .line 139
    .line 140
    iget-object v0, v3, Lep0;->b:Lgw0;

    .line 141
    .line 142
    iget v2, v0, Lgw0;->a:F

    .line 143
    .line 144
    iget v3, v0, Lgw0;->b:F

    .line 145
    .line 146
    invoke-static {v2}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 147
    .line 148
    .line 149
    move-result v2

    .line 150
    int-to-long v10, v2

    .line 151
    invoke-static {v3}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 152
    .line 153
    .line 154
    move-result v2

    .line 155
    int-to-long v2, v2

    .line 156
    shl-long/2addr v10, v6

    .line 157
    and-long/2addr v2, v8

    .line 158
    or-long/2addr v2, v10

    .line 159
    iget v10, v0, Lgw0;->c:F

    .line 160
    .line 161
    iget v11, v0, Lgw0;->a:F

    .line 162
    .line 163
    sub-float/2addr v10, v11

    .line 164
    iget v11, v0, Lgw0;->d:F

    .line 165
    .line 166
    iget v0, v0, Lgw0;->b:F

    .line 167
    .line 168
    sub-float/2addr v11, v0

    .line 169
    invoke-static {v10}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 170
    .line 171
    .line 172
    move-result v0

    .line 173
    int-to-long v12, v0

    .line 174
    invoke-static {v11}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 175
    .line 176
    .line 177
    move-result v0

    .line 178
    int-to-long v10, v0

    .line 179
    shl-long/2addr v12, v6

    .line 180
    and-long/2addr v8, v10

    .line 181
    or-long/2addr v8, v12

    .line 182
    move-wide/from16 v26, v4

    .line 183
    .line 184
    move-wide v3, v2

    .line 185
    move-wide/from16 v1, v26

    .line 186
    .line 187
    move-wide v5, v8

    .line 188
    const/4 v8, 0x3

    .line 189
    move-object/from16 v0, p1

    .line 190
    .line 191
    invoke-virtual/range {v0 .. v8}, Lda0;->k(JJJLac;I)V

    .line 192
    .line 193
    .line 194
    goto/16 :goto_165

    .line 195
    .line 196
    :cond_c3
    move-object v0, v1

    .line 197
    instance-of v1, v3, Lfp0;

    .line 198
    .line 199
    if-eqz v1, :cond_157

    .line 200
    .line 201
    check-cast v3, Lfp0;

    .line 202
    .line 203
    iget-object v1, v3, Lfp0;->c:Lr6;

    .line 204
    .line 205
    if-eqz v1, :cond_d3

    .line 206
    .line 207
    :goto_ce
    invoke-virtual {v0, v1, v4, v5, v7}, Lda0;->e(Lr6;JLac;)V

    .line 208
    .line 209
    .line 210
    goto/16 :goto_165

    .line 211
    .line 212
    :cond_d3
    iget-object v1, v3, Lfp0;->b:Lmy0;

    .line 213
    .line 214
    iget v3, v1, Lmy0;->b:F

    .line 215
    .line 216
    iget v10, v1, Lmy0;->a:F

    .line 217
    .line 218
    iget-wide v11, v1, Lmy0;->h:J

    .line 219
    .line 220
    shr-long/2addr v11, v6

    .line 221
    long-to-int v11, v11

    .line 222
    invoke-static {v11}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 223
    .line 224
    .line 225
    move-result v11

    .line 226
    invoke-static {v10}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 227
    .line 228
    .line 229
    move-result v12

    .line 230
    int-to-long v12, v12

    .line 231
    invoke-static {v3}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 232
    .line 233
    .line 234
    move-result v14

    .line 235
    int-to-long v14, v14

    .line 236
    shl-long/2addr v12, v6

    .line 237
    and-long/2addr v14, v8

    .line 238
    or-long/2addr v12, v14

    .line 239
    iget v14, v1, Lmy0;->c:F

    .line 240
    .line 241
    sub-float/2addr v14, v10

    .line 242
    iget v1, v1, Lmy0;->d:F

    .line 243
    .line 244
    sub-float/2addr v1, v3

    .line 245
    invoke-static {v14}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 246
    .line 247
    .line 248
    move-result v3

    .line 249
    int-to-long v14, v3

    .line 250
    invoke-static {v1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 251
    .line 252
    .line 253
    move-result v1

    .line 254
    move-wide/from16 v16, v8

    .line 255
    .line 256
    int-to-long v8, v1

    .line 257
    shl-long/2addr v14, v6

    .line 258
    and-long v8, v8, v16

    .line 259
    .line 260
    or-long/2addr v8, v14

    .line 261
    invoke-static {v11}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 262
    .line 263
    .line 264
    move-result v1

    .line 265
    int-to-long v14, v1

    .line 266
    invoke-static {v11}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 267
    .line 268
    .line 269
    move-result v1

    .line 270
    int-to-long v10, v1

    .line 271
    shl-long/2addr v14, v6

    .line 272
    and-long v10, v10, v16

    .line 273
    .line 274
    or-long/2addr v10, v14

    .line 275
    iget-object v1, v2, Lte;->e:Lse;

    .line 276
    .line 277
    iget-object v1, v1, Lse;->c:Lre;

    .line 278
    .line 279
    shr-long v14, v12, v6

    .line 280
    .line 281
    long-to-int v3, v14

    .line 282
    invoke-static {v3}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 283
    .line 284
    .line 285
    move-result v19

    .line 286
    and-long v12, v12, v16

    .line 287
    .line 288
    long-to-int v12, v12

    .line 289
    invoke-static {v12}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 290
    .line 291
    .line 292
    move-result v20

    .line 293
    invoke-static {v3}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 294
    .line 295
    .line 296
    move-result v3

    .line 297
    shr-long v13, v8, v6

    .line 298
    .line 299
    long-to-int v13, v13

    .line 300
    invoke-static {v13}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 301
    .line 302
    .line 303
    move-result v13

    .line 304
    add-float v21, v13, v3

    .line 305
    .line 306
    invoke-static {v12}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 307
    .line 308
    .line 309
    move-result v3

    .line 310
    and-long v8, v8, v16

    .line 311
    .line 312
    long-to-int v8, v8

    .line 313
    invoke-static {v8}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 314
    .line 315
    .line 316
    move-result v8

    .line 317
    add-float v22, v8, v3

    .line 318
    .line 319
    shr-long v8, v10, v6

    .line 320
    .line 321
    long-to-int v3, v8

    .line 322
    invoke-static {v3}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 323
    .line 324
    .line 325
    move-result v23

    .line 326
    and-long v8, v10, v16

    .line 327
    .line 328
    long-to-int v3, v8

    .line 329
    invoke-static {v3}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 330
    .line 331
    .line 332
    move-result v24

    .line 333
    const/4 v3, 0x3

    .line 334
    invoke-static {v2, v4, v5, v7, v3}, Lte;->c(Lte;JLac;I)Lk6;

    .line 335
    .line 336
    .line 337
    move-result-object v25

    .line 338
    move-object/from16 v18, v1

    .line 339
    .line 340
    invoke-interface/range {v18 .. v25}, Lre;->h(FFFFFFLk6;)V

    .line 341
    .line 342
    .line 343
    goto :goto_165

    .line 344
    :cond_157
    instance-of v1, v3, Ldp0;

    .line 345
    .line 346
    if-eqz v1, :cond_161

    .line 347
    .line 348
    check-cast v3, Ldp0;

    .line 349
    .line 350
    iget-object v1, v3, Ldp0;->b:Lr6;

    .line 351
    .line 352
    goto/16 :goto_ce

    .line 353
    .line 354
    :cond_161
    invoke-static {}, Lod;->k()V

    .line 355
    .line 356
    .line 357
    return-void

    .line 358
    :goto_165
    invoke-virtual {v0}, Lda0;->c()V

    .line 359
    .line 360
    .line 361
    return-void
.end method

.method public final Q(Lr21;)V
    .registers 2

    .line 1
    iget-object p0, p0, Lbb;->t:Ly41;

    .line 2
    .line 3
    invoke-static {p1, p0}, Lp21;->b(Lr21;Ly41;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final synthetic S()Z
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public final synthetic T()Z
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public final synthetic Z()V
    .registers 1

    .line 1
    return-void
.end method

.method public final e()Z
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public final z()V
    .registers 3

    .line 1
    const-wide v0, 0x7fc000007fc00000L  # 2.247117487993712E307

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    iput-wide v0, p0, Lbb;->u:J

    .line 7
    .line 8
    const/4 v0, 0x0

    .line 9
    iput-object v0, p0, Lbb;->v:Lo90;

    .line 10
    .line 11
    iput-object v0, p0, Lbb;->w:Ljb0;

    .line 12
    .line 13
    iput-object v0, p0, Lbb;->x:Ly41;

    .line 14
    .line 15
    invoke-static {p0}, La5;->x(Lds;)V

    .line 16
    .line 17
    .line 18
    return-void
.end method
