.class public abstract Ldd0;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# static fields
.field public static a:Ly30;


# direct methods
.method public static a(Ljava/lang/String;Lob1;JLmp;Lyy;I)Lm6;
    .registers 14

    .line 1
    move-object v1, p0

    .line 2
    new-instance p0, Lm6;

    .line 3
    .line 4
    new-instance v0, Lq6;

    .line 5
    .line 6
    sget-object v3, Lut;->e:Lut;

    .line 7
    .line 8
    move-object v4, v3

    .line 9
    move-object v2, p1

    .line 10
    move-object v6, p4

    .line 11
    move-object v5, p5

    .line 12
    invoke-direct/range {v0 .. v6}, Lq6;-><init>(Ljava/lang/String;Lob1;Ljava/util/List;Ljava/util/List;Lyy;Ljp;)V

    .line 13
    .line 14
    .line 15
    move-wide p4, p2

    .line 16
    move-object p1, v0

    .line 17
    const/4 p3, 0x1

    .line 18
    move p2, p6

    .line 19
    invoke-direct/range {p0 .. p5}, Lm6;-><init>(Lq6;IIJ)V

    .line 20
    .line 21
    .line 22
    return-object p0
.end method

.method public static final b(II)J
    .registers 6

    .line 1
    if-ltz p0, :cond_5

    .line 2
    .line 3
    if-ltz p1, :cond_5

    .line 4
    .line 5
    goto :goto_23

    .line 6
    :cond_5
    new-instance v0, Ljava/lang/StringBuilder;

    .line 7
    .line 8
    const-string v1, "start and end cannot be negative. [start: "

    .line 9
    .line 10
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 14
    .line 15
    .line 16
    const-string v1, ", end: "

    .line 17
    .line 18
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 19
    .line 20
    .line 21
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 22
    .line 23
    .line 24
    const/16 v1, 0x5d

    .line 25
    .line 26
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 27
    .line 28
    .line 29
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    invoke-static {v0}, Lq50;->a(Ljava/lang/String;)V

    .line 34
    .line 35
    .line 36
    :goto_23
    int-to-long v0, p0

    .line 37
    const/16 p0, 0x20

    .line 38
    .line 39
    shl-long/2addr v0, p0

    .line 40
    int-to-long p0, p1

    .line 41
    const-wide v2, 0xffffffffL

    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    and-long/2addr p0, v2

    .line 47
    or-long/2addr p0, v0

    .line 48
    sget v0, Lhb1;->c:I

    .line 49
    .line 50
    return-wide p0
.end method

.method public static c(Ljava/lang/StringBuilder;Ljava/lang/Object;Li00;)V
    .registers 3

    .line 1
    if-eqz p2, :cond_c

    .line 2
    .line 3
    invoke-interface {p2, p1}, Li00;->i(Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    check-cast p1, Ljava/lang/CharSequence;

    .line 8
    .line 9
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;

    .line 10
    .line 11
    .line 12
    return-void

    .line 13
    :cond_c
    if-nez p1, :cond_10

    .line 14
    .line 15
    const/4 p2, 0x1

    .line 16
    goto :goto_12

    .line 17
    :cond_10
    instance-of p2, p1, Ljava/lang/CharSequence;

    .line 18
    .line 19
    :goto_12
    if-eqz p2, :cond_1a

    .line 20
    .line 21
    check-cast p1, Ljava/lang/CharSequence;

    .line 22
    .line 23
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;

    .line 24
    .line 25
    .line 26
    return-void

    .line 27
    :cond_1a
    instance-of p2, p1, Ljava/lang/Character;

    .line 28
    .line 29
    if-eqz p2, :cond_28

    .line 30
    .line 31
    check-cast p1, Ljava/lang/Character;

    .line 32
    .line 33
    invoke-virtual {p1}, Ljava/lang/Character;->charValue()C

    .line 34
    .line 35
    .line 36
    move-result p1

    .line 37
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/Appendable;

    .line 38
    .line 39
    .line 40
    return-void

    .line 41
    :cond_28
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object p1

    .line 45
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;

    .line 46
    .line 47
    .line 48
    return-void
.end method

.method public static final d(Lfh1;Lal;Lud0;)V
    .registers 4

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    .line 6
    .line 7
    const-string v0, "androidx.lifecycle.savedstate.vm.tag"

    .line 8
    .line 9
    invoke-virtual {p0, v0}, Lfh1;->c(Ljava/lang/String;)Ljava/lang/AutoCloseable;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    check-cast p0, Lrz0;

    .line 14
    .line 15
    if-eqz p0, :cond_32

    .line 16
    .line 17
    iget-boolean v0, p0, Lrz0;->g:Z

    .line 18
    .line 19
    if-nez v0, :cond_32

    .line 20
    .line 21
    invoke-virtual {p0, p1, p2}, Lrz0;->f(Lal;Lud0;)V

    .line 22
    .line 23
    .line 24
    iget-object p0, p2, Lud0;->d:Ljd0;

    .line 25
    .line 26
    sget-object v0, Ljd0;->f:Ljd0;

    .line 27
    .line 28
    if-eq p0, v0, :cond_2f

    .line 29
    .line 30
    sget-object v0, Ljd0;->h:Ljd0;

    .line 31
    .line 32
    invoke-virtual {p0, v0}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    .line 33
    .line 34
    .line 35
    move-result p0

    .line 36
    if-ltz p0, :cond_26

    .line 37
    .line 38
    goto :goto_2f

    .line 39
    :cond_26
    new-instance p0, Lto;

    .line 40
    .line 41
    invoke-direct {p0, p1, p2}, Lto;-><init>(Lal;Lud0;)V

    .line 42
    .line 43
    .line 44
    invoke-virtual {p2, p0}, Lud0;->a(Lrd0;)V

    .line 45
    .line 46
    .line 47
    return-void

    .line 48
    :cond_2f
    :goto_2f
    invoke-virtual {p1}, Lal;->t()V

    .line 49
    .line 50
    .line 51
    :cond_32
    return-void
.end method

.method public static e()[F
    .registers 1

    .line 1
    const/16 v0, 0x10

    .line 2
    .line 3
    new-array v0, v0, [F

    .line 4
    .line 5
    fill-array-data v0, :array_8

    .line 6
    .line 7
    .line 8
    return-object v0

    .line 9
    :array_8
    .array-data 4
        0x3f800000  # 1.0f
        0x0
        0x0
        0x0
        0x0
        0x3f800000  # 1.0f
        0x0
        0x0
        0x0
        0x0
        0x3f800000  # 1.0f
        0x0
        0x0
        0x0
        0x0
        0x3f800000  # 1.0f
    .end array-data
.end method

.method public static final h(ILjava/util/List;)I
    .registers 9

    .line 1
    invoke-static {p1}, Ltg;->W(Ljava/util/List;)Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    check-cast v0, Lbq0;

    .line 6
    .line 7
    iget v0, v0, Lbq0;->c:I

    .line 8
    .line 9
    invoke-static {p1}, Ltg;->W(Ljava/util/List;)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    check-cast v1, Lbq0;

    .line 14
    .line 15
    iget v1, v1, Lbq0;->c:I

    .line 16
    .line 17
    if-gt p0, v1, :cond_13

    .line 18
    .line 19
    goto :goto_2c

    .line 20
    :cond_13
    new-instance v1, Ljava/lang/StringBuilder;

    .line 21
    .line 22
    const-string v2, "Index "

    .line 23
    .line 24
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 28
    .line 29
    .line 30
    const-string v2, " should be less or equal than last line\'s end "

    .line 31
    .line 32
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 33
    .line 34
    .line 35
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 36
    .line 37
    .line 38
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    invoke-static {v0}, Lq50;->a(Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    :goto_2c
    invoke-interface {p1}, Ljava/util/List;->size()I

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    const/4 v1, 0x1

    .line 50
    sub-int/2addr v0, v1

    .line 51
    const/4 v2, 0x0

    .line 52
    move v3, v2

    .line 53
    :goto_34
    if-gt v3, v0, :cond_56

    .line 54
    .line 55
    add-int v4, v3, v0

    .line 56
    .line 57
    ushr-int/2addr v4, v1

    .line 58
    invoke-interface {p1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 59
    .line 60
    .line 61
    move-result-object v5

    .line 62
    check-cast v5, Lbq0;

    .line 63
    .line 64
    iget v6, v5, Lbq0;->b:I

    .line 65
    .line 66
    if-le v6, p0, :cond_45

    .line 67
    .line 68
    move v5, v1

    .line 69
    goto :goto_4c

    .line 70
    :cond_45
    iget v5, v5, Lbq0;->c:I

    .line 71
    .line 72
    if-gt v5, p0, :cond_4b

    .line 73
    .line 74
    const/4 v5, -0x1

    .line 75
    goto :goto_4c

    .line 76
    :cond_4b
    move v5, v2

    .line 77
    :goto_4c
    if-gez v5, :cond_51

    .line 78
    .line 79
    add-int/lit8 v3, v4, 0x1

    .line 80
    .line 81
    goto :goto_34

    .line 82
    :cond_51
    if-lez v5, :cond_58

    .line 83
    .line 84
    add-int/lit8 v0, v4, -0x1

    .line 85
    .line 86
    goto :goto_34

    .line 87
    :cond_56
    add-int/2addr v3, v1

    .line 88
    neg-int v4, v3

    .line 89
    :cond_58
    if-ltz v4, :cond_61

    .line 90
    .line 91
    invoke-interface {p1}, Ljava/util/Collection;->size()I

    .line 92
    .line 93
    .line 94
    move-result v0

    .line 95
    if-ge v4, v0, :cond_61

    .line 96
    .line 97
    return v4

    .line 98
    :cond_61
    const-string v0, "Found paragraph index "

    .line 99
    .line 100
    const-string v1, " should be in range [0, "

    .line 101
    .line 102
    invoke-static {v4, v0, v1}, Lfu0;->H(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 103
    .line 104
    .line 105
    move-result-object v0

    .line 106
    invoke-interface {p1}, Ljava/util/List;->size()I

    .line 107
    .line 108
    .line 109
    move-result v1

    .line 110
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 111
    .line 112
    .line 113
    const-string v1, ").\nDebug info: index="

    .line 114
    .line 115
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 116
    .line 117
    .line 118
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 119
    .line 120
    .line 121
    const-string p0, ", paragraphs=["

    .line 122
    .line 123
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 124
    .line 125
    .line 126
    new-instance p0, Lz1;

    .line 127
    .line 128
    const/16 v1, 0x10

    .line 129
    .line 130
    invoke-direct {p0, v1}, Lz1;-><init>(I)V

    .line 131
    .line 132
    .line 133
    const/16 v1, 0x1f

    .line 134
    .line 135
    const/4 v2, 0x0

    .line 136
    invoke-static {p1, v2, p0, v1}, Lue0;->a(Ljava/util/List;Ljava/lang/String;Lz1;I)Ljava/lang/String;

    .line 137
    .line 138
    .line 139
    move-result-object p0

    .line 140
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 141
    .line 142
    .line 143
    const/16 p0, 0x5d

    .line 144
    .line 145
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 146
    .line 147
    .line 148
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 149
    .line 150
    .line 151
    move-result-object p0

    .line 152
    invoke-static {p0}, Lq50;->a(Ljava/lang/String;)V

    .line 153
    .line 154
    .line 155
    return v4
.end method

.method public static final i(ILjava/util/List;)I
    .registers 9

    .line 1
    invoke-interface {p1}, Ljava/util/List;->size()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x1

    .line 6
    sub-int/2addr v0, v1

    .line 7
    const/4 v2, 0x0

    .line 8
    move v3, v2

    .line 9
    :goto_8
    if-gt v3, v0, :cond_2b

    .line 10
    .line 11
    add-int v4, v3, v0

    .line 12
    .line 13
    ushr-int/2addr v4, v1

    .line 14
    invoke-interface {p1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object v5

    .line 18
    check-cast v5, Lbq0;

    .line 19
    .line 20
    iget v6, v5, Lbq0;->d:I

    .line 21
    .line 22
    if-le v6, p0, :cond_19

    .line 23
    .line 24
    move v5, v1

    .line 25
    goto :goto_20

    .line 26
    :cond_19
    iget v5, v5, Lbq0;->e:I

    .line 27
    .line 28
    if-gt v5, p0, :cond_1f

    .line 29
    .line 30
    const/4 v5, -0x1

    .line 31
    goto :goto_20

    .line 32
    :cond_1f
    move v5, v2

    .line 33
    :goto_20
    if-gez v5, :cond_25

    .line 34
    .line 35
    add-int/lit8 v3, v4, 0x1

    .line 36
    .line 37
    goto :goto_8

    .line 38
    :cond_25
    if-lez v5, :cond_2a

    .line 39
    .line 40
    add-int/lit8 v0, v4, -0x1

    .line 41
    .line 42
    goto :goto_8

    .line 43
    :cond_2a
    return v4

    .line 44
    :cond_2b
    add-int/2addr v3, v1

    .line 45
    neg-int p0, v3

    .line 46
    return p0
.end method

.method public static final j(Landroid/view/View;)Landroid/view/ViewParent;
    .registers 2

    .line 1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    if-eqz v0, :cond_a

    .line 9
    .line 10
    return-object v0

    .line 11
    :cond_a
    const v0, 0x7f050074

    .line 12
    .line 13
    .line 14
    invoke-virtual {p0, v0}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object p0

    .line 18
    instance-of v0, p0, Landroid/view/ViewParent;

    .line 19
    .line 20
    if-eqz v0, :cond_18

    .line 21
    .line 22
    check-cast p0, Landroid/view/ViewParent;

    .line 23
    .line 24
    return-object p0

    .line 25
    :cond_18
    const/4 p0, 0x0

    .line 26
    return-object p0
.end method

.method public static final k(Ljava/lang/Object;)La21;
    .registers 2

    .line 1
    sget-object v0, Lj70;->b:Lmt;

    .line 2
    .line 3
    if-eq p0, v0, :cond_7

    .line 4
    .line 5
    check-cast p0, La21;

    .line 6
    .line 7
    return-object p0

    .line 8
    :cond_7
    const-string p0, "Does not contain segment"

    .line 9
    .line 10
    invoke-static {p0}, Lod;->p(Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    const/4 p0, 0x0

    .line 14
    return-object p0
.end method

.method public static final l(Ljava/lang/Object;)Z
    .registers 2

    .line 1
    sget-object v0, Lj70;->b:Lmt;

    .line 2
    .line 3
    if-ne p0, v0, :cond_6

    .line 4
    .line 5
    const/4 p0, 0x1

    .line 6
    return p0

    .line 7
    :cond_6
    const/4 p0, 0x0

    .line 8
    return p0
.end method

.method public static final m(FFLr6;)Z
    .registers 7

    .line 1
    const v0, 0x3ba3d70a

    .line 2
    .line 3
    .line 4
    sub-float v1, p0, v0

    .line 5
    .line 6
    sub-float v2, p1, v0

    .line 7
    .line 8
    add-float/2addr p0, v0

    .line 9
    add-float/2addr p1, v0

    .line 10
    invoke-static {}, Lt6;->a()Lr6;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    invoke-static {v1}, Ljava/lang/Float;->isNaN(F)Z

    .line 15
    .line 16
    .line 17
    move-result v3

    .line 18
    if-nez v3, :cond_25

    .line 19
    .line 20
    invoke-static {v2}, Ljava/lang/Float;->isNaN(F)Z

    .line 21
    .line 22
    .line 23
    move-result v3

    .line 24
    if-nez v3, :cond_25

    .line 25
    .line 26
    invoke-static {p0}, Ljava/lang/Float;->isNaN(F)Z

    .line 27
    .line 28
    .line 29
    move-result v3

    .line 30
    if-nez v3, :cond_25

    .line 31
    .line 32
    invoke-static {p1}, Ljava/lang/Float;->isNaN(F)Z

    .line 33
    .line 34
    .line 35
    move-result v3

    .line 36
    if-eqz v3, :cond_2a

    .line 37
    .line 38
    :cond_25
    const-string v3, "Invalid rectangle, make sure no value is NaN"

    .line 39
    .line 40
    invoke-static {v3}, Lt6;->b(Ljava/lang/String;)V

    .line 41
    .line 42
    .line 43
    :cond_2a
    iget-object v3, v0, Lr6;->b:Landroid/graphics/RectF;

    .line 44
    .line 45
    if-nez v3, :cond_35

    .line 46
    .line 47
    new-instance v3, Landroid/graphics/RectF;

    .line 48
    .line 49
    invoke-direct {v3}, Landroid/graphics/RectF;-><init>()V

    .line 50
    .line 51
    .line 52
    iput-object v3, v0, Lr6;->b:Landroid/graphics/RectF;

    .line 53
    .line 54
    :cond_35
    iget-object v3, v0, Lr6;->b:Landroid/graphics/RectF;

    .line 55
    .line 56
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 57
    .line 58
    .line 59
    invoke-virtual {v3, v1, v2, p0, p1}, Landroid/graphics/RectF;->set(FFFF)V

    .line 60
    .line 61
    .line 62
    iget-object p0, v0, Lr6;->a:Landroid/graphics/Path;

    .line 63
    .line 64
    iget-object p1, v0, Lr6;->b:Landroid/graphics/RectF;

    .line 65
    .line 66
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 67
    .line 68
    .line 69
    sget-object v1, Landroid/graphics/Path$Direction;->CCW:Landroid/graphics/Path$Direction;

    .line 70
    .line 71
    invoke-virtual {p0, p1, v1}, Landroid/graphics/Path;->addRect(Landroid/graphics/RectF;Landroid/graphics/Path$Direction;)V

    .line 72
    .line 73
    .line 74
    invoke-static {}, Lt6;->a()Lr6;

    .line 75
    .line 76
    .line 77
    move-result-object p0

    .line 78
    const/4 p1, 0x1

    .line 79
    invoke-virtual {p0, p2, v0, p1}, Lr6;->b(Lr6;Lr6;I)Z

    .line 80
    .line 81
    .line 82
    iget-object p2, p0, Lr6;->a:Landroid/graphics/Path;

    .line 83
    .line 84
    invoke-virtual {p2}, Landroid/graphics/Path;->isEmpty()Z

    .line 85
    .line 86
    .line 87
    move-result p2

    .line 88
    invoke-virtual {p0}, Lr6;->c()V

    .line 89
    .line 90
    .line 91
    invoke-virtual {v0}, Lr6;->c()V

    .line 92
    .line 93
    .line 94
    xor-int/lit8 p0, p2, 0x1

    .line 95
    .line 96
    return p0
.end method

.method public static final n(FFFFJ)Z
    .registers 8

    .line 1
    sub-float/2addr p0, p2

    .line 2
    sub-float/2addr p1, p3

    .line 3
    const/16 p2, 0x20

    .line 4
    .line 5
    shr-long p2, p4, p2

    .line 6
    .line 7
    long-to-int p2, p2

    .line 8
    invoke-static {p2}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 9
    .line 10
    .line 11
    move-result p2

    .line 12
    const-wide v0, 0xffffffffL

    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    and-long/2addr p4, v0

    .line 18
    long-to-int p3, p4

    .line 19
    invoke-static {p3}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 20
    .line 21
    .line 22
    move-result p3

    .line 23
    mul-float/2addr p0, p0

    .line 24
    mul-float/2addr p2, p2

    .line 25
    div-float/2addr p0, p2

    .line 26
    mul-float/2addr p1, p1

    .line 27
    mul-float/2addr p3, p3

    .line 28
    div-float/2addr p1, p3

    .line 29
    add-float/2addr p1, p0

    .line 30
    const/high16 p0, 0x3f800000  # 1.0f

    .line 31
    .line 32
    cmpg-float p0, p1, p0

    .line 33
    .line 34
    if-gtz p0, :cond_25

    .line 35
    .line 36
    const/4 p0, 0x1

    .line 37
    return p0

    .line 38
    :cond_25
    const/4 p0, 0x0

    .line 39
    return p0
.end method

.method public static final o([FJ)J
    .registers 15

    .line 1
    array-length v0, p0

    .line 2
    const/16 v1, 0x10

    .line 3
    .line 4
    if-ge v0, v1, :cond_6

    .line 5
    .line 6
    return-wide p1

    .line 7
    :cond_6
    const/4 v0, 0x0

    .line 8
    aget v0, p0, v0

    .line 9
    .line 10
    const/4 v1, 0x1

    .line 11
    aget v1, p0, v1

    .line 12
    .line 13
    const/4 v2, 0x3

    .line 14
    aget v2, p0, v2

    .line 15
    .line 16
    const/4 v3, 0x4

    .line 17
    aget v3, p0, v3

    .line 18
    .line 19
    const/4 v4, 0x5

    .line 20
    aget v4, p0, v4

    .line 21
    .line 22
    const/4 v5, 0x7

    .line 23
    aget v5, p0, v5

    .line 24
    .line 25
    const/16 v6, 0xc

    .line 26
    .line 27
    aget v6, p0, v6

    .line 28
    .line 29
    const/16 v7, 0xd

    .line 30
    .line 31
    aget v7, p0, v7

    .line 32
    .line 33
    const/16 v8, 0xf

    .line 34
    .line 35
    aget p0, p0, v8

    .line 36
    .line 37
    const/16 v8, 0x20

    .line 38
    .line 39
    shr-long v9, p1, v8

    .line 40
    .line 41
    long-to-int v9, v9

    .line 42
    invoke-static {v9}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 43
    .line 44
    .line 45
    move-result v9

    .line 46
    const-wide v10, 0xffffffffL

    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    and-long/2addr p1, v10

    .line 52
    long-to-int p1, p1

    .line 53
    invoke-static {p1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 54
    .line 55
    .line 56
    move-result p1

    .line 57
    mul-float/2addr v2, v9

    .line 58
    mul-float/2addr v5, p1

    .line 59
    add-float/2addr v5, v2

    .line 60
    add-float/2addr v5, p0

    .line 61
    const/high16 p0, 0x3f800000  # 1.0f

    .line 62
    .line 63
    div-float/2addr p0, v5

    .line 64
    invoke-static {p0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 65
    .line 66
    .line 67
    move-result p2

    .line 68
    const v2, 0x7fffffff

    .line 69
    .line 70
    .line 71
    and-int/2addr p2, v2

    .line 72
    const/high16 v2, 0x7f800000  # Float.POSITIVE_INFINITY

    .line 73
    .line 74
    if-ge p2, v2, :cond_4c

    .line 75
    .line 76
    goto :goto_4d

    .line 77
    :cond_4c
    const/4 p0, 0x0

    .line 78
    :goto_4d
    mul-float/2addr v0, v9

    .line 79
    mul-float/2addr v3, p1

    .line 80
    add-float/2addr v3, v0

    .line 81
    add-float/2addr v3, v6

    .line 82
    mul-float/2addr v3, p0

    .line 83
    mul-float/2addr v1, v9

    .line 84
    mul-float/2addr v4, p1

    .line 85
    add-float/2addr v4, v1

    .line 86
    add-float/2addr v4, v7

    .line 87
    mul-float/2addr v4, p0

    .line 88
    invoke-static {v3}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 89
    .line 90
    .line 91
    move-result p0

    .line 92
    int-to-long p0, p0

    .line 93
    invoke-static {v4}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 94
    .line 95
    .line 96
    move-result p2

    .line 97
    int-to-long v0, p2

    .line 98
    shl-long/2addr p0, v8

    .line 99
    and-long/2addr v0, v10

    .line 100
    or-long/2addr p0, v0

    .line 101
    return-wide p0
.end method

.method public static final p([FLgk0;)V
    .registers 26

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    array-length v2, v0

    .line 6
    const/16 v3, 0x10

    .line 7
    .line 8
    if-ge v2, v3, :cond_a

    .line 9
    .line 10
    return-void

    .line 11
    :cond_a
    const/4 v2, 0x0

    .line 12
    aget v2, v0, v2

    .line 13
    .line 14
    const/4 v3, 0x1

    .line 15
    aget v3, v0, v3

    .line 16
    .line 17
    const/4 v4, 0x3

    .line 18
    aget v4, v0, v4

    .line 19
    .line 20
    const/4 v5, 0x4

    .line 21
    aget v5, v0, v5

    .line 22
    .line 23
    const/4 v6, 0x5

    .line 24
    aget v6, v0, v6

    .line 25
    .line 26
    const/4 v7, 0x7

    .line 27
    aget v7, v0, v7

    .line 28
    .line 29
    const/16 v8, 0xc

    .line 30
    .line 31
    aget v8, v0, v8

    .line 32
    .line 33
    const/16 v9, 0xd

    .line 34
    .line 35
    aget v9, v0, v9

    .line 36
    .line 37
    const/16 v10, 0xf

    .line 38
    .line 39
    aget v0, v0, v10

    .line 40
    .line 41
    iget v10, v1, Lgk0;->a:F

    .line 42
    .line 43
    iget v11, v1, Lgk0;->b:F

    .line 44
    .line 45
    iget v12, v1, Lgk0;->c:F

    .line 46
    .line 47
    iget v13, v1, Lgk0;->d:F

    .line 48
    .line 49
    mul-float v14, v4, v10

    .line 50
    .line 51
    mul-float v15, v7, v11

    .line 52
    .line 53
    add-float v16, v14, v15

    .line 54
    .line 55
    add-float v16, v16, v0

    .line 56
    .line 57
    const/high16 v17, 0x3f800000  # 1.0f

    .line 58
    .line 59
    div-float v16, v17, v16

    .line 60
    .line 61
    invoke-static/range {v16 .. v16}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 62
    .line 63
    .line 64
    move-result v18

    .line 65
    const v19, 0x7fffffff

    .line 66
    .line 67
    .line 68
    move/from16 p0, v0

    .line 69
    .line 70
    and-int v0, v18, v19

    .line 71
    .line 72
    const/16 v18, 0x0

    .line 73
    .line 74
    move/from16 v20, v2

    .line 75
    .line 76
    const/high16 v2, 0x7f800000  # Float.POSITIVE_INFINITY

    .line 77
    .line 78
    if-ge v0, v2, :cond_50

    .line 79
    .line 80
    goto :goto_52

    .line 81
    :cond_50
    move/from16 v16, v18

    .line 82
    .line 83
    :goto_52
    mul-float v0, v20, v10

    .line 84
    .line 85
    mul-float v21, v5, v11

    .line 86
    .line 87
    add-float v22, v0, v21

    .line 88
    .line 89
    add-float v22, v22, v8

    .line 90
    .line 91
    mul-float v2, v22, v16

    .line 92
    .line 93
    mul-float/2addr v10, v3

    .line 94
    mul-float/2addr v11, v6

    .line 95
    add-float v22, v10, v11

    .line 96
    .line 97
    add-float v22, v22, v9

    .line 98
    .line 99
    move/from16 v23, v0

    .line 100
    .line 101
    mul-float v0, v22, v16

    .line 102
    .line 103
    mul-float/2addr v7, v13

    .line 104
    add-float/2addr v14, v7

    .line 105
    add-float v14, v14, p0

    .line 106
    .line 107
    div-float v14, v17, v14

    .line 108
    .line 109
    invoke-static {v14}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 110
    .line 111
    .line 112
    move-result v16

    .line 113
    move/from16 v22, v3

    .line 114
    .line 115
    and-int v3, v16, v19

    .line 116
    .line 117
    move/from16 v16, v4

    .line 118
    .line 119
    const/high16 v4, 0x7f800000  # Float.POSITIVE_INFINITY

    .line 120
    .line 121
    if-ge v3, v4, :cond_7b

    .line 122
    .line 123
    goto :goto_7d

    .line 124
    :cond_7b
    move/from16 v14, v18

    .line 125
    .line 126
    :goto_7d
    mul-float/2addr v5, v13

    .line 127
    add-float v3, v23, v5

    .line 128
    .line 129
    add-float/2addr v3, v8

    .line 130
    mul-float/2addr v3, v14

    .line 131
    mul-float/2addr v6, v13

    .line 132
    add-float/2addr v10, v6

    .line 133
    add-float/2addr v10, v9

    .line 134
    mul-float/2addr v10, v14

    .line 135
    mul-float v4, v16, v12

    .line 136
    .line 137
    add-float/2addr v15, v4

    .line 138
    add-float v15, v15, p0

    .line 139
    .line 140
    div-float v13, v17, v15

    .line 141
    .line 142
    invoke-static {v13}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 143
    .line 144
    .line 145
    move-result v14

    .line 146
    and-int v14, v14, v19

    .line 147
    .line 148
    const/high16 v15, 0x7f800000  # Float.POSITIVE_INFINITY

    .line 149
    .line 150
    if-ge v14, v15, :cond_98

    .line 151
    .line 152
    goto :goto_9a

    .line 153
    :cond_98
    move/from16 v13, v18

    .line 154
    .line 155
    :goto_9a
    mul-float v14, v20, v12

    .line 156
    .line 157
    add-float v21, v14, v21

    .line 158
    .line 159
    add-float v21, v21, v8

    .line 160
    .line 161
    mul-float v15, v21, v13

    .line 162
    .line 163
    mul-float v12, v12, v22

    .line 164
    .line 165
    add-float/2addr v11, v12

    .line 166
    add-float/2addr v11, v9

    .line 167
    mul-float/2addr v11, v13

    .line 168
    add-float/2addr v4, v7

    .line 169
    add-float v4, v4, p0

    .line 170
    .line 171
    div-float v17, v17, v4

    .line 172
    .line 173
    invoke-static/range {v17 .. v17}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 174
    .line 175
    .line 176
    move-result v4

    .line 177
    and-int v4, v4, v19

    .line 178
    .line 179
    const/high16 v7, 0x7f800000  # Float.POSITIVE_INFINITY

    .line 180
    .line 181
    if-ge v4, v7, :cond_b8

    .line 182
    .line 183
    move/from16 v18, v17

    .line 184
    .line 185
    :cond_b8
    add-float/2addr v14, v5

    .line 186
    add-float/2addr v14, v8

    .line 187
    mul-float v14, v14, v18

    .line 188
    .line 189
    add-float/2addr v12, v6

    .line 190
    add-float/2addr v12, v9

    .line 191
    mul-float v12, v12, v18

    .line 192
    .line 193
    invoke-static {v15, v14}, Ljava/lang/Math;->min(FF)F

    .line 194
    .line 195
    .line 196
    move-result v4

    .line 197
    invoke-static {v3, v4}, Ljava/lang/Math;->min(FF)F

    .line 198
    .line 199
    .line 200
    move-result v4

    .line 201
    invoke-static {v2, v4}, Ljava/lang/Math;->min(FF)F

    .line 202
    .line 203
    .line 204
    move-result v4

    .line 205
    iput v4, v1, Lgk0;->a:F

    .line 206
    .line 207
    invoke-static {v11, v12}, Ljava/lang/Math;->min(FF)F

    .line 208
    .line 209
    .line 210
    move-result v4

    .line 211
    invoke-static {v10, v4}, Ljava/lang/Math;->min(FF)F

    .line 212
    .line 213
    .line 214
    move-result v4

    .line 215
    invoke-static {v0, v4}, Ljava/lang/Math;->min(FF)F

    .line 216
    .line 217
    .line 218
    move-result v4

    .line 219
    iput v4, v1, Lgk0;->b:F

    .line 220
    .line 221
    invoke-static {v15, v14}, Ljava/lang/Math;->max(FF)F

    .line 222
    .line 223
    .line 224
    move-result v4

    .line 225
    invoke-static {v3, v4}, Ljava/lang/Math;->max(FF)F

    .line 226
    .line 227
    .line 228
    move-result v3

    .line 229
    invoke-static {v2, v3}, Ljava/lang/Math;->max(FF)F

    .line 230
    .line 231
    .line 232
    move-result v2

    .line 233
    iput v2, v1, Lgk0;->c:F

    .line 234
    .line 235
    invoke-static {v11, v12}, Ljava/lang/Math;->max(FF)F

    .line 236
    .line 237
    .line 238
    move-result v2

    .line 239
    invoke-static {v10, v2}, Ljava/lang/Math;->max(FF)F

    .line 240
    .line 241
    .line 242
    move-result v2

    .line 243
    invoke-static {v0, v2}, Ljava/lang/Math;->max(FF)F

    .line 244
    .line 245
    .line 246
    move-result v0

    .line 247
    iput v0, v1, Lgk0;->d:F

    .line 248
    .line 249
    return-void
.end method

.method public static final q(Lqy0;IIIIILoh0;Ljava/util/List;[Lks0;II[II)Lnh0;
    .registers 36

    move-object/from16 v0, p0

    move/from16 v1, p3

    move/from16 v2, p4

    move/from16 v3, p5

    move-object/from16 v4, p7

    move/from16 v9, p10

    int-to-long v5, v3

    sub-int v7, v9, p9

    .line 1
    new-array v8, v7, [I

    move/from16 v12, p9

    const/4 v10, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    :goto_1b
    if-ge v12, v9, :cond_8e

    .line 2
    invoke-interface {v4, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v18

    move-object/from16 v11, v18

    check-cast v11, Lhh0;

    .line 3
    invoke-static {v11}, Lwc0;->k(Lhh0;)Lry0;

    move-result-object v18

    .line 4
    invoke-static/range {v18 .. v18}, Lwc0;->l(Lry0;)F

    move-result v18

    cmpl-float v19, v18, v17

    if-lez v19, :cond_3a

    add-float v16, v16, v18

    add-int/lit8 v13, v13, 0x1

    move-wide/from16 v19, v5

    move/from16 v21, v12

    goto :goto_89

    :cond_3a
    sub-int v15, v1, v14

    .line 5
    aget-object v18, p8, v12

    move-wide/from16 v19, v5

    if-nez v18, :cond_65

    const v5, 0x7fffffff

    if-ne v1, v5, :cond_50

    move/from16 v21, v12

    move/from16 v22, v13

    const v5, 0x7fffffff

    :goto_4e
    const/4 v6, 0x0

    goto :goto_5a

    :cond_50
    move/from16 v21, v12

    move/from16 v22, v13

    if-gez v15, :cond_58

    const/4 v5, 0x0

    goto :goto_4e

    :cond_58
    move v5, v15

    goto :goto_4e

    .line 6
    :goto_5a
    invoke-interface {v0, v6, v5, v2, v6}, Lqy0;->d(IIIZ)J

    move-result-wide v12

    .line 7
    invoke-interface {v11, v12, v13}, Lhh0;->e(J)Lks0;

    move-result-object v18

    :goto_62
    move-object/from16 v5, v18

    goto :goto_6a

    :cond_65
    move/from16 v21, v12

    move/from16 v22, v13

    goto :goto_62

    .line 8
    :goto_6a
    invoke-interface {v0, v5}, Lqy0;->h(Lks0;)I

    move-result v6

    .line 9
    invoke-interface {v0, v5}, Lqy0;->e(Lks0;)I

    move-result v11

    sub-int v12, v21, p9

    .line 10
    aput v6, v8, v12

    sub-int v12, v15, v6

    if-gez v12, :cond_7b

    const/4 v12, 0x0

    .line 11
    :cond_7b
    invoke-static {v3, v12}, Ljava/lang/Math;->min(II)I

    move-result v15

    add-int/2addr v6, v15

    add-int/2addr v14, v6

    .line 12
    invoke-static {v10, v11}, Ljava/lang/Math;->max(II)I

    move-result v10

    .line 13
    aput-object v5, p8, v21

    move/from16 v13, v22

    :goto_89
    add-int/lit8 v12, v21, 0x1

    move-wide/from16 v5, v19

    goto :goto_1b

    :cond_8e
    move-wide/from16 v19, v5

    move/from16 v22, v13

    if-nez v22, :cond_98

    sub-int/2addr v14, v15

    const/4 v6, 0x0

    goto/16 :goto_15f

    :cond_98
    const v5, 0x7fffffff

    if-eq v1, v5, :cond_9f

    move v3, v1

    goto :goto_a1

    :cond_9f
    move/from16 v3, p1

    :goto_a1
    const/4 v5, 0x1

    add-int/lit8 v13, v22, -0x1

    int-to-long v11, v13

    mul-long v11, v11, v19

    sub-int/2addr v3, v14

    int-to-long v5, v3

    sub-long/2addr v5, v11

    const-wide/16 v19, 0x0

    cmp-long v3, v5, v19

    if-gez v3, :cond_b2

    move-wide/from16 v5, v19

    :cond_b2
    long-to-float v3, v5

    div-float v3, v3, v16

    move/from16 v13, p9

    :goto_b7
    if-ge v13, v9, :cond_d4

    .line 14
    invoke-interface {v4, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lhh0;

    .line 15
    invoke-static {v15}, Lwc0;->k(Lhh0;)Lry0;

    move-result-object v15

    invoke-static {v15}, Lwc0;->l(Lry0;)F

    move-result v15

    mul-float/2addr v15, v3

    .line 16
    invoke-static {v15}, Ljava/lang/Math;->round(F)I

    move-result v15

    move-wide/from16 v19, v5

    int-to-long v5, v15

    sub-long v5, v19, v5

    add-int/lit8 v13, v13, 0x1

    goto :goto_b7

    :cond_d4
    move-wide/from16 v19, v5

    move/from16 v15, p9

    move v13, v10

    const/4 v10, 0x0

    :goto_da
    if-ge v15, v9, :cond_153

    .line 17
    aget-object v16, p8, v15

    if-nez v16, :cond_145

    .line 18
    invoke-interface {v4, v15}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v16

    move-object/from16 v1, v16

    check-cast v1, Lhh0;

    move/from16 v16, v3

    .line 19
    invoke-static {v1}, Lwc0;->k(Lhh0;)Lry0;

    move-result-object v3

    .line 20
    invoke-static {v3}, Lwc0;->l(Lry0;)F

    move-result v18

    cmpl-float v19, v18, v17

    if-lez v19, :cond_f7

    goto :goto_fc

    .line 21
    :cond_f7
    const-string v19, "All weights <= 0 should have placeables"

    .line 22
    invoke-static/range {v19 .. v19}, Ln50;->b(Ljava/lang/String;)V

    .line 23
    :goto_fc
    invoke-static {v5, v6}, Ljava/lang/Long;->signum(J)I

    move-result v4

    move-wide/from16 v19, v5

    int-to-long v5, v4

    sub-long v5, v19, v5

    mul-float v18, v18, v16

    .line 24
    invoke-static/range {v18 .. v18}, Ljava/lang/Math;->round(F)I

    move-result v18

    add-int v4, v18, v4

    move-wide/from16 v19, v5

    const/4 v5, 0x0

    .line 25
    invoke-static {v5, v4}, Ljava/lang/Math;->max(II)I

    move-result v6

    if-eqz v3, :cond_119

    .line 26
    iget-boolean v3, v3, Lry0;->b:Z

    goto :goto_11a

    :cond_119
    const/4 v3, 0x1

    :goto_11a
    const v5, 0x7fffffff

    if-eqz v3, :cond_124

    if-eq v6, v5, :cond_124

    move v3, v6

    :goto_122
    const/4 v4, 0x1

    goto :goto_126

    :cond_124
    const/4 v3, 0x0

    goto :goto_122

    .line 27
    :goto_126
    invoke-interface {v0, v3, v6, v2, v4}, Lqy0;->d(IIIZ)J

    move-result-wide v5

    .line 28
    invoke-interface {v1, v5, v6}, Lhh0;->e(J)Lks0;

    move-result-object v1

    .line 29
    invoke-interface {v0, v1}, Lqy0;->h(Lks0;)I

    move-result v3

    .line 30
    invoke-interface {v0, v1}, Lqy0;->e(Lks0;)I

    move-result v5

    sub-int v6, v15, p9

    .line 31
    aput v3, v8, v6

    add-int/2addr v10, v3

    .line 32
    invoke-static {v13, v5}, Ljava/lang/Math;->max(II)I

    move-result v3

    .line 33
    aput-object v1, p8, v15

    move v13, v3

    move-wide/from16 v5, v19

    goto :goto_14a

    :cond_145
    move/from16 v16, v3

    move-wide/from16 v19, v5

    const/4 v4, 0x1

    :goto_14a
    add-int/lit8 v15, v15, 0x1

    move/from16 v1, p3

    move-object/from16 v4, p7

    move/from16 v3, v16

    goto :goto_da

    :cond_153
    int-to-long v1, v10

    add-long/2addr v1, v11

    long-to-int v6, v1

    sub-int v1, p3, v14

    if-gez v6, :cond_15b

    const/4 v6, 0x0

    :cond_15b
    if-le v6, v1, :cond_15e

    move v6, v1

    :cond_15e
    move v10, v13

    :goto_15f
    add-int/2addr v6, v14

    if-gez v6, :cond_163

    const/4 v6, 0x0

    :cond_163
    move/from16 v1, p1

    .line 34
    invoke-static {v6, v1}, Ljava/lang/Math;->max(II)I

    move-result v4

    move/from16 v1, p2

    const/4 v5, 0x0

    .line 35
    invoke-static {v1, v5}, Ljava/lang/Math;->max(II)I

    move-result v1

    invoke-static {v10, v1}, Ljava/lang/Math;->max(II)I

    move-result v5

    .line 36
    new-array v3, v7, [I

    move-object/from16 v2, p6

    .line 37
    invoke-interface {v0, v4, v2, v8, v3}, Lqy0;->b(ILoh0;[I[I)V

    move-object/from16 v1, p8

    move/from16 v8, p9

    move-object/from16 v6, p11

    move/from16 v7, p12

    .line 38
    invoke-interface/range {v0 .. v9}, Lqy0;->j([Lks0;Loh0;[III[IIII)Lnh0;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic r(Lqy0;IIIIILoh0;Ljava/util/List;[Lks0;I)Lnh0;
    .registers 23

    .line 1
    const/4 v9, 0x0

    .line 2
    const/4 v12, 0x0

    .line 3
    const/4 v11, 0x0

    .line 4
    move-object v0, p0

    .line 5
    move v1, p1

    .line 6
    move v2, p2

    .line 7
    move/from16 v3, p3

    .line 8
    .line 9
    move/from16 v4, p4

    .line 10
    .line 11
    move/from16 v5, p5

    .line 12
    .line 13
    move-object/from16 v6, p6

    .line 14
    .line 15
    move-object/from16 v7, p7

    .line 16
    .line 17
    move-object/from16 v8, p8

    .line 18
    .line 19
    move/from16 v10, p9

    .line 20
    .line 21
    invoke-static/range {v0 .. v12}, Ldd0;->q(Lqy0;IIIIILoh0;Ljava/util/List;[Lks0;II[II)Lnh0;

    .line 22
    .line 23
    .line 24
    move-result-object p0

    .line 25
    return-object p0
.end method

.method public static final s(Landroid/view/ViewStructure;Lba0;Landroid/view/autofill/AutofillId;Ljava/lang/String;Liw0;)V
    .registers 43

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    sget-object v2, Ln21;->a:Lq21;

    .line 6
    .line 7
    sget-object v2, Lc21;->a:Lq21;

    .line 8
    .line 9
    invoke-virtual {v1}, Lba0;->x()Ld21;

    .line 10
    .line 11
    .line 12
    move-result-object v2

    .line 13
    const/4 v8, 0x2

    .line 14
    const/16 v11, 0x8

    .line 15
    .line 16
    const/4 v14, 0x1

    .line 17
    if-eqz v2, :cond_1a0

    .line 18
    .line 19
    iget-object v2, v2, Ld21;->e:Lhk0;

    .line 20
    .line 21
    if-eqz v2, :cond_1a0

    .line 22
    .line 23
    iget-object v15, v2, Lhk0;->b:[Ljava/lang/Object;

    .line 24
    .line 25
    const-wide/16 v16, 0x80

    .line 26
    .line 27
    iget-object v3, v2, Lhk0;->c:[Ljava/lang/Object;

    .line 28
    .line 29
    iget-object v2, v2, Lhk0;->a:[J

    .line 30
    .line 31
    array-length v4, v2

    .line 32
    sub-int/2addr v4, v8

    .line 33
    move/from16 v31, v8

    .line 34
    .line 35
    if-ltz v4, :cond_179

    .line 36
    .line 37
    move/from16 v28, v14

    .line 38
    .line 39
    const/4 v5, 0x0

    .line 40
    const/4 v6, 0x0

    .line 41
    const-wide/16 v18, 0xff

    .line 42
    .line 43
    const/16 v20, 0x0

    .line 44
    .line 45
    const/16 v21, 0x0

    .line 46
    .line 47
    const/16 v22, 0x0

    .line 48
    .line 49
    const/16 v23, 0x0

    .line 50
    .line 51
    const/16 v24, 0x0

    .line 52
    .line 53
    const/16 v25, 0x0

    .line 54
    .line 55
    const/16 v26, 0x0

    .line 56
    .line 57
    const/16 v27, 0x0

    .line 58
    .line 59
    const/16 v29, 0x0

    .line 60
    .line 61
    const/16 v30, 0x7

    .line 62
    .line 63
    :goto_3e
    aget-wide v7, v2, v5

    .line 64
    .line 65
    const-wide v32, -0x7f7f7f7f7f7f7f80L  # -2.937446524422997E-306

    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    not-long v9, v7

    .line 71
    shl-long v9, v9, v30

    .line 72
    .line 73
    and-long/2addr v9, v7

    .line 74
    and-long v9, v9, v32

    .line 75
    .line 76
    cmp-long v9, v9, v32

    .line 77
    .line 78
    if-eqz v9, :cond_173

    .line 79
    .line 80
    sub-int v9, v5, v4

    .line 81
    .line 82
    not-int v9, v9

    .line 83
    ushr-int/lit8 v9, v9, 0x1f

    .line 84
    .line 85
    rsub-int/lit8 v9, v9, 0x8

    .line 86
    .line 87
    const/4 v10, 0x0

    .line 88
    :goto_57
    if-ge v10, v9, :cond_171

    .line 89
    .line 90
    and-long v34, v7, v18

    .line 91
    .line 92
    cmp-long v34, v34, v16

    .line 93
    .line 94
    if-gez v34, :cond_16c

    .line 95
    .line 96
    shl-int/lit8 v34, v5, 0x3

    .line 97
    .line 98
    add-int v34, v34, v10

    .line 99
    .line 100
    aget-object v35, v15, v34

    .line 101
    .line 102
    aget-object v34, v3, v34

    .line 103
    .line 104
    move-object/from16 v12, v35

    .line 105
    .line 106
    check-cast v12, Lq21;

    .line 107
    .line 108
    sget-object v13, Ln21;->s:Lq21;

    .line 109
    .line 110
    invoke-static {v12, v13}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 111
    .line 112
    .line 113
    move-result v13

    .line 114
    if-eqz v13, :cond_7c

    .line 115
    .line 116
    invoke-virtual/range {v34 .. v34}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 117
    .line 118
    .line 119
    move-object/from16 v6, v34

    .line 120
    .line 121
    check-cast v6, Li5;

    .line 122
    .line 123
    goto/16 :goto_16c

    .line 124
    .line 125
    :cond_7c
    sget-object v13, Ln21;->a:Lq21;

    .line 126
    .line 127
    invoke-static {v12, v13}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 128
    .line 129
    .line 130
    move-result v13

    .line 131
    if-eqz v13, :cond_96

    .line 132
    .line 133
    invoke-virtual/range {v34 .. v34}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 134
    .line 135
    .line 136
    check-cast v34, Ljava/util/List;

    .line 137
    .line 138
    invoke-static/range {v34 .. v34}, Ltg;->R(Ljava/util/List;)Ljava/lang/Object;

    .line 139
    .line 140
    .line 141
    move-result-object v12

    .line 142
    check-cast v12, Ljava/lang/String;

    .line 143
    .line 144
    if-eqz v12, :cond_16c

    .line 145
    .line 146
    invoke-virtual {v0, v12}, Landroid/view/ViewStructure;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 147
    .line 148
    .line 149
    goto/16 :goto_16c

    .line 150
    .line 151
    :cond_96
    sget-object v13, Ln21;->r:Lq21;

    .line 152
    .line 153
    invoke-static {v12, v13}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 154
    .line 155
    .line 156
    move-result v13

    .line 157
    if-eqz v13, :cond_a7

    .line 158
    .line 159
    invoke-virtual/range {v34 .. v34}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 160
    .line 161
    .line 162
    move-object/from16 v24, v34

    .line 163
    .line 164
    check-cast v24, Ljl;

    .line 165
    .line 166
    goto/16 :goto_16c

    .line 167
    .line 168
    :cond_a7
    sget-object v13, Ln21;->t:Lq21;

    .line 169
    .line 170
    invoke-static {v12, v13}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 171
    .line 172
    .line 173
    move-result v13

    .line 174
    if-eqz v13, :cond_b8

    .line 175
    .line 176
    invoke-virtual/range {v34 .. v34}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 177
    .line 178
    .line 179
    move-object/from16 v23, v34

    .line 180
    .line 181
    check-cast v23, La6;

    .line 182
    .line 183
    goto/16 :goto_16c

    .line 184
    .line 185
    :cond_b8
    sget-object v13, Ln21;->F:Lq21;

    .line 186
    .line 187
    invoke-static {v12, v13}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 188
    .line 189
    .line 190
    move-result v13

    .line 191
    if-eqz v13, :cond_c9

    .line 192
    .line 193
    invoke-virtual/range {v34 .. v34}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 194
    .line 195
    .line 196
    move-object/from16 v22, v34

    .line 197
    .line 198
    check-cast v22, Lx8;

    .line 199
    .line 200
    goto/16 :goto_16c

    .line 201
    .line 202
    :cond_c9
    sget-object v13, Ln21;->l:Lq21;

    .line 203
    .line 204
    invoke-static {v12, v13}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 205
    .line 206
    .line 207
    move-result v13

    .line 208
    if-eqz v13, :cond_df

    .line 209
    .line 210
    invoke-virtual/range {v34 .. v34}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 211
    .line 212
    .line 213
    check-cast v34, Ljava/lang/Boolean;

    .line 214
    .line 215
    invoke-virtual/range {v34 .. v34}, Ljava/lang/Boolean;->booleanValue()Z

    .line 216
    .line 217
    .line 218
    move-result v12

    .line 219
    invoke-virtual {v0, v12}, Landroid/view/ViewStructure;->setFocused(Z)V

    .line 220
    .line 221
    .line 222
    goto/16 :goto_16c

    .line 223
    .line 224
    :cond_df
    sget-object v13, Ln21;->N:Lq21;

    .line 225
    .line 226
    invoke-static {v12, v13}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 227
    .line 228
    .line 229
    move-result v13

    .line 230
    if-eqz v13, :cond_f0

    .line 231
    .line 232
    invoke-virtual/range {v34 .. v34}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 233
    .line 234
    .line 235
    move-object/from16 v29, v34

    .line 236
    .line 237
    check-cast v29, Ljava/lang/Integer;

    .line 238
    .line 239
    goto/16 :goto_16c

    .line 240
    .line 241
    :cond_f0
    sget-object v13, Ln21;->J:Lq21;

    .line 242
    .line 243
    invoke-static {v12, v13}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 244
    .line 245
    .line 246
    move-result v13

    .line 247
    if-eqz v13, :cond_fc

    .line 248
    .line 249
    move/from16 v27, v14

    .line 250
    .line 251
    goto/16 :goto_16c

    .line 252
    .line 253
    :cond_fc
    sget-object v13, Ln21;->o:Lq21;

    .line 254
    .line 255
    invoke-static {v12, v13}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 256
    .line 257
    .line 258
    move-result v13

    .line 259
    if-eqz v13, :cond_10e

    .line 260
    .line 261
    invoke-virtual/range {v34 .. v34}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 262
    .line 263
    .line 264
    check-cast v34, Ljava/lang/Boolean;

    .line 265
    .line 266
    invoke-virtual/range {v34 .. v34}, Ljava/lang/Boolean;->booleanValue()Z

    .line 267
    .line 268
    .line 269
    move-result v28

    .line 270
    goto :goto_16c

    .line 271
    :cond_10e
    sget-object v13, Ln21;->y:Lq21;

    .line 272
    .line 273
    invoke-static {v12, v13}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 274
    .line 275
    .line 276
    move-result v13

    .line 277
    if-eqz v13, :cond_11e

    .line 278
    .line 279
    invoke-virtual/range {v34 .. v34}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 280
    .line 281
    .line 282
    move-object/from16 v26, v34

    .line 283
    .line 284
    check-cast v26, Liy0;

    .line 285
    .line 286
    goto :goto_16c

    .line 287
    :cond_11e
    sget-object v13, Ln21;->H:Lq21;

    .line 288
    .line 289
    invoke-static {v12, v13}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 290
    .line 291
    .line 292
    move-result v13

    .line 293
    if-eqz v13, :cond_12e

    .line 294
    .line 295
    invoke-virtual/range {v34 .. v34}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 296
    .line 297
    .line 298
    move-object/from16 v25, v34

    .line 299
    .line 300
    check-cast v25, Ljava/lang/Boolean;

    .line 301
    .line 302
    goto :goto_16c

    .line 303
    :cond_12e
    sget-object v13, Ln21;->I:Lq21;

    .line 304
    .line 305
    invoke-static {v12, v13}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 306
    .line 307
    .line 308
    move-result v13

    .line 309
    if-eqz v13, :cond_13e

    .line 310
    .line 311
    invoke-virtual/range {v34 .. v34}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 312
    .line 313
    .line 314
    move-object/from16 v21, v34

    .line 315
    .line 316
    check-cast v21, Loc1;

    .line 317
    .line 318
    goto :goto_16c

    .line 319
    :cond_13e
    sget-object v13, Lc21;->b:Lq21;

    .line 320
    .line 321
    invoke-static {v12, v13}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 322
    .line 323
    .line 324
    move-result v13

    .line 325
    if-eqz v13, :cond_14a

    .line 326
    .line 327
    invoke-virtual {v0, v14}, Landroid/view/ViewStructure;->setClickable(Z)V

    .line 328
    .line 329
    .line 330
    goto :goto_16c

    .line 331
    :cond_14a
    sget-object v13, Lc21;->c:Lq21;

    .line 332
    .line 333
    invoke-static {v12, v13}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 334
    .line 335
    .line 336
    move-result v13

    .line 337
    if-eqz v13, :cond_156

    .line 338
    .line 339
    invoke-virtual {v0, v14}, Landroid/view/ViewStructure;->setLongClickable(Z)V

    .line 340
    .line 341
    .line 342
    goto :goto_16c

    .line 343
    :cond_156
    sget-object v13, Lc21;->v:Lq21;

    .line 344
    .line 345
    invoke-static {v12, v13}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 346
    .line 347
    .line 348
    move-result v13

    .line 349
    if-eqz v13, :cond_162

    .line 350
    .line 351
    invoke-virtual {v0, v14}, Landroid/view/ViewStructure;->setFocusable(Z)V

    .line 352
    .line 353
    .line 354
    goto :goto_16c

    .line 355
    :cond_162
    sget-object v13, Lc21;->k:Lq21;

    .line 356
    .line 357
    invoke-static {v12, v13}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 358
    .line 359
    .line 360
    move-result v12

    .line 361
    if-eqz v12, :cond_16c

    .line 362
    .line 363
    move/from16 v20, v14

    .line 364
    .line 365
    :cond_16c
    :goto_16c
    shr-long/2addr v7, v11

    .line 366
    add-int/lit8 v10, v10, 0x1

    .line 367
    .line 368
    goto/16 :goto_57

    .line 369
    .line 370
    :cond_171
    if-ne v9, v11, :cond_197

    .line 371
    .line 372
    :cond_173
    if-eq v5, v4, :cond_197

    .line 373
    .line 374
    add-int/lit8 v5, v5, 0x1

    .line 375
    .line 376
    goto/16 :goto_3e

    .line 377
    .line 378
    :cond_179
    const-wide/16 v18, 0xff

    .line 379
    .line 380
    const/16 v30, 0x7

    .line 381
    .line 382
    const-wide v32, -0x7f7f7f7f7f7f7f80L  # -2.937446524422997E-306

    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    move/from16 v28, v14

    .line 388
    .line 389
    const/4 v6, 0x0

    .line 390
    const/16 v20, 0x0

    .line 391
    .line 392
    const/16 v21, 0x0

    .line 393
    .line 394
    const/16 v22, 0x0

    .line 395
    .line 396
    const/16 v23, 0x0

    .line 397
    .line 398
    const/16 v24, 0x0

    .line 399
    .line 400
    const/16 v25, 0x0

    .line 401
    .line 402
    const/16 v26, 0x0

    .line 403
    .line 404
    const/16 v27, 0x0

    .line 405
    .line 406
    const/16 v29, 0x0

    .line 407
    .line 408
    :cond_197
    move-object/from16 v2, v21

    .line 409
    .line 410
    move-object/from16 v3, v22

    .line 411
    .line 412
    move-object/from16 v4, v23

    .line 413
    .line 414
    move-object/from16 v5, v26

    .line 415
    .line 416
    goto :goto_1be

    .line 417
    :cond_1a0
    move/from16 v31, v8

    .line 418
    .line 419
    const-wide/16 v16, 0x80

    .line 420
    .line 421
    const-wide/16 v18, 0xff

    .line 422
    .line 423
    const/16 v30, 0x7

    .line 424
    .line 425
    const-wide v32, -0x7f7f7f7f7f7f7f80L  # -2.937446524422997E-306

    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    move/from16 v28, v14

    .line 431
    .line 432
    const/4 v2, 0x0

    .line 433
    const/4 v3, 0x0

    .line 434
    const/4 v4, 0x0

    .line 435
    const/4 v5, 0x0

    .line 436
    const/4 v6, 0x0

    .line 437
    const/16 v20, 0x0

    .line 438
    .line 439
    const/16 v24, 0x0

    .line 440
    .line 441
    const/16 v25, 0x0

    .line 442
    .line 443
    const/16 v27, 0x0

    .line 444
    .line 445
    const/16 v29, 0x0

    .line 446
    .line 447
    :goto_1be
    invoke-virtual {v1}, Lba0;->x()Ld21;

    .line 448
    .line 449
    .line 450
    move-result-object v7

    .line 451
    if-eqz v7, :cond_210

    .line 452
    .line 453
    iget-boolean v8, v7, Ld21;->g:Z

    .line 454
    .line 455
    if-eqz v8, :cond_210

    .line 456
    .line 457
    iget-boolean v8, v7, Ld21;->h:Z

    .line 458
    .line 459
    if-eqz v8, :cond_1cd

    .line 460
    .line 461
    goto :goto_210

    .line 462
    :cond_1cd
    invoke-virtual {v7}, Ld21;->b()Ld21;

    .line 463
    .line 464
    .line 465
    move-result-object v7

    .line 466
    new-instance v8, Lak0;

    .line 467
    .line 468
    invoke-virtual {v1}, Lba0;->n()Ljava/util/List;

    .line 469
    .line 470
    .line 471
    move-result-object v9

    .line 472
    check-cast v9, Lnk0;

    .line 473
    .line 474
    iget-object v9, v9, Lnk0;->e:Lqk0;

    .line 475
    .line 476
    iget v9, v9, Lqk0;->g:I

    .line 477
    .line 478
    invoke-direct {v8, v9}, Lak0;-><init>(I)V

    .line 479
    .line 480
    .line 481
    invoke-virtual {v1}, Lba0;->n()Ljava/util/List;

    .line 482
    .line 483
    .line 484
    move-result-object v9

    .line 485
    invoke-virtual {v8, v9}, Lak0;->c(Ljava/util/List;)V

    .line 486
    .line 487
    .line 488
    :cond_1e7
    :goto_1e7
    invoke-virtual {v8}, Lak0;->i()Z

    .line 489
    .line 490
    .line 491
    move-result v9

    .line 492
    if-eqz v9, :cond_210

    .line 493
    .line 494
    iget v9, v8, Lak0;->b:I

    .line 495
    .line 496
    sub-int/2addr v9, v14

    .line 497
    invoke-virtual {v8, v9}, Lak0;->k(I)Ljava/lang/Object;

    .line 498
    .line 499
    .line 500
    move-result-object v9

    .line 501
    check-cast v9, Lba0;

    .line 502
    .line 503
    invoke-virtual {v9}, Lba0;->x()Ld21;

    .line 504
    .line 505
    .line 506
    move-result-object v10

    .line 507
    if-eqz v10, :cond_1e7

    .line 508
    .line 509
    iget-boolean v12, v10, Ld21;->g:Z

    .line 510
    .line 511
    if-eqz v12, :cond_201

    .line 512
    .line 513
    goto :goto_1e7

    .line 514
    :cond_201
    invoke-virtual {v7, v10}, Ld21;->e(Ld21;)V

    .line 515
    .line 516
    .line 517
    iget-boolean v10, v10, Ld21;->h:Z

    .line 518
    .line 519
    if-nez v10, :cond_1e7

    .line 520
    .line 521
    invoke-virtual {v9}, Lba0;->n()Ljava/util/List;

    .line 522
    .line 523
    .line 524
    move-result-object v9

    .line 525
    invoke-virtual {v8, v9}, Lak0;->c(Ljava/util/List;)V

    .line 526
    .line 527
    .line 528
    goto :goto_1e7

    .line 529
    :cond_210
    :goto_210
    if-eqz v7, :cond_29b

    .line 530
    .line 531
    iget-object v7, v7, Ld21;->e:Lhk0;

    .line 532
    .line 533
    if-eqz v7, :cond_29b

    .line 534
    .line 535
    iget-object v8, v7, Lhk0;->b:[Ljava/lang/Object;

    .line 536
    .line 537
    iget-object v9, v7, Lhk0;->c:[Ljava/lang/Object;

    .line 538
    .line 539
    iget-object v7, v7, Lhk0;->a:[J

    .line 540
    .line 541
    array-length v10, v7

    .line 542
    add-int/lit8 v10, v10, -0x2

    .line 543
    .line 544
    move/from16 v21, v14

    .line 545
    .line 546
    if-ltz v10, :cond_29d

    .line 547
    .line 548
    const/4 v12, 0x0

    .line 549
    const/4 v13, 0x0

    .line 550
    :goto_225
    aget-wide v14, v7, v12

    .line 551
    .line 552
    move/from16 v22, v11

    .line 553
    .line 554
    move/from16 v23, v12

    .line 555
    .line 556
    not-long v11, v14

    .line 557
    shl-long v11, v11, v30

    .line 558
    .line 559
    and-long/2addr v11, v14

    .line 560
    and-long v11, v11, v32

    .line 561
    .line 562
    cmp-long v11, v11, v32

    .line 563
    .line 564
    if-eqz v11, :cond_28a

    .line 565
    .line 566
    sub-int v12, v23, v10

    .line 567
    .line 568
    not-int v11, v12

    .line 569
    ushr-int/lit8 v11, v11, 0x1f

    .line 570
    .line 571
    rsub-int/lit8 v11, v11, 0x8

    .line 572
    .line 573
    const/4 v12, 0x0

    .line 574
    :goto_23d
    if-ge v12, v11, :cond_27f

    .line 575
    .line 576
    and-long v36, v14, v18

    .line 577
    .line 578
    cmp-long v26, v36, v16

    .line 579
    .line 580
    if-gez v26, :cond_272

    .line 581
    .line 582
    shl-int/lit8 v26, v23, 0x3

    .line 583
    .line 584
    add-int v26, v26, v12

    .line 585
    .line 586
    aget-object v34, v8, v26

    .line 587
    .line 588
    aget-object v26, v9, v26

    .line 589
    .line 590
    move-object/from16 v36, v7

    .line 591
    .line 592
    move-object/from16 v7, v34

    .line 593
    .line 594
    check-cast v7, Lq21;

    .line 595
    .line 596
    move-object/from16 v34, v8

    .line 597
    .line 598
    sget-object v8, Ln21;->j:Lq21;

    .line 599
    .line 600
    invoke-static {v7, v8}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 601
    .line 602
    .line 603
    move-result v8

    .line 604
    if-eqz v8, :cond_262

    .line 605
    .line 606
    const/4 v8, 0x0

    .line 607
    invoke-virtual {v0, v8}, Landroid/view/ViewStructure;->setEnabled(Z)V

    .line 608
    .line 609
    .line 610
    goto :goto_276

    .line 611
    :cond_262
    sget-object v8, Ln21;->B:Lq21;

    .line 612
    .line 613
    invoke-static {v7, v8}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 614
    .line 615
    .line 616
    move-result v7

    .line 617
    if-eqz v7, :cond_276

    .line 618
    .line 619
    invoke-virtual/range {v26 .. v26}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 620
    .line 621
    .line 622
    move-object/from16 v13, v26

    .line 623
    .line 624
    check-cast v13, Ljava/util/List;

    .line 625
    .line 626
    goto :goto_276

    .line 627
    :cond_272
    move-object/from16 v36, v7

    .line 628
    .line 629
    move-object/from16 v34, v8

    .line 630
    .line 631
    :cond_276
    :goto_276
    shr-long v14, v14, v22

    .line 632
    .line 633
    add-int/lit8 v12, v12, 0x1

    .line 634
    .line 635
    move-object/from16 v8, v34

    .line 636
    .line 637
    move-object/from16 v7, v36

    .line 638
    .line 639
    goto :goto_23d

    .line 640
    :cond_27f
    move-object/from16 v36, v7

    .line 641
    .line 642
    move-object/from16 v34, v8

    .line 643
    .line 644
    move/from16 v7, v22

    .line 645
    .line 646
    if-ne v11, v7, :cond_29e

    .line 647
    .line 648
    :goto_287
    move/from16 v8, v23

    .line 649
    .line 650
    goto :goto_291

    .line 651
    :cond_28a
    move-object/from16 v36, v7

    .line 652
    .line 653
    move-object/from16 v34, v8

    .line 654
    .line 655
    move/from16 v7, v22

    .line 656
    .line 657
    goto :goto_287

    .line 658
    :goto_291
    if-eq v8, v10, :cond_29e

    .line 659
    .line 660
    add-int/lit8 v12, v8, 0x1

    .line 661
    .line 662
    move v11, v7

    .line 663
    move-object/from16 v8, v34

    .line 664
    .line 665
    move-object/from16 v7, v36

    .line 666
    .line 667
    goto :goto_225

    .line 668
    :cond_29b
    move/from16 v21, v14

    .line 669
    .line 670
    :cond_29d
    const/4 v13, 0x0

    .line 671
    :cond_29e
    iget v7, v1, Lba0;->f:I

    .line 672
    .line 673
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 674
    .line 675
    .line 676
    move-result-object v7

    .line 677
    invoke-virtual {v1}, Lba0;->v()Lba0;

    .line 678
    .line 679
    .line 680
    move-result-object v8

    .line 681
    if-nez v8, :cond_2ab

    .line 682
    .line 683
    const/4 v7, 0x0

    .line 684
    :cond_2ab
    if-eqz v7, :cond_2b4

    .line 685
    .line 686
    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    .line 687
    .line 688
    .line 689
    move-result v7

    .line 690
    :goto_2b1
    move-object/from16 v8, p2

    .line 691
    .line 692
    goto :goto_2b6

    .line 693
    :cond_2b4
    const/4 v7, -0x1

    .line 694
    goto :goto_2b1

    .line 695
    :goto_2b6
    invoke-static {v0, v8, v7}, La1;->r(Landroid/view/ViewStructure;Landroid/view/autofill/AutofillId;I)V

    .line 696
    .line 697
    .line 698
    move-object/from16 v8, p3

    .line 699
    .line 700
    const/4 v9, 0x0

    .line 701
    invoke-virtual {v0, v7, v8, v9, v9}, Landroid/view/ViewStructure;->setId(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 702
    .line 703
    .line 704
    if-eqz v6, :cond_2c8

    .line 705
    .line 706
    iget v6, v6, Li5;->a:I

    .line 707
    .line 708
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 709
    .line 710
    .line 711
    move-result-object v12

    .line 712
    goto :goto_2d7

    .line 713
    :cond_2c8
    if-eqz v20, :cond_2cf

    .line 714
    .line 715
    invoke-static/range {v21 .. v21}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 716
    .line 717
    .line 718
    move-result-object v12

    .line 719
    goto :goto_2d7

    .line 720
    :cond_2cf
    if-eqz v2, :cond_2d6

    .line 721
    .line 722
    invoke-static/range {v31 .. v31}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 723
    .line 724
    .line 725
    move-result-object v12

    .line 726
    goto :goto_2d7

    .line 727
    :cond_2d6
    move-object v12, v9

    .line 728
    :goto_2d7
    if-eqz v12, :cond_2e0

    .line 729
    .line 730
    invoke-virtual {v12}, Ljava/lang/Number;->intValue()I

    .line 731
    .line 732
    .line 733
    move-result v6

    .line 734
    invoke-static {v0, v6}, La1;->q(Landroid/view/ViewStructure;I)V

    .line 735
    .line 736
    .line 737
    :cond_2e0
    if-eqz v3, :cond_313

    .line 738
    .line 739
    iget-object v3, v3, Lx8;->f:Ljava/lang/String;

    .line 740
    .line 741
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    .line 742
    .line 743
    .line 744
    move-result v6

    .line 745
    const/16 v7, 0x1388

    .line 746
    .line 747
    if-ge v6, v7, :cond_2ed

    .line 748
    .line 749
    goto :goto_30c

    .line 750
    :cond_2ed
    const/16 v6, 0x1387

    .line 751
    .line 752
    invoke-virtual {v3, v6}, Ljava/lang/String;->charAt(I)C

    .line 753
    .line 754
    .line 755
    move-result v8

    .line 756
    invoke-static {v8}, Ljava/lang/Character;->isHighSurrogate(C)Z

    .line 757
    .line 758
    .line 759
    move-result v8

    .line 760
    if-eqz v8, :cond_308

    .line 761
    .line 762
    invoke-virtual {v3, v7}, Ljava/lang/String;->charAt(I)C

    .line 763
    .line 764
    .line 765
    move-result v8

    .line 766
    invoke-static {v8}, Ljava/lang/Character;->isLowSurrogate(C)Z

    .line 767
    .line 768
    .line 769
    move-result v8

    .line 770
    if-eqz v8, :cond_308

    .line 771
    .line 772
    invoke-static {v3, v6}, Lq81;->J(Ljava/lang/String;I)Ljava/lang/String;

    .line 773
    .line 774
    .line 775
    move-result-object v3

    .line 776
    goto :goto_30c

    .line 777
    :cond_308
    invoke-static {v3, v7}, Lq81;->J(Ljava/lang/String;I)Ljava/lang/String;

    .line 778
    .line 779
    .line 780
    move-result-object v3

    .line 781
    :goto_30c
    invoke-static {v3}, La1;->i(Ljava/lang/String;)Landroid/view/autofill/AutofillValue;

    .line 782
    .line 783
    .line 784
    move-result-object v3

    .line 785
    invoke-static {v0, v3}, La1;->s(Landroid/view/ViewStructure;Landroid/view/autofill/AutofillValue;)V

    .line 786
    .line 787
    .line 788
    :cond_313
    if-eqz v4, :cond_31a

    .line 789
    .line 790
    iget-object v3, v4, La6;->a:Landroid/view/autofill/AutofillValue;

    .line 791
    .line 792
    invoke-static {v0, v3}, La1;->s(Landroid/view/ViewStructure;Landroid/view/autofill/AutofillValue;)V

    .line 793
    .line 794
    .line 795
    :cond_31a
    if-eqz v24, :cond_325

    .line 796
    .line 797
    invoke-static/range {v24 .. v24}, La5;->u(Ljl;)[Ljava/lang/String;

    .line 798
    .line 799
    .line 800
    move-result-object v3

    .line 801
    if-eqz v3, :cond_325

    .line 802
    .line 803
    invoke-static {v0, v3}, La1;->u(Landroid/view/ViewStructure;[Ljava/lang/String;)V

    .line 804
    .line 805
    .line 806
    :cond_325
    move-object/from16 v3, p4

    .line 807
    .line 808
    iget-object v3, v3, Liw0;->a:Li6;

    .line 809
    .line 810
    iget v4, v1, Lba0;->f:I

    .line 811
    .line 812
    new-instance v6, Lot0;

    .line 813
    .line 814
    invoke-direct {v6, v0}, Lot0;-><init>(Landroid/view/ViewStructure;)V

    .line 815
    .line 816
    .line 817
    invoke-virtual {v3, v4, v6}, Li6;->h(ILo00;)V

    .line 818
    .line 819
    .line 820
    if-eqz v25, :cond_33c

    .line 821
    .line 822
    invoke-virtual/range {v25 .. v25}, Ljava/lang/Boolean;->booleanValue()Z

    .line 823
    .line 824
    .line 825
    move-result v3

    .line 826
    invoke-virtual {v0, v3}, Landroid/view/ViewStructure;->setSelected(Z)V

    .line 827
    .line 828
    .line 829
    :cond_33c
    const/4 v8, 0x4

    .line 830
    if-eqz v2, :cond_350

    .line 831
    .line 832
    move/from16 v3, v21

    .line 833
    .line 834
    invoke-virtual {v0, v3}, Landroid/view/ViewStructure;->setCheckable(Z)V

    .line 835
    .line 836
    .line 837
    sget-object v3, Loc1;->e:Loc1;

    .line 838
    .line 839
    if-ne v2, v3, :cond_34a

    .line 840
    .line 841
    const/4 v2, 0x1

    .line 842
    goto :goto_34b

    .line 843
    :cond_34a
    const/4 v2, 0x0

    .line 844
    :goto_34b
    invoke-virtual {v0, v2}, Landroid/view/ViewStructure;->setChecked(Z)V

    .line 845
    .line 846
    .line 847
    :cond_34e
    :goto_34e
    const/4 v3, 0x1

    .line 848
    goto :goto_365

    .line 849
    :cond_350
    if-eqz v25, :cond_34e

    .line 850
    .line 851
    if-nez v5, :cond_356

    .line 852
    .line 853
    :cond_354
    const/4 v3, 0x1

    .line 854
    goto :goto_35b

    .line 855
    :cond_356
    iget v2, v5, Liy0;->a:I

    .line 856
    .line 857
    if-ne v2, v8, :cond_354

    .line 858
    .line 859
    goto :goto_34e

    .line 860
    :goto_35b
    invoke-virtual {v0, v3}, Landroid/view/ViewStructure;->setCheckable(Z)V

    .line 861
    .line 862
    .line 863
    invoke-virtual/range {v25 .. v25}, Ljava/lang/Boolean;->booleanValue()Z

    .line 864
    .line 865
    .line 866
    move-result v2

    .line 867
    invoke-virtual {v0, v2}, Landroid/view/ViewStructure;->setChecked(Z)V

    .line 868
    .line 869
    .line 870
    :goto_365
    sget-object v2, Ljl;->a:Lil;

    .line 871
    .line 872
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 873
    .line 874
    .line 875
    sget-object v2, Lil;->b:Lj5;

    .line 876
    .line 877
    invoke-static {v2}, La5;->u(Ljl;)[Ljava/lang/String;

    .line 878
    .line 879
    .line 880
    move-result-object v2

    .line 881
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 882
    .line 883
    .line 884
    array-length v4, v2

    .line 885
    if-eqz v4, :cond_419

    .line 886
    .line 887
    const/16 v35, 0x0

    .line 888
    .line 889
    aget-object v2, v2, v35

    .line 890
    .line 891
    if-eqz v24, :cond_38a

    .line 892
    .line 893
    invoke-static/range {v24 .. v24}, La5;->u(Ljl;)[Ljava/lang/String;

    .line 894
    .line 895
    .line 896
    move-result-object v4

    .line 897
    if-eqz v4, :cond_38a

    .line 898
    .line 899
    invoke-static {v4, v2}, Lba;->f0([Ljava/lang/Object;Ljava/lang/Object;)I

    .line 900
    .line 901
    .line 902
    move-result v2

    .line 903
    if-ltz v2, :cond_38a

    .line 904
    .line 905
    move v2, v3

    .line 906
    goto :goto_38c

    .line 907
    :cond_38a
    move/from16 v2, v35

    .line 908
    .line 909
    :goto_38c
    if-nez v27, :cond_394

    .line 910
    .line 911
    if-eqz v2, :cond_391

    .line 912
    .line 913
    goto :goto_394

    .line 914
    :cond_391
    move/from16 v2, v35

    .line 915
    .line 916
    goto :goto_395

    .line 917
    :cond_394
    :goto_394
    move v2, v3

    .line 918
    :goto_395
    if-nez v2, :cond_39d

    .line 919
    .line 920
    if-eqz v28, :cond_39a

    .line 921
    .line 922
    goto :goto_39d

    .line 923
    :cond_39a
    move/from16 v14, v35

    .line 924
    .line 925
    goto :goto_39e

    .line 926
    :cond_39d
    :goto_39d
    move v14, v3

    .line 927
    :goto_39e
    invoke-static {v0, v14}, La1;->t(Landroid/view/ViewStructure;Z)V

    .line 928
    .line 929
    .line 930
    iget-object v3, v1, Lba0;->J:Lem0;

    .line 931
    .line 932
    iget-object v3, v3, Lem0;->d:Lgm0;

    .line 933
    .line 934
    invoke-virtual {v3}, Lgm0;->G0()Z

    .line 935
    .line 936
    .line 937
    move-result v3

    .line 938
    if-eqz v3, :cond_3ac

    .line 939
    .line 940
    goto :goto_3ae

    .line 941
    :cond_3ac
    move/from16 v8, v35

    .line 942
    .line 943
    :goto_3ae
    invoke-virtual {v0, v8}, Landroid/view/ViewStructure;->setVisibility(I)V

    .line 944
    .line 945
    .line 946
    if-eqz v13, :cond_3e4

    .line 947
    .line 948
    invoke-interface {v13}, Ljava/util/Collection;->size()I

    .line 949
    .line 950
    .line 951
    move-result v3

    .line 952
    const-string v4, ""

    .line 953
    .line 954
    move/from16 v6, v35

    .line 955
    .line 956
    :goto_3bb
    if-ge v6, v3, :cond_3dc

    .line 957
    .line 958
    invoke-interface {v13, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 959
    .line 960
    .line 961
    move-result-object v7

    .line 962
    check-cast v7, Lx8;

    .line 963
    .line 964
    new-instance v8, Ljava/lang/StringBuilder;

    .line 965
    .line 966
    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    .line 967
    .line 968
    .line 969
    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 970
    .line 971
    .line 972
    iget-object v4, v7, Lx8;->f:Ljava/lang/String;

    .line 973
    .line 974
    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 975
    .line 976
    .line 977
    const/16 v4, 0xa

    .line 978
    .line 979
    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 980
    .line 981
    .line 982
    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 983
    .line 984
    .line 985
    move-result-object v4

    .line 986
    add-int/lit8 v6, v6, 0x1

    .line 987
    .line 988
    goto :goto_3bb

    .line 989
    :cond_3dc
    invoke-virtual {v0, v4}, Landroid/view/ViewStructure;->setText(Ljava/lang/CharSequence;)V

    .line 990
    .line 991
    .line 992
    const-string v3, "android.widget.TextView"

    .line 993
    .line 994
    invoke-virtual {v0, v3}, Landroid/view/ViewStructure;->setClassName(Ljava/lang/String;)V

    .line 995
    .line 996
    .line 997
    :cond_3e4
    invoke-virtual {v1}, Lba0;->n()Ljava/util/List;

    .line 998
    .line 999
    .line 1000
    move-result-object v1

    .line 1001
    check-cast v1, Lnk0;

    .line 1002
    .line 1003
    invoke-virtual {v1}, Lnk0;->isEmpty()Z

    .line 1004
    .line 1005
    .line 1006
    move-result v1

    .line 1007
    if-eqz v1, :cond_3fd

    .line 1008
    .line 1009
    if-eqz v5, :cond_3fd

    .line 1010
    .line 1011
    iget v1, v5, Liy0;->a:I

    .line 1012
    .line 1013
    invoke-static {v1}, Lnb0;->u(I)Ljava/lang/String;

    .line 1014
    .line 1015
    .line 1016
    move-result-object v1

    .line 1017
    if-eqz v1, :cond_3fd

    .line 1018
    .line 1019
    invoke-virtual {v0, v1}, Landroid/view/ViewStructure;->setClassName(Ljava/lang/String;)V

    .line 1020
    .line 1021
    .line 1022
    :cond_3fd
    if-eqz v20, :cond_418

    .line 1023
    .line 1024
    const-string v1, "android.widget.EditText"

    .line 1025
    .line 1026
    invoke-virtual {v0, v1}, Landroid/view/ViewStructure;->setClassName(Ljava/lang/String;)V

    .line 1027
    .line 1028
    .line 1029
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 1030
    .line 1031
    const/16 v3, 0x1c

    .line 1032
    .line 1033
    if-lt v1, v3, :cond_413

    .line 1034
    .line 1035
    if-eqz v29, :cond_413

    .line 1036
    .line 1037
    invoke-virtual/range {v29 .. v29}, Ljava/lang/Number;->intValue()I

    .line 1038
    .line 1039
    .line 1040
    move-result v1

    .line 1041
    invoke-static {v0, v1}, Lz0;->m(Landroid/view/ViewStructure;I)V

    .line 1042
    .line 1043
    .line 1044
    :cond_413
    if-eqz v2, :cond_418

    .line 1045
    .line 1046
    invoke-static {v0}, La1;->p(Landroid/view/ViewStructure;)V

    .line 1047
    .line 1048
    .line 1049
    :cond_418
    return-void

    .line 1050
    :cond_419
    new-instance v0, Ljava/util/NoSuchElementException;

    .line 1051
    .line 1052
    const-string v1, "Array is empty."

    .line 1053
    .line 1054
    invoke-direct {v0, v1}, Ljava/util/NoSuchElementException;-><init>(Ljava/lang/String;)V

    .line 1055
    .line 1056
    .line 1057
    throw v0
.end method

.method public static final t([F)V
    .registers 4

    .line 1
    array-length v0, p0

    .line 2
    const/16 v1, 0x10

    .line 3
    .line 4
    if-ge v0, v1, :cond_6

    .line 5
    .line 6
    return-void

    .line 7
    :cond_6
    const/4 v0, 0x0

    .line 8
    const/high16 v1, 0x3f800000  # 1.0f

    .line 9
    .line 10
    aput v1, p0, v0

    .line 11
    .line 12
    const/4 v0, 0x1

    .line 13
    const/4 v2, 0x0

    .line 14
    aput v2, p0, v0

    .line 15
    .line 16
    const/4 v0, 0x2

    .line 17
    aput v2, p0, v0

    .line 18
    .line 19
    const/4 v0, 0x3

    .line 20
    aput v2, p0, v0

    .line 21
    .line 22
    const/4 v0, 0x4

    .line 23
    aput v2, p0, v0

    .line 24
    .line 25
    const/4 v0, 0x5

    .line 26
    aput v1, p0, v0

    .line 27
    .line 28
    const/4 v0, 0x6

    .line 29
    aput v2, p0, v0

    .line 30
    .line 31
    const/4 v0, 0x7

    .line 32
    aput v2, p0, v0

    .line 33
    .line 34
    const/16 v0, 0x8

    .line 35
    .line 36
    aput v2, p0, v0

    .line 37
    .line 38
    const/16 v0, 0x9

    .line 39
    .line 40
    aput v2, p0, v0

    .line 41
    .line 42
    const/16 v0, 0xa

    .line 43
    .line 44
    aput v1, p0, v0

    .line 45
    .line 46
    const/16 v0, 0xb

    .line 47
    .line 48
    aput v2, p0, v0

    .line 49
    .line 50
    const/16 v0, 0xc

    .line 51
    .line 52
    aput v2, p0, v0

    .line 53
    .line 54
    const/16 v0, 0xd

    .line 55
    .line 56
    aput v2, p0, v0

    .line 57
    .line 58
    const/16 v0, 0xe

    .line 59
    .line 60
    aput v2, p0, v0

    .line 61
    .line 62
    const/16 v0, 0xf

    .line 63
    .line 64
    aput v1, p0, v0

    .line 65
    .line 66
    return-void
.end method

.method public static u(Landroid/view/Window;Z)V
    .registers 4

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 2
    .line 3
    const/16 v1, 0x23

    .line 4
    .line 5
    if-lt v0, v1, :cond_a

    .line 6
    .line 7
    invoke-static {p0, p1}, Lg1;->e(Landroid/view/Window;Z)V

    .line 8
    .line 9
    .line 10
    return-void

    .line 11
    :cond_a
    const/16 v1, 0x1e

    .line 12
    .line 13
    if-lt v0, v1, :cond_12

    .line 14
    .line 15
    invoke-static {p0, p1}, Lg1;->d(Landroid/view/Window;Z)V

    .line 16
    .line 17
    .line 18
    return-void

    .line 19
    :cond_12
    invoke-virtual {p0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 20
    .line 21
    .line 22
    move-result-object p0

    .line 23
    invoke-virtual {p0}, Landroid/view/View;->getSystemUiVisibility()I

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    if-eqz p1, :cond_1f

    .line 28
    .line 29
    and-int/lit16 p1, v0, -0x701

    .line 30
    .line 31
    goto :goto_21

    .line 32
    :cond_1f
    or-int/lit16 p1, v0, 0x700

    .line 33
    .line 34
    :goto_21
    invoke-virtual {p0, p1}, Landroid/view/View;->setSystemUiVisibility(I)V

    .line 35
    .line 36
    .line 37
    return-void
.end method

.method public static final v(Lzo0;ILjava/lang/Object;)V
    .registers 6

    .line 1
    iget-object v0, p0, Lzo0;->f:[Ljava/lang/Object;

    .line 2
    .line 3
    iget v1, p0, Lzo0;->g:I

    .line 4
    .line 5
    iget-object v2, p0, Lzo0;->b:[Lxo0;

    .line 6
    .line 7
    iget p0, p0, Lzo0;->c:I

    .line 8
    .line 9
    add-int/lit8 p0, p0, -0x1

    .line 10
    .line 11
    aget-object p0, v2, p0

    .line 12
    .line 13
    iget p0, p0, Lxo0;->b:I

    .line 14
    .line 15
    sub-int/2addr v1, p0

    .line 16
    add-int/2addr v1, p1

    .line 17
    aput-object p2, v0, v1

    .line 18
    .line 19
    return-void
.end method

.method public static final w(Lzo0;ILjava/lang/Object;ILjava/lang/Object;)V
    .registers 8

    .line 1
    iget v0, p0, Lzo0;->g:I

    .line 2
    .line 3
    iget-object v1, p0, Lzo0;->b:[Lxo0;

    .line 4
    .line 5
    iget v2, p0, Lzo0;->c:I

    .line 6
    .line 7
    add-int/lit8 v2, v2, -0x1

    .line 8
    .line 9
    aget-object v1, v1, v2

    .line 10
    .line 11
    iget v1, v1, Lxo0;->b:I

    .line 12
    .line 13
    sub-int/2addr v0, v1

    .line 14
    iget-object p0, p0, Lzo0;->f:[Ljava/lang/Object;

    .line 15
    .line 16
    add-int/2addr p1, v0

    .line 17
    aput-object p2, p0, p1

    .line 18
    .line 19
    add-int/2addr v0, p3

    .line 20
    aput-object p4, p0, v0

    .line 21
    .line 22
    return-void
.end method

.method public static final x(Lr60;)Landroid/graphics/Rect;
    .registers 5

    .line 1
    new-instance v0, Landroid/graphics/Rect;

    .line 2
    .line 3
    iget v1, p0, Lr60;->a:I

    .line 4
    .line 5
    iget v2, p0, Lr60;->b:I

    .line 6
    .line 7
    iget v3, p0, Lr60;->c:I

    .line 8
    .line 9
    iget p0, p0, Lr60;->d:I

    .line 10
    .line 11
    invoke-direct {v0, v1, v2, v3, p0}, Landroid/graphics/Rect;-><init>(IIII)V

    .line 12
    .line 13
    .line 14
    return-object v0
.end method

.method public static y([FFF)V
    .registers 11

    .line 1
    array-length v0, p0

    .line 2
    const/16 v1, 0x10

    .line 3
    .line 4
    if-ge v0, v1, :cond_6

    .line 5
    .line 6
    return-void

    .line 7
    :cond_6
    const/4 v0, 0x0

    .line 8
    aget v0, p0, v0

    .line 9
    .line 10
    mul-float/2addr v0, p1

    .line 11
    const/4 v1, 0x4

    .line 12
    aget v1, p0, v1

    .line 13
    .line 14
    mul-float/2addr v1, p2

    .line 15
    add-float/2addr v1, v0

    .line 16
    const/16 v0, 0x8

    .line 17
    .line 18
    aget v0, p0, v0

    .line 19
    .line 20
    const/4 v2, 0x0

    .line 21
    mul-float/2addr v0, v2

    .line 22
    add-float/2addr v0, v1

    .line 23
    const/16 v1, 0xc

    .line 24
    .line 25
    aget v3, p0, v1

    .line 26
    .line 27
    add-float/2addr v0, v3

    .line 28
    const/4 v3, 0x1

    .line 29
    aget v3, p0, v3

    .line 30
    .line 31
    mul-float/2addr v3, p1

    .line 32
    const/4 v4, 0x5

    .line 33
    aget v4, p0, v4

    .line 34
    .line 35
    mul-float/2addr v4, p2

    .line 36
    add-float/2addr v4, v3

    .line 37
    const/16 v3, 0x9

    .line 38
    .line 39
    aget v3, p0, v3

    .line 40
    .line 41
    mul-float/2addr v3, v2

    .line 42
    add-float/2addr v3, v4

    .line 43
    const/16 v4, 0xd

    .line 44
    .line 45
    aget v5, p0, v4

    .line 46
    .line 47
    add-float/2addr v3, v5

    .line 48
    const/4 v5, 0x2

    .line 49
    aget v5, p0, v5

    .line 50
    .line 51
    mul-float/2addr v5, p1

    .line 52
    const/4 v6, 0x6

    .line 53
    aget v6, p0, v6

    .line 54
    .line 55
    mul-float/2addr v6, p2

    .line 56
    add-float/2addr v6, v5

    .line 57
    const/16 v5, 0xa

    .line 58
    .line 59
    aget v5, p0, v5

    .line 60
    .line 61
    mul-float/2addr v5, v2

    .line 62
    add-float/2addr v5, v6

    .line 63
    const/16 v6, 0xe

    .line 64
    .line 65
    aget v7, p0, v6

    .line 66
    .line 67
    add-float/2addr v5, v7

    .line 68
    const/4 v7, 0x3

    .line 69
    aget v7, p0, v7

    .line 70
    .line 71
    mul-float/2addr v7, p1

    .line 72
    const/4 p1, 0x7

    .line 73
    aget p1, p0, p1

    .line 74
    .line 75
    mul-float/2addr p1, p2

    .line 76
    add-float/2addr p1, v7

    .line 77
    const/16 p2, 0xb

    .line 78
    .line 79
    aget p2, p0, p2

    .line 80
    .line 81
    mul-float/2addr p2, v2

    .line 82
    add-float/2addr p2, p1

    .line 83
    const/16 p1, 0xf

    .line 84
    .line 85
    aget v2, p0, p1

    .line 86
    .line 87
    add-float/2addr p2, v2

    .line 88
    aput v0, p0, v1

    .line 89
    .line 90
    aput v3, p0, v4

    .line 91
    .line 92
    aput v5, p0, v6

    .line 93
    .line 94
    aput p2, p0, p1

    .line 95
    .line 96
    return-void
.end method


# virtual methods
.method public abstract f([BII)Ljava/lang/String;
.end method

.method public abstract g(Ljava/lang/String;[BII)I
.end method
