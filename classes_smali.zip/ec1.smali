.class final Lec1;
.super Lqi0;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lqi0;"
    }
.end annotation


# instance fields
.field public final a:Luj0;

.field public final b:Z

.field public final c:Lp71;


# direct methods
.method public constructor <init>(Luj0;ZLp71;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lec1;->a:Luj0;

    .line 5
    .line 6
    iput-boolean p2, p0, Lec1;->b:Z

    .line 7
    .line 8
    iput-object p3, p0, Lec1;->c:Lp71;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final e()Lli0;
    .registers 3

    .line 1
    new-instance v0, Lhc1;

    .line 2
    .line 3
    invoke-direct {v0}, Lli0;-><init>()V

    .line 4
    .line 5
    .line 6
    iget-object v1, p0, Lec1;->a:Luj0;

    .line 7
    .line 8
    iput-object v1, v0, Lhc1;->s:Luj0;

    .line 9
    .line 10
    iget-boolean v1, p0, Lec1;->b:Z

    .line 11
    .line 12
    iput-boolean v1, v0, Lhc1;->t:Z

    .line 13
    .line 14
    iget-object p0, p0, Lec1;->c:Lp71;

    .line 15
    .line 16
    iput-object p0, v0, Lhc1;->u:Lp71;

    .line 17
    .line 18
    const/high16 p0, 0x7fc00000  # Float.NaN

    .line 19
    .line 20
    iput p0, v0, Lhc1;->y:F

    .line 21
    .line 22
    iput p0, v0, Lhc1;->z:F

    .line 23
    .line 24
    return-object v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 4

    .line 1
    if-ne p0, p1, :cond_3

    .line 2
    .line 3
    goto :goto_28

    .line 4
    :cond_3
    instance-of v0, p1, Lec1;

    .line 5
    .line 6
    if-nez v0, :cond_8

    .line 7
    .line 8
    goto :goto_26

    .line 9
    :cond_8
    check-cast p1, Lec1;

    .line 10
    .line 11
    iget-object v0, p0, Lec1;->a:Luj0;

    .line 12
    .line 13
    iget-object v1, p1, Lec1;->a:Luj0;

    .line 14
    .line 15
    invoke-static {v0, v1}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    if-nez v0, :cond_15

    .line 20
    .line 21
    goto :goto_26

    .line 22
    :cond_15
    iget-boolean v0, p0, Lec1;->b:Z

    .line 23
    .line 24
    iget-boolean v1, p1, Lec1;->b:Z

    .line 25
    .line 26
    if-eq v0, v1, :cond_1c

    .line 27
    .line 28
    goto :goto_26

    .line 29
    :cond_1c
    iget-object p0, p0, Lec1;->c:Lp71;

    .line 30
    .line 31
    iget-object p1, p1, Lec1;->c:Lp71;

    .line 32
    .line 33
    invoke-virtual {p0, p1}, Lp71;->equals(Ljava/lang/Object;)Z

    .line 34
    .line 35
    .line 36
    move-result p0

    .line 37
    if-nez p0, :cond_28

    .line 38
    .line 39
    :goto_26
    const/4 p0, 0x0

    .line 40
    return p0

    .line 41
    :cond_28
    :goto_28
    const/4 p0, 0x1

    .line 42
    return p0
.end method

.method public final f(Lli0;)V
    .registers 4

    .line 1
    check-cast p1, Lhc1;

    .line 2
    .line 3
    iget-object v0, p0, Lec1;->a:Luj0;

    .line 4
    .line 5
    iput-object v0, p1, Lhc1;->s:Luj0;

    .line 6
    .line 7
    iget-boolean v0, p1, Lhc1;->t:Z

    .line 8
    .line 9
    iget-boolean v1, p0, Lec1;->b:Z

    .line 10
    .line 11
    if-eq v0, v1, :cond_f

    .line 12
    .line 13
    invoke-static {p1}, Lvd1;->t(Lt90;)V

    .line 14
    .line 15
    .line 16
    :cond_f
    iput-boolean v1, p1, Lhc1;->t:Z

    .line 17
    .line 18
    iget-object p0, p0, Lec1;->c:Lp71;

    .line 19
    .line 20
    iput-object p0, p1, Lhc1;->u:Lp71;

    .line 21
    .line 22
    iget-object p0, p1, Lhc1;->x:Lc8;

    .line 23
    .line 24
    if-nez p0, :cond_29

    .line 25
    .line 26
    iget p0, p1, Lhc1;->z:F

    .line 27
    .line 28
    invoke-static {p0}, Ljava/lang/Float;->isNaN(F)Z

    .line 29
    .line 30
    .line 31
    move-result p0

    .line 32
    if-nez p0, :cond_29

    .line 33
    .line 34
    iget p0, p1, Lhc1;->z:F

    .line 35
    .line 36
    invoke-static {p0}, Lk70;->a(F)Lc8;

    .line 37
    .line 38
    .line 39
    move-result-object p0

    .line 40
    iput-object p0, p1, Lhc1;->x:Lc8;

    .line 41
    .line 42
    :cond_29
    iget-object p0, p1, Lhc1;->w:Lc8;

    .line 43
    .line 44
    if-nez p0, :cond_3d

    .line 45
    .line 46
    iget p0, p1, Lhc1;->y:F

    .line 47
    .line 48
    invoke-static {p0}, Ljava/lang/Float;->isNaN(F)Z

    .line 49
    .line 50
    .line 51
    move-result p0

    .line 52
    if-nez p0, :cond_3d

    .line 53
    .line 54
    iget p0, p1, Lhc1;->y:F

    .line 55
    .line 56
    invoke-static {p0}, Lk70;->a(F)Lc8;

    .line 57
    .line 58
    .line 59
    move-result-object p0

    .line 60
    iput-object p0, p1, Lhc1;->w:Lc8;

    .line 61
    .line 62
    :cond_3d
    return-void
.end method

.method public final hashCode()I
    .registers 3

    .line 1
    iget-object v0, p0, Lec1;->a:Luj0;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    mul-int/lit8 v0, v0, 0x1f

    .line 8
    .line 9
    iget-boolean v1, p0, Lec1;->b:Z

    .line 10
    .line 11
    if-eqz v1, :cond_f

    .line 12
    .line 13
    const/16 v1, 0x4cf

    .line 14
    .line 15
    goto :goto_11

    .line 16
    :cond_f
    const/16 v1, 0x4d5

    .line 17
    .line 18
    :goto_11
    add-int/2addr v0, v1

    .line 19
    mul-int/lit8 v0, v0, 0x1f

    .line 20
    .line 21
    iget-object p0, p0, Lec1;->c:Lp71;

    .line 22
    .line 23
    invoke-virtual {p0}, Lp71;->hashCode()I

    .line 24
    .line 25
    .line 26
    move-result p0

    .line 27
    add-int/2addr p0, v0

    .line 28
    return p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-string v1, "ThumbElement(interactionSource="

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    iget-object v1, p0, Lec1;->a:Luj0;

    .line 9
    .line 10
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 11
    .line 12
    .line 13
    const-string v1, ", checked="

    .line 14
    .line 15
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 16
    .line 17
    .line 18
    iget-boolean v1, p0, Lec1;->b:Z

    .line 19
    .line 20
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 21
    .line 22
    .line 23
    const-string v1, ", animationSpec="

    .line 24
    .line 25
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 26
    .line 27
    .line 28
    iget-object p0, p0, Lec1;->c:Lp71;

    .line 29
    .line 30
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 31
    .line 32
    .line 33
    const/16 p0, 0x29

    .line 34
    .line 35
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 36
    .line 37
    .line 38
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 39
    .line 40
    .line 41
    move-result-object p0

    .line 42
    return-object p0
.end method
