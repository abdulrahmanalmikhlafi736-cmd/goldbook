.class public abstract Lcl;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# static fields
.field public static final a:Lgk;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Lgk;

    .line 2
    .line 3
    sget-object v1, Lbl;->e:Lbl;

    .line 4
    .line 5
    invoke-direct {v0, v1}, Lgk;-><init>(Lxz;)V

    .line 6
    .line 7
    .line 8
    sput-object v0, Lcl;->a:Lgk;

    .line 9
    .line 10
    return-void
.end method
