.class public interface abstract Lck;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# static fields
.field public static final d:Lbk;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    sget-object v0, Lbk;->a:Lbk;

    .line 2
    .line 3
    sput-object v0, Lck;->d:Lbk;

    .line 4
    .line 5
    return-void
.end method
