.class public final Lb71;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# instance fields
.field public final a:Li00;

.field public final b:Ljava/util/concurrent/atomic/AtomicReference;

.field public c:Z

.field public final d:Lhc;

.field public final e:Ll;

.field public final f:Lqk0;

.field public final g:Ljava/lang/Object;

.field public h:Lm2;

.field public i:La71;

.field public j:J


# direct methods
.method public constructor <init>(Li00;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lb71;->a:Li00;

    .line 5
    .line 6
    new-instance p1, Ljava/util/concurrent/atomic/AtomicReference;

    .line 7
    .line 8
    const/4 v0, 0x0

    .line 9
    invoke-direct {p1, v0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>(Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    iput-object p1, p0, Lb71;->b:Ljava/util/concurrent/atomic/AtomicReference;

    .line 13
    .line 14
    new-instance p1, Lhc;

    .line 15
    .line 16
    const/16 v0, 0x10

    .line 17
    .line 18
    invoke-direct {p1, v0, p0}, Lhc;-><init>(ILjava/lang/Object;)V

    .line 19
    .line 20
    .line 21
    iput-object p1, p0, Lb71;->d:Lhc;

    .line 22
    .line 23
    new-instance p1, Ll;

    .line 24
    .line 25
    const/16 v1, 0x19

    .line 26
    .line 27
    invoke-direct {p1, v1, p0}, Ll;-><init>(ILjava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    iput-object p1, p0, Lb71;->e:Ll;

    .line 31
    .line 32
    new-instance p1, Lqk0;

    .line 33
    .line 34
    new-array v0, v0, [La71;

    .line 35
    .line 36
    invoke-direct {p1, v0}, Lqk0;-><init>([Ljava/lang/Object;)V

    .line 37
    .line 38
    .line 39
    iput-object p1, p0, Lb71;->f:Lqk0;

    .line 40
    .line 41
    new-instance p1, Ljava/lang/Object;

    .line 42
    .line 43
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 44
    .line 45
    .line 46
    iput-object p1, p0, Lb71;->g:Ljava/lang/Object;

    .line 47
    .line 48
    const-wide/16 v0, -0x1

    .line 49
    .line 50
    iput-wide v0, p0, Lb71;->j:J

    .line 51
    .line 52
    return-void
.end method


# virtual methods
.method public final a()Z
    .registers 11

    .line 1
    iget-object v0, p0, Lb71;->g:Ljava/lang/Object;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    :try_start_3
    iget-boolean v1, p0, Lb71;->c:Z
    :try_end_5
    .catchall {:try_start_3 .. :try_end_5} :catchall_87

    .line 5
    .line 6
    monitor-exit v0

    .line 7
    const/4 v0, 0x0

    .line 8
    if-eqz v1, :cond_a

    .line 9
    .line 10
    return v0

    .line 11
    :cond_a
    move v1, v0

    .line 12
    :goto_b
    iget-object v2, p0, Lb71;->b:Ljava/util/concurrent/atomic/AtomicReference;

    .line 13
    .line 14
    :goto_d
    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object v3

    .line 18
    const/4 v4, 0x0

    .line 19
    const/4 v5, 0x1

    .line 20
    if-nez v3, :cond_16

    .line 21
    .line 22
    goto :goto_4d

    .line 23
    :cond_16
    instance-of v6, v3, Ljava/util/Set;

    .line 24
    .line 25
    if-eqz v6, :cond_1e

    .line 26
    .line 27
    move-object v6, v3

    .line 28
    check-cast v6, Ljava/util/Set;

    .line 29
    .line 30
    goto :goto_46

    .line 31
    :cond_1e
    instance-of v6, v3, Ljava/util/List;

    .line 32
    .line 33
    if-eqz v6, :cond_7c

    .line 34
    .line 35
    move-object v6, v3

    .line 36
    check-cast v6, Ljava/util/List;

    .line 37
    .line 38
    invoke-interface {v6, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object v7

    .line 42
    check-cast v7, Ljava/util/Set;

    .line 43
    .line 44
    invoke-interface {v6}, Ljava/util/List;->size()I

    .line 45
    .line 46
    .line 47
    move-result v8

    .line 48
    const/4 v9, 0x2

    .line 49
    if-ne v8, v9, :cond_37

    .line 50
    .line 51
    invoke-interface {v6, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    move-result-object v4

    .line 55
    goto :goto_45

    .line 56
    :cond_37
    invoke-interface {v6}, Ljava/util/List;->size()I

    .line 57
    .line 58
    .line 59
    move-result v8

    .line 60
    if-le v8, v9, :cond_45

    .line 61
    .line 62
    invoke-interface {v6}, Ljava/util/List;->size()I

    .line 63
    .line 64
    .line 65
    move-result v4

    .line 66
    invoke-interface {v6, v5, v4}, Ljava/util/List;->subList(II)Ljava/util/List;

    .line 67
    .line 68
    .line 69
    move-result-object v4

    .line 70
    :cond_45
    :goto_45
    move-object v6, v7

    .line 71
    :cond_46
    :goto_46
    invoke-virtual {v2, v3, v4}, Ljava/util/concurrent/atomic/AtomicReference;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 72
    .line 73
    .line 74
    move-result v7

    .line 75
    if-eqz v7, :cond_75

    .line 76
    .line 77
    move-object v4, v6

    .line 78
    :goto_4d
    if-nez v4, :cond_50

    .line 79
    .line 80
    return v1

    .line 81
    :cond_50
    iget-object v2, p0, Lb71;->g:Ljava/lang/Object;

    .line 82
    .line 83
    monitor-enter v2

    .line 84
    :try_start_53
    iget-object v3, p0, Lb71;->f:Lqk0;

    .line 85
    .line 86
    iget-object v6, v3, Lqk0;->e:[Ljava/lang/Object;

    .line 87
    .line 88
    iget v3, v3, Lqk0;->g:I

    .line 89
    .line 90
    move v7, v0

    .line 91
    :goto_5a
    if-ge v7, v3, :cond_71

    .line 92
    .line 93
    aget-object v8, v6, v7

    .line 94
    .line 95
    check-cast v8, La71;

    .line 96
    .line 97
    invoke-virtual {v8, v4}, La71;->a(Ljava/util/Set;)Z

    .line 98
    .line 99
    .line 100
    move-result v8
    :try_end_64
    .catchall {:try_start_53 .. :try_end_64} :catchall_6f

    .line 101
    if-nez v8, :cond_6b

    .line 102
    .line 103
    if-eqz v1, :cond_69

    .line 104
    .line 105
    goto :goto_6b

    .line 106
    :cond_69
    move v1, v0

    .line 107
    goto :goto_6c

    .line 108
    :cond_6b
    :goto_6b
    move v1, v5

    .line 109
    :goto_6c
    add-int/lit8 v7, v7, 0x1

    .line 110
    .line 111
    goto :goto_5a

    .line 112
    :catchall_6f
    move-exception p0

    .line 113
    goto :goto_73

    .line 114
    :cond_71
    monitor-exit v2

    .line 115
    goto :goto_b

    .line 116
    :goto_73
    monitor-exit v2

    .line 117
    throw p0

    .line 118
    :cond_75
    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 119
    .line 120
    .line 121
    move-result-object v7

    .line 122
    if-eq v7, v3, :cond_46

    .line 123
    .line 124
    goto :goto_d

    .line 125
    :cond_7c
    const-string p0, "Unexpected notification"

    .line 126
    .line 127
    invoke-static {p0}, Lqj;->b(Ljava/lang/String;)Ljava/lang/Void;

    .line 128
    .line 129
    .line 130
    new-instance p0, Lyh;

    .line 131
    .line 132
    invoke-direct {p0}, Ljava/lang/RuntimeException;-><init>()V

    .line 133
    .line 134
    .line 135
    throw p0

    .line 136
    :catchall_87
    move-exception p0

    .line 137
    monitor-exit v0

    .line 138
    throw p0
.end method

.method public final b(Ljava/lang/Object;Li00;Lxz;)V
    .registers 25

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v0, p1

    .line 4
    .line 5
    move-object/from16 v2, p2

    .line 6
    .line 7
    invoke-static {}, Lkb0;->j()J

    .line 8
    .line 9
    .line 10
    move-result-wide v3

    .line 11
    iget-object v5, v1, Lb71;->g:Ljava/lang/Object;

    .line 12
    .line 13
    monitor-enter v5

    .line 14
    :try_start_d
    iget-object v6, v1, Lb71;->f:Lqk0;

    .line 15
    .line 16
    iget-object v7, v6, Lqk0;->e:[Ljava/lang/Object;

    .line 17
    .line 18
    iget v8, v6, Lqk0;->g:I

    .line 19
    .line 20
    const/4 v10, 0x0

    .line 21
    :goto_14
    const/4 v11, 0x0

    .line 22
    if-ge v10, v8, :cond_24

    .line 23
    .line 24
    aget-object v12, v7, v10

    .line 25
    .line 26
    move-object v13, v12

    .line 27
    check-cast v13, La71;

    .line 28
    .line 29
    iget-object v13, v13, La71;->a:Li00;

    .line 30
    .line 31
    if-ne v13, v2, :cond_21

    .line 32
    .line 33
    goto :goto_25

    .line 34
    :cond_21
    add-int/lit8 v10, v10, 0x1

    .line 35
    .line 36
    goto :goto_14

    .line 37
    :cond_24
    move-object v12, v11

    .line 38
    :goto_25
    check-cast v12, La71;

    .line 39
    .line 40
    const/4 v7, 0x1

    .line 41
    if-nez v12, :cond_38

    .line 42
    .line 43
    new-instance v12, La71;

    .line 44
    .line 45
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 46
    .line 47
    .line 48
    invoke-static {v7, v2}, Lvd1;->e(ILjava/lang/Object;)V

    .line 49
    .line 50
    .line 51
    invoke-direct {v12, v2}, La71;-><init>(Li00;)V

    .line 52
    .line 53
    .line 54
    invoke-virtual {v6, v12}, Lqk0;->b(Ljava/lang/Object;)V

    .line 55
    .line 56
    .line 57
    :cond_38
    iget-object v2, v1, Lb71;->i:La71;

    .line 58
    .line 59
    iget-wide v13, v1, Lb71;->j:J
    :try_end_3c
    .catchall {:try_start_d .. :try_end_3c} :catchall_225

    .line 60
    .line 61
    monitor-exit v5

    .line 62
    const-wide/16 v5, -0x1

    .line 63
    .line 64
    cmp-long v5, v13, v5

    .line 65
    .line 66
    if-eqz v5, :cond_76

    .line 67
    .line 68
    cmp-long v5, v13, v3

    .line 69
    .line 70
    if-nez v5, :cond_48

    .line 71
    .line 72
    goto :goto_76

    .line 73
    :cond_48
    new-instance v5, Ljava/lang/StringBuilder;

    .line 74
    .line 75
    const-string v6, "Detected multithreaded access to SnapshotStateObserver: previousThreadId="

    .line 76
    .line 77
    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 78
    .line 79
    .line 80
    invoke-virtual {v5, v13, v14}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 81
    .line 82
    .line 83
    const-string v6, "), currentThread={id="

    .line 84
    .line 85
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 86
    .line 87
    .line 88
    invoke-virtual {v5, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 89
    .line 90
    .line 91
    const-string v6, ", name="

    .line 92
    .line 93
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 94
    .line 95
    .line 96
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    .line 97
    .line 98
    .line 99
    move-result-object v6

    .line 100
    invoke-virtual {v6}, Ljava/lang/Thread;->getName()Ljava/lang/String;

    .line 101
    .line 102
    .line 103
    move-result-object v6

    .line 104
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 105
    .line 106
    .line 107
    const-string v6, "}. Note that observation on multiple threads in layout/draw is not supported. Make sure your measure/layout/draw for each Owner (AndroidComposeView) is executed on the same thread."

    .line 108
    .line 109
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 110
    .line 111
    .line 112
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 113
    .line 114
    .line 115
    move-result-object v5

    .line 116
    invoke-static {v5}, Lrt0;->a(Ljava/lang/String;)V

    .line 117
    .line 118
    .line 119
    :cond_76
    :goto_76
    :try_start_76
    iget-object v5, v1, Lb71;->g:Ljava/lang/Object;

    .line 120
    .line 121
    monitor-enter v5
    :try_end_79
    .catchall {:try_start_76 .. :try_end_79} :catchall_a9

    .line 122
    :try_start_79
    iput-object v12, v1, Lb71;->i:La71;

    .line 123
    .line 124
    iput-wide v3, v1, Lb71;->j:J
    :try_end_7d
    .catchall {:try_start_79 .. :try_end_7d} :catchall_215

    .line 125
    .line 126
    :try_start_7d
    monitor-exit v5

    .line 127
    iget-object v3, v1, Lb71;->e:Ll;

    .line 128
    .line 129
    iget-object v4, v12, La71;->b:Ljava/lang/Object;

    .line 130
    .line 131
    iget-object v5, v12, La71;->c:Lzj0;

    .line 132
    .line 133
    iget v6, v12, La71;->d:I

    .line 134
    .line 135
    iput-object v0, v12, La71;->b:Ljava/lang/Object;

    .line 136
    .line 137
    iget-object v8, v12, La71;->f:Lhk0;

    .line 138
    .line 139
    invoke-virtual {v8, v0}, Lhk0;->g(Ljava/lang/Object;)Ljava/lang/Object;

    .line 140
    .line 141
    .line 142
    move-result-object v0

    .line 143
    check-cast v0, Lzj0;

    .line 144
    .line 145
    iput-object v0, v12, La71;->c:Lzj0;

    .line 146
    .line 147
    iget v0, v12, La71;->d:I

    .line 148
    .line 149
    const/4 v8, -0x1

    .line 150
    if-ne v0, v8, :cond_ad

    .line 151
    .line 152
    invoke-static {}, Ln61;->j()Lg61;

    .line 153
    .line 154
    .line 155
    move-result-object v0

    .line 156
    invoke-virtual {v0}, Lg61;->g()J

    .line 157
    .line 158
    .line 159
    move-result-wide v15

    .line 160
    const/16 v0, 0x20

    .line 161
    .line 162
    ushr-long v17, v15, v0

    .line 163
    .line 164
    xor-long v9, v15, v17

    .line 165
    .line 166
    long-to-int v8, v9

    .line 167
    iput v8, v12, La71;->d:I

    .line 168
    .line 169
    goto :goto_ad

    .line 170
    :catchall_a9
    move-exception v0

    .line 171
    move-object v3, v1

    .line 172
    goto/16 :goto_219

    .line 173
    .line 174
    :cond_ad
    :goto_ad
    iget-object v8, v12, La71;->i:Lc10;

    .line 175
    .line 176
    invoke-static {}, Lmc0;->i()Lqk0;

    .line 177
    .line 178
    .line 179
    move-result-object v9
    :try_end_b3
    .catchall {:try_start_7d .. :try_end_b3} :catchall_a9

    .line 180
    :try_start_b3
    invoke-virtual {v9, v8}, Lqk0;->b(Ljava/lang/Object;)V

    .line 181
    .line 182
    .line 183
    if-nez v3, :cond_c3

    .line 184
    .line 185
    invoke-interface/range {p3 .. p3}, Lxz;->a()Ljava/lang/Object;

    .line 186
    .line 187
    .line 188
    goto/16 :goto_140

    .line 189
    .line 190
    :catchall_bd
    move-exception v0

    .line 191
    move-object v3, v1

    .line 192
    :goto_bf
    move/from16 p2, v7

    .line 193
    .line 194
    goto/16 :goto_20b

    .line 195
    .line 196
    :cond_c3
    sget-object v8, Ln61;->b:Lk9;

    .line 197
    .line 198
    invoke-virtual {v8}, Lk9;->p()Ljava/lang/Object;

    .line 199
    .line 200
    .line 201
    move-result-object v8

    .line 202
    check-cast v8, Lg61;

    .line 203
    .line 204
    instance-of v10, v8, Lhd1;
    :try_end_cd
    .catchall {:try_start_b3 .. :try_end_cd} :catchall_bd

    .line 205
    .line 206
    if-eqz v10, :cond_110

    .line 207
    .line 208
    :try_start_cf
    move-object v10, v8

    .line 209
    check-cast v10, Lhd1;

    .line 210
    .line 211
    iget-wide v0, v10, Lhd1;->t:J

    .line 212
    .line 213
    invoke-static {}, Lkb0;->j()J

    .line 214
    .line 215
    .line 216
    move-result-wide v15

    .line 217
    cmp-long v0, v0, v15

    .line 218
    .line 219
    if-nez v0, :cond_110

    .line 220
    .line 221
    move-object v0, v8

    .line 222
    check-cast v0, Lhd1;

    .line 223
    .line 224
    iget-object v1, v0, Lhd1;->r:Li00;

    .line 225
    .line 226
    move-object v0, v8

    .line 227
    check-cast v0, Lhd1;

    .line 228
    .line 229
    iget-object v10, v0, Lhd1;->s:Li00;
    :try_end_e6
    .catchall {:try_start_cf .. :try_end_e6} :catchall_101

    .line 230
    .line 231
    :try_start_e6
    move-object v0, v8

    .line 232
    check-cast v0, Lhd1;

    .line 233
    .line 234
    invoke-static {v3, v1, v7}, Ln61;->k(Li00;Li00;Z)Li00;

    .line 235
    .line 236
    .line 237
    move-result-object v3

    .line 238
    iput-object v3, v0, Lhd1;->r:Li00;

    .line 239
    .line 240
    move-object v0, v8

    .line 241
    check-cast v0, Lhd1;

    .line 242
    .line 243
    iput-object v10, v0, Lhd1;->s:Li00;

    .line 244
    .line 245
    invoke-interface/range {p3 .. p3}, Lxz;->a()Ljava/lang/Object;
    :try_end_f7
    .catchall {:try_start_e6 .. :try_end_f7} :catchall_105

    .line 246
    .line 247
    .line 248
    :try_start_f7
    move-object v0, v8

    .line 249
    check-cast v0, Lhd1;

    .line 250
    .line 251
    iput-object v1, v0, Lhd1;->r:Li00;

    .line 252
    .line 253
    check-cast v8, Lhd1;

    .line 254
    .line 255
    iput-object v10, v8, Lhd1;->s:Li00;

    .line 256
    .line 257
    goto :goto_140

    .line 258
    :catchall_101
    move-exception v0

    .line 259
    move-object/from16 v3, p0

    .line 260
    .line 261
    goto :goto_bf

    .line 262
    :catchall_105
    move-exception v0

    .line 263
    move-object v3, v8

    .line 264
    check-cast v3, Lhd1;

    .line 265
    .line 266
    iput-object v1, v3, Lhd1;->r:Li00;

    .line 267
    .line 268
    check-cast v8, Lhd1;

    .line 269
    .line 270
    iput-object v10, v8, Lhd1;->s:Li00;

    .line 271
    .line 272
    throw v0

    .line 273
    :cond_110
    if-eqz v8, :cond_11d

    .line 274
    .line 275
    instance-of v0, v8, Llk0;

    .line 276
    .line 277
    if-eqz v0, :cond_117

    .line 278
    .line 279
    goto :goto_11d

    .line 280
    :cond_117
    invoke-virtual {v8, v3}, Lg61;->u(Li00;)Lg61;

    .line 281
    .line 282
    .line 283
    move-result-object v0

    .line 284
    move-object v15, v0

    .line 285
    goto :goto_133

    .line 286
    :cond_11d
    :goto_11d
    new-instance v15, Lhd1;

    .line 287
    .line 288
    instance-of v0, v8, Llk0;

    .line 289
    .line 290
    if-eqz v0, :cond_126

    .line 291
    .line 292
    move-object v11, v8

    .line 293
    check-cast v11, Llk0;

    .line 294
    .line 295
    :cond_126
    move-object/from16 v16, v11

    .line 296
    .line 297
    const/16 v19, 0x1

    .line 298
    .line 299
    const/16 v20, 0x0

    .line 300
    .line 301
    const/16 v18, 0x0

    .line 302
    .line 303
    move-object/from16 v17, v3

    .line 304
    .line 305
    invoke-direct/range {v15 .. v20}, Lhd1;-><init>(Llk0;Li00;Li00;ZZ)V
    :try_end_133
    .catchall {:try_start_f7 .. :try_end_133} :catchall_101

    .line 306
    .line 307
    .line 308
    :goto_133
    :try_start_133
    invoke-virtual {v15}, Lg61;->j()Lg61;

    .line 309
    .line 310
    .line 311
    move-result-object v1
    :try_end_137
    .catchall {:try_start_133 .. :try_end_137} :catchall_1f6

    .line 312
    :try_start_137
    invoke-interface/range {p3 .. p3}, Lxz;->a()Ljava/lang/Object;
    :try_end_13a
    .catchall {:try_start_137 .. :try_end_13a} :catchall_1fc

    .line 313
    .line 314
    .line 315
    :try_start_13a
    invoke-static {v1}, Lg61;->q(Lg61;)V
    :try_end_13d
    .catchall {:try_start_13a .. :try_end_13d} :catchall_1f6

    .line 316
    .line 317
    .line 318
    :try_start_13d
    invoke-virtual {v15}, Lg61;->c()V
    :try_end_140
    .catchall {:try_start_13d .. :try_end_140} :catchall_101

    .line 319
    .line 320
    .line 321
    :goto_140
    :try_start_140
    iget v0, v9, Lqk0;->g:I

    .line 322
    .line 323
    sub-int/2addr v0, v7

    .line 324
    invoke-virtual {v9, v0}, Lqk0;->k(I)Ljava/lang/Object;

    .line 325
    .line 326
    .line 327
    iget-object v0, v12, La71;->b:Ljava/lang/Object;

    .line 328
    .line 329
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 330
    .line 331
    .line 332
    iget v1, v12, La71;->d:I

    .line 333
    .line 334
    iget-object v3, v12, La71;->c:Lzj0;

    .line 335
    .line 336
    if-eqz v3, :cond_1dd

    .line 337
    .line 338
    iget-object v8, v3, Lzj0;->a:[J

    .line 339
    .line 340
    array-length v9, v8

    .line 341
    add-int/lit8 v9, v9, -0x2

    .line 342
    .line 343
    if-ltz v9, :cond_1dd

    .line 344
    .line 345
    move v11, v7

    .line 346
    move-object v15, v8

    .line 347
    const/4 v10, 0x0

    .line 348
    :goto_15b
    aget-wide v7, v15, v10

    .line 349
    .line 350
    move/from16 p2, v11

    .line 351
    .line 352
    move-object/from16 v16, v12

    .line 353
    .line 354
    not-long v11, v7

    .line 355
    const/16 v17, 0x7

    .line 356
    .line 357
    shl-long v11, v11, v17

    .line 358
    .line 359
    and-long/2addr v11, v7

    .line 360
    const-wide v17, -0x7f7f7f7f7f7f7f80L  # -2.937446524422997E-306

    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    and-long v11, v11, v17

    .line 366
    .line 367
    cmp-long v11, v11, v17

    .line 368
    .line 369
    if-eqz v11, :cond_1ce

    .line 370
    .line 371
    sub-int v11, v10, v9

    .line 372
    .line 373
    not-int v11, v11

    .line 374
    ushr-int/lit8 v11, v11, 0x1f

    .line 375
    .line 376
    const/16 v12, 0x8

    .line 377
    .line 378
    rsub-int/lit8 v11, v11, 0x8

    .line 379
    .line 380
    move/from16 p3, v12

    .line 381
    .line 382
    const/4 v12, 0x0

    .line 383
    :goto_17e
    if-ge v12, v11, :cond_1c5

    .line 384
    .line 385
    const-wide/16 v17, 0xff

    .line 386
    .line 387
    and-long v17, v7, v17

    .line 388
    .line 389
    const-wide/16 v19, 0x80

    .line 390
    .line 391
    cmp-long v17, v17, v19

    .line 392
    .line 393
    if-gez v17, :cond_1b4

    .line 394
    .line 395
    shl-int/lit8 v17, v10, 0x3

    .line 396
    .line 397
    move-wide/from16 v18, v7

    .line 398
    .line 399
    add-int v7, v17, v12

    .line 400
    .line 401
    iget-object v8, v3, Lzj0;->b:[Ljava/lang/Object;

    .line 402
    .line 403
    aget-object v8, v8, v7

    .line 404
    .line 405
    move/from16 v17, v12

    .line 406
    .line 407
    iget-object v12, v3, Lzj0;->c:[I

    .line 408
    .line 409
    aget v12, v12, v7

    .line 410
    .line 411
    if-eq v12, v1, :cond_19f

    .line 412
    .line 413
    move/from16 v12, p2

    .line 414
    .line 415
    goto :goto_1a0

    .line 416
    :cond_19f
    const/4 v12, 0x0

    .line 417
    :goto_1a0
    if-eqz v12, :cond_1aa

    .line 418
    .line 419
    move/from16 v20, v1

    .line 420
    .line 421
    move-object/from16 v1, v16

    .line 422
    .line 423
    invoke-virtual {v1, v0, v8}, La71;->c(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 424
    .line 425
    .line 426
    goto :goto_1ae

    .line 427
    :cond_1aa
    move/from16 v20, v1

    .line 428
    .line 429
    move-object/from16 v1, v16

    .line 430
    .line 431
    :goto_1ae
    if-eqz v12, :cond_1bc

    .line 432
    .line 433
    invoke-virtual {v3, v7}, Lzj0;->f(I)V

    .line 434
    .line 435
    .line 436
    goto :goto_1bc

    .line 437
    :cond_1b4
    move/from16 v20, v1

    .line 438
    .line 439
    move-wide/from16 v18, v7

    .line 440
    .line 441
    move/from16 v17, v12

    .line 442
    .line 443
    move-object/from16 v1, v16

    .line 444
    .line 445
    :cond_1bc
    :goto_1bc
    shr-long v7, v18, p3

    .line 446
    .line 447
    add-int/lit8 v12, v17, 0x1

    .line 448
    .line 449
    move-object/from16 v16, v1

    .line 450
    .line 451
    move/from16 v1, v20

    .line 452
    .line 453
    goto :goto_17e

    .line 454
    :cond_1c5
    move/from16 v7, p3

    .line 455
    .line 456
    move/from16 v20, v1

    .line 457
    .line 458
    move-object/from16 v1, v16

    .line 459
    .line 460
    if-ne v11, v7, :cond_1de

    .line 461
    .line 462
    goto :goto_1d2

    .line 463
    :cond_1ce
    move/from16 v20, v1

    .line 464
    .line 465
    move-object/from16 v1, v16

    .line 466
    .line 467
    :goto_1d2
    if-eq v10, v9, :cond_1de

    .line 468
    .line 469
    add-int/lit8 v10, v10, 0x1

    .line 470
    .line 471
    move/from16 v11, p2

    .line 472
    .line 473
    move-object v12, v1

    .line 474
    move/from16 v1, v20

    .line 475
    .line 476
    goto/16 :goto_15b

    .line 477
    .line 478
    :cond_1dd
    move-object v1, v12

    .line 479
    :cond_1de
    iput-object v4, v1, La71;->b:Ljava/lang/Object;

    .line 480
    .line 481
    iput-object v5, v1, La71;->c:Lzj0;

    .line 482
    .line 483
    iput v6, v1, La71;->d:I
    :try_end_1e4
    .catchall {:try_start_140 .. :try_end_1e4} :catchall_1f2

    .line 484
    .line 485
    move-object/from16 v3, p0

    .line 486
    .line 487
    iget-object v1, v3, Lb71;->g:Ljava/lang/Object;

    .line 488
    .line 489
    monitor-enter v1

    .line 490
    :try_start_1e9
    iput-object v2, v3, Lb71;->i:La71;

    .line 491
    .line 492
    iput-wide v13, v3, Lb71;->j:J
    :try_end_1ed
    .catchall {:try_start_1e9 .. :try_end_1ed} :catchall_1ef

    .line 493
    .line 494
    monitor-exit v1

    .line 495
    return-void

    .line 496
    :catchall_1ef
    move-exception v0

    .line 497
    monitor-exit v1

    .line 498
    throw v0

    .line 499
    :catchall_1f2
    move-exception v0

    .line 500
    move-object/from16 v3, p0

    .line 501
    .line 502
    goto :goto_219

    .line 503
    :catchall_1f6
    move-exception v0

    .line 504
    move-object/from16 v3, p0

    .line 505
    .line 506
    move/from16 p2, v7

    .line 507
    .line 508
    goto :goto_206

    .line 509
    :catchall_1fc
    move-exception v0

    .line 510
    move-object/from16 v3, p0

    .line 511
    .line 512
    move/from16 p2, v7

    .line 513
    .line 514
    :try_start_201
    invoke-static {v1}, Lg61;->q(Lg61;)V

    .line 515
    .line 516
    .line 517
    throw v0
    :try_end_205
    .catchall {:try_start_201 .. :try_end_205} :catchall_205

    .line 518
    :catchall_205
    move-exception v0

    .line 519
    :goto_206
    :try_start_206
    invoke-virtual {v15}, Lg61;->c()V

    .line 520
    .line 521
    .line 522
    throw v0
    :try_end_20a
    .catchall {:try_start_206 .. :try_end_20a} :catchall_20a

    .line 523
    :catchall_20a
    move-exception v0

    .line 524
    :goto_20b
    :try_start_20b
    iget v1, v9, Lqk0;->g:I

    .line 525
    .line 526
    add-int/lit8 v1, v1, -0x1

    .line 527
    .line 528
    invoke-virtual {v9, v1}, Lqk0;->k(I)Ljava/lang/Object;

    .line 529
    .line 530
    .line 531
    throw v0

    .line 532
    :catchall_213
    move-exception v0

    .line 533
    goto :goto_219

    .line 534
    :catchall_215
    move-exception v0

    .line 535
    move-object v3, v1

    .line 536
    monitor-exit v5

    .line 537
    throw v0
    :try_end_219
    .catchall {:try_start_20b .. :try_end_219} :catchall_213

    .line 538
    :goto_219
    iget-object v1, v3, Lb71;->g:Ljava/lang/Object;

    .line 539
    .line 540
    monitor-enter v1

    .line 541
    :try_start_21c
    iput-object v2, v3, Lb71;->i:La71;

    .line 542
    .line 543
    iput-wide v13, v3, Lb71;->j:J
    :try_end_220
    .catchall {:try_start_21c .. :try_end_220} :catchall_222

    .line 544
    .line 545
    monitor-exit v1

    .line 546
    throw v0

    .line 547
    :catchall_222
    move-exception v0

    .line 548
    monitor-exit v1

    .line 549
    throw v0

    .line 550
    :catchall_225
    move-exception v0

    .line 551
    monitor-exit v5

    .line 552
    throw v0
.end method

.method public final c()V
    .registers 4

    .line 1
    iget-object v0, p0, Lb71;->d:Lhc;

    .line 2
    .line 3
    sget-object v1, Ln61;->a:Lf11;

    .line 4
    .line 5
    invoke-static {v1}, Ln61;->e(Li00;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    sget-object v1, Ln61;->c:Ljava/lang/Object;

    .line 9
    .line 10
    monitor-enter v1

    .line 11
    :try_start_a
    sget-object v2, Ln61;->h:Ljava/util/List;

    .line 12
    .line 13
    invoke-static {v2, v0}, Ltg;->Y(Ljava/util/Collection;Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 14
    .line 15
    .line 16
    move-result-object v2

    .line 17
    sput-object v2, Ln61;->h:Ljava/util/List;
    :try_end_12
    .catchall {:try_start_a .. :try_end_12} :catchall_1b

    .line 18
    .line 19
    monitor-exit v1

    .line 20
    new-instance v1, Lm2;

    .line 21
    .line 22
    invoke-direct {v1, v0}, Lm2;-><init>(Ljava/lang/Object;)V

    .line 23
    .line 24
    .line 25
    iput-object v1, p0, Lb71;->h:Lm2;

    .line 26
    .line 27
    return-void

    .line 28
    :catchall_1b
    move-exception p0

    .line 29
    monitor-exit v1

    .line 30
    throw p0
.end method
