.class public final Le70;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# instance fields
.field public final a:Lxf0;

.field public final b:Lal;

.field public c:Z


# direct methods
.method public constructor <init>(Lxf0;Lal;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Le70;->a:Lxf0;

    .line 5
    .line 6
    iput-object p2, p0, Le70;->b:Lal;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final a(J)Z
    .registers 9

    .line 1
    iget-object p0, p0, Le70;->b:Lal;

    .line 2
    .line 3
    iget-object p0, p0, Lal;->f:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast p0, Ljava/util/List;

    .line 6
    .line 7
    invoke-interface {p0}, Ljava/util/Collection;->size()I

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    const/4 v1, 0x0

    .line 12
    move v2, v1

    .line 13
    :goto_c
    if-ge v2, v0, :cond_21

    .line 14
    .line 15
    invoke-interface {p0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v3

    .line 19
    move-object v4, v3

    .line 20
    check-cast v4, Lft0;

    .line 21
    .line 22
    iget-wide v4, v4, Lft0;->a:J

    .line 23
    .line 24
    invoke-static {v4, v5, p1, p2}, Lsb0;->k(JJ)Z

    .line 25
    .line 26
    .line 27
    move-result v4

    .line 28
    if-eqz v4, :cond_1e

    .line 29
    .line 30
    goto :goto_22

    .line 31
    :cond_1e
    add-int/lit8 v2, v2, 0x1

    .line 32
    .line 33
    goto :goto_c

    .line 34
    :cond_21
    const/4 v3, 0x0

    .line 35
    :goto_22
    check-cast v3, Lft0;

    .line 36
    .line 37
    if-eqz v3, :cond_29

    .line 38
    .line 39
    iget-boolean p0, v3, Lft0;->h:Z

    .line 40
    .line 41
    return p0

    .line 42
    :cond_29
    return v1
.end method
