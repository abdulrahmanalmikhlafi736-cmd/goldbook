.class public final Lbl1;
.super Landroid/database/ContentObserver;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# instance fields
.field public final synthetic a:Lid;


# direct methods
.method public constructor <init>(Lid;Landroid/os/Handler;)V
    .registers 3

    .line 1
    iput-object p1, p0, Lbl1;->a:Lid;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Landroid/database/ContentObserver;-><init>(Landroid/os/Handler;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onChange(ZLandroid/net/Uri;)V
    .registers 3

    .line 1
    iget-object p0, p0, Lbl1;->a:Lid;

    .line 2
    .line 3
    sget-object p1, Lwe1;->a:Lwe1;

    .line 4
    .line 5
    invoke-interface {p0, p1}, Lz21;->s(Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    return-void
.end method
