.class public final Leh1;
.super Lcs;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# virtual methods
.method public final dispatchDraw(Landroid/graphics/Canvas;)V
    .registers 2

    .line 1
    return-void
.end method

.method public final dispatchGetDisplayList()V
    .registers 1

    .line 1
    return-void
.end method
