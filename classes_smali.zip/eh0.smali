.class public final synthetic Leh0;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lm00;


# instance fields
.field public final synthetic e:I

.field public final synthetic f:Lke1;

.field public final synthetic g:Lpi;


# direct methods
.method public synthetic constructor <init>(Lke1;Lpi;I)V
    .registers 4

    .line 1
    iput p3, p0, Leh0;->e:I

    .line 2
    .line 3
    iput-object p1, p0, Leh0;->f:Lke1;

    .line 4
    .line 5
    iput-object p2, p0, Leh0;->g:Lpi;

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 9

    .line 1
    iget v0, p0, Leh0;->e:I

    .line 2
    .line 3
    sget-object v1, Lwe1;->a:Lwe1;

    .line 4
    .line 5
    const/4 v2, 0x2

    .line 6
    const/4 v3, 0x0

    .line 7
    iget-object v4, p0, Leh0;->g:Lpi;

    .line 8
    .line 9
    iget-object p0, p0, Leh0;->f:Lke1;

    .line 10
    .line 11
    const/4 v5, 0x1

    .line 12
    check-cast p1, Ld10;

    .line 13
    .line 14
    check-cast p2, Ljava/lang/Integer;

    .line 15
    .line 16
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 17
    .line 18
    .line 19
    move-result p2

    .line 20
    packed-switch v0, :pswitch_data_50

    .line 21
    .line 22
    .line 23
    and-int/lit8 v0, p2, 0x3

    .line 24
    .line 25
    if-eq v0, v2, :cond_1c

    .line 26
    .line 27
    move v0, v5

    .line 28
    goto :goto_1d

    .line 29
    :cond_1c
    move v0, v3

    .line 30
    :goto_1d
    and-int/2addr p2, v5

    .line 31
    invoke-virtual {p1, p2, v0}, Ld10;->O(IZ)Z

    .line 32
    .line 33
    .line 34
    move-result p2

    .line 35
    if-eqz p2, :cond_2a

    .line 36
    .line 37
    iget-object p0, p0, Lke1;->j:Lob1;

    .line 38
    .line 39
    invoke-static {p0, v4, p1, v3}, Lza1;->a(Lob1;Lpi;Ld10;I)V

    .line 40
    .line 41
    .line 42
    goto :goto_2d

    .line 43
    :cond_2a
    invoke-virtual {p1}, Ld10;->R()V

    .line 44
    .line 45
    .line 46
    :goto_2d
    return-object v1

    .line 47
    :pswitch_2e  #0x0
    and-int/lit8 v0, p2, 0x3

    .line 48
    .line 49
    if-eq v0, v2, :cond_33

    .line 50
    .line 51
    move v3, v5

    .line 52
    :cond_33
    and-int/2addr p2, v5

    .line 53
    invoke-virtual {p1, p2, v3}, Ld10;->O(IZ)Z

    .line 54
    .line 55
    .line 56
    move-result p2

    .line 57
    if-eqz p2, :cond_4b

    .line 58
    .line 59
    new-instance p2, Leh0;

    .line 60
    .line 61
    invoke-direct {p2, p0, v4, v5}, Leh0;-><init>(Lke1;Lpi;I)V

    .line 62
    .line 63
    .line 64
    const p0, -0xe658f05

    .line 65
    .line 66
    .line 67
    invoke-static {p0, p2, p1}, Lvd1;->A(ILu00;Ld10;)Lpi;

    .line 68
    .line 69
    .line 70
    move-result-object p0

    .line 71
    const/4 p2, 0x6

    .line 72
    invoke-static {p0, p1, p2}, Lqt0;->a(Lpi;Ld10;I)V

    .line 73
    .line 74
    .line 75
    goto :goto_4e

    .line 76
    :cond_4b
    invoke-virtual {p1}, Ld10;->R()V

    .line 77
    .line 78
    .line 79
    :goto_4e
    return-object v1

    .line 80
    nop

    .line 81
    :pswitch_data_50
    .packed-switch 0x0
        :pswitch_2e  #00000000
    .end packed-switch
.end method
