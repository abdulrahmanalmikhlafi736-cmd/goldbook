.class public Lap;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Ljh1;


# static fields
.field public static final b:Lap;

.field public static c:Lap;


# instance fields
.field public final synthetic a:I


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Lap;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Lap;-><init>(I)V

    .line 5
    .line 6
    .line 7
    sput-object v0, Lap;->b:Lap;

    .line 8
    .line 9
    return-void
.end method

.method public synthetic constructor <init>(I)V
    .registers 2

    .line 1
    iput p1, p0, Lap;->a:I

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public a(Ljava/lang/Class;)Lfh1;
    .registers 3

    .line 1
    iget p0, p0, Lap;->a:I

    .line 2
    .line 3
    const-string v0, "`Factory.create(String, CreationExtras)` is not implemented. You may need to override the method and provide a custom implementation. Note that using `Factory.create(String)` is not supported and considered an error."

    .line 4
    .line 5
    packed-switch p0, :pswitch_data_18

    .line 6
    .line 7
    .line 8
    invoke-static {p1}, Lzi1;->r(Ljava/lang/Class;)Lfh1;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0

    .line 13
    :pswitch_c  #0x1
    new-instance p0, Ljava/lang/UnsupportedOperationException;

    .line 14
    .line 15
    invoke-direct {p0, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    throw p0

    .line 19
    :pswitch_12  #0x0
    new-instance p0, Ljava/lang/UnsupportedOperationException;

    .line 20
    .line 21
    invoke-direct {p0, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    throw p0

    .line 25
    :pswitch_data_18
    .packed-switch 0x0
        :pswitch_12  #00000000
        :pswitch_c  #00000001
    .end packed-switch
.end method

.method public b(Ljava/lang/Class;Lpj0;)Lfh1;
    .registers 4

    .line 1
    iget p2, p0, Lap;->a:I

    .line 2
    .line 3
    const/4 v0, 0x0

    .line 4
    packed-switch p2, :pswitch_data_14

    .line 5
    .line 6
    .line 7
    invoke-virtual {p0, p1}, Lap;->a(Ljava/lang/Class;)Lfh1;

    .line 8
    .line 9
    .line 10
    move-result-object p0

    .line 11
    return-object p0

    .line 12
    :pswitch_b  #0x1
    invoke-virtual {p0, p1}, Lap;->a(Ljava/lang/Class;)Lfh1;

    .line 13
    .line 14
    .line 15
    throw v0

    .line 16
    :pswitch_f  #0x0
    invoke-virtual {p0, p1}, Lap;->a(Ljava/lang/Class;)Lfh1;

    .line 17
    .line 18
    .line 19
    throw v0

    .line 20
    nop

    .line 21
    :pswitch_data_14
    .packed-switch 0x0
        :pswitch_f  #00000000
        :pswitch_b  #00000001
    .end packed-switch
.end method

.method public final c(Lwf;Lpj0;)Lfh1;
    .registers 4

    .line 1
    iget v0, p0, Lap;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_20

    .line 4
    .line 5
    .line 6
    iget-object p1, p1, Lwf;->a:Ljava/lang/Class;

    .line 7
    .line 8
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9
    .line 10
    .line 11
    invoke-virtual {p0, p1, p2}, Lap;->b(Ljava/lang/Class;Lpj0;)Lfh1;

    .line 12
    .line 13
    .line 14
    move-result-object p0

    .line 15
    return-object p0

    .line 16
    :pswitch_f  #0x1
    new-instance p0, Ltz0;

    .line 17
    .line 18
    invoke-direct {p0}, Ltz0;-><init>()V

    .line 19
    .line 20
    .line 21
    return-object p0

    .line 22
    :pswitch_15  #0x0
    iget-object p0, p1, Lwf;->a:Ljava/lang/Class;

    .line 23
    .line 24
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 25
    .line 26
    .line 27
    invoke-static {p0}, Lzi1;->r(Ljava/lang/Class;)Lfh1;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    return-object p0

    .line 32
    nop

    .line 33
    :pswitch_data_20
    .packed-switch 0x0
        :pswitch_15  #00000000
        :pswitch_f  #00000001
    .end packed-switch
.end method
