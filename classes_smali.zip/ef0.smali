.class public abstract Lef0;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"


# static fields
.field public static final a:Lk81;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Li2;

    .line 2
    .line 3
    const/16 v1, 0x16

    .line 4
    .line 5
    invoke-direct {v0, v1}, Li2;-><init>(I)V

    .line 6
    .line 7
    .line 8
    new-instance v1, Lk81;

    .line 9
    .line 10
    invoke-direct {v1, v0}, Llv0;-><init>(Lxz;)V

    .line 11
    .line 12
    .line 13
    sput-object v1, Lef0;->a:Lk81;

    .line 14
    .line 15
    return-void
.end method
