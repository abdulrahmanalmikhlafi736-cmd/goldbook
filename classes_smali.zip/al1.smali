.class public final Lal1;
.super Lu91;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Lm00;


# instance fields
.field public i:Lhd;

.field public j:I

.field public synthetic k:Ljava/lang/Object;

.field public final synthetic l:Landroid/content/ContentResolver;

.field public final synthetic m:Landroid/net/Uri;

.field public final synthetic n:Lbl1;

.field public final synthetic o:Lid;

.field public final synthetic p:Landroid/content/Context;


# direct methods
.method public constructor <init>(Landroid/content/ContentResolver;Landroid/net/Uri;Lbl1;Lid;Landroid/content/Context;Lml;)V
    .registers 7

    .line 1
    iput-object p1, p0, Lal1;->l:Landroid/content/ContentResolver;

    .line 2
    .line 3
    iput-object p2, p0, Lal1;->m:Landroid/net/Uri;

    .line 4
    .line 5
    iput-object p3, p0, Lal1;->n:Lbl1;

    .line 6
    .line 7
    iput-object p4, p0, Lal1;->o:Lid;

    .line 8
    .line 9
    iput-object p5, p0, Lal1;->p:Landroid/content/Context;

    .line 10
    .line 11
    const/4 p1, 0x2

    .line 12
    invoke-direct {p0, p1, p6}, Lu91;-><init>(ILml;)V

    .line 13
    .line 14
    .line 15
    return-void
.end method


# virtual methods
.method public final f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 1
    check-cast p1, Luw;

    .line 2
    .line 3
    check-cast p2, Lml;

    .line 4
    .line 5
    invoke-virtual {p0, p2, p1}, Lal1;->n(Lml;Ljava/lang/Object;)Lml;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    check-cast p0, Lal1;

    .line 10
    .line 11
    sget-object p1, Lwe1;->a:Lwe1;

    .line 12
    .line 13
    invoke-virtual {p0, p1}, Lal1;->p(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method

.method public final n(Lml;Ljava/lang/Object;)Lml;
    .registers 10

    .line 1
    new-instance v0, Lal1;

    .line 2
    .line 3
    iget-object v4, p0, Lal1;->o:Lid;

    .line 4
    .line 5
    iget-object v5, p0, Lal1;->p:Landroid/content/Context;

    .line 6
    .line 7
    iget-object v1, p0, Lal1;->l:Landroid/content/ContentResolver;

    .line 8
    .line 9
    iget-object v2, p0, Lal1;->m:Landroid/net/Uri;

    .line 10
    .line 11
    iget-object v3, p0, Lal1;->n:Lbl1;

    .line 12
    .line 13
    move-object v6, p1

    .line 14
    invoke-direct/range {v0 .. v6}, Lal1;-><init>(Landroid/content/ContentResolver;Landroid/net/Uri;Lbl1;Lid;Landroid/content/Context;Lml;)V

    .line 15
    .line 16
    .line 17
    iput-object p2, v0, Lal1;->k:Ljava/lang/Object;

    .line 18
    .line 19
    return-object v0
.end method

.method public final p(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 12

    .line 1
    iget v0, p0, Lal1;->j:I

    .line 2
    .line 3
    const/4 v1, 0x2

    .line 4
    const/4 v2, 0x1

    .line 5
    iget-object v3, p0, Lal1;->n:Lbl1;

    .line 6
    .line 7
    iget-object v4, p0, Lal1;->l:Landroid/content/ContentResolver;

    .line 8
    .line 9
    sget-object v5, Lcm;->e:Lcm;

    .line 10
    .line 11
    if-eqz v0, :cond_2f

    .line 12
    .line 13
    if-eq v0, v2, :cond_25

    .line 14
    .line 15
    if-ne v0, v1, :cond_1e

    .line 16
    .line 17
    iget-object v0, p0, Lal1;->i:Lhd;

    .line 18
    .line 19
    iget-object v6, p0, Lal1;->k:Ljava/lang/Object;

    .line 20
    .line 21
    check-cast v6, Luw;

    .line 22
    .line 23
    :try_start_16
    invoke-static {p1}, Lnb0;->t(Ljava/lang/Object;)V
    :try_end_19
    .catchall {:try_start_16 .. :try_end_19} :catchall_1c

    .line 24
    .line 25
    .line 26
    :cond_19
    move-object p1, v6

    .line 27
    move-object v6, v0

    .line 28
    goto :goto_43

    .line 29
    :catchall_1c
    move-exception p0

    .line 30
    goto :goto_85

    .line 31
    :cond_1e
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 32
    .line 33
    invoke-static {p0}, Lod;->p(Ljava/lang/String;)V

    .line 34
    .line 35
    .line 36
    const/4 p0, 0x0

    .line 37
    return-object p0

    .line 38
    :cond_25
    iget-object v0, p0, Lal1;->i:Lhd;

    .line 39
    .line 40
    iget-object v6, p0, Lal1;->k:Ljava/lang/Object;

    .line 41
    .line 42
    check-cast v6, Luw;

    .line 43
    .line 44
    :try_start_2b
    invoke-static {p1}, Lnb0;->t(Ljava/lang/Object;)V
    :try_end_2e
    .catchall {:try_start_2b .. :try_end_2e} :catchall_1c

    .line 45
    .line 46
    .line 47
    goto :goto_54

    .line 48
    :cond_2f
    invoke-static {p1}, Lnb0;->t(Ljava/lang/Object;)V

    .line 49
    .line 50
    .line 51
    iget-object p1, p0, Lal1;->k:Ljava/lang/Object;

    .line 52
    .line 53
    check-cast p1, Luw;

    .line 54
    .line 55
    iget-object v0, p0, Lal1;->m:Landroid/net/Uri;

    .line 56
    .line 57
    const/4 v6, 0x0

    .line 58
    invoke-virtual {v4, v0, v6, v3}, Landroid/content/ContentResolver;->registerContentObserver(Landroid/net/Uri;ZLandroid/database/ContentObserver;)V

    .line 59
    .line 60
    .line 61
    :try_start_3c
    iget-object v0, p0, Lal1;->o:Lid;

    .line 62
    .line 63
    new-instance v6, Lhd;

    .line 64
    .line 65
    invoke-direct {v6, v0}, Lhd;-><init>(Lid;)V

    .line 66
    .line 67
    .line 68
    :goto_43
    iput-object p1, p0, Lal1;->k:Ljava/lang/Object;

    .line 69
    .line 70
    iput-object v6, p0, Lal1;->i:Lhd;

    .line 71
    .line 72
    iput v2, p0, Lal1;->j:I

    .line 73
    .line 74
    invoke-virtual {v6, p0}, Lhd;->b(Lnl;)Ljava/lang/Object;

    .line 75
    .line 76
    .line 77
    move-result-object v0

    .line 78
    if-ne v0, v5, :cond_50

    .line 79
    .line 80
    goto :goto_7e

    .line 81
    :cond_50
    move-object v9, v6

    .line 82
    move-object v6, p1

    .line 83
    move-object p1, v0

    .line 84
    move-object v0, v9

    .line 85
    :goto_54
    check-cast p1, Ljava/lang/Boolean;

    .line 86
    .line 87
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 88
    .line 89
    .line 90
    move-result p1

    .line 91
    if-eqz p1, :cond_7f

    .line 92
    .line 93
    invoke-virtual {v0}, Lhd;->c()Ljava/lang/Object;

    .line 94
    .line 95
    .line 96
    iget-object p1, p0, Lal1;->p:Landroid/content/Context;

    .line 97
    .line 98
    invoke-virtual {p1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 99
    .line 100
    .line 101
    move-result-object p1

    .line 102
    const-string v7, "animator_duration_scale"

    .line 103
    .line 104
    const/high16 v8, 0x3f800000  # 1.0f

    .line 105
    .line 106
    invoke-static {p1, v7, v8}, Landroid/provider/Settings$Global;->getFloat(Landroid/content/ContentResolver;Ljava/lang/String;F)F

    .line 107
    .line 108
    .line 109
    move-result p1

    .line 110
    new-instance v7, Ljava/lang/Float;

    .line 111
    .line 112
    invoke-direct {v7, p1}, Ljava/lang/Float;-><init>(F)V

    .line 113
    .line 114
    .line 115
    iput-object v6, p0, Lal1;->k:Ljava/lang/Object;

    .line 116
    .line 117
    iput-object v0, p0, Lal1;->i:Lhd;

    .line 118
    .line 119
    iput v1, p0, Lal1;->j:I

    .line 120
    .line 121
    invoke-interface {v6, v7, p0}, Luw;->k(Ljava/lang/Object;Lml;)Ljava/lang/Object;

    .line 122
    .line 123
    .line 124
    move-result-object p1
    :try_end_7c
    .catchall {:try_start_3c .. :try_end_7c} :catchall_1c

    .line 125
    if-ne p1, v5, :cond_19

    .line 126
    .line 127
    :goto_7e
    return-object v5

    .line 128
    :cond_7f
    invoke-virtual {v4, v3}, Landroid/content/ContentResolver;->unregisterContentObserver(Landroid/database/ContentObserver;)V

    .line 129
    .line 130
    .line 131
    sget-object p0, Lwe1;->a:Lwe1;

    .line 132
    .line 133
    return-object p0

    .line 134
    :goto_85
    invoke-virtual {v4, v3}, Landroid/content/ContentResolver;->unregisterContentObserver(Landroid/database/ContentObserver;)V

    .line 135
    .line 136
    .line 137
    throw p0
.end method
