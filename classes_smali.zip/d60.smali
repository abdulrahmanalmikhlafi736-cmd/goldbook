.class public final synthetic Ld60;
.super Ljava/lang/Object;
.source "r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a"

# interfaces
.implements Li00;


# instance fields
.field public final synthetic e:I

.field public final synthetic f:Lvk;


# direct methods
.method public synthetic constructor <init>(Lvk;I)V
    .registers 3

    .line 1
    iput p2, p0, Ld60;->e:I

    .line 2
    .line 3
    iput-object p1, p0, Ld60;->f:Lvk;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final i(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 1
    iget v0, p0, Ld60;->e:I

    .line 2
    .line 3
    iget-object p0, p0, Ld60;->f:Lvk;

    .line 4
    .line 5
    check-cast p1, Lkd1;

    .line 6
    .line 7
    packed-switch v0, :pswitch_data_3c

    .line 8
    .line 9
    .line 10
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    .line 12
    .line 13
    check-cast p1, Lvk;

    .line 14
    .line 15
    iget-object p1, p1, Lvk;->t:Ldj1;

    .line 16
    .line 17
    iput-object p1, p0, Lvk;->s:Ldj1;

    .line 18
    .line 19
    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 20
    .line 21
    return-object p0

    .line 22
    :pswitch_15  #0x0
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 23
    .line 24
    .line 25
    check-cast p1, Lvk;

    .line 26
    .line 27
    iget-object p0, p0, Lvk;->t:Ldj1;

    .line 28
    .line 29
    iget-object v0, p1, Lvk;->s:Ldj1;

    .line 30
    .line 31
    invoke-static {v0, p0}, Lk70;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    if-nez v0, :cond_38

    .line 36
    .line 37
    iput-object p0, p1, Lvk;->s:Ldj1;

    .line 38
    .line 39
    iget-object v0, p1, Lvk;->u:Li00;

    .line 40
    .line 41
    invoke-interface {v0, p0}, Li00;->i(Ljava/lang/Object;)Ljava/lang/Object;

    .line 42
    .line 43
    .line 44
    iput-object p0, p1, Lvk;->t:Ldj1;

    .line 45
    .line 46
    new-instance p0, Ld60;

    .line 47
    .line 48
    const/4 v0, 0x0

    .line 49
    invoke-direct {p0, p1, v0}, Ld60;-><init>(Lvk;I)V

    .line 50
    .line 51
    .line 52
    const-string v0, "androidx.compose.foundation.layout.ConsumedInsetsProvider"

    .line 53
    .line 54
    invoke-static {p1, v0, p0}, Lmc0;->F(Lcp;Ljava/lang/String;Li00;)V

    .line 55
    .line 56
    .line 57
    :cond_38
    sget-object p0, Ljd1;->f:Ljd1;

    .line 58
    .line 59
    return-object p0

    .line 60
    nop

    .line 61
    :pswitch_data_3c
    .packed-switch 0x0
        :pswitch_15  #00000000
    .end packed-switch
.end method
