package androidx.core.app;

import android.app.PendingIntent;
import android.os.Parcel;
import android.text.TextUtils;
import androidx.core.graphics.drawable.IconCompat;
import defpackage.kg1;
import defpackage.lg1;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
public class RemoteActionCompatParcelizer {
    public static RemoteActionCompat read(kg1 kg1) {
        RemoteActionCompat remoteActionCompat = new RemoteActionCompat();
        IconCompat iconCompat = remoteActionCompat.a;
        boolean z = true;
        if (kg1.e(1)) {
            iconCompat = kg1.g();
        }
        remoteActionCompat.a = iconCompat;
        CharSequence charSequence = remoteActionCompat.b;
        if (kg1.e(2)) {
            charSequence = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(((lg1) kg1).e);
        }
        remoteActionCompat.b = charSequence;
        charSequence = remoteActionCompat.c;
        if (kg1.e(3)) {
            charSequence = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(((lg1) kg1).e);
        }
        remoteActionCompat.c = charSequence;
        remoteActionCompat.d = (PendingIntent) kg1.f(remoteActionCompat.d, 4);
        boolean z2 = remoteActionCompat.e;
        if (kg1.e(5)) {
            z2 = ((lg1) kg1).e.readInt() != 0;
        }
        remoteActionCompat.e = z2;
        z2 = remoteActionCompat.f;
        if (!kg1.e(6)) {
            z = z2;
        } else if (((lg1) kg1).e.readInt() == 0) {
            z = false;
        }
        remoteActionCompat.f = z;
        return remoteActionCompat;
    }

    public static void write(RemoteActionCompat remoteActionCompat, kg1 kg1) {
        kg1.getClass();
        IconCompat iconCompat = remoteActionCompat.a;
        kg1.h(1);
        kg1.i(iconCompat);
        CharSequence charSequence = remoteActionCompat.b;
        kg1.h(2);
        Parcel parcel = ((lg1) kg1).e;
        TextUtils.writeToParcel(charSequence, parcel, 0);
        charSequence = remoteActionCompat.c;
        kg1.h(3);
        TextUtils.writeToParcel(charSequence, parcel, 0);
        PendingIntent pendingIntent = remoteActionCompat.d;
        kg1.h(4);
        parcel.writeParcelable(pendingIntent, 0);
        boolean z = remoteActionCompat.e;
        kg1.h(5);
        parcel.writeInt(z);
        boolean z2 = remoteActionCompat.f;
        kg1.h(6);
        parcel.writeInt(z2);
    }
}