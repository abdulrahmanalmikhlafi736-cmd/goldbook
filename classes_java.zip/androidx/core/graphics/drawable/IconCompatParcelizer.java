package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.os.Parcel;
import android.os.Parcelable;
import defpackage.gu0;
import defpackage.kg1;
import defpackage.lg1;
import defpackage.od;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
public class IconCompatParcelizer {
    public static IconCompat read(kg1 kg1) {
        IconCompat iconCompat = new IconCompat();
        int i = iconCompat.a;
        if (kg1.e(1)) {
            i = ((lg1) kg1).e.readInt();
        }
        iconCompat.a = i;
        byte[] bArr = iconCompat.c;
        if (kg1.e(2)) {
            Parcel parcel = ((lg1) kg1).e;
            int readInt = parcel.readInt();
            if (readInt < 0) {
                bArr = null;
            } else {
                byte[] bArr2 = new byte[readInt];
                parcel.readByteArray(bArr2);
                bArr = bArr2;
            }
        }
        iconCompat.c = bArr;
        iconCompat.d = kg1.f(iconCompat.d, 3);
        i = iconCompat.e;
        if (kg1.e(4)) {
            i = ((lg1) kg1).e.readInt();
        }
        iconCompat.e = i;
        i = iconCompat.f;
        if (kg1.e(5)) {
            i = ((lg1) kg1).e.readInt();
        }
        iconCompat.f = i;
        iconCompat.g = (ColorStateList) kg1.f(iconCompat.g, 6);
        String str = iconCompat.i;
        if (kg1.e(7)) {
            str = ((lg1) kg1).e.readString();
        }
        iconCompat.i = str;
        str = iconCompat.j;
        if (kg1.e(8)) {
            str = ((lg1) kg1).e.readString();
        }
        iconCompat.j = str;
        iconCompat.h = Mode.valueOf(iconCompat.i);
        Parcelable parcelable;
        switch (iconCompat.a) {
            case -1:
                parcelable = iconCompat.d;
                if (parcelable != null) {
                    iconCompat.b = parcelable;
                    return iconCompat;
                }
                od.m("Invalid icon");
                return null;
            case 1:
            case gu0.STRING_FIELD_NUMBER /*5*/:
                parcelable = iconCompat.d;
                if (parcelable != null) {
                    iconCompat.b = parcelable;
                    return iconCompat;
                }
                byte[] bArr3 = iconCompat.c;
                iconCompat.b = bArr3;
                iconCompat.a = 3;
                iconCompat.e = 0;
                iconCompat.f = bArr3.length;
                return iconCompat;
            case 2:
            case gu0.LONG_FIELD_NUMBER /*4*/:
            case gu0.STRING_SET_FIELD_NUMBER /*6*/:
                String str2 = new String(iconCompat.c, Class.forName("UTF-16"));
                iconCompat.b = str2;
                if (iconCompat.a == 2 && iconCompat.j == null) {
                    iconCompat.j = str2.split(":", -1)[0];
                    break;
                }
            case 3:
                iconCompat.b = iconCompat.c;
                return iconCompat;
            default:
                break;
        }
        return iconCompat;
    }

    public static void write(IconCompat iconCompat, kg1 kg1) {
        kg1.getClass();
        iconCompat.i = iconCompat.h.name();
        String str = "UTF-16";
        switch (iconCompat.a) {
            case -1:
                iconCompat.d = (Parcelable) iconCompat.b;
                break;
            case 1:
            case gu0.STRING_FIELD_NUMBER /*5*/:
                iconCompat.d = (Parcelable) iconCompat.b;
                break;
            case 2:
                iconCompat.c = ((String) iconCompat.b).getBytes(Class.forName(str));
                break;
            case 3:
                iconCompat.c = (byte[]) iconCompat.b;
                break;
            case gu0.LONG_FIELD_NUMBER /*4*/:
            case gu0.STRING_SET_FIELD_NUMBER /*6*/:
                iconCompat.c = iconCompat.b.toString().getBytes(Class.forName(str));
                break;
            default:
                break;
        }
        int i = iconCompat.a;
        if (-1 != i) {
            kg1.h(1);
            ((lg1) kg1).e.writeInt(i);
        }
        byte[] bArr = iconCompat.c;
        if (bArr != null) {
            kg1.h(2);
            Parcel parcel = ((lg1) kg1).e;
            parcel.writeInt(bArr.length);
            parcel.writeByteArray(bArr);
        }
        Parcelable parcelable = iconCompat.d;
        if (parcelable != null) {
            kg1.h(3);
            ((lg1) kg1).e.writeParcelable(parcelable, 0);
        }
        i = iconCompat.e;
        if (i != 0) {
            kg1.h(4);
            ((lg1) kg1).e.writeInt(i);
        }
        i = iconCompat.f;
        if (i != 0) {
            kg1.h(5);
            ((lg1) kg1).e.writeInt(i);
        }
        ColorStateList colorStateList = iconCompat.g;
        if (colorStateList != null) {
            kg1.h(6);
            ((lg1) kg1).e.writeParcelable(colorStateList, 0);
        }
        String str2 = iconCompat.i;
        if (str2 != null) {
            kg1.h(7);
            ((lg1) kg1).e.writeString(str2);
        }
        String str3 = iconCompat.j;
        if (str3 != null) {
            kg1.h(8);
            ((lg1) kg1).e.writeString(str3);
        }
    }
}