package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff.Mode;
import android.os.Build.VERSION;
import android.os.Parcelable;
import android.util.Log;
import androidx.versionedparcelable.CustomVersionedParcelable;
import defpackage.ac;
import defpackage.dl1;
import defpackage.gu0;
import java.lang.reflect.InvocationTargetException;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
public class IconCompat extends CustomVersionedParcelable {
    public static final Mode k = Mode.SRC_IN;
    public int a = -1;
    public Object b;
    public byte[] c = null;
    public Parcelable d = null;
    public int e = 0;
    public int f = 0;
    public ColorStateList g = null;
    public Mode h = k;
    public String i = null;
    public String j;

    /* JADX WARNING: Removed duplicated region for block: B:43:0x00fa  */
    /* JADX WARNING: Removed duplicated region for block: B:46:0x010a  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final String toString() {
        StringBuilder dl1;
        int intValue;
        if (this.a == -1) {
            return String.valueOf(this.b);
        }
        String str;
        dl1 = new dl1("Icon(typ=");
        switch (this.a) {
            case 1:
                str = "BITMAP";
                break;
            case 2:
                str = "RESOURCE";
                break;
            case 3:
                str = "DATA";
                break;
            case gu0.LONG_FIELD_NUMBER /*4*/:
                str = "URI";
                break;
            case gu0.STRING_FIELD_NUMBER /*5*/:
                str = "BITMAP_MASKABLE";
                break;
            case gu0.STRING_SET_FIELD_NUMBER /*6*/:
                str = "URI_MASKABLE";
                break;
            default:
                str = "UNKNOWN";
                break;
        }
        dl1.append(str);
        switch (this.a) {
            case 1:
            case gu0.STRING_FIELD_NUMBER /*5*/:
                dl1.append(" size=");
                dl1.append(((Bitmap) this.b).getWidth());
                dl1.append("x");
                dl1.append(((Bitmap) this.b).getHeight());
                break;
            case 2:
                dl1.append(" pkg=");
                dl1.append(this.j);
                dl1.append(" id=");
                int i = this.a;
                if (i == -1) {
                    Object obj = this.b;
                    str = "Unable to get icon resource";
                    String str2 = "IconCompat";
                    if (VERSION.SDK_INT < 28) {
                        try {
                            intValue = ((Integer) obj.getClass().getMethod("getResId", null).invoke(obj, null)).intValue();
                        } catch (IllegalAccessException e) {
                            Log.e(str2, str, e);
                            break;
                        } catch (InvocationTargetException e2) {
                            Log.e(str2, str, e2);
                            break;
                        } catch (NoSuchMethodException e3) {
                            Log.e(str2, str, e3);
                            break;
                        }
                    }
                    intValue = ac.c(obj);
                } else if (i == 2) {
                    intValue = this.e;
                } else {
                    StringBuilder dl12 = new dl1("called getResId() on ");
                    dl12.append(this);
                    throw new dl1(dl12.toString());
                }
                dl1.append(String.format("0x%08x", new Object[]{Integer.valueOf(intValue)}));
                break;
            case 3:
                dl1.append(" len=");
                dl1.append(this.e);
                if (this.f != 0) {
                    dl1.append(" off=");
                    dl1.append(this.f);
                    break;
                }
                break;
            case gu0.LONG_FIELD_NUMBER /*4*/:
            case gu0.STRING_SET_FIELD_NUMBER /*6*/:
                dl1.append(" uri=");
                dl1.append(this.b);
                break;
            default:
                break;
        }
        if (this.g != null) {
            dl1.append(" tint=");
            dl1.append(this.g);
        }
        if (this.h != k) {
            dl1.append(" mode=");
            dl1.append(this.h);
        }
        dl1.append(")");
        return dl1.toString();
        intValue = 0;
        dl1.append(String.format("0x%08x", new Object[]{Integer.valueOf(intValue)}));
        if (this.g != null) {
        }
        if (this.h != k) {
        }
        dl1.append(")");
        return dl1.toString();
    }
}