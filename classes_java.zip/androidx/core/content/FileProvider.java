package androidx.core.content;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.ProviderInfo;
import android.content.res.XmlResourceParser;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.net.Uri.Builder;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.text.TextUtils;
import android.webkit.MimeTypeMap;
import defpackage.dl1;
import defpackage.lv;
import defpackage.od;
import java.io.File;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import org.xmlpull.v1.XmlPullParserException;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
public class FileProvider extends ContentProvider {
    public static final String[] h = new String[]{"_display_name", "_size"};
    public static final File i = new dl1("/");
    public static final HashMap j = new HashMap();
    public final Object e = new Object();
    public String f;
    public lv g;

    public static lv e(Context context, String str) {
        lv dl1 = new dl1(str);
        ProviderInfo resolveContentProvider = context.getPackageManager().resolveContentProvider(str, 128);
        if (resolveContentProvider != null) {
            XmlResourceParser loadXmlMetaData = resolveContentProvider.loadXmlMetaData(context.getPackageManager(), "android.support.FILE_PROVIDER_PATHS");
            if (loadXmlMetaData != null) {
                while (true) {
                    int next = loadXmlMetaData.next();
                    if (next == 1) {
                        return dl1;
                    }
                    if (next == 2) {
                        Object obj;
                        String name = loadXmlMetaData.getName();
                        String attributeValue = loadXmlMetaData.getAttributeValue(null, "name");
                        String attributeValue2 = loadXmlMetaData.getAttributeValue(null, "path");
                        if ("root-path".equals(name)) {
                            obj = i;
                        } else if ("files-path".equals(name)) {
                            obj = context.getFilesDir();
                        } else if ("cache-path".equals(name)) {
                            obj = context.getCacheDir();
                        } else if ("external-path".equals(name)) {
                            obj = Environment.getExternalStorageDirectory();
                        } else {
                            File[] externalFilesDirs;
                            if ("external-files-path".equals(name)) {
                                externalFilesDirs = context.getExternalFilesDirs(null);
                                if (externalFilesDirs.length > 0) {
                                    obj = externalFilesDirs[0];
                                }
                            } else if ("external-cache-path".equals(name)) {
                                externalFilesDirs = context.getExternalCacheDirs();
                                if (externalFilesDirs.length > 0) {
                                    obj = externalFilesDirs[0];
                                }
                            } else if ("external-media-path".equals(name)) {
                                externalFilesDirs = context.getExternalMediaDirs();
                                if (externalFilesDirs.length > 0) {
                                    obj = externalFilesDirs[0];
                                }
                            }
                            obj = null;
                        }
                        if (obj != null) {
                            attributeValue2 = new String[]{attributeValue2}[0];
                            if (attributeValue2 != null) {
                                obj = new File(obj, attributeValue2);
                            }
                            if (TextUtils.isEmpty(attributeValue)) {
                                od.m("Name must not be empty");
                                return null;
                            }
                            try {
                                obj = obj.getCanonicalFile();
                                dl1.b.put(attributeValue, obj);
                            } catch (IOException e) {
                                StringBuilder dl12 = new dl1("Failed to resolve canonical path for ");
                                dl12.append(obj);
                                throw new IllegalArgumentException(dl12.toString(), e);
                            }
                        }
                        continue;
                    }
                }
            } else {
                od.m("Missing android.support.FILE_PROVIDER_PATHS meta-data");
                return null;
            }
        }
        od.e(str, "Couldn't find meta-data for provider with authority ");
        return null;
    }

    public static Uri d(Context context, String str, File file) {
        lv c = c(context, str);
        Object file2;
        try {
            String str2;
            file2 = file2.getCanonicalPath();
            Iterator it = c.b.entrySet().iterator();
            Entry entry = null;
            while (true) {
                str2 = "/";
                if (!it.hasNext()) {
                    break;
                }
                Entry entry2 = (Entry) it.next();
                String path = ((File) entry2.getValue()).getPath();
                if (a(file2).startsWith(a(path).concat(str2)) && (entry == null || path.length() > ((File) entry.getValue()).getPath().length())) {
                    entry = entry2;
                }
            }
            if (entry != null) {
                str = ((File) entry.getValue()).getPath();
                str = str.endsWith(str2) ? file2.substring(str.length()) : file2.substring(str.length() + 1);
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(Uri.encode((String) entry.getKey()));
                stringBuilder.append('/');
                stringBuilder.append(URLEncoder.encode(str, str2));
                return new Builder().scheme("content").authority(c.a).encodedPath(stringBuilder.toString()).build();
            }
            od.e(file2, "Failed to find configured root that contains ");
            return null;
        } catch (IOException unused) {
            od.e(file2, "Failed to resolve canonical path for ");
            return null;
        }
    }

    public final Cursor query(Uri uri, String[] strArr, String str, String[] strArr2, String str2) {
        File a = b().a(uri);
        String queryParameter = uri.getQueryParameter("displayName");
        if (strArr == null) {
            strArr = h;
        }
        String[] strArr3 = new String[strArr.length];
        Object[] objArr = new Object[strArr.length];
        int length = strArr.length;
        int i = 0;
        int i2 = i;
        while (i < length) {
            int i3;
            Object obj = strArr[i];
            String str3 = "_display_name";
            if (str3.equals(obj)) {
                strArr3[i2] = str3;
                i3 = i2 + 1;
                objArr[i2] = queryParameter == null ? a.getName() : queryParameter;
            } else {
                str3 = "_size";
                if (str3.equals(obj)) {
                    strArr3[i2] = str3;
                    i3 = i2 + 1;
                    objArr[i2] = Long.valueOf(a.length());
                } else {
                    i++;
                }
            }
            i2 = i3;
            i++;
        }
        String[] strArr4 = new String[i2];
        System.arraycopy(strArr3, 0, strArr4, 0, i2);
        Object[] objArr2 = new Object[i2];
        System.arraycopy(objArr, 0, objArr2, 0, i2);
        MatrixCursor matrixCursor = new MatrixCursor(strArr4, 1);
        matrixCursor.addRow(objArr2);
        return matrixCursor;
    }

    public final ParcelFileDescriptor openFile(Uri uri, String str) {
        int i;
        File a = b().a(uri);
        if ("r".equals(str)) {
            i = 268435456;
        } else {
            if (!"w".equals(str)) {
                if (!"wt".equals(str)) {
                    if ("wa".equals(str)) {
                        i = 704643072;
                    } else if ("rw".equals(str)) {
                        i = 939524096;
                    } else if ("rwt".equals(str)) {
                        i = 1006632960;
                    } else {
                        od.e(str, "Invalid mode: ");
                        return null;
                    }
                }
            }
            i = 738197504;
        }
        return ParcelFileDescriptor.open(a, i);
    }

    public final void attachInfo(Context context, ProviderInfo providerInfo) {
        super.attachInfo(context, providerInfo);
        if (providerInfo.exported) {
            throw new dl1("Provider must not be exported");
        } else if (providerInfo.grantUriPermissions) {
            String str = providerInfo.authority;
            if (str == null || str.trim().isEmpty()) {
                throw new dl1("Provider must have a non-empty authority");
            }
            str = providerInfo.authority.split(";")[0];
            synchronized (this.e) {
                this.f = str;
            }
            HashMap hashMap = j;
            synchronized (hashMap) {
                hashMap.remove(str);
            }
        } else {
            throw new dl1("Provider must grant uri permissions");
        }
    }

    public final String getType(Uri uri) {
        File a = b().a(uri);
        int lastIndexOf = a.getName().lastIndexOf(46);
        if (lastIndexOf >= 0) {
            String mimeTypeFromExtension = MimeTypeMap.getSingleton().getMimeTypeFromExtension(a.getName().substring(lastIndexOf + 1));
            if (mimeTypeFromExtension != null) {
                return mimeTypeFromExtension;
            }
        }
        return "application/octet-stream";
    }

    public static lv c(Context context, String str) {
        lv lvVar;
        HashMap hashMap = j;
        synchronized (hashMap) {
            lvVar = (lv) hashMap.get(str);
            if (lvVar == null) {
                try {
                    lvVar = e(context, str);
                    hashMap.put(str, lvVar);
                } catch (IOException e) {
                    throw new IllegalArgumentException("Failed to parse android.support.FILE_PROVIDER_PATHS meta-data", e);
                } catch (XmlPullParserException e2) {
                    throw new IllegalArgumentException("Failed to parse android.support.FILE_PROVIDER_PATHS meta-data", e2);
                }
            }
        }
        return lvVar;
    }

    public final lv b() {
        lv lvVar;
        synchronized (this.e) {
            try {
                String str = "mAuthority is null. Did you override attachInfo and did not call super.attachInfo()?";
                if (this.f != null) {
                    if (this.g == null) {
                        this.g = c(getContext(), this.f);
                    }
                    lvVar = this.g;
                } else {
                    throw new dl1(str);
                }
            } finally {
            }
        }
        return lvVar;
    }

    public static String a(String str) {
        return (str.length() <= 0 || str.charAt(str.length() - 1) != '/') ? str : str.substring(0, str.length() - 1);
    }

    public final int delete(Uri uri, String str, String[] strArr) {
        return b().a(uri).delete();
    }

    public final Uri insert(Uri uri, ContentValues contentValues) {
        throw new dl1("No external inserts");
    }

    public final int update(Uri uri, ContentValues contentValues, String str, String[] strArr) {
        throw new dl1("No external updates");
    }

    public final String getTypeAnonymous(Uri uri) {
        return "application/octet-stream";
    }

    public final boolean onCreate() {
        return true;
    }
}