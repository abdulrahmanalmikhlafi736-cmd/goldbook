package androidx.startup;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager.NameNotFoundException;
import android.database.Cursor;
import android.net.Uri;
import android.os.Trace;
import defpackage.dl1;
import defpackage.j9;
import defpackage.k9;
import defpackage.sb0;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
public class InitializationProvider extends ContentProvider {
    public final boolean onCreate() {
        Context context = getContext();
        if (context != null) {
            if (context.getApplicationContext() != null) {
                k9 s = k9.s(context);
                Context context2 = (Context) s.h;
                try {
                    sb0.c("Startup");
                    s.n(context2.getPackageManager().getProviderInfo(new j9(context2.getPackageName(), InitializationProvider.class.getName()), 128).metaData);
                    Trace.endSection();
                } catch (NameNotFoundException e) {
                    throw new RuntimeException(e);
                } catch (Throwable th) {
                    Trace.endSection();
                }
            }
            return true;
        }
        throw new dl1("Context cannot be null");
    }

    public final int delete(Uri uri, String str, String[] strArr) {
        throw new dl1("Not allowed.");
    }

    public final String getType(Uri uri) {
        throw new dl1("Not allowed.");
    }

    public final Uri insert(Uri uri, ContentValues contentValues) {
        throw new dl1("Not allowed.");
    }

    public final Cursor query(Uri uri, String[] strArr, String str, String[] strArr2, String str2) {
        throw new dl1("Not allowed.");
    }

    public final int update(Uri uri, ContentValues contentValues, String str, String[] strArr) {
        throw new dl1("Not allowed.");
    }
}