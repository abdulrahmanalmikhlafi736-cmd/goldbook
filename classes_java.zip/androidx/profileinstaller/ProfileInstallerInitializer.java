package androidx.profileinstaller;

import android.content.Context;
import android.os.Build.VERSION;
import android.view.Choreographer;
import defpackage.cv0;
import defpackage.h90;
import defpackage.l50;
import java.util.Collections;
import java.util.List;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
public class ProfileInstallerInitializer implements l50 {
    public final Object b(Context context) {
        if (VERSION.SDK_INT < 24) {
            return new h90(2);
        }
        Choreographer.getInstance().postFrameCallback(new cv0(this, context.getApplicationContext()));
        return new h90(2);
    }

    public final List a() {
        return Collections.EMPTY_LIST;
    }
}