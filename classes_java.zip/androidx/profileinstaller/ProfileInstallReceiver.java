package androidx.profileinstaller;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Process;
import android.util.Log;
import defpackage.l50;
import defpackage.pg0;
import defpackage.wl1;
import java.io.File;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
public class ProfileInstallReceiver extends BroadcastReceiver {
    public final void onReceive(Context context, Intent intent) {
        if (intent != null) {
            int action = intent.getAction();
            Bundle extras;
            String string;
            if ("androidx.profileinstaller.action.INSTALL_PROFILE".equals(action)) {
                wl1.R(context, new Object(), new pg0(28, (Object) this), true);
            } else if ("androidx.profileinstaller.action.SKIP_FILE".equals(action)) {
                extras = intent.getExtras();
                if (extras != null) {
                    string = extras.getString("EXTRA_SKIP_FILE_OPERATION");
                    if ("WRITE_SKIP_FILE".equals(string)) {
                        pg0 pg0 = new pg0(28, (Object) this);
                        try {
                            wl1.D(context.getPackageManager().getPackageInfo(context.getApplicationContext().getPackageName(), 0), context.getFilesDir());
                            pg0.g(10, null);
                        } catch (NameNotFoundException e) {
                            pg0.g(7, e);
                        }
                    } else if ("DELETE_SKIP_FILE".equals(string)) {
                        new File(context.getFilesDir(), "profileinstaller_profileWrittenFor_lastUpdateTime.dat").delete();
                        Log.d("ProfileInstaller", "RESULT_DELETE_SKIP_FILE_SUCCESS");
                        setResultCode(11);
                    }
                }
            } else if ("androidx.profileinstaller.action.SAVE_PROFILE".equals(action)) {
                pg0 pg02 = new pg0(28, (Object) this);
                if (VERSION.SDK_INT >= 24) {
                    Process.sendSignal(Process.myPid(), 10);
                    pg02.g(12, null);
                    return;
                }
                pg02.g(13, null);
            } else if ("androidx.profileinstaller.action.BENCHMARK_OPERATION".equals(action)) {
                extras = intent.getExtras();
                if (extras != null) {
                    string = extras.getString("EXTRA_BENCHMARK_OPERATION");
                    pg0 pg03 = new pg0(28, (Object) this);
                    if ("DROP_SHADER_CACHE".equals(string)) {
                        int i = VERSION.SDK_INT;
                        File cacheDir = i >= 34 ? l50.b(context).getCacheDir() : i >= 24 ? l50.b(context).getCodeCacheDir() : i == 23 ? context.getCodeCacheDir() : context.getCacheDir();
                        if (wl1.s(cacheDir)) {
                            pg03.g(14, null);
                            return;
                        } else {
                            pg03.g(15, null);
                            return;
                        }
                    }
                    pg03.g(16, null);
                }
            }
        }
    }
}