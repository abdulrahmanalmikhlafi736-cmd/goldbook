package androidx.lifecycle;

import android.app.Application;
import android.content.Context;
import android.os.Handler;
import defpackage.id0;
import defpackage.k9;
import defpackage.l50;
import defpackage.ld0;
import defpackage.md0;
import defpackage.od;
import defpackage.ut;
import defpackage.vu0;
import defpackage.wu0;
import java.util.HashSet;
import java.util.List;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
public final class ProcessLifecycleInitializer implements l50 {
    public final Object b(Context context) {
        context.getClass();
        k9 s = k9.s(context);
        s.getClass();
        if (((HashSet) s.g).contains(ProcessLifecycleInitializer.class)) {
            if (!md0.a.getAndSet(true)) {
                Context applicationContext = context.getApplicationContext();
                applicationContext.getClass();
                ((Application) applicationContext).registerActivityLifecycleCallbacks(new ld0());
            }
            wu0 wu0 = wu0.m;
            wu0.getClass();
            wu0.i = new Handler();
            wu0.j.d(id0.ON_CREATE);
            context = context.getApplicationContext();
            context.getClass();
            ((Application) context).registerActivityLifecycleCallbacks(new vu0(wu0));
            return wu0;
        }
        od.p("ProcessLifecycleInitializer cannot be initialized lazily.\n               Please ensure that you have:\n               <meta-data\n                   android:name='androidx.lifecycle.ProcessLifecycleInitializer'\n                   android:value='androidx.startup' />\n               under InitializationProvider in your AndroidManifest.xml");
        return null;
    }

    public final List a() {
        return ut.e;
    }
}