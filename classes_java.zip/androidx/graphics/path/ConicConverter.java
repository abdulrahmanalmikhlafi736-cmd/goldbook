package androidx.graphics.path;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
public final class ConicConverter {
    private final native int internalConicToQuadratics(float[] fArr, int i, float[] fArr2, float f, float f2);
}