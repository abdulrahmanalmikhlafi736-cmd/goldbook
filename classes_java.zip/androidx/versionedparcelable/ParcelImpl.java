package androidx.versionedparcelable;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import defpackage.h90;
import defpackage.mg1;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
public class ParcelImpl implements Parcelable {
    public static final Creator<ParcelImpl> CREATOR = new h90(3);
    public final mg1 e;

    public ParcelImpl(Parcel parcel) {
        this.e = new ParcelImpl(parcel).g();
    }

    public final void writeToParcel(Parcel parcel, int i) {
        new ParcelImpl(parcel).i(this.e);
    }

    public final int describeContents() {
        return 0;
    }
}