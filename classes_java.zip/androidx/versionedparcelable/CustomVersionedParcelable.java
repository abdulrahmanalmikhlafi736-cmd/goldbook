package androidx.versionedparcelable;

import defpackage.mg1;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
public abstract class CustomVersionedParcelable implements mg1 {
}