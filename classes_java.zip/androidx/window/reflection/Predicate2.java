package androidx.window.reflection;

import androidx.window.extensions.core.util.function.Predicate;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
public interface Predicate2<T> extends Predicate<T> {
    boolean test(T t);
}