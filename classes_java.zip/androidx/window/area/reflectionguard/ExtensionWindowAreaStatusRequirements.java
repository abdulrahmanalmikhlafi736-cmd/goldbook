package androidx.window.area.reflectionguard;

import android.util.DisplayMetrics;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
public interface ExtensionWindowAreaStatusRequirements {
    DisplayMetrics getWindowAreaDisplayMetrics();

    int getWindowAreaStatus();
}