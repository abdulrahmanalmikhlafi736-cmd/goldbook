package androidx.emoji2.text;

import android.content.Context;
import androidx.lifecycle.ProcessLifecycleInitializer;
import defpackage.dt;
import defpackage.et;
import defpackage.jz;
import defpackage.k9;
import defpackage.l50;
import defpackage.pg0;
import defpackage.sd0;
import defpackage.ud0;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
public class EmojiCompatInitializer implements l50 {
    public final void c(Context context) {
        Object obj;
        k9 s = k9.s(context);
        Class cls = ProcessLifecycleInitializer.class;
        s.getClass();
        synchronized (k9.j) {
            try {
                obj = ((HashMap) s.f).get(cls);
                if (obj == null) {
                    obj = s.o(cls, new HashSet());
                }
            } finally {
            }
        }
        ud0 g = ((sd0) obj).g();
        g.a(new et(this, g));
    }

    public final Object b(Context context) {
        jz jzVar = new jz(new pg0(context));
        jzVar.b = 1;
        if (dt.k == null) {
            synchronized (dt.j) {
                try {
                    if (dt.k == null) {
                        dt.k = new dt(jzVar);
                    }
                } finally {
                }
            }
        }
        c(context);
        return Boolean.TRUE;
    }

    public final List a() {
        return Collections.singletonList(ProcessLifecycleInitializer.class);
    }
}