package defpackage;

import android.app.Activity;
import android.webkit.ValueCallback;
import mod.Mod;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: c20 */
public final /* synthetic */ class c20 implements ValueCallback {
    public final /* synthetic */ Activity a;
    public final /* synthetic */ jq0 b;
    public final /* synthetic */ mk0 c;
    public final /* synthetic */ ui1 d;
    public final /* synthetic */ mk0 e;

    public final void onReceiveValue(Object obj) {
        String str = (String) obj;
        this.b.h(0);
        if (str == null) {
            str = "\"false\"";
        }
        if (str.length() >= 2) {
            String str2 = "\"";
            if (str.startsWith(str2) && q81.A(str, str2)) {
                str = str.substring(1, str.length() - 1);
            }
        }
        int hashCode = str.hashCode();
        Activity activity = this.a;
        if (hashCode != 3127582) {
            if (hashCode != 3569038) {
                if (hashCode == 417800693) {
                    if (str.equals("scrolling")) {
                        this.c.setValue(Boolean.TRUE);
                        return;
                    }
                }
            } else if (str.equals("true")) {
                return;
            }
        } else if (str.equals("exit")) {
            Mod.warmExit(activity);
            return;
        }
        j70.e(this.d, activity, this.e);
    }

    public /* synthetic */ c20(mk0 mk0, mk0 mk02, jq0 jq0, ui1 ui1, Activity activity) {
        this.a = activity;
        this.b = jq0;
        this.c = mk0;
        this.d = ui1;
        this.e = mk02;
    }
}