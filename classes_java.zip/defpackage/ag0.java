package defpackage;

import java.util.Map;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ag0 */
public final class ag0 implements nh0 {
    public final /* synthetic */ int a;
    public final /* synthetic */ int b;
    public final /* synthetic */ Map c;
    public final /* synthetic */ i00 d;
    public final /* synthetic */ i00 e;
    public final /* synthetic */ bg0 f;

    public ag0(int i, int i2, Map map, i00 i00, i00 i002, bg0 bg0) {
        this.a = i;
        this.b = i2;
        this.c = map;
        this.d = i00;
        this.e = i002;
        this.f = bg0;
    }

    public final void a() {
        this.e.i(this.f.p);
    }

    public final int b() {
        return this.b;
    }

    public final Map c() {
        return this.c;
    }

    public final i00 d() {
        return this.d;
    }

    public final int e() {
        return this.a;
    }
}