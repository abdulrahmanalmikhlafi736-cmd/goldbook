package defpackage;

import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.CancellationSignal;
import android.view.ScrollCaptureCallback;
import android.view.ScrollCaptureSession;
import android.view.Surface;
import android.view.autofill.AutofillValue;
import java.util.function.Consumer;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cj */
public final class cj implements ScrollCaptureCallback {
    public final i21 a;
    public final r60 b;
    public final bd0 c;
    public final n4 d;
    public final ll e;
    public final tw0 f;

    /* JADX WARNING: Removed duplicated region for block: B:39:0x00da  */
    /* JADX WARNING: Removed duplicated region for block: B:37:0x00d7  */
    /* JADX WARNING: Removed duplicated region for block: B:14:0x0052  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0022  */
    /* JADX WARNING: Removed duplicated region for block: B:34:0x00ae  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final Object a(cj cjVar, ScrollCaptureSession scrollCaptureSession, r60 r60, nl nlVar) {
        bj bjVar;
        int i;
        Object obj;
        Object obj2;
        int i2;
        int P;
        i4 i4Var;
        sl slVar;
        if (nlVar instanceof bj) {
            bjVar = (bj) nlVar;
            i = bjVar.n;
            if ((i & Integer.MIN_VALUE) != 0) {
                int i3;
                int i4;
                r60 r602;
                ScrollCaptureSession h;
                tw0 tw0;
                bjVar.n = i - Integer.MIN_VALUE;
                obj = bjVar.l;
                i = bjVar.n;
                obj2 = cm.e;
                if (i != 0) {
                    nb0.t(obj);
                    i2 = r60.b;
                    i = r60.d;
                    tw0 tw02 = cjVar.f;
                    bjVar.h = scrollCaptureSession;
                    bjVar.i = r60;
                    bjVar.j = i2;
                    bjVar.k = i;
                    bjVar.n = 1;
                    int i5 = tw02.a;
                    if (i2 <= i) {
                        int i6 = i - i2;
                        if (i6 <= i5) {
                            float f = (float) i2;
                            float f2 = tw02.c;
                            int i7 = (f > f2 ? 1 : (f == f2 ? 0 : -1));
                            we1 we1 = we1.a;
                            if (i7 < 0 || ((float) i) > ((float) i5) + f2) {
                                cm a = tw02.a(((float) (((i6 / 2) + i2) - (i5 / 2))) - f2, bjVar);
                                if (a != obj2) {
                                    a = we1;
                                }
                                if (a == obj2) {
                                    we1 = a;
                                }
                            }
                            if (we1 == obj2) {
                                return obj2;
                            }
                        }
                        throw new dl1(fu0.D(i6, i5, "Expected range (", ") to be ≤ viewportSize=").toString());
                    }
                    throw new dl1(fu0.D(i2, i, "Expected min=", " ≤ max=").toString());
                } else if (i == 1) {
                    i3 = bjVar.k;
                    i4 = bjVar.j;
                    r602 = bjVar.i;
                    AutofillValue h2 = ((AutofillValue) bjVar.h);
                    nb0.t(obj);
                    i2 = i4;
                    r60 = r602;
                    i = i3;
                    scrollCaptureSession = h2;
                } else if (i == 2) {
                    i3 = bjVar.k;
                    i4 = bjVar.j;
                    r602 = bjVar.i;
                    h = ((AutofillValue) bjVar.h);
                    nb0.t(obj);
                    tw0 = cjVar.f;
                    i4 = sb0.h(i4 - gh0.P(tw0.c), 0, tw0.a);
                    tw0 = cjVar.f;
                    i3 = sb0.h(i3 - gh0.P(tw0.c), 0, tw0.a);
                    i2 = r602.a;
                    i = r602.c;
                    if (i4 != i3) {
                        return r60.e;
                    }
                    Canvas lockHardwareCanvas = h.getSurface().lockHardwareCanvas();
                    try {
                        lockHardwareCanvas.save();
                        lockHardwareCanvas.translate(-((float) i2), -((float) i4));
                        r60 r603 = cjVar.b;
                        lockHardwareCanvas.translate(-((float) r603.a), -((float) r603.b));
                        cjVar.d.getRootView().draw(lockHardwareCanvas);
                    } finally {
                        Surface surface = h;
                        i3 = h.getSurface();
                        i3.unlockCanvasAndPost(lockHardwareCanvas);
                        P = gh0.P(cjVar.f.c);
                        return new r60(i2, i4 + P, i, i3 + P);
                    }
                    P = gh0.P(cjVar.f.c);
                    return new r60(i2, i4 + P, i, i3 + P);
                } else {
                    od.p("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                i4Var = i4.s;
                bjVar.h = scrollCaptureSession;
                bjVar.i = r60;
                bjVar.j = i2;
                bjVar.k = i;
                bjVar.n = 2;
                slVar = bjVar.f;
                slVar.getClass();
                if (sb0.o(slVar).c(i4Var, bjVar) != obj2) {
                    h = scrollCaptureSession;
                    i3 = i;
                    r602 = r60;
                    i4 = i2;
                    tw0 = cjVar.f;
                    i4 = sb0.h(i4 - gh0.P(tw0.c), 0, tw0.a);
                    tw0 = cjVar.f;
                    i3 = sb0.h(i3 - gh0.P(tw0.c), 0, tw0.a);
                    i2 = r602.a;
                    i = r602.c;
                    if (i4 != i3) {
                    }
                }
                return obj2;
            }
        }
        bjVar = new bj(cjVar, nlVar);
        obj = bjVar.l;
        i = bjVar.n;
        obj2 = cm.e;
        if (i != 0) {
        }
        i4Var = i4.s;
        bjVar.h = scrollCaptureSession;
        bjVar.i = r60;
        bjVar.j = i2;
        bjVar.k = i;
        bjVar.n = 2;
        slVar = bjVar.f;
        slVar.getClass();
        if (sb0.o(slVar).c(i4Var, bjVar) != obj2) {
        }
        return obj2;
    }

    public cj(i21 i21, r60 r60, ll llVar, bd0 bd0, n4 n4Var) {
        this.a = i21;
        this.b = r60;
        this.c = bd0;
        this.d = n4Var;
        this.e = new ax0(llVar.e.i(eq.f));
        this.f = new tw0(r60.d - r60.b, new gc1(this, null));
    }

    public final void onScrollCaptureImageRequest(ScrollCaptureSession scrollCaptureSession, CancellationSignal cancellationSignal, Rect rect, Consumer consumer) {
        s71 B = wl1.B(this.e, null, new aj(this, scrollCaptureSession, rect, consumer, null, 0), 3);
        B.r(new j3(8, cancellationSignal));
        cancellationSignal.setOnCancelListener(new dj(B));
    }

    public final void onScrollCaptureStart(ScrollCaptureSession scrollCaptureSession, CancellationSignal cancellationSignal, Runnable runnable) {
        this.f.c = 0.0f;
        this.c.a.setValue(Boolean.TRUE);
        runnable.run();
    }

    public final void onScrollCaptureEnd(Runnable runnable) {
        wl1.B(this.e, mm0.f, new d(this, runnable, null, 5), 2);
    }

    public final void onScrollCaptureSearch(CancellationSignal cancellationSignal, Consumer consumer) {
        consumer.accept(dd0.x(this.b));
    }
}