package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: au */
final class au extends qi0 {
    public final ed1 a;
    public final zc1 b;
    public final zc1 c;
    public final ju d;
    public final wu e;
    public final xz f;
    public final bu g;

    public final boolean equals(Object obj) {
        if (obj instanceof au) {
            au auVar = (au) obj;
            if (auVar.a == this.a) {
                if (k70.p(auVar.b, this.b) && k70.p(auVar.c, this.c) && auVar.d.equals(this.d) && k70.p(auVar.e, this.e) && auVar.f == this.f && k70.p(auVar.g, this.g)) {
                    return true;
                }
            }
        }
        return false;
    }

    public final int hashCode() {
        int hashCode = this.a.hashCode() * 31;
        int i = 0;
        zc1 zc1 = this.b;
        hashCode = (hashCode + (zc1 != null ? zc1.hashCode() : 0)) * 31;
        zc1 = this.c;
        if (zc1 != null) {
            i = zc1.hashCode();
        }
        return this.g.hashCode() + ((this.f.hashCode() + ((this.e.a.hashCode() + ((this.d.a.hashCode() + ((hashCode + i) * 961)) * 31)) * 31)) * 31);
    }

    public final void f(li0 li0) {
        iu iuVar = (iu) li0;
        iuVar.s = this.a;
        iuVar.t = this.b;
        iuVar.u = this.c;
        iuVar.v = this.d;
        iuVar.w = this.e;
        iuVar.x = this.f;
        iuVar.y = this.g;
    }

    public final li0 e() {
        return new au(this.a, this.b, this.c, this.d, this.e, this.f, this.g);
    }

    public au(ed1 ed1, zc1 zc1, zc1 zc12, ju juVar, wu wuVar, xz xzVar, bu buVar) {
        this.a = ed1;
        this.b = zc1;
        this.c = zc12;
        this.d = juVar;
        this.e = wuVar;
        this.f = xzVar;
        this.g = buVar;
    }
}