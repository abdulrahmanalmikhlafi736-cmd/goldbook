package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: t90 */
public interface t90 extends cp {
    int G(bg0 bg0, hh0 hh0, int i);

    nh0 U(oh0 oh0, hh0 hh0, long j);

    int d(bg0 bg0, hh0 hh0, int i);

    int h(bg0 bg0, hh0 hh0, int i);

    int t(bg0 bg0, hh0 hh0, int i);
}