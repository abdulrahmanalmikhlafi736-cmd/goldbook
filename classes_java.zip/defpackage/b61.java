package defpackage;

import java.util.Arrays;
import java.util.Collection;
import java.util.ListIterator;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: b61 */
public final class b61 extends c0 {
    public static final b61 f = new b61(new Object[0]);
    public final Object[] e;

    public final c0 b(int i, Object obj) {
        Object[] objArr = this.e;
        kb0.g(i, objArr.length);
        if (i == objArr.length) {
            return c(obj);
        }
        Object[] objArr2;
        if (objArr.length < 32) {
            objArr2 = new Object[(objArr.length + 1)];
            ba.a0(objArr, objArr2, 0, i, 6);
            ba.Y(objArr, objArr2, i + 1, i, objArr.length);
            objArr2[i] = obj;
            return new b61(objArr2);
        }
        objArr2 = Arrays.copyOf(objArr, objArr.length);
        ba.Y(objArr, objArr2, i + 1, i, objArr.length - 1);
        objArr2[i] = obj;
        Object[] objArr3 = new Object[32];
        objArr3[0] = objArr[31];
        return new ds0(objArr2, objArr3, objArr.length + 1, 0);
    }

    public final c0 g(b0 b0Var) {
        Object[] objArr = this.e;
        int length = objArr.length;
        int length2 = objArr.length;
        Object[] objArr2 = objArr;
        int i = 0;
        int i2 = i;
        while (i < length2) {
            Object obj = objArr[i];
            if (((Boolean) b0Var.i(obj)).booleanValue()) {
                if (i2 == 0) {
                    objArr2 = Arrays.copyOf(objArr, objArr.length);
                    i2 = 1;
                    length = i;
                }
            } else if (i2 != 0) {
                int i3 = length + 1;
                objArr2[length] = obj;
                length = i3;
            }
            i++;
        }
        if (length == objArr.length) {
            return this;
        }
        return length == 0 ? f : new b61(ba.b0(objArr2, 0, length));
    }

    public final c0 e(Collection collection) {
        Object[] objArr = this.e;
        if (collection.size() + objArr.length <= 32) {
            Object[] copyOf = Arrays.copyOf(objArr, collection.size() + objArr.length);
            int length = objArr.length;
            for (Object obj : collection) {
                int i = length + 1;
                copyOf[length] = obj;
                length = i;
            }
            return new b61(copyOf);
        }
        es0 f = f();
        f.addAll(collection);
        return f.c();
    }

    public final int lastIndexOf(Object obj) {
        Object[] objArr = this.e;
        int i;
        if (obj == null) {
            int length = objArr.length - 1;
            if (length >= 0) {
                while (true) {
                    i = length - 1;
                    if (objArr[length] == null) {
                        return length;
                    }
                    if (i < 0) {
                        break;
                    }
                    length = i;
                }
            }
        } else {
            i = objArr.length - 1;
            if (i >= 0) {
                while (true) {
                    int i2 = i - 1;
                    if (obj.equals(objArr[i])) {
                        return i;
                    }
                    if (i2 < 0) {
                        break;
                    }
                    i = i2;
                }
            }
        }
        return -1;
    }

    public final d81 c(Object obj) {
        Object[] objArr = this.e;
        Object[] copyOf;
        if (objArr.length < 32) {
            copyOf = Arrays.copyOf(objArr, objArr.length + 1);
            copyOf[objArr.length] = obj;
            return new b61(copyOf);
        }
        copyOf = new Object[32];
        copyOf[0] = obj;
        return new ds0(objArr, copyOf, objArr.length + 1, 0);
    }

    public final c0 h(int i) {
        Object[] objArr = this.e;
        vd1.f(i, objArr.length);
        if (objArr.length == 1) {
            return f;
        }
        Object[] copyOf = Arrays.copyOf(objArr, objArr.length - 1);
        ba.Y(objArr, copyOf, i, i + 1, objArr.length);
        return new b61(copyOf);
    }

    public final c0 i(int i, Object obj) {
        Object[] objArr = this.e;
        vd1.f(i, objArr.length);
        objArr = Arrays.copyOf(objArr, objArr.length);
        objArr[i] = obj;
        return new b61(objArr);
    }

    public final ListIterator listIterator(int i) {
        Object[] objArr = this.e;
        kb0.g(i, objArr.length);
        return new fd(objArr, i, objArr.length);
    }

    public final es0 f() {
        return new es0(this, null, this.e, 0);
    }

    public final Object get(int i) {
        Object[] objArr = this.e;
        vd1.f(i, objArr.length);
        return objArr[i];
    }

    public final int indexOf(Object obj) {
        return ba.f0(this.e, obj);
    }

    public b61(Object[] objArr) {
        this.e = objArr;
    }

    public final int a() {
        return this.e.length;
    }
}