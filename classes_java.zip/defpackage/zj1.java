package defpackage;

import android.view.View;
import android.view.WindowInsets;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: zj1 */
public class zj1 extends yj1 {
    public static final hk1 w = hk1.c(null, WindowInsets.CONSUMED);

    public c60 i(int i) {
        return c60.c(this.c.getInsets(fk1.a(i)));
    }

    public c60 j(int i) {
        return c60.c(this.c.getInsetsIgnoringVisibility(fk1.a(i)));
    }

    public boolean u(int i) {
        return this.c.isVisible(fk1.a(i));
    }

    public zj1(hk1 hk1, WindowInsets windowInsets) {
        super(hk1, windowInsets);
    }

    public zj1(hk1 hk1, zj1 zj1) {
        super(hk1, (yj1) zj1);
    }

    public final void d(View view) {
    }
}