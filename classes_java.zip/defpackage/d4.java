package defpackage;

import android.view.View;
import android.view.accessibility.AccessibilityNodeInfo;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: d4 */
public final class d4 extends r0 {
    public final /* synthetic */ n4 h;
    public final /* synthetic */ ba0 i;
    public final /* synthetic */ n4 j;

    public final void b(View view, l1 l1Var) {
        Integer num;
        AccessibilityNodeInfo accessibilityNodeInfo = l1Var.a;
        this.e.onInitializeAccessibilityNodeInfo(view, accessibilityNodeInfo);
        n4 n4Var = this.h;
        u4 u4Var = n4Var.E;
        if (u4Var.o()) {
            accessibilityNodeInfo.setVisibleToUser(false);
        }
        ba0 ba0 = this.i;
        ba0 v = ba0.v();
        while (true) {
            num = null;
            if (v == null) {
                v = null;
                break;
            } else if (v.J.d(8)) {
                break;
            } else {
                v = v.v();
            }
        }
        if (v != null) {
            num = Integer.valueOf(v.f);
        }
        if (num == null || num.intValue() == n4Var.getSemanticsOwner().a().f) {
            num = Integer.valueOf(-1);
        }
        int intValue = num.intValue();
        l1Var.b = intValue;
        n4 n4Var2 = this.j;
        accessibilityNodeInfo.setParent(n4Var2, intValue);
        int i = ba0.f;
        int d = u4Var.G.d(i);
        if (d != -1) {
            q7 r = nb0.r(n4Var.getAndroidViewsHandler$ui(), d);
            if (r != null) {
                accessibilityNodeInfo.setTraversalBefore(r);
            } else {
                accessibilityNodeInfo.setTraversalBefore(n4Var2, d);
            }
            n4.i(n4Var, i, accessibilityNodeInfo, u4Var.I);
        }
        d = u4Var.H.d(i);
        if (d != -1) {
            q7 r2 = nb0.r(n4Var.getAndroidViewsHandler$ui(), d);
            if (r2 != null) {
                accessibilityNodeInfo.setTraversalAfter(r2);
            } else {
                accessibilityNodeInfo.setTraversalAfter(n4Var2, d);
            }
            n4.i(n4Var, i, accessibilityNodeInfo, u4Var.J);
        }
    }

    public d4(n4 n4Var, ba0 ba0, n4 n4Var2) {
        this.h = n4Var;
        this.i = ba0;
        this.j = n4Var2;
    }
}