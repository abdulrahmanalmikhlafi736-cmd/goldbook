package defpackage;

import java.util.ArrayList;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: db0 */
public final class db0 extends li0 implements ds {
    public fb0 s;

    public final void C(da0 da0) {
        ArrayList arrayList = this.s.h;
        if (arrayList.size() <= 0) {
            da0.c();
        } else {
            fu0.L(arrayList.get(0));
            throw null;
        }
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof db0)) {
            return false;
        }
        return k70.p(this.s, ((db0) obj).s);
    }

    public final String toString() {
        StringBuilder dl1 = new dl1("DisplayingDisappearingItemsNode(animator=");
        dl1.append(this.s);
        dl1.append(')');
        return dl1.toString();
    }

    public final void j0() {
        fb0 fb0 = this.s;
        fb0.c();
        fb0.b = null;
    }

    public final int hashCode() {
        return this.s.hashCode();
    }

    public final void h0() {
        this.s.getClass();
    }

    public final /* synthetic */ void Z() {
    }
}