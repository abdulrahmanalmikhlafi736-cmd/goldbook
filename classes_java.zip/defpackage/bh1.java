package defpackage;

import android.view.ViewParent;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bh1 */
public final /* synthetic */ class bh1 extends w00 implements i00 {
    public static final bh1 l = new w00(1, ViewParent.class, "getParent", "getParent()Landroid/view/ViewParent;", 0);

    public final Object i(Object obj) {
        return ((ViewParent) obj).getParent();
    }
}