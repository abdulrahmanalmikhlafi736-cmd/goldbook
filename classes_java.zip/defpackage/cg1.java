package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cg1 */
public interface cg1 {
    boolean a();

    u8 f(long j, u8 u8Var, u8 u8Var2, u8 u8Var3);

    u8 i(long j, u8 u8Var, u8 u8Var2, u8 u8Var3);

    u8 j(u8 u8Var, u8 u8Var2, u8 u8Var3);

    long k(u8 u8Var, u8 u8Var2, u8 u8Var3);
}