package defpackage;

import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: of0 */
public class of0 {
    public static final /* synthetic */ AtomicReferenceFieldUpdater e;
    public static final /* synthetic */ AtomicReferenceFieldUpdater f;
    public static final /* synthetic */ AtomicReferenceFieldUpdater g;
    private volatile /* synthetic */ Object _next$volatile = this;
    private volatile /* synthetic */ Object _prev$volatile = this;
    private volatile /* synthetic */ Object _removedRef$volatile;

    /* JADX WARNING: Missing block: B:18:0x0031, code:
            r6 = ((defpackage.bx0) r6).a;
     */
    /* JADX WARNING: Missing block: B:20:0x0039, code:
            if (r5.compareAndSet(r4, r3, r6) == false) goto L_0x003d;
     */
    /* JADX WARNING: Missing block: B:23:0x0041, code:
            if (r5.get(r4) == r3) goto L_0x0035;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final of0 f() {
        of0 of0;
        loop0:
        while (true) {
            AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = f;
            of0 of02 = (of0) atomicReferenceFieldUpdater.get(this);
            of0 = of02;
            while (true) {
                Object obj = null;
                while (true) {
                    AtomicReferenceFieldUpdater atomicReferenceFieldUpdater2 = e;
                    of0 of03 = atomicReferenceFieldUpdater2.get(of0);
                    if (of03 == this) {
                        if (of02 != of0) {
                            while (!atomicReferenceFieldUpdater.compareAndSet(this, of02, of0)) {
                                if (atomicReferenceFieldUpdater.get(this) != of02) {
                                }
                            }
                            break loop0;
                        }
                        break;
                    } else if (i()) {
                        return null;
                    } else {
                        if (!(of03 instanceof bx0)) {
                            of03.getClass();
                            obj = of0;
                            of0 = of03;
                        } else if (obj != null) {
                            break;
                        } else {
                            of0 = (of0) atomicReferenceFieldUpdater.get(of0);
                        }
                    }
                }
                of0 = obj;
            }
        }
        return of0;
    }

    public final boolean e(of0 of0, int i) {
        while (true) {
            Object f = f();
            AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = f;
            if (f == null) {
                f = (of0) atomicReferenceFieldUpdater.get(this);
                while (f.i()) {
                    of0 of02 = (of0) atomicReferenceFieldUpdater.get(f);
                }
            }
            if (f instanceof re0) {
                return (((re0) f).h & i) == 0 && f.e(of0, i);
            } else {
                atomicReferenceFieldUpdater.set(of0, f);
                atomicReferenceFieldUpdater = e;
                atomicReferenceFieldUpdater.set(of0, this);
                while (!atomicReferenceFieldUpdater.compareAndSet(f, this, of0)) {
                    if (atomicReferenceFieldUpdater.get(f) != this) {
                    }
                }
                of0.g(this);
                return true;
            }
        }
    }

    public final void g(of0 of0) {
        while (true) {
            AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = f;
            of0 of02 = (of0) atomicReferenceFieldUpdater.get(of0);
            if (e.get(this) == of0) {
                while (!atomicReferenceFieldUpdater.compareAndSet(of0, of02, this)) {
                    if (atomicReferenceFieldUpdater.get(of0) != of02) {
                    }
                }
                if (i()) {
                    of0.f();
                    return;
                }
                return;
            }
            return;
        }
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(new ic0(1, 1, vn.class, this, "classSimpleName", "getClassSimpleName(Ljava/lang/Object;)Ljava/lang/String;"));
        stringBuilder.append('@');
        stringBuilder.append(vn.y(this));
        return stringBuilder.toString();
    }

    static {
        Class cls = of0.class;
        Class cls2 = Object.class;
        e = AtomicReferenceFieldUpdater.newUpdater(cls, cls2, "_next$volatile");
        f = AtomicReferenceFieldUpdater.newUpdater(cls, cls2, "_prev$volatile");
        g = AtomicReferenceFieldUpdater.newUpdater(cls, cls2, "_removedRef$volatile");
    }

    public final of0 h() {
        Object obj = e.get(this);
        bx0 bx0 = obj instanceof bx0 ? (bx0) obj : null;
        if (bx0 != null) {
            return bx0.a;
        }
        obj.getClass();
        return (of0) obj;
    }

    public boolean i() {
        return e.get(this) instanceof bx0;
    }
}