package defpackage;

import android.app.Application;
import android.app.PictureInPictureUiState;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Trace;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import com.almekhlafi.goldbook.MainActivity;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ki */
public abstract class ki extends ji implements kh1, z20, xz0, kn0, el0, o2 {
    public final kl f;
    public final pg0 g = new h90(21);
    public final al h;
    public jg0 i;
    public final gi j;
    public final da1 k;
    public final ii l;
    public final CopyOnWriteArrayList m;
    public final CopyOnWriteArrayList n;
    public final CopyOnWriteArrayList o;
    public final CopyOnWriteArrayList p;
    public final CopyOnWriteArrayList q;
    public final CopyOnWriteArrayList r;
    public final CopyOnWriteArrayList s;
    public boolean t;
    public boolean u;
    public final da1 v;
    public final da1 w;
    public final da1 x;

    public ki() {
        kl klVar = new kl();
        this.f = klVar;
        MainActivity mainActivity = (MainActivity) this;
        wz0 wz0 = new wz0(this, new x1(13, (Object) this));
        al alVar = new al(wz0, 20);
        this.h = alVar;
        this.j = new gi(mainActivity);
        this.k = new ad0(new ai(mainActivity, 1));
        AtomicInteger atomicInteger = new AtomicInteger();
        this.l = new ii(mainActivity);
        this.m = new CopyOnWriteArrayList();
        this.n = new CopyOnWriteArrayList();
        this.o = new CopyOnWriteArrayList();
        this.p = new CopyOnWriteArrayList();
        this.q = new CopyOnWriteArrayList();
        this.r = new CopyOnWriteArrayList();
        this.s = new CopyOnWriteArrayList();
        this.v = new ad0(new ai(mainActivity, 2));
        ud0 ud0 = this.e;
        if (ud0 != null) {
            ud0.a(new ci(0, mainActivity));
            this.e.a(new ci(1, mainActivity));
            this.e.a(new fw0(1, mainActivity));
            wz0.a();
            jd0 jd0 = this.e.d;
            if (jd0 != jd0.f) {
                if (jd0 != jd0.g) {
                    od.m("Failed requirement.");
                    throw null;
                }
            }
            String str = "androidx.lifecycle.internal.SavedStateHandlesProvider";
            if (((al) alVar.g).o(str) == null) {
                sz0 sz0 = new sz0((al) alVar.g, mainActivity);
                ((al) alVar.g).s(str, sz0);
                this.e.a(new fw0(3, sz0));
            }
            if (VERSION.SDK_INT == 23) {
                this.e.a(new h40(mainActivity));
            }
            ((al) alVar.g).s("android:support:activity-result", new di(0, mainActivity));
            ei eiVar = new ei(mainActivity);
            ki kiVar = klVar.b;
            if (kiVar != null) {
                eiVar.a(kiVar);
            }
            klVar.a.add(eiVar);
            this.w = new ad0(new ai(mainActivity, 3));
            this.x = new ad0(new ai(mainActivity, 4));
            return;
        }
        od.p("getLifecycle() returned null in ComponentActivity's constructor. Please make sure you are lazily constructing your Lifecycle in the first call to getLifecycle() rather than relying on field initialization.");
        throw null;
    }

    public final void h() {
        View decorView = getWindow().getDecorView();
        decorView.getClass();
        decorView.setTag(2131034229, this);
        decorView = getWindow().getDecorView();
        decorView.getClass();
        decorView.setTag(2131034233, this);
        decorView = getWindow().getDecorView();
        decorView.getClass();
        decorView.setTag(2131034232, this);
        decorView = getWindow().getDecorView();
        decorView.getClass();
        decorView.setTag(2131034231, this);
        decorView = getWindow().getDecorView();
        decorView.getClass();
        decorView.setTag(2131034193, this);
        decorView = getWindow().getDecorView();
        decorView.getClass();
        decorView.setTag(2131034230, this);
    }

    public final void onPictureInPictureUiStateChanged(PictureInPictureUiState pictureInPictureUiState) {
        Object h90;
        pictureInPictureUiState.getClass();
        super.onPictureInPictureUiStateChanged(pictureInPictureUiState);
        int i = VERSION.SDK_INT;
        if (i >= 35) {
            pictureInPictureUiState.isStashed();
            pictureInPictureUiState.isTransitioningToPip();
            h90 = new h90(26);
        } else if (i >= 31) {
            pictureInPictureUiState.isStashed();
            h90 = new h90(26);
        } else {
            h90 = new h90(26);
        }
        Iterator it = this.r.iterator();
        it.getClass();
        while (it.hasNext()) {
            ((wk) it.next()).accept(h90);
        }
    }

    public final void reportFullyDrawn() {
        try {
            if (sb0.p()) {
                sb0.c("reportFullyDrawn() for ComponentActivity");
            }
            super.reportFullyDrawn();
            wz wzVar = (wz) this.k.getValue();
            synchronized (wzVar.a) {
                try {
                    wzVar.b = true;
                    ArrayList arrayList = wzVar.c;
                    int size = arrayList.size();
                    int i = 0;
                    while (i < size) {
                        Object obj = arrayList.get(i);
                        i++;
                        ((xz) obj).a();
                    }
                    wzVar.c.clear();
                } catch (Throwable th) {
                    throw th;
                }
            }
            Trace.endSection();
        } catch (Throwable th2) {
            Trace.endSection();
            throw th2;
        }
    }

    public final pj0 e() {
        pj0 pj0 = new pj0(hm.b);
        Application application = getApplication();
        LinkedHashMap linkedHashMap = pj0.a;
        if (application != null) {
            linkedHashMap.put(ih1.f, getApplication());
        }
        linkedHashMap.put(k70.q, this);
        linkedHashMap.put(k70.r, this);
        Intent intent = getIntent();
        Object extras = intent != null ? intent.getExtras() : null;
        if (extras != null) {
            linkedHashMap.put(k70.s, extras);
        }
        return pj0;
    }

    public void onCreate(Bundle bundle) {
        this.h.q(bundle);
        kl klVar = this.f;
        klVar.getClass();
        klVar.b = this;
        Iterator it = klVar.a.iterator();
        while (it.hasNext()) {
            ((ei) it.next()).a(this);
        }
        super.onCreate(bundle);
        int i = ix0.f;
        gx0.b(this);
        getPackageManager().hasSystemFeature("android.software.picture_in_picture");
    }

    public final void onMultiWindowModeChanged(boolean z, Configuration configuration) {
        configuration.getClass();
        this.t = true;
        try {
            super.onMultiWindowModeChanged(z, configuration);
            Iterator it = this.p.iterator();
            it.getClass();
            while (it.hasNext()) {
                ((wk) it.next()).accept(new h90(19));
            }
        } finally {
            this.t = false;
        }
    }

    public void onPictureInPictureModeChanged(boolean z, Configuration configuration) {
        configuration.getClass();
        this.u = true;
        try {
            super.onPictureInPictureModeChanged(z, configuration);
            Iterator it = this.q.iterator();
            it.getClass();
            while (it.hasNext()) {
                ((wk) it.next()).accept(new h90(25));
            }
        } finally {
            this.u = false;
        }
    }

    public final jg0 f() {
        if (getApplication() != null) {
            if (this.i == null) {
                fi fiVar = (fi) getLastNonConfigurationInstance();
                if (fiVar != null) {
                    this.i = fiVar.a;
                }
                if (this.i == null) {
                    this.i = new h90(1);
                }
            }
            jg0 jg0 = this.i;
            jg0.getClass();
            return jg0;
        }
        od.p("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
        return null;
    }

    public final boolean onCreatePanelMenu(int i, Menu menu) {
        menu.getClass();
        if (i == 0) {
            super.onCreatePanelMenu(i, menu);
            getMenuInflater();
            Iterator it = ((CopyOnWriteArrayList) this.g.f).iterator();
            if (it.hasNext()) {
                it.next().getClass();
                od.d();
                return false;
            }
        }
        return true;
    }

    public final boolean onMenuItemSelected(int i, MenuItem menuItem) {
        menuItem.getClass();
        if (super.onMenuItemSelected(i, menuItem)) {
            return true;
        }
        if (i == 0) {
            Iterator it = ((CopyOnWriteArrayList) this.g.f).iterator();
            if (it.hasNext()) {
                it.next().getClass();
                od.d();
            }
        }
        return false;
    }

    public final boolean onPreparePanel(int i, View view, Menu menu) {
        menu.getClass();
        if (i == 0) {
            super.onPreparePanel(i, view, menu);
            Iterator it = ((CopyOnWriteArrayList) this.g.f).iterator();
            if (it.hasNext()) {
                it.next().getClass();
                od.d();
                return false;
            }
        }
        return true;
    }

    public final void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        strArr.getClass();
        iArr.getClass();
        if (!this.l.a(i, -1, new Intent().putExtra("androidx.activity.result.contract.extra.PERMISSIONS", strArr).putExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS", iArr))) {
            super.onRequestPermissionsResult(i, strArr, iArr);
        }
    }

    public static void d(MainActivity mainActivity) {
        try {
            super.onBackPressed();
        } catch (IllegalStateException e) {
            if (!k70.p(e.getMessage(), "Can not perform this action after onSaveInstanceState")) {
                throw e;
            }
        } catch (NullPointerException e2) {
            if (!k70.p(e2.getMessage(), "Attempt to invoke virtual method 'android.os.Handler android.app.FragmentHostCallback.getHandler()' on a null object reference")) {
                throw e2;
            }
        }
    }

    public final void onPanelClosed(int i, Menu menu) {
        menu.getClass();
        Iterator it = ((CopyOnWriteArrayList) this.g.f).iterator();
        if (it.hasNext()) {
            it.next().getClass();
            od.d();
            return;
        }
        super.onPanelClosed(i, menu);
    }

    public final void onTrimMemory(int i) {
        super.onTrimMemory(i);
        Iterator it = this.n.iterator();
        it.getClass();
        while (it.hasNext()) {
            ((wk) it.next()).accept(Integer.valueOf(i));
        }
    }

    public final void onConfigurationChanged(Configuration configuration) {
        configuration.getClass();
        super.onConfigurationChanged(configuration);
        Iterator it = this.m.iterator();
        it.getClass();
        while (it.hasNext()) {
            ((wk) it.next()).accept(configuration);
        }
    }

    public final void onNewIntent(Intent intent) {
        intent.getClass();
        super.onNewIntent(intent);
        Iterator it = this.o.iterator();
        it.getClass();
        while (it.hasNext()) {
            ((wk) it.next()).accept(intent);
        }
    }

    public final void onSaveInstanceState(Bundle bundle) {
        bundle.getClass();
        ud0 ud0 = this.e;
        if (ud0 != null) {
            ud0.getClass();
            ud0.c("setCurrentState");
            ud0.e(jd0.g);
        }
        super.onSaveInstanceState(bundle);
        this.h.r(bundle);
    }

    public void onUserLeaveHint() {
        super.onUserLeaveHint();
        Iterator it = this.s.iterator();
        it.getClass();
        while (it.hasNext()) {
            ((Runnable) it.next()).run();
        }
    }

    public final Object onRetainNonConfigurationInstance() {
        fi fiVar;
        jg0 jg0 = this.i;
        if (jg0 == null) {
            fiVar = (fi) getLastNonConfigurationInstance();
            if (fiVar != null) {
                jg0 = fiVar.a;
            }
        }
        if (jg0 == null) {
            return null;
        }
        fiVar = new Object();
        fiVar.a = jg0;
        return fiVar;
    }

    public final void addContentView(View view, LayoutParams layoutParams) {
        h();
        View decorView = getWindow().getDecorView();
        decorView.getClass();
        this.j.a(decorView);
        super.addContentView(view, layoutParams);
    }

    public final void setContentView(int i) {
        h();
        View decorView = getWindow().getDecorView();
        decorView.getClass();
        this.j.a(decorView);
        super.setContentView(i);
    }

    public final void onActivityResult(int i, int i2, Intent intent) {
        if (!this.l.a(i, i2, intent)) {
            super.onActivityResult(i, i2, intent);
        }
    }

    public final void onBackPressed() {
        ((cq) this.v.getValue()).a();
    }

    public final p3 a() {
        return b().a();
    }

    public final jn0 b() {
        return (jn0) this.x.getValue();
    }

    public final al c() {
        return (al) this.h.g;
    }

    public final void startActivityForResult(Intent intent, int i) {
        intent.getClass();
        super.startActivityForResult(intent, i);
    }

    public final void startIntentSenderForResult(IntentSender intentSender, int i, Intent intent, int i2, int i3, int i4) {
        intentSender.getClass();
        super.startIntentSenderForResult(intentSender, i, intent, i2, i3, i4);
    }

    public final void onMultiWindowModeChanged(boolean z) {
        if (!this.t) {
            Iterator it = this.p.iterator();
            it.getClass();
            while (it.hasNext()) {
                ((wk) it.next()).accept(new h90(19));
            }
        }
    }

    public final void onPictureInPictureModeChanged(boolean z) {
        if (!this.u) {
            Iterator it = this.q.iterator();
            it.getClass();
            while (it.hasNext()) {
                ((wk) it.next()).accept(new h90(25));
            }
        }
    }

    public final ud0 g() {
        return this.e;
    }

    public void setContentView(View view) {
        h();
        View decorView = getWindow().getDecorView();
        decorView.getClass();
        this.j.a(decorView);
        super.setContentView(view);
    }

    public final void setContentView(View view, LayoutParams layoutParams) {
        h();
        View decorView = getWindow().getDecorView();
        decorView.getClass();
        this.j.a(decorView);
        super.setContentView(view, layoutParams);
    }

    public final void startActivityForResult(Intent intent, int i, Bundle bundle) {
        intent.getClass();
        super.startActivityForResult(intent, i, bundle);
    }

    public final void startIntentSenderForResult(IntentSender intentSender, int i, Intent intent, int i2, int i3, int i4, Bundle bundle) {
        intentSender.getClass();
        super.startIntentSenderForResult(intentSender, i, intent, i2, i3, i4, bundle);
    }
}