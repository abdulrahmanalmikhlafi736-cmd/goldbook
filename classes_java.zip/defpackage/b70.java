package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: b70 */
public abstract class b70 {
    public static final h30 a = new f3(a70.l);
    public static final ng1 b = new f3(z60.l);
    public static final k81 c = new ad0(new h90(16));

    static {
        wa0.s(new h90(15));
    }
}