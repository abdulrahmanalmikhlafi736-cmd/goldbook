package defpackage;

import java.io.Serializable;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: h90 */
public abstract class h90 implements v00, Serializable {
    public final int e;

    public final String toString() {
        ow0.a.getClass();
        return pw0.a(this);
    }

    public h90(int i) {
        this.e = i;
    }

    public final int b() {
        return this.e;
    }
}