package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bd0 */
public final class bd0 implements bj1 {
    public final lq0 a;

    public bd0(int i) {
        switch (i) {
            case 1:
                this.a = mc0.t(Boolean.FALSE);
                return;
            default:
                this.a = mc0.t(Boolean.FALSE);
                return;
        }
    }
}