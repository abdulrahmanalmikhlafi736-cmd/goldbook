package defpackage;

import java.util.LinkedHashMap;
import java.util.Map;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ch0 */
public abstract class ch0 extends sb0 {
    public static Object x(Object obj, Map map) {
        map.getClass();
        Object obj2 = map.get(obj);
        if (obj2 == null) {
            if (!map.containsKey(obj)) {
                StringBuilder dl1 = new dl1("Key ");
                dl1.append(obj);
                dl1.append(" is missing in the map.");
                throw new dl1(dl1.toString());
            }
        }
        return obj2;
    }

    public static Map z(zp0... zp0Arr) {
        if (zp0Arr.length <= 0) {
            return vt.e;
        }
        LinkedHashMap h90 = new h90(ch0.y(zp0Arr.length));
        for (zp0 zp0 : zp0Arr) {
            h90.put(zp0.e, zp0.f);
        }
        return h90;
    }

    public static int y(int i) {
        if (i < 0) {
            return i;
        }
        if (i < 3) {
            return i + 1;
        }
        return i < 1073741824 ? (int) ((((float) i) / 0.75f) + 1.0f) : Integer.MAX_VALUE;
    }
}