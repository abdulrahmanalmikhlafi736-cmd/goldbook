package defpackage;

import android.os.Build.VERSION;
import android.text.Spannable;
import android.text.SpannableString;
import java.util.stream.IntStream;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bf1 */
public final class bf1 implements Spannable {
    public boolean e = false;
    public Spannable f;

    public final void a() {
        Spannable spannable = this.f;
        if (!this.e) {
            if ((VERSION.SDK_INT < 28 ? new h90(18) : new h90(18)).q(spannable)) {
                this.f = new SpannableString(spannable);
            }
        }
        this.e = true;
    }

    public bf1(Spannable spannable) {
        this.f = spannable;
    }

    public final void removeSpan(Object obj) {
        a();
        this.f.removeSpan(obj);
    }

    public final void setSpan(Object obj, int i, int i2, int i3) {
        a();
        this.f.setSpan(obj, i, i2, i3);
    }

    public final char charAt(int i) {
        return this.f.charAt(i);
    }

    public final IntStream chars() {
        return this.f.chars();
    }

    public final IntStream codePoints() {
        return this.f.codePoints();
    }

    public final int getSpanEnd(Object obj) {
        return this.f.getSpanEnd(obj);
    }

    public final int getSpanFlags(Object obj) {
        return this.f.getSpanFlags(obj);
    }

    public final int getSpanStart(Object obj) {
        return this.f.getSpanStart(obj);
    }

    public final Object[] getSpans(int i, int i2, Class cls) {
        return this.f.getSpans(i, i2, cls);
    }

    public final int length() {
        return this.f.length();
    }

    public final int nextSpanTransition(int i, int i2, Class cls) {
        return this.f.nextSpanTransition(i, i2, cls);
    }

    public final CharSequence subSequence(int i, int i2) {
        return this.f.subSequence(i, i2);
    }

    public final String toString() {
        return this.f.toString();
    }
}