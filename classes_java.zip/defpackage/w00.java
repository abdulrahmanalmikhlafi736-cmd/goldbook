package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: w00 */
public class w00 extends ge implements v00, u80, u00 {
    public final int k;

    /* JADX WARNING: Missing block: B:11:0x0033, code:
            if (e().equals(r3.e()) != false) goto L_0x0035;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean equals(Object obj) {
        if (obj != this) {
            if (obj instanceof w00) {
                w00 w00 = (w00) obj;
                if (this.h.equals(w00.h)) {
                    if (this.i.equals(w00.i)) {
                        if (k70.p(this.f, w00.f)) {
                        }
                    }
                }
            } else if (obj instanceof w00) {
                Object thisR;
                u80 u80 = this.e;
                if (u80 == null) {
                    d();
                    this.e = this;
                } else {
                    thisR = u80;
                }
                return obj.equals(thisR);
            }
            return false;
        }
        return true;
    }

    public final String toString() {
        w00 w00 = this.e;
        if (w00 == null) {
            d();
            this.e = this;
            w00 = this;
        }
        if (w00 != this) {
            return w00.toString();
        }
        String str = this.h;
        if ("<init>".equals(str)) {
            return "constructor (Kotlin reflection is not available)";
        }
        StringBuilder dl1 = new dl1("function ");
        dl1.append(str);
        dl1.append(" (Kotlin reflection is not available)");
        return dl1.toString();
    }

    public final int hashCode() {
        e();
        return this.i.hashCode() + ((this.h.hashCode() + (e().hashCode() * 31)) * 31);
    }

    public w00(int i, Object obj, Class cls, String str, String str2, int i2, int i3) {
        boolean z = true;
        if ((i2 & 1) != 1) {
            z = false;
        }
        super(obj, cls, str, str2, z);
        this.k = i;
    }

    public final u80 d() {
        ow0.a.getClass();
        return this;
    }

    public final int b() {
        return this.k;
    }

    public w00(int i, Class cls, String str, String str2, int i2) {
        this(i, fe.e, cls, str, str2, i2, 0);
    }
}