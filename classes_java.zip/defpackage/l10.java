package defpackage;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: l10 */
public abstract class l10 extends x {
    private static final int MEMOIZED_SERIALIZED_SIZE_MASK = Integer.MAX_VALUE;
    private static final int MUTABLE_FLAG_MASK = Integer.MIN_VALUE;
    static final int UNINITIALIZED_HASH_CODE = 0;
    static final int UNINITIALIZED_SERIALIZED_SIZE = Integer.MAX_VALUE;
    private static Map<Object, l10> defaultInstanceMap = new ConcurrentHashMap();
    private int memoizedSerializedSize = -1;
    protected xe1 unknownFields = xe1.f;

    public final int a(q01 q01) {
        jv0 jv0;
        if (g()) {
            int d;
            if (q01 == null) {
                jv0 = jv0.c;
                jv0.getClass();
                d = jv0.a(getClass()).d(this);
            } else {
                d = q01.d(this);
            }
            if (d >= 0) {
                return d;
            }
            od.p(fu0.E("serialized size must be non-negative, was ", d));
            return 0;
        }
        int i = this.memoizedSerializedSize;
        if ((i & Integer.MAX_VALUE) != Integer.MAX_VALUE) {
            return i & Integer.MAX_VALUE;
        }
        int d2;
        if (q01 == null) {
            jv0 = jv0.c;
            jv0.getClass();
            d2 = jv0.a(getClass()).d(this);
        } else {
            d2 = q01.d(this);
        }
        k(d2);
        return d2;
    }

    public static l10 d(Class cls) {
        l10 l10 = (l10) defaultInstanceMap.get(cls);
        if (l10 == null) {
            try {
                Class.forName(cls.getName(), true, cls.getClassLoader());
                l10 = (l10) defaultInstanceMap.get(cls);
            } catch (ClassNotFoundException e) {
                throw new IllegalStateException("Class initialization cannot fail.", e);
            }
        }
        if (l10 != null) {
            return l10;
        }
        l10 = (l10) l10.d(cls).c(6);
        if (l10 != null) {
            defaultInstanceMap.put(cls, l10);
            return l10;
        }
        throw new IllegalStateException();
    }

    public final int hashCode() {
        jv0 jv0;
        if (g()) {
            jv0 = jv0.c;
            jv0.getClass();
            return jv0.a(getClass()).a(this);
        }
        if (this.memoizedHashCode == 0) {
            jv0 = jv0.c;
            jv0.getClass();
            this.memoizedHashCode = jv0.a(getClass()).a(this);
        }
        return this.memoizedHashCode;
    }

    public static final boolean f(l10 l10, boolean z) {
        byte byteValue = ((Byte) l10.c(1)).byteValue();
        if (byteValue == (byte) 1) {
            return true;
        }
        if (byteValue == (byte) 0) {
            return false;
        }
        jv0 jv0 = jv0.c;
        jv0.getClass();
        Object e = jv0.a(l10.getClass()).e(l10);
        if (z) {
            l10.c(2);
        }
        return e;
    }

    public static Object e(Method method, l10 l10, Object... objArr) {
        try {
            return method.invoke(l10, objArr);
        } catch (IllegalAccessException e) {
            throw new RuntimeException("Couldn't use Java reflection to implement protocol message reflection.", e);
        } catch (InvocationTargetException e2) {
            Throwable cause = e2.getCause();
            if (cause instanceof RuntimeException) {
                throw ((RuntimeException) cause);
            } else if (cause instanceof Error) {
                throw ((Error) cause);
            } else {
                throw new RuntimeException("Unexpected exception thrown by generated accessor method.", cause);
            }
        }
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null) {
            if (getClass() == obj.getClass()) {
                jv0 jv0 = jv0.c;
                jv0.getClass();
                return jv0.a(getClass()).g(this, (l10) obj);
            }
        }
        return false;
    }

    public final String toString() {
        String obj = super.toString();
        char[] cArr = sh0.a;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("# ");
        stringBuilder.append(obj);
        sh0.c(this, stringBuilder, 0);
        return stringBuilder.toString();
    }

    public final void b(rg rgVar) {
        jv0 jv0 = jv0.c;
        jv0.getClass();
        fh1 a = jv0.a(getClass());
        pg0 pg0 = rgVar.a;
        if (pg0 == null) {
            pg0 = new pg0(rgVar);
        }
        a.f(this, pg0);
    }

    public final void k(int i) {
        if (i >= 0) {
            this.memoizedSerializedSize = (i & Integer.MAX_VALUE) | (this.memoizedSerializedSize & MUTABLE_FLAG_MASK);
            return;
        }
        od.p(fu0.E("serialized size must be non-negative, was ", i));
    }

    public final boolean g() {
        return (this.memoizedSerializedSize & MUTABLE_FLAG_MASK) != 0;
    }

    public static void j(Class cls, l10 l10) {
        l10.h();
        defaultInstanceMap.put(cls, l10);
    }

    public final void h() {
        this.memoizedSerializedSize &= Integer.MAX_VALUE;
    }

    public final l10 i() {
        return (l10) c(4);
    }

    public abstract Object c(int i);
}