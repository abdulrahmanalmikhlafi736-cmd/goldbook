package defpackage;

import android.content.pm.PackageInfo;
import android.net.Uri;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bi1 */
public abstract class bi1 {
    public static final /* synthetic */ int a = 0;

    public static PackageInfo a() {
        return (PackageInfo) Class.forName("android.webkit.WebViewFactory").getMethod("getLoadedPackageInfo", null).invoke(null, null);
    }

    static {
        Uri.parse("*");
        Uri.parse("");
    }
}