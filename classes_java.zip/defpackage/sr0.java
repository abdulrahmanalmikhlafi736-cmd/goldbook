package defpackage;

import java.util.Iterator;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: sr0 */
public abstract class sr0 implements Iterator, w80 {
    public final pd1[] e;
    public int f;
    public boolean g = true;

    public final void a() {
        int i = this.f;
        pd1[] pd1Arr = this.e;
        pd1 pd1 = pd1Arr[i];
        if (pd1.g >= pd1.f) {
            while (-1 < i) {
                int b = b(i);
                if (b == -1) {
                    pd1 pd12 = pd1Arr[i];
                    int i2 = pd12.g;
                    Object[] objArr = pd12.e;
                    if (i2 < objArr.length) {
                        b = objArr.length;
                        pd12.g = i2 + 1;
                        b = b(i);
                    }
                }
                if (b != -1) {
                    this.f = b;
                    return;
                }
                if (i > 0) {
                    pd1 pd13 = pd1Arr[i - 1];
                    b = pd13.g;
                    int length = pd13.e.length;
                    pd13.g = b + 1;
                }
                pd1Arr[i].a(od1.e.d, 0, 0);
                i--;
            }
            this.g = false;
        }
    }

    public final int b(int i) {
        pd1[] pd1Arr = this.e;
        pd1 pd1 = pd1Arr[i];
        int i2 = pd1.g;
        if (i2 < pd1.f) {
            return i;
        }
        Object[] objArr = pd1.e;
        if (i2 >= objArr.length) {
            return -1;
        }
        int length = objArr.length;
        Object obj = objArr[i2];
        obj.getClass();
        od1 od1 = (od1) obj;
        if (i == 6) {
            pd1 pd12 = pd1Arr[i + 1];
            objArr = od1.d;
            pd12.a(objArr, objArr.length, 0);
        } else {
            pd1Arr[i + 1].a(od1.d, Integer.bitCount(od1.a) * 2, 0);
        }
        return b(i + 1);
    }

    public sr0(od1 od1, pd1[] pd1Arr) {
        this.e = pd1Arr;
        pd1Arr[0].a(od1.d, Integer.bitCount(od1.a) * 2, 0);
        this.f = 0;
        a();
    }

    public Object next() {
        if (this.g) {
            Object next = this.e[this.f].next();
            a();
            return next;
        }
        od.n();
        return null;
    }

    public void remove() {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final boolean hasNext() {
        return this.g;
    }
}