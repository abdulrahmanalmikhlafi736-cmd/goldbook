package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cc0 */
public final class cc0 extends u91 implements m00 {
    public int i;
    public final /* synthetic */ dc0 j;
    public final /* synthetic */ int k;

    public final Object p(Object obj) {
        int i = this.i;
        we1 we1 = we1.a;
        if (i == 0) {
            nb0.t(obj);
            yb0 yb0 = this.j.t;
            this.i = 1;
            sc0 sc0 = yb0.b;
            al alVar = sc0.x;
            sc0.getClass();
            cm d = sc0.d(tk0.e, new ao(sc0, this.k, null), this);
            cm cmVar = cm.e;
            if (d != cmVar) {
                d = we1;
            }
            if (d != cmVar) {
                d = we1;
            }
            return d == cmVar ? cmVar : we1;
        } else if (i == 1) {
            nb0.t(obj);
            return we1;
        } else {
            od.p("call to 'resume' before 'invoke' with coroutine");
            return null;
        }
    }

    public final Object f(Object obj, Object obj2) {
        return ((cc0) n((ml) obj2, (bm) obj)).p(we1.a);
    }

    public final ml n(ml mlVar, Object obj) {
        return new cc0(this.j, this.k, mlVar);
    }

    public cc0(dc0 dc0, int i, ml mlVar) {
        this.j = dc0;
        this.k = i;
        super(2, mlVar);
    }
}