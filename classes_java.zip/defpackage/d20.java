package defpackage;

import android.content.Context;
import android.view.autofill.AutofillManager$AutofillCallback;
import android.view.autofill.AutofillValue;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: d20 */
public final /* synthetic */ class d20 implements m00 {
    public final /* synthetic */ int e = 1;
    public final /* synthetic */ Object f;
    public final /* synthetic */ Object g;
    public final /* synthetic */ Object h;
    public final /* synthetic */ Object i;
    public final /* synthetic */ Object j;

    public final Object f(Object obj, Object obj2) {
        int i = this.e;
        we1 we1 = we1.a;
        Object obj3 = this.j;
        Object obj4 = this.i;
        Object obj5 = this.h;
        Object obj6 = this.g;
        Object obj7 = this.f;
        switch (i) {
            case 0:
                String str = (String) obj7;
                mk0 mk0 = (mk0) obj5;
                String str2 = (String) obj6;
                t41 t41 = (t41) obj4;
                Context context = (Context) obj3;
                d10 d10 = (d10) obj;
                int intValue = ((Integer) obj2).intValue();
                if (d10.O(intValue & 1, (intValue & 3) != 2)) {
                    boolean p = k70.p(str, "messages");
                    nq0 nq0 = oj.a;
                    if (p) {
                        d10.W(2052150207);
                        AutofillManager$AutofillCallback f = ((AutofillManager$AutofillCallback) d10);
                        obj3 = d10.L();
                        if (f != null || obj3 == nq0) {
                            obj3 = new a20(mk0, 1);
                            d10.g0(obj3);
                        }
                        zh0.a((xz) obj3, d10, 0);
                        d10.p(false);
                    } else {
                        d10.W(2052154767);
                        int h = ((AutofillValue) d10) | ((AutofillManager$AutofillCallback) d10);
                        Object L = d10.L();
                        if (h != 0 || L == nq0) {
                            L = new e20(context, mk0, 0);
                            d10.g0(L);
                        }
                        j70.d(str2, t41, (xz) L, d10, 0);
                        d10.p(false);
                    }
                } else {
                    d10.R();
                }
                return we1;
            default:
                ed1 ed1 = (ed1) obj7;
                bd1 bd1 = (bd1) obj6;
                Float f2 = (Float) obj5;
                Float f3 = (Float) obj4;
                yv yvVar = (yv) obj3;
                d10 d102 = (d10) obj;
                ((Integer) obj2).getClass();
                gd1.a(ed1, bd1, f2, f3, yvVar, d102, wc0.s(1));
                return we1;
        }
    }

    public /* synthetic */ d20(ed1 ed1, bd1 bd1, Float f, Float f2, yv yvVar, int i) {
        this.f = ed1;
        this.g = bd1;
        this.h = f;
        this.i = f2;
        this.j = yvVar;
    }

    public /* synthetic */ d20(String str, mk0 mk0, String str2, t41 t41, Context context) {
        this.f = str;
        this.h = mk0;
        this.g = str2;
        this.i = t41;
        this.j = context;
    }
}