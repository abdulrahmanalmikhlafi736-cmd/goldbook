package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: c21 */
public abstract class c21 {
    public static final q21 A;
    public static final q21 B;
    public static final q21 a;
    public static final q21 b;
    public static final q21 c;
    public static final q21 d;
    public static final q21 e = new dl1("ScrollByOffset");
    public static final q21 f;
    public static final q21 g;
    public static final q21 h;
    public static final q21 i;
    public static final q21 j;
    public static final q21 k;
    public static final q21 l;
    public static final q21 m;
    public static final q21 n;
    public static final q21 o;
    public static final q21 p;
    public static final q21 q;
    public static final q21 r;
    public static final q21 s;
    public static final q21 t;
    public static final q21 u;
    public static final q21 v;
    public static final q21 w = new q21("CustomActions", true, s7.z);
    public static final q21 x;
    public static final q21 y;
    public static final q21 z;

    static {
        m21 m21 = m21.m;
        a = new q21("GetTextLayoutResult", true, m21);
        b = new q21("OnClick", true, m21);
        c = new q21("OnLongClick", true, m21);
        d = new q21("ScrollBy", true, m21);
        f = new q21("ScrollToIndex", true, m21);
        g = new q21("OnAutofillText", true, m21);
        h = new q21("OnFillData", true, m21);
        i = new q21("SetProgress", true, m21);
        j = new q21("SetSelection", true, m21);
        k = new q21("SetText", true, m21);
        l = new q21("SetTextSubstitution", true, m21);
        m = new q21("ShowTextSubstitution", true, m21);
        n = new q21("ClearTextSubstitution", true, m21);
        o = new q21("PerformImeAction", true, m21);
        p = new q21("CopyText", true, m21);
        q = new q21("CutText", true, m21);
        r = new q21("PasteText", true, m21);
        s = new q21("Expand", true, m21);
        t = new q21("Collapse", true, m21);
        u = new q21("Dismiss", true, m21);
        v = new q21("RequestFocus", true, m21);
        x = new q21("PageUp", true, m21);
        y = new q21("PageLeft", true, m21);
        z = new q21("PageDown", true, m21);
        A = new q21("PageRight", true, m21);
        B = new q21("GetScrollViewportLength", true, m21);
    }
}