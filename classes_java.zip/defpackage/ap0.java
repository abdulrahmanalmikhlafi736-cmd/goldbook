package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ap0 */
public abstract class ap0 {
    public static final /* synthetic */ int a = 0;

    static {
        bk0 h90 = new h90(0);
    }
}