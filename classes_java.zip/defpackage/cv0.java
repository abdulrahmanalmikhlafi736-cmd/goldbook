package defpackage;

import android.content.Context;
import android.os.Build.VERSION;
import android.os.Handler;
import android.os.Looper;
import android.view.Choreographer.FrameCallback;
import androidx.profileinstaller.ProfileInstallerInitializer;
import java.util.Random;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cv0 */
public final /* synthetic */ class cv0 implements FrameCallback {
    public final /* synthetic */ Context e;

    public final void doFrame(long j) {
        (VERSION.SDK_INT >= 28 ? Handler.createAsync(Looper.getMainLooper()) : new Handler(Looper.getMainLooper())).postDelayed(new dv0(this.e, 0), (long) (new Random().nextInt(Math.max(1000, 1)) + 5000));
    }

    public /* synthetic */ cv0(ProfileInstallerInitializer profileInstallerInitializer, Context context) {
        this.e = context;
    }
}