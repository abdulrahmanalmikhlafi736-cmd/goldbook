package defpackage;

import android.graphics.Path;
import android.graphics.Path.FillType;
import android.view.View;
import android.view.autofill.AutofillManager$AutofillCallback;
import android.view.autofill.AutofillValue;
import java.io.BufferedReader;
import java.io.StringWriter;
import java.util.List;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ua0 */
public abstract class ua0 {
    public static y30 a;

    public static final void x(List list, r6 r6Var) {
        a91 a91 = list;
        r6 r6Var2 = r6Var;
        Path path = r6Var2.a;
        am amVar = r6Var2.a;
        FillType fillType = path.getFillType();
        FillType fillType2 = FillType.EVEN_ODD;
        int i = fillType == fillType2 ? 1 : 0;
        amVar.rewind();
        if (i != 1) {
            fillType2 = FillType.WINDING;
        }
        amVar.setFillType(fillType2);
        jr0 jr0 = a91.isEmpty() ? rq0.c : (jr0) a91.get(0);
        int size = a91.size();
        float f = 0.0f;
        int i2 = 0;
        float f2 = 0.0f;
        float f3 = f2;
        float f4 = f3;
        float f5 = f4;
        float f6 = f5;
        float f7 = f6;
        while (i2 < size) {
            am amVar2;
            int i3;
            float f8;
            int i4;
            jr0 jr02;
            jr0 jr03 = (jr0) a91.get(i2);
            if (jr03 instanceof rq0) {
                amVar.close();
                amVar2 = amVar;
                i3 = size;
                f8 = f;
                i4 = i2;
                jr02 = jr03;
                f2 = f6;
                f4 = f2;
                f3 = f7;
                f5 = f3;
            } else {
                float f9;
                float f10;
                if (jr03 instanceof dr0) {
                    dr0 dr0 = (dr0) jr03;
                    f9 = dr0.c;
                    f4 += f9;
                    f10 = dr0.d;
                    f5 += f10;
                    amVar.rMoveTo(f9, f10);
                    amVar2 = amVar;
                    i3 = size;
                    f8 = f;
                    i4 = i2;
                    f6 = f4;
                    f7 = f5;
                } else {
                    if (jr03 instanceof vq0) {
                        vq0 vq0 = (vq0) jr03;
                        f9 = vq0.c;
                        f10 = vq0.d;
                        amVar.moveTo(f9, f10);
                        f5 = f10;
                        f7 = f5;
                        amVar2 = amVar;
                        f4 = f9;
                        f6 = f4;
                    } else {
                        if (jr03 instanceof cr0) {
                            cr0 cr0 = (cr0) jr03;
                            f9 = cr0.d;
                            f10 = cr0.c;
                            amVar.rLineTo(f10, f9);
                            f4 += f10;
                            f5 += f9;
                        } else if (jr03 instanceof uq0) {
                            uq0 uq0 = (uq0) jr03;
                            f9 = uq0.d;
                            f10 = uq0.c;
                            amVar.lineTo(f10, f9);
                            f4 = f10;
                            amVar2 = amVar;
                            f5 = f9;
                        } else if (jr03 instanceof br0) {
                            f10 = ((br0) jr03).c;
                            amVar.rLineTo(f10, f);
                            f4 += f10;
                        } else if (jr03 instanceof tq0) {
                            f10 = ((tq0) jr03).c;
                            amVar.lineTo(f10, f5);
                            f4 = f10;
                        } else {
                            if (jr03 instanceof hr0) {
                                f10 = ((hr0) jr03).c;
                                amVar.rLineTo(f, f10);
                            } else if (jr03 instanceof ir0) {
                                f10 = ((ir0) jr03).c;
                                amVar.lineTo(f4, f10);
                                f5 = f10;
                            } else if (jr03 instanceof ar0) {
                                ar0 ar0 = (ar0) jr03;
                                amVar.rCubicTo(ar0.c, ar0.d, ar0.e, ar0.f, ar0.g, ar0.h);
                                f2 = ar0.e + f4;
                                f3 = ar0.f + f5;
                                f4 += ar0.g;
                                f10 = ar0.h;
                            } else {
                                if (jr03 instanceof sq0) {
                                    sq0 sq0 = (sq0) jr03;
                                    amVar.cubicTo(sq0.c, sq0.d, sq0.e, sq0.f, sq0.g, sq0.h);
                                    f2 = sq0.e;
                                    f3 = sq0.f;
                                    f9 = sq0.g;
                                    f10 = sq0.h;
                                } else if (jr03 instanceof fr0) {
                                    if (jr0.a) {
                                        f3 = f5 - f3;
                                        f2 = f4 - f2;
                                    } else {
                                        f2 = f;
                                        f3 = f2;
                                    }
                                    fr0 fr0 = (fr0) jr03;
                                    amVar.rCubicTo(f2, f3, fr0.c, fr0.d, fr0.e, fr0.f);
                                    f2 = fr0.c + f4;
                                    f3 = fr0.d + f5;
                                    f4 += fr0.e;
                                    f10 = fr0.f;
                                } else if (jr03 instanceof xq0) {
                                    if (jr0.a) {
                                        f4 = (f4 * 2.0f) - f2;
                                        f5 = (2.0f * f5) - f3;
                                    }
                                    xq0 xq0 = (xq0) jr03;
                                    amVar.cubicTo(f4, f5, xq0.c, xq0.d, xq0.e, xq0.f);
                                    f2 = xq0.c;
                                    f3 = xq0.d;
                                    f9 = xq0.e;
                                    f10 = xq0.f;
                                } else if (jr03 instanceof er0) {
                                    er0 er0 = (er0) jr03;
                                    f2 = er0.f;
                                    f3 = er0.e;
                                    f9 = er0.d;
                                    f10 = er0.c;
                                    amVar.rQuadTo(f10, f9, f3, f2);
                                    f10 += f4;
                                    f9 += f5;
                                    f4 += f3;
                                    f5 += f2;
                                    f2 = f10;
                                    amVar2 = amVar;
                                    f3 = f9;
                                } else {
                                    jr0 jr04;
                                    float f11;
                                    if (jr03 instanceof wq0) {
                                        wq0 wq0 = (wq0) jr03;
                                        f2 = wq0.f;
                                        f3 = wq0.e;
                                        f9 = wq0.d;
                                        f10 = wq0.c;
                                        amVar.quadTo(f10, f9, f3, f2);
                                        amVar2 = amVar;
                                        f5 = f2;
                                        f4 = f3;
                                        f3 = f9;
                                    } else if (jr03 instanceof gr0) {
                                        if (jr0.b) {
                                            f10 = f4 - f2;
                                            f2 = f5 - f3;
                                        } else {
                                            f10 = f;
                                            f2 = f10;
                                        }
                                        gr0 gr0 = (gr0) jr03;
                                        f9 = gr0.d;
                                        f3 = gr0.c;
                                        amVar.rQuadTo(f10, f2, f3, f9);
                                        f10 += f4;
                                        f2 += f5;
                                        f4 += f3;
                                        f5 += f9;
                                        amVar2 = amVar;
                                        f3 = f2;
                                    } else if (jr03 instanceof yq0) {
                                        if (jr0.b) {
                                            f4 = (f4 * 2.0f) - f2;
                                            f5 = (2.0f * f5) - f3;
                                        }
                                        yq0 yq0 = (yq0) jr03;
                                        f2 = yq0.d;
                                        f10 = yq0.c;
                                        amVar.quadTo(f4, f5, f10, f2);
                                        amVar2 = amVar;
                                        i3 = size;
                                        f8 = f;
                                        i4 = i2;
                                        f3 = f5;
                                        jr02 = jr03;
                                        f5 = f2;
                                        f2 = f4;
                                        f4 = f10;
                                    } else if (jr03 instanceof zq0) {
                                        zq0 zq0 = (zq0) jr03;
                                        f2 = zq0.h + f4;
                                        f3 = zq0.i + f5;
                                        i3 = size;
                                        f8 = 0.0f;
                                        double d = (double) zq0.e;
                                        jr04 = jr03;
                                        double d2 = (double) zq0.c;
                                        amVar2 = amVar;
                                        i4 = i2;
                                        float f12 = f2;
                                        f11 = f3;
                                        ua0.k(r6Var, (double) f4, (double) f5, (double) f2, (double) f3, d2, (double) zq0.d, d, zq0.f, zq0.g);
                                        f2 = f12;
                                        f4 = f2;
                                        f3 = f11;
                                        f5 = f3;
                                        jr02 = jr04;
                                    } else {
                                        amVar2 = amVar;
                                        i3 = size;
                                        f8 = f;
                                        i4 = i2;
                                        jr04 = jr03;
                                        if (jr04 instanceof qq0) {
                                            double d3 = (double) f4;
                                            double d4 = (double) f5;
                                            qq0 qq0 = (qq0) jr04;
                                            float f13 = qq0.i;
                                            float f14 = qq0.h;
                                            double d5 = (double) f14;
                                            float f15 = f14;
                                            double d6 = (double) f13;
                                            double d7 = (double) qq0.c;
                                            double d8 = (double) qq0.d;
                                            jr02 = jr04;
                                            float f16 = f13;
                                            double d9 = (double) qq0.e;
                                            boolean z = qq0.f;
                                            boolean z2 = qq0.g;
                                            float f17 = f16;
                                            boolean z3 = z;
                                            float f18 = f17;
                                            f11 = f15;
                                            ua0.k(r6Var, d3, d4, d5, d6, d7, d8, d9, z3, z2);
                                            f3 = f18;
                                            f5 = f3;
                                            f2 = f11;
                                            f4 = f2;
                                        } else {
                                            od.k();
                                            return;
                                        }
                                    }
                                    i3 = size;
                                    f8 = f;
                                    i4 = i2;
                                    jr02 = jr03;
                                    f2 = f10;
                                }
                                f5 = f10;
                                amVar2 = amVar;
                                f4 = f9;
                            }
                            f5 += f10;
                        }
                        amVar2 = amVar;
                    }
                    i3 = size;
                    f8 = f;
                    i4 = i2;
                }
                jr02 = jr03;
            }
            i2 = i4 + 1;
            List a912 = list;
            r6Var2 = r6Var;
            size = i3;
            amVar = amVar2;
            jr0 = jr02;
            f = f8;
        }
    }

    public static final void k(r6 r6Var, double d, double d2, double d3, double d4, double d5, double d6, double d7, boolean z, boolean z2) {
        double d8 = d;
        double d9 = d3;
        double d10 = d5;
        double d11 = (d7 / 180.0d) * 3.141592653589793d;
        double cos = Math.cos(d11);
        double sin = Math.sin(d11);
        double d12 = ((d2 * sin) + (d8 * cos)) / d10;
        double d13 = 3.141592653589793d;
        double d14 = ((d2 * cos) + ((-d8) * sin)) / d6;
        double d15 = ((d4 * sin) + (d9 * cos)) / d10;
        double d16 = ((d4 * cos) + ((-d9) * sin)) / d6;
        double d17 = d12 - d15;
        double d18 = d14 - d16;
        double d19 = (d12 + d15) / 2.0d;
        double d20 = (d14 + d16) / 2.0d;
        double d21 = (d18 * d18) + (d17 * d17);
        if (d21 != 0.0d) {
            double d22 = (1.0d / d21) - 0.25d;
            if (d22 < 0.0d) {
                d11 = (double) ((float) (Math.sqrt(d21) / 1.99999d));
                ua0.k(r6Var, d8, d2, d9, d4, d10 * d11, d6 * d11, d7, z, z2);
                return;
            }
            boolean z3 = z2;
            d8 = Math.sqrt(d22);
            d17 *= d8;
            d8 *= d18;
            if (z == z3) {
                d19 -= d8;
                d20 += d17;
            } else {
                d19 += d8;
                d20 -= d17;
            }
            d8 = Math.atan2(d14 - d20, d12 - d19);
            d9 = Math.atan2(d16 - d20, d15 - d19) - d8;
            int i = (d9 > 0.0d ? 1 : (d9 == 0.0d ? 0 : -1));
            if (z3 != (i >= 0)) {
                d9 = i > 0 ? d9 - 6.283185307179586d : d9 + 6.283185307179586d;
            }
            d19 *= d10;
            d20 *= d6;
            d17 = (d19 * cos) - (d20 * sin);
            d20 = (d20 * cos) + (d19 * sin);
            int ceil = (int) Math.ceil(Math.abs((d9 * 4.0d) / d13));
            sin = Math.cos(d11);
            d11 = Math.sin(d11);
            d13 = Math.cos(d8);
            d12 = Math.sin(d8);
            double d23 = 4.0d;
            cos = -d10;
            d14 = cos * sin;
            d16 = d6 * d11;
            d15 = (d14 * d12) - (d16 * d13);
            cos *= d11;
            d18 = d6 * sin;
            d13 = (d13 * d18) + (d12 * cos);
            d9 /= (double) ceil;
            d12 = d8;
            d19 = d15;
            int i2 = 0;
            d15 = d13;
            d13 = d2;
            while (i2 < ceil) {
                double d24 = d12 + d9;
                d21 = Math.sin(d24);
                d22 = Math.cos(d24);
                int i3 = ceil;
                int i4 = i2;
                double d25 = (((d10 * sin) * d22) + d17) - (d16 * d21);
                int i5 = i3;
                double d26 = (d18 * d21) + (((d10 * d11) * d22) + d20);
                double d27 = (d14 * d21) - (d16 * d22);
                d21 = (d22 * d18) + (d21 * cos);
                d12 = d24 - d12;
                d22 = Math.tan(d12 / 2.0d);
                d22 = ((Math.sqrt(((d22 * 3.0d) * d22) + d23) - 1.0d) * Math.sin(d12)) / 3.0d;
                d6 = d9;
                d7 = d11;
                double d28 = (d15 * d22) + d13;
                double d29 = d17;
                d13 = cos;
                r6Var.a.cubicTo((float) ((d19 * d22) + d), (float) d28, (float) (d25 - (d22 * d27)), (float) (d26 - (d22 * d21)), (float) d25, (float) d26);
                d9 = d6;
                d11 = d7;
                d17 = d29;
                d = d25;
                i2 = i4 + 1;
                cos = d13;
                d12 = d24;
                d15 = d21;
                d19 = d27;
                ceil = i5;
                d13 = d26;
                d10 = d5;
            }
        }
    }

    public static final boolean w(int i, n7 n7Var, ry ryVar, gw0 gw0) {
        qk0 qk0 = new qk0(new ry[16]);
        if (!ryVar.e.r) {
            a5.b("visitChildren called on an unattached node");
        }
        qk0 qk02 = new qk0(new li0[16]);
        li0 li0 = ryVar.e;
        li0 li02 = li0.j;
        if (li02 == null) {
            k70.i(qk02, li0);
        } else {
            qk02.b(li02);
        }
        while (true) {
            int i2 = qk02.g;
            if (i2 == 0) {
                break;
            }
            li0 = (li0) qk02.k(i2 - 1);
            if ((li0.h & 1024) == 0) {
                k70.i(qk02, li0);
            } else {
                Object obj;
                while (obj != null) {
                    if ((obj.g & 1024) != 0) {
                        hb0 hb0 = null;
                        while (li0 != null) {
                            if (li0 instanceof ry) {
                                ryVar = (ry) li0;
                                if (ryVar.r) {
                                    qk0.b(ryVar);
                                }
                            } else if ((li0.g & 1024) != 0 && (li0 instanceof dp)) {
                                int i3 = 0;
                                for (li0 li03 = ((dp) li0).t; li03 != null; li03 = li03.j) {
                                    if ((li03.g & 1024) != 0) {
                                        i3++;
                                        if (i3 == 1) {
                                            li0 = li03;
                                        } else {
                                            if (hb0 == null) {
                                                hb0 = new qk0(new li0[16]);
                                            }
                                            if (obj != null) {
                                                r6.b(obj);
                                                obj = null;
                                            }
                                            r6.b(li03);
                                        }
                                    }
                                }
                                if (i3 == 1) {
                                }
                            }
                            obj = k70.m(hb0);
                        }
                    } else {
                        li0 = obj.j;
                    }
                }
            }
        }
        while (qk0.g != 0) {
            ryVar = ua0.l(qk0, gw0, i);
            if (ryVar == null) {
                break;
            } else if (ryVar.t0().a) {
                return ((Boolean) n7Var.i(ryVar)).booleanValue();
            } else {
                if (ua0.n(i, n7Var, ryVar, gw0)) {
                    return true;
                }
                qk0.j(ryVar);
            }
        }
        return false;
    }

    public static final void b(Boolean bool, Object obj, sd0 sd0, i00 i00, d10 d10, int i) {
        int i2;
        d10.X(696924721);
        if ((i & 6) == 0) {
            i2 = (((AutofillValue) d10) != null ? 4 : 2) | i;
        } else {
            i2 = i;
        }
        if ((i & 48) == 0) {
            i2 |= ((AutofillValue) d10) != null ? 32 : 16;
        }
        if ((i & 384) == 0) {
            i2 |= 128;
        }
        if ((i & 3072) == 0) {
            i2 |= ((AutofillValue) d10) != null ? 2048 : 1024;
        }
        if (d10.O(i2 & 1, (i2 & 1171) != 1170)) {
            int f;
            Object L;
            d10.T();
            if ((i & 1) != 0) {
                if (!d10.y()) {
                    d10.R();
                    i2 &= -897;
                    d10.q();
                    f = (((AutofillManager$AutofillCallback) d10) | ((AutofillManager$AutofillCallback) d10)) | ((AutofillManager$AutofillCallback) d10);
                    L = d10.L();
                    if (f != 0 || L == oj.a) {
                        L = new yd0(sd0.g());
                        d10.g0(L);
                    }
                    ua0.c(sd0, (yd0) L, i00, d10, (i2 >> 3) & 896);
                }
            }
            sd0 = (sd0) d10.j(bf0.a);
            i2 &= -897;
            d10.q();
            f = (((AutofillManager$AutofillCallback) d10) | ((AutofillManager$AutofillCallback) d10)) | ((AutofillManager$AutofillCallback) d10);
            L = d10.L();
            L = new yd0(sd0.g());
            d10.g0(L);
            ua0.c(sd0, (yd0) L, i00, d10, (i2 >> 3) & 896);
        } else {
            d10.R();
        }
        Object obj2 = sd0;
        xv0 r = d10.r();
        if (r != null) {
            r.d = new z2(bool, obj, obj2, i00, i, 1);
        }
    }

    public static final Boolean y(int i, n7 n7Var, ry ryVar, gw0 gw0) {
        int ordinal = ryVar.w0().ordinal();
        if (ordinal != 0) {
            if (ordinal == 1) {
                ry q = vd1.q(ryVar);
                String str = "ActiveParent must have a focusedChild";
                if (q != null) {
                    int ordinal2 = q.w0().ordinal();
                    if (ordinal2 != 0) {
                        if (ordinal2 == 1) {
                            Boolean y = ua0.y(i, n7Var, q, gw0);
                            if (!k70.p(y, Boolean.FALSE)) {
                                return y;
                            }
                            if (gw0 == null) {
                                if (q.w0() == my.f) {
                                    ry m = vd1.m(q);
                                    if (m != null) {
                                        gw0 = vd1.p(m);
                                    } else {
                                        od.p(str);
                                        return null;
                                    }
                                }
                                od.p("Searching for active node in inactive hierarchy");
                                return null;
                            }
                            return Boolean.valueOf(ua0.n(i, n7Var, ryVar, gw0));
                        } else if (ordinal2 != 2) {
                            if (ordinal2 != 3) {
                                od.k();
                                return null;
                            }
                            od.p(str);
                            return null;
                        }
                    }
                    if (gw0 == null) {
                        gw0 = vd1.p(q);
                    }
                    return Boolean.valueOf(ua0.n(i, n7Var, ryVar, gw0));
                }
                od.p(str);
                return null;
            } else if (ordinal != 2) {
                if (ordinal != 3) {
                    od.k();
                    return null;
                } else if (ryVar.t0().a) {
                    return (Boolean) n7Var.i(ryVar);
                } else {
                    return gw0 == null ? Boolean.valueOf(ua0.m(ryVar, i, n7Var)) : Boolean.valueOf(ua0.w(i, n7Var, ryVar, gw0));
                }
            }
        }
        return Boolean.valueOf(ua0.m(ryVar, i, n7Var));
    }

    public static final void j(ry ryVar, qk0 qk0) {
        if (!ryVar.e.r) {
            a5.b("visitChildren called on an unattached node");
        }
        qk0 qk02 = new qk0(new li0[16]);
        li0 li0 = ryVar.e;
        li0 li02 = li0.j;
        if (li02 == null) {
            k70.i(qk02, li0);
        } else {
            qk02.b(li02);
        }
        while (true) {
            int i = qk02.g;
            if (i != 0) {
                li0 = (li0) qk02.k(i - 1);
                if ((li0.h & 1024) == 0) {
                    k70.i(qk02, li0);
                } else {
                    Object obj;
                    while (obj != null) {
                        if ((obj.g & 1024) != 0) {
                            hb0 hb0 = null;
                            while (li0 != null) {
                                if (li0 instanceof ry) {
                                    ryVar = (ry) li0;
                                    if (ryVar.r) {
                                        if (!k70.O(ryVar).U) {
                                            if (ryVar.t0().a) {
                                                qk0.b(ryVar);
                                            } else {
                                                ua0.j(ryVar, qk0);
                                            }
                                        }
                                    }
                                } else if ((li0.g & 1024) != 0 && (li0 instanceof dp)) {
                                    int i2 = 0;
                                    for (li0 li03 = ((dp) li0).t; li03 != null; li03 = li03.j) {
                                        if ((li03.g & 1024) != 0) {
                                            i2++;
                                            if (i2 == 1) {
                                                li0 = li03;
                                            } else {
                                                if (hb0 == null) {
                                                    hb0 = new qk0(new li0[16]);
                                                }
                                                if (obj != null) {
                                                    r3.b(obj);
                                                    obj = null;
                                                }
                                                r3.b(li03);
                                            }
                                        }
                                    }
                                    if (i2 == 1) {
                                    }
                                }
                                obj = k70.m(hb0);
                            }
                        } else {
                            li0 = obj.j;
                        }
                    }
                }
            } else {
                return;
            }
        }
    }

    /* JADX WARNING: Missing block: B:20:0x0048, code:
            if (r8 <= r5) goto L_0x004a;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final boolean g(gw0 gw0, gw0 gw02, gw0 gw03, int i) {
        gw0 gw04 = gw0;
        gw0 gw05 = gw02;
        gw0 gw06 = gw03;
        int i2 = i;
        boolean h = ua0.h(i2, gw06, gw04);
        float f = gw06.b;
        float f2 = gw06.d;
        float f3 = gw06.a;
        float f4 = gw06.c;
        float f5 = gw04.d;
        float f6 = gw04.b;
        float f7 = gw04.c;
        float f8 = gw04.a;
        if (!h) {
            if (ua0.h(i2, gw05, gw04)) {
                String str = "This function should only be used for 2-D focus search";
                if (i2 == 3) {
                    if (f8 >= f4) {
                    }
                    return true;
                } else if (i2 == 4) {
                    if (f7 <= f3) {
                    }
                    return true;
                } else if (i2 == 5) {
                    if (f6 >= f2) {
                    }
                    return true;
                } else if (i2 != 6) {
                    od.p(str);
                }
                if (i2 != 3) {
                    if (i2 != 4) {
                        float f9;
                        if (i2 == 3) {
                            f9 = f8 - gw05.c;
                        } else if (i2 == 4) {
                            f9 = gw05.a - f7;
                        } else if (i2 == 5) {
                            f9 = f6 - gw05.d;
                        } else if (i2 == 6) {
                            f9 = gw05.b - f5;
                        } else {
                            od.p(str);
                            return false;
                        }
                        if (f9 < 0.0f) {
                            f9 = 0.0f;
                        }
                        if (i2 == 3) {
                            f8 -= f3;
                        } else if (i2 == 4) {
                            f8 = f4 - f7;
                        } else if (i2 == 5) {
                            f8 = f6 - f;
                        } else if (i2 == 6) {
                            f8 = f2 - f5;
                        } else {
                            od.p(str);
                            return false;
                        }
                        if (f8 < 1.0f) {
                            f8 = 1.0f;
                        }
                        return f9 < f8;
                    }
                }
                return true;
            }
        }
        return false;
    }

    public static final void c(sd0 sd0, yd0 yd0, i00 i00, d10 d10, int i) {
        int i2;
        d10.X(228371534);
        if ((i & 6) == 0) {
            i2 = (((AutofillValue) d10) != null ? 4 : 2) | i;
        } else {
            i2 = i;
        }
        if ((i & 48) == 0) {
            i2 |= ((AutofillValue) d10) != null ? 32 : 16;
        }
        if ((i & 384) == 0) {
            i2 |= ((AutofillValue) d10) != null ? 256 : 128;
        }
        int i3 = 0;
        if (d10.O(i2 & 1, (i2 & 147) != 146)) {
            AutofillValue h = ((AutofillValue) d10);
            if ((i2 & 896) == 256) {
                i3 = 1;
            }
            i2 = (h | i3) | ((AutofillValue) d10);
            Object L = d10.L();
            if (i2 != 0 || L == oj.a) {
                L = new z7((Object) sd0, (Object) yd0, (Object) i00, 3);
                d10.g0(L);
            }
            j70.c(sd0, yd0, (i00) L, d10);
        } else {
            d10.R();
        }
        xv0 r = d10.r();
        if (r != null) {
            r.d = new nc((Object) sd0, (Object) yd0, (u00) i00, i, 4);
        }
    }

    public static final boolean u(float[] fArr) {
        return fArr.length >= 16 && fArr[0] == 1.0f && fArr[1] == 0.0f && fArr[2] == 0.0f && fArr[3] == 0.0f && fArr[4] == 0.0f && fArr[5] == 1.0f && fArr[6] == 0.0f && fArr[7] == 0.0f && fArr[8] == 0.0f && fArr[9] == 0.0f && fArr[10] == 1.0f && fArr[11] == 0.0f && fArr[12] == 0.0f && fArr[13] == 0.0f && fArr[14] == 0.0f && fArr[15] == 1.0f;
    }

    /* JADX WARNING: Removed duplicated region for block: B:25:0x005c  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final boolean m(ry ryVar, int i, i00 i00) {
        qk0 qk0 = new qk0(new ry[16]);
        ua0.j(ryVar, qk0);
        int i2 = qk0.g;
        if (i2 <= 1) {
            ryVar = (ry) (i2 == 0 ? null : qk0.e[0]);
            if (ryVar != null) {
                return ((Boolean) i00.i(ryVar)).booleanValue();
            }
        }
        gw0 p;
        float f;
        float f2;
        gw0 gw0;
        if (i == 7) {
            i = 4;
        }
        if (i != 4) {
            if (i != 6) {
                if (i != 3) {
                    if (i != 5) {
                        od.p("This function should only be used for 2-D focus search");
                        return false;
                    }
                }
                p = vd1.p(ryVar);
                f = p.c;
                f2 = p.d;
                gw0 = new gw0(f, f2, f, f2);
                ryVar = ua0.l(qk0, gw0, i);
                if (ryVar != null) {
                    return ((Boolean) i00.i(ryVar)).booleanValue();
                }
            }
        }
        p = vd1.p(ryVar);
        f = p.a;
        f2 = p.b;
        gw0 = new gw0(f, f2, f, f2);
        ryVar = ua0.l(qk0, gw0, i);
        if (ryVar != null) {
        }
        return false;
    }

    public static final boolean s(int i, gw0 gw0, gw0 gw02) {
        float f;
        float f2;
        float f3;
        if (i == 3) {
            f = gw02.c;
            f2 = gw02.a;
            f3 = gw0.c;
            return (f > f3 || f2 >= f3) && f2 > gw0.a;
        } else if (i == 4) {
            f = gw02.a;
            f2 = gw02.c;
            f3 = gw0.a;
            return (f < f3 || f2 <= f3) && f2 < gw0.c;
        } else if (i == 5) {
            f = gw02.d;
            f2 = gw02.b;
            f3 = gw0.d;
            return (f > f3 || f2 >= f3) && f2 > gw0.b;
        } else if (i == 6) {
            f = gw02.b;
            f2 = gw02.d;
            f3 = gw0.b;
            return (f < f3 || f2 <= f3) && f2 < gw0.d;
        } else {
            od.p("This function should only be used for 2-D focus search");
            return false;
        }
    }

    public static final ry l(qk0 qk0, gw0 gw0, int i) {
        gw0 d;
        ry ryVar = null;
        if (i == 3) {
            d = gw0.d((gw0.c - gw0.a) + 1.0f, 0.0f);
        } else if (i == 4) {
            d = gw0.d(-((gw0.c - gw0.a) + 1.0f), 0.0f);
        } else if (i == 5) {
            d = gw0.d(0.0f, (gw0.d - gw0.b) + 1.0f);
        } else if (i == 6) {
            d = gw0.d(0.0f, -((gw0.d - gw0.b) + 1.0f));
        } else {
            od.p("This function should only be used for 2-D focus search");
            return null;
        }
        Object[] objArr = qk0.e;
        int i2 = qk0.g;
        for (int i3 = 0; i3 < i2; i3++) {
            ry ryVar2 = (ry) objArr[i3];
            if (vd1.v(ryVar2)) {
                gw0 p = vd1.p(ryVar2);
                if (ua0.r(p, d, gw0, i)) {
                    ryVar = ryVar2;
                    d = p;
                }
            }
        }
        return ryVar;
    }

    public static final long t(int i, gw0 gw0, gw0 gw02) {
        float f;
        float f2;
        float f3;
        float f4;
        float f5;
        long j;
        String str = "This function should only be used for 2-D focus search";
        if (i == 3) {
            f = gw0.a;
            f2 = gw02.c;
        } else if (i == 4) {
            f = gw02.a;
            f2 = gw0.c;
        } else if (i == 5) {
            f = gw0.b;
            f2 = gw02.d;
        } else if (i == 6) {
            f = gw02.b;
            f2 = gw0.d;
        } else {
            od.p(str);
            return 0;
        }
        f -= f2;
        if (f < 0.0f) {
            f = 0.0f;
        }
        long j2 = (long) f;
        if (i != 3) {
            if (i != 4) {
                if (i != 5) {
                    if (i != 6) {
                        od.p(str);
                        return 0;
                    }
                }
                f3 = gw0.a;
                f4 = ((gw0.c - f3) / 2.0f) + f3;
                f3 = gw02.a;
                f5 = gw02.c;
                j = (long) (f4 - (((f5 - f3) / 2.0f) + f3));
                return (j * j) + ((13 * j2) * j2);
            }
        }
        f3 = gw0.b;
        f4 = ((gw0.d - f3) / 2.0f) + f3;
        f3 = gw02.b;
        f5 = gw02.d;
        j = (long) (f4 - (((f5 - f3) / 2.0f) + f3));
        return (j * j) + ((13 * j2) * j2);
    }

    public static int p(int i) {
        if (i == 1) {
            return 0;
        }
        if (i == 2) {
            return 1;
        }
        if (i == 4) {
            return 2;
        }
        if (i == 8) {
            return 3;
        }
        if (i == 16) {
            return 4;
        }
        if (i == 32) {
            return 5;
        }
        if (i == 64) {
            return 6;
        }
        if (i == 128) {
            return 7;
        }
        if (i == 256) {
            return 8;
        }
        if (i == 512) {
            return 9;
        }
        od.m(fu0.E("type needs to be >= FIRST and <= LAST, type=", i));
        return 0;
    }

    public static final boolean h(int i, gw0 gw0, gw0 gw02) {
        if (i != 3) {
            if (i != 4) {
                if (i != 5) {
                    if (i != 6) {
                        od.p("This function should only be used for 2-D focus search");
                        return false;
                    }
                }
                return gw0.c > gw02.a && gw0.a < gw02.c;
            }
        }
        return gw0.d > gw02.b && gw0.b < gw02.d;
    }

    public static final gw0 d(long j, long j2) {
        int i = (int) (j >> 32);
        int i2 = (int) (j & 4294967295L);
        return new gw0(Float.intBitsToFloat(i), Float.intBitsToFloat(i2), Float.intBitsToFloat((int) (j2 >> 32)) + Float.intBitsToFloat(i), Float.intBitsToFloat((int) (j2 & 4294967295L)) + Float.intBitsToFloat(i2));
    }

    public static final boolean n(int i, n7 n7Var, ry ryVar, gw0 gw0) {
        if (ua0.w(i, n7Var, ryVar, gw0)) {
            return true;
        }
        int i2 = i;
        ry ryVar2 = ryVar;
        Boolean bool = (Boolean) a5.N(ryVar2, i2, new on0(((hy) ((n4) k70.P(ryVar)).getFocusOwner()).f(), ryVar2, gw0, i2, n7Var, 1));
        return bool != null ? bool.booleanValue() : false;
    }

    public static final void a(mi0 mi0, sc0 sc0, up0 up0, p9 p9Var, mb mbVar, jo joVar, boolean z, x5 x5Var, i00 i00, d10 d10, int i) {
        mb mbVar2;
        mi0 mi02;
        jo joVar2;
        boolean z2;
        x5 x5Var2;
        sc0 sc02;
        d10 d102 = d10;
        d102.X(-1884325601);
        i00 i002 = i00;
        int i2 = (i | 46861334) | (((AutofillValue) d102) != null ? 536870912 : 268435456);
        boolean z3 = true;
        if (d102.O(i2 & 1, (306783379 & i2) != 306783378)) {
            sc0 sc03;
            jo joVar3;
            x5 x5Var3;
            int i3;
            mi0 mi03;
            x5 x5Var4;
            d102.T();
            if ((i & 1) != 0) {
                if (!d102.y()) {
                    d102.R();
                    sc03 = sc0;
                    mbVar2 = mbVar;
                    joVar3 = joVar;
                    z3 = z;
                    x5Var3 = x5Var;
                    i3 = i2 & -238551153;
                    mi03 = mi0;
                    d102.q();
                    mc0.a(mi03, sc03, up0, joVar3, z3, x5Var3, mbVar2, p9Var, i002, d102, 1600902, 432 | ((i3 >> 18) & 7168));
                    mi02 = mi03;
                    joVar2 = joVar3;
                    z2 = z3;
                    x5Var2 = x5Var3;
                    sc02 = sc03;
                }
            }
            nc0 nc0 = uc0.a;
            Object[] objArr = new Object[0];
            al alVar = sc0.x;
            int d = d102.d(0) | d102.d(0);
            Object L = d102.L();
            nq0 nq0 = oj.a;
            if (d != 0 || L == nq0) {
                L = new h90(17);
                d102.g0(L);
            }
            sc03 = (sc0) kb0.x(objArr, alVar, (xz) L, d102, 0);
            mb mbVar3 = e3.o;
            float f = n71.a;
            jp jpVar = (jp) d102.j(fk.h);
            boolean c = d102.c(jpVar.a());
            Object L2 = d102.L();
            if (c || L2 == nq0) {
                L2 = new xn(new cz0(jpVar));
                d102.g0(L2);
            }
            xn xnVar = (xn) L2;
            AutofillManager$AutofillCallback f2 = ((AutofillManager$AutofillCallback) d102);
            L = d102.L();
            if (f2 != null || L == nq0) {
                L = new jo(xnVar);
                d102.g0(L);
            }
            jo joVar4 = (jo) L;
            gk gkVar = jp0.a;
            d102.W(282942128);
            y5 y5Var = (y5) d102.j(jp0.a);
            if (y5Var == null) {
                d102.p(false);
                x5Var4 = null;
            } else {
                AutofillManager$AutofillCallback f3 = ((AutofillManager$AutofillCallback) d102);
                Object L3 = d102.L();
                if (f3 != null || L3 == nq0) {
                    x5 x5Var5 = new x5(y5Var.a, y5Var.b, y5Var.c, y5Var.d);
                    d102.g0(x5Var5);
                    L3 = x5Var5;
                }
                x5Var4 = (x5) L3;
                d102.p(false);
            }
            i3 = i2 & -238551153;
            mi03 = ji0.a;
            joVar3 = joVar4;
            mbVar2 = mbVar3;
            x5Var3 = x5Var4;
            d102.q();
            mc0.a(mi03, sc03, up0, joVar3, z3, x5Var3, mbVar2, p9Var, i002, d102, 1600902, 432 | ((i3 >> 18) & 7168));
            mi02 = mi03;
            joVar2 = joVar3;
            z2 = z3;
            x5Var2 = x5Var3;
            sc02 = sc03;
        } else {
            d10.R();
            mi02 = mi0;
            sc02 = sc0;
            mbVar2 = mbVar;
            joVar2 = joVar;
            z2 = z;
            x5Var2 = x5Var;
        }
        xv0 r = d10.r();
        if (r != null) {
            r.d = new b2(mi02, sc02, up0, p9Var, mbVar2, joVar2, z2, x5Var2, i00, i);
        }
    }

    /* JADX WARNING: Missing block: B:13:0x0026, code:
            if (defpackage.ua0.t(r5, r4, r2) < defpackage.ua0.t(r5, r4, r3)) goto L_0x0028;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final boolean r(gw0 gw0, gw0 gw02, gw0 gw03, int i) {
        if (ua0.s(i, gw0, gw03)) {
            if (ua0.s(i, gw02, gw03)) {
                if (!ua0.g(gw03, gw0, gw02, i)) {
                    if (ua0.g(gw03, gw02, gw0, i)) {
                    }
                }
            }
            return true;
        }
        return false;
    }

    public static final float f(js0 js0, boolean z, j30[] j30Arr, float f) {
        float f2 = Float.NaN;
        for (j30 d : j30Arr) {
            float d2 = js0.d(d);
            if (!Float.isNaN(f2)) {
                if (z != (d2 > f2)) {
                }
            }
            f2 = d2;
        }
        return Float.isNaN(f2) ? f : f2;
    }

    public static final sd0 o(View view) {
        view.getClass();
        while (view != null) {
            Object tag = view.getTag(2131034229);
            sd0 sd0 = tag instanceof sd0 ? (sd0) tag : null;
            if (sd0 != null) {
                return sd0;
            }
            kh1 j = jb0.j(view);
            view = j instanceof View ? (View) j : null;
        }
        return null;
    }

    public static final String v(BufferedReader bufferedReader) {
        StringWriter stringWriter = new StringWriter();
        char[] cArr = new char[8192];
        int read = bufferedReader.read(cArr);
        while (read >= 0) {
            stringWriter.write(cArr, 0, read);
            read = bufferedReader.read(cArr);
        }
        String stringWriter2 = stringWriter.toString();
        stringWriter2.getClass();
        return stringWriter2;
    }

    public static void i(Object obj, String str) {
        if (obj == null) {
            throw new dl1(str);
        }
    }

    public static l91 e() {
        return new c80(null);
    }

    public static final int q(int i, int i2) {
        return (i >> i2) & 31;
    }
}