package defpackage;

import java.util.concurrent.CancellationException;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: b80 */
public final class b80 extends CancellationException {
    public final transient h80 e;

    public final boolean equals(Object obj) {
        if (obj != this) {
            if (obj instanceof b80) {
                b80 b80 = (b80) obj;
                if (k70.p(b80.getMessage(), getMessage())) {
                    Object obj2 = b80.e;
                    if (obj2 == null) {
                        obj2 = mm0.f;
                    }
                    Object obj3 = this.e;
                    if (obj3 == null) {
                        obj3 = mm0.f;
                    }
                    if (k70.p(obj2, obj3) && k70.p(b80.getCause(), getCause())) {
                    }
                }
            }
            return false;
        }
        return true;
    }

    public final int hashCode() {
        String message = getMessage();
        message.getClass();
        int hashCode = message.hashCode() * 31;
        Object obj = this.e;
        if (obj == null) {
            obj = mm0.f;
        }
        int i = 0;
        hashCode = (hashCode + (obj != null ? obj.hashCode() : 0)) * 31;
        Throwable cause = getCause();
        if (cause != null) {
            i = cause.hashCode();
        }
        return hashCode + i;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(super.toString());
        stringBuilder.append("; job=");
        Object obj = this.e;
        if (obj == null) {
            obj = mm0.f;
        }
        stringBuilder.append(obj);
        return stringBuilder.toString();
    }

    public b80(String str, Throwable th, h80 h80) {
        super(str);
        this.e = h80;
        if (th != null) {
            initCause(th);
        }
    }

    public final Throwable fillInStackTrace() {
        setStackTrace(new StackTraceElement[0]);
        return this;
    }
}