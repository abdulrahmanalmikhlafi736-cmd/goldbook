package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ae0 */
public final class ae0 implements Runnable {
    public Runnable e;
    public final /* synthetic */ be0 f;

    public final void run() {
        int i = 0;
        while (true) {
            try {
                this.e.run();
            } catch (Throwable th) {
                be0 be0 = this.f;
                synchronized (be0.k) {
                    be0.l.decrementAndGet(be0);
                }
            }
            Runnable j = this.f.j();
            if (j != null) {
                this.e = j;
                i++;
                if (i >= 16) {
                    be0 be02 = this.f;
                    if (wl1.I(be02.h, be02)) {
                        be0 be03 = this.f;
                        wl1.H(be03.h, be03, this);
                        return;
                    }
                }
            } else {
                return;
            }
        }
    }

    public ae0(be0 be0, Runnable runnable) {
        this.f = be0;
        this.e = runnable;
    }
}