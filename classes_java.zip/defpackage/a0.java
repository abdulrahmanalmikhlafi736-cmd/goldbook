package defpackage;

import java.util.AbstractSet;
import java.util.Set;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: a0 */
public abstract class a0 extends AbstractSet implements Set, y80 {
    public final /* bridge */ int size() {
        return a();
    }

    public abstract int a();
}