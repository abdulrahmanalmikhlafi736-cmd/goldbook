package defpackage;

import android.view.autofill.AutofillManager;
import java.util.Iterator;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: d21 */
public final class d21 implements r21, Iterable, w80 {
    public final hk0 e = new hk0();
    public bh0 f;
    public boolean g;
    public boolean h;

    public final String toString() {
        String str;
        StringBuilder stringBuilder = new StringBuilder();
        String str2 = ", ";
        if (this.g) {
            stringBuilder.append("mergeDescendants=true");
            str = str2;
        } else {
            str = "";
        }
        if (this.h) {
            stringBuilder.append(str);
            stringBuilder.append("isClearingSemantics=true");
            str = str2;
        }
        hk0 hk0 = this.e;
        Object[] objArr = hk0.b;
        Object[] objArr2 = hk0.c;
        long[] jArr = hk0.a;
        int length = jArr.length - 2;
        if (length >= 0) {
            int i = 0;
            while (true) {
                long j = jArr[i];
                if (((((~j) << 7) & j) & -9187201950435737472L) != -9187201950435737472L) {
                    int i2 = 8 - ((~(i - length)) >>> 31);
                    for (int i3 = 0; i3 < i2; i3++) {
                        if ((255 & j) < 128) {
                            int i4 = (i << 3) + i3;
                            Object obj = objArr[i4];
                            Object obj2 = objArr2[i4];
                            q21 q21 = (q21) obj;
                            stringBuilder.append(str);
                            stringBuilder.append(q21.a);
                            stringBuilder.append(" : ");
                            stringBuilder.append(obj2);
                            str = str2;
                        }
                        j >>= 8;
                    }
                    if (i2 != 8) {
                        break;
                    }
                }
                if (i == length) {
                    break;
                }
                i++;
            }
        }
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(a61.S(this));
        stringBuilder2.append("{ ");
        stringBuilder2.append(stringBuilder);
        stringBuilder2.append(" }");
        return stringBuilder2.toString();
    }

    public final void e(d21 d21) {
        hk0 hk0 = d21.e;
        Object[] objArr = hk0.b;
        Object[] objArr2 = hk0.c;
        long[] jArr = hk0.a;
        int length = jArr.length - 2;
        if (length >= 0) {
            int i = 0;
            while (true) {
                long j = jArr[i];
                if (((((~j) << 7) & j) & -9187201950435737472L) != -9187201950435737472L) {
                    int i2 = 8 - ((~(i - length)) >>> 31);
                    for (int i3 = 0; i3 < i2; i3++) {
                        if ((255 & j) < 128) {
                            int i4 = (i << 3) + i3;
                            Object obj = objArr[i4];
                            Object obj2 = objArr2[i4];
                            q21 q21 = (q21) obj;
                            hk0 hk02 = this.e;
                            AutofillManager g = ((AutofillManager) hk02);
                            q21.getClass();
                            Object f = q21.b.f(g, obj2);
                            if (f != null) {
                                hk02.m(q21, f);
                            }
                        }
                        j >>= 8;
                    }
                    if (i2 != 8) {
                        return;
                    }
                }
                if (i != length) {
                    i++;
                } else {
                    return;
                }
            }
        }
    }

    public final d21 b() {
        d21 d21 = new d21();
        d21.g = this.g;
        d21.h = this.h;
        hk0 hk0 = d21.e;
        hk0.getClass();
        hk0 hk02 = this.e;
        hk02.getClass();
        Object[] objArr = hk02.b;
        Object[] objArr2 = hk02.c;
        long[] jArr = hk02.a;
        int length = jArr.length - 2;
        if (length >= 0) {
            int i = 0;
            while (true) {
                long j = jArr[i];
                if (((((~j) << 7) & j) & -9187201950435737472L) != -9187201950435737472L) {
                    int i2 = 8 - ((~(i - length)) >>> 31);
                    for (int i3 = 0; i3 < i2; i3++) {
                        if ((255 & j) < 128) {
                            int i4 = (i << 3) + i3;
                            hk0.m(objArr[i4], objArr2[i4]);
                        }
                        j >>= 8;
                    }
                    if (i2 != 8) {
                        break;
                    }
                }
                if (i == length) {
                    break;
                }
                i++;
            }
        }
        return d21;
    }

    public final void a(q21 q21, Object obj) {
        boolean z = obj instanceof o0;
        hk0 hk0 = this.e;
        if (!z || hk0.c(q21) == null) {
            hk0.m(q21, obj);
        } else {
            AutofillManager g = ((AutofillManager) hk0);
            g.getClass();
            o0 o0Var = (o0) g;
            o0 o0Var2 = (o0) obj;
            String str = o0Var2.a;
            if (str == null) {
                str = o0Var.a;
            }
            u00 u00 = o0Var2.b;
            if (u00 == null) {
                u00 = o0Var.b;
            }
            hk0.m(q21, new o0(str, u00));
        }
        q21.getClass();
    }

    /* JADX WARNING: Missing block: B:12:0x0020, code:
            if (r2.h != r3.h) goto L_0x0022;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean equals(Object obj) {
        if (this != obj) {
            if (obj instanceof d21) {
                d21 d21 = (d21) obj;
                if (k70.p(this.e, d21.e)) {
                    if (this.g != d21.g) {
                    }
                }
            }
            return false;
        }
        return true;
    }

    public final Object c(q21 q21) {
        AutofillManager g = ((AutofillManager) this.e);
        if (g != null) {
            return g;
        }
        StringBuilder dl1 = new dl1("Key not present: ");
        dl1.append(q21);
        dl1.append(" - consider getOrElse or getOrNull");
        throw new dl1(dl1.toString());
    }

    public final int hashCode() {
        int i = 1237;
        int hashCode = ((this.e.hashCode() * 31) + (this.g ? 1231 : 1237)) * 31;
        if (this.h) {
            i = 1231;
        }
        return hashCode + i;
    }

    public final Iterator iterator() {
        bh0 bh0 = this.f;
        if (bh0 == null) {
            hk0 hk0 = this.e;
            hk0.getClass();
            bh0 bh02 = new bh0(hk0);
            this.f = bh02;
            bh0 = bh02;
        }
        return ((lu) bh0.entrySet()).iterator();
    }

    public d21() {
        long[] jArr = n01.a;
    }
}