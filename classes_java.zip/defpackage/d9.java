package defpackage;

import android.graphics.Insets;
import android.view.Window;
import android.view.WindowInsets.Type;
import android.view.WindowManager.LayoutParams;
import android.view.WindowMetrics;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: d9 */
public final class d9 {
    public static final d9 a = new Object();

    public final int a(Window window) {
        WindowMetrics currentWindowMetrics = window.getWindowManager().getCurrentWindowMetrics();
        Insets insets = currentWindowMetrics.getWindowInsets().getInsets(Type.systemBars());
        return currentWindowMetrics.getBounds().height() - (insets.top + insets.bottom);
    }

    public final void b(LayoutParams layoutParams, int i) {
        layoutParams.setFitInsetsSides(i);
    }

    public final void c(LayoutParams layoutParams, int i) {
        layoutParams.setFitInsetsTypes(i);
    }
}