package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ae */
public final class ae extends li0 implements vm0, nd, ds {
    public final be s;
    public boolean t;
    public final l u;

    public final void C(da0 da0) {
        boolean z = this.t;
        be beVar = this.s;
        if (!z) {
            beVar.f = null;
            sb0.r(this, new al(3, this, beVar));
            if (beVar.f != null) {
                this.t = true;
            } else {
                throw fu0.C("DrawResult not defined, did you forget to call onDraw?");
            }
        }
        pg0 pg0 = beVar.f;
        pg0.getClass();
        ((i00) pg0.f).i(da0);
    }

    public final long b() {
        return wl1.M(k70.M(this, 4).g);
    }

    public final void r0() {
        this.t = false;
        this.s.f = null;
        a5.x(this);
    }

    public ae(be beVar, l lVar) {
        this.s = beVar;
        this.u = lVar;
    }

    public final jp a() {
        return k70.O(this).C;
    }

    public final o90 getLayoutDirection() {
        return k70.O(this).D;
    }

    public final void Z() {
        r0();
    }

    public final void i0() {
        r0();
    }

    public final void k0() {
        r0();
    }

    public final void l0() {
        r0();
    }

    public final void z() {
        r0();
    }

    public final void j0() {
    }
}