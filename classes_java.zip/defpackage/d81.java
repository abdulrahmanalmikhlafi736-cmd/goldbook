package defpackage;

import android.view.autofill.AutofillValue;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: d81 */
public final class d81 extends m0 implements tw, x00, b81, uw {
    public static final /* synthetic */ AtomicReferenceFieldUpdater j = AtomicReferenceFieldUpdater.newUpdater(d81.class, Object.class, "_state$volatile");
    private volatile /* synthetic */ Object _state$volatile;
    public int i;

    /* JADX WARNING: Removed duplicated region for block: B:32:0x0082  */
    /* JADX WARNING: Removed duplicated region for block: B:43:0x009c  */
    /* JADX WARNING: Removed duplicated region for block: B:42:0x009a  */
    /* JADX WARNING: Removed duplicated region for block: B:47:0x00b0  */
    /* JADX WARNING: Removed duplicated region for block: B:51:0x00c1  */
    /* JADX WARNING: Removed duplicated region for block: B:50:0x00c0  */
    /* JADX WARNING: Removed duplicated region for block: B:32:0x0082  */
    /* JADX WARNING: Removed duplicated region for block: B:42:0x009a  */
    /* JADX WARNING: Removed duplicated region for block: B:43:0x009c  */
    /* JADX WARNING: Removed duplicated region for block: B:46:0x00af  */
    /* JADX WARNING: Removed duplicated region for block: B:47:0x00b0  */
    /* JADX WARNING: Removed duplicated region for block: B:32:0x0082  */
    /* JADX WARNING: Removed duplicated region for block: B:43:0x009c  */
    /* JADX WARNING: Removed duplicated region for block: B:42:0x009a  */
    /* JADX WARNING: Removed duplicated region for block: B:47:0x00b0  */
    /* JADX WARNING: Removed duplicated region for block: B:25:0x005f  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0024  */
    /* JADX WARNING: Removed duplicated region for block: B:32:0x0082  */
    /* JADX WARNING: Removed duplicated region for block: B:42:0x009a  */
    /* JADX WARNING: Removed duplicated region for block: B:43:0x009c  */
    /* JADX WARNING: Removed duplicated region for block: B:46:0x00af  */
    /* JADX WARNING: Removed duplicated region for block: B:47:0x00b0  */
    /* JADX WARNING: Missing block: B:57:0x00ea, code:
            ((android.view.autofill.AutofillValue) r10);
     */
    /* JADX WARNING: Missing block: B:61:0x00f4, code:
            if (r15 == r2) goto L_0x00f6;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final Object b(uw uwVar, ml mlVar) {
        c81 c81;
        int i;
        Object obj;
        Object obj2;
        e81 e81;
        n0 n0Var;
        m0 m0Var;
        Throwable th;
        a40 a40;
        a80 a80;
        uw uwVar2;
        d81 d81;
        mt andSet;
        Object obj3;
        sl slVar;
        if (mlVar instanceof c81) {
            c81 = (c81) mlVar;
            i = c81.o;
            if ((i & Integer.MIN_VALUE) != 0) {
                c81.o = i - Integer.MIN_VALUE;
                obj = c81.m;
                i = c81.o;
                obj2 = cm.e;
                AtomicReference atomicReference;
                mt mtVar;
                if (i != 0) {
                    nb0.t(obj);
                    e81 = (e81) a();
                } else if (i == 1) {
                    n0Var = c81.j;
                    uwVar = c81.i;
                    this = c81.h;
                    try {
                        nb0.t(obj);
                    } catch (Throwable th2) {
                        m0Var = this;
                        th = th2;
                    }
                } else if (i == 2) {
                    a40 = c81.l;
                    a80 = c81.k;
                    e81 = c81.j;
                    uwVar2 = c81.i;
                    d81 = c81.h;
                    nb0.t(obj);
                    atomicReference = e81.a;
                    mtVar = ac.B;
                    andSet = atomicReference.getAndSet(mtVar);
                    andSet.getClass();
                    if (andSet == ac.C) {
                    }
                    andSet = j.get(d81);
                    if (a80 != null) {
                    }
                    if (andSet == wl1.k) {
                    }
                    c81.h = d81;
                    c81.i = uwVar2;
                    c81.j = e81;
                    c81.k = a80;
                    c81.l = andSet;
                    c81.o = 2;
                    if (uwVar2.k(obj3, c81) != obj2) {
                    }
                    return obj2;
                } else if (i == 3) {
                    a40 = c81.l;
                    a80 = c81.k;
                    n0Var = c81.j;
                    uwVar2 = c81.i;
                    m0Var = c81.h;
                    try {
                        nb0.t(obj);
                        andSet = j.get(d81);
                        if (a80 != null) {
                            if (a80.b()) {
                            }
                            throw a80.o();
                        }
                        if (a40 == null || !a40.equals(andSet)) {
                            obj3 = andSet == wl1.k ? null : andSet;
                            c81.h = d81;
                            c81.i = uwVar2;
                            c81.j = e81;
                            c81.k = a80;
                            c81.l = andSet;
                            c81.o = 2;
                            if (uwVar2.k(obj3, c81) != obj2) {
                                a40 = andSet;
                            }
                            return obj2;
                        }
                        atomicReference = e81.a;
                        mtVar = ac.B;
                        andSet = atomicReference.getAndSet(mtVar);
                        andSet.getClass();
                        if (andSet == ac.C) {
                            c81.h = d81;
                            c81.i = uwVar2;
                            c81.j = e81;
                            c81.k = a80;
                            c81.l = a40;
                            c81.o = 3;
                            we1 we1 = we1.a;
                            ne neVar = new ne(1, ac.x(c81));
                            neVar.t();
                            AtomicReference atomicReference2 = e81.a;
                            while (!atomicReference2.compareAndSet(mtVar, neVar)) {
                                if (atomicReference2.get() != mtVar) {
                                    break;
                                }
                            }
                            cm s = neVar.s();
                            if (s == obj2) {
                                we1 = s;
                            }
                        }
                        andSet = j.get(d81);
                        if (a80 != null) {
                        }
                        if (andSet == wl1.k) {
                        }
                        c81.h = d81;
                        c81.i = uwVar2;
                        c81.j = e81;
                        c81.k = a80;
                        c81.l = andSet;
                        c81.o = 2;
                        if (uwVar2.k(obj3, c81) != obj2) {
                        }
                        return obj2;
                    } catch (Throwable th3) {
                        th = th3;
                    }
                } else {
                    od.p("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                slVar = c81.f;
                slVar.getClass();
                d81 = this;
                uwVar2 = uwVar;
                a80 = (a80) slVar.k(e3.S);
                a40 = null;
                andSet = j.get(d81);
                if (a80 != null) {
                }
                if (andSet == wl1.k) {
                }
                c81.h = d81;
                c81.i = uwVar2;
                c81.j = e81;
                c81.k = a80;
                c81.l = andSet;
                c81.o = 2;
                if (uwVar2.k(obj3, c81) != obj2) {
                }
                return obj2;
            }
        }
        c81 = new c81(this, mlVar);
        obj = c81.m;
        i = c81.o;
        obj2 = cm.e;
        if (i != 0) {
        }
        slVar = c81.f;
        slVar.getClass();
        d81 = this;
        uwVar2 = uwVar;
        a80 = (a80) slVar.k(e3.S);
        a40 = null;
        andSet = j.get(d81);
        if (a80 != null) {
        }
        if (andSet == wl1.k) {
        }
        c81.h = d81;
        c81.i = uwVar2;
        c81.j = e81;
        c81.k = a80;
        c81.l = andSet;
        c81.o = 2;
        if (uwVar2.k(obj3, c81) != obj2) {
        }
        return obj2;
        m0Var.f(n0Var);
        throw th;
    }

    /* JADX WARNING: Missing block: B:20:0x002d, code:
            r11 = (defpackage.e81[]) r11;
     */
    /* JADX WARNING: Missing block: B:21:0x002f, code:
            if (r11 == null) goto L_0x0071;
     */
    /* JADX WARNING: Missing block: B:22:0x0031, code:
            r0 = r11.length;
            r3 = 0;
     */
    /* JADX WARNING: Missing block: B:23:0x0033, code:
            if (r3 >= r0) goto L_0x0071;
     */
    /* JADX WARNING: Missing block: B:24:0x0035, code:
            r4 = r11[r3];
     */
    /* JADX WARNING: Missing block: B:25:0x0037, code:
            if (r4 == null) goto L_0x006e;
     */
    /* JADX WARNING: Missing block: B:26:0x0039, code:
            r4 = r4.a;
     */
    /* JADX WARNING: Missing block: B:27:0x003b, code:
            r5 = r4.get();
     */
    /* JADX WARNING: Missing block: B:28:0x003f, code:
            if (r5 != null) goto L_0x0042;
     */
    /* JADX WARNING: Missing block: B:30:0x0042, code:
            r6 = defpackage.ac.C;
     */
    /* JADX WARNING: Missing block: B:31:0x0044, code:
            if (r5 != r6) goto L_0x0047;
     */
    /* JADX WARNING: Missing block: B:33:0x0047, code:
            r7 = defpackage.ac.B;
     */
    /* JADX WARNING: Missing block: B:34:0x0049, code:
            if (r5 != r7) goto L_0x0059;
     */
    /* JADX WARNING: Missing block: B:36:0x004f, code:
            if (r4.compareAndSet(r5, r6) == false) goto L_0x0052;
     */
    /* JADX WARNING: Missing block: B:39:0x0056, code:
            if (r4.get() == r5) goto L_0x004b;
     */
    /* JADX WARNING: Missing block: B:42:0x005d, code:
            if (r4.compareAndSet(r5, r7) == false) goto L_0x0067;
     */
    /* JADX WARNING: Missing block: B:43:0x005f, code:
            ((android.view.autofill.AutofillValue) ((defpackage.ne) r5));
     */
    /* JADX WARNING: Missing block: B:45:0x006b, code:
            if (r4.get() == r5) goto L_0x0059;
     */
    /* JADX WARNING: Missing block: B:47:0x006e, code:
            r3 = r3 + 1;
     */
    /* JADX WARNING: Missing block: B:48:0x0071, code:
            monitor-enter(r9);
     */
    /* JADX WARNING: Missing block: B:50:?, code:
            r11 = r9.i;
     */
    /* JADX WARNING: Missing block: B:51:0x0074, code:
            if (r11 != r10) goto L_0x007d;
     */
    /* JADX WARNING: Missing block: B:52:0x0076, code:
            r9.i = r10 + 1;
     */
    /* JADX WARNING: Missing block: B:53:0x0079, code:
            monitor-exit(r9);
     */
    /* JADX WARNING: Missing block: B:54:0x007a, code:
            return true;
     */
    /* JADX WARNING: Missing block: B:57:?, code:
            r10 = r9.e;
     */
    /* JADX WARNING: Missing block: B:58:0x007f, code:
            monitor-exit(r9);
     */
    /* JADX WARNING: Missing block: B:59:0x0080, code:
            r8 = r11;
            r11 = r10;
            r10 = r8;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean i(Object obj, Object obj2) {
        synchronized (this) {
            AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = j;
            Object obj3 = atomicReferenceFieldUpdater.get(this);
            if (obj != null && !k70.p(obj3, obj)) {
                return false;
            } else if (k70.p(obj3, obj2)) {
                return true;
            } else {
                atomicReferenceFieldUpdater.set(this, obj2);
                int i = this.i;
                if ((i & 1) == 0) {
                    i++;
                    this.i = i;
                    n0[] n0VarArr = this.e;
                } else {
                    this.i = i + 2;
                    return true;
                }
            }
        }
    }

    /* JADX WARNING: Missing block: B:5:0x0007, code:
            if (r3 == -2) goto L_0x0009;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final tw c(sl slVar, int i, gd gdVar) {
        if (i < 0 || i >= 2) {
        }
        if (gdVar == gd.f) {
            return this;
        }
        if (!((i == 0 || i == -3) && gdVar == gd.e)) {
            return new af(this, slVar, i, gdVar);
        }
        return this;
    }

    public final Object getValue() {
        mt mtVar = wl1.k;
        mt mtVar2 = j.get(this);
        return mtVar2 == mtVar ? null : mtVar2;
    }

    public final AutofillValue h(Object obj) {
        if (obj == null) {
            obj = wl1.k;
        }
        i(null, obj);
        return;
    }

    public d81(Object obj) {
        this._state$volatile = obj;
    }

    public final n0 d() {
        return new e81();
    }

    public final Object k(Object obj, ml mlVar) {
        ((AutofillValue) this);
        return we1.a;
    }

    public final n0[] e() {
        return new e81[2];
    }
}