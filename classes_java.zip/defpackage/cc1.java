package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cc1 */
public final class cc1 {
    public final sj0 a = new sj0();
    public bc1 b;
    public long c = -1;
    public long d = 0;
    public long e = 0;
    public long f;
    public float[] g;

    /* JADX WARNING: Removed duplicated region for block: B:10:? A:{SYNTHETIC, RETURN} */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0018  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void a(bc1 bc1, long j, long j2, float[] fArr, long j3) {
        Object obj;
        long j4 = j3;
        long j5 = bc1.g;
        if (j4 - j5 <= 0) {
            if (j5 != Long.MIN_VALUE) {
                obj = null;
                if (obj == null) {
                    bc1.g = j4;
                    bc1.a(bc1.e, bc1.f, j, j2, fArr);
                    return;
                }
                return;
            }
        }
        obj = 1;
        if (obj == null) {
        }
    }

    public cc1() {
        sj0 sj0 = m60.a;
    }
}