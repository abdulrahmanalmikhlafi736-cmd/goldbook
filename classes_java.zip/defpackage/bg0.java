package defpackage;

import android.view.autofill.AutofillManager;
import java.lang.ref.WeakReference;
import java.util.Map;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bg0 */
public abstract class bg0 extends ks0 implements xi0, oh0 {
    public yf0 j;
    public i00 k;
    public ms0 l;
    public boolean m;
    public boolean n;
    public boolean o;
    public final cg0 p = new cg0(0, this);
    public wy0 q;
    public hk0 r;

    public final void X(ms0 ms0, long j, long j2) {
        int i;
        long j3;
        int i2;
        long j4;
        long j5;
        long j6;
        hk0 hk0 = this.r;
        wy0 wy0 = this.q;
        if (wy0 == null) {
            wy0 = new wy0();
            this.q = wy0;
        }
        wy0 wy02 = wy0;
        lp0 lp0 = f0().r;
        if (lp0 != null) {
            op0 snapshotObserver = ((n4) lp0).getSnapshotObserver();
            if (snapshotObserver != null) {
                ms0 ms02 = ms0;
                snapshotObserver.a.b(ms02, i4.F, new zf0(this, j, j2, ms02));
            }
        }
        boolean n = n();
        ik0 ik0 = (ik0) wy02.e;
        ik0 ik02 = (ik0) wy02.f;
        int i3 = wy02.a;
        for (i = 0; i < i3; i++) {
            byte b = ((byte[]) wy02.d)[i];
            Object obj;
            if (b == (byte) 3) {
                obj = ((j30[]) wy02.b)[i];
                obj.getClass();
                ik02.k(obj);
            } else if (!(b == (byte) 0 || hk0 == null)) {
                obj = ((j30[]) wy02.b)[i];
                obj.getClass();
                ik0 ik03 = (ik0) hk0.k(obj);
                if (ik03 != null) {
                    ik0.j(ik03);
                }
            }
        }
        i3 = wy02.a;
        int i4 = 0;
        for (i = 0; i < i3; i++) {
            byte[] bArr = (byte[]) wy02.d;
            if (bArr[i] == (byte) 2) {
                i4++;
            } else if (i4 > 0) {
                j30[] j30Arr = (j30[]) wy02.b;
                j30Arr[i - i4] = j30Arr[i];
            }
            bArr[i] = (byte) 2;
        }
        i3 = wy02.a;
        for (i = i3 - i4; i < i3; i++) {
            ((j30[]) wy02.b)[i] = null;
        }
        wy02.a -= i4;
        bg0 h0 = h0();
        Object[] objArr = ik02.b;
        long[] jArr = ik02.a;
        int length = jArr.length - 2;
        long j7 = 7;
        long j8 = -9187201950435737472L;
        byte b2 = (byte) 2;
        int i5 = 8;
        if (length >= 0) {
            j3 = 128;
            i2 = 0;
            while (true) {
                long j9 = jArr[i2];
                j4 = 255;
                if (((((~j9) << j7) & j9) & j8) != j8) {
                    int i6 = 8 - ((~(i2 - length)) >>> 31);
                    int i7 = 0;
                    while (i7 < i6) {
                        Object obj2;
                        long j10;
                        if ((j9 & 255) < 128) {
                            obj2 = j7;
                            j30 j30 = (j30) objArr[(i2 << 3) + i7];
                            j5 = j8;
                            bg0 bg0 = h0 == null ? this : h0;
                            j10 = i5;
                            bg0 bg02 = bg0;
                            while (true) {
                                wy0 wy03 = bg02.q;
                                if (wy03 != null && ba.f0((j30[]) wy03.b, j30) >= 0) {
                                    break;
                                }
                                bg0 h02 = bg02.h0();
                                if (h02 == null) {
                                    break;
                                }
                                bg02 = h02;
                            }
                            hk0 hk02 = bg02.r;
                            ik0 ik04 = hk02 != null ? (ik0) hk02.k(j30) : null;
                            if (ik04 != null) {
                                bg0.l0(ik04);
                            }
                        } else {
                            j10 = i5;
                            obj2 = j7;
                            j5 = j8;
                        }
                        j9 >>= j10;
                        i7++;
                        j7 = obj2;
                        j8 = j5;
                        i5 = j10;
                    }
                    j6 = j7;
                    j5 = j8;
                    if (i6 != i5) {
                        break;
                    }
                } else {
                    j6 = j7;
                    j5 = j8;
                }
                if (i2 == length) {
                    break;
                }
                i2++;
                j7 = j6;
                j8 = j5;
                i5 = 8;
            }
        } else {
            j6 = 7;
            j5 = -9187201950435737472L;
            j3 = 128;
            j4 = 255;
        }
        ik02.b();
        Object[] objArr2 = ik0.b;
        long[] jArr2 = ik0.a;
        int length2 = jArr2.length - 2;
        if (length2 >= 0) {
            i = 0;
            while (true) {
                long j11 = jArr2[i];
                if (((((~j11) << j6) & j11) & j5) != j5) {
                    length = 8 - ((~(i - length2)) >>> 31);
                    for (i2 = 0; i2 < length; i2++) {
                        if ((j11 & j4) < j3) {
                            ba0 ba0 = (ba0) ((qh1) objArr2[(i << 3) + i2]).get();
                            if (ba0 != null) {
                                if (n) {
                                    ba0.S(false);
                                } else {
                                    ba0.U(false);
                                }
                                j11 >>= 8;
                            }
                        }
                        j11 >>= 8;
                    }
                    if (length != 8) {
                        break;
                    }
                }
                if (i == length2) {
                    break;
                }
                i++;
            }
        }
        ik0.b();
    }

    /* JADX WARNING: Removed duplicated region for block: B:48:0x0114  */
    /* JADX WARNING: Removed duplicated region for block: B:69:0x0168  */
    /* JADX WARNING: Removed duplicated region for block: B:72:0x0175  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void U(ba0 ba0, j30 j30) {
        long j;
        long j2;
        long j3;
        long j4;
        a1 a1Var;
        AutofillManager g;
        j30 j302 = j30;
        hk0 hk0 = this.r;
        long j5 = 7;
        long j6 = -9187201950435737472L;
        int i = 8;
        if (hk0 != null) {
            Object[] objArr = hk0.c;
            long[] jArr = hk0.a;
            int length = jArr.length - 2;
            if (length >= 0) {
                int i2;
                int i3;
                int i4 = 0;
                long j7 = 128;
                while (true) {
                    long[] jArr2;
                    long j8 = jArr[i4];
                    j = 255;
                    if (((((~j8) << j5) & j8) & j6) != j6) {
                        i2 = 8 - ((~(i4 - length)) >>> 31);
                        int i5 = 0;
                        while (i5 < i2) {
                            Object obj;
                            long j9;
                            int i6;
                            if ((j8 & 255) < j7) {
                                obj = j5;
                                ik0 ik0 = (ik0) objArr[(i4 << 3) + i5];
                                j2 = j6;
                                Object[] objArr2 = ik0.b;
                                long[] jArr3 = ik0.a;
                                int length2 = jArr3.length - 2;
                                if (length2 >= 0) {
                                    j3 = j7;
                                    int i7 = 0;
                                    long j10 = i;
                                    while (true) {
                                        int i8 = length2;
                                        long j11 = jArr3[i7];
                                        jArr2 = jArr;
                                        j9 = j8;
                                        if (((((~j11) << obj) & j11) & j2) != j2) {
                                            int i9 = 8 - ((~(i7 - i8)) >>> 31);
                                            int i10 = 0;
                                            while (i10 < i9) {
                                                int i11;
                                                if ((j11 & 255) < j3) {
                                                    i3 = (i7 << 3) + i10;
                                                    ba0 ba02 = (ba0) ((qh1) objArr2[i3]).get();
                                                    i11 = i10;
                                                    if (ba02 != null) {
                                                        boolean H = ba02.H();
                                                        i6 = i5;
                                                        if (H) {
                                                        }
                                                    } else {
                                                        i6 = i5;
                                                    }
                                                    ik0.m(i3);
                                                } else {
                                                    i11 = i10;
                                                    i6 = i5;
                                                }
                                                j11 >>= j10;
                                                i10 = i11 + 1;
                                                i5 = i6;
                                            }
                                            i6 = i5;
                                            if (i9 != j10) {
                                                break;
                                            }
                                        }
                                        i6 = i5;
                                        length2 = i8;
                                        if (i7 == length2) {
                                            break;
                                        }
                                        i7++;
                                        jArr = jArr2;
                                        j8 = j9;
                                        i5 = i6;
                                        j10 = 8;
                                    }
                                } else {
                                    jArr2 = jArr;
                                    j9 = j8;
                                    i6 = i5;
                                    j3 = j7;
                                }
                                j8 = 8;
                            } else {
                                jArr2 = jArr;
                                j9 = j8;
                                i6 = i5;
                                obj = j5;
                                j2 = j6;
                                j3 = j7;
                                j8 = i;
                            }
                            i = j8;
                            j8 = j9 >> j8;
                            j5 = obj;
                            j6 = j2;
                            j7 = j3;
                            i5 = i6 + 1;
                            jArr = jArr2;
                        }
                        jArr2 = jArr;
                        j4 = j5;
                        j2 = j6;
                        j3 = j7;
                        if (i2 != i) {
                            break;
                        }
                    } else {
                        jArr2 = jArr;
                        j4 = j5;
                        j2 = j6;
                        j3 = j7;
                    }
                    if (i4 == length) {
                        break;
                    }
                    i4++;
                    j5 = j4;
                    j6 = j2;
                    j7 = j3;
                    jArr = jArr2;
                    i = 8;
                }
                hk0 = this.r;
                if (hk0 != null) {
                    long[] jArr4 = hk0.a;
                    i3 = jArr4.length - 2;
                    if (i3 >= 0) {
                        i2 = 0;
                        while (true) {
                            long j12 = jArr4[i2];
                            if (((((~j12) << j4) & j12) & j2) != j2) {
                                i = 8 - ((~(i2 - i3)) >>> 31);
                                for (int i12 = 0; i12 < i; i12++) {
                                    if ((j12 & j) < j3) {
                                        int i13 = (i2 << 3) + i12;
                                        j30 j303 = (j30) hk0.b[i13];
                                        if (((ik0) hk0.c[i13]).g()) {
                                            hk0.l(i13);
                                        }
                                    }
                                    j12 >>= 8;
                                }
                                if (i != 8) {
                                    break;
                                }
                            }
                            if (i2 == i3) {
                                break;
                            }
                            i2++;
                        }
                    }
                }
                a1Var = this.r;
                if (a1Var == null) {
                    a1Var = new hk0();
                    this.r = a1Var;
                }
                g = ((AutofillManager) a1Var);
                if (g == null) {
                    g = new ik0();
                    a1Var.m(j302, g);
                }
                ((ik0) g).k(new WeakReference(ba0));
            }
        }
        j4 = 7;
        j2 = -9187201950435737472L;
        j = 255;
        j3 = 128;
        hk0 = this.r;
        if (hk0 != null) {
        }
        a1Var = this.r;
        if (a1Var == null) {
        }
        g = ((AutofillManager) a1Var);
        if (g == null) {
        }
        ((ik0) g).k(new WeakReference(ba0));
    }

    public final void Y(nh0 nh0) {
        hk0 hk0 = this.r;
        if (!this.o) {
            i00 d = nh0.d();
            Object obj = null;
            long j;
            if (d != null) {
                long j2;
                Object obj2 = this.k != d ? 1 : null;
                if (obj2 == null && j0().e) {
                    n90 d0 = d0();
                    long C = vd1.C(d0.d(0));
                    long A = d0.A();
                    if (!(d90.a(C, j0().f) && d90.a(A, j0().g))) {
                        obj = 1;
                    }
                    j2 = C;
                    j = A;
                    obj2 = obj;
                } else {
                    j = 0;
                    j2 = 9223372034707292159L;
                }
                if (obj2 != null) {
                    ms0 ms0 = this.l;
                    if (ms0 != null) {
                        ms0.e = nh0;
                    } else {
                        ms0 = new ms0(nh0, this);
                        this.l = ms0;
                    }
                    X(ms0, j2, j);
                    this.k = nh0.d();
                }
            } else if (hk0 != null) {
                Object[] objArr = hk0.c;
                long[] jArr = hk0.a;
                int length = jArr.length - 2;
                if (length >= 0) {
                    int i = 0;
                    while (true) {
                        j = jArr[i];
                        if (((((~j) << 7) & j) & -9187201950435737472L) != -9187201950435737472L) {
                            int i2 = 8 - ((~(i - length)) >>> 31);
                            for (int i3 = 0; i3 < i2; i3++) {
                                if ((255 & j) < 128) {
                                    l0((ik0) objArr[(i << 3) + i3]);
                                }
                                j >>= 8;
                            }
                            if (i2 != 8) {
                                break;
                            }
                        }
                        if (i == length) {
                            break;
                        }
                        i++;
                    }
                }
                hk0.a();
            }
        }
    }

    public final void l0(ik0 ik0) {
        Object[] objArr = ik0.b;
        long[] jArr = ik0.a;
        int length = jArr.length - 2;
        if (length >= 0) {
            int i = 0;
            while (true) {
                long j = jArr[i];
                if (((((~j) << 7) & j) & -9187201950435737472L) != -9187201950435737472L) {
                    int i2 = 8 - ((~(i - length)) >>> 31);
                    for (int i3 = 0; i3 < i2; i3++) {
                        if ((255 & j) < 128) {
                            ba0 ba0 = (ba0) ((qh1) objArr[(i << 3) + i3]).get();
                            if (ba0 != null) {
                                if (n()) {
                                    ba0.S(false);
                                } else {
                                    ba0.U(false);
                                }
                            }
                        }
                        j >>= 8;
                    }
                    if (i2 != 8) {
                        return;
                    }
                }
                if (i != length) {
                    i++;
                } else {
                    return;
                }
            }
        }
    }

    public final void m(boolean z) {
        bg0 h0 = h0();
        x90 x90 = null;
        Object f0 = h0 != null ? h0.f0() : null;
        if (k70.p(f0, f0())) {
            this.m = z;
            return;
        }
        if ((f0 != null ? f0.K.d : null) != x90.g) {
            if (f0 != null) {
                x90 = f0.K.d;
            }
            if (x90 != x90.h) {
                return;
            }
        }
        this.m = z;
    }

    public final nh0 E(int i, int i2, Map map, i00 i00, i00 i002) {
        if ((i & -16777216) != 0 || (-16777216 & i2) != 0) {
            StringBuilder dl1 = new dl1("Size(");
            dl1.append(i);
            dl1.append(" x ");
            dl1.append(i2);
            dl1.append(") is out of range. Each dimension must be between 0 and 16777215.");
            a5.b(dl1.toString());
        }
        return new ag0(i, i2, map, i00, i002, this);
    }

    public static void k0(gm0 gm0) {
        gm0 gm02 = gm0.t;
        ba0 ba0 = gm0.s;
        if (k70.p(gm02 != null ? gm02.s : null, ba0)) {
            k3 s = ba0.K.p.s();
            if (s != null) {
                ca0 ca0 = ((lh0) s).A;
                if (ca0 != null) {
                    ca0.f();
                }
            }
            return;
        }
        ba0.K.p.A.f();
    }

    public final int Z(f3 f3Var) {
        if (e0()) {
            int W = W(f3Var);
            if (W != Integer.MIN_VALUE) {
                boolean z = f3Var instanceof ng1;
                long j = this.i;
                return W + ((int) (z ? j >> 32 : 4294967295L & j));
            }
        }
        return Integer.MIN_VALUE;
    }

    public final yf0 j0() {
        yf0 yf0 = this.j;
        if (yf0 != null) {
            return yf0;
        }
        yf0 = new yf0(this);
        this.j = yf0;
        return yf0;
    }

    public final nh0 O(int i, int i2, Map map, i00 i00) {
        return E(i, i2, map, null, i00);
    }

    public final long V(float f) {
        return fu0.q(f / a(), this);
    }

    public final float b0(int i) {
        return ((float) i) / a();
    }

    public final float c0(float f) {
        return f / a();
    }

    public final float q(float f) {
        return a() * f;
    }

    public final /* synthetic */ int F(float f) {
        return fu0.k(f, this);
    }

    public final /* synthetic */ long K(long j) {
        return fu0.p(j, this);
    }

    public final /* synthetic */ float N(long j) {
        return fu0.o(j, this);
    }

    public final /* synthetic */ float y(long j) {
        return fu0.m(j, this);
    }

    public boolean n() {
        return false;
    }

    public abstract int W(f3 f3Var);

    public abstract bg0 a0();

    public abstract n90 d0();

    public abstract boolean e0();

    public abstract ba0 f0();

    public abstract nh0 g0();

    public abstract bg0 h0();

    public abstract long i0();

    public abstract void m0();
}