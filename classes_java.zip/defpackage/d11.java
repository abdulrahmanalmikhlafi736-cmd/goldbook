package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: d11 */
final class d11 extends qi0 {
    public final r11 a;
    public final bp0 b;
    public final boolean c;
    public final jo d;
    public final uj0 e;
    public final boolean f;
    public final x5 g;

    public final boolean equals(Object obj) {
        if (this != obj) {
            if (obj != null) {
                if (d11.class == obj.getClass()) {
                    d11 d11 = (d11) obj;
                    if (k70.p(this.a, d11.a)) {
                        if (this.b == d11.b) {
                            if (this.c == d11.c) {
                                if (k70.p(this.d, d11.d)) {
                                    if (k70.p(this.e, d11.e)) {
                                        if (this.f == d11.f) {
                                            if (!k70.p(this.g, d11.g)) {
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return false;
        }
        return true;
    }

    public final int hashCode() {
        int i = 1237;
        int hashCode = (((((this.b.hashCode() + (this.a.hashCode() * 31)) * 31) + (this.c ? 1231 : 1237)) * 31) + 1237) * 31;
        int i2 = 0;
        jo joVar = this.d;
        hashCode = (hashCode + (joVar != null ? joVar.hashCode() : 0)) * 31;
        uj0 uj0 = this.e;
        hashCode = (hashCode + (uj0 != null ? uj0.hashCode() : 0)) * 961;
        if (this.f) {
            i = 1231;
        }
        hashCode = (hashCode + i) * 31;
        x5 x5Var = this.g;
        if (x5Var != null) {
            i2 = x5Var.hashCode();
        }
        return hashCode + i2;
    }

    public final li0 e() {
        e11 dpVar = new dp();
        dpVar.u = this.a;
        dpVar.v = this.b;
        dpVar.w = this.c;
        dpVar.x = this.d;
        dpVar.y = this.e;
        dpVar.z = this.f;
        dpVar.A = this.g;
        return dpVar;
    }

    public final void f(li0 li0) {
        ((e11) li0).w0(this.g, this.d, this.e, this.b, this.a, this.f, this.c);
    }

    public d11(x5 x5Var, jo joVar, uj0 uj0, bp0 bp0, r11 r11, boolean z, boolean z2) {
        this.a = r11;
        this.b = bp0;
        this.c = z;
        this.d = joVar;
        this.e = uj0;
        this.f = z2;
        this.g = x5Var;
    }
}