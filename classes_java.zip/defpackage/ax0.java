package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ax0 */
public final class ax0 implements bm, ww0 {
    public static final qe h = new h90(0);
    public final sl e;
    public final ax0 f = this;
    public volatile sl g;

    public final sl f() {
        Object obj = this.g;
        if (obj == null || obj == h) {
            wj wjVar = (wj) this.e.k(wj.f);
            sl zw0 = wjVar != null ? new zw0(wjVar, this) : st.e;
            synchronized (this.f) {
                try {
                    sl slVar = this.g;
                    if (slVar == null) {
                        slVar = this.e;
                        zw0 = slVar.i(new c80((a80) slVar.k(e3.S))).i(st.e).i(zw0);
                    } else if (slVar == h) {
                        slVar = this.e;
                        c80 c80 = new c80((a80) slVar.k(e3.S));
                        c80.A(new h90(0));
                        zw0 = slVar.i(c80).i(st.e).i(zw0);
                    } else {
                        zw0 = slVar;
                    }
                    this.g = zw0;
                } finally {
                }
            }
            obj = zw0;
        }
        obj.getClass();
        return obj;
    }

    public final void a() {
        synchronized (this.f) {
            try {
                sl slVar = this.g;
                if (slVar == null) {
                    this.g = h;
                } else {
                    uz h90 = new h90(0);
                    a80 a80 = (a80) slVar.k(e3.S);
                    if (a80 != null) {
                        a80.a(h90);
                    }
                }
            } finally {
            }
        }
    }

    public ax0(sl slVar) {
        this.e = slVar;
    }

    public final void d() {
        a();
    }

    public final void e() {
        a();
    }

    public final void c() {
    }
}