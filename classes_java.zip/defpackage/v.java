package defpackage;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: v */
public abstract class v extends m implements List {
    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof List)) {
            return false;
        }
        Collection collection = (Collection) obj;
        if (size() == collection.size()) {
            Iterator it = collection.iterator();
            for (Object p : this) {
                if (!k70.p(p, it.next())) {
                }
            }
            return true;
        }
        return false;
    }

    public int lastIndexOf(Object obj) {
        ListIterator listIterator = listIterator(size());
        while (listIterator.hasPrevious()) {
            if (k70.p(listIterator.previous(), obj)) {
                return listIterator.nextIndex();
            }
        }
        return -1;
    }

    public final int hashCode() {
        int i = 1;
        for (Object next : this) {
            i = (i * 31) + (next != null ? next.hashCode() : 0);
        }
        return i;
    }

    public int indexOf(Object obj) {
        int i = 0;
        for (Object p : this) {
            if (k70.p(p, obj)) {
                return i;
            }
            i++;
        }
        return -1;
    }

    public final void add(int i, Object obj) {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final boolean addAll(int i, Collection collection) {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final Object remove(int i) {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final Object set(int i, Object obj) {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public ListIterator listIterator() {
        return new t(this, 0);
    }

    public Iterator iterator() {
        return new s(this);
    }

    public List subList(int i, int i2) {
        return new u(this, i, i2);
    }

    public ListIterator listIterator(int i) {
        return new t(this, i);
    }
}