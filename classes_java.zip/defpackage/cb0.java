package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cb0 */
final class cb0 extends qi0 {
    public final fb0 a;

    public final void f(li0 li0) {
        db0 db0 = (db0) li0;
        fb0 fb0 = db0.s;
        fb0 fb02 = this.a;
        if (!k70.p(fb0, fb02) && db0.e.r) {
            fb0 = db0.s;
            fb0.c();
            fb0.b = null;
            db0.s = fb02;
        }
    }

    public final String toString() {
        StringBuilder dl1 = new dl1("DisplayingDisappearingItemsElement(animator=");
        dl1.append(this.a);
        dl1.append(')');
        return dl1.toString();
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof cb0)) {
            return false;
        }
        return this.a == ((cb0) obj).a;
    }

    public final li0 e() {
        db0 li0 = new li0();
        li0.s = this.a;
        return li0;
    }

    public final int hashCode() {
        return this.a.hashCode();
    }

    public cb0(fb0 fb0) {
        this.a = fb0;
    }
}