package defpackage;

import java.util.concurrent.atomic.AtomicReference;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: al0 */
public final class al0 {
    public final AtomicReference a = new AtomicReference(null);
    public final cl0 b = new cl0();

    public static Object a(al0 al0, i00 i00, nl nlVar) {
        al0.getClass();
        return vd1.i(new xk0(al0, i00, null), nlVar);
    }
}