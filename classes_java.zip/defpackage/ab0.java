package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ab0 */
public final class ab0 implements kb {
    public final /* synthetic */ bb0 a;
    public final /* synthetic */ nw0 b;
    public final /* synthetic */ int c;

    public final boolean a() {
        return this.a.r0((xa0) this.b.e, this.c);
    }

    public ab0(bb0 bb0, nw0 nw0, int i) {
        this.a = bb0;
        this.b = nw0;
        this.c = i;
    }
}