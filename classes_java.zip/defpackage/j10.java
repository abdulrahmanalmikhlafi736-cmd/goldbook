package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: j10 */
public abstract class j10 implements Cloneable {
    public final l10 e;
    public l10 f;

    public final l10 b() {
        boolean g = this.f.g();
        l10 l10 = this.f;
        if (!g) {
            return l10;
        }
        l10.getClass();
        jv0 jv0 = jv0.c;
        jv0.getClass();
        jv0.a(l10.getClass()).c(l10);
        l10.h();
        return this.f;
    }

    public final void c() {
        if (!this.f.g()) {
            l10 i = this.e.i();
            l10 l10 = this.f;
            jv0 jv0 = jv0.c;
            jv0.getClass();
            jv0.a(i.getClass()).b(i, l10);
            this.f = i;
        }
    }

    public j10(l10 l10) {
        this.e = l10;
        if (l10.g()) {
            od.m("Default instance must be immutable.");
            throw null;
        } else {
            this.f = l10.i();
        }
    }

    public final l10 a() {
        l10 b = b();
        b.getClass();
        if (l10.f(b, true)) {
            return b;
        }
        throw new ue1();
    }

    public final Object clone() {
        j10 j10 = (j10) this.e.c(5);
        j10.f = b();
        return j10;
    }
}