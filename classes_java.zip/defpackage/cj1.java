package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cj1 */
public abstract class cj1 implements bj1 {
    public static final lq0 a = mc0.t(new h90(0));
}