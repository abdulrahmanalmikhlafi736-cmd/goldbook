package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ar0 */
public final class ar0 extends jr0 {
    public final float c;
    public final float d;
    public final float e;
    public final float f;
    public final float g;
    public final float h;

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof ar0)) {
            return false;
        }
        ar0 ar0 = (ar0) obj;
        return Float.compare(this.c, ar0.c) == 0 && Float.compare(this.d, ar0.d) == 0 && Float.compare(this.e, ar0.e) == 0 && Float.compare(this.f, ar0.f) == 0 && Float.compare(this.g, ar0.g) == 0 && Float.compare(this.h, ar0.h) == 0;
    }

    public final String toString() {
        StringBuilder dl1 = new dl1("RelativeCurveTo(dx1=");
        dl1.append(this.c);
        dl1.append(", dy1=");
        dl1.append(this.d);
        dl1.append(", dx2=");
        dl1.append(this.e);
        dl1.append(", dy2=");
        dl1.append(this.f);
        dl1.append(", dx3=");
        dl1.append(this.g);
        dl1.append(", dy3=");
        return fu0.F(dl1, this.h, ')');
    }

    public final int hashCode() {
        return Float.floatToIntBits(this.h) + fu0.z(this.g, fu0.z(this.f, fu0.z(this.e, fu0.z(this.d, Float.floatToIntBits(this.c) * 31, 31), 31), 31), 31);
    }

    public ar0(float f, float f2, float f3, float f4, float f5, float f6) {
        super(2);
        this.c = f;
        this.d = f2;
        this.e = f3;
        this.f = f4;
        this.g = f5;
        this.h = f6;
    }
}