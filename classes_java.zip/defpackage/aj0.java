package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: aj0 */
public final class aj0 {
    public final long a;
    public final long b;
    public final boolean c;

    public final String toString() {
        StringBuilder dl1 = new dl1("MouseWheelScrollDelta(value=");
        dl1.append(xm0.h(this.a));
        dl1.append(", timeMillis=");
        dl1.append(this.b);
        dl1.append(", shouldApplyImmediately=");
        dl1.append(this.c);
        dl1.append(')');
        return dl1.toString();
    }

    /* JADX WARNING: Missing block: B:12:0x0022, code:
            if (r4.c != r5.c) goto L_0x0024;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean equals(Object obj) {
        if (this != obj) {
            if (obj instanceof aj0) {
                aj0 aj0 = (aj0) obj;
                if (n60.b(this.a, aj0.a) != null) {
                    if (this.b != aj0.b) {
                    }
                }
            }
            return false;
        }
        return true;
    }

    public final int hashCode() {
        int d = xm0.d(this.a) * 31;
        long j = this.b;
        return ((d + ((int) (j ^ (j >>> 32)))) * 31) + (this.c ? 1231 : 1237);
    }

    public final aj0 a(aj0 aj0) {
        return new aj0(xm0.f(this.a, aj0.a), Math.max(this.b, aj0.b), this.c);
    }

    public aj0(long j, long j2, boolean z) {
        this.a = j;
        this.b = j2;
        this.c = z;
    }
}