package defpackage;

import android.view.autofill.AutofillValue;
import java.util.Arrays;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: m0 */
public abstract class m0 {
    public n0[] e;
    public int f;
    public int g;
    public j91 h;

    public final n0 a() {
        n0 n0Var;
        j91 j91;
        synchronized (this) {
            try {
                n0[] n0VarArr = this.e;
                if (n0VarArr == null) {
                    n0VarArr = e();
                    this.e = n0VarArr;
                } else if (this.f >= n0VarArr.length) {
                    Object[] copyOf = Arrays.copyOf(n0VarArr, n0VarArr.length * 2);
                    this.e = (n0[]) copyOf;
                    n0VarArr = (n0[]) copyOf;
                }
                int i = this.g;
                while (true) {
                    n0Var = n0VarArr[i];
                    if (n0Var == null) {
                        n0Var = d();
                        n0VarArr[i] = n0Var;
                    }
                    i++;
                    if (i >= n0VarArr.length) {
                        i = 0;
                    }
                    if (n0Var.a(this)) {
                        break;
                    }
                }
                this.g = i;
                this.f++;
                j91 = this.h;
            } finally {
            }
        }
        if (j91 != null) {
            j91.w(1);
        }
        return n0Var;
    }

    public final void f(n0 n0Var) {
        j91 j91;
        int i;
        ml[] b;
        synchronized (this) {
            try {
                int i2 = this.f - 1;
                this.f = i2;
                j91 = this.h;
                i = 0;
                if (i2 == 0) {
                    this.g = 0;
                }
                n0Var.getClass();
                b = n0Var.b(this);
            } finally {
            }
        }
        int length = b.length;
        while (i < length) {
            a1 a1Var = b[i];
            if (a1Var != null) {
                ((AutofillValue) a1Var);
            }
            i++;
        }
        if (j91 != null) {
            j91.w(-1);
        }
    }

    public final j91 g() {
        j91 j91;
        synchronized (this) {
            j91 = this.h;
            if (j91 == null) {
                int i = this.f;
                j91 = new g51(1, Integer.MAX_VALUE, gd.f);
                j91.q(Integer.valueOf(i));
                this.h = j91;
            }
        }
        return j91;
    }

    public abstract n0 d();

    public abstract n0[] e();
}