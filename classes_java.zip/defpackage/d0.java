package defpackage;

import java.util.Random;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: d0 */
public abstract class d0 extends qv0 {
    public abstract Random a();
}