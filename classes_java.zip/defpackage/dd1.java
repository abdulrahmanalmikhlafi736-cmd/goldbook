package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dd1 */
public final class dd1 implements qq {
    public final /* synthetic */ int a;

    public /* synthetic */ dd1(int i) {
        this.a = i;
    }

    public final void a() {
        int i = this.a;
    }

    private final void b() {
    }

    private final void c() {
    }
}