package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bj0 */
public final class bj0 extends nl {
    public y11 h;
    public kw0 i;
    public float j;
    public /* synthetic */ Object k;
    public final /* synthetic */ tp l;
    public int m;

    public final Object p(Object obj) {
        this.k = obj;
        this.m |= Integer.MIN_VALUE;
        return tp.a(this.l, null, null, 0.0f, 0.0f, this);
    }

    public bj0(tp tpVar, nl nlVar) {
        this.l = tpVar;
        super(nlVar);
    }
}