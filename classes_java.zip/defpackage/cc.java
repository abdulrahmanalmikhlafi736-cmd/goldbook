package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cc */
public final class cc {
    public static final /* synthetic */ cc a = new Object();
    public static final String b = dc.class.getSimpleName();
}