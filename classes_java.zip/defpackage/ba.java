package defpackage;

import java.util.Arrays;

/* renamed from: ba */
public abstract class ba extends vn {
    public static Object[] b0(Object[] objArr, int i, int i2) {
        objArr.getClass();
        int length = objArr.length;
        if (i2 <= length) {
            objArr = Arrays.copyOfRange(objArr, i, i2);
            objArr.getClass();
            return objArr;
        }
        StringBuilder dl1 = new dl1("toIndex (");
        dl1.append(i2);
        dl1.append(") is greater than size (");
        dl1.append(length);
        dl1.append(").");
        throw new dl1(dl1.toString());
    }

    public static int f0(Object[] objArr, Object obj) {
        int i = 0;
        if (obj == null) {
            int length = objArr.length;
            while (i < length) {
                if (objArr[i] == null) {
                    return i;
                }
                i++;
            }
        } else {
            int length2 = objArr.length;
            while (i < length2) {
                if (obj.equals(objArr[i])) {
                    return i;
                }
                i++;
            }
        }
        return -1;
    }

    public static boolean V(int[] iArr, int i) {
        int length = iArr.length;
        int i2 = 0;
        while (i2 < length) {
            if (i == iArr[i2]) {
                break;
            }
            i2++;
        }
        i2 = -1;
        return i2 >= 0;
    }

    public static /* synthetic */ void Z(int[] iArr, int[] iArr2, int i, int i2, int i3) {
        if ((i3 & 2) != 0) {
            i = 0;
        }
        if ((i3 & 8) != 0) {
            i2 = iArr.length;
        }
        ba.W(iArr, iArr2, i, 0, i2);
    }

    public static void W(int[] iArr, int[] iArr2, int i, int i2, int i3) {
        iArr.getClass();
        iArr2.getClass();
        System.arraycopy(iArr, i2, iArr2, i, i3 - i2);
    }

    public static void X(long[] jArr, long[] jArr2, int i, int i2, int i3) {
        jArr.getClass();
        jArr2.getClass();
        System.arraycopy(jArr, i2, jArr2, i, i3 - i2);
    }

    public static void Y(Object[] objArr, Object[] objArr2, int i, int i2, int i3) {
        objArr.getClass();
        objArr2.getClass();
        System.arraycopy(objArr, i2, objArr2, i, i3 - i2);
    }

    public static /* synthetic */ void a0(Object[] objArr, Object[] objArr2, int i, int i2, int i3) {
        if ((i3 & 4) != 0) {
            i = 0;
        }
        ba.Y(objArr, objArr2, 0, i, i2);
    }

    public static void d0(long[] jArr, long j) {
        int length = jArr.length;
        jArr.getClass();
        Arrays.fill(jArr, 0, length, j);
    }

    public static void c0(Object[] objArr, int i, int i2) {
        objArr.getClass();
        Arrays.fill(objArr, i, i2, null);
    }

    public static int e0(long[] jArr) {
        jArr.getClass();
        return jArr.length - 1;
    }
}