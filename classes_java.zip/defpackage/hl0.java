package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: hl0 */
public abstract class hl0 {
    public p3 a;
    public boolean b;

    public final void a() {
        p3 p3Var = this.a;
        if (p3Var != null) {
            if (!this.b) {
                p3Var.g(this, null);
            }
            il0 il0 = (il0) p3Var.f;
            m2 m2Var = (m2) p3Var.e;
            il0.getClass();
            if (equals(il0.h)) {
                if (-1 == il0.g) {
                    fl0 fl0 = il0.f;
                    if (fl0 == null) {
                        fl0 = il0.c(-1);
                    }
                    il0.f = null;
                    il0.g = 0;
                    il0.h = null;
                    if (fl0 == null) {
                        ((jn0) m2Var.a).a.run();
                    } else {
                        fl0.b();
                    }
                    d81 d81 = il0.a;
                    d81.getClass();
                    d81.i(null, jl0.b);
                }
            }
            this.b = false;
            return;
        }
        od.p("This input is not added to any dispatcher.");
    }

    public void b(boolean z) {
    }
}