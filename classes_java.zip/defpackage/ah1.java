package defpackage;

import android.content.Context;
import android.util.SparseArray;
import android.view.View;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ah1 */
public final class ah1 extends q7 {
    public final View E;
    public final rl0 F;
    public lz0 G;
    public i00 H;
    public i00 I;
    public i00 J;

    public ah1(Context context, i00 i00, b10 b10, mz0 mz0, int i, lp0 lp0) {
        View view = (View) i00.i(context);
        rl0 rl0 = new rl0();
        int i2 = i;
        super(context, b10, i2, rl0, view, lp0);
        this.E = view;
        this.F = rl0;
        setClipChildren(false);
        String valueOf = String.valueOf(i2);
        SparseArray sparseArray = null;
        Object f = mz0 != null ? mz0.f(valueOf) : null;
        if (f instanceof SparseArray) {
            sparseArray = (SparseArray) f;
        }
        if (sparseArray != null) {
            view.restoreHierarchyState(sparseArray);
        }
        if (mz0 != null) {
            setSavableRegistryEntry(mz0.a(valueOf, new l7(this, 2)));
        }
        i4 i4Var = i4.o;
        this.H = i4Var;
        this.I = i4Var;
        this.J = i4Var;
    }

    private final void setSavableRegistryEntry(lz0 lz0) {
        lz0 lz02 = this.G;
        if (lz02 != null) {
            ((k9) lz02).F();
        }
        this.G = lz0;
    }

    public final void setReleaseBlock(i00 i00) {
        this.J = i00;
        setRelease(new l7(this, 3));
    }

    public final void setResetBlock(i00 i00) {
        this.I = i00;
        setReset(new l7(this, 4));
    }

    public final void setUpdateBlock(i00 i00) {
        this.H = i00;
        setUpdate(new l7(this, 5));
    }

    public static final void h(ah1 ah1) {
        ah1.setSavableRegistryEntry(null);
    }

    public final rl0 getDispatcher() {
        return this.F;
    }

    public final i00 getReleaseBlock() {
        return this.J;
    }

    public final i00 getResetBlock() {
        return this.I;
    }

    public final i00 getUpdateBlock() {
        return this.H;
    }

    public /* bridge */ /* synthetic */ o getSubCompositionView() {
        return null;
    }

    public View getViewRoot() {
        return this;
    }
}