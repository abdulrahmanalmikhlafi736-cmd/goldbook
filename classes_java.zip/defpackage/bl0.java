package defpackage;

import android.view.autofill.AutofillValue;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bl0 */
public final class bl0 implements le, oh1 {
    public final ne e;
    public final /* synthetic */ cl0 f;

    public final mt j(Object obj, n00 n00) {
        we1 we1 = (we1) obj;
        cl0 cl0 = this.f;
        mt j = this.e.j(we1, new l(cl0, this));
        if (j != null) {
            cl0.g.set(cl0, null);
        }
        return j;
    }

    public bl0(cl0 cl0, ne neVar) {
        this.f = cl0;
        this.e = neVar;
    }

    public final boolean l(Throwable th) {
        return this.e.l(th);
    }

    public final void a(a21 a21, int i) {
        this.e.a(a21, i);
    }

    public final AutofillValue h(Object obj) {
        ((AutofillValue) this.e);
        return;
    }

    public final void x(Object obj) {
        this.e.x(obj);
    }

    public final sl e() {
        return this.e.i;
    }
}