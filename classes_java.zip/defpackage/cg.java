package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cg */
public final class cg implements n00 {
    public final /* synthetic */ t40 e;
    public final /* synthetic */ boolean f;
    public final /* synthetic */ iy0 g;
    public final /* synthetic */ xz h;

    public final Object c(Object obj, Object obj2, Object obj3) {
        mi0 mi0 = (mi0) obj;
        d10 d10 = (d10) obj2;
        ((Number) obj3).intValue();
        d10.W(-1525724089);
        obj = d10.L();
        if (obj == oj.a) {
            obj = new uj0();
            d10.g0(obj);
        }
        uj0 uj0 = (uj0) obj;
        mi0 b = p40.a(ji0.a, uj0, this.e).b(new bg(uj0, null, false, this.f, this.g, this.h));
        d10.p(false);
        return b;
    }

    public cg(t40 t40, boolean z, iy0 iy0, xz xzVar) {
        this.e = t40;
        this.f = z;
        this.g = iy0;
        this.h = xzVar;
    }
}