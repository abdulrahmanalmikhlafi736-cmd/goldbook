package defpackage;

import android.graphics.Insets;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: c60 */
public final class c60 {
    public static final c60 e = new c60(0, 0, 0, 0);
    public final int a;
    public final int b;
    public final int c;
    public final int d;

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null) {
            if (c60.class == obj.getClass()) {
                c60 c60 = (c60) obj;
                return this.d == c60.d && this.a == c60.a && this.c == c60.c && this.b == c60.b;
            }
        }
        return false;
    }

    public final String toString() {
        StringBuilder dl1 = new dl1("Insets{left=");
        dl1.append(this.a);
        dl1.append(", top=");
        dl1.append(this.b);
        dl1.append(", right=");
        dl1.append(this.c);
        dl1.append(", bottom=");
        return fu0.G(dl1, this.d, '}');
    }

    public static c60 a(c60 c60, c60 c602) {
        return c60.b(Math.max(c60.a, c602.a), Math.max(c60.b, c602.b), Math.max(c60.c, c602.c), Math.max(c60.d, c602.d));
    }

    public static c60 c(Insets insets) {
        return c60.b(insets.left, insets.top, insets.right, insets.bottom);
    }

    public final int hashCode() {
        return (((((this.a * 31) + this.b) * 31) + this.c) * 31) + this.d;
    }

    public static c60 b(int i, int i2, int i3, int i4) {
        return (i == 0 && i2 == 0 && i3 == 0 && i4 == 0) ? e : new c60(i, i2, i3, i4);
    }

    public final Insets d() {
        return zk.h(this.a, this.b, this.c, this.d);
    }

    public c60(int i, int i2, int i3, int i4) {
        this.a = i;
        this.b = i2;
        this.c = i3;
        this.d = i4;
    }
}