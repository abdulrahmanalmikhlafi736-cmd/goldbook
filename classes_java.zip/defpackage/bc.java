package defpackage;

import android.graphics.Rect;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bc */
public final class bc {
    public final int a;
    public final int b;
    public final int c;
    public final int d;

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(bc.class.getSimpleName());
        stringBuilder.append(" { [");
        stringBuilder.append(this.a);
        stringBuilder.append(',');
        stringBuilder.append(this.b);
        stringBuilder.append(',');
        stringBuilder.append(this.c);
        stringBuilder.append(',');
        stringBuilder.append(this.d);
        stringBuilder.append("] }");
        return stringBuilder.toString();
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!bc.class.equals(obj != null ? obj.getClass() : null)) {
            return false;
        }
        obj.getClass();
        bc bcVar = (bc) obj;
        return this.a == bcVar.a && this.b == bcVar.b && this.c == bcVar.c && this.d == bcVar.d;
    }

    public bc(int i, int i2, int i3, int i4) {
        this.a = i;
        this.b = i2;
        this.c = i3;
        this.d = i4;
        if (i > i3) {
            throw new dl1(fu0.D(i, i3, "Left must be less than or equal to right, left: ", ", right: ").toString());
        } else if (i2 > i4) {
            throw new dl1(fu0.D(i2, i4, "top must be less than or equal to bottom, top: ", ", bottom: ").toString());
        }
    }

    public final int hashCode() {
        return (((((this.a * 31) + this.b) * 31) + this.c) * 31) + this.d;
    }

    static {
        bc bcVar = new bc(0, 0, 0, 0);
    }

    public bc(Rect rect) {
        rect.getClass();
        this(rect.left, rect.top, rect.right, rect.bottom);
    }
}