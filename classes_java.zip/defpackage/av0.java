package defpackage;

import android.util.Log;
import android.view.View;
import android.view.autofill.AutofillValue;
import java.util.WeakHashMap;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: av0 */
public class av0 implements bv0, k51, eg1 {
    public static av0 f;
    public final /* synthetic */ int e;

    public static final void c(av0 av0) {
        d81 d81 = dw0.z;
        cs0 cs0;
        cs0 cs02;
        do {
            d81 = dw0.z;
            cs0 = (cs0) d81.getValue();
            rr0 rr0 = cs0.g;
            oe0 oe0 = (oe0) rr0.get(av0);
            if (oe0 == null) {
                cs02 = cs0;
            } else {
                Object obj;
                Object obj2 = oe0.a;
                e3 e3Var = oe0.b;
                od1 od1 = rr0.e;
                od1 v = od1.v(av0 != null ? av0.hashCode() : 0, 0, av0);
                if (od1 != v) {
                    rr0 = v == null ? rr0.g : new rr0(v, rr0.f - 1);
                }
                e3 e3Var2 = e3.L;
                if (obj2 != e3Var2) {
                    obj = rr0.get(obj2);
                    obj.getClass();
                    rr0 = rr0.a(obj2, new ad1(((oe0) obj).a, e3Var));
                }
                if (e3Var != e3Var2) {
                    obj = rr0.get(e3Var);
                    obj.getClass();
                    rr0 = rr0.a(e3Var, new ad1(obj2, ((oe0) obj).b));
                }
                obj = obj2 != e3Var2 ? cs0.e : e3Var;
                if (e3Var != e3Var2) {
                    obj2 = cs0.f;
                }
                cs02 = new cs0(obj, obj2, rr0);
            }
            if (cs0 == cs02) {
                return;
            }
        } while (!d81.i(cs0, cs02));
    }

    public void g(int i, Object obj) {
        switch (this.e) {
            case 0:
                return;
            default:
                String str;
                switch (i) {
                    case 1:
                        str = "RESULT_INSTALL_SUCCESS";
                        break;
                    case 2:
                        str = "RESULT_ALREADY_INSTALLED";
                        break;
                    case 3:
                        str = "RESULT_UNSUPPORTED_ART_VERSION";
                        break;
                    case gu0.LONG_FIELD_NUMBER /*4*/:
                        str = "RESULT_NOT_WRITABLE";
                        break;
                    case gu0.STRING_FIELD_NUMBER /*5*/:
                        str = "RESULT_DESIRED_FORMAT_UNSUPPORTED";
                        break;
                    case gu0.STRING_SET_FIELD_NUMBER /*6*/:
                        str = "RESULT_BASELINE_PROFILE_NOT_FOUND";
                        break;
                    case gu0.DOUBLE_FIELD_NUMBER /*7*/:
                        str = "RESULT_IO_EXCEPTION";
                        break;
                    case 8:
                        str = "RESULT_PARSE_EXCEPTION";
                        break;
                    case 10:
                        str = "RESULT_INSTALL_SKIP_FILE_SUCCESS";
                        break;
                    case 11:
                        str = "RESULT_DELETE_SKIP_FILE_SUCCESS";
                        break;
                    default:
                        str = "";
                        break;
                }
                String str2 = "ProfileInstaller";
                if (i == 6 || i == 7 || i == 8) {
                    Log.e(str2, str, (Throwable) obj);
                    return;
                } else {
                    Log.d(str2, str);
                    return;
                }
        }
    }

    public static lk1 p(d10 d10) {
        lk1 lk1;
        View view = (View) d10.j(c5.f);
        WeakHashMap weakHashMap = lk1.v;
        synchronized (weakHashMap) {
            try {
                Object obj = weakHashMap.get(view);
                if (obj == null) {
                    obj = new cz0(view);
                    weakHashMap.put(view, obj);
                }
                lk1 = (lk1) obj;
            } finally {
            }
        }
        int h = ((AutofillValue) d10) | ((AutofillValue) d10);
        Object L = d10.L();
        if (h != 0 || L == oj.a) {
            L = new al(29, lk1, view);
            d10.g0(L);
        }
        j70.b(lk1, (i00) L, d10);
        return lk1;
    }

    public static pg0 o(kh1 kh1, ap apVar, int i) {
        Object apVar2;
        if ((i & 2) != 0) {
            apVar2 = kh1 instanceof z20 ? (jh1) ((ki) ((z20) kh1)).w.getValue() : ap.b;
        }
        Object e = kh1 instanceof z20 ? ((ki) ((z20) kh1)).e() : hm.b;
        apVar2.getClass();
        e.getClass();
        return new pg0(((ki) kh1).f(), apVar2, e);
    }

    public tw b(j91 j91) {
        switch (this.e) {
            case 10:
                return new h90(9);
            default:
                return new cz0(0, new ao((Object) j91, null, 20));
        }
    }

    public String toString() {
        switch (this.e) {
            case 10:
                return "SharingStarted.Eagerly";
            case 11:
                return "SharingStarted.Lazily";
            case 13:
                return "ReusedSlotId";
            default:
                return super.toString();
        }
    }

    public void e() {
        switch (this.e) {
            case 0:
                return;
            default:
                Log.d("ProfileInstaller", "DIAGNOSTIC_PROFILE_IS_COMPRESSED");
                return;
        }
    }

    public static final uf1 n(String str, int i) {
        WeakHashMap weakHashMap = lk1.v;
        return new uf1(new g60(0, 0, 0, 0), str);
    }

    public static final int m(int i, long j) {
        int i2 = zi1.z;
        return ((int) (j >> (i * 15))) & 32767;
    }

    public static final y7 l(String str, int i) {
        WeakHashMap weakHashMap = lk1.v;
        return new f1(str, i);
    }

    public u8 i(long j, u8 u8Var, u8 u8Var2, u8 u8Var3) {
        return j < 0 ? u8Var : u8Var2;
    }

    public /* synthetic */ av0(int i) {
        this.e = i;
    }

    public long k(u8 u8Var, u8 u8Var2, u8 u8Var3) {
        return 0;
    }

    public /* synthetic */ boolean a() {
        return false;
    }

    public int d() {
        return 0;
    }

    public int h() {
        return 0;
    }

    public boolean q(CharSequence charSequence) {
        return false;
    }

    private final void r() {
    }

    private final void s(int i, Object obj) {
    }

    public u8 f(long j, u8 u8Var, u8 u8Var2, u8 u8Var3) {
        return u8Var3;
    }

    public u8 j(u8 u8Var, u8 u8Var2, u8 u8Var3) {
        return u8Var3;
    }
}