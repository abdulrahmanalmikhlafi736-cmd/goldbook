package defpackage;

import android.content.Context;
import android.graphics.Bitmap.Config;
import android.graphics.BlendMode;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.Region.Op;
import android.os.Build.VERSION;
import android.os.Trace;
import android.view.Display;
import android.view.RoundedCorner;
import android.view.View;
import android.view.ViewGroup;
import android.view.autofill.AutofillValue;
import java.lang.ref.Reference;
import java.lang.ref.WeakReference;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ConcurrentModificationException;
import java.util.List;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ac */
public abstract class ac {
    public static final gw0 A = new gw0(0.0f, 0.0f, 10.0f, 10.0f);
    public static final mt B = new f1("NONE", 1);
    public static final mt C = new f1("PENDING", 1);
    public static final zv D = new Object();
    public static y30 E;
    public static final int[] a = new int[]{16842755, 16843041, 16843093, 16843097, 16843551, 16843754, 16843771, 16843778, 16843779};
    public static final int[] b = new int[]{16842755, 16843189, 16843190, 16843556, 16843557, 16843558, 16843866, 16843867};
    public static final int[] c = new int[]{16842755, 16843780, 16843781, 16843782, 16843783, 16843784, 16843785, 16843786, 16843787, 16843788, 16843789, 16843979, 16843980, 16844062};
    public static final int[] d = new int[]{16842755, 16843781};
    public static final float[][] e;
    public static final float[][] f;
    public static final float[] g = new float[]{95.047f, 100.0f, 108.883f};
    public static final float[][] h;
    public static final pi i = new pi(-1837983555, false, new h90(8));
    public static final pi j = new pi(1116374984, false, new h90(9));
    public static final pi k = new pi(812517449, false, new h90(10));
    public static final mp l = new aj1(1.0f, 1.0f);
    public static final eh m = eh.j;
    public static final eh n = eh.g;
    public static final float o = 0.1f;
    public static final eh p = eh.h;
    public static final float q = 0.38f;
    public static final float r = 1.0f;
    public static final eh s = eh.e;
    public static final byte[] t = new byte[]{(byte) 48, (byte) 49, (byte) 53, (byte) 0};
    public static final byte[] u = new byte[]{(byte) 48, (byte) 49, (byte) 48, (byte) 0};
    public static final byte[] v = new byte[]{(byte) 48, (byte) 48, (byte) 57, (byte) 0};
    public static final byte[] w = new byte[]{(byte) 48, (byte) 48, (byte) 53, (byte) 0};
    public static final byte[] x = new byte[]{(byte) 48, (byte) 48, (byte) 49, (byte) 0};
    public static final byte[] y = new byte[]{(byte) 48, (byte) 48, (byte) 49, (byte) 0};
    public static final byte[] z = new byte[]{(byte) 48, (byte) 48, (byte) 50, (byte) 0};

    static {
        float[] fArr = new float[]{-0.250268f, 1.204414f, 0.045854f};
        float[] fArr2 = new float[]{-0.002079f, 0.048952f, 0.953127f};
        e = new float[][]{new float[]{0.401288f, 0.650173f, -0.051461f}, fArr, fArr2};
        float[] fArr3 = new float[]{0.38752654f, 0.62144744f, -0.00897398f};
        float[] fArr4 = new float[]{-0.0158415f, -0.03412294f, 1.0499644f};
        f = new float[][]{new float[]{1.8620678f, -1.0112547f, 0.14918678f}, fArr3, fArr4};
        fArr3 = new float[]{0.2126f, 0.7152f, 0.0722f};
        fArr4 = new float[]{0.01932141f, 0.11916382f, 0.9503448f};
        h = new float[][]{new float[]{0.41233894f, 0.35762063f, 0.18051042f}, fArr3, fArr4};
    }

    /* JADX WARNING: Removed duplicated region for block: B:43:0x00b8  */
    /* JADX WARNING: Removed duplicated region for block: B:50:0x00c7  */
    /* JADX WARNING: Removed duplicated region for block: B:55:0x00e9  */
    /* JADX WARNING: Removed duplicated region for block: B:70:0x014f  */
    /* JADX WARNING: Removed duplicated region for block: B:58:0x00ef  */
    /* JADX WARNING: Removed duplicated region for block: B:80:0x018d  */
    /* JADX WARNING: Removed duplicated region for block: B:16:0x004b  */
    /* JADX WARNING: Removed duplicated region for block: B:82:0x01a7  */
    /* JADX WARNING: Removed duplicated region for block: B:19:0x0054  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final void s(i00 i00, sj0 sj0, cz0 cz0, cz0 cz02, i21 i21, i21 i212) {
        Object obj;
        r60 F;
        i00 i002 = i00;
        sj0 sj02 = sj0;
        cz0 cz03 = cz0;
        i21 i213 = i21;
        i21 i214 = i212;
        int i = i213.f;
        Region region = (Region) cz03.f;
        cz0 cz04 = cz02;
        Region region2 = (Region) cz04.f;
        ba0 ba0 = i214.c;
        ba0 ba02 = i214.c;
        int i2 = i214.f;
        if (ba0.I()) {
            if (ba02.H()) {
                obj = null;
                if (!region2.isEmpty() || i2 == i) {
                    if (obj != null || i214.o()) {
                        F = zi1.F(i214.m());
                        cz03.n(F);
                        if (i2 == i) {
                            i2 = -1;
                        }
                        if (!region.op(region2, Op.INTERSECT)) {
                            Object obj2;
                            Rect bounds = region.getBounds();
                            sj02.h(i2, new k21(i214, new r60(bounds.left, bounds.top, bounds.right, bounds.bottom)));
                            List j = i21.j(4, i214);
                            if (i214.d.g) {
                                n90 n90;
                                i21 l = i214.l();
                                while (true) {
                                    n90 = null;
                                    if (l == null) {
                                        l = null;
                                        break;
                                    }
                                    hk0 hk0 = l.d.e;
                                    if (hk0.c(n21.w) != null) {
                                        break;
                                    } else if (hk0.c(n21.v) != null) {
                                        break;
                                    } else {
                                        l = l.l();
                                    }
                                }
                                if (l != null) {
                                    gm0 d;
                                    n90 d2 = i214.d();
                                    if (d2 != null) {
                                        if (!d2.y0().r) {
                                            d2 = null;
                                        }
                                        if (d2 != null) {
                                            d = l.d();
                                            if (d != null) {
                                                if (!d.y0().r) {
                                                    d = null;
                                                }
                                                if (d != null) {
                                                    n90 = d;
                                                }
                                            }
                                            if (d2 != null) {
                                                if (n90 != null) {
                                                    gw0 z = n90.z(d2, false);
                                                    i = z.equals(z.c(ua0.d(0, wl1.M(n90.g)))) ^ 1;
                                                    if (i != 0) {
                                                        obj2 = 1;
                                                        cz0 h90;
                                                        if (obj2 == null) {
                                                            gw0 z2;
                                                            h90 = new h90(1);
                                                            g21 f = i214.f();
                                                            if (f == null) {
                                                                v50 v50 = ba02.J.c;
                                                                z2 = k70.D(v50).z(v50, false);
                                                            } else {
                                                                z2 = jb0.h(((li0) f).e, false, false);
                                                            }
                                                            h90.n(zi1.F(z2));
                                                            int size = j.size() - 1;
                                                            while (-1 < size) {
                                                                if (!((Boolean) i002.i(j.get(size))).booleanValue()) {
                                                                    sj02 = sj0;
                                                                    ac.r(i002, sj02, new h90(1), h90, i213, (i21) j.get(size));
                                                                }
                                                                size--;
                                                                i213 = i21;
                                                            }
                                                        } else {
                                                            int size2 = j.size() - 1;
                                                            while (-1 < size2) {
                                                                if (((Boolean) i002.i(j.get(size2))).booleanValue()) {
                                                                    sj02 = sj0;
                                                                    i213 = i21;
                                                                } else {
                                                                    h90 = cz04;
                                                                    ac.s(i002, sj0, cz0, h90, i21, (i21) j.get(size2));
                                                                }
                                                                size2--;
                                                                i002 = i00;
                                                                cz04 = cz02;
                                                            }
                                                        }
                                                        if (ac.z(i214)) {
                                                            Region region3 = region2;
                                                            region3.op(F.a, F.b, F.c, F.d, Op.DIFFERENCE);
                                                            return;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    d2 = null;
                                    d = l.d();
                                    if (d != null) {
                                    }
                                    if (d2 != null) {
                                    }
                                }
                                i = 0;
                                if (i != 0) {
                                }
                            }
                            obj2 = null;
                            if (obj2 == null) {
                            }
                            if (ac.z(i214)) {
                            }
                        } else if (i214.o()) {
                            ac.q(sj02, i213, i214);
                            return;
                        } else if (i2 == -1) {
                            Rect bounds2 = region.getBounds();
                            sj02.h(i2, new k21(i214, new r60(bounds2.left, bounds2.top, bounds2.right, bounds2.bottom)));
                        }
                    }
                }
            }
        }
        obj = 1;
        if (obj != null) {
        }
        F = zi1.F(i214.m());
        cz03.n(F);
        if (i2 == i) {
        }
        if (!region.op(region2, Op.INTERSECT)) {
        }
    }

    public static final BlendMode H(int i) {
        if (i == 0) {
            return BlendMode.CLEAR;
        }
        if (i == 1) {
            return BlendMode.SRC;
        }
        if (i == 2) {
            return BlendMode.DST;
        }
        if (i == 3) {
            return BlendMode.SRC_OVER;
        }
        if (i == 4) {
            return BlendMode.DST_OVER;
        }
        if (i == 5) {
            return BlendMode.SRC_IN;
        }
        if (i == 6) {
            return BlendMode.DST_IN;
        }
        if (i == 7) {
            return BlendMode.SRC_OUT;
        }
        if (i == 8) {
            return BlendMode.DST_OUT;
        }
        if (i == 9) {
            return BlendMode.SRC_ATOP;
        }
        if (i == 10) {
            return BlendMode.DST_ATOP;
        }
        if (i == 11) {
            return BlendMode.XOR;
        }
        if (i == 12) {
            return BlendMode.PLUS;
        }
        if (i == 13) {
            return BlendMode.MODULATE;
        }
        if (i == 14) {
            return BlendMode.SCREEN;
        }
        if (i == 15) {
            return BlendMode.OVERLAY;
        }
        if (i == 16) {
            return BlendMode.DARKEN;
        }
        if (i == 17) {
            return BlendMode.LIGHTEN;
        }
        if (i == 18) {
            return BlendMode.COLOR_DODGE;
        }
        if (i == 19) {
            return BlendMode.COLOR_BURN;
        }
        if (i == 20) {
            return BlendMode.HARD_LIGHT;
        }
        if (i == 21) {
            return BlendMode.SOFT_LIGHT;
        }
        if (i == 22) {
            return BlendMode.DIFFERENCE;
        }
        if (i == 23) {
            return BlendMode.EXCLUSION;
        }
        if (i == 24) {
            return BlendMode.MULTIPLY;
        }
        if (i == 25) {
            return BlendMode.HUE;
        }
        if (i == 26) {
            return BlendMode.SATURATION;
        }
        if (i == 27) {
            return BlendMode.COLOR;
        }
        return i == 28 ? BlendMode.LUMINOSITY : BlendMode.SRC_OVER;
    }

    public static final void r(i00 i00, sj0 sj0, cz0 cz0, cz0 cz02, i21 i21, i21 i212) {
        sj0 sj02 = sj0;
        cz0 cz03 = cz0;
        i21 i213 = i21;
        i21 i214 = i212;
        Region region = (Region) cz03.f;
        cz0 cz04 = cz02;
        Region region2 = (Region) cz04.f;
        ba0 ba0 = i214.c;
        ba0 ba02 = i214.c;
        if (ba0.I() && ba02.H()) {
            if (!region2.isEmpty()) {
                gw0 z;
                g21 f = i214.f();
                if (f == null) {
                    v50 v50 = ba02.J.c;
                    z = k70.D(v50).z(v50, false);
                } else {
                    z = jb0.h(((li0) f).e, false, false);
                }
                r60 F = zi1.F(z);
                cz03.n(F);
                if (region.op(region2, Op.INTERSECT)) {
                    int i = i214.f;
                    if (i == i213.f) {
                        i = -1;
                    }
                    Rect bounds = region.getBounds();
                    sj02.h(i, new k21(i214, new r60(bounds.left, bounds.top, bounds.right, bounds.bottom)));
                    List j = i21.j(4, i214);
                    int size = j.size() - 1;
                    while (-1 < size) {
                        i00 i002 = i00;
                        if (!((Boolean) i002.i(j.get(size))).booleanValue()) {
                            ac.r(i002, sj02, cz03, cz04, i213, (i21) j.get(size));
                        }
                        size--;
                        cz03 = cz0;
                        cz04 = cz02;
                    }
                    if (ac.z(i214)) {
                        Region region3 = region2;
                        region3.op(F.a, F.b, F.c, F.d, Op.DIFFERENCE);
                        return;
                    }
                }
            }
        }
        if (i214.o()) {
            ac.q(sj02, i213, i214);
        }
    }

    public static final void a(wp0 wp0, mi0 mi0, nb nbVar, vj vjVar, float f, d10 d10, int i) {
        d10.X(1142754848);
        int i2 = ((((AutofillValue) d10) != null ? 4 : 2) | i) | 1797120;
        if (d10.O(i2 & 1, (599187 & i2) != 599186)) {
            nbVar = e3.j;
            d10.W(1899381698);
            d10.p(false);
            f = 1.0f;
            mi0 N = vn.N(k70.G(mi0.b(ji0.a), 0.0f, null, true, 520191), wp0, 1.0f, null, 2);
            Object L = d10.L();
            if (L == oj.a) {
                L = p5.f;
                d10.g0(L);
            }
            mh0 mh0 = (mh0) L;
            long j = d10.T;
            int i3 = (int) (j ^ (j >>> 32));
            N = vn.I(d10, N);
            qr0 l = d10.l();
            ij.c.getClass();
            dk dkVar = hj.b;
            d10.Z();
            if (d10.S) {
                d10.k(dkVar);
            } else {
                d10.j0();
            }
            mc0.B(hj.f, d10, mh0);
            mc0.B(hj.e, d10, l);
            mc0.w(d10, hj.h);
            mc0.B(hj.d, d10, N);
            mc0.p(d10, Integer.valueOf(i3), hj.g);
            d10.p(true);
            vjVar = hl.a;
        } else {
            d10.R();
        }
        nb nbVar2 = nbVar;
        vj vjVar2 = vjVar;
        float f2 = f;
        xv0 r = d10.r();
        if (r != null) {
            r.d = new v30(wp0, mi0, nbVar2, vjVar2, f2, i);
        }
    }

    public static final Mode J(int i) {
        if (i == 0) {
            return Mode.CLEAR;
        }
        if (i == 1) {
            return Mode.SRC;
        }
        if (i == 2) {
            return Mode.DST;
        }
        if (i == 3) {
            return Mode.SRC_OVER;
        }
        if (i == 4) {
            return Mode.DST_OVER;
        }
        if (i == 5) {
            return Mode.SRC_IN;
        }
        if (i == 6) {
            return Mode.DST_IN;
        }
        if (i == 7) {
            return Mode.SRC_OUT;
        }
        if (i == 8) {
            return Mode.DST_OUT;
        }
        if (i == 9) {
            return Mode.SRC_ATOP;
        }
        if (i == 10) {
            return Mode.DST_ATOP;
        }
        if (i == 11) {
            return Mode.XOR;
        }
        if (i == 12) {
            return Mode.ADD;
        }
        if (i == 14) {
            return Mode.SCREEN;
        }
        if (i == 15) {
            return Mode.OVERLAY;
        }
        if (i == 16) {
            return Mode.DARKEN;
        }
        if (i == 17) {
            return Mode.LIGHTEN;
        }
        return i == 13 ? Mode.MULTIPLY : Mode.SRC_OVER;
    }

    public static String K(long j) {
        int i = (int) (j >> 32);
        int i2 = (int) (j & 4294967295L);
        if (Float.intBitsToFloat(i) == Float.intBitsToFloat(i2)) {
            StringBuilder dl1 = new dl1("CornerRadius.circular(");
            dl1.append(vn.U(Float.intBitsToFloat(i)));
            dl1.append(')');
            return dl1.toString();
        }
        StringBuilder dl12 = new dl1("CornerRadius.elliptical(");
        dl12.append(vn.U(Float.intBitsToFloat(i)));
        dl12.append(", ");
        dl12.append(vn.U(Float.intBitsToFloat(i2)));
        dl12.append(')');
        return dl12.toString();
    }

    public static final boolean z(i21 i21) {
        if (!ac.y(i21)) {
            d21 d21 = i21.d;
            if (!d21.g) {
                hk0 hk0 = d21.e;
                Object[] objArr = hk0.b;
                Object[] objArr2 = hk0.c;
                long[] jArr = hk0.a;
                int length = jArr.length - 2;
                if (length >= 0) {
                    int i = 0;
                    loop0:
                    while (true) {
                        long j = jArr[i];
                        if (((((~j) << 7) & j) & -9187201950435737472L) != -9187201950435737472L) {
                            int i2 = 8 - ((~(i - length)) >>> 31);
                            for (int i3 = 0; i3 < i2; i3++) {
                                if ((255 & j) < 128) {
                                    int i4 = (i << 3) + i3;
                                    Object obj = objArr[i4];
                                    Object obj2 = objArr2[i4];
                                    if (((q21) obj).c) {
                                        break loop0;
                                    }
                                }
                                j >>= 8;
                            }
                            if (i2 != 8) {
                                break;
                            }
                        }
                        if (i == length) {
                            break;
                        }
                        i++;
                    }
                }
            }
            return true;
        }
        return false;
    }

    public static final View g(o oVar) {
        if (!oVar.isAttachedToWindow()) {
            return oVar;
        }
        int min = Math.min(ac.o(oVar, 2131034229), ac.o(oVar, 2131034232));
        View view = oVar;
        int i = 0;
        View view2 = view;
        View oVar2;
        while (oVar2 != null) {
            if (i != min) {
                Object tag = oVar2.getTag(2131034154);
                Reference reference = tag instanceof WeakReference ? (WeakReference) tag : null;
                if ((reference != null ? (mj) reference.get() : null) == null) {
                    i++;
                    kh1 j = jb0.j(oVar2);
                    View view3 = view;
                    view = oVar2;
                    oVar2 = j instanceof View ? (View) j : null;
                    view2 = view3;
                }
            } else if (!(oVar2.getParent() instanceof ViewGroup)) {
                return view;
            }
            return oVar2;
        }
        return view2;
    }

    public static int w(float f) {
        if (f < 1.0f) {
            return -16777216;
        }
        if (f > 99.0f) {
            return -1;
        }
        float f2 = (f + 16.0f) / 116.0f;
        f = f > 8.0f ? (f2 * f2) * f2 : f / 903.2963f;
        float f3 = (f2 * f2) * f2;
        int i = f3 > 0.008856452f ? 1 : 0;
        float f4 = i != 0 ? f3 : ((f2 * 116.0f) - 16.0f) / 903.2963f;
        if (i == 0) {
            f3 = ((f2 * 116.0f) - 16.0f) / 903.2963f;
        }
        float[] fArr = g;
        return mh.a((double) (f4 * fArr[0]), (double) (f * fArr[1]), (double) (f3 * fArr[2]));
    }

    public static final int v(aa aaVar, Object obj, int i) {
        int i2 = aaVar.g;
        if (i2 == 0) {
            return -1;
        }
        try {
            int r = k70.r(aaVar.e, i2, i);
            if (r >= 0) {
                if (!k70.p(obj, aaVar.f[r])) {
                    int i3 = r + 1;
                    while (i3 < i2 && aaVar.e[i3] == i) {
                        if (k70.p(obj, aaVar.f[i3])) {
                            return i3;
                        }
                        i3++;
                    }
                    r--;
                    while (r >= 0 && aaVar.e[r] == i) {
                        if (k70.p(obj, aaVar.f[r])) {
                            return r;
                        }
                        r--;
                    }
                    return ~i3;
                }
            }
            return r;
        } catch (IndexOutOfBoundsException unused) {
            throw new ConcurrentModificationException();
        }
    }

    public static final sj0 p(l21 l21, i00 i00) {
        Trace.beginSection("getAllUncoveredSemanticsNodesToIntObjectMap");
        try {
            i21 a = l21.a();
            ba0 ba0 = a.c;
            if (ba0.I()) {
                if (ba0.H()) {
                    gw0 g = a.g();
                    sj0 h90 = new h90(48);
                    cz0 h902 = new h90(1);
                    h902.n(zi1.F(g));
                    ac.s(i00, h90, new h90(1), h902, a, a);
                    Trace.endSection();
                    return h90;
                }
            }
            sj0 sj0 = m60.a;
            sj0.getClass();
            Trace.endSection();
            return sj0;
        } catch (Throwable th) {
            Throwable th2 = th;
            Trace.endSection();
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:15:0x0030  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x001f  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final Object h(dc1 dc1, en enVar, Throwable th, nl nlVar) {
        ww wwVar;
        int i;
        Object obj;
        if (nlVar instanceof ww) {
            wwVar = (ww) nlVar;
            i = wwVar.j;
            if ((i & Integer.MIN_VALUE) != 0) {
                wwVar.j = i - Integer.MIN_VALUE;
                obj = wwVar.i;
                i = wwVar.j;
                if (i != 0) {
                    nb0.t(obj);
                    wwVar.h = th;
                    wwVar.j = 1;
                    cm c = enVar.c(dc1, th, wwVar);
                    cm cmVar = cm.e;
                    if (c == cmVar) {
                        return cmVar;
                    }
                } else if (i == 1) {
                    th = wwVar.h;
                    try {
                        nb0.t(obj);
                    } catch (Throwable th2) {
                        if (!(th == null || th == th2)) {
                            ac.i(th2, th);
                        }
                    }
                } else {
                    od.p("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                return we1.a;
            }
        }
        wwVar = new db(nlVar);
        obj = wwVar.i;
        i = wwVar.j;
        if (i != 0) {
        }
        return we1.a;
    }

    public static ny0 u(Display display, int i) {
        if (VERSION.SDK_INT >= 31) {
            RoundedCorner g = display.getRoundedCorner(i);
            if (g != null) {
                int i2;
                int c = g.getPosition();
                if (c != 0) {
                    i2 = 1;
                    if (c != 1) {
                        i2 = 2;
                        if (c != 2) {
                            i2 = 3;
                            if (c != 3) {
                                od.m(fu0.E("Invalid position: ", c));
                                return null;
                            }
                        }
                    }
                } else {
                    i2 = 0;
                }
                return new ny0(i2, g.getRadius(), g.getCenter());
            }
        }
        return null;
    }

    public static final Config I(int i) {
        if (i == 0) {
            return Config.ARGB_8888;
        }
        if (i == 1) {
            return Config.ALPHA_8;
        }
        if (i == 2) {
            return Config.RGB_565;
        }
        int i2 = VERSION.SDK_INT;
        if (i2 < 26 || i != 3) {
            return (i2 < 26 || i != 4) ? Config.ARGB_8888 : Config.HARDWARE;
        } else {
            return Config.RGBA_F16;
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:12:0x0020  */
    /* JADX WARNING: Removed duplicated region for block: B:10:0x001c  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static void i(Throwable th, Throwable th2) {
        th.getClass();
        th2.getClass();
        if (th != th2) {
            int i;
            Integer num = x70.a;
            if (num != null) {
                if (num.intValue() < 19) {
                    i = 0;
                    if (i == 0) {
                        th.addSuppressed(th2);
                        return;
                    }
                    Method method = os0.a;
                    if (method != null) {
                        method.invoke(th, new Object[]{th2});
                    }
                }
            }
            i = 1;
            if (i == 0) {
            }
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:10:0x001e  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final void q(sj0 sj0, i21 i21, i21 i212) {
        gw0 g;
        int i;
        i21 l = i212.l();
        if (l != null) {
            ba0 ba0 = l.c;
            if (ba0 != null && ba0.I()) {
                g = l.g();
                i = i212.f;
                if (i == i21.f) {
                    i = -1;
                }
                sj0.h(i, new k21(i212, zi1.F(g)));
            }
        }
        g = A;
        i = i212.f;
        if (i == i21.f) {
        }
        sj0.h(i, new k21(i212, zi1.F(g)));
    }

    public static ml x(ml mlVar) {
        mlVar.getClass();
        nl nlVar = mlVar instanceof nl ? (nl) mlVar : null;
        if (nlVar != null) {
            mlVar = nlVar.g;
            if (mlVar == null) {
                ul ulVar = (ul) nlVar.e().k(e3.B);
                ml gqVar = ulVar != null ? new gq(ulVar, nlVar) : nlVar;
                nlVar.g = gqVar;
                return gqVar;
            }
        }
        return mlVar;
    }

    public static final int o(o oVar, int i) {
        int i2 = 0;
        int i3 = Integer.MAX_VALUE;
        Object obj = null;
        View oVar2;
        while (oVar2 != null) {
            Object tag = oVar2.getTag(i);
            if (tag != null) {
                if (obj != null) {
                    if (!tag.equals(obj)) {
                        break;
                    }
                }
                obj = tag;
                i3 = i2;
            }
            i2++;
            kh1 j = jb0.j(oVar2);
            oVar2 = j instanceof View ? (View) j : null;
        }
        return i3;
    }

    public static float B(int i) {
        float f = ((float) i) / 255.0f;
        return (f <= 0.04045f ? f / 12.92f : (float) Math.pow((double) ((f + 0.055f) / 1.055f), 2.4000000953674316d)) * 100.0f;
    }

    public static final boolean y(i21 i21) {
        gm0 d = i21.d();
        hk0 hk0 = i21.d.e;
        if (!(d != null ? d.G0() : false) && hk0.c(n21.q) == null) {
            if (hk0.c(n21.p) == null) {
                return false;
            }
        }
        return true;
    }

    public static final int M(float f, float[] fArr, int i) {
        float f2 = 0.0f;
        if (f >= 0.0f) {
            f2 = f;
        }
        if (f2 > 1.0f) {
            f2 = 1.0f;
        }
        if (Math.abs(f2 - f) > 1.05E-6f) {
            f2 = Float.NaN;
        }
        fArr[i] = f2;
        return Float.isNaN(f2) ^ 1;
    }

    public static ml m(ml mlVar, ml mlVar2, m00 m00) {
        m00.getClass();
        if (m00 instanceof db) {
            return ((db) m00).n(mlVar2, mlVar);
        }
        sl e = mlVar2.e();
        return e == st.e ? new l70(mlVar2, mlVar, m00) : new m70(mlVar2, e, m00, mlVar);
    }

    public static final void l(long j, bp0 bp0) {
        if (bp0 == bp0.e) {
            if (sk.g(j) == Integer.MAX_VALUE) {
                s50.c("Vertically scrollable component was measured with an infinity maximum height constraints, which is disallowed. One of the common reasons is nesting layouts like LazyColumn and Column(Modifier.verticalScroll()). If you want to add a header before the list of items please add a header as a separate item() before the main items() inside the LazyColumn scope. There could be other reasons for this to happen: your ComposeView was added into a LinearLayout with some weight, you applied Modifier.wrapContentSize(unbounded = true) or wrote a custom layout. Please try to remove the source of infinite constraints in the hierarchy above the scrolling container.");
            }
        } else if (sk.h(j) == Integer.MAX_VALUE) {
            s50.c("Horizontally scrollable component was measured with an infinity maximum width constraints, which is disallowed. One of the common reasons is nesting layouts like LazyRow and Row(Modifier.horizontalScroll()). If you want to add a header before the list of items please add a header as a separate item() before the main items() inside the LazyRow scope. There could be other reasons for this to happen: your ComposeView was added into a LinearLayout with some weight, you applied Modifier.wrapContentSize(unbounded = true) or wrote a custom layout. Please try to remove the source of infinite constraints in the hierarchy above the scrolling container.");
        }
    }

    public static Object L(m00 m00, Object obj, ml mlVar) {
        m00.getClass();
        sl e = mlVar.e();
        Object dbVar = e == st.e ? new db(mlVar) : new nl(mlVar, e);
        vd1.e(2, m00);
        return m00.f(obj, dbVar);
    }

    public static mi0 G(mi0 mi0, float f, float f2, float f3, float f4, int i) {
        if ((i & 1) != 0) {
            f = 0.0f;
        }
        if ((i & 2) != 0) {
            f2 = 0.0f;
        }
        if ((i & 4) != 0) {
            f3 = 0.0f;
        }
        if ((i & 8) != 0) {
            f4 = 0.0f;
        }
        return mi0.b(new qp0(f, f2, f3, f4));
    }

    public static Object k(Class cls, InvocationHandler invocationHandler) {
        if (invocationHandler == null) {
            return null;
        }
        return cls.cast(Proxy.newProxyInstance(ac.class.getClassLoader(), new Class[]{cls}, invocationHandler));
    }

    public static mi0 F(mi0 mi0, float f, int i) {
        float f2 = 0.0f;
        if ((i & 1) != 0) {
            f = 0.0f;
        }
        if ((i & 2) == 0) {
            f2 = 16.0f;
        }
        return ac.E(mi0, f, f2);
    }

    public static final y00 j(y00 y00) {
        if (y00 == null) {
            y00 = null;
        }
        if (y00 != null) {
            return y00;
        }
        a5.b("Inconsistent composition");
        throw new RuntimeException();
    }

    public static long t(Context context, int i) {
        return wl1.d(context.getResources().getColor(i, context.getTheme()));
    }

    public static float N() {
        return ((float) Math.pow(0.5689655172413793d, 3.0d)) * 100.0f;
    }

    public static up0 d(int i) {
        float f = (i & 1) != 0 ? 0.0f : 14.0f;
        return new up0(f, 0.0f, f, 0.0f);
    }

    public static final mi0 C(mi0 mi0, sp0 sp0) {
        return mi0.b(new tp0(sp0));
    }

    public static final mi0 D(mi0 mi0, float f) {
        return mi0.b(new qp0(f, f, f, f));
    }

    public static final mi0 E(mi0 mi0, float f, float f2) {
        return mi0.b(new qp0(f, f2, f, f2));
    }

    public static final d81 c(Object obj) {
        if (obj == null) {
            obj = wl1.k;
        }
        return new d81(obj);
    }

    public static final boolean n(long j, long j2) {
        return j == j2;
    }

    public static final long b(int i) {
        long j = ((long) i) << 32;
        i = d90.p;
        return j;
    }

    public static up0 f(float f) {
        return new up0(0.0f, 0.0f, 0.0f, f);
    }

    public static final mi0 A(ec0 ec0, sc scVar, bp0 bp0) {
        return new ya0(ec0, scVar, bp0);
    }

    public static final up0 e(float f, float f2, float f3, float f4) {
        return new up0(f, f2, f3, f4);
    }
}