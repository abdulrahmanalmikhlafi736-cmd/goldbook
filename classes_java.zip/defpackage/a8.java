package defpackage;

import java.util.concurrent.CancellationException;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: a8 */
public final class a8 extends u91 implements i00 {
    public p8 i;
    public jw0 j;
    public int k;
    public final /* synthetic */ c8 l;
    public final /* synthetic */ Object m;
    public final /* synthetic */ ja1 n;
    public final /* synthetic */ long o;

    public final Object p(Object obj) {
        p8 p8Var;
        jw0 jw0;
        ja1 ja1 = this.n;
        int i = this.k;
        Object obj2 = this.l;
        if (i == 0) {
            nb0.t(obj);
            obj2.c.g = (u8) obj2.a.a.i(this.m);
            obj2.e.setValue(ja1.c);
            obj2.d.setValue(Boolean.TRUE);
            p8 p8Var2 = obj2.c;
            p8Var2 = new p8(p8Var2.e, p8Var2.f.getValue(), a5.n(p8Var2.g), p8Var2.h, Long.MIN_VALUE, p8Var2.j);
            jw0 obj3 = new Object();
            long j = this.o;
            z7 z7Var = new z7(obj2, (Object) p8Var2, (Object) obj3, 0);
            this.i = p8Var2;
            this.j = obj3;
            this.k = 1;
            cm b = wa0.b(p8Var2, ja1, j, z7Var, this);
            cm cmVar = cm.e;
            if (b == cmVar) {
                return cmVar;
            }
            p8Var = p8Var2;
            jw0 = obj3;
        } else if (i == 1) {
            jw0 = this.j;
            p8Var = this.i;
            try {
                nb0.t(obj);
            } catch (CancellationException e) {
                c8.b(obj2);
                throw e;
            }
        } else {
            od.p("call to 'resume' before 'invoke' with coroutine");
            return null;
        }
        l8 l8Var = jw0.e ? l8.e : l8.f;
        c8.b(obj2);
        return new m8(p8Var, l8Var);
    }

    public final Object i(Object obj) {
        ml mlVar = (ml) obj;
        return new a8(this.l, this.m, this.n, this.o, mlVar).p(we1.a);
    }

    public a8(c8 c8Var, Object obj, ja1 ja1, long j, ml mlVar) {
        this.l = c8Var;
        this.m = obj;
        this.n = ja1;
        this.o = j;
        super(1, mlVar);
    }
}