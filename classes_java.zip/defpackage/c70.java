package defpackage;

import java.util.List;
import java.util.RandomAccess;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: c70 */
public interface c70 extends List, RandomAccess {
}