package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: xo0 */
public abstract class xo0 {
    public final int a;
    public final int b;

    public final String toString() {
        String b = jh1.a(getClass()).b();
        return b == null ? "" : b;
    }

    public /* synthetic */ xo0(int i, int i2, int i3) {
        if ((i3 & 1) != 0) {
            i = 0;
        }
        if ((i3 & 2) != 0) {
            i2 = 0;
        }
        this(i, i2);
    }

    public y00 b(pg pgVar) {
        return null;
    }

    public xo0(int i, int i2) {
        this.a = i;
        this.b = i2;
    }

    public abstract void a(pg pgVar, m9 m9Var, a61 a61, uw0 uw0, yo0 yo0);
}