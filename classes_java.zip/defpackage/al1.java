package defpackage;

import android.content.ContentResolver;
import android.content.Context;
import android.net.Uri;
import android.provider.Settings.Global;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: al1 */
public final class al1 extends u91 implements m00 {
    public hd i;
    public int j;
    public /* synthetic */ Object k;
    public final /* synthetic */ ContentResolver l;
    public final /* synthetic */ Uri m;
    public final /* synthetic */ bl1 n;
    public final /* synthetic */ id o;
    public final /* synthetic */ Context p;

    /* JADX WARNING: Removed duplicated region for block: B:23:0x005c  */
    /* JADX WARNING: Removed duplicated region for block: B:20:0x0050  */
    /* JADX WARNING: Missing block: B:24:0x007c, code:
            if (r6.k(r7, r10) == r5) goto L_0x007e;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final Object p(Object obj) {
        uw uwVar;
        hd hdVar;
        cm b;
        uw uwVar2;
        hd hdVar2;
        int i = this.j;
        bl1 bl1 = this.n;
        ContentResolver contentResolver = this.l;
        cm cmVar = cm.e;
        if (i == 0) {
            nb0.t(obj);
            uwVar = (uw) this.k;
            contentResolver.registerContentObserver(this.m, false, bl1);
            hdVar = new hd(this.o);
            this.k = uwVar;
            this.i = hdVar;
            this.j = 1;
            b = hdVar.b(this);
            if (b == cmVar) {
                hd hdVar3 = hdVar;
                uwVar2 = uwVar;
                obj = b;
                hdVar2 = hdVar3;
                if (!((Boolean) obj).booleanValue()) {
                    contentResolver.unregisterContentObserver(bl1);
                }
                contentResolver.unregisterContentObserver(bl1);
                return we1.a;
            }
            return cmVar;
        } else if (i == 1) {
            hdVar2 = this.i;
            uwVar2 = (uw) this.k;
            nb0.t(obj);
            if (!((Boolean) obj).booleanValue()) {
                hdVar2.c();
                Float br0 = new br0(Global.getFloat(this.p.getContentResolver(), "animator_duration_scale", 1.0f));
                this.k = uwVar2;
                this.i = hdVar2;
                this.j = 2;
            }
            contentResolver.unregisterContentObserver(bl1);
            return we1.a;
        } else if (i == 2) {
            hdVar2 = this.i;
            uwVar2 = (uw) this.k;
            try {
                nb0.t(obj);
            } catch (Throwable th) {
                contentResolver.unregisterContentObserver(bl1);
            }
        } else {
            od.p("call to 'resume' before 'invoke' with coroutine");
            return null;
        }
        uwVar = uwVar2;
        hdVar = hdVar2;
        this.k = uwVar;
        this.i = hdVar;
        this.j = 1;
        b = hdVar.b(this);
        if (b == cmVar) {
        }
        return cmVar;
    }

    public final ml n(ml mlVar, Object obj) {
        al1 al1 = new al1(this.l, this.m, this.n, this.o, this.p, mlVar);
        al1.k = obj;
        return al1;
    }

    public final Object f(Object obj, Object obj2) {
        return ((al1) n((ml) obj2, (uw) obj)).p(we1.a);
    }

    public al1(ContentResolver contentResolver, Uri uri, bl1 bl1, id idVar, Context context, ml mlVar) {
        this.l = contentResolver;
        this.m = uri;
        this.n = bl1;
        this.o = idVar;
        this.p = context;
        super(2, mlVar);
    }
}