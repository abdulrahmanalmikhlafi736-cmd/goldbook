package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: aw */
public final class aw extends ks0 {
    public final /* synthetic */ int j;

    public aw(int i, int i2, int i3) {
        this.j = i3;
        switch (i3) {
            case 1:
                S((((long) i2) & 4294967295L) | (((long) i) << 32));
                return;
            default:
                S((((long) i2) & 4294967295L) | (((long) i) << 32));
                return;
        }
    }

    public final void R(long j, float f, i00 i00) {
        int i = this.j;
    }

    private final void U(long j, float f, i00 i00) {
    }

    private final void W(long j, float f, i00 i00) {
    }
}