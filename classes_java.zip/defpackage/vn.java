package defpackage;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.ProviderInfo;
import android.content.pm.ResolveInfo;
import android.content.pm.Signature;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.os.Build.VERSION;
import android.text.Layout;
import android.text.Layout.Alignment;
import android.util.Log;
import android.view.autofill.AutofillManager$AutofillCallback;
import android.view.autofill.AutofillValue;
import androidx.core.content.FileProvider;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: vn */
public abstract class vn {
    public static final nq0 a = new h90(18);
    public static final float[][] b;
    public static final float[][] c;
    public static final float[] d = new float[]{95.047f, 100.0f, 108.883f};
    public static final double[][] e;
    public static final double[][] f;
    public static final Object g = new Object();
    public static final v6 h = new h90(2);
    public static final v6 i = new h90(5);
    public static final k30 j = new h90(2);
    public static final av0 k = new h90(9);
    public static final av0 l = new h90(13);
    public static final Object m = new Object();
    public static y30 n;
    public static y30 o;

    public static final boolean C(float[] fArr, float[] fArr2) {
        float[] fArr3 = fArr;
        float[] fArr4 = fArr2;
        if (fArr3.length < 16 || fArr4.length < 16) {
            return false;
        }
        float f = fArr3[0];
        float f2 = fArr3[1];
        float f3 = fArr3[2];
        float f4 = fArr3[3];
        float f5 = fArr3[4];
        float f6 = fArr3[5];
        float f7 = fArr3[6];
        float f8 = fArr3[7];
        int i = 0;
        float f9 = fArr3[8];
        int i2 = 1;
        float f10 = fArr3[9];
        float f11 = fArr3[10];
        float f12 = fArr3[11];
        int i3 = 2;
        float f13 = fArr3[12];
        float f14 = fArr3[13];
        float f15 = fArr3[14];
        float f16 = fArr3[15];
        float f17 = (f * f6) - (f2 * f5);
        float f18 = (f * f7) - (f3 * f5);
        float f19 = (f * f8) - (f4 * f5);
        float f20 = (f2 * f7) - (f3 * f6);
        float f21 = (f2 * f8) - (f4 * f6);
        float f22 = (f3 * f8) - (f4 * f7);
        float f23 = (f9 * f14) - (f10 * f13);
        float f24 = (f9 * f15) - (f11 * f13);
        float f25 = (f9 * f16) - (f12 * f13);
        float f26 = (f10 * f15) - (f11 * f14);
        float f27 = (f10 * f16) - (f12 * f14);
        float f28 = (f11 * f16) - (f12 * f15);
        float f29 = (f22 * f23) + (((f20 * f25) + ((f19 * f26) + ((f17 * f28) - (f18 * f27)))) - (f21 * f24));
        int i4 = (f29 > 0.0f ? 1 : (f29 == 0.0f ? 0 : -1));
        if (i4 != 0) {
            float f30 = 1.0f / f29;
            fArr4[i] = ((f8 * f26) + ((f6 * f28) - (f7 * f27))) * f30;
            int i5 = 3;
            fArr4[i2] = (((f3 * f27) + ((-f2) * f28)) - (f4 * f26)) * f30;
            fArr4[i3] = ((f16 * f20) + ((f14 * f22) - (f15 * f21))) * f30;
            fArr4[i5] = (((f11 * f21) + ((-f10) * f22)) - (f12 * f20)) * f30;
            float f31 = -f5;
            fArr4[4] = (((f7 * f25) + (f31 * f28)) - (f8 * f24)) * f30;
            fArr4[5] = ((f4 * f24) + ((f28 * f) - (f3 * f25))) * f30;
            float f32 = -f13;
            fArr4[6] = (((f15 * f19) + (f32 * f22)) - (f16 * f18)) * f30;
            fArr4[7] = ((f12 * f18) + ((f22 * f9) - (f11 * f19))) * f30;
            fArr4[8] = ((f8 * f23) + ((f5 * f27) - (f6 * f25))) * f30;
            fArr4[9] = (((f25 * f2) + ((-f) * f27)) - (f4 * f23)) * f30;
            fArr4[10] = ((f16 * f17) + ((f13 * f21) - (f14 * f19))) * f30;
            fArr4[11] = (((f19 * f10) + ((-f9) * f21)) - (f12 * f17)) * f30;
            fArr4[12] = (((f6 * f24) + (f31 * f26)) - (f7 * f23)) * f30;
            fArr4[13] = ((f3 * f23) + ((f * f26) - (f2 * f24))) * f30;
            fArr4[14] = (((f14 * f18) + (f32 * f20)) - (f15 * f17)) * f30;
            fArr4[15] = ((f11 * f17) + ((f9 * f20) - (f10 * f18))) * f30;
        }
        return (i4 == 0 ? i2 : i) ^ 1;
    }

    static {
        float[] fArr = new float[]{-0.250268f, 1.204414f, 0.045854f};
        float[] fArr2 = new float[]{-0.002079f, 0.048952f, 0.953127f};
        b = new float[][]{new float[]{0.401288f, 0.650173f, -0.051461f}, fArr, fArr2};
        float[] fArr3 = new float[]{0.38752654f, 0.62144744f, -0.00897398f};
        float[] fArr4 = new float[]{-0.0158415f, -0.03412294f, 1.0499644f};
        c = new float[][]{new float[]{1.8620678f, -1.0112547f, 0.14918678f}, fArr3, fArr4};
        double[] dArr = new double[]{0.2126d, 0.7152d, 0.0722d};
        double[] dArr2 = new double[]{0.01932141d, 0.11916382d, 0.95034478d};
        e = new double[][]{new double[]{0.41233895d, 0.35762064d, 0.18051042d}, dArr, dArr2};
        dArr = new double[]{-0.9691452513005321d, 1.8758853451067872d, 0.04156585616912061d};
        dArr2 = new double[]{0.05562093689691305d, -0.20395524564742123d, 1.0571799111220335d};
        f = new double[][]{new double[]{3.2413774792388685d, -1.5376652402851851d, -0.49885366846268053d}, dArr, dArr2};
    }

    public static final void c(f91 f91, mi0 mi0, m00 m00, d10 d10, int i) {
        int i2;
        d10.X(-511989831);
        if ((i & 6) == 0) {
            i2 = (((AutofillValue) d10) != null ? 4 : 2) | i;
        } else {
            i2 = i;
        }
        if ((i & 48) == 0) {
            i2 |= ((AutofillManager$AutofillCallback) d10) != null ? 32 : 16;
        }
        if ((i & 384) == 0) {
            i2 |= ((AutofillValue) d10) != null ? 256 : 128;
        }
        if (d10.O(i2 & 1, (i2 & 147) != 146)) {
            long j = d10.T;
            i2 = (int) (j ^ (j >>> 32));
            b10 E = zi1.E(d10);
            mi0 I = vn.I(d10, mi0);
            qr0 l = d10.l();
            dk dkVar = dk.p;
            d10.Z();
            if (d10.S) {
                d10.k(dkVar);
            } else {
                d10.j0();
            }
            mc0.B(f91.c, d10, f91);
            mc0.B(f91.d, d10, E);
            mc0.B(f91.e, d10, m00);
            ij.c.getClass();
            mc0.B(hj.e, d10, l);
            mc0.w(d10, hj.h);
            mc0.B(hj.d, d10, I);
            mc0.p(d10, Integer.valueOf(i2), hj.g);
            d10.p(true);
            if (d10.A()) {
                d10.W(-1259186295);
                d10.p(false);
            } else {
                d10.W(-1259244916);
                AutofillValue h = ((AutofillValue) d10);
                Object L = d10.L();
                if (h != null || L == oj.a) {
                    L = new f8(11, f91);
                    d10.g0(L);
                }
                j70.o((xz) L, d10);
                d10.p(false);
            }
        } else {
            d10.R();
        }
        xv0 r = d10.r();
        if (r != null) {
            r.d = new c91(f91, mi0, m00, i);
        }
    }

    public static final void d(xz xzVar, mi0 mi0, boolean z, y41 y41, pd pdVar, sp0 sp0, pi piVar, d10 d10, int i) {
        Object obj;
        Object obj2;
        mi0 mi02;
        Object obj3;
        boolean z2;
        d10 d102 = d10;
        d102.X(-1061374109);
        xz xzVar2 = xzVar;
        int i2 = (i | (((AutofillValue) d102) != null ? 4 : 2)) | 115025328;
        if (d102.O(i2 & 1, (306783379 & i2) != 306783378)) {
            boolean z3;
            y41 y412;
            pd pdVar2;
            sp0 sp02;
            int i3;
            mi0 mi03;
            pd p30;
            d102.T();
            if ((i & 1) != 0) {
                if (!d102.y()) {
                    d102.R();
                    z3 = z;
                    y412 = y41;
                    pdVar2 = pdVar;
                    sp02 = sp0;
                    i3 = i2 & -64513;
                    mi03 = mi0;
                    d102.q();
                    vn.a(xzVar2, mi03, z3, y412, pdVar2, null, sp02, piVar, d102, i3 & 2147483646, 0);
                    obj = y412;
                    obj2 = sp02;
                    mi02 = mi03;
                    obj3 = pdVar2;
                    z2 = z3;
                }
            }
            up0 up0 = qd.a;
            y41 a = d51.a(a5.b, d102);
            dh dhVar = ((dh0) d102.j(fh0.a)).a;
            pd pdVar3 = dhVar.X;
            if (pdVar3 == null) {
                long j = zg.h;
                p30 = new p30(j, fh.c(dhVar, eh.j), j, zg.b(fh.c(dhVar, k70.u), k70.v));
                dhVar.X = p30;
            } else {
                p30 = pdVar3;
            }
            i2 &= -64513;
            up0 up02 = qd.b;
            i3 = i2;
            mi03 = ji0.a;
            sp02 = up02;
            y412 = a;
            z3 = true;
            pdVar2 = p30;
            d102.q();
            vn.a(xzVar2, mi03, z3, y412, pdVar2, null, sp02, piVar, d102, i3 & 2147483646, 0);
            obj = y412;
            obj2 = sp02;
            mi02 = mi03;
            obj3 = pdVar2;
            z2 = z3;
        } else {
            d10.R();
            mi02 = mi0;
            z2 = z;
            obj = y41;
            obj3 = pdVar;
            obj2 = sp0;
        }
        xv0 r = d10.r();
        if (r != null) {
            r.d = new ud(xzVar, mi02, z2, obj, obj3, obj2, piVar, i, 0);
        }
    }

    public static String T(int i) {
        if (i == 0) {
            return "Clear";
        }
        if (i == 1) {
            return "Src";
        }
        if (i == 2) {
            return "Dst";
        }
        if (i == 3) {
            return "SrcOver";
        }
        if (i == 4) {
            return "DstOver";
        }
        if (i == 5) {
            return "SrcIn";
        }
        if (i == 6) {
            return "DstIn";
        }
        if (i == 7) {
            return "SrcOut";
        }
        if (i == 8) {
            return "DstOut";
        }
        if (i == 9) {
            return "SrcAtop";
        }
        if (i == 10) {
            return "DstAtop";
        }
        if (i == 11) {
            return "Xor";
        }
        if (i == 12) {
            return "Plus";
        }
        if (i == 13) {
            return "Modulate";
        }
        if (i == 14) {
            return "Screen";
        }
        if (i == 15) {
            return "Overlay";
        }
        if (i == 16) {
            return "Darken";
        }
        if (i == 17) {
            return "Lighten";
        }
        if (i == 18) {
            return "ColorDodge";
        }
        if (i == 19) {
            return "ColorBurn";
        }
        if (i == 20) {
            return "HardLight";
        }
        if (i == 21) {
            return "Softlight";
        }
        if (i == 22) {
            return "Difference";
        }
        if (i == 23) {
            return "Exclusion";
        }
        if (i == 24) {
            return "Multiply";
        }
        if (i == 25) {
            return "Hue";
        }
        if (i == 26) {
            return "Saturation";
        }
        if (i == 27) {
            return "Color";
        }
        return i == 28 ? "Luminosity" : "Unknown";
    }

    public static final y30 u() {
        y30 y30 = n;
        if (y30 != null) {
            return y30;
        }
        x30 x30 = new x30("Outlined.Circle", 24.0f, 24.0f, 24.0f, 24.0f, 0, 0, false, 96);
        int i = yf1.a;
        f71 adVar = new ad(zg.b);
        pg0 h90 = new h90(22);
        h90.w(12.0f, 2.0f);
        h90.l(6.47f, 2.0f, 2.0f, 6.47f, 2.0f, 12.0f);
        h90.m(0.0f, 5.53f, 4.47f, 10.0f, 10.0f, 10.0f);
        h90.A(10.0f, -4.47f, 10.0f, -10.0f);
        h90.l(22.0f, 6.47f, 17.53f, 2.0f, 12.0f, 2.0f);
        h90.i();
        h90.w(12.0f, 20.0f);
        h90.m(-4.42f, 0.0f, -8.0f, -3.58f, -8.0f, -8.0f);
        h90.m(0.0f, -4.42f, 3.58f, -8.0f, 8.0f, -8.0f);
        h90.A(8.0f, 3.58f, 8.0f, 8.0f);
        h90.l(20.0f, 16.42f, 16.42f, 20.0f, 12.0f, 20.0f);
        h90.i();
        x30.a(x30, (ArrayList) h90.f, adVar);
        y30 = x30.b();
        n = y30;
        return y30;
    }

    public static final float[] K(float[] fArr, float[] fArr2) {
        float[] fArr3 = fArr;
        float[] fArr4 = fArr2;
        float[] fArr5 = new float[9];
        if (fArr3.length >= 9) {
            if (fArr4.length >= 9) {
                float f = fArr3[0] * fArr4[0];
                float f2 = fArr3[3];
                float f3 = fArr4[1];
                float f4 = (f2 * f3) + f;
                float f5 = fArr3[6];
                float f6 = fArr4[2];
                fArr5[0] = (f5 * f6) + f4;
                f4 = fArr3[1];
                float f7 = fArr4[0];
                f4 *= f7;
                float f8 = fArr3[4];
                f3 = (f3 * f8) + f4;
                float f9 = fArr3[7];
                fArr5[1] = (f9 * f6) + f3;
                f3 = fArr3[2] * f7;
                float f10 = fArr3[5];
                float f11 = (fArr4[1] * f10) + f3;
                float f12 = fArr3[8];
                fArr5[2] = (f6 * f12) + f11;
                float f13 = fArr3[0];
                f6 = fArr4[3] * f13;
                f11 = fArr4[4];
                f2 = (f2 * f11) + f6;
                f6 = fArr4[5];
                fArr5[3] = (f5 * f6) + f2;
                f2 = fArr3[1];
                float f14 = fArr4[3];
                f8 *= f11;
                fArr5[4] = (f9 * f6) + (f8 + (f2 * f14));
                float f15 = fArr3[2];
                f6 *= f12;
                fArr5[5] = f6 + ((f10 * fArr4[4]) + (f14 * f15));
                f13 *= fArr4[6];
                float f16 = fArr3[3];
                f14 = fArr4[7];
                f16 = (f16 * f14) + f13;
                f13 = fArr4[8];
                fArr5[6] = (f5 * f13) + f16;
                f = fArr4[6];
                f9 *= f13;
                fArr5[7] = f9 + ((fArr3[4] * f14) + (f2 * f));
                f12 *= f13;
                fArr5[8] = f12 + ((fArr3[5] * fArr4[7]) + (f15 * f));
                return fArr5;
            }
        }
        return fArr5;
    }

    /* JADX WARNING: Removed duplicated region for block: B:26:0x0080  */
    /* JADX WARNING: Removed duplicated region for block: B:25:0x007f  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static jz n(Context context) {
        ProviderInfo providerInfo;
        hz hzVar;
        vj h90 = VERSION.SDK_INT >= 28 ? new h90(4) : new h90(4);
        PackageManager packageManager = context.getPackageManager();
        ua0.i(packageManager, "Package manager required to locate emoji font provider");
        int i = 0;
        for (ResolveInfo resolveInfo : packageManager.queryIntentContentProviders(new dl1("androidx.content.action.LOAD_EMOJI_FONT"), 0)) {
            providerInfo = resolveInfo.providerInfo;
            if (providerInfo != null) {
                ApplicationInfo applicationInfo = providerInfo.applicationInfo;
                if (applicationInfo != null && (applicationInfo.flags & 1) == 1) {
                    break;
                }
            }
        }
        providerInfo = null;
        if (providerInfo != null) {
            try {
                String str = providerInfo.authority;
                String str2 = providerInfo.packageName;
                Signature[] i2 = h90.i(packageManager, str2);
                ArrayList arrayList = new ArrayList();
                int length = i2.length;
                while (i < length) {
                    arrayList.add(i2[i].toByteArray());
                    i++;
                }
                hzVar = new hz(str, str2, "emojicompat-emoji-font", Collections.singletonList(arrayList), null, null);
            } catch (NameNotFoundException e) {
                Log.wtf("emoji2.text.DefaultEmojiConfig", e);
            }
            return hzVar != null ? null : new jz(new iz(context, hzVar));
        }
        hzVar = null;
        if (hzVar != null) {
        }
    }

    public static int i(double d) {
        double d2 = (d + 16.0d) / 116.0d;
        double d3 = d > 8.0d ? (d2 * d2) * d2 : d / 903.2962962962963d;
        double d4 = (d2 * d2) * d2;
        int i = d4 > 0.008856451679035631d ? 1 : 0;
        double d5 = i != 0 ? d4 : d / 903.2962962962963d;
        if (i == 0) {
            d4 = d / 903.2962962962963d;
        }
        float[] fArr = d;
        d5 *= (double) fArr[0];
        d3 *= (double) fArr[1];
        d4 *= (double) fArr[2];
        double[][] dArr = f;
        double[] dArr2 = dArr[0];
        double d6 = (dArr2[2] * d4) + ((dArr2[1] * d3) + (dArr2[0] * d5));
        dArr2 = dArr[1];
        double d7 = (dArr2[2] * d4) + ((dArr2[1] * d3) + (dArr2[0] * d5));
        double[] dArr3 = dArr[2];
        return ((((vn.p(d6) & 255) << 16) | -16777216) | ((vn.p(d7) & 255) << 8)) | (vn.p((dArr3[2] * d4) + ((dArr3[1] * d3) + (dArr3[0] * d5))) & 255);
    }

    public static final float[] B(float[] fArr) {
        float[] fArr2 = fArr;
        float f = fArr2[0];
        float f2 = fArr2[3];
        float f3 = fArr2[6];
        float f4 = fArr2[1];
        float f5 = fArr2[4];
        float f6 = fArr2[7];
        float f7 = fArr2[2];
        float f8 = fArr2[5];
        float f9 = fArr2[8];
        float f10 = (f5 * f9) - (f6 * f8);
        float f11 = (f6 * f7) - (f4 * f9);
        float f12 = (f4 * f8) - (f5 * f7);
        float f13 = (f3 * f12) + ((f2 * f11) + (f * f10));
        fArr2 = new float[fArr2.length];
        fArr2[0] = f10 / f13;
        fArr2[1] = f11 / f13;
        fArr2[2] = f12 / f13;
        fArr2[3] = ((f3 * f8) - (f2 * f9)) / f13;
        fArr2[4] = ((f9 * f) - (f3 * f7)) / f13;
        fArr2[5] = ((f7 * f2) - (f8 * f)) / f13;
        fArr2[6] = ((f2 * f6) - (f3 * f5)) / f13;
        fArr2[7] = ((f3 * f4) - (f6 * f)) / f13;
        fArr2[8] = ((f * f5) - (f2 * f4)) / f13;
        return fArr2;
    }

    public static final float[] j(float[] fArr, float[] fArr2, float[] fArr3) {
        float[] fArr4 = fArr;
        float[] fArr5 = fArr3;
        vn.L(fArr, fArr2);
        vn.L(fArr4, fArr5);
        float f = fArr5[0] / fArr2[0];
        float f2 = fArr5[1] / fArr2[1];
        float f3 = fArr5[2] / fArr2[2];
        float[] fArr6 = new float[]{f, f2, f3};
        fArr5 = vn.B(fArr4);
        f = fArr6[0];
        f2 = fArr4[0] * f;
        float f4 = fArr6[1];
        float f5 = fArr4[1] * f4;
        float f6 = fArr6[2];
        float f7 = fArr4[2] * f6;
        float f8 = fArr4[3] * f;
        float f9 = fArr4[4] * f4;
        float f10 = fArr4[5] * f6;
        f *= fArr4[6];
        f4 *= fArr4[7];
        f6 *= fArr4[8];
        return vn.K(fArr5, new float[]{f2, f5, f7, f8, f9, f10, f, f4, f6});
    }

    public static final void b(mi0 mi0, m00 m00, d10 d10, int i, int i2) {
        int i3;
        d10.X(-1298353104);
        int i4 = i2 & 1;
        if (i4 != 0) {
            i3 = i | 6;
        } else if ((i & 6) == 0) {
            i3 = (((AutofillManager$AutofillCallback) d10) != null ? 4 : 2) | i;
        } else {
            i3 = i;
        }
        if ((i & 48) == 0) {
            i3 |= ((AutofillValue) d10) != null ? 32 : 16;
        }
        if (d10.O(i3 & 1, (i3 & 19) != 18)) {
            if (i4 != 0) {
                mi0 = ji0.a;
            }
            Object L = d10.L();
            if (L == oj.a) {
                L = new f91(e3.Y);
                d10.g0(L);
            }
            vn.c((f91) L, mi0, m00, d10, (i3 << 3) & 1008);
        } else {
            d10.R();
        }
        xv0 r = d10.r();
        if (r != null) {
            r.d = new b91(mi0, m00, i, i2);
        }
    }

    public static final float x(Layout layout, int i, Paint paint) {
        ThreadLocal threadLocal = db1.a;
        if (layout.getEllipsisCount(i) > 0) {
            int i2 = -1;
            if (layout.getParagraphDirection(i) == -1 && ((float) layout.getWidth()) < layout.getLineRight(i)) {
                float width;
                float width2;
                float measureText = paint.measureText("…") + (layout.getLineRight(i) - layout.getPrimaryHorizontal(layout.getEllipsisStart(i) + layout.getLineStart(i)));
                Alignment paragraphAlignment = layout.getParagraphAlignment(i);
                if (paragraphAlignment != null) {
                    i2 = o40.a[paragraphAlignment.ordinal()];
                }
                if (i2 == 1) {
                    width = ((float) layout.getWidth()) - layout.getLineRight(i);
                    width2 = (((float) layout.getWidth()) - measureText) / 2.0f;
                } else {
                    width = ((float) layout.getWidth()) - layout.getLineRight(i);
                    width2 = ((float) layout.getWidth()) - measureText;
                }
                return width - width2;
            }
        }
        return 0.0f;
    }

    public static final float w(Layout layout, int i, Paint paint) {
        float lineLeft = layout.getLineLeft(i);
        ThreadLocal threadLocal = db1.a;
        if (layout.getEllipsisCount(i) <= 0 || layout.getParagraphDirection(i) != 1 || lineLeft >= 0.0f) {
            return 0.0f;
        }
        float abs;
        float width;
        float measureText = paint.measureText("…") + (layout.getPrimaryHorizontal(layout.getEllipsisStart(i) + layout.getLineStart(i)) - lineLeft);
        Alignment paragraphAlignment = layout.getParagraphAlignment(i);
        if ((paragraphAlignment == null ? -1 : o40.a[paragraphAlignment.ordinal()]) == 1) {
            abs = Math.abs(lineLeft);
            width = (((float) layout.getWidth()) - measureText) / 2.0f;
        } else {
            abs = Math.abs(lineLeft);
            width = ((float) layout.getWidth()) - measureText;
        }
        return width + abs;
    }

    public static int A(float f) {
        if (f < 1.0f) {
            return -16777216;
        }
        if (f > 99.0f) {
            return -1;
        }
        float f2 = (f + 16.0f) / 116.0f;
        f = f > 8.0f ? (f2 * f2) * f2 : f / 903.2963f;
        float f3 = (f2 * f2) * f2;
        int i = f3 > 0.008856452f ? 1 : 0;
        float f4 = i != 0 ? f3 : ((f2 * 116.0f) - 16.0f) / 903.2963f;
        if (i == 0) {
            f3 = ((f2 * 116.0f) - 16.0f) / 903.2963f;
        }
        float[] fArr = d;
        return mh.a((double) (f4 * fArr[0]), (double) (f * fArr[1]), (double) (f3 * fArr[2]));
    }

    public static final void Q(float[] fArr, Matrix matrix) {
        float[] fArr2 = fArr;
        matrix.getValues(fArr2);
        float f = fArr2[0];
        float f2 = fArr2[1];
        float f3 = fArr2[2];
        float f4 = fArr2[3];
        float f5 = fArr2[4];
        float f6 = fArr2[5];
        float f7 = fArr2[6];
        float f8 = fArr2[7];
        float f9 = fArr2[8];
        fArr2[0] = f;
        fArr2[1] = f4;
        fArr2[2] = 0.0f;
        fArr2[3] = f7;
        fArr2[4] = f2;
        fArr2[5] = f5;
        fArr2[6] = 0.0f;
        fArr2[7] = f8;
        fArr2[8] = 0.0f;
        fArr2[9] = 0.0f;
        fArr2[10] = 1.0f;
        fArr2[11] = 0.0f;
        fArr2[12] = f3;
        fArr2[13] = f6;
        fArr2[14] = 0.0f;
        fArr2[15] = f9;
    }

    public static final long S(long j, is isVar) {
        TimeUnit timeUnit = isVar.e;
        TimeUnit timeUnit2 = TimeUnit.NANOSECONDS;
        long convert = timeUnit.convert(4611686018426999999L, timeUnit2);
        if ((-convert) <= j && j <= convert) {
            j = timeUnit2.convert(j, timeUnit);
            vj vjVar = gs.e;
            j <<= 1;
            int i = hs.a;
            return j;
        } else if (isVar.compareTo(is.MILLISECONDS) < 0) {
            return vn.r(sb0.i(TimeUnit.MILLISECONDS.convert(j, timeUnit)));
        } else {
            long signum = (long) Long.signum(j);
            if (j < -9223372036854775807L) {
                j = -9223372036854775807L;
            }
            return vn.r(j70.w(Math.abs(j), isVar) * signum);
        }
    }

    public static final String R(ml mlVar) {
        if (mlVar instanceof gq) {
            return ((gq) mlVar).toString();
        }
        StringBuilder stringBuilder;
        Object stringBuilder2;
        try {
            stringBuilder = new StringBuilder();
            stringBuilder.append(mlVar);
            stringBuilder.append('@');
            stringBuilder.append(vn.y(mlVar));
            stringBuilder2 = stringBuilder.toString();
        } catch (Throwable th) {
            stringBuilder2 = new px0(th);
        }
        if (ak0.a(stringBuilder2) != null) {
            stringBuilder = new StringBuilder();
            stringBuilder.append(mlVar.getClass().getName());
            stringBuilder.append('@');
            stringBuilder.append(vn.y(mlVar));
            stringBuilder2 = stringBuilder.toString();
        }
        return (String) stringBuilder2;
    }

    /* JADX WARNING: Removed duplicated region for block: B:174:0x028b  */
    /* JADX WARNING: Removed duplicated region for block: B:173:0x0274  */
    /* JADX WARNING: Removed duplicated region for block: B:190:0x02c8  */
    /* JADX WARNING: Removed duplicated region for block: B:189:0x02c7  */
    /* JADX WARNING: Removed duplicated region for block: B:193:0x02d7  */
    /* JADX WARNING: Removed duplicated region for block: B:165:0x0263  */
    /* JADX WARNING: Removed duplicated region for block: B:173:0x0274  */
    /* JADX WARNING: Removed duplicated region for block: B:174:0x028b  */
    /* JADX WARNING: Removed duplicated region for block: B:177:0x02a6  */
    /* JADX WARNING: Removed duplicated region for block: B:189:0x02c7  */
    /* JADX WARNING: Removed duplicated region for block: B:190:0x02c8  */
    /* JADX WARNING: Removed duplicated region for block: B:193:0x02d7  */
    /* JADX WARNING: Removed duplicated region for block: B:142:0x01d5  */
    /* JADX WARNING: Removed duplicated region for block: B:146:0x01e7  */
    /* JADX WARNING: Removed duplicated region for block: B:145:0x01e4  */
    /* JADX WARNING: Removed duplicated region for block: B:149:0x01ee  */
    /* JADX WARNING: Removed duplicated region for block: B:148:0x01eb  */
    /* JADX WARNING: Removed duplicated region for block: B:153:0x020f  */
    /* JADX WARNING: Removed duplicated region for block: B:152:0x01f4  */
    /* JADX WARNING: Removed duplicated region for block: B:200:0x030f  */
    /* JADX WARNING: Removed duplicated region for block: B:199:0x0302  */
    /* JADX WARNING: Removed duplicated region for block: B:203:0x0317  */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x0066  */
    /* JADX WARNING: Removed duplicated region for block: B:28:0x0051  */
    /* JADX WARNING: Removed duplicated region for block: B:47:0x0081  */
    /* JADX WARNING: Removed duplicated region for block: B:39:0x006c  */
    /* JADX WARNING: Removed duplicated region for block: B:58:0x009d  */
    /* JADX WARNING: Removed duplicated region for block: B:50:0x0088  */
    /* JADX WARNING: Removed duplicated region for block: B:62:0x00a9  */
    /* JADX WARNING: Removed duplicated region for block: B:61:0x00a6  */
    /* JADX WARNING: Removed duplicated region for block: B:72:0x00c4  */
    /* JADX WARNING: Removed duplicated region for block: B:71:0x00bf  */
    /* JADX WARNING: Removed duplicated region for block: B:82:0x00e0  */
    /* JADX WARNING: Removed duplicated region for block: B:81:0x00dd  */
    /* JADX WARNING: Removed duplicated region for block: B:91:0x00f5  */
    /* JADX WARNING: Removed duplicated region for block: B:99:0x0110  */
    /* JADX WARNING: Removed duplicated region for block: B:98:0x010d  */
    /* JADX WARNING: Removed duplicated region for block: B:205:0x035d  */
    /* JADX WARNING: Removed duplicated region for block: B:102:0x0119  */
    /* JADX WARNING: Removed duplicated region for block: B:210:? A:{SYNTHETIC, RETURN} */
    /* JADX WARNING: Removed duplicated region for block: B:208:0x036b  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final void a(xz xzVar, mi0 mi0, boolean z, y41 y41, pd pdVar, td tdVar, sp0 sp0, pi piVar, d10 d10, int i, int i2) {
        int i3;
        boolean z2;
        int i4;
        int i5;
        xv0 r;
        mi0 mi02 = mi0;
        pi piVar2 = piVar;
        d10 d102 = d10;
        int i6 = i;
        int i7 = i2;
        d102.X(-1310015664);
        xz xzVar2 = xzVar;
        if ((i6 & 6) == 0) {
            i3 = (((AutofillValue) d102) != null ? 4 : 2) | i6;
        } else {
            i3 = i6;
        }
        if ((i6 & 48) == 0) {
            i3 |= ((AutofillManager$AutofillCallback) d102) != null ? 32 : 16;
        }
        int i8 = i7 & 4;
        if (i8 != 0) {
            i3 |= 384;
        } else if ((i6 & 384) == 0) {
            y41 y412;
            pd pdVar2;
            td tdVar2;
            sp0 sp02;
            boolean z3;
            y41 y413;
            pd pdVar3;
            td tdVar3;
            z2 = z;
            i3 |= d102.g(z2) ? 256 : 128;
            if ((i6 & 3072) != 0) {
                int i9;
                if ((i7 & 8) == 0) {
                    y412 = y41;
                    if (((AutofillManager$AutofillCallback) d102) != null) {
                        i9 = 2048;
                        i3 |= i9;
                    }
                } else {
                    y412 = y41;
                }
                i9 = 1024;
                i3 |= i9;
            } else {
                y412 = y41;
            }
            if ((i6 & 24576) != 0) {
                int i10;
                if ((i7 & 16) == 0) {
                    pdVar2 = pdVar;
                    if (((AutofillManager$AutofillCallback) d102) != null) {
                        i10 = 16384;
                        i3 |= i10;
                    }
                } else {
                    pdVar2 = pdVar;
                }
                i10 = 8192;
                i3 |= i10;
            } else {
                pdVar2 = pdVar;
            }
            if ((196608 & i6) != 0) {
                if ((i7 & 32) == 0) {
                    tdVar2 = tdVar;
                    if (((AutofillManager$AutofillCallback) d102) != null) {
                        i4 = 131072;
                        i3 |= i4;
                    }
                } else {
                    tdVar2 = tdVar;
                }
                i4 = 65536;
                i3 |= i4;
            } else {
                tdVar2 = tdVar;
            }
            if ((i7 & 64) == 0) {
                i3 |= 1572864;
            } else if ((i6 & 1572864) == 0) {
                i3 |= ((AutofillManager$AutofillCallback) d102) != null ? 1048576 : 524288;
            }
            i4 = i7 & 128;
            if (i4 == 0) {
                i3 |= 12582912;
                sp02 = sp0;
            } else {
                sp02 = sp0;
                if ((i6 & 12582912) == 0) {
                    i3 |= ((AutofillManager$AutofillCallback) d102) != null ? 8388608 : 4194304;
                }
            }
            if ((i7 & 256) == 0) {
                i3 |= 100663296;
            } else if ((i6 & 100663296) == 0) {
                i3 |= ((AutofillManager$AutofillCallback) d102) != null ? 67108864 : 33554432;
            }
            if ((805306368 & i6) == 0) {
                i3 |= ((AutofillValue) d102) != null ? 536870912 : 268435456;
            }
            i5 = 1;
            if (d102.O(i3 & 1, (306783379 & i3) == 306783378)) {
                mi0 mi03 = mi02;
                d10.R();
                z3 = z2;
                y413 = y412;
                pdVar3 = pdVar2;
                tdVar3 = tdVar2;
            } else {
                int i11;
                pd pdVar4;
                y41 y414;
                boolean z4;
                Object L;
                c8 c8Var;
                uj0 uj0;
                long j;
                long j2;
                pd pdVar5;
                int i12;
                uj0 uj02;
                boolean z5;
                y41 y415;
                td tdVar4;
                long j3;
                p8 p8Var;
                float f;
                Object L2;
                mi0 a;
                pi A;
                y41 a2;
                up0 up0;
                pd pdVar6;
                int i13;
                td br0;
                d102.T();
                if ((i & 1) != 0) {
                    if (!d102.y()) {
                        d102.R();
                        if ((i7 & 8) != 0) {
                            i3 &= -7169;
                        }
                        if ((i7 & 16) != 0) {
                            i3 &= -57345;
                        }
                        if ((i7 & 32) != 0) {
                            i3 &= -458753;
                        }
                        i11 = i3;
                        pdVar4 = pdVar2;
                        y414 = y412;
                        z4 = z2;
                        d102.q();
                        d102.W(1691726283);
                        L = d102.L();
                        c8Var = oj.a;
                        if (L == c8Var) {
                            L = new uj0();
                            d102.g0(L);
                        }
                        uj0 = (uj0) L;
                        d102.p(false);
                        j = z4 ? pdVar4.a : pdVar4.c;
                        j2 = z4 ? pdVar4.b : pdVar4.d;
                        if (tdVar2 != null) {
                            d102.W(1691909926);
                            d102.p(false);
                            pdVar5 = pdVar4;
                            i12 = i11;
                            uj02 = uj0;
                            z5 = z4;
                            y415 = y414;
                            tdVar4 = tdVar2;
                            j3 = j;
                            p8Var = null;
                        } else {
                            y60 y60;
                            float f2;
                            c8 L3;
                            br br02;
                            d102.W(-499611589);
                            i7 = ((i11 >> 6) & 14) | ((i11 >> 9) & 896);
                            pdVar5 = pdVar4;
                            Object L4 = d102.L();
                            if (L4 == c8Var) {
                                L4 = new z61();
                                d102.g0(L4);
                            }
                            z61 z61 = (z61) L4;
                            AutofillManager$AutofillCallback f3 = ((AutofillManager$AutofillCallback) d102);
                            Object L5 = d102.L();
                            if (f3 == null) {
                                if (L5 != c8Var) {
                                    y415 = y414;
                                    j3 = j;
                                    j70.j((m00) L5, d102, uj0);
                                    y60 = (y60) tg.X(z61);
                                    if (z4) {
                                        if (!(y60 instanceof ou0)) {
                                            if (y60 instanceof m30) {
                                                f2 = tdVar2.a;
                                                L3 = d102.L();
                                                if (L3 == c8Var) {
                                                    uj02 = uj0;
                                                    i12 = i11;
                                                    L3 = new c8(new br0(f2), wl1.p, null, 12);
                                                    d102.g0(L3);
                                                } else {
                                                    i12 = i11;
                                                    uj02 = uj0;
                                                }
                                                L3 = L3;
                                                br02 = new br0(f2);
                                                i8 = ((AutofillValue) d102) | d102.c(f2);
                                                i4 = ((((i7 & 14) ^ 6) > 4 || !d102.g(z4)) && (i7 & 6) != 4) ? 0 : 1;
                                                i8 |= i4;
                                                if (((i7 & 896) ^ 384) <= 256 || ((AutofillManager$AutofillCallback) d102) == null) {
                                                    if ((i7 & 384) != 256) {
                                                        i5 = 0;
                                                    }
                                                }
                                                i7 = (i8 | i5) | ((AutofillValue) d102);
                                                L = d102.L();
                                                if (i7 == 0) {
                                                    if (L != c8Var) {
                                                        z5 = z4;
                                                        tdVar4 = tdVar2;
                                                        j70.j((m00) L, d102, br02);
                                                        p8Var = L3.c;
                                                        d102.p(false);
                                                    }
                                                }
                                                z5 = z4;
                                                tdVar4 = tdVar2;
                                                L = new sd(L3, f2, z5, tdVar4, y60, null);
                                                d102.g0(L);
                                                j70.j((m00) L, d102, br02);
                                                p8Var = L3.c;
                                                d102.p(false);
                                            }
                                        }
                                    }
                                    f2 = 0.0f;
                                    L3 = d102.L();
                                    if (L3 == c8Var) {
                                    }
                                    L3 = L3;
                                    br02 = new br0(f2);
                                    i8 = ((AutofillValue) d102) | d102.c(f2);
                                    if (((i7 & 14) ^ 6) > 4) {
                                    }
                                    i8 |= i4;
                                    if ((i7 & 384) != 256) {
                                    }
                                    i7 = (i8 | i5) | ((AutofillValue) d102);
                                    L = d102.L();
                                    if (i7 == 0) {
                                    }
                                    z5 = z4;
                                    tdVar4 = tdVar2;
                                    L = new sd(L3, f2, z5, tdVar4, y60, null);
                                    d102.g0(L);
                                    j70.j((m00) L, d102, br02);
                                    p8Var = L3.c;
                                    d102.p(false);
                                }
                            }
                            y415 = y414;
                            j3 = j;
                            L5 = new d(uj0, z61, null, 4);
                            d102.g0(L5);
                            j70.j((m00) L5, d102, uj0);
                            y60 = (y60) tg.X(z61);
                            if (z4) {
                            }
                            f2 = 0.0f;
                            L3 = d102.L();
                            if (L3 == c8Var) {
                            }
                            L3 = L3;
                            br02 = new br0(f2);
                            i8 = ((AutofillValue) d102) | d102.c(f2);
                            if (((i7 & 14) ^ 6) > 4) {
                            }
                            i8 |= i4;
                            if ((i7 & 384) != 256) {
                            }
                            i7 = (i8 | i5) | ((AutofillValue) d102);
                            L = d102.L();
                            if (i7 == 0) {
                            }
                            z5 = z4;
                            tdVar4 = tdVar2;
                            L = new sd(L3, f2, z5, tdVar4, y60, null);
                            d102.g0(L);
                            j70.j((m00) L, d102, br02);
                            p8Var = L3.c;
                            d102.p(false);
                        }
                        f = p8Var == null ? ((br) p8Var.f.getValue()).e : 0.0f;
                        L2 = d102.L();
                        if (L2 == c8Var) {
                            L2 = new h90(3);
                            d102.g0(L2);
                        }
                        a = f21.a(mi0, (i00) L2);
                        A = vd1.A(-535639973, new vd(j2, sp02, piVar2), d102);
                        i7 = i12;
                        z4 = z5;
                        y414 = y415;
                        p91.b(xzVar, a, z4, y414, j3, j2, 0.0f, f, uj02, A, d102, (i7 & 8078) | ((i7 << 6) & 234881024), 64);
                        y413 = y414;
                        z3 = z4;
                        tdVar3 = tdVar4;
                        pdVar3 = pdVar5;
                    }
                }
                if (i8 != 0) {
                    z2 = true;
                }
                if ((i7 & 8) != 0) {
                    up0 up02 = qd.a;
                    a2 = d51.a(a5.b, d102);
                    i3 &= -7169;
                } else {
                    a2 = y412;
                }
                if ((i7 & 16) != 0) {
                    up0 = qd.a;
                    dh dhVar = ((dh0) d102.j(fh0.a)).a;
                    pdVar6 = dhVar.W;
                    if (pdVar6 == null) {
                        i13 = -458753;
                        pdVar6 = new p30(fh.c(dhVar, ac.m), fh.c(dhVar, ac.s), zg.b(fh.c(dhVar, ac.n), ac.o), zg.b(fh.c(dhVar, ac.p), ac.q));
                        dhVar.W = pdVar6;
                    } else {
                        i13 = -458753;
                    }
                    i3 &= -57345;
                } else {
                    i13 = -458753;
                    pdVar6 = pdVar2;
                }
                if ((i7 & 32) != 0) {
                    up0 = qd.a;
                    br0 = new br0(ac.r);
                    i3 &= i13;
                } else {
                    br0 = tdVar2;
                }
                Object obj = i4 != 0 ? qd.a : sp02;
                tdVar2 = br0;
                y414 = a2;
                i11 = i3;
                pdVar4 = pdVar6;
                z4 = z2;
                d102.q();
                d102.W(1691726283);
                L = d102.L();
                c8Var = oj.a;
                if (L == c8Var) {
                }
                uj0 = (uj0) L;
                d102.p(false);
                if (z4) {
                }
                if (z4) {
                }
                if (tdVar2 != null) {
                }
                if (p8Var == null) {
                }
                L2 = d102.L();
                if (L2 == c8Var) {
                }
                a = f21.a(mi0, (i00) L2);
                A = vd1.A(-535639973, new vd(j2, sp02, piVar2), d102);
                i7 = i12;
                z4 = z5;
                y414 = y415;
                p91.b(xzVar, a, z4, y414, j3, j2, 0.0f, f, uj02, A, d102, (i7 & 8078) | ((i7 << 6) & 234881024), 64);
                y413 = y414;
                z3 = z4;
                tdVar3 = tdVar4;
                pdVar3 = pdVar5;
            }
            r = d10.r();
            if (r == null) {
                r.d = new wd(xzVar, mi0, z3, y413, pdVar3, tdVar3, sp02, piVar2, i, i2);
                return;
            }
            return;
        }
        z2 = z;
        if ((i6 & 3072) != 0) {
        }
        if ((i6 & 24576) != 0) {
        }
        if ((196608 & i6) != 0) {
        }
        if ((i7 & 64) == 0) {
        }
        i4 = i7 & 128;
        if (i4 == 0) {
        }
        if ((i7 & 256) == 0) {
        }
        if ((805306368 & i6) == 0) {
        }
        i5 = 1;
        if ((306783379 & i3) == 306783378) {
        }
        if (d102.O(i3 & 1, (306783379 & i3) == 306783378)) {
        }
        r = d10.r();
        if (r == null) {
        }
    }

    public static boolean z() {
        try {
            Method declaredMethod;
            Object invoke;
            if (n4.R0 == null) {
                n4.R0 = Class.forName("android.os.SystemProperties");
            }
            Object obj = null;
            if (n4.S0 == null) {
                Class cls = n4.R0;
                if (cls != null) {
                    declaredMethod = cls.getDeclaredMethod("getBoolean", new Class[]{String.class, Boolean.TYPE});
                } else {
                    declaredMethod = null;
                }
                n4.S0 = declaredMethod;
            }
            declaredMethod = n4.S0;
            if (declaredMethod != null) {
                invoke = declaredMethod.invoke(null, new Object[]{"debug.layout", Boolean.FALSE});
            } else {
                invoke = null;
            }
            if (invoke instanceof Boolean) {
                obj = (Boolean) invoke;
            }
            return k70.p(obj, Boolean.TRUE);
        } catch (Exception unused) {
            return false;
        }
    }

    public static gh g(gh ghVar) {
        aj1 aj1 = vd1.g;
        if (a5.r(ghVar.b, 12884901888L)) {
            gh ghVar2 = (ay0) ghVar;
            aj1 aj12 = ghVar2.d;
            if (!vn.l(aj12, aj1)) {
                ghVar = ghVar2;
                return new ay0(ghVar.a, ghVar.h, aj1, vn.K(vn.j(r2.c.b, aj12.a(), aj1.a()), ghVar2.i), ghVar.k, ghVar.n, ghVar.e, ghVar.f, ghVar.g, -1);
            }
        }
        return ghVar;
    }

    public static final String U(float f) {
        if (Float.isNaN(f)) {
            return "NaN";
        }
        if (Float.isInfinite(f)) {
            return f < 0.0f ? "-Infinity" : "Infinity";
        } else {
            int max = Math.max(1, 0);
            float pow = (float) Math.pow(10.0d, (double) max);
            f *= pow;
            int i = (int) f;
            if (f - ((float) i) >= 0.5f) {
                i++;
            }
            f = ((float) i) / pow;
            return max > 0 ? String.valueOf(f) : String.valueOf((int) f);
        }
    }

    public static final int m(long j, long j2) {
        boolean F = vn.F(j);
        if (F != vn.F(j2)) {
            return F ? -1 : 1;
        } else {
            int signum = (int) Math.signum(vn.v(j) - vn.v(j2));
            if (Math.min(vn.v(j), vn.v(j2)) >= 0.0f) {
                if (vn.E(j) != vn.E(j2)) {
                    return vn.E(j) ? -1 : 1;
                }
            }
            return signum;
        }
    }

    public static final float[] L(float[] fArr, float[] fArr2) {
        if (fArr.length >= 9) {
            if (fArr2.length >= 3) {
                float f = fArr2[0];
                float f2 = fArr2[1];
                float f3 = fArr2[2];
                fArr2[0] = (fArr[6] * f3) + ((fArr[3] * f2) + (fArr[0] * f));
                fArr2[1] = (fArr[7] * f3) + ((fArr[4] * f2) + (fArr[1] * f));
                fArr2[2] = (fArr[8] * f3) + ((fArr[5] * f2) + (fArr[2] * f));
                return fArr2;
            }
        }
        return fArr2;
    }

    public static int p(double d) {
        d /= 100.0d;
        int round = (int) Math.round((d <= 0.0031308d ? d * 12.92d : (Math.pow(d, 0.4166666666666667d) * 1.055d) - 0.055d) * 255.0d);
        if (round < 0) {
            return 0;
        }
        return round > 255 ? 255 : round;
    }

    public static final long h(long j, long j2) {
        if (j != 4611686018427387903L) {
            if (j != -4611686018427387903L) {
                if (j2 != 4611686018427387903L) {
                    if (j2 != -4611686018427387903L) {
                        return sb0.i(j + j2);
                    }
                }
                return j2;
            }
        }
        if (-4611686018427387903L >= j2 || j2 >= 4611686018427387903L) {
            if ((j2 ^ j) < 0) {
                return 9223372036854759646L;
            }
        }
        return j;
    }

    public static final void e(ah1 ah1, ba0 ba0) {
        long B = ba0.J.c.B(0);
        int round = Math.round(Float.intBitsToFloat((int) (B >> 32)));
        int round2 = Math.round(Float.intBitsToFloat((int) (B & 4294967295L)));
        ah1.layout(round, round2, ah1.getMeasuredWidth() + round, ah1.getMeasuredHeight() + round2);
    }

    public static final pk o(gh ghVar, gh ghVar2) {
        if (ghVar == ghVar2) {
            return new pk(ghVar, ghVar, 1);
        }
        return (a5.r(ghVar.b, 12884901888L) && a5.r(ghVar2.b, 12884901888L)) ? new ok((ay0) ghVar, (ay0) ghVar2) : new pk(ghVar, ghVar2, 0);
    }

    public static final void P(a61 a61, int i, Object obj) {
        i = a61.h(i);
        Object[] objArr = a61.c;
        Object obj2 = objArr[i];
        objArr[i] = oj.a;
        if (obj != obj2) {
            StringBuilder dl1 = new dl1("Slot table is out of sync (expected ");
            dl1.append(obj);
            dl1.append(", got ");
            dl1.append(obj2);
            dl1.append(')');
            FileProvider.a(dl1.toString());
        }
    }

    public static final int s(int i, List list) {
        int size = list.size() - 1;
        int i2 = 0;
        while (i2 <= size) {
            int i3 = (i2 + size) >>> 1;
            int y = k70.y(((u70) list.get(i3)).b, i);
            if (y < 0) {
                i2 = i3 + 1;
            } else if (y <= 0) {
                return i3;
            } else {
                size = i3 - 1;
            }
        }
        return -(i2 + 1);
    }

    public static float G(int i) {
        float f = ((float) i) / 255.0f;
        return (f <= 0.04045f ? f / 12.92f : (float) Math.pow((double) ((f + 0.055f) / 1.055f), 2.4000000953674316d)) * 100.0f;
    }

    public static final void k(w51 w51, ArrayList arrayList, int i) {
        boolean l = w51.l(i);
        int[] iArr = w51.b;
        if (l) {
            arrayList.add(w51.n(i));
            return;
        }
        int i2 = iArr[(i * 5) + 3] + i;
        for (int i3 = i + 1; i3 < i2; i3 += iArr[(i3 * 5) + 3]) {
            vn.k(w51, arrayList, i3);
        }
    }

    public static final boolean l(aj1 aj1, aj1 aj12) {
        if (aj1 == aj12) {
            return true;
        }
        return Math.abs(aj1.a - aj12.a) < 0.001f && Math.abs(aj1.b - aj12.b) < 0.001f;
    }

    public static final mi0 H(d10 d10, mi0 mi0) {
        if (mi0.d(i4.u)) {
            return mi0;
        }
        d10.S(1219399079, 0, null, null);
        mi0 = (mi0) mi0.a(new n(3, d10), ji0.a);
        d10.p(false);
        return mi0;
    }

    public static final void f(List list, int i, int i2) {
        i = vn.s(i, list);
        if (i < 0) {
            i = -(i + 1);
        }
        while (i < list.size() && ((u70) list.get(i)).b < i2) {
            u70 u70 = (u70) list.remove(i);
        }
    }

    public static sl O(ql qlVar, sl slVar) {
        slVar.getClass();
        return slVar == st.e ? qlVar : (sl) slVar.p(new h90(11), qlVar);
    }

    public static mi0 N(mi0 mi0, wp0 wp0, float f, pb pbVar, int i) {
        nb nbVar = e3.j;
        if ((i & 16) != 0) {
            f = 1.0f;
        }
        return mi0.b(new xp0(wp0, nbVar, f, pbVar));
    }

    public static final void D(d10 d10, m00 m00) {
        m00.getClass();
        vd1.e(2, m00);
        m00.f(d10, Integer.valueOf(1));
    }

    public static sl J(ql qlVar, rl rlVar) {
        rlVar.getClass();
        return k70.p(qlVar.getKey(), rlVar) ? st.e : qlVar;
    }

    public static ql t(ql qlVar, rl rlVar) {
        rlVar.getClass();
        return k70.p(qlVar.getKey(), rlVar) ? qlVar : null;
    }

    public static final mi0 I(d10 d10, mi0 mi0) {
        d10.W(439770924);
        mi0 = vn.H(d10, mi0);
        d10.p(false);
        return mi0;
    }

    public static final boolean E(long j) {
        return (j & 2) != 0;
    }

    public static final boolean F(long j) {
        return (j & 1) != 0;
    }

    public static final long r(long j) {
        j = (j << 1) + 1;
        gs.e.getClass();
        int i = hs.a;
        return j;
    }

    public static final mi0 M(mi0 mi0, i00 i00) {
        return mi0.b(new uk(i00));
    }

    public static final mi0 q(mi0 mi0, n7 n7Var) {
        return mi0.b(new as(n7Var));
    }

    public static final float v(long j) {
        return Float.intBitsToFloat((int) (j >> 32));
    }

    public static final String y(Object obj) {
        return Integer.toHexString(System.identityHashCode(obj));
    }
}