package defpackage;

import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: c80 */
public class c80 extends h80 {
    public final boolean g;

    public c80(a80 a80) {
        boolean z = true;
        super(true);
        O(a80);
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = h80.f;
        pf pfVar = (pf) atomicReferenceFieldUpdater.get(this);
        d80 d80 = pfVar instanceof qf ? (qf) pfVar : null;
        if (d80 != null) {
            h80 j = d80.j();
            while (!j.J()) {
                pfVar = (pf) atomicReferenceFieldUpdater.get(j);
                d80 = pfVar instanceof qf ? (qf) pfVar : null;
                if (d80 != null) {
                    j = d80.j();
                }
            }
            this.g = z;
        }
        z = false;
        this.g = z;
    }

    public final boolean J() {
        return this.g;
    }

    public final boolean K() {
        return true;
    }
}