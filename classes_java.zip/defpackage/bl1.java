package defpackage;

import android.database.ContentObserver;
import android.net.Uri;
import android.os.Handler;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bl1 */
public final class bl1 extends ContentObserver {
    public final /* synthetic */ id a;

    public final void onChange(boolean z, Uri uri) {
        this.a.s(we1.a);
    }

    public bl1(id idVar, Handler handler) {
        this.a = idVar;
        super(handler);
    }
}