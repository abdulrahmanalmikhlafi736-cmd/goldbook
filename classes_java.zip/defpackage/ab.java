package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ab */
final class ab extends qi0 {
    public final long a;
    public final float b = 1.0f;
    public final y41 c;

    public final boolean equals(Object obj) {
        ab abVar = obj instanceof ab ? (ab) obj : null;
        if (abVar != null) {
            if (n60.c(this.a, abVar.a) != null && this.b == abVar.b && k70.p(this.c, abVar.c)) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        int i = zg.j;
        return this.c.hashCode() + fu0.z(this.b, pe1.a(this.a) * 961, 31);
    }

    public final void f(li0 li0) {
        bb bbVar = (bb) li0;
        bbVar.s = this.a;
        y41 y41 = bbVar.t;
        y41 y412 = this.c;
        if (!k70.p(y41, y412)) {
            bbVar.t = y412;
            jb0.n(bbVar);
        }
        a5.x(bbVar);
    }

    public final li0 e() {
        bb li0 = new li0();
        li0.s = this.a;
        li0.t = this.c;
        li0.u = 9205357640488583168L;
        return li0;
    }

    public ab(long j, y41 y41) {
        this.a = j;
        this.c = y41;
    }
}