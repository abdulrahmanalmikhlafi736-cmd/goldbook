package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bn */
public final class bn extends u91 implements m00 {
    public final /* synthetic */ int i;
    public int j;
    public final /* synthetic */ tn k;

    /* JADX WARNING: Missing block: B:19:0x0049, code:
            if (r10 == r6) goto L_0x004b;
     */
    /* JADX WARNING: Missing block: B:38:0x0097, code:
            if (r10.b(r0, r9) == r6) goto L_0x0099;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final Object p(Object obj) {
        int i = this.i;
        Object obj2 = we1.a;
        Object obj3 = null;
        String str = "call to 'resume' before 'invoke' with coroutine";
        cm cmVar = cm.e;
        tn tnVar = this.k;
        switch (i) {
            case 0:
                i = this.j;
                if (i == 0) {
                    nb0.t(obj);
                    this.j = 1;
                    if (tn.c(tnVar, this) == cmVar) {
                        obj2 = cmVar;
                    }
                } else if (i == 1) {
                    nb0.t(obj);
                } else {
                    od.p(str);
                    obj2 = null;
                }
                return obj2;
            case 1:
                i = this.j;
                if (i == 0) {
                    nb0.t(obj);
                    p3 p3Var = tnVar.l;
                    this.j = 1;
                    cm e0 = ((uh) p3Var.f).e0(this);
                    if (e0 != cmVar) {
                        e0 = obj2;
                    }
                    if (e0 == cmVar) {
                        obj2 = cmVar;
                        return obj2;
                    }
                } else if (i != 1) {
                    if (i == 2) {
                        nb0.t(obj);
                    } else {
                        od.p(str);
                        obj2 = null;
                    }
                    return obj2;
                } else {
                    nb0.t(obj);
                }
                tw o = wl1.o(tnVar.h().c, -1);
                rd rdVar = new rd(1, tnVar);
                this.j = 2;
                break;
            default:
                pg0 pg0 = tnVar.k;
                int i2 = this.j;
                if (i2 != 0) {
                    if (i2 == 1) {
                        try {
                            nb0.t(obj);
                        } catch (Throwable th) {
                            obj3 = new sv0(th, -1);
                        }
                    } else if (i2 == 2) {
                        nb0.t(obj);
                        obj3 = (z71) obj;
                    } else {
                        od.p(str);
                    }
                    return obj3;
                }
                nb0.t(obj);
                if (pg0.o() instanceof xv) {
                    obj3 = pg0.o();
                    return obj3;
                }
                this.j = 1;
                if (tn.e(tnVar, this) == cmVar) {
                    obj3 = cmVar;
                    return obj3;
                }
                this.j = 2;
                obj = tn.f(tnVar, false, this);
                break;
        }
    }

    public final Object f(Object obj, Object obj2) {
        int i = this.i;
        we1 we1 = we1.a;
        switch (i) {
            case 0:
                return ((bn) n((ml) obj2, (uw) obj)).p(we1);
            case 1:
                return ((bn) n((ml) obj2, (bm) obj)).p(we1);
            default:
                return ((bn) n((ml) obj2, (bm) obj)).p(we1);
        }
    }

    public final ml n(ml mlVar, Object obj) {
        int i = this.i;
        tn tnVar = this.k;
        switch (i) {
            case 0:
                return new bn(tnVar, mlVar, 0);
            case 1:
                return new bn(tnVar, mlVar, 1);
            default:
                return new bn(tnVar, mlVar, 2);
        }
    }

    public /* synthetic */ bn(tn tnVar, ml mlVar, int i) {
        this.i = i;
        this.k = tnVar;
        super(2, mlVar);
    }
}