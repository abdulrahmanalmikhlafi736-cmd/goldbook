package defpackage;

import java.util.ConcurrentModificationException;
import java.util.ListIterator;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: c30 */
public final class c30 implements ListIterator, w80 {
    public final /* synthetic */ int e = 0;
    public int f;
    public int g;
    public int h;
    public final Object i;

    public final Object next() {
        int i = this.e;
        Object obj = null;
        Object obj2 = this.i;
        switch (i) {
            case 0:
                ak0 ak0 = ((e30) obj2).e;
                int i2 = this.f;
                this.f = i2 + 1;
                Object f = ak0.f(i2);
                f.getClass();
                return (li0) f;
            case 1:
                a();
                i = this.f;
                pe0 pe0 = (pe0) obj2;
                if (i < pe0.g) {
                    this.f = i + 1;
                    this.g = i;
                    obj = pe0.e[pe0.f + i];
                } else {
                    od.n();
                }
                return obj;
            case 2:
                b();
                i = this.f;
                qe0 qe0 = (qe0) obj2;
                if (i < qe0.f) {
                    this.f = i + 1;
                    this.g = i;
                    obj = qe0.e[i];
                } else {
                    od.n();
                }
                return obj;
            default:
                c();
                i = this.f + 1;
                this.g = i;
                z61 z61 = (z61) obj2;
                zi1.j(i, z61.size());
                obj = z61.get(i);
                this.f = i;
                return obj;
        }
    }

    public final Object previous() {
        int i = this.e;
        Object obj = null;
        Object obj2 = this.i;
        switch (i) {
            case 0:
                ak0 ak0 = ((e30) obj2).e;
                int i2 = this.f - 1;
                this.f = i2;
                Object f = ak0.f(i2);
                f.getClass();
                return (li0) f;
            case 1:
                a();
                i = this.f;
                if (i > 0) {
                    i--;
                    this.f = i;
                    this.g = i;
                    pe0 pe0 = (pe0) obj2;
                    obj = pe0.e[pe0.f + i];
                } else {
                    od.n();
                }
                return obj;
            case 2:
                b();
                i = this.f;
                if (i > 0) {
                    i--;
                    this.f = i;
                    this.g = i;
                    obj = ((qe0) obj2).e[i];
                } else {
                    od.n();
                }
                return obj;
            default:
                c();
                z61 z61 = (z61) obj2;
                zi1.j(this.f, z61.size());
                i = this.f;
                this.g = i;
                Object obj3 = z61.get(i);
                this.f--;
                return obj3;
        }
    }

    public final void remove() {
        int i = this.e;
        String str = "Call next() or previous() before removing element from the iterator.";
        Object obj = this.i;
        switch (i) {
            case 0:
                throw new dl1("Operation is not supported for read-only collection");
            case 1:
                pe0 pe0 = (pe0) obj;
                a();
                i = this.g;
                if (i != -1) {
                    pe0.b(i);
                    this.f = this.g;
                    this.g = -1;
                    this.h = pe0.modCount;
                } else {
                    od.p(str);
                }
                return;
            case 2:
                qe0 qe0 = (qe0) obj;
                b();
                i = this.g;
                if (i != -1) {
                    qe0.b(i);
                    this.f = this.g;
                    this.g = -1;
                    this.h = qe0.modCount;
                } else {
                    od.p(str);
                }
                return;
            default:
                c();
                z61 z61 = (z61) obj;
                z61.remove(this.g);
                this.f--;
                this.g = -1;
                this.h = zi1.v(z61);
                return;
        }
    }

    public final void add(Object obj) {
        int i = this.e;
        Object obj2 = this.i;
        switch (i) {
            case 0:
                throw new dl1("Operation is not supported for read-only collection");
            case 1:
                a();
                pe0 pe0 = (pe0) obj2;
                i = this.f;
                this.f = i + 1;
                pe0.add(i, obj);
                this.g = -1;
                this.h = pe0.modCount;
                return;
            case 2:
                b();
                qe0 qe0 = (qe0) obj2;
                i = this.f;
                this.f = i + 1;
                qe0.add(i, obj);
                this.g = -1;
                this.h = qe0.modCount;
                return;
            default:
                c();
                z61 z61 = (z61) obj2;
                z61.add(this.f + 1, obj);
                this.g = -1;
                this.f++;
                this.h = zi1.v(z61);
                return;
        }
    }

    public final void set(Object obj) {
        int i = this.e;
        String str = "Call next() or previous() before replacing element from the iterator.";
        Object obj2 = this.i;
        int i2;
        switch (i) {
            case 0:
                throw new dl1("Operation is not supported for read-only collection");
            case 1:
                a();
                i2 = this.g;
                if (i2 != -1) {
                    ((pe0) obj2).set(i2, obj);
                } else {
                    od.p(str);
                }
                return;
            case 2:
                b();
                i2 = this.g;
                if (i2 != -1) {
                    ((qe0) obj2).set(i2, obj);
                } else {
                    od.p(str);
                }
                return;
            default:
                z61 z61 = (z61) obj2;
                c();
                i = this.g;
                if (i >= 0) {
                    z61.set(i, obj);
                    this.h = zi1.v(z61);
                } else {
                    od.p("Cannot call set before the first call to next() or previous() or immediately after a call to add() or remove()");
                }
                return;
        }
    }

    public final boolean hasNext() {
        int i = this.e;
        Object obj = this.i;
        boolean z = false;
        switch (i) {
            case 0:
                if (this.f < this.h) {
                    z = true;
                }
                return z;
            case 1:
                if (this.f < ((pe0) obj).g) {
                    z = true;
                }
                return z;
            case 2:
                if (this.f < ((qe0) obj).f) {
                    z = true;
                }
                return z;
            default:
                if (this.f < ((z61) obj).size() - 1) {
                    z = true;
                }
                return z;
        }
    }

    public final boolean hasPrevious() {
        switch (this.e) {
            case 0:
                return this.f > this.g;
            case 1:
                return this.f > 0;
            case 2:
                return this.f > 0;
            default:
                return this.f >= 0;
        }
    }

    public final int previousIndex() {
        int i;
        switch (this.e) {
            case 0:
                return (this.f - this.g) - 1;
            case 1:
                i = this.f;
                break;
            case 2:
                i = this.f;
                break;
            default:
                return this.f;
        }
        return i - 1;
    }

    public final int nextIndex() {
        switch (this.e) {
            case 0:
                return this.f - this.g;
            case 1:
                return this.f;
            case 2:
                return this.f;
            default:
                return this.f + 1;
        }
    }

    public c30(z61 z61, int i) {
        this.i = z61;
        this.f = i - 1;
        this.g = -1;
        this.h = zi1.v(z61);
    }

    public void a() {
        if (((pe0) this.i).i.modCount != this.h) {
            throw new ConcurrentModificationException();
        }
    }

    public void b() {
        if (((qe0) this.i).modCount != this.h) {
            throw new ConcurrentModificationException();
        }
    }

    public void c() {
        if (zi1.v((z61) this.i) != this.h) {
            throw new ConcurrentModificationException();
        }
    }

    public c30(pe0 pe0, int i) {
        this.i = pe0;
        this.f = i;
        this.g = -1;
        this.h = pe0.modCount;
    }

    public c30(qe0 qe0, int i) {
        this.i = qe0;
        this.f = i;
        this.g = -1;
        this.h = qe0.modCount;
    }

    public c30(e30 e30, int i, int i2, int i3) {
        this.i = e30;
        this.f = i;
        this.g = i2;
        this.h = i3;
    }

    public c30(e30 e30, int i, int i2) {
        if ((i2 & 1) != 0) {
            i = 0;
        }
        this(e30, i, 0, e30.e.b);
    }
}