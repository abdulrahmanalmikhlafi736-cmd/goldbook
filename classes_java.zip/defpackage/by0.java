package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: by0 */
public final class by0 {
    public final int hashCode() {
        return Float.floatToIntBits(0.1f) + fu0.z(0.08f, fu0.z(0.1f, Float.floatToIntBits(0.16f) * 31, 31), 31);
    }

    public final boolean equals(Object obj) {
        return this == obj || (obj instanceof by0);
    }

    public final String toString() {
        return "RippleAlpha(draggedAlpha=0.16, focusedAlpha=0.1, hoveredAlpha=0.08, pressedAlpha=0.1)";
    }
}