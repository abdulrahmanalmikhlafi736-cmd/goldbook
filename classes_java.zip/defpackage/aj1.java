package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: aj1 */
public final class aj1 {
    public final float a;
    public final float b;

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof aj1)) {
            return false;
        }
        aj1 aj1 = (aj1) obj;
        return Float.compare(this.a, aj1.a) == 0 && Float.compare(this.b, aj1.b) == 0;
    }

    public final String toString() {
        StringBuilder dl1 = new dl1("WhitePoint(x=");
        dl1.append(this.a);
        dl1.append(", y=");
        return fu0.F(dl1, this.b, ')');
    }

    public final float[] a() {
        float f = this.a;
        float f2 = this.b;
        float f3 = f / f2;
        f = ((1.0f - f) - f2) / f2;
        return new float[]{f3, 1.0f, f};
    }

    public final int hashCode() {
        return Float.floatToIntBits(this.b) + (Float.floatToIntBits(this.a) * 31);
    }

    public aj1(float f, float f2) {
        this.a = f;
        this.b = f2;
    }
}