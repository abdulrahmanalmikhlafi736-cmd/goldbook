package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: c6 */
public abstract class c6 {
    public static final float[] a;

    static {
        float[] fArr = new float[101];
        a = fArr;
        float[] fArr2 = new float[101];
        float f = 0.0f;
        int i = 0;
        float f2 = 0.0f;
        while (true) {
            float f3 = 1.0f;
            float f4;
            if (i < 100) {
                float f5;
                float f6;
                float f7;
                float f8;
                float f9;
                float f10;
                float f11;
                float f12;
                float f13 = ((float) i) / 100.0f;
                float f14 = 1.0f;
                while (true) {
                    f5 = ((f14 - f) / 2.0f) + f;
                    f6 = f3 - f5;
                    f7 = (f5 * 3.0f) * f6;
                    f8 = (f5 * f5) * f5;
                    float f15 = (((f5 * 0.35000002f) + (f6 * 0.175f)) * f7) + f8;
                    f4 = f3;
                    f9 = 2.0f;
                    f10 = 3.0f;
                    if (((double) Math.abs(f15 - f13)) < 1.0E-5d) {
                        break;
                    }
                    if (f15 > f13) {
                        f14 = f5;
                    } else {
                        f = f5;
                    }
                    f3 = f4;
                }
                f3 = 0.5f;
                fArr[i] = (((f6 * 0.5f) + f5) * f7) + f8;
                f14 = f4;
                while (true) {
                    f5 = ((f14 - f2) / f9) + f2;
                    f11 = f4 - f5;
                    f12 = (f5 * f10) * f11;
                    f6 = (f5 * f5) * f5;
                    f7 = (((f11 * f3) + f5) * f12) + f6;
                    float f16 = f14;
                    if (((double) Math.abs(f7 - f13)) < 1.0E-5d) {
                        break;
                    }
                    if (f7 > f13) {
                        f14 = f5;
                    } else {
                        f2 = f5;
                        f14 = f16;
                    }
                    f3 = 0.5f;
                }
                fArr2[i] = (((f5 * 0.35000002f) + (f11 * 0.175f)) * f12) + f6;
                i++;
            } else {
                f4 = 1.0f;
                fArr2[100] = f4;
                fArr[100] = f4;
                return;
            }
        }
    }

    public static b6 a(float f) {
        float f2 = 0.0f;
        float f3 = 1.0f;
        f = sb0.g(f, 0.0f, 1.0f);
        int i = (int) (100.0f * f);
        if (i < 100) {
            f2 = ((float) i) / 100.0f;
            int i2 = i + 1;
            float f4 = ((float) i2) / 100.0f;
            float[] fArr = a;
            float f5 = fArr[i];
            f3 = (fArr[i2] - f5) / (f4 - f2);
            f2 = f3;
            f3 = ((f - f2) * f3) + f5;
        }
        return new aj1(f3, f2);
    }
}