package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ax */
public final class ax extends nl {
    public g8 h;
    public Object i;
    public /* synthetic */ Object j;
    public final /* synthetic */ g8 k;
    public int l;

    public final Object p(Object obj) {
        this.j = obj;
        this.l |= Integer.MIN_VALUE;
        return this.k.k(null, this);
    }

    public ax(g8 g8Var, ml mlVar) {
        this.k = g8Var;
        super(mlVar);
    }
}