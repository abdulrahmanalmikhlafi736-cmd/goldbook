package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: b3 */
public final /* synthetic */ class b3 implements m00 {
    public final /* synthetic */ pi e;
    public final /* synthetic */ mi0 f;
    public final /* synthetic */ m00 g;
    public final /* synthetic */ m00 h;
    public final /* synthetic */ y41 i;
    public final /* synthetic */ long j;
    public final /* synthetic */ long k;
    public final /* synthetic */ long l;
    public final /* synthetic */ long m;
    public final /* synthetic */ long n;

    public final Object f(Object obj, Object obj2) {
        d10 d10 = (d10) obj;
        ((Integer) obj2).getClass();
        int s = wc0.s(7);
        pi piVar = this.e;
        mi0 mi0 = this.f;
        pi piVar2 = piVar;
        pi piVar3 = piVar2;
        pi piVar4 = piVar3;
        pi piVar5 = piVar4;
        pi piVar6 = piVar5;
        pi piVar7 = piVar6;
        pi piVar8 = piVar7;
        mi0 mi02 = mi0;
        d3.a(piVar8, mi02, this.g, this.h, this.i, this.j, this.k, this.l, this.m, this.n, d10, s);
        return we1.a;
    }

    public /* synthetic */ b3(pi piVar, mi0 mi0, m00 m00, m00 m002, y41 y41, long j, long j2, long j3, long j4, long j5, int i) {
        this.e = piVar;
        this.f = mi0;
        this.g = m00;
        this.h = m002;
        this.i = y41;
        this.j = j;
        this.k = j2;
        this.l = j3;
        this.m = j4;
        this.n = j5;
    }
}