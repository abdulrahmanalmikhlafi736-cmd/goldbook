package defpackage;

import android.view.autofill.AutofillManager;
import java.util.List;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ak0 */
public final class ak0 {
    public Object[] a;
    public int b;

    public final void l(int i, int i2) {
        String str = "Start (";
        if (i >= 0) {
            int i3 = this.b;
            if (i <= i3 && i2 >= 0 && i2 <= i3) {
                if (i2 < i) {
                    StringBuilder dl1 = new dl1(str);
                    dl1.append(i);
                    dl1.append(") is more than end (");
                    dl1.append(i2);
                    dl1.append(')');
                    throw new dl1(dl1.toString());
                } else if (i2 != i) {
                    if (i2 < i3) {
                        Object[] objArr = this.a;
                        ba.Y(objArr, objArr, i, i2, i3);
                    }
                    int i4 = this.b;
                    i = i4 - (i2 - i);
                    ba.c0(this.a, i, i4);
                    this.b = i;
                    return;
                } else {
                    return;
                }
            }
        }
        int i5 = this.b;
        StringBuilder dl12 = new dl1(str);
        dl12.append(i);
        dl12.append(") and end (");
        dl12.append(i2);
        dl12.append(") must be in 0..");
        dl12.append(i5);
        throw new dl1(dl12.toString());
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("[");
        Object[] objArr = this.a;
        int i = this.b;
        for (int i2 = 0; i2 < i; i2++) {
            ak0 ak0 = objArr[i2];
            if (i2 == -1) {
                stringBuilder.append("...");
                break;
            }
            if (i2 != 0) {
                stringBuilder.append(", ");
            }
            stringBuilder.append(ak0 == this ? "(this)" : String.valueOf(ak0));
        }
        stringBuilder.append("]");
        return stringBuilder.toString();
    }

    public final void c(List list) {
        if (!list.isEmpty()) {
            int i = this.b;
            int size = list.size() + i;
            Object[] objArr = this.a;
            if (objArr.length < size) {
                m(size, objArr);
            }
            Object[] objArr2 = this.a;
            int size2 = list.size();
            for (int i2 = 0; i2 < size2; i2++) {
                objArr2[i2 + i] = list.get(i2);
            }
            this.b = list.size() + this.b;
        }
    }

    public final boolean equals(Object obj) {
        if (obj instanceof ak0) {
            ak0 ak0 = (ak0) obj;
            int i = ak0.b;
            int i2 = this.b;
            if (i == i2) {
                Object[] objArr = this.a;
                Object[] objArr2 = ak0.a;
                q60 w = sb0.w(0, i2);
                i2 = w.e;
                i = w.f;
                if (i2 <= i) {
                    while (k70.p(objArr[i2], objArr2[i2])) {
                        if (i2 != i) {
                            i2++;
                        }
                    }
                    return false;
                }
                return true;
            }
        }
        return false;
    }

    public final void b(ak0 ak0) {
        ak0.getClass();
        if (!ak0.h()) {
            int i = this.b + ak0.b;
            Object[] objArr = this.a;
            if (objArr.length < i) {
                m(i, objArr);
            }
            ba.Y(ak0.a, this.a, this.b, 0, ak0.b);
            this.b += ak0.b;
        }
    }

    public final AutofillManager g(Object obj) {
        Object[] objArr = this.a;
        int i = 0;
        int i2;
        if (obj == null) {
            i2 = this.b;
            while (i < i2) {
                if (objArr[i] == null) {
                    return i;
                }
                i++;
            }
        } else {
            i2 = this.b;
            while (i < i2) {
                if (obj.equals(objArr[i])) {
                    return i;
                }
                i++;
            }
        }
        return -1;
    }

    public final Object k(int i) {
        if (i >= 0) {
            int i2 = this.b;
            if (i < i2) {
                Object[] objArr = this.a;
                Object obj = objArr[i];
                if (i != i2 - 1) {
                    ba.Y(objArr, objArr, i, i + 1, i2);
                }
                i = this.b - 1;
                this.b = i;
                objArr[i] = null;
                return obj;
            }
        }
        o(i);
        throw null;
    }

    public final int hashCode() {
        Object[] objArr = this.a;
        int i = this.b;
        int i2 = 0;
        int i3 = i2;
        while (i2 < i) {
            Object obj = objArr[i2];
            i3 += (obj != null ? obj.hashCode() : 0) * 31;
            i2++;
        }
        return i3;
    }

    public final void o(int i) {
        StringBuilder H = fu0.H(i, "Index ", " must be in 0..");
        H.append(this.b - 1);
        throw new dl1(H.toString());
    }

    public final void a(Object obj) {
        int i = this.b + 1;
        Object[] objArr = this.a;
        if (objArr.length < i) {
            m(i, objArr);
        }
        Object[] objArr2 = this.a;
        int i2 = this.b;
        objArr2[i2] = obj;
        this.b = i2 + 1;
    }

    public final void m(int i, Object[] objArr) {
        objArr.getClass();
        int length = objArr.length;
        Object[] objArr2 = new Object[Math.max(i, (length * 3) / 2)];
        ba.Y(objArr, objArr2, 0, 0, length);
        this.a = objArr2;
    }

    public final Object e() {
        if (!h()) {
            return this.a[0];
        }
        throw new dl1("ObjectList is empty.");
    }

    public final Object n(int i, Object obj) {
        if (i < 0 || i >= this.b) {
            o(i);
            throw null;
        }
        Object[] objArr = this.a;
        Object obj2 = objArr[i];
        objArr[i] = obj;
        return obj2;
    }

    public final Object f(int i) {
        if (i >= 0 && i < this.b) {
            return this.a[i];
        }
        o(i);
        throw null;
    }

    public ak0(int i) {
        this.a = i == 0 ? tm0.a : new Object[i];
    }

    public final boolean j(Object obj) {
        AutofillManager g = ((AutofillManager) this);
        if (g < null) {
            return false;
        }
        k(g);
        return true;
    }

    public final void d() {
        ba.c0(this.a, 0, this.b);
        this.b = 0;
    }

    public final boolean h() {
        return this.b == 0;
    }

    public final boolean i() {
        return this.b != 0;
    }

    public /* synthetic */ ak0() {
        super(16);
    }
}