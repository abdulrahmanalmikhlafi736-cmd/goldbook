package defpackage;

import android.graphics.Rect;
import android.view.FocusFinder;
import android.view.View;
import android.view.ViewGroup;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ay */
public abstract class ay {
    public static final int[] a = new int[2];
    public static final Rect b = new Rect();

    public static final boolean b(View view, Integer num, Rect rect) {
        if (num == null) {
            return view.requestFocus();
        }
        if (!(view instanceof ViewGroup)) {
            return view.requestFocus(num.intValue(), rect);
        }
        ViewGroup viewGroup = (ViewGroup) view;
        if (viewGroup.isFocused()) {
            return true;
        }
        if (viewGroup.isFocusable() && !viewGroup.hasFocus()) {
            return viewGroup.requestFocus(num.intValue(), rect);
        }
        if (view instanceof n4) {
            return ((n4) view).requestFocus(num.intValue(), rect);
        }
        if (rect != null) {
            view = FocusFinder.getInstance().findNextFocusFromRect(viewGroup, rect, num.intValue());
            return view != null ? view.requestFocus(num.intValue(), rect) : viewGroup.requestFocus(num.intValue(), rect);
        } else {
            View findNextFocus = FocusFinder.getInstance().findNextFocus(viewGroup, viewGroup.hasFocus() ? viewGroup.findFocus() : null, num.intValue());
            return findNextFocus != null ? findNextFocus.requestFocus(num.intValue()) : view.requestFocus(num.intValue());
        }
    }

    public static final ux d(int i) {
        if (i == 1) {
            return new h90(2);
        }
        if (i == 2) {
            return new h90(1);
        }
        if (i == 17) {
            return new h90(3);
        }
        if (i == 33) {
            return new h90(5);
        }
        if (i != 66) {
            return i != 130 ? null : new h90(6);
        } else {
            return new h90(4);
        }
    }

    public static final Integer c(int i) {
        if (i == 5) {
            return Integer.valueOf(33);
        }
        if (i == 6) {
            return Integer.valueOf(130);
        }
        if (i == 3) {
            return Integer.valueOf(17);
        }
        if (i == 4) {
            return Integer.valueOf(66);
        }
        if (i == 1) {
            return Integer.valueOf(2);
        }
        return i == 2 ? Integer.valueOf(1) : null;
    }

    public static final gw0 a(View view, View view2) {
        int[] iArr = a;
        view.getLocationInWindow(iArr);
        int i = iArr[0];
        int i2 = iArr[1];
        view2.getLocationInWindow(iArr);
        float f = (float) (i - iArr[0]);
        float f2 = (float) (i2 - iArr[1]);
        Rect rect = b;
        view.getFocusedRect(rect);
        f += (float) rect.left;
        return new gw0(f, ((float) rect.top) + f2, ((float) rect.width()) + f, (f2 + ((float) rect.top)) + ((float) rect.height()));
    }
}