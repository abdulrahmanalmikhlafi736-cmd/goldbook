package defpackage;

import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: db1 */
public abstract class db1 {
    public static final ThreadLocal a = new ThreadLocal();
    public static final long b = cm0.a(0, 0);

    public static final TextDirectionHeuristic b(int i) {
        if (i == 0) {
            return TextDirectionHeuristics.LTR;
        }
        if (i == 1) {
            return TextDirectionHeuristics.RTL;
        }
        if (i == 2) {
            return TextDirectionHeuristics.FIRSTSTRONG_LTR;
        }
        if (i == 3) {
            return TextDirectionHeuristics.FIRSTSTRONG_RTL;
        }
        if (i != 4) {
            return i != 5 ? TextDirectionHeuristics.FIRSTSTRONG_LTR : TextDirectionHeuristics.LOCALE;
        } else {
            return TextDirectionHeuristics.ANYRTL_LTR;
        }
    }

    public static final boolean a(int i, int i2) {
        return (((long) i2) & 4294967295L) | (((long) i) << 32);
    }
}