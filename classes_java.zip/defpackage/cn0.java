package defpackage;

import android.window.OnBackInvokedCallback;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cn0 */
public final /* synthetic */ class cn0 implements OnBackInvokedCallback {
    public final /* synthetic */ bn0 a;

    public /* synthetic */ cn0(bn0 bn0) {
        this.a = bn0;
    }

    public final void onBackInvoked() {
        this.a.a();
    }
}