package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: q */
public abstract class q implements ql {
    public final rl e;

    public q(rl rlVar) {
        this.e = rlVar;
    }

    public final /* bridge */ sl i(sl slVar) {
        return vn.O(this, slVar);
    }

    public /* bridge */ ql k(rl rlVar) {
        return vn.t(this, rlVar);
    }

    public final Object p(m00 m00, Object obj) {
        return m00.f(obj, this);
    }

    public /* bridge */ sl t(rl rlVar) {
        return vn.J(this, rlVar);
    }

    public final rl getKey() {
        return this.e;
    }
}