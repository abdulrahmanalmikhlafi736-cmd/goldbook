package defpackage;

import java.util.AbstractMap;
import java.util.AbstractSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: c61 */
public final class c61 extends AbstractMap {
    public static final /* synthetic */ int j = 0;
    public List e;
    public Map f;
    public boolean g;
    public volatile u9 h;
    public Map i;

    /* renamed from: g */
    public final Object put(Comparable comparable, Object obj) {
        b();
        int a = a(comparable);
        if (a >= 0) {
            return ((d61) this.e.get(a)).setValue(obj);
        }
        b();
        if (this.e.isEmpty() && !(this.e instanceof ArrayList)) {
            this.e = new h90(16);
        }
        a = -(a + 1);
        if (a >= 16) {
            return e().put(comparable, obj);
        }
        if (this.e.size() == 16) {
            d61 d61 = (d61) this.e.remove(15);
            e().put(d61.e, d61.f);
        }
        this.e.add(a, new d61(this, comparable, obj));
        return null;
    }

    public final boolean equals(Object obj) {
        if (this != obj) {
            if (!(obj instanceof c61)) {
                return super.equals(obj);
            }
            c61 c61 = (c61) obj;
            int size = size();
            if (size == c61.size()) {
                int size2 = this.e.size();
                if (size2 != c61.e.size()) {
                    return ((AbstractSet) entrySet()).equals(c61.entrySet());
                }
                int i = 0;
                while (i < size2) {
                    if (c(i).equals(c61.c(i))) {
                        i++;
                    }
                }
                if (size2 != size) {
                    return this.f.equals(c61.f);
                }
            }
            return false;
        }
        return true;
    }

    public final int a(Comparable comparable) {
        int compareTo;
        int size = this.e.size();
        int i = size - 1;
        if (i >= 0) {
            compareTo = comparable.compareTo(((d61) this.e.get(i)).e);
            if (compareTo > 0) {
                size++;
                return -size;
            } else if (compareTo == 0) {
                return i;
            }
        }
        size = 0;
        while (size <= i) {
            compareTo = (size + i) / 2;
            int compareTo2 = comparable.compareTo(((d61) this.e.get(compareTo)).e);
            if (compareTo2 < 0) {
                i = compareTo - 1;
            } else if (compareTo2 <= 0) {
                return compareTo;
            } else {
                size = compareTo + 1;
            }
        }
        size++;
        return -size;
    }

    public final Object h(int i) {
        b();
        Object obj = ((d61) this.e.remove(i)).f;
        if (!this.f.isEmpty()) {
            Iterator it = e().entrySet().iterator();
            Entry entry = (Entry) it.next();
            this.e.add(new d61(this, (Comparable) entry.getKey(), entry.getValue()));
            it.remove();
        }
        return obj;
    }

    public final int hashCode() {
        int i = 0;
        int i2 = 0;
        while (i < this.e.size()) {
            i2 += ((d61) this.e.get(i)).hashCode();
            i++;
        }
        return this.f.size() > 0 ? this.f.hashCode() + i2 : i2;
    }

    public final SortedMap e() {
        b();
        if (this.f.isEmpty() && !(this.f instanceof TreeMap)) {
            TreeMap treeMap = new TreeMap();
            this.f = treeMap;
            this.i = treeMap.descendingMap();
        }
        return (SortedMap) this.f;
    }

    public final Object remove(Object obj) {
        b();
        Comparable comparable = (Comparable) obj;
        int a = a(comparable);
        if (a >= 0) {
            return h(a);
        }
        return this.f.isEmpty() ? null : this.f.remove(comparable);
    }

    public final void clear() {
        b();
        if (!this.e.isEmpty()) {
            this.e.clear();
        }
        if (!this.f.isEmpty()) {
            this.f.clear();
        }
    }

    public final Object get(Object obj) {
        Comparable comparable = (Comparable) obj;
        int a = a(comparable);
        return a >= 0 ? ((d61) this.e.get(a)).f : this.f.get(comparable);
    }

    public final boolean containsKey(Object obj) {
        Comparable comparable = (Comparable) obj;
        if (a(comparable) < 0) {
            if (!this.f.containsKey(comparable)) {
                return false;
            }
        }
        return true;
    }

    public final Set d() {
        return this.f.isEmpty() ? Collections.EMPTY_SET : this.f.entrySet();
    }

    public static c61 f() {
        c61 abstractMap = new AbstractMap();
        abstractMap.e = Collections.EMPTY_LIST;
        Map map = Collections.EMPTY_MAP;
        abstractMap.f = map;
        abstractMap.i = map;
        return abstractMap;
    }

    public final Set entrySet() {
        if (this.h == null) {
            this.h = new u9(1, this);
        }
        return this.h;
    }

    public final int size() {
        return this.f.size() + this.e.size();
    }

    public final void b() {
        if (this.g) {
            throw new UnsupportedOperationException();
        }
    }

    public final Entry c(int i) {
        return (Entry) this.e.get(i);
    }
}