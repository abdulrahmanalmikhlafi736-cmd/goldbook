package defpackage;

import android.util.SparseArray;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ci0 */
public final class ci0 {
    public final SparseArray a;
    public fe1 b;

    public final void a(fe1 fe1, int i, int i2) {
        int a = fe1.a(i);
        SparseArray sparseArray = this.a;
        ci0 ci0 = sparseArray == null ? null : (ci0) sparseArray.get(a);
        if (ci0 == null) {
            ci0 = new h90(1);
            sparseArray.put(fe1.a(i), ci0);
        }
        if (i2 > i) {
            ci0.a(fe1, i + 1, i2);
        } else {
            ci0.b = fe1;
        }
    }

    public ci0(int i) {
        this.a = new h90(i);
    }
}