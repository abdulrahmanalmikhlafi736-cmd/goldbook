package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: c51 */
public final class c51 {
    public final oy0 a;
    public final oy0 b;
    public final oy0 c;
    public final oy0 d;
    public final oy0 e;
    public final oy0 f;
    public final oy0 g;
    public final oy0 h;

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof c51)) {
            return false;
        }
        c51 c51 = (c51) obj;
        return k70.p(this.a, c51.a) && k70.p(this.b, c51.b) && k70.p(this.c, c51.c) && k70.p(this.d, c51.d) && k70.p(this.e, c51.e) && k70.p(this.f, c51.f) && k70.p(this.g, c51.g) && k70.p(this.h, c51.h);
    }

    public final String toString() {
        StringBuilder dl1 = new dl1("Shapes(extraSmall=");
        dl1.append(this.a);
        dl1.append(", small=");
        dl1.append(this.b);
        dl1.append(", medium=");
        dl1.append(this.c);
        dl1.append(", large=");
        dl1.append(this.d);
        dl1.append(", largeIncreased=");
        dl1.append(this.f);
        dl1.append(", extraLarge=");
        dl1.append(this.e);
        dl1.append(", extralargeIncreased=");
        dl1.append(this.g);
        dl1.append(", extraExtraLarge=");
        dl1.append(this.h);
        dl1.append(')');
        return dl1.toString();
    }

    public final int hashCode() {
        return this.h.hashCode() + ((this.g.hashCode() + ((this.f.hashCode() + ((this.e.hashCode() + ((this.d.hashCode() + ((this.c.hashCode() + ((this.b.hashCode() + (this.a.hashCode() * 31)) * 31)) * 31)) * 31)) * 31)) * 31)) * 31);
    }

    public c51() {
        oy0 oy0 = z41.a;
        oy0 oy02 = z41.b;
        oy0 oy03 = z41.c;
        oy0 oy04 = z41.d;
        oy0 oy05 = z41.f;
        oy0 oy06 = z41.e;
        oy0 oy07 = z41.g;
        oy0 oy08 = z41.h;
        this.a = oy0;
        this.b = oy02;
        this.c = oy03;
        this.d = oy04;
        this.e = oy05;
        this.f = oy06;
        this.g = oy07;
        this.h = oy08;
    }
}