package defpackage;

import android.graphics.Path;
import android.graphics.Path.Direction;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Build.VERSION;
import android.view.View;
import android.view.ViewParent;
import android.view.ViewStructure;
import android.view.Window;
import android.view.autofill.AutofillId;
import android.view.autofill.AutofillValue;
import androidx.core.content.FileProvider;
import java.util.Collection;
import java.util.List;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dd0 */
public abstract class dd0 {
    public static y30 a;

    /* JADX WARNING: Removed duplicated region for block: B:191:0x03ac  */
    /* JADX WARNING: Removed duplicated region for block: B:190:0x03ab  */
    /* JADX WARNING: Removed duplicated region for block: B:194:0x03b3  */
    /* JADX WARNING: Removed duplicated region for block: B:203:0x03fa  */
    /* JADX WARNING: Removed duplicated region for block: B:250:? A:{SYNTHETIC, RETURN} */
    /* JADX WARNING: Removed duplicated region for block: B:205:0x03ff  */
    /* JADX WARNING: Removed duplicated region for block: B:184:0x0397  */
    /* JADX WARNING: Removed duplicated region for block: B:190:0x03ab  */
    /* JADX WARNING: Removed duplicated region for block: B:191:0x03ac  */
    /* JADX WARNING: Removed duplicated region for block: B:194:0x03b3  */
    /* JADX WARNING: Removed duplicated region for block: B:203:0x03fa  */
    /* JADX WARNING: Removed duplicated region for block: B:205:0x03ff  */
    /* JADX WARNING: Removed duplicated region for block: B:250:? A:{SYNTHETIC, RETURN} */
    /* JADX WARNING: Removed duplicated region for block: B:179:0x038e  */
    /* JADX WARNING: Removed duplicated region for block: B:184:0x0397  */
    /* JADX WARNING: Removed duplicated region for block: B:191:0x03ac  */
    /* JADX WARNING: Removed duplicated region for block: B:190:0x03ab  */
    /* JADX WARNING: Removed duplicated region for block: B:194:0x03b3  */
    /* JADX WARNING: Removed duplicated region for block: B:203:0x03fa  */
    /* JADX WARNING: Removed duplicated region for block: B:250:? A:{SYNTHETIC, RETURN} */
    /* JADX WARNING: Removed duplicated region for block: B:205:0x03ff  */
    /* JADX WARNING: Removed duplicated region for block: B:211:0x0419  */
    /* JADX WARNING: Removed duplicated region for block: B:170:0x0376  */
    /* JADX WARNING: Removed duplicated region for block: B:118:0x02aa  */
    /* JADX WARNING: Removed duplicated region for block: B:122:0x02b4  */
    /* JADX WARNING: Removed duplicated region for block: B:120:0x02ad  */
    /* JADX WARNING: Removed duplicated region for block: B:126:0x02c8  */
    /* JADX WARNING: Removed duplicated region for block: B:125:0x02c1  */
    /* JADX WARNING: Removed duplicated region for block: B:132:0x02d9  */
    /* JADX WARNING: Removed duplicated region for block: B:134:0x02e2  */
    /* JADX WARNING: Removed duplicated region for block: B:145:0x0315  */
    /* JADX WARNING: Removed duplicated region for block: B:147:0x031c  */
    /* JADX WARNING: Removed duplicated region for block: B:152:0x0335  */
    /* JADX WARNING: Removed duplicated region for block: B:161:0x0350  */
    /* JADX WARNING: Removed duplicated region for block: B:155:0x033f  */
    /* JADX WARNING: Removed duplicated region for block: B:170:0x0376  */
    /* JADX WARNING: Removed duplicated region for block: B:211:0x0419  */
    /* JADX WARNING: Removed duplicated region for block: B:118:0x02aa  */
    /* JADX WARNING: Removed duplicated region for block: B:120:0x02ad  */
    /* JADX WARNING: Removed duplicated region for block: B:122:0x02b4  */
    /* JADX WARNING: Removed duplicated region for block: B:125:0x02c1  */
    /* JADX WARNING: Removed duplicated region for block: B:126:0x02c8  */
    /* JADX WARNING: Removed duplicated region for block: B:132:0x02d9  */
    /* JADX WARNING: Removed duplicated region for block: B:134:0x02e2  */
    /* JADX WARNING: Removed duplicated region for block: B:145:0x0315  */
    /* JADX WARNING: Removed duplicated region for block: B:147:0x031c  */
    /* JADX WARNING: Removed duplicated region for block: B:152:0x0335  */
    /* JADX WARNING: Removed duplicated region for block: B:155:0x033f  */
    /* JADX WARNING: Removed duplicated region for block: B:161:0x0350  */
    /* JADX WARNING: Removed duplicated region for block: B:211:0x0419  */
    /* JADX WARNING: Removed duplicated region for block: B:170:0x0376  */
    /* JADX WARNING: Removed duplicated region for block: B:77:0x01cd  */
    /* JADX WARNING: Removed duplicated region for block: B:76:0x01cc  */
    /* JADX WARNING: Removed duplicated region for block: B:89:0x0212  */
    /* JADX WARNING: Removed duplicated region for block: B:118:0x02aa  */
    /* JADX WARNING: Removed duplicated region for block: B:122:0x02b4  */
    /* JADX WARNING: Removed duplicated region for block: B:120:0x02ad  */
    /* JADX WARNING: Removed duplicated region for block: B:126:0x02c8  */
    /* JADX WARNING: Removed duplicated region for block: B:125:0x02c1  */
    /* JADX WARNING: Removed duplicated region for block: B:132:0x02d9  */
    /* JADX WARNING: Removed duplicated region for block: B:134:0x02e2  */
    /* JADX WARNING: Removed duplicated region for block: B:145:0x0315  */
    /* JADX WARNING: Removed duplicated region for block: B:147:0x031c  */
    /* JADX WARNING: Removed duplicated region for block: B:152:0x0335  */
    /* JADX WARNING: Removed duplicated region for block: B:161:0x0350  */
    /* JADX WARNING: Removed duplicated region for block: B:155:0x033f  */
    /* JADX WARNING: Removed duplicated region for block: B:170:0x0376  */
    /* JADX WARNING: Removed duplicated region for block: B:211:0x0419  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final void s(ViewStructure viewStructure, ba0 ba0, AutofillId autofillId, String str, iw0 iw0) {
        long j;
        int i;
        boolean z;
        i5 i5Var;
        long j2;
        boolean z2;
        jl jlVar;
        Boolean bool;
        boolean z3;
        long j3;
        long j4;
        Number number;
        oc1 oc1;
        x8 x8Var;
        a6 a6Var;
        iy0 iy0;
        d21 x;
        boolean z4;
        Collection collection;
        int i2;
        int i3;
        Integer valueOf;
        Number valueOf2;
        boolean z5;
        String[] u;
        ViewStructure viewStructure2 = viewStructure;
        ba0 ba02 = ba0;
        q21 q21 = n21.a;
        q21 = c21.a;
        d21 x2 = ba02.x();
        int i4 = 8;
        if (x2 != null) {
            hk0 hk0 = x2.e;
            if (hk0 != null) {
                oc1 oc12;
                x8 x8Var2;
                a6 a6Var2;
                iy0 iy02;
                int i5;
                Object obj;
                Object[] objArr = hk0.b;
                j = 128;
                Object[] objArr2 = hk0.c;
                long[] jArr = hk0.a;
                int length = jArr.length - 2;
                i = 2;
                if (length >= 0) {
                    z = true;
                    int i6 = 0;
                    i5Var = null;
                    j2 = 255;
                    z2 = false;
                    oc12 = null;
                    x8Var2 = null;
                    a6Var2 = null;
                    jlVar = null;
                    bool = null;
                    iy02 = null;
                    z3 = false;
                    Integer num = null;
                    j3 = 7;
                    while (true) {
                        long j5 = jArr[i6];
                        j4 = -9187201950435737472L;
                        if (((((~j5) << 7) & j5) & -9187201950435737472L) != -9187201950435737472L) {
                            int i7 = 8 - ((~(i6 - length)) >>> 31);
                            for (i5 = 0; i5 < i7; i5++) {
                                if ((j5 & 255) < 128) {
                                    int i8 = (i6 << 3) + i5;
                                    Object obj2 = objArr[i8];
                                    obj = objArr2[i8];
                                    q21 q212 = (q21) obj2;
                                    if (k70.p(q212, n21.s)) {
                                        obj.getClass();
                                        i5Var = (i5) obj;
                                    } else if (k70.p(q212, n21.a)) {
                                        obj.getClass();
                                        String str2 = (String) tg.R((List) obj);
                                        if (str2 != null) {
                                            viewStructure2.setContentDescription(str2);
                                        }
                                    } else if (k70.p(q212, n21.r)) {
                                        obj.getClass();
                                        jlVar = (jl) obj;
                                    } else if (k70.p(q212, n21.t)) {
                                        obj.getClass();
                                        a6Var2 = (a6) obj;
                                    } else if (k70.p(q212, n21.F)) {
                                        obj.getClass();
                                        x8Var2 = (x8) obj;
                                    } else if (k70.p(q212, n21.l)) {
                                        obj.getClass();
                                        viewStructure2.setFocused(((Boolean) obj).booleanValue());
                                    } else if (k70.p(q212, n21.N)) {
                                        obj.getClass();
                                        number = (Integer) obj;
                                    } else if (k70.p(q212, n21.J)) {
                                        z3 = true;
                                    } else if (k70.p(q212, n21.o)) {
                                        obj.getClass();
                                        z = ((Boolean) obj).booleanValue();
                                    } else if (k70.p(q212, n21.y)) {
                                        obj.getClass();
                                        iy02 = (iy0) obj;
                                    } else if (k70.p(q212, n21.H)) {
                                        obj.getClass();
                                        bool = (Boolean) obj;
                                    } else if (k70.p(q212, n21.I)) {
                                        obj.getClass();
                                        oc12 = (oc1) obj;
                                    } else if (k70.p(q212, c21.b)) {
                                        viewStructure2.setClickable(true);
                                    } else if (k70.p(q212, c21.c)) {
                                        viewStructure2.setLongClickable(true);
                                    } else if (k70.p(q212, c21.v)) {
                                        viewStructure2.setFocusable(true);
                                    } else if (k70.p(q212, c21.k)) {
                                        z2 = true;
                                    }
                                }
                                j5 >>= 8;
                            }
                            if (i7 != 8) {
                                break;
                            }
                        }
                        if (i6 == length) {
                            break;
                        }
                        i6++;
                    }
                } else {
                    j2 = 255;
                    j3 = 7;
                    j4 = -9187201950435737472L;
                    z = true;
                    i5Var = null;
                    z2 = false;
                    oc12 = null;
                    x8Var2 = null;
                    a6Var2 = null;
                    jlVar = null;
                    bool = null;
                    iy02 = null;
                    z3 = false;
                    number = null;
                }
                oc1 = oc12;
                x8Var = x8Var2;
                a6Var = a6Var2;
                iy0 = iy02;
                x = ba02.x();
                if (x != null && x.g) {
                    if (x.h) {
                        x = x.b();
                        ak0 h90 = new h90(((nk0) ba02.n()).e.g);
                        h90.c(ba02.n());
                        while (h90.i()) {
                            ba0 ba03 = (ba0) h90.k(h90.b - 1);
                            d21 x3 = ba03.x();
                            if (x3 != null) {
                                if (!x3.g) {
                                    x.e(x3);
                                    if (!x3.h) {
                                        h90.c(ba03.n());
                                    }
                                }
                            }
                        }
                    }
                }
                if (x != null) {
                    hk0 hk02 = x.e;
                    if (hk02 != null) {
                        Object[] objArr3 = hk02.b;
                        Object[] objArr4 = hk02.c;
                        long[] jArr2 = hk02.a;
                        i5 = jArr2.length - 2;
                        z4 = true;
                        if (i5 >= 0) {
                            int i9 = 0;
                            collection = null;
                            while (true) {
                                long[] jArr3;
                                Object[] objArr5;
                                long j6 = jArr2[i9];
                                int i10 = i4;
                                int i11 = i9;
                                if (((((~j6) << j3) & j6) & j4) != j4) {
                                    i4 = 8 - ((~(i11 - i5)) >>> 31);
                                    i9 = 0;
                                    while (i9 < i4) {
                                        if ((j6 & j2) < j) {
                                            int i12 = (i11 << 3) + i9;
                                            obj = objArr3[i12];
                                            Object obj3 = objArr4[i12];
                                            jArr3 = jArr2;
                                            q21 q213 = (q21) obj;
                                            objArr5 = objArr3;
                                            if (k70.p(q213, n21.j)) {
                                                viewStructure2.setEnabled(false);
                                            } else if (k70.p(q213, n21.B)) {
                                                obj3.getClass();
                                                collection = (List) obj3;
                                            }
                                        } else {
                                            jArr3 = jArr2;
                                            objArr5 = objArr3;
                                        }
                                        j6 >>= i10;
                                        i9++;
                                        objArr3 = objArr5;
                                        jArr2 = jArr3;
                                    }
                                    jArr3 = jArr2;
                                    objArr5 = objArr3;
                                    i2 = i10;
                                    if (i4 != i2) {
                                        break;
                                    }
                                }
                                jArr3 = jArr2;
                                objArr5 = objArr3;
                                i2 = i10;
                                i3 = i11;
                                if (i3 == i5) {
                                    break;
                                }
                                i9 = i3 + 1;
                                i4 = i2;
                                objArr3 = objArr5;
                                jArr2 = jArr3;
                            }
                            valueOf = Integer.valueOf(ba02.f);
                            if (ba02.v() == null) {
                                valueOf = null;
                            }
                            i2 = valueOf == null ? valueOf.intValue() : -1;
                            viewStructure2.setAutofillId(autofillId, i2);
                            viewStructure2.setId(i2, str, null, null);
                            valueOf2 = i5Var == null ? Integer.valueOf(i5Var.a) : z2 ? Integer.valueOf(z4) : oc1 != null ? Integer.valueOf(i) : null;
                            if (valueOf2 != null) {
                                viewStructure2.setAutofillType(valueOf2.intValue());
                            }
                            if (x8Var != null) {
                                String str3 = x8Var.f;
                                if (str3.length() >= 5000) {
                                    str3 = (Character.isHighSurrogate(str3.charAt(4999)) && Character.isLowSurrogate(str3.charAt(5000))) ? q81.J(str3, 4999) : q81.J(str3, 5000);
                                }
                                viewStructure2.setAutofillValue(AutofillValue.forText(str3));
                            }
                            if (a6Var != null) {
                                viewStructure2.setAutofillValue(a6Var.a);
                            }
                            if (jlVar != null) {
                                String[] u2 = a5.u(jlVar);
                                if (u2 != null) {
                                    viewStructure2.setAutofillHints(u2);
                                }
                            }
                            iw0.a.h(ba02.f, new ot0(viewStructure2));
                            if (bool != null) {
                                viewStructure2.setSelected(bool.booleanValue());
                            }
                            i3 = 4;
                            if (oc1 == null) {
                                viewStructure2.setCheckable(z4);
                                viewStructure2.setChecked(oc1 == oc1.e);
                            } else if (bool != null) {
                                if (iy0 == null || iy0.a != 4) {
                                    z5 = true;
                                    viewStructure2.setCheckable(true);
                                    viewStructure2.setChecked(bool.booleanValue());
                                    jl.a.getClass();
                                    u = a5.u(il.b);
                                    u.getClass();
                                    if (u.length != 0) {
                                        boolean z6;
                                        int i13;
                                        boolean z7;
                                        String u3;
                                        Object obj4 = u[0];
                                        if (jlVar != null) {
                                            String[] u4 = a5.u(jlVar);
                                            if (u4 != null && ba.f0(u4, obj4) >= 0) {
                                                z6 = z5;
                                                if (!z3) {
                                                    if (!z6) {
                                                        i13 = 0;
                                                        if (i13 == 0) {
                                                            if (!z) {
                                                                z7 = false;
                                                                viewStructure2.setDataIsSensitive(z7);
                                                                if (ba02.J.d.G0()) {
                                                                    i3 = 0;
                                                                }
                                                                viewStructure2.setVisibility(i3);
                                                                if (collection != null) {
                                                                    int size = collection.size();
                                                                    String str4 = "";
                                                                    for (int i14 = 0; i14 < size; i14++) {
                                                                        x8 x8Var3 = (x8) collection.get(i14);
                                                                        StringBuilder stringBuilder = new StringBuilder();
                                                                        stringBuilder.append(str4);
                                                                        stringBuilder.append(x8Var3.f);
                                                                        stringBuilder.append(10);
                                                                        str4 = stringBuilder.toString();
                                                                    }
                                                                    viewStructure2.setText(str4);
                                                                    viewStructure2.setClassName("android.widget.TextView");
                                                                }
                                                                if (((nk0) ba02.n()).isEmpty() && iy0 != null) {
                                                                    u3 = nb0.u(iy0.a);
                                                                    if (u3 != null) {
                                                                        viewStructure2.setClassName(u3);
                                                                    }
                                                                }
                                                                if (!z2) {
                                                                    viewStructure2.setClassName("android.widget.EditText");
                                                                    if (VERSION.SDK_INT >= 28 && number != null) {
                                                                        viewStructure2.setMaxTextLength(number.intValue());
                                                                    }
                                                                    if (i13 != 0) {
                                                                        viewStructure2.setInputType(129);
                                                                        return;
                                                                    }
                                                                    return;
                                                                }
                                                                return;
                                                            }
                                                        }
                                                        z7 = z5;
                                                        viewStructure2.setDataIsSensitive(z7);
                                                        if (ba02.J.d.G0()) {
                                                        }
                                                        viewStructure2.setVisibility(i3);
                                                        if (collection != null) {
                                                        }
                                                        u3 = nb0.u(iy0.a);
                                                        if (u3 != null) {
                                                        }
                                                        if (!z2) {
                                                        }
                                                    }
                                                }
                                                i13 = z5;
                                                if (i13 == 0) {
                                                }
                                                z7 = z5;
                                                viewStructure2.setDataIsSensitive(z7);
                                                if (ba02.J.d.G0()) {
                                                }
                                                viewStructure2.setVisibility(i3);
                                                if (collection != null) {
                                                }
                                                u3 = nb0.u(iy0.a);
                                                if (u3 != null) {
                                                }
                                                if (!z2) {
                                                }
                                            }
                                        }
                                        z6 = false;
                                        if (z3) {
                                        }
                                        i13 = z5;
                                        if (i13 == 0) {
                                        }
                                        z7 = z5;
                                        viewStructure2.setDataIsSensitive(z7);
                                        if (ba02.J.d.G0()) {
                                        }
                                        viewStructure2.setVisibility(i3);
                                        if (collection != null) {
                                        }
                                        u3 = nb0.u(iy0.a);
                                        if (u3 != null) {
                                        }
                                        if (!z2) {
                                        }
                                    } else {
                                        throw new dl1("Array is empty.");
                                    }
                                }
                            }
                            z5 = true;
                            jl.a.getClass();
                            u = a5.u(il.b);
                            u.getClass();
                            if (u.length != 0) {
                            }
                        }
                        collection = null;
                        valueOf = Integer.valueOf(ba02.f);
                        if (ba02.v() == null) {
                        }
                        if (valueOf == null) {
                        }
                        viewStructure2.setAutofillId(autofillId, i2);
                        viewStructure2.setId(i2, str, null, null);
                        if (i5Var == null) {
                        }
                        if (valueOf2 != null) {
                        }
                        if (x8Var != null) {
                        }
                        if (a6Var != null) {
                        }
                        if (jlVar != null) {
                        }
                        iw0.a.h(ba02.f, new ot0(viewStructure2));
                        if (bool != null) {
                        }
                        i3 = 4;
                        if (oc1 == null) {
                        }
                        z5 = true;
                        jl.a.getClass();
                        u = a5.u(il.b);
                        u.getClass();
                        if (u.length != 0) {
                        }
                    }
                }
                z4 = true;
                collection = null;
                valueOf = Integer.valueOf(ba02.f);
                if (ba02.v() == null) {
                }
                if (valueOf == null) {
                }
                viewStructure2.setAutofillId(autofillId, i2);
                viewStructure2.setId(i2, str, null, null);
                if (i5Var == null) {
                }
                if (valueOf2 != null) {
                }
                if (x8Var != null) {
                }
                if (a6Var != null) {
                }
                if (jlVar != null) {
                }
                iw0.a.h(ba02.f, new ot0(viewStructure2));
                if (bool != null) {
                }
                i3 = 4;
                if (oc1 == null) {
                }
                z5 = true;
                jl.a.getClass();
                u = a5.u(il.b);
                u.getClass();
                if (u.length != 0) {
                }
            }
        }
        i = 2;
        j = 128;
        j2 = 255;
        j3 = 7;
        j4 = -9187201950435737472L;
        z = true;
        oc1 = null;
        x8Var = null;
        a6Var = null;
        iy0 = null;
        i5Var = null;
        z2 = false;
        jlVar = null;
        bool = null;
        z3 = false;
        number = null;
        x = ba02.x();
        if (x.h) {
        }
        if (x != null) {
        }
        z4 = true;
        collection = null;
        valueOf = Integer.valueOf(ba02.f);
        if (ba02.v() == null) {
        }
        if (valueOf == null) {
        }
        viewStructure2.setAutofillId(autofillId, i2);
        viewStructure2.setId(i2, str, null, null);
        if (i5Var == null) {
        }
        if (valueOf2 != null) {
        }
        if (x8Var != null) {
        }
        if (a6Var != null) {
        }
        if (jlVar != null) {
        }
        iw0.a.h(ba02.f, new ot0(viewStructure2));
        if (bool != null) {
        }
        i3 = 4;
        if (oc1 == null) {
        }
        z5 = true;
        jl.a.getClass();
        u = a5.u(il.b);
        u.getClass();
        if (u.length != 0) {
        }
    }

    public static final void p(float[] fArr, gk0 gk0) {
        float[] fArr2 = fArr;
        gk0 gk02 = gk0;
        if (fArr2.length >= 16) {
            float f = fArr2[0];
            float f2 = fArr2[1];
            float f3 = fArr2[3];
            float f4 = fArr2[4];
            float f5 = fArr2[5];
            float f6 = fArr2[7];
            float f7 = fArr2[12];
            float f8 = fArr2[13];
            float f9 = fArr2[15];
            float f10 = gk02.a;
            float f11 = gk02.b;
            float f12 = gk02.c;
            float f13 = gk02.d;
            float f14 = f3 * f10;
            float f15 = f6 * f11;
            float f16 = 1.0f / ((f14 + f15) + f9);
            float f17 = f9;
            float f18 = 0.0f;
            float f19 = f;
            if ((Float.floatToRawIntBits(f16) & Integer.MAX_VALUE) >= 2139095040) {
                f16 = 0.0f;
            }
            f9 = f19 * f10;
            float f20 = f4 * f11;
            f = ((f9 + f20) + f7) * f16;
            f10 *= f2;
            f11 *= f5;
            float f21 = f9;
            f9 = ((f10 + f11) + f8) * f16;
            f6 *= f13;
            f14 = 1.0f / ((f14 + f6) + f17);
            float f22 = f2;
            f16 = f3;
            if ((Float.floatToRawIntBits(f14) & Integer.MAX_VALUE) >= 2139095040) {
                f14 = 0.0f;
            }
            f4 *= f13;
            f2 = ((f21 + f4) + f7) * f14;
            f5 *= f13;
            f10 = ((f10 + f5) + f8) * f14;
            f3 = f16 * f12;
            f13 = 1.0f / ((f15 + f3) + f17);
            if ((Float.floatToRawIntBits(f13) & Integer.MAX_VALUE) >= 2139095040) {
                f13 = 0.0f;
            }
            f14 = f19 * f12;
            f15 = ((f14 + f20) + f7) * f13;
            f12 *= f22;
            f11 = ((f11 + f12) + f8) * f13;
            float f23 = 1.0f / ((f3 + f6) + f17);
            if ((Float.floatToRawIntBits(f23) & Integer.MAX_VALUE) < 2139095040) {
                f18 = f23;
            }
            f14 = ((f14 + f4) + f7) * f18;
            f12 = ((f12 + f5) + f8) * f18;
            gk02.a = Math.min(f, Math.min(f2, Math.min(f15, f14)));
            gk02.b = Math.min(f9, Math.min(f10, Math.min(f11, f12)));
            gk02.c = Math.max(f, Math.max(f2, Math.max(f15, f14)));
            gk02.d = Math.max(f9, Math.max(f10, Math.max(f11, f12)));
        }
    }

    public static final int h(int i, List list) {
        int i2;
        int i3 = ((bq0) tg.W(list)).c;
        if (i > ((bq0) tg.W(list)).c) {
            StringBuilder dl1 = new dl1("Index ");
            dl1.append(i);
            dl1.append(" should be less or equal than last line's end ");
            dl1.append(i3);
            FileProvider.a(dl1.toString());
        }
        i3 = list.size() - 1;
        int i4 = 0;
        while (i4 <= i3) {
            i2 = (i4 + i3) >>> 1;
            bq0 bq0 = (bq0) list.get(i2);
            int i5 = bq0.b > i ? 1 : bq0.c <= i ? -1 : 0;
            if (i5 >= 0) {
                if (i5 <= 0) {
                    break;
                }
                i3 = i2 - 1;
            } else {
                i4 = i2 + 1;
            }
        }
        i2 = -(i4 + 1);
        if (i2 >= 0 && i2 < list.size()) {
            return i2;
        }
        StringBuilder H = fu0.H(i2, "Found paragraph index ", " should be in range [0, ");
        H.append(list.size());
        H.append(").\nDebug info: index=");
        H.append(i);
        H.append(", paragraphs=[");
        H.append(ue0.a(list, null, new h90(16), 31));
        H.append(']');
        FileProvider.a(H.toString());
        return i2;
    }

    public static final long o(float[] fArr, long j) {
        if (fArr.length < 16) {
            return j;
        }
        float f = fArr[0];
        float f2 = fArr[1];
        float f3 = fArr[3];
        float f4 = fArr[4];
        float f5 = fArr[5];
        float f6 = fArr[7];
        float f7 = fArr[12];
        float f8 = fArr[13];
        float f9 = fArr[15];
        float intBitsToFloat = Float.intBitsToFloat((int) (j >> 32));
        float intBitsToFloat2 = Float.intBitsToFloat((int) (j & 4294967295L));
        f9 = 1.0f / (((f6 * intBitsToFloat2) + (f3 * intBitsToFloat)) + f9);
        if ((Float.floatToRawIntBits(f9) & Integer.MAX_VALUE) >= 2139095040) {
            f9 = 0.0f;
        }
        f5 = (((f5 * intBitsToFloat2) + (f2 * intBitsToFloat)) + f8) * f9;
        return (((long) Float.floatToRawIntBits((((f4 * intBitsToFloat2) + (f * intBitsToFloat)) + f7) * f9)) << 32) | (((long) Float.floatToRawIntBits(f5)) & 4294967295L);
    }

    public static final boolean m(float f, float f2, r6 r6Var) {
        float f3 = f - 0.005f;
        float f4 = f2 - 0.005f;
        f += 0.005f;
        f2 += 0.005f;
        r6 a = t6.a();
        if (Float.isNaN(f3) || Float.isNaN(f4) || Float.isNaN(f) || Float.isNaN(f2)) {
            a5.b("Invalid rectangle, make sure no value is NaN");
        }
        if (a.b == null) {
            a.b = new RectF();
        }
        RectF rectF = a.b;
        rectF.getClass();
        rectF.set(f3, f4, f, f2);
        Path path = a.a;
        RectF rectF2 = a.b;
        rectF2.getClass();
        path.addRect(rectF2, Direction.CCW);
        r6 a2 = t6.a();
        a2.b(r6Var, a, 1);
        boolean isEmpty = a2.a.isEmpty();
        a2.c();
        a.c();
        return isEmpty ^ 1;
    }

    public static void y(float[] fArr, float f, float f2) {
        if (fArr.length >= 16) {
            float f3 = ((fArr[9] * 0.0f) + ((fArr[5] * f2) + (fArr[1] * f))) + fArr[13];
            float f4 = ((fArr[10] * 0.0f) + ((fArr[6] * f2) + (fArr[2] * f))) + fArr[14];
            f2 = ((fArr[11] * 0.0f) + ((fArr[7] * f2) + (fArr[3] * f))) + fArr[15];
            fArr[12] = ((fArr[8] * 0.0f) + ((fArr[4] * f2) + (fArr[0] * f))) + fArr[12];
            fArr[13] = f3;
            fArr[14] = f4;
            fArr[15] = f2;
        }
    }

    public static final void t(float[] fArr) {
        if (fArr.length >= 16) {
            fArr[0] = 1.0f;
            fArr[1] = 0.0f;
            fArr[2] = 0.0f;
            fArr[3] = 0.0f;
            fArr[4] = 0.0f;
            fArr[5] = 1.0f;
            fArr[6] = 0.0f;
            fArr[7] = 0.0f;
            fArr[8] = 0.0f;
            fArr[9] = 0.0f;
            fArr[10] = 1.0f;
            fArr[11] = 0.0f;
            fArr[12] = 0.0f;
            fArr[13] = 0.0f;
            fArr[14] = 0.0f;
            fArr[15] = 1.0f;
        }
    }

    public static final void d(fh1 fh1, al alVar, ud0 ud0) {
        alVar.getClass();
        ud0.getClass();
        rz0 rz0 = (rz0) fh1.c("androidx.lifecycle.savedstate.vm.tag");
        if (!(rz0 == null || rz0.g)) {
            rz0.f(alVar, ud0);
            jd0 jd0 = ud0.d;
            if (jd0 != jd0.f) {
                if (jd0.compareTo(jd0.h) < 0) {
                    ud0.a(new to(alVar, ud0));
                    return;
                }
            }
            alVar.t();
        }
    }

    public static final long b(int i, int i2) {
        if (i < 0 || i2 < 0) {
            StringBuilder dl1 = new dl1("start and end cannot be negative. [start: ");
            dl1.append(i);
            dl1.append(", end: ");
            dl1.append(i2);
            dl1.append(']');
            FileProvider.a(dl1.toString());
        }
        long j = (((long) i2) & 4294967295L) | (((long) i) << 32);
        int i3 = hb1.c;
        return j;
    }

    public static void c(StringBuilder stringBuilder, Object obj, i00 i00) {
        if (i00 != null) {
            stringBuilder.append((CharSequence) i00.i(obj));
            return;
        }
        if (obj == null ? true : obj instanceof CharSequence) {
            stringBuilder.append((CharSequence) obj);
        } else if (obj instanceof Character) {
            stringBuilder.append(((Character) obj).charValue());
        } else {
            stringBuilder.append(obj.toString());
        }
    }

    public static final int i(int i, List list) {
        int size = list.size() - 1;
        int i2 = 0;
        while (i2 <= size) {
            int i3 = (i2 + size) >>> 1;
            bq0 bq0 = (bq0) list.get(i3);
            int i4 = bq0.d > i ? 1 : bq0.e <= i ? -1 : 0;
            if (i4 < 0) {
                i2 = i3 + 1;
            } else if (i4 <= 0) {
                return i3;
            } else {
                size = i3 - 1;
            }
        }
        return -(i2 + 1);
    }

    public static final boolean n(float f, float f2, float f3, float f4, long j) {
        f -= f3;
        f2 -= f4;
        f3 = Float.intBitsToFloat((int) (j >> 32));
        f4 = Float.intBitsToFloat((int) (j & 4294967295L));
        return ((f2 * f2) / (f4 * f4)) + ((f * f) / (f3 * f3)) <= 1.0f;
    }

    public static final nh0 q(qy0 qy0, int i, int i2, int i3, int i4, int i5, oh0 oh0, List list, ks0[] ks0Arr, int i6, int i7, int[] iArr, int i8) {
        float l;
        long j;
        int i9;
        int i10;
        int h;
        int signum;
        qy0 qy02 = qy0;
        int i11 = i3;
        int i12 = i4;
        int i13 = i5;
        a91 a91 = list;
        int i14 = i7;
        long j2 = (long) i13;
        int i15 = i14 - i6;
        int[] iArr2 = new int[i15];
        int i16 = i6;
        int i17 = 0;
        int i18 = 0;
        int i19 = 0;
        int i20 = 0;
        float f = 0.0f;
        while (i16 < i14) {
            int i21;
            hh0 hh0 = (hh0) a91.get(i16);
            l = wc0.l(wc0.k(hh0));
            if (l > 0.0f) {
                f += l;
                i18++;
                j = j2;
                i21 = i16;
            } else {
                i20 = i11 - i19;
                ks0 ks0 = ks0Arr[i16];
                j = j2;
                if (ks0 == null) {
                    if (i11 == Integer.MAX_VALUE) {
                        i21 = i16;
                        i9 = i18;
                        i10 = Integer.MAX_VALUE;
                    } else {
                        i21 = i16;
                        i9 = i18;
                        i10 = i20 < 0 ? 0 : i20;
                    }
                    ks0 = hh0.e(qy02.d(0, i10, i12, false));
                } else {
                    i21 = i16;
                    i9 = i18;
                }
                ks0 ks02 = ks0;
                h = qy02.h(ks02);
                int e = qy02.e(ks02);
                iArr2[i21 - i6] = h;
                i16 = i20 - h;
                if (i16 < 0) {
                    i16 = 0;
                }
                i20 = Math.min(i13, i16);
                i19 += h + i20;
                i17 = Math.max(i17, e);
                ks0Arr[i21] = ks02;
                i18 = i9;
            }
            i16 = i21 + 1;
            j2 = j;
        }
        j = j2;
        i9 = i18;
        if (i9 == 0) {
            i19 -= i20;
            h = 0;
        } else {
            long j3 = ((long) (i9 - 1)) * j;
            j2 = ((long) ((i11 != Integer.MAX_VALUE ? i11 : i) - i19)) - j3;
            if (j2 < 0) {
                j2 = 0;
            }
            float f2 = ((float) j2) / f;
            for (i18 = i6; i18 < i14; i18++) {
                j2 -= (long) Math.round(wc0.l(wc0.k((hh0) a91.get(i18))) * f2);
            }
            j = j2;
            i20 = i6;
            i18 = i17;
            i17 = 0;
            while (i20 < i14) {
                if (ks0Arr[i20] == null) {
                    hh0 hh02 = (hh0) a91.get(i20);
                    f = f2;
                    ry0 k = wc0.k(hh02);
                    l = wc0.l(k);
                    if (l <= 0.0f) {
                        a5.b("All weights <= 0 should have placeables");
                    }
                    signum = Long.signum(j2);
                    j = j2 - ((long) signum);
                    h = Math.max(0, Math.round(l * f) + signum);
                    i13 = (!(k != null ? k.b : true) || h == Integer.MAX_VALUE) ? 0 : h;
                    ks0 e2 = hh02.e(qy02.d(i13, h, i12, true));
                    i13 = qy02.h(e2);
                    i10 = qy02.e(e2);
                    iArr2[i20 - i6] = i13;
                    i17 += i13;
                    i13 = Math.max(i18, i10);
                    ks0Arr[i20] = e2;
                    i18 = i13;
                    j2 = j;
                } else {
                    f = f2;
                    j = j2;
                }
                i20++;
                i11 = i3;
                List a912 = list;
                f2 = f;
            }
            h = (int) (((long) i17) + j3);
            i11 = i3 - i19;
            if (h < 0) {
                h = 0;
            }
            if (h > i11) {
                h = i11;
            }
            i17 = i18;
        }
        h += i19;
        if (h < 0) {
            h = 0;
        }
        signum = Math.max(h, i);
        i10 = Math.max(i17, Math.max(i2, 0));
        int[] iArr3 = new int[i15];
        oh0 oh02 = oh0;
        qy02.b(signum, oh02, iArr2, iArr3);
        return qy02.j(ks0Arr, oh02, iArr3, signum, i10, iArr, i8, i6, i14);
    }

    public static void u(Window window, boolean z) {
        int i = VERSION.SDK_INT;
        if (i >= 35) {
            g1.e(window, z);
        } else if (i >= 30) {
            g1.d(window, z);
        } else {
            View decorView = window.getDecorView();
            i = decorView.getSystemUiVisibility();
            decorView.setSystemUiVisibility(z ? i & -1793 : i | 1792);
        }
    }

    public static final kh1 j(View view) {
        view.getClass();
        ViewParent parent = view.getParent();
        if (parent != null) {
            return parent;
        }
        Object tag = view.getTag(2131034228);
        return tag instanceof ViewParent ? (ViewParent) tag : null;
    }

    public static m6 a(String str, ob1 ob1, long j, mp mpVar, yy yyVar, int i) {
        String str2 = str;
        ut utVar = ut.e;
        return new m6(new q6(str2, ob1, utVar, utVar, yyVar, mpVar), i, 1, j);
    }

    public static final void w(zo0 zo0, int i, Object obj, int i2, Object obj2) {
        int i3 = zo0.g - zo0.b[zo0.c - 1].b;
        Object[] objArr = zo0.f;
        objArr[i + i3] = obj;
        objArr[i3 + i2] = obj2;
    }

    public static final void v(zo0 zo0, int i, Object obj) {
        zo0.f[(zo0.g - zo0.b[zo0.c - 1].b) + i] = obj;
    }

    public static final a21 k(Object obj) {
        if (obj != j70.b) {
            return (a21) obj;
        }
        od.p("Does not contain segment");
        return null;
    }

    public static final Rect x(r60 r60) {
        return new Rect(r60.a, r60.b, r60.c, r60.d);
    }

    public static float[] e() {
        return new float[]{1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f};
    }

    public static final boolean l(Object obj) {
        return obj == j70.b;
    }

    public abstract String f(byte[] bArr, int i, int i2);

    public abstract int g(String str, byte[] bArr, int i, int i2);
}