package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: c8 */
public final class c8 {
    public final ud1 a;
    public final Object b;
    public final p8 c;
    public final lq0 d;
    public final lq0 e;
    public final al0 f;
    public final u8 g;
    public final u8 h;
    public final u8 i;
    public final u8 j;

    public c8(Object obj, ud1 ud1, Float f, int i) {
        Object f2;
        if ((i & 4) != 0) {
            f2 = null;
        }
        this.a = ud1;
        p8 p8Var = new p8(ud1, obj, null, 60);
        this.c = p8Var;
        this.d = mc0.t(Boolean.FALSE);
        this.e = mc0.t(obj);
        this.f = new al0();
        p71 p71 = new p71(1.0f, 1500.0f, f2);
        u8 u8Var = p8Var.g;
        boolean z = u8Var instanceof q8;
        u8 u8Var2 = z ? k70.e : u8Var instanceof r8 ? k70.f : u8Var instanceof s8 ? k70.g : k70.h;
        this.g = u8Var2;
        u8Var = z ? k70.a : u8Var instanceof r8 ? k70.b : u8Var instanceof s8 ? k70.c : k70.d;
        this.h = u8Var;
        this.i = u8Var2;
        this.j = u8Var;
    }

    public static final Object a(c8 c8Var, Object obj) {
        ud1 ud1 = c8Var.a;
        u8 u8Var = c8Var.j;
        u8 u8Var2 = c8Var.i;
        if (!k70.p(u8Var2, c8Var.g) || !k70.p(u8Var, c8Var.h)) {
            u8 u8Var3 = (u8) ud1.a.i(obj);
            int b = u8Var3.b();
            int i = 0;
            int i2 = 0;
            while (i < b) {
                if (u8Var3.a(i) < u8Var2.a(i) || u8Var3.a(i) > u8Var.a(i)) {
                    u8Var3.e(sb0.g(u8Var3.a(i), u8Var2.a(i), u8Var.a(i)), i);
                    i2 = 1;
                }
                i++;
            }
            if (i2 != 0) {
                return ud1.b.i(u8Var3);
            }
        }
        return obj;
    }

    public static Object c(c8 c8Var, Comparable comparable, o8 o8Var, nl nlVar) {
        Object i = c8Var.a.b.i(c8Var.c.g);
        Object d = c8Var.d();
        ud1 ud1 = c8Var.a;
        o8 o8Var2 = o8Var;
        return al0.a(c8Var.f, new a8(c8Var, i, new ja1(o8Var2, ud1, d, comparable, (u8) ud1.a.i(i)), c8Var.c.h, null), nlVar);
    }

    public final Object e(br brVar, nl nlVar) {
        cm a = al0.a(this.f, new b8(this, brVar, null), nlVar);
        return a == cm.e ? a : we1.a;
    }

    public static final void b(c8 c8Var) {
        p8 p8Var = c8Var.c;
        p8Var.g.d();
        p8Var.h = Long.MIN_VALUE;
        c8Var.d.setValue(Boolean.FALSE);
    }

    public final Object d() {
        return this.c.f.getValue();
    }
}