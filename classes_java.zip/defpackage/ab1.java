package defpackage;

import android.graphics.Paint.FontMetricsInt;
import android.graphics.Rect;
import android.os.Build.VERSION;
import android.os.Trace;
import android.text.BoringLayout.Metrics;
import android.text.Layout;
import android.text.Layout.Alignment;
import android.text.Spanned;
import android.text.TextDirectionHeuristic;
import android.text.TextPaint;
import android.text.TextUtils.TruncateAt;
import androidx.core.content.FileProvider;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ab1 */
public final class ab1 {
    public final TextPaint a;
    public final TruncateAt b;
    public final boolean c;
    public final boolean d;
    public final Layout e;
    public final int f;
    public final int g;
    public final int h;
    public final float i;
    public final float j;
    public final boolean k;
    public final FontMetricsInt l;
    public final int m;
    public final ie0[] n;
    public final Rect o;
    public pa p;

    /* JADX WARNING: Removed duplicated region for block: B:104:0x01c1  */
    /* JADX WARNING: Removed duplicated region for block: B:103:0x01b8  */
    /* JADX WARNING: Removed duplicated region for block: B:103:0x01b8  */
    /* JADX WARNING: Removed duplicated region for block: B:104:0x01c1  */
    /* JADX WARNING: Removed duplicated region for block: B:163:0x032e  */
    /* JADX WARNING: Removed duplicated region for block: B:162:0x031f  */
    /* JADX WARNING: Removed duplicated region for block: B:120:0x0213  */
    /* JADX WARNING: Removed duplicated region for block: B:90:0x018f  */
    /* JADX WARNING: Removed duplicated region for block: B:123:0x0221  */
    /* JADX WARNING: Removed duplicated region for block: B:122:0x021f  */
    /* JADX WARNING: Removed duplicated region for block: B:126:0x0228  */
    /* JADX WARNING: Removed duplicated region for block: B:125:0x0226  */
    /* JADX WARNING: Removed duplicated region for block: B:142:0x0260  */
    /* JADX WARNING: Removed duplicated region for block: B:129:0x0231  */
    /* JADX WARNING: Removed duplicated region for block: B:149:0x0294  */
    /* JADX WARNING: Removed duplicated region for block: B:148:0x0292  */
    /* JADX WARNING: Removed duplicated region for block: B:74:0x0165  */
    /* JADX WARNING: Removed duplicated region for block: B:86:0x017b A:{SKIP} */
    /* JADX WARNING: Removed duplicated region for block: B:90:0x018f  */
    /* JADX WARNING: Removed duplicated region for block: B:120:0x0213  */
    /* JADX WARNING: Removed duplicated region for block: B:122:0x021f  */
    /* JADX WARNING: Removed duplicated region for block: B:123:0x0221  */
    /* JADX WARNING: Removed duplicated region for block: B:125:0x0226  */
    /* JADX WARNING: Removed duplicated region for block: B:126:0x0228  */
    /* JADX WARNING: Removed duplicated region for block: B:129:0x0231  */
    /* JADX WARNING: Removed duplicated region for block: B:142:0x0260  */
    /* JADX WARNING: Removed duplicated region for block: B:148:0x0292  */
    /* JADX WARNING: Removed duplicated region for block: B:149:0x0294  */
    /* JADX WARNING: Removed duplicated region for block: B:74:0x0165  */
    /* JADX WARNING: Removed duplicated region for block: B:86:0x017b A:{SKIP} */
    /* JADX WARNING: Removed duplicated region for block: B:120:0x0213  */
    /* JADX WARNING: Removed duplicated region for block: B:90:0x018f  */
    /* JADX WARNING: Removed duplicated region for block: B:123:0x0221  */
    /* JADX WARNING: Removed duplicated region for block: B:122:0x021f  */
    /* JADX WARNING: Removed duplicated region for block: B:126:0x0228  */
    /* JADX WARNING: Removed duplicated region for block: B:125:0x0226  */
    /* JADX WARNING: Removed duplicated region for block: B:142:0x0260  */
    /* JADX WARNING: Removed duplicated region for block: B:129:0x0231  */
    /* JADX WARNING: Removed duplicated region for block: B:149:0x0294  */
    /* JADX WARNING: Removed duplicated region for block: B:148:0x0292  */
    /* JADX WARNING: Removed duplicated region for block: B:59:0x0149  */
    /* JADX WARNING: Removed duplicated region for block: B:74:0x0165  */
    /* JADX WARNING: Removed duplicated region for block: B:86:0x017b A:{SKIP} */
    /* JADX WARNING: Removed duplicated region for block: B:90:0x018f  */
    /* JADX WARNING: Removed duplicated region for block: B:120:0x0213  */
    /* JADX WARNING: Removed duplicated region for block: B:122:0x021f  */
    /* JADX WARNING: Removed duplicated region for block: B:123:0x0221  */
    /* JADX WARNING: Removed duplicated region for block: B:125:0x0226  */
    /* JADX WARNING: Removed duplicated region for block: B:126:0x0228  */
    /* JADX WARNING: Removed duplicated region for block: B:129:0x0231  */
    /* JADX WARNING: Removed duplicated region for block: B:142:0x0260  */
    /* JADX WARNING: Removed duplicated region for block: B:148:0x0292  */
    /* JADX WARNING: Removed duplicated region for block: B:149:0x0294  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public ab1(CharSequence charSequence, float f, TextPaint textPaint, int i, TruncateAt truncateAt, int i2, boolean z, int i3, int i4, int i5, int i6, int i7, int i8, r90 r90) {
        CharSequence charSequence2 = charSequence;
        Layout layout = f;
        int i9 = i;
        boolean z2 = z;
        ab1 obj = new Object();
        TextPaint textPaint2 = textPaint;
        obj.a = textPaint2;
        int i10 = truncateAt;
        obj.b = i10;
        obj.c = z2;
        obj.o = new Rect();
        int length = charSequence2.length();
        TextDirectionHeuristic b = db1.b(i2);
        Alignment alignment = oa1.a;
        Alignment alignment2 = i9 != 0 ? i9 != 1 ? i9 != 2 ? i9 != 3 ? i9 != 4 ? Alignment.ALIGN_NORMAL : oa1.b : oa1.a : Alignment.ALIGN_CENTER : Alignment.ALIGN_OPPOSITE : Alignment.ALIGN_NORMAL;
        TextDirectionHeuristic textDirectionHeuristic = (charSequence2 instanceof Spanned) && ((Spanned) charSequence2).nextSpanTransition(-1, length, gb.class) < length;
        Trace.beginSection("TextLayout:initLayout");
        try {
            boolean z3;
            ie0[] ie0Arr;
            int i11;
            int i12;
            int i13;
            long j;
            long j2;
            long j3;
            int i14;
            long a;
            long a2;
            TextPaint textPaint3;
            ie0[] ie0Arr2;
            int i15;
            Layout layout2;
            Metrics a3 = r90.a();
            double d = (double) layout;
            int ceil = (int) ((float) Math.ceil(d));
            Alignment alignment3;
            if (a3 == null || r90.c() > layout || textDirectionHeuristic == true) {
                alignment3 = alignment2;
                i9 = ceil;
                obj.k = false;
                i10 = i3;
                textDirectionHeuristic = b;
                layout = sb0.j(charSequence, textPaint, i9, charSequence.length(), textDirectionHeuristic, alignment3, i10, truncateAt, (int) ((float) Math.ceil(d)), i8, z, i4, i5, i6, i7);
            } else {
                obj.k = true;
                if (ceil < 0) {
                    FileProvider.a("negative width");
                }
                if (ceil < 0) {
                    FileProvider.a("negative ellipsized width");
                }
                if (VERSION.SDK_INT >= 33) {
                    layout = 
/*
Method generation error in method: ab1.<init>(java.lang.CharSequence, float, android.text.TextPaint, int, android.text.TextUtils$TruncateAt, int, boolean, int, int, int, int, int, int, r90):void, dex: 
jadx.core.utils.exceptions.CodegenException: Error generate insn: 0x0093: INVOKE  (r2_6 'layout' android.text.Layout) = (r1_0 'charSequence2' java.lang.CharSequence), (r4_0 'textPaint2' android.text.TextPaint), (r11_1 'ceil' int), (r3_7 'alignment2' android.text.Layout$Alignment), (r8_8 'a3' android.text.BoringLayout$Metrics), (r6_0 'z2' boolean), (r7_0 'i10' int), (r11_1 'ceil' int) e1.e(java.lang.CharSequence, android.text.TextPaint, int, android.text.Layout$Alignment, android.text.BoringLayout$Metrics, boolean, android.text.TextUtils$TruncateAt, int):android.text.BoringLayout type: STATIC in method: ab1.<init>(java.lang.CharSequence, float, android.text.TextPaint, int, android.text.TextUtils$TruncateAt, int, boolean, int, int, int, int, int, int, r90):void, dex: 
	at jadx.core.codegen.InsnGen.makeInsn(Unknown Source:86)
	at jadx.core.codegen.InsnGen.makeInsn(Unknown Source:1)
	at jadx.core.codegen.RegionGen.makeSimpleBlock(Unknown Source:46)
	at jadx.core.codegen.RegionGen.makeRegion(Unknown Source:6)
	at jadx.core.codegen.RegionGen.makeSimpleRegion(Unknown Source:24)
	at jadx.core.codegen.RegionGen.makeRegion(Unknown Source:20)
	at jadx.core.codegen.RegionGen.makeRegionIndent(Unknown Source:3)
	at jadx.core.codegen.RegionGen.makeIf(Unknown Source:43)
	at jadx.core.codegen.RegionGen.makeRegion(Unknown Source:34)
	at jadx.core.codegen.RegionGen.makeSimpleRegion(Unknown Source:24)
	at jadx.core.codegen.RegionGen.makeRegion(Unknown Source:20)
	at jadx.core.codegen.RegionGen.makeRegionIndent(Unknown Source:3)
	at jadx.core.codegen.RegionGen.makeIf(Unknown Source:80)
	at jadx.core.codegen.RegionGen.makeRegion(Unknown Source:34)
	at jadx.core.codegen.RegionGen.makeSimpleRegion(Unknown Source:24)
	at jadx.core.codegen.RegionGen.makeRegion(Unknown Source:20)
	at jadx.core.codegen.RegionGen.makeRegionIndent(Unknown Source:3)
	at jadx.core.codegen.RegionGen.makeTryCatch(Unknown Source:9)
	at jadx.core.codegen.RegionGen.makeRegion(Unknown Source:64)
	at jadx.core.codegen.RegionGen.makeSimpleRegion(Unknown Source:24)
	at jadx.core.codegen.RegionGen.makeRegion(Unknown Source:20)
	at jadx.core.codegen.MethodGen.addInstructions(Unknown Source:40)
	at jadx.core.codegen.ClassGen.addMethod(Unknown Source:103)
	at jadx.core.codegen.ClassGen.addMethods(Unknown Source:51)
	at jadx.core.codegen.ClassGen.addClassBody(Unknown Source:22)
	at jadx.core.codegen.ClassGen.addClassCode(Unknown Source:24)
	at jadx.core.codegen.ClassGen.makeClass(Unknown Source:5)
	at jadx.core.codegen.CodeGen.visit(Unknown Source:13)
	at jadx.core.ProcessClass.process(Unknown Source:71)
	at jadx.api.JadxDecompiler.processClass(Unknown Source:4)
	at jadx.api.JavaClass.decompile(Unknown Source:19)
Caused by: org.objenesis.ObjenesisException: java.lang.reflect.InvocationTargetException
	at android.s.ۥۡۡۢ.ۥ(Unknown Source:36)
	at android.s.ۥۡۡۢ.<init>(Unknown Source:11)
	at android.s.fk2.ۥ(Unknown Source:110)
	at android.s.c81.ۥ(Unknown Source:25)
	at android.s.c81.newInstance(Unknown Source:0)
	at com.rits.cloning.ObjenesisInstantiationStrategy.newInstance(Unknown Source:2)
	at com.rits.cloning.Cloner.newInstance(Unknown Source:2)
	at com.rits.cloning.Cloner.cloneObject(Unknown Source:0)
	at com.rits.cloning.Cloner.cloneInternal(Unknown Source:132)
	at com.rits.cloning.Cloner.deepClone(Unknown Source:27)
	at jadx.core.dex.nodes.InsnNode.copy(Unknown Source:26)
	at jadx.core.dex.nodes.InsnNode.copyCommonParams(Unknown Source:44)
	at jadx.core.dex.nodes.InsnNode.copy(Unknown Source:19)
	at jadx.core.codegen.InsnGen.inlineMethod(Unknown Source:54)
	at jadx.core.codegen.InsnGen.makeInvoke(Unknown Source:16)
	at jadx.core.codegen.InsnGen.makeInsnBody(Unknown Source:222)
	at jadx.core.codegen.InsnGen.makeInsn(Unknown Source:48)
	... 30 more
Caused by: java.lang.reflect.InvocationTargetException
	at java.lang.reflect.Method.invoke(Native Method)
	at android.s.ۥۡۡۢ.ۥ(Unknown Source:26)
	... 46 more
Caused by: java.lang.UnsupportedOperationException: ObjectStreamClass.getConstructorId(Class<?>) is not supported on SDK 30
	at java.io.ObjectStreamClass.getConstructorId(ObjectStreamClass.java:2498)
	... 48 more

*/

    public final float d(int i) {
        int i2 = this.f;
        int i3 = i2 - 1;
        Layout layout = this.e;
        if (i == i3) {
            FontMetricsInt fontMetricsInt = this.l;
            if (fontMetricsInt != null) {
                return ((float) layout.getLineBottom(i - 1)) + ((float) fontMetricsInt.bottom);
            }
        }
        return (((float) this.g) + ((float) layout.getLineBottom(i))) + ((float) (i == i2 + -1 ? this.h : 0));
    }

    public final float c(int i) {
        float f;
        float f2 = (float) this.g;
        if (i == this.f - 1) {
            FontMetricsInt fontMetricsInt = this.l;
            if (fontMetricsInt != null) {
                f = f(i) - ((float) fontMetricsInt.ascent);
                return f2 + f;
            }
        }
        f = (float) this.e.getLineBaseline(i);
        return f2 + f;
    }

    public final int e(int i) {
        ThreadLocal threadLocal = db1.a;
        Layout layout = this.e;
        return (layout.getEllipsisCount(i) <= 0 || this.b != TruncateAt.END) ? layout.getLineEnd(i) : layout.getText().length();
    }

    public final float h(int i, boolean z) {
        return (this.e.getLineForOffset(i) == this.f + -1 ? this.i + this.j : 0.0f) + b().h(i, false, z);
    }

    public final int a() {
        boolean z = this.d;
        Layout layout = this.e;
        return (((z ? layout.getLineBottom(this.f - 1) : layout.getHeight()) + this.g) + this.h) + this.m;
    }

    public final float g(int i, boolean z) {
        return (this.e.getLineForOffset(i) == this.f - 1 ? this.i + this.j : 0.0f) + b().h(i, true, z);
    }

    public final float f(int i) {
        return ((float) this.e.getLineTop(i)) + ((float) (i == 0 ? 0 : this.g));
    }

    public final pa b() {
        pa paVar = this.p;
        if (paVar != null) {
            return paVar;
        }
        paVar = new pa(this.e);
        this.p = paVar;
        return paVar;
    }
}