package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: a31 */
public final class a31 implements uw {
    public final z21 e;

    public final Object k(Object obj, ml mlVar) {
        cm c = this.e.c(mlVar, obj);
        return c == cm.e ? c : we1.a;
    }

    public a31(yu0 yu0) {
        this.e = yu0;
    }
}