package defpackage;

import java.util.Map.Entry;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: d61 */
public final class d61 implements Entry, Comparable {
    public final Comparable e;
    public Object f;
    public final /* synthetic */ c61 g;

    public final boolean equals(Object obj) {
        if (obj != this) {
            if (obj instanceof Entry) {
                Entry entry = (Entry) obj;
                rl key = entry.getKey();
                Comparable comparable = this.e;
                boolean equals = comparable == null ? key == null : comparable.equals(key);
                if (equals) {
                    Object obj2 = this.f;
                    obj = entry.getValue();
                    boolean equals2 = obj2 == null ? obj == null : obj2.equals(obj);
                    if (equals2) {
                        return true;
                    }
                }
            }
            return false;
        }
        return true;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.e);
        stringBuilder.append("=");
        stringBuilder.append(this.f);
        return stringBuilder.toString();
    }

    public final int hashCode() {
        int i = 0;
        Comparable comparable = this.e;
        int hashCode = comparable == null ? 0 : comparable.hashCode();
        Object obj = this.f;
        if (obj != null) {
            i = obj.hashCode();
        }
        return hashCode ^ i;
    }

    public final int compareTo(Object obj) {
        return this.e.compareTo(((d61) obj).e);
    }

    public d61(c61 c61, Comparable comparable, Object obj) {
        this.g = c61;
        this.e = comparable;
        this.f = obj;
    }

    public final Object setValue(Object obj) {
        this.g.b();
        Object obj2 = this.f;
        this.f = obj;
        return obj2;
    }

    public final rl getKey() {
        return this.e;
    }

    public final Object getValue() {
        return this.f;
    }
}