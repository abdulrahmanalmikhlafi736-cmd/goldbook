package defpackage;

import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: kk */
public abstract class kk {
    public static final /* synthetic */ AtomicReferenceFieldUpdater a;
    public static final /* synthetic */ AtomicReferenceFieldUpdater b;
    private volatile /* synthetic */ Object _next$volatile;
    private volatile /* synthetic */ Object _prev$volatile;

    public final void d() {
        if (b() != null) {
            while (true) {
                AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = b;
                kk kkVar = (kk) atomicReferenceFieldUpdater.get(this);
                while (kkVar != null && kkVar.c()) {
                    kkVar = (kk) atomicReferenceFieldUpdater.get(kkVar);
                }
                kk b = b();
                b.getClass();
                while (b.c()) {
                    kk b2 = b.b();
                    if (b2 == null) {
                        break;
                    }
                    b = b2;
                }
                while (true) {
                    Object obj = atomicReferenceFieldUpdater.get(b);
                    Object obj2 = ((kk) obj) == null ? null : kkVar;
                    while (!atomicReferenceFieldUpdater.compareAndSet(b, obj, obj2)) {
                        if (atomicReferenceFieldUpdater.get(b) != obj) {
                        }
                    }
                    break;
                }
                if (kkVar != null) {
                    a.set(kkVar, b);
                }
                if ((!b.c() || b.b() == null) && (kkVar == null || !kkVar.c())) {
                }
            }
        }
    }

    static {
        Class cls = kk.class;
        Class cls2 = Object.class;
        a = AtomicReferenceFieldUpdater.newUpdater(cls, cls2, "_next$volatile");
        b = AtomicReferenceFieldUpdater.newUpdater(cls, cls2, "_prev$volatile");
    }

    public final kk b() {
        mt mtVar = a.get(this);
        return mtVar == j70.b ? null : (kk) mtVar;
    }

    public final void a() {
        b.set(this, null);
    }

    public kk(a21 a21) {
        this._prev$volatile = a21;
    }

    public abstract boolean c();
}