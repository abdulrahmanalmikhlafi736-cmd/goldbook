package defpackage;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bf0 */
public abstract class bf0 {
    public static final lv0 a;

    /* JADX WARNING: Removed duplicated region for block: B:17:0x0042  */
    /* JADX WARNING: Removed duplicated region for block: B:16:0x0041  */
    /* JADX WARNING: Removed duplicated region for block: B:20:0x0047  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    static {
        lv0 lv0;
        lv0 lv02;
        Class[] clsArr = null;
        try {
            ClassLoader classLoader = sd0.class.getClassLoader();
            classLoader.getClass();
            Method method = classLoader.loadClass("androidx.compose.ui.platform.AndroidCompositionLocals_androidKt").getMethod("getLocalLifecycleOwner", null);
            for (Annotation annotation : method.getAnnotations()) {
                if (annotation instanceof op) {
                    break;
                }
            }
            Object invoke = method.invoke(null, null);
            if (invoke instanceof lv0) {
                lv0 = (lv0) invoke;
                if (lv0 instanceof px0) {
                    clsArr = lv0;
                }
                lv02 = (lv0) clsArr;
                if (lv02 == null) {
                    lv02 = new ad0(new h90(19));
                }
                a = lv02;
            }
            lv0 = null;
        } catch (Throwable th) {
            lv0 = new px0(th);
        }
        if (lv0 instanceof px0) {
        }
        lv02 = (lv0) clsArr;
        if (lv02 == null) {
        }
        a = lv02;
    }
}