package defpackage;

import android.os.Looper;
import android.view.Choreographer;
import java.util.Random;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: b7 */
public final class b7 extends ThreadLocal {
    public final /* synthetic */ int a;

    public final Object initialValue() {
        switch (this.a) {
            case 0:
                Object O;
                Choreographer instance = Choreographer.getInstance();
                Looper myLooper = Looper.myLooper();
                if (myLooper != null) {
                    d7 d7Var = new d7(instance, vd1.j(myLooper));
                    O = vn.O(d7Var, d7Var.p);
                } else {
                    od.p("no Looper on this thread");
                    O = null;
                }
                return O;
            default:
                return new Random();
        }
    }

    public /* synthetic */ b7(int i) {
        this.a = i;
    }
}