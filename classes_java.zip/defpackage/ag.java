package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ag */
public final class ag extends qi0 implements e21 {
    public final i00 a;

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof ag) && this.a == ((ag) obj).a;
    }

    public final d21 c() {
        d21 d21 = new d21();
        d21.g = false;
        d21.h = true;
        this.a.i(d21);
        return d21;
    }

    public final li0 e() {
        return new ol(false, true, this.a);
    }

    public final void f(li0 li0) {
        ((ol) li0).u = this.a;
    }

    public final int hashCode() {
        return this.a.hashCode();
    }

    public ag(i00 i00) {
        this.a = i00;
    }
}