package defpackage;

import android.os.Trace;
import android.view.autofill.AutofillManager;
import android.view.autofill.AutofillManager$AutofillCallback;
import android.view.autofill.AutofillValue;
import androidx.core.content.FileProvider;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Set;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: d10 */
public final class d10 {
    public int A;
    public int B;
    public boolean C;
    public final c10 D;
    public final ArrayList E;
    public boolean F;
    public w51 G;
    public x51 H;
    public a61 I;
    public boolean J;
    public qr0 K;
    public ve L;
    public final pj M;
    public y00 N;
    public bw O;
    public l51 P;
    public final wj Q;
    public final sl R;
    public boolean S;
    public long T;
    public e10 U;
    public final k9 a;
    public final sj b;
    public final x51 c;
    public final kk0 d;
    public final ve e;
    public final ve f;
    public final pg0 g;
    public final yj h;
    public final ArrayList i = new ArrayList();
    public g10 j;
    public int k;
    public int l;
    public int m;
    public final w60 n = new w60();
    public int[] o;
    public qj0 p;
    public boolean q;
    public boolean r;
    public final ArrayList s = new ArrayList();
    public final w60 t = new w60();
    public qr0 u = qr0.h;
    public sj0 v;
    public boolean w;
    public final w60 x = new w60();
    public boolean y;
    public int z = -1;

    /* JADX WARNING: Removed duplicated region for block: B:151:0x03a9  */
    /* JADX WARNING: Removed duplicated region for block: B:171:0x0427  */
    /* JADX WARNING: Removed duplicated region for block: B:256:0x0426 A:{SYNTHETIC} */
    /* JADX WARNING: Removed duplicated region for block: B:218:0x05b2  */
    /* JADX WARNING: Removed duplicated region for block: B:174:0x042f  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void p(boolean z) {
        a61 a61;
        int i;
        int s;
        w51 w51;
        w51 w512;
        int i2;
        w60 w60;
        int i3;
        List list;
        int i4;
        boolean z2;
        w51 w513;
        ArrayList arrayList;
        g10 g10;
        w60 w602 = this.n;
        int i5 = w602.a[w602.b - 2] - 1;
        boolean z3 = this.S;
        nq0 nq0 = oj.a;
        Object t;
        Object q;
        long rotateRight;
        if (z3) {
            a61 = this.I;
            i = a61.v;
            s = a61.s(i);
            t = this.I.t(i);
            q = this.I.q(i);
            if (t != null) {
                rotateRight = Long.rotateRight(Long.rotateRight(this.T, 3) ^ ((long) (t instanceof Enum ? ((Enum) t).ordinal() : t.hashCode())), 3);
            } else if (q == null || s != 207 || q.equals(nq0)) {
                rotateRight = Long.rotateRight(Long.rotateRight(this.T ^ ((long) i5), 3) ^ ((long) s), 3);
            } else {
                this.T = Long.rotateRight(Long.rotateRight(this.T ^ ((long) i5), 3) ^ ((long) q.hashCode()), 3);
            }
            this.T = rotateRight;
        } else {
            w51 = this.G;
            i = w51.i;
            s = w51.i(i);
            w51 w514 = this.G;
            t = w514.p(w514.b, i);
            w512 = this.G;
            q = w512.b(w512.b, i);
            if (t != null) {
                rotateRight = Long.rotateRight(Long.rotateRight(this.T, 3) ^ ((long) (t instanceof Enum ? ((Enum) t).ordinal() : t.hashCode())), 3);
            } else if (q == null || s != 207 || q.equals(nq0)) {
                rotateRight = Long.rotateRight(Long.rotateRight(this.T ^ ((long) i5), 3) ^ ((long) s), 3);
            } else {
                this.T = Long.rotateRight(Long.rotateRight(this.T ^ ((long) i5), 3) ^ ((long) q.hashCode()), 3);
            }
            this.T = rotateRight;
        }
        i5 = this.l;
        cm0 cm0 = this.j;
        List list2 = this.s;
        pj pjVar = this.M;
        if (cm0 != null) {
            sj0 sj0 = cm0.e;
            int i6 = cm0.b;
            a91 a91 = cm0.a;
            if (a91.size() > 0) {
                int i7;
                a91 a912;
                int length;
                int i8;
                w60 w603;
                zo0 zo0;
                a91 a913 = cm0.d;
                a91 h90 = new h90(a913.size());
                int size = a913.size();
                int i9 = 3;
                for (i7 = 0; i7 < size; i7++) {
                    h90.add(a913.get(i7));
                }
                i2 = -1;
                ik0 ik0 = o01.a;
                ac ik02 = new ik0();
                i7 = a913.size();
                size = a91.size();
                int i10 = 0;
                int i11 = 0;
                int i12 = 0;
                while (i10 < size) {
                    int i13;
                    e90 e90 = (e90) a91.get(i10);
                    int i14;
                    if (h90.contains(e90)) {
                        w60 = w602;
                        i13 = i10;
                        if (ik02.c(e90) == null) {
                            i14 = i11;
                            if (i14 < i7) {
                                cm0 cm02;
                                ac acVar;
                                int i15;
                                int i16;
                                a91 a914;
                                a91 a915;
                                t20 t20;
                                e90 e902 = (e90) a913.get(i14);
                                if (e902 != e90) {
                                    t20 t202 = (t20) sj0.b(e902.c);
                                    i = t202 != null ? t202.b : -1;
                                    ik02.a(e902);
                                    i11 = i14;
                                    i14 = i12;
                                    cm02 = cm0;
                                    if (i != i14) {
                                        t20 t203 = (t20) sj0.b(e902.c);
                                        s = t203 != null ? t203.c : e902.d;
                                        acVar = ik02;
                                        i3 = i + i6;
                                        i15 = i7;
                                        i7 = i14 + i6;
                                        if (s > 0) {
                                            i16 = i6;
                                            i6 = pjVar.l;
                                            if (i6 > 0) {
                                                int i17 = i6;
                                                a912 = a91;
                                                if (pjVar.j == i3 - i17 && pjVar.k == i7 - i17) {
                                                    pjVar.l = i17 + s;
                                                }
                                            } else {
                                                a912 = a91;
                                            }
                                            pjVar.c();
                                            pjVar.j = i3;
                                            pjVar.k = i7;
                                            pjVar.l = s;
                                        } else {
                                            i16 = i6;
                                            a912 = a91;
                                            pjVar.getClass();
                                        }
                                        int i18;
                                        if (i > i14) {
                                            Object[] objArr = sj0.c;
                                            long[] jArr = sj0.a;
                                            length = jArr.length - 2;
                                            if (length >= 0) {
                                                a914 = a913;
                                                a915 = h90;
                                                i3 = 0;
                                                while (true) {
                                                    Object[] objArr2;
                                                    long[] jArr2;
                                                    long j = jArr[i3];
                                                    i18 = s;
                                                    list = list2;
                                                    if (((((~j) << 7) & j) & -9187201950435737472L) != -9187201950435737472L) {
                                                        s = 8 - ((~(i3 - length)) >>> 31);
                                                        i4 = 0;
                                                        while (i4 < s) {
                                                            int i19;
                                                            if ((j & 255) < 128) {
                                                                i19 = i4;
                                                                t20 = (t20) objArr[(i3 << 3) + i4];
                                                                objArr2 = objArr;
                                                                i7 = t20.b;
                                                                jArr2 = jArr;
                                                                if (i <= i7 && i7 < i + i18) {
                                                                    t20.b = (i7 - i) + i14;
                                                                } else if (i14 <= i7 && i7 < i) {
                                                                    t20.b = i7 + i18;
                                                                }
                                                            } else {
                                                                i19 = i4;
                                                                objArr2 = objArr;
                                                                jArr2 = jArr;
                                                            }
                                                            j >>= 8;
                                                            i4 = i19 + 1;
                                                            objArr = objArr2;
                                                            jArr = jArr2;
                                                        }
                                                        objArr2 = objArr;
                                                        jArr2 = jArr;
                                                        if (s != 8) {
                                                            break;
                                                        }
                                                    } else {
                                                        objArr2 = objArr;
                                                        jArr2 = jArr;
                                                    }
                                                    if (i3 == length) {
                                                        break;
                                                    }
                                                    i3++;
                                                    list2 = list;
                                                    s = i18;
                                                    objArr = objArr2;
                                                    jArr = jArr2;
                                                }
                                            } else {
                                                list = list2;
                                            }
                                        } else {
                                            i18 = s;
                                            list = list2;
                                            a914 = a913;
                                            a915 = h90;
                                            if (i14 > i) {
                                                Object[] objArr3 = sj0.c;
                                                long[] jArr3 = sj0.a;
                                                i3 = jArr3.length - 2;
                                                if (i3 >= 0) {
                                                    i7 = 0;
                                                    while (true) {
                                                        Object[] objArr4;
                                                        long[] jArr4;
                                                        int i20;
                                                        long j2 = jArr3[i7];
                                                        if (((((~j2) << 7) & j2) & -9187201950435737472L) != -9187201950435737472L) {
                                                            i8 = 8 - ((~(i7 - i3)) >>> 31);
                                                            int i21 = 0;
                                                            while (i21 < i8) {
                                                                if ((j2 & 255) < 128) {
                                                                    objArr4 = objArr3;
                                                                    t203 = (t20) objArr3[(i7 << 3) + i21];
                                                                    jArr4 = jArr3;
                                                                    i4 = t203.b;
                                                                    i20 = i;
                                                                    if (i <= i4 && i4 < i20 + i18) {
                                                                        t203.b = (i4 - i20) + i14;
                                                                    } else if (i20 + 1 <= i4 && i4 < i14) {
                                                                        t203.b = i4 - i18;
                                                                    }
                                                                } else {
                                                                    objArr4 = objArr3;
                                                                    jArr4 = jArr3;
                                                                    i20 = i;
                                                                }
                                                                j2 >>= 8;
                                                                i21++;
                                                                jArr3 = jArr4;
                                                                objArr3 = objArr4;
                                                                i = i20;
                                                            }
                                                            objArr4 = objArr3;
                                                            jArr4 = jArr3;
                                                            i20 = i;
                                                            if (i8 != 8) {
                                                                break;
                                                            }
                                                        } else {
                                                            objArr4 = objArr3;
                                                            jArr4 = jArr3;
                                                            i20 = i;
                                                        }
                                                        if (i7 == i3) {
                                                            break;
                                                        }
                                                        i7++;
                                                        jArr3 = jArr4;
                                                        objArr3 = objArr4;
                                                        i = i20;
                                                    }
                                                }
                                            }
                                        }
                                        s = i13;
                                    } else {
                                        list = list2;
                                        acVar = ik02;
                                        i15 = i7;
                                        i16 = i6;
                                        a912 = a91;
                                    }
                                    a914 = a913;
                                    a915 = h90;
                                    s = i13;
                                } else {
                                    i11 = i14;
                                    list = list2;
                                    acVar = ik02;
                                    i15 = i7;
                                    i16 = i6;
                                    a912 = a91;
                                    a914 = a913;
                                    a915 = h90;
                                    i14 = i12;
                                    cm02 = cm0;
                                    s = i13 + 1;
                                }
                                i11++;
                                t20 = (t20) sj0.b(e902.c);
                                i14 += t20 != null ? t20.c : e902.d;
                                i10 = s;
                                cm0 = cm02;
                                ik02 = acVar;
                                i7 = i15;
                                i6 = i16;
                                a91 = a912;
                                a913 = a914;
                                h90 = a915;
                                list2 = list;
                                i12 = i14;
                                w602 = w60;
                            } else {
                                i11 = i14;
                                i14 = i12;
                                w602 = w60;
                                i10 = i13;
                            }
                        }
                    } else {
                        w60 = w602;
                        t20 t204 = (t20) sj0.b(e90.c);
                        int i22 = t204 != null ? t204.b : -1;
                        i14 = e90.c;
                        i13 = i10;
                        pjVar.e(i22 + i6, e90.d);
                        cm0.a(i14, 0);
                        pjVar.f = (i14 - pjVar.a.G.g) + pjVar.f;
                        this.G.r(i14);
                        I();
                        this.G.s();
                        vn.f(list2, i14, this.G.b[(i14 * 5) + 3] + i14);
                    }
                    i10 = i13 + 1;
                    w602 = w60;
                }
                w60 = w602;
                list = list2;
                a912 = a91;
                pjVar.c();
                if (a912.size() > 0) {
                    w51 w515 = this.G;
                    pjVar.f = (w515.h - pjVar.a.G.g) + pjVar.f;
                    w515.t();
                }
                z2 = this.S;
                if (!z2) {
                    w51 = this.G;
                    i4 = w51.m - w51.l;
                    if (i4 > 0) {
                        if (i4 > 0) {
                            pjVar.d(false);
                            w603 = pjVar.d;
                            w51 w516 = pjVar.a.G;
                            if (w516.c > 0) {
                                i7 = w516.i;
                                if (w603.a(-2) != i7) {
                                    if (!pjVar.c && pjVar.e) {
                                        pjVar.d(false);
                                        pjVar.b.F.C(eo0.c);
                                        pjVar.c = true;
                                    }
                                    if (i7 > 0) {
                                        y00 a = w516.a(i7);
                                        w603.c(i7);
                                        pjVar.d(false);
                                        zo0 zo02 = pjVar.b.F;
                                        zo02.C(do0.c);
                                        dd0.v(zo02, 0, a);
                                        pjVar.c = true;
                                    }
                                }
                            }
                            zo0 = pjVar.b.F;
                            zo0.C(so0.c);
                            zo0.d[zo0.e - zo0.b[zo0.c - 1].a] = i4;
                        } else {
                            pjVar.getClass();
                        }
                    }
                }
                s = this.k;
                while (true) {
                    w513 = this.G;
                    if (w513.k <= 0) {
                        break;
                    }
                    i3 = w513.g;
                    if (i3 == w513.h) {
                        break;
                    }
                    i4 = i2;
                    I();
                    pjVar.e(s, this.G.s());
                    vn.f(list, i3, this.G.g);
                }
                if (z2) {
                    if (z) {
                        pjVar.a();
                    }
                    i10 = pjVar.a.G.i;
                    w603 = pjVar.d;
                    i4 = i2;
                    if (w603.a(i4) > i10) {
                        FileProvider.a("Missed recording an endGroup");
                    }
                    if (w603.a(i4) == i10) {
                        pjVar.d(false);
                        w603.b();
                        pjVar.b.F.C(ao0.c);
                    }
                    i10 = this.G.i;
                    if (i5 != i0(i10)) {
                        e0(i10, i5);
                    }
                    if (z) {
                        i5 = 1;
                    }
                    this.G.e();
                    pjVar.c();
                } else {
                    int i23;
                    if (z) {
                        bw bwVar = this.O;
                        zo0 = bwVar.c;
                        if (zo0.c == 0) {
                            FileProvider.a("Cannot end node insertion, there are no pending operations that can be realized.");
                        }
                        zo0 zo03 = bwVar.b;
                        xo0[] xo0Arr = zo0.b;
                        i3 = zo0.c - 1;
                        zo0.c = i3;
                        xo0 xo0 = xo0Arr[i3];
                        xo0Arr[i3] = null;
                        zo03.C(xo0);
                        Object[] objArr5 = zo0.f;
                        Object[] objArr6 = zo03.f;
                        i23 = zo03.g;
                        i6 = xo0.b;
                        i23 -= i6;
                        length = zo0.g;
                        i8 = length - i6;
                        System.arraycopy(objArr5, i8, objArr6, i23, length - i8);
                        objArr5 = zo0.f;
                        i3 = zo0.g;
                        Arrays.fill(objArr5, i3 - i6, i3, null);
                        int[] iArr = zo0.d;
                        int[] iArr2 = zo03.d;
                        i5 = zo03.e;
                        i7 = xo0.a;
                        i5 -= i7;
                        i = zo0.e;
                        ba.W(iArr, iArr2, i5, i - i7, i);
                        zo0.g -= i6;
                        zo0.e -= i7;
                        i5 = 1;
                    }
                    w51 = this.G;
                    if (w51.k <= 0) {
                        FileProvider.a("Unbalanced begin/end empty");
                    }
                    w51.k--;
                    a61 = this.I;
                    i4 = a61.v;
                    a61.j();
                    if (this.G.k <= 0) {
                        boolean z4;
                        s = -2 - i4;
                        this.I.k();
                        this.I.e(true);
                        y00 y00 = this.N;
                        boolean B = this.O.b.B();
                        x51 x51 = this.H;
                        w60 w604;
                        y00 a2;
                        zo0 zo04;
                        if (B) {
                            pjVar.b();
                            pjVar.d(false);
                            w604 = pjVar.d;
                            w51 w517 = pjVar.a.G;
                            if (w517.c > 0) {
                                i23 = w517.i;
                                if (w604.a(-2) != i23) {
                                    if (!pjVar.c && pjVar.e) {
                                        pjVar.d(false);
                                        pjVar.b.F.C(eo0.c);
                                        pjVar.c = true;
                                    }
                                    if (i23 > 0) {
                                        a2 = w517.a(i23);
                                        w604.c(i23);
                                        pjVar.d(false);
                                        zo0 zo05 = pjVar.b.F;
                                        zo05.C(do0.c);
                                        dd0.v(zo05, 0, a2);
                                        i = 1;
                                        pjVar.c = true;
                                        pjVar.c();
                                        zo04 = pjVar.b.F;
                                        zo04.C(go0.c);
                                        dd0.w(zo04, 0, y00, i, x51);
                                        z4 = false;
                                    }
                                }
                            }
                            i = 1;
                            pjVar.c();
                            zo04 = pjVar.b.F;
                            zo04.C(go0.c);
                            dd0.w(zo04, 0, y00, i, x51);
                            z4 = false;
                        } else {
                            bw bwVar2 = this.O;
                            pjVar.b();
                            pjVar.d(false);
                            w604 = pjVar.d;
                            w512 = pjVar.a.G;
                            if (w512.c > 0) {
                                i6 = w512.i;
                                if (w604.a(-2) != i6) {
                                    if (!pjVar.c && pjVar.e) {
                                        pjVar.d(false);
                                        pjVar.b.F.C(eo0.c);
                                        pjVar.c = true;
                                    }
                                    if (i6 > 0) {
                                        a2 = w512.a(i6);
                                        w604.c(i6);
                                        pjVar.d(false);
                                        zo0 zo06 = pjVar.b.F;
                                        zo06.C(do0.c);
                                        dd0.v(zo06, 0, a2);
                                        pjVar.c = true;
                                    }
                                }
                            }
                            pjVar.c();
                            zo04 = pjVar.b.F;
                            zo04.C(ho0.c);
                            i3 = zo04.g - zo04.b[zo04.c - 1].b;
                            Object[] objArr7 = zo04.f;
                            objArr7[i3] = y00;
                            objArr7[i3 + 1] = x51;
                            objArr7[i3 + 2] = bwVar2;
                            this.O = new bw();
                            z4 = false;
                        }
                        this.S = z4;
                        if (this.c.f != 0) {
                            d0(s, z4);
                            e0(s, i5);
                        }
                    }
                }
                arrayList = this.i;
                g10 = (g10) arrayList.remove(arrayList.size() - 1);
                if (!(g10 == null || z2)) {
                    g10.c++;
                }
                this.j = g10;
                this.k = w60.b() + i5;
                this.m = w60.b();
                this.l = w60.b() + i5;
            }
        }
        w60 = w602;
        list = list2;
        i2 = -1;
        z2 = this.S;
        if (z2) {
        }
        s = this.k;
        while (true) {
            w513 = this.G;
            if (w513.k <= 0) {
            }
            i4 = i2;
            I();
            pjVar.e(s, this.G.s());
            vn.f(list, i3, this.G.g);
        }
        if (z2) {
        }
        arrayList = this.i;
        g10 = (g10) arrayList.remove(arrayList.size() - 1);
        g10.c++;
        this.j = g10;
        this.k = w60.b() + i5;
        this.m = w60.b();
        this.l = w60.b() + i5;
    }

    /* JADX WARNING: Removed duplicated region for block: B:75:0x014c  */
    /* JADX WARNING: Removed duplicated region for block: B:50:0x00d2  */
    /* JADX WARNING: Removed duplicated region for block: B:75:0x014c  */
    /* JADX WARNING: Removed duplicated region for block: B:20:0x0071  */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x007b  */
    /* JADX WARNING: Removed duplicated region for block: B:23:0x0079  */
    /* JADX WARNING: Removed duplicated region for block: B:42:0x00c4  */
    /* JADX WARNING: Removed duplicated region for block: B:27:0x0082  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void S(int i, int i2, Object obj, Object obj2) {
        long rotateLeft;
        boolean z;
        int i3 = i;
        int i4 = i2;
        Object obj3 = obj;
        a40 a40 = obj2;
        Integer valueOf = Integer.valueOf(-1);
        if (this.r) {
            FileProvider.a("A call to createNode(), emitNode() or useNode() expected");
        }
        int i5 = this.m;
        Object obj4 = oj.a;
        if (obj3 != null) {
            rotateLeft = Long.rotateLeft(Long.rotateLeft(this.T, 3) ^ ((long) (obj3 instanceof Enum ? ((Enum) obj3).ordinal() : obj3.hashCode())), 3);
        } else if (a40 == null || i3 != 207 || a40.equals(obj4)) {
            rotateLeft = Long.rotateLeft(Long.rotateLeft(this.T, 3) ^ ((long) i3), 3) ^ ((long) i5);
        } else {
            this.T = Long.rotateLeft(Long.rotateLeft(this.T, 3) ^ ((long) a40.hashCode()), 3) ^ ((long) i5);
            if (obj3 == null) {
                this.m++;
            }
            z = i4 == 0;
            int g;
            g10 g10;
            w51 w51;
            a61 a61;
            int i6;
            if (this.S) {
                g10 g102;
                if (i4 == 1) {
                    if (this.y) {
                        i4 = 1;
                        if (this.j == null) {
                            int i7;
                            int i8;
                            g = this.G.g();
                            if (i4 == 0 && g == i3) {
                                w51 w512 = this.G;
                                i7 = w512.g;
                                if (k70.p(obj3, i7 < w512.h ? w512.p(w512.b, i7) : null)) {
                                    V(a40, z);
                                }
                            }
                            w51 w513 = this.G;
                            int[] iArr = w513.b;
                            ArrayList arrayList = new ArrayList();
                            if (w513.k <= 0) {
                                i8 = w513.g;
                                while (i8 < w513.h) {
                                    int i9 = i8 * 5;
                                    i5 = iArr[i9];
                                    Object p = w513.p(iArr, i8);
                                    int i10 = iArr[i9 + 1];
                                    if ((i10 & 1073741824) != 0) {
                                        i2 = i4;
                                        i4 = 1;
                                    } else {
                                        i2 = i4;
                                        i4 = i10 & 67108863;
                                    }
                                    arrayList.add(new e90(p, i5, i8, i4));
                                    i8 += iArr[i9 + 3];
                                    i4 = i2;
                                }
                            }
                            i2 = i4;
                            this.j = new g10(this.k, arrayList);
                            g10 = this.j;
                            if (g10 != null) {
                                arrayList = g10.d;
                                sj0 sj0 = g10.e;
                                int i11 = g10.b;
                                Object i80 = obj3 != null ? new i80(Integer.valueOf(i3), obj3) : Integer.valueOf(i3);
                                hk0 hk0 = ((oj0) g10.f.getValue()).a;
                                AutofillManager g2 = ((AutofillManager) hk0);
                                if (g2 == null) {
                                    g2 = null;
                                } else if (g2 instanceof ak0) {
                                    ak0 ak0 = (ak0) g2;
                                    AutofillManager k = ak0.k(0);
                                    if (ak0.h()) {
                                        hk0.k(i80);
                                    }
                                    if (ak0.b == 1) {
                                        hk0.m(i80, ak0.e());
                                    }
                                    g2 = k;
                                } else {
                                    hk0.k(i80);
                                }
                                e90 e90 = (e90) g2;
                                int i12;
                                if (i2 != 0 || e90 == null) {
                                    w51 = this.G;
                                    w51.k++;
                                    this.S = true;
                                    this.K = null;
                                    if (this.I.w) {
                                        a61 e = this.H.e();
                                        this.I = e;
                                        e.M();
                                        this.J = false;
                                        this.K = null;
                                    }
                                    this.I.d();
                                    a61 = this.I;
                                    i12 = a61.t;
                                    if (z) {
                                        a61.Q(i3, obj4, true, obj4);
                                        i7 = 0;
                                    } else if (a40 != null) {
                                        if (obj != null) {
                                            obj4 = obj;
                                        }
                                        i7 = 0;
                                        a61.Q(i3, obj4, false, a40);
                                    } else {
                                        i7 = 0;
                                        a61.Q(i3, obj == null ? obj4 : obj, false, obj4);
                                    }
                                    this.N = this.I.b(i12);
                                    i6 = -2 - i12;
                                    e90 e902 = new e90(valueOf, i3, i6, -1);
                                    sj0.h(i6, new t20(-1, this.k - i11, i7));
                                    arrayList.add(e902);
                                    g102 = new g10(z ? i7 : this.k, new ArrayList());
                                    u(z, g102);
                                    return;
                                }
                                int i13;
                                i3 = e90.c;
                                arrayList.add(e90);
                                t20 t20 = (t20) sj0.b(i3);
                                this.k = (t20 != null ? t20.b : -1) + i11;
                                t20 = (t20) sj0.b(i3);
                                int i14 = t20 != null ? t20.a : -1;
                                i4 = g10.c;
                                i12 = i14 - i4;
                                int i15 = 8;
                                int length;
                                long j;
                                if (i14 > i4) {
                                    Object[] objArr = sj0.c;
                                    long[] jArr = sj0.a;
                                    length = jArr.length - 2;
                                    if (length >= 0) {
                                        i11 = 0;
                                        while (true) {
                                            j = jArr[i11];
                                            if (((((~j) << 7) & j) & -9187201950435737472L) != -9187201950435737472L) {
                                                i8 = 8 - ((~(i11 - length)) >>> 31);
                                                i7 = 0;
                                                while (i7 < i8) {
                                                    long j2;
                                                    if ((j & 255) < 128) {
                                                        j2 = i15;
                                                        t20 t202 = (t20) objArr[(i11 << 3) + i7];
                                                        i13 = i12;
                                                        i12 = t202.a;
                                                        if (i12 == i14) {
                                                            t202.a = i4;
                                                        } else if (i4 <= i12 && i12 < i14) {
                                                            t202.a = i12 + 1;
                                                        }
                                                    } else {
                                                        i13 = i12;
                                                        j2 = i15;
                                                    }
                                                    j >>= j2;
                                                    i7++;
                                                    i12 = i13;
                                                    i15 = j2;
                                                }
                                                i13 = i12;
                                                if (i8 != i15) {
                                                    break;
                                                }
                                            } else {
                                                i13 = i12;
                                            }
                                            if (i11 == length) {
                                                break;
                                            }
                                            i11++;
                                            i12 = i13;
                                            i15 = 8;
                                        }
                                    } else {
                                        i13 = i12;
                                    }
                                } else {
                                    i13 = i12;
                                    if (i4 > i14) {
                                        Object[] objArr2 = sj0.c;
                                        long[] jArr2 = sj0.a;
                                        i5 = jArr2.length - 2;
                                        if (i5 >= 0) {
                                            length = 0;
                                            while (true) {
                                                Object[] objArr3;
                                                j = jArr2[length];
                                                if (((((~j) << 7) & j) & -9187201950435737472L) != -9187201950435737472L) {
                                                    i15 = 8 - ((~(length - i5)) >>> 31);
                                                    i11 = 0;
                                                    while (i11 < i15) {
                                                        if ((j & 255) < 128) {
                                                            t20 t203 = (t20) objArr2[(length << 3) + i11];
                                                            i7 = t203.a;
                                                            if (i7 == i14) {
                                                                t203.a = i4;
                                                            } else {
                                                                objArr3 = objArr2;
                                                                if (i14 + 1 <= i7 && i7 < i4) {
                                                                    t203.a = i7 - 1;
                                                                }
                                                                j >>= 8;
                                                                i11++;
                                                                objArr2 = objArr3;
                                                            }
                                                        }
                                                        objArr3 = objArr2;
                                                        j >>= 8;
                                                        i11++;
                                                        objArr2 = objArr3;
                                                    }
                                                    objArr3 = objArr2;
                                                    if (i15 != 8) {
                                                        break;
                                                    }
                                                } else {
                                                    objArr3 = objArr2;
                                                }
                                                if (length == i5) {
                                                    break;
                                                }
                                                length++;
                                                objArr2 = objArr3;
                                            }
                                        }
                                    }
                                }
                                pj pjVar = this.M;
                                i12 = pjVar.f;
                                d10 d10 = pjVar.a;
                                pjVar.f = (i3 - d10.G.g) + i12;
                                this.G.r(i3);
                                if (i13 > 0) {
                                    zo0 zo0;
                                    pjVar.d(false);
                                    w60 w60 = pjVar.d;
                                    w51 w514 = d10.G;
                                    if (w514.c > 0) {
                                        i14 = w514.i;
                                        if (w60.a(-2) != i14) {
                                            if (!pjVar.c && pjVar.e) {
                                                pjVar.d(false);
                                                pjVar.b.F.C(eo0.c);
                                                pjVar.c = true;
                                            }
                                            if (i14 > 0) {
                                                y00 a = w514.a(i14);
                                                w60.c(i14);
                                                pjVar.d(false);
                                                zo0 = pjVar.b.F;
                                                zo0.C(do0.c);
                                                dd0.v(zo0, 0, a);
                                                pjVar.c = true;
                                            }
                                        }
                                    }
                                    zo0 = pjVar.b.F;
                                    zo0.C(io0.c);
                                    zo0.d[zo0.e - zo0.b[zo0.c - 1].a] = i13;
                                }
                                V(a40, z);
                            }
                            g102 = null;
                            u(z, g102);
                            return;
                        }
                        i2 = i4;
                        g10 = this.j;
                        if (g10 != null) {
                        }
                        g102 = null;
                        u(z, g102);
                        return;
                    }
                }
                i4 = false;
                if (this.j == null) {
                }
                i2 = i4;
                g10 = this.j;
                if (g10 != null) {
                }
                g102 = null;
                u(z, g102);
                return;
            }
            w51 = this.G;
            w51.k++;
            a61 = this.I;
            g = a61.t;
            if (z) {
                a61.Q(i3, obj4, true, obj4);
            } else if (a40 != null) {
                if (obj3 == null) {
                    obj3 = obj4;
                }
                a61.Q(i3, obj3, false, a40);
            } else {
                if (obj3 == null) {
                    obj3 = obj4;
                }
                a61.Q(i3, obj3, false, obj4);
            }
            g10 = this.j;
            if (g10 != null) {
                i6 = -2 - g;
                e90 e903 = new e90(valueOf, i3, i6, -1);
                g10.e.h(i6, new t20(-1, this.k - g10.b, 0));
                g10.d.add(e903);
            }
            u(z, null);
            return;
        }
        this.T = rotateLeft;
        if (obj3 == null) {
        }
        if (i4 == 0) {
        }
        if (this.S) {
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:126:0x0290  */
    /* JADX WARNING: Removed duplicated region for block: B:59:0x0139  */
    /* JADX WARNING: Removed duplicated region for block: B:161:0x0327  */
    /* JADX WARNING: Removed duplicated region for block: B:167:0x033e  */
    /* JADX WARNING: Removed duplicated region for block: B:164:0x0330  */
    /* JADX WARNING: Removed duplicated region for block: B:11:0x0046  */
    /* JADX WARNING: Removed duplicated region for block: B:173:0x0372  */
    /* JADX WARNING: Removed duplicated region for block: B:172:0x0359  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void H() {
        u70 u70;
        int i;
        int i2;
        int i3;
        int i4;
        int i5;
        int i6;
        boolean z;
        nq0 nq0 = nq0.j;
        boolean z2 = this.F;
        this.F = true;
        w51 w51 = this.G;
        int i7 = w51.i;
        int i8 = (i7 * 5) + 3;
        int i9 = w51.b[i8] + i7;
        int i10 = this.k;
        long j = this.T;
        int i11 = this.l;
        int i12 = this.m;
        int i13 = w51.g;
        ArrayList arrayList = this.s;
        i13 = vn.s(i13, arrayList);
        if (i13 < 0) {
            i13 = -(i13 + 1);
        }
        int i14 = 3;
        if (i13 < arrayList.size()) {
            u70 = (u70) arrayList.get(i13);
            if (u70.b < i9) {
                int s;
                i = 1;
                i2 = i7;
                i3 = 0;
                while (u70 != null) {
                    int i15;
                    int i16;
                    xv0 xv0 = u70.a;
                    int i17 = u70.b;
                    nq0 nq02 = nq0;
                    s = vn.s(i17, arrayList);
                    if (s >= 0) {
                        u70 u702 = (u70) arrayList.remove(s);
                    }
                    Object obj = u70.c;
                    int i18;
                    if (obj == null) {
                        xv0.getClass();
                        i18 = i9;
                        i15 = i8;
                        i4 = i10;
                    } else {
                        long j2 = 8;
                        hk0 hk0 = xv0.g;
                        if (hk0 == null) {
                            i18 = i9;
                            i15 = i8;
                            i4 = i10;
                        } else {
                            Object[] objArr;
                            int i19;
                            long j3;
                            i15 = i8;
                            if (obj instanceof sp) {
                                sp spVar = (sp) obj;
                                a71 a71 = spVar.g;
                                if (a71 == null) {
                                    a71 = nq02;
                                }
                                i4 = i10;
                                s = a71.c(spVar.h().f, ((AutofillManager) hk0)) ^ 1;
                                i18 = i9;
                                i5 = i11;
                                i6 = i12;
                            } else {
                                i4 = i10;
                                if (obj instanceof ik0) {
                                    ik0 ik0 = (ik0) obj;
                                    if (ik0.h()) {
                                        Object[] objArr2 = ik0.b;
                                        long[] jArr = ik0.a;
                                        i10 = jArr.length - 2;
                                        if (i10 >= 0) {
                                            long[] jArr2 = jArr;
                                            i5 = i11;
                                            i6 = i12;
                                            s = 0;
                                            while (true) {
                                                long j4 = jArr2[s];
                                                i18 = i9;
                                                objArr = objArr2;
                                                if (((((~j4) << 7) & j4) & -9187201950435737472L) != -9187201950435737472L) {
                                                    i9 = 8 - ((~(s - i10)) >>> 31);
                                                    i8 = 0;
                                                    while (i8 < i9) {
                                                        if ((j4 & 255) < 128) {
                                                            i19 = i8;
                                                            Object obj2 = objArr[(s << 3) + i8];
                                                            j3 = j4;
                                                            if (!(obj2 instanceof sp)) {
                                                                break;
                                                            }
                                                            sp spVar2 = (sp) obj2;
                                                            a71 a712 = spVar2.g;
                                                            if (a712 == null) {
                                                                a712 = nq02;
                                                            }
                                                            if (a712.c(spVar2.h().f, ((AutofillManager) hk0)) == null) {
                                                                break;
                                                            }
                                                        } else {
                                                            i19 = i8;
                                                            j3 = j4;
                                                        }
                                                        j4 = j3 >> j2;
                                                        i8 = i19 + 1;
                                                    }
                                                    if (i9 != j2) {
                                                        break;
                                                    }
                                                }
                                                if (s == i10) {
                                                    break;
                                                }
                                                s++;
                                                i9 = i18;
                                                objArr2 = objArr;
                                                j2 = 8;
                                            }
                                            s = 0;
                                        }
                                    }
                                    i18 = i9;
                                    i5 = i11;
                                    i6 = i12;
                                    s = 0;
                                } else {
                                    i18 = i9;
                                }
                            }
                            if (s == 0) {
                                this.G.r(i17);
                                s = this.G.g;
                                K(i2, s, i7);
                                i2 = this.G.q(s);
                                while (i2 != i7 && !this.G.l(i2)) {
                                    i2 = this.G.q(i2);
                                }
                                i13 = this.G.l(i2) ? 0 : i4;
                                if (i2 != s) {
                                    i9 = (i0(i2) - this.G.o(s)) + i13;
                                    while (i13 < i9 && i2 != i17) {
                                        i2++;
                                        while (i2 < i17) {
                                            w51 w512 = this.G;
                                            i10 = w512.b[(i2 * 5) + 3] + i2;
                                            if (i17 >= i10) {
                                                i13 += w512.l(i2) ? i : i0(i2);
                                                i2 = i10;
                                            }
                                        }
                                        break;
                                    }
                                }
                                this.k = i13;
                                this.m = F(s);
                                i2 = this.G.q(s);
                                long j5 = 0;
                                i17 = i14;
                                i13 = 0;
                                while (i2 >= 0) {
                                    if (i2 == i7) {
                                        j5 ^= Long.rotateLeft(j, i13);
                                        break;
                                    }
                                    w51 w513 = this.G;
                                    boolean k = w513.k(i2);
                                    int[] iArr = w513.b;
                                    if (k) {
                                        Object p = w513.p(iArr, i2);
                                        if (p != null) {
                                            i10 = p instanceof Enum ? ((Enum) p).ordinal() : p.hashCode();
                                            i3 = s;
                                        } else {
                                            i3 = s;
                                            i10 = 0;
                                        }
                                    } else {
                                        i11 = w513.i(i2);
                                        i3 = s;
                                        if (i11 == 207) {
                                            obj = w513.b(iArr, i2);
                                            if (obj != null) {
                                                if (!obj.equals(oj.a)) {
                                                    i10 = obj.hashCode();
                                                }
                                            }
                                        }
                                        i10 = i11;
                                    }
                                    if (i10 == 126665345) {
                                        j5 ^= Long.rotateLeft((long) i10, i13);
                                        break;
                                    }
                                    j5 = (j5 ^ Long.rotateLeft((long) i10, i17)) ^ Long.rotateLeft((long) (this.G.k(i2) ? 0 : F(i2)), i13);
                                    i17 = (i17 + 6) % 64;
                                    i13 = (i13 + 6) % 64;
                                    i2 = this.G.q(i2);
                                    s = i3;
                                }
                                i3 = s;
                                this.T = j5;
                                this.K = null;
                                m00 m00 = xv0.d;
                                if (m00 != null) {
                                    m00.f(this, Integer.valueOf(i));
                                    this.K = null;
                                    w51 w514 = this.G;
                                    i13 = w514.b[i15] + i7;
                                    i9 = w514.g;
                                    i8 = (i9 < i7 || i9 > i13) ? 0 : i;
                                    if (i8 == 0) {
                                        StringBuilder dl1 = new dl1("Index ");
                                        dl1.append(i7);
                                        dl1.append(" is not a parent of ");
                                        dl1.append(i9);
                                        FileProvider.a(dl1.toString());
                                    }
                                    w514.i = i7;
                                    w514.h = i13;
                                    w514.l = 0;
                                    w514.m = 0;
                                    z = z2;
                                    s = 0;
                                    i2 = i3;
                                    i3 = i;
                                } else {
                                    od.p("Invalid restart scope");
                                    return;
                                }
                            }
                            ArrayList arrayList2 = this.E;
                            arrayList2.add(xv0);
                            this.g.k();
                            yj yjVar = xv0.a;
                            if (yjVar != null) {
                                zj0 zj0 = xv0.f;
                                if (zj0 != null) {
                                    xv0.d(i);
                                    try {
                                        Object[] objArr3 = zj0.b;
                                        int[] iArr2 = zj0.c;
                                        long[] jArr3 = zj0.a;
                                        i11 = jArr3.length - 2;
                                        z = z2;
                                        if (i11 >= 0) {
                                            i12 = 0;
                                            while (true) {
                                                long j6 = jArr3[i12];
                                                long[] jArr4 = jArr3;
                                                objArr = objArr3;
                                                if (((((~j6) << 7) & j6) & -9187201950435737472L) != -9187201950435737472L) {
                                                    i8 = 8 - ((~(i12 - i11)) >>> 31);
                                                    i17 = 0;
                                                    while (i17 < i8) {
                                                        if ((j6 & 255) < 128) {
                                                            i19 = (i12 << 3) + i17;
                                                            j3 = j6;
                                                            obj = objArr[i19];
                                                            i16 = iArr2[i19];
                                                            yjVar.y(obj);
                                                        } else {
                                                            j3 = j6;
                                                        }
                                                        i17++;
                                                        j6 = j3 >> 8;
                                                    }
                                                    if (i8 != 8) {
                                                        break;
                                                    }
                                                }
                                                if (i12 == i11) {
                                                    break;
                                                }
                                                i12++;
                                                objArr3 = objArr;
                                                jArr3 = jArr4;
                                            }
                                        }
                                        xv0.d(false);
                                        i = 1;
                                        arrayList2.remove(arrayList2.size() - 1);
                                    } catch (Throwable th) {
                                        xv0.d(false);
                                    }
                                }
                            }
                            z = z2;
                            i = 1;
                            arrayList2.remove(arrayList2.size() - 1);
                            i16 = vn.s(this.G.g, arrayList);
                            if (i16 < 0) {
                                i16 = -(i16 + 1);
                            }
                            if (i16 >= arrayList.size()) {
                                u70 u703 = (u70) arrayList.get(i16);
                                i9 = i18;
                                if (u703.b < i9) {
                                    u70 = u703;
                                    z2 = z;
                                    nq0 = nq02;
                                    i8 = i15;
                                    i10 = i4;
                                    i11 = i5;
                                    i12 = i6;
                                }
                            } else {
                                i9 = i18;
                            }
                            u70 = null;
                            z2 = z;
                            nq0 = nq02;
                            i8 = i15;
                            i10 = i4;
                            i11 = i5;
                            i12 = i6;
                        }
                    }
                    i5 = i11;
                    i6 = i12;
                    s = i;
                    if (s == 0) {
                    }
                    i16 = vn.s(this.G.g, arrayList);
                    if (i16 < 0) {
                    }
                    if (i16 >= arrayList.size()) {
                    }
                    u70 = null;
                    z2 = z;
                    nq0 = nq02;
                    i8 = i15;
                    i10 = i4;
                    i11 = i5;
                    i12 = i6;
                }
                z = z2;
                i4 = i10;
                i5 = i11;
                i6 = i12;
                if (i3 == 0) {
                    K(i2, i7, i7);
                    this.G.t();
                    s = i0(i7);
                    this.k = i4 + s;
                    this.l = i5 + s;
                    this.m = i6;
                } else {
                    Q();
                }
                this.T = j;
                this.F = z;
            }
        }
        u70 = null;
        i = 1;
        i2 = i7;
        i3 = 0;
        while (u70 != null) {
        }
        z = z2;
        i4 = i10;
        i5 = i11;
        i6 = i12;
        if (i3 == 0) {
        }
        this.T = j;
        this.F = z;
    }

    /* JADX WARNING: Removed duplicated region for block: B:103:0x0192  */
    /* JADX WARNING: Removed duplicated region for block: B:102:0x0190  */
    /* JADX WARNING: Removed duplicated region for block: B:124:0x01a5 A:{SYNTHETIC} */
    /* JADX WARNING: Removed duplicated region for block: B:106:0x019b  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final int N(d10 d10, int i, boolean z, int i2) {
        Throwable th;
        int i3;
        d10 d102 = d10;
        int i4 = i;
        w51 w51 = d102.G;
        boolean z2 = false;
        boolean z3;
        if (w51.j(i4)) {
            int i5 = w51.i(i4);
            Object p = w51.p(w51.b, i4);
            if (i5 == 206 && k70.p(p, qj.e)) {
                void h = w51.h(i4, 0);
                a10 a10 = null;
                xw0 xw0 = h instanceof xw0 ? (xw0) h : null;
                ww0 ww0 = xw0 != null ? xw0.a : null;
                if (ww0 instanceof a10) {
                    a10 = (a10) ww0;
                }
                if (a10 != null) {
                    ik0 ik0 = a10.e.e;
                    Object[] objArr = ik0.b;
                    long[] jArr = ik0.a;
                    int length = jArr.length - 2;
                    if (length >= 0) {
                        int i6 = 0;
                        while (true) {
                            long[] jArr2;
                            long j = jArr[i6];
                            if (((((~j) << 7) & j) & -9187201950435737472L) != -9187201950435737472L) {
                                int i7 = 8;
                                int i8 = 8 - ((~(i6 - length)) >>> 31);
                                int i9 = z2;
                                while (i9 < i8) {
                                    long j2;
                                    if ((255 & j) < 128) {
                                        d10 d103 = (d10) objArr[(i6 << 3) + i9];
                                        x51 x51 = d103.c;
                                        if (x51.f <= 0 || (x51.e[1] & 67108864) == 0) {
                                            jArr2 = jArr;
                                            z3 = z2;
                                            j2 = i7;
                                        } else {
                                            yj yjVar = d103.h;
                                            synchronized (yjVar.h) {
                                                yjVar.p();
                                                j2 = i7;
                                                hk0 hk0 = yjVar.r;
                                                yjVar.r = mc0.h();
                                                try {
                                                    yjVar.z.c0(hk0);
                                                } catch (Throwable th2) {
                                                    yjVar.r = hk0;
                                                }
                                            }
                                            ve veVar = new ve();
                                            d103.L = veVar;
                                            w51 c = d103.c.c();
                                            w51 w512;
                                            try {
                                                d103.G = c;
                                                pj pjVar = d103.M;
                                                ve veVar2 = pjVar.b;
                                                try {
                                                    pjVar.b = veVar;
                                                    d103.M(0);
                                                    pj pjVar2 = d103.M;
                                                    pjVar2.b();
                                                    jArr2 = jArr;
                                                    if (pjVar2.c) {
                                                        w512 = c;
                                                        try {
                                                            pjVar2.b.F.C(qo0.c);
                                                            if (pjVar2.c) {
                                                                pjVar2.d(false);
                                                                pjVar2.d(false);
                                                                pjVar2.b.F.C(ao0.c);
                                                                z3 = false;
                                                                pjVar2.c = false;
                                                                pjVar.b = veVar2;
                                                                w512.c();
                                                            }
                                                        } catch (Throwable th3) {
                                                            th = th3;
                                                            pjVar.b = veVar2;
                                                            throw th;
                                                        }
                                                    }
                                                    w512 = c;
                                                    z3 = false;
                                                    try {
                                                        pjVar.b = veVar2;
                                                        w512.c();
                                                    } catch (Throwable th4) {
                                                        th = th4;
                                                        w512.c();
                                                        throw th;
                                                    }
                                                } catch (Throwable th5) {
                                                    th = th5;
                                                    w512 = c;
                                                    pjVar.b = veVar2;
                                                    throw th;
                                                }
                                            } catch (Throwable th6) {
                                                th = th6;
                                                w512 = c;
                                                w512.c();
                                                throw th;
                                            }
                                        }
                                        d102.b.r(d103.h);
                                    } else {
                                        jArr2 = jArr;
                                        z3 = z2;
                                        j2 = i7;
                                    }
                                    j >>= j2;
                                    i9++;
                                    i7 = j2;
                                    z2 = z3;
                                    jArr = jArr2;
                                }
                                jArr2 = jArr;
                                z3 = z2;
                                if (i8 != i7) {
                                    break;
                                }
                            } else {
                                jArr2 = jArr;
                                z3 = z2;
                            }
                            if (i6 == length) {
                                break;
                            }
                            i6++;
                            z2 = z3;
                            jArr = jArr2;
                        }
                    }
                }
                return w51.o(i4);
            }
            i3 = 1;
            if (!w51.l(i4)) {
                return w51.o(i4);
            }
        } else {
            z3 = false;
            i3 = 1;
            if (w51.d(i4)) {
                int i10 = w51.b[(i4 * 5) + 3] + i4;
                int i11 = z3;
                for (int i12 = i4 + 1; i12 < i10; i12 += w51.b[(i12 * 5) + 3]) {
                    boolean z4;
                    boolean l = w51.l(i12);
                    if (l) {
                        d102.M.c();
                        pj pjVar3 = d102.M;
                        Object n = w51.n(i12);
                        pjVar3.c();
                        pjVar3.h.add(n);
                    }
                    if (!l) {
                        if (!z) {
                            z4 = z3;
                            i11 += d10.N(d102, i12, z4, l ? z3 : i2 + i11);
                            if (!l) {
                                d102.M.c();
                                d102.M.a();
                            }
                        }
                    }
                    z4 = true;
                    if (l) {
                    }
                    i11 += d10.N(d102, i12, z4, l ? z3 : i2 + i11);
                    if (!l) {
                    }
                }
                if (!w51.l(i4)) {
                    return i11;
                }
            } else if (!w51.l(i4)) {
                return w51.o(i4);
            }
        }
        return i3;
    }

    /* JADX WARNING: Missing block: B:44:0x00d1, code:
            if (r0.q != false) goto L_0x00d3;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final xv0 r() {
        int i;
        xv0 xv0;
        ArrayList arrayList = this.E;
        xv0 xv02 = !arrayList.isEmpty() ? (xv0) arrayList.remove(arrayList.size() - 1) : null;
        if (xv02 != null) {
            Object hiVar;
            xv02.b &= -9;
            this.g.k();
            int i2 = this.B;
            zj0 zj0 = xv02.f;
            if (zj0 != null) {
                if ((xv02.b & 16) == 0) {
                    Object[] objArr = zj0.b;
                    int[] iArr = zj0.c;
                    long[] jArr = zj0.a;
                    int length = jArr.length - 2;
                    if (length >= 0) {
                        int i3 = 0;
                        loop0:
                        while (true) {
                            long j = jArr[i3];
                            if (((((~j) << 7) & j) & -9187201950435737472L) != -9187201950435737472L) {
                                int i4 = 8 - ((~(i3 - length)) >>> 31);
                                for (int i5 = 0; i5 < i4; i5++) {
                                    if ((j & 255) < 128) {
                                        int i6 = (i3 << 3) + i5;
                                        Object obj = objArr[i6];
                                        if (iArr[i6] != i2) {
                                            hiVar = new hi(i2, 0, xv02, zj0);
                                            break loop0;
                                        }
                                    }
                                    j >>= 8;
                                }
                                if (i4 != 8) {
                                    break;
                                }
                            }
                            if (i3 == length) {
                                break;
                            }
                            i3++;
                        }
                    }
                }
            }
            hiVar = null;
            pj pjVar = this.M;
            if (hiVar != null) {
                zo0 zo0 = pjVar.b.F;
                zo0.C(zn0.c);
                dd0.w(zo0, 0, hiVar, 1, this.h);
            }
            i = xv02.b;
            if ((i & 512) != 0) {
                xv02.b = i & -513;
                zo0 zo02 = pjVar.b.F;
                zo02.C(co0.c);
                dd0.v(zo02, 0, xv02);
                i = xv02.b;
                xv02.b = i & -129;
                if ((i & 1024) != 0) {
                    xv02.b = i & -1153;
                    this.y = false;
                }
            }
        }
        if (xv02 != null) {
            i = xv02.b;
            if ((i & 16) == 0) {
                if ((i & 1) != 0) {
                }
                if (xv02.c == null) {
                    y00 b;
                    if (this.S) {
                        a61 a61 = this.I;
                        b = a61.b(a61.v);
                    } else {
                        w51 w51 = this.G;
                        b = w51.a(w51.i);
                    }
                    xv02.c = b;
                }
                xv02.b &= -5;
                xv0 = xv02;
                p(false);
                return xv0;
            }
        }
        xv0 = null;
        p(false);
        return xv0;
    }

    /* JADX WARNING: Removed duplicated region for block: B:25:0x0091  */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x0090  */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x00cd  */
    /* JADX WARNING: Removed duplicated region for block: B:28:0x009d  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void P() {
        if (this.s.isEmpty()) {
            this.l = this.G.s() + this.l;
            return;
        }
        long rotateLeft;
        boolean z;
        w51 w51 = this.G;
        int g = w51.g();
        int[] iArr = w51.b;
        int i = w51.g;
        Object p = i < w51.h ? w51.p(iArr, i) : null;
        Object f = w51.f();
        int i2 = this.m;
        nq0 nq0 = oj.a;
        if (p != null) {
            rotateLeft = Long.rotateLeft(Long.rotateLeft(this.T, 3) ^ ((long) (p instanceof Enum ? ((Enum) p).ordinal() : p.hashCode())), 3);
        } else if (f == null || g != 207 || f.equals(nq0)) {
            rotateLeft = Long.rotateLeft(Long.rotateLeft(this.T, 3) ^ ((long) g), 3) ^ ((long) i2);
        } else {
            this.T = Long.rotateLeft(Long.rotateLeft(this.T, 3) ^ ((long) f.hashCode()), 3) ^ ((long) i2);
            z = true;
            if ((iArr[(w51.g * 5) + 1] & 1073741824) != 0) {
                z = false;
            }
            V(null, z);
            H();
            w51.e();
            if (p != null) {
                if (f == null || g != 207 || f.equals(nq0)) {
                    this.T = Long.rotateRight(((long) g) ^ Long.rotateRight(this.T ^ ((long) i2), 3), 3);
                    return;
                } else {
                    this.T = Long.rotateRight(Long.rotateRight(this.T ^ ((long) i2), 3) ^ ((long) f.hashCode()), 3);
                    return;
                }
            } else if (p instanceof Enum) {
                this.T = Long.rotateRight(Long.rotateRight(this.T, 3) ^ ((long) ((Enum) p).ordinal()), 3);
                return;
            } else {
                this.T = Long.rotateRight(Long.rotateRight(this.T, 3) ^ ((long) p.hashCode()), 3);
                return;
            }
        }
        this.T = rotateLeft;
        z = true;
        if ((iArr[(w51.g * 5) + 1] & 1073741824) != 0) {
        }
        V(null, z);
        H();
        w51.e();
        if (p != null) {
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:9:0x0073  */
    /* JADX WARNING: Removed duplicated region for block: B:12:0x007c  */
    /* JADX WARNING: Removed duplicated region for block: B:18:0x00bd  */
    /* JADX WARNING: Removed duplicated region for block: B:17:0x00bc  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public d10(k9 k9Var, sj sjVar, x51 x51, kk0 kk0, ve veVar, ve veVar2, pg0 pg0, yj yjVar) {
        boolean z;
        w51 c;
        x51 x512;
        y00 d;
        a61 e;
        sl j;
        sl z2;
        this.a = k9Var;
        this.b = sjVar;
        this.c = x51;
        this.d = kk0;
        this.e = veVar;
        this.f = veVar2;
        this.g = pg0;
        this.h = yjVar;
        if (!sjVar.f()) {
            if (!sjVar.d()) {
                z = false;
                this.C = z;
                this.D = new c10(0, this);
                this.E = new ArrayList();
                c = x51.c();
                c.c();
                this.G = c;
                x512 = new x51();
                if (sjVar.f()) {
                    x512.b();
                }
                d = sjVar.d();
                if (d == true) {
                    d = new sj0();
                    x512.o = d;
                }
                this.H = x512;
                e = x512.e();
                e.e(true);
                this.I = e;
                this.M = new pj(this, veVar);
                c = this.H.c();
                d = c.a(0);
                this.N = d;
                this.O = new bw();
                this.Q = new wj(this);
                j = sjVar.j();
                z2 = z();
                if (z2 != null) {
                    z2 = st.e;
                }
                this.R = j.i(z2);
            }
        }
        z = true;
        this.C = z;
        this.D = new c10(0, this);
        this.E = new ArrayList();
        c = x51.c();
        c.c();
        this.G = c;
        x512 = new x51();
        if (sjVar.f()) {
        }
        d = sjVar.d();
        if (d == true) {
        }
        this.H = x512;
        e = x512.e();
        e.e(true);
        this.I = e;
        this.M = new pj(this, veVar);
        c = this.H.c();
        try {
            d = c.a(0);
            this.N = d;
            this.O = new bw();
            this.Q = new wj(this);
            j = sjVar.j();
            z2 = z();
            if (z2 != null) {
            }
            this.R = j.i(z2);
        } finally {
            c.c();
        }
    }

    public final void n(hk0 hk0, m00 m00) {
        String str = "Check failed";
        ArrayList arrayList = this.s;
        if (this.F) {
            FileProvider.a("Reentrant composition is not supported");
        }
        this.g.k();
        Trace.beginSection("Compose:recompose");
        try {
            long g = n61.j().g();
            this.B = (int) (g ^ (g >>> 32));
            this.v = null;
            c0(hk0);
            this.k = 0;
            this.F = true;
            try {
                a0();
                m00 D = D();
                if (!(D == m00 || m00 == null)) {
                    h0(m00);
                }
                c10 c10 = this.D;
                qk0 i = mc0.i();
                try {
                    i.b(c10);
                    qn0 qn0 = qj.a;
                    if (m00 != null) {
                        U(200, qn0);
                        vn.D(this, m00);
                        p(false);
                    } else if (!this.w || D == null || D.equals(oj.a)) {
                        P();
                    } else {
                        U(200, qn0);
                        vd1.e(2, D);
                        vn.D(this, D);
                        p(false);
                    }
                    t();
                    this.F = false;
                    arrayList.clear();
                    if (!this.I.w) {
                        FileProvider.a(str);
                    }
                    v();
                } finally {
                    i.k(i.g - 1);
                }
            } catch (Throwable th) {
                this.F = false;
                arrayList.clear();
                a();
                if (!this.I.w) {
                    FileProvider.a(str);
                }
                v();
            }
        } finally {
            Trace.endSection();
        }
    }

    public final void B(ArrayList arrayList) {
        d10 d10 = this;
        ve veVar = d10.f;
        pj pjVar = d10.M;
        ve veVar2 = pjVar.b;
        try {
            pjVar.b = veVar;
            veVar.F.C(oo0.c);
            int size = arrayList.size();
            int i = 0;
            while (i < size) {
                zp0 zp0 = (zp0) arrayList.get(i);
                gj0 gj0 = (gj0) zp0.e;
                gj0 gj02 = (gj0) zp0.f;
                gj0.getClass();
                y00 j = ac.j(null);
                x51 d = z51.d(null);
                int a = d.a(j);
                s60 s60 = new s60();
                pjVar.b();
                zo0 zo0 = pjVar.b.F;
                zo0.C(xn0.c);
                dd0.w(zo0, 0, s60, 1, j);
                if (d == d10.H) {
                    if (!d10.I.w) {
                        FileProvider.a("Check failed");
                    }
                    d10.v();
                }
                w51 c = d.c();
                try {
                    c.r(a);
                    pjVar.f = a;
                    ve veVar3 = new ve();
                    d10.G(null, null, null, ut.e, new na(d10, veVar3, c, gj0));
                    ve veVar4 = pjVar.b;
                    veVar4.getClass();
                    if (!veVar3.F.B()) {
                        zo0 zo02 = veVar4.F;
                        zo02.C(tn0.c);
                        dd0.w(zo02, 0, veVar3, 1, s60);
                    }
                    c.c();
                    pjVar.b.F.C(qo0.c);
                    i++;
                    d10 = this;
                } catch (Throwable th) {
                    c.c();
                    throw th;
                }
            }
            pjVar.b();
            pjVar.b.F.C(bo0.c);
            pjVar.f = 0;
            pjVar.b = veVar2;
        } catch (Throwable th2) {
            pjVar.b = veVar2;
            throw th2;
        }
    }

    public final void W(int i) {
        if (this.j != null) {
            S(i, 0, null, null);
            return;
        }
        if (this.r) {
            FileProvider.a("A call to createNode(), emitNode() or useNode() expected");
        }
        this.T = Long.rotateLeft(Long.rotateLeft(this.T, 3) ^ ((long) i), 3) ^ ((long) this.m);
        this.m++;
        w51 w51 = this.G;
        boolean z = this.S;
        nq0 nq0 = oj.a;
        if (z) {
            w51.k++;
            this.I.Q(i, nq0, false, nq0);
            u(false, null);
            return;
        }
        int i2;
        a61 e;
        if (w51.g() == i) {
            i2 = w51.g;
            if (i2 >= w51.h || (w51.b[(i2 * 5) + 1] & 536870912) == 0) {
                w51.u();
                u(false, null);
                return;
            }
        }
        if (w51.k <= 0) {
            i2 = w51.g;
            if (i2 != w51.h) {
                int i3 = this.k;
                I();
                this.M.e(i3, w51.s());
                vn.f(this.s, i2, w51.g);
            }
        }
        w51.k++;
        this.S = true;
        this.K = null;
        if (this.I.w) {
            e = this.H.e();
            this.I = e;
            e.M();
            this.J = false;
            this.K = null;
        }
        e = this.I;
        e.d();
        int i4 = e.t;
        e.Q(i, nq0, false, nq0);
        this.N = e.b(i4);
        u(false, null);
    }

    /* JADX WARNING: Removed duplicated region for block: B:27:0x0076  */
    /* JADX WARNING: Removed duplicated region for block: B:26:0x0073  */
    /* JADX WARNING: Removed duplicated region for block: B:30:0x0090  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final d10 X(int i) {
        W(i);
        boolean z = this.S;
        pg0 pg0 = this.g;
        ArrayList arrayList = this.E;
        yj yjVar = this.h;
        if (z) {
            xv0 xv0 = new xv0(yjVar);
            arrayList.add(xv0);
            h0(xv0);
            xv0.e = this.B;
            xv0.b &= -17;
            pg0.k();
            return this;
        }
        xv0 xv02;
        int i2;
        i = this.G.i;
        ArrayList arrayList2 = this.s;
        i = vn.s(i, arrayList2);
        u70 u70 = i >= 0 ? (u70) arrayList2.remove(i) : null;
        Object m = this.G.m();
        if (k70.p(m, oj.a)) {
            xv02 = new xv0(yjVar);
            h0(xv02);
        } else {
            m.getClass();
            xv02 = (xv0) m;
        }
        if (u70 == null) {
            i = xv02.b;
            boolean z2 = (i & 64) != 0;
            if (z2) {
                xv02.b = i & -65;
            }
            if (!z2) {
                i = 0;
                i2 = xv02.b;
                xv02.b = i == 0 ? i2 | 8 : i2 & -9;
                arrayList.add(xv02);
                xv02.e = this.B;
                xv02.b &= -17;
                pg0.k();
                i = xv02.b;
                if ((i & 256) != 0) {
                    xv02.b = (i & -257) | 512;
                    zo0 zo0 = this.M.b.F;
                    zo0.C(ro0.c);
                    dd0.v(zo0, 0, xv02);
                    if (!this.y) {
                        i = xv02.b;
                        if ((i & 128) != 0) {
                            this.y = true;
                            xv02.b = i | 1024;
                        }
                    }
                }
                return this;
            }
        }
        i = true;
        i2 = xv02.b;
        if (i == 0) {
        }
        xv02.b = i == 0 ? i2 | 8 : i2 & -9;
        arrayList.add(xv02);
        xv02.e = this.B;
        xv02.b &= -17;
        pg0.k();
        i = xv02.b;
        if ((i & 256) != 0) {
        }
        return this;
    }

    public final void h0(Object obj) {
        if (this.S) {
            a61 a61 = this.I;
            if (a61.n <= 0 || a61.i == a61.k) {
                a61.F(obj);
            } else {
                sj0 sj0 = a61.s;
                if (sj0 == null) {
                    sj0 = new sj0();
                }
                a61.s = sj0;
                int i = a61.v;
                Object b = sj0.b(i);
                if (b == null) {
                    b = new ak0();
                    sj0.h(i, b);
                }
                ((ak0) b).a(obj);
            }
            return;
        }
        w51 w51 = this.G;
        boolean z = w51.n;
        pj pjVar = this.M;
        y00 a;
        zo0 zo0;
        if (z) {
            int b2 = (w51.l - w51.b(w51.b, w51.i)) - 1;
            if (pjVar.a.G.i - pjVar.f < 0) {
                w51 w512 = this.G;
                a = w512.a(w512.i);
                zo0 = pjVar.b.F;
                zo0.C(fo0.f);
                dd0.w(zo0, 0, obj, 1, a);
                zo0.d[zo0.e - zo0.b[zo0.c - 1].a] = b2;
                return;
            }
            pjVar.d(true);
            zo0 zo02 = pjVar.b.F;
            zo02.C(fo0.g);
            dd0.v(zo02, 0, obj);
            zo02.d[zo02.e - zo02.b[zo02.c - 1].a] = b2;
            return;
        }
        a = w51.a(w51.i);
        zo0 = pjVar.b.F;
        zo0.C(sn0.c);
        dd0.w(zo0, 0, a, 1, obj);
    }

    public final void c0(hk0 hk0) {
        int i;
        hk0 hk02 = hk0;
        ArrayList arrayList = this.s;
        for (int t = zi1.t(arrayList); -1 < t; t--) {
            u70 u70 = (u70) arrayList.get(t);
            y00 y00 = u70.a.c;
            y00 j = y00 != null ? ac.j(y00) : null;
            if (j == null || !j.a()) {
                arrayList.remove(t);
            } else {
                i = u70.b;
                int i2 = j.a;
                if (i != i2) {
                    u70.b = i2;
                }
            }
        }
        Object[] objArr = hk02.b;
        Object[] objArr2 = hk02.c;
        long[] jArr = hk02.a;
        i = jArr.length - 2;
        if (i >= 0) {
            int i3 = 0;
            while (true) {
                long j2 = jArr[i3];
                if (((((~j2) << 7) & j2) & -9187201950435737472L) != -9187201950435737472L) {
                    int i4 = 8 - ((~(i3 - i)) >>> 31);
                    for (int i5 = 0; i5 < i4; i5++) {
                        if ((255 & j2) < 128) {
                            int i6 = (i3 << 3) + i5;
                            Object obj = objArr[i6];
                            Object obj2 = objArr2[i6];
                            obj.getClass();
                            xv0 xv0 = (xv0) obj;
                            y00 y002 = xv0.c;
                            if (y002 != null) {
                                int i7 = ac.j(y002).a;
                                if (obj2 == nq0.i) {
                                    obj2 = null;
                                }
                                arrayList.add(new u70(xv0, i7, obj2));
                            }
                        }
                        j2 >>= 8;
                    }
                    if (i4 != 8) {
                        break;
                    }
                }
                if (i3 == i) {
                    break;
                }
                i3++;
            }
        }
        xg.N(arrayList, vn.h);
    }

    /* JADX WARNING: Missing block: B:26:0x006e, code:
            if (r1 == null) goto L_0x0070;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final qr0 l() {
        qr0 qr0 = this.K;
        if (qr0 != null) {
            return qr0;
        }
        Object q;
        int i = this.G.i;
        boolean z = this.S;
        qn0 qn0 = qj.c;
        if (z && this.J) {
            int i2 = this.I.v;
            while (i2 > 0) {
                if (this.I.s(i2) == 202 && k70.p(this.I.t(i2), qn0)) {
                    q = this.I.q(i2);
                    q.getClass();
                    qr0 = (qr0) q;
                    this.K = qr0;
                    return qr0;
                }
                a61 a61 = this.I;
                i2 = a61.E(a61.b, i2);
            }
        }
        if (this.G.c > 0) {
            while (i > 0) {
                if (this.G.i(i) == 202) {
                    w51 w51 = this.G;
                    if (k70.p(w51.p(w51.b, i), qn0)) {
                        qr0 qr02;
                        sj0 sj0 = this.v;
                        if (sj0 != null) {
                            qr02 = (qr0) sj0.b(i);
                        }
                        w51 = this.G;
                        q = w51.b(w51.b, i);
                        q.getClass();
                        qr02 = (qr0) q;
                        this.K = qr02;
                        return qr02;
                    }
                }
                i = this.G.q(i);
            }
        }
        qr0 = this.u;
        this.K = qr0;
        return qr0;
    }

    /* JADX WARNING: Removed duplicated region for block: B:50:0x007a A:{SYNTHETIC} */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x0075  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void K(int i, int i2, int i3) {
        w51 w51 = this.G;
        if (i != i2) {
            if (i != i3) {
                if (i2 != i3) {
                    if (w51.q(i) == i2) {
                        i3 = i2;
                    } else if (w51.q(i2) != i) {
                        if (w51.q(i) == w51.q(i2)) {
                            i3 = w51.q(i);
                        } else {
                            int i4 = 0;
                            int i5 = i;
                            int i6 = 0;
                            while (i5 > 0 && i5 != i3) {
                                i5 = w51.q(i5);
                                i6++;
                            }
                            i5 = i2;
                            int i7 = 0;
                            while (i5 > 0 && i5 != i3) {
                                i5 = w51.q(i5);
                                i7++;
                            }
                            i3 = i6 - i7;
                            int i8 = i;
                            for (i5 = 0; i5 < i3; i5++) {
                                i8 = w51.q(i8);
                            }
                            i7 -= i6;
                            i3 = i2;
                            while (i4 < i7) {
                                i3 = w51.q(i3);
                                i4++;
                            }
                            i3 = i8;
                            for (i4 = i3; i3 != i4; i4 = w51.q(i4)) {
                                i3 = w51.q(i3);
                            }
                        }
                    }
                }
            }
            while (i > 0 && i != i3) {
                if (!w51.l(i)) {
                    this.M.a();
                }
                i = w51.q(i);
            }
            o(i2, i3);
        }
        i3 = i;
        while (i > 0) {
            if (!w51.l(i)) {
            }
            i = w51.q(i);
        }
        o(i2, i3);
    }

    public final void C(qr0 qr0, Object obj) {
        S(126665345, 0, null, null);
        D();
        h0(obj);
        long j = this.T;
        try {
            this.T = 126665345;
            if (this.S) {
                a61.z(this.I);
            }
            boolean z = (this.S || k70.p(this.G.f(), qr0)) ? false : true;
            if (z) {
                J(qr0);
            }
            S(202, 0, qj.c, qr0);
            this.K = null;
            boolean z2 = this.w;
            this.w = z;
            vn.D(this, new pi(-59194059, true, new hc(3, obj)));
            this.w = z2;
            p(false);
            this.K = null;
            this.T = j;
            p(false);
        } catch (Throwable th) {
            p(false);
            this.K = null;
            this.T = j;
            p(false);
        }
    }

    public final ej m() {
        if (!this.b.k()) {
            return null;
        }
        Collection collection;
        qe0 h90 = new h90(10);
        a61 a61 = this.I;
        h90.addAll(wl1.p(a61, null, a61.t, null));
        w51 w51 = this.G;
        boolean z = w51.f;
        int[] iArr = w51.b;
        if (z || w51.c == 0) {
            collection = ut.e;
        } else {
            tv0 tv0 = new tv0(w51);
            int i = w51.i;
            Object valueOf = Integer.valueOf(w51.l - w51.b(iArr, i));
            while (i >= 0) {
                tv0.f(w51.i(i), w51.k(i) ? w51.p(iArr, i) : oj.a, w51.a.g(i), valueOf);
                valueOf = w51.a(i);
                i = w51.q(i);
            }
            collection = (ArrayList) tv0.a;
        }
        h90.addAll(collection);
        h90.addAll(E());
        return new ej(zi1.o(h90), this.C);
    }

    public final void a0() {
        this.m = 0;
        this.G = this.c.c();
        S(100, 0, null, null);
        sj sjVar = this.b;
        sjVar.t();
        qr0 i = sjVar.i();
        this.x.c(this.w);
        this.w = ((AutofillManager$AutofillCallback) this);
        this.K = null;
        if (!this.q) {
            this.q = sjVar.e();
        }
        if (!this.C) {
            this.C = sjVar.f();
        }
        if (this.C) {
            k81 k81 = xj.a;
            k81.getClass();
            i = i.b(k81, new l81(z()));
        }
        this.u = i;
        Set set = (Set) gh0.L(i, h60.a);
        if (set != null) {
            set.add(w());
            sjVar.o(set);
        }
        long g = sjVar.g();
        S((int) (g ^ (g >>> 32)), 0, null, null);
    }

    public final void I() {
        M(this.G.g);
        pj pjVar = this.M;
        pjVar.d(false);
        w60 w60 = pjVar.d;
        d10 d10 = pjVar.a;
        w51 w51 = d10.G;
        if (w51.c > 0) {
            int i = w51.i;
            if (w60.a(-2) != i) {
                if (!pjVar.c && pjVar.e) {
                    pjVar.d(false);
                    pjVar.b.F.C(eo0.c);
                    pjVar.c = true;
                }
                if (i > 0) {
                    y00 a = w51.a(i);
                    w60.c(i);
                    pjVar.d(false);
                    zo0 zo0 = pjVar.b.F;
                    zo0.C(do0.c);
                    dd0.v(zo0, 0, a);
                    pjVar.c = true;
                }
            }
        }
        pjVar.b.F.C(mo0.c);
        int i2 = pjVar.f;
        w51 w512 = d10.G;
        pjVar.f = w512.b[(w512.g * 5) + 3] + i2;
    }

    public final boolean b0(xv0 xv0, Object obj) {
        y00 y00 = xv0.c;
        if (y00 != null) {
            int a = this.G.a.a(ac.j(y00));
            if (this.F && a >= this.G.g) {
                ArrayList arrayList = this.s;
                int s = vn.s(a, arrayList);
                if (s < 0) {
                    s = -(s + 1);
                    if (!(obj instanceof sp)) {
                        obj = null;
                    }
                    arrayList.add(s, new u70(xv0, a, obj));
                    return true;
                }
                u70 u70 = (u70) arrayList.get(s);
                if (obj instanceof sp) {
                    Object obj2 = u70.c;
                    if (obj2 == null) {
                        u70.c = obj;
                        return true;
                    } else if (obj2 instanceof ik0) {
                        ((ik0) obj2).a(obj);
                        return true;
                    } else {
                        ik0 ik0 = o01.a;
                        ik0 = new h90(2);
                        ik0.k(obj2);
                        ik0.k(obj);
                        u70.c = ik0;
                        return true;
                    }
                }
                u70.c = null;
                return true;
            }
        }
        return false;
    }

    public final void k(xz xzVar) {
        if (!this.r) {
            FileProvider.a("A call to createNode(), emitNode() or useNode() expected was not expected");
        }
        this.r = false;
        if (!this.S) {
            FileProvider.a("createNode() can only be called when inserting");
        }
        w60 w60 = this.n;
        int i = w60.a[w60.b - 1];
        a61 a61 = this.I;
        y00 b = a61.b(a61.v);
        this.l++;
        bw bwVar = this.O;
        zo0 zo0 = bwVar.b;
        zo0.C(fo0.d);
        dd0.v(zo0, 0, xzVar);
        zo0.d[zo0.e - zo0.b[zo0.c - 1].a] = i;
        dd0.v(zo0, 1, b);
        zo0 zo02 = bwVar.c;
        zo02.C(fo0.e);
        zo02.d[zo02.e - zo02.b[zo02.c - 1].a] = i;
        dd0.v(zo02, 0, b);
    }

    /* JADX WARNING: Missing block: B:26:0x0053, code:
            if (r10 != null) goto L_0x0059;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final Object G(yj yjVar, yj yjVar2, Integer num, List list, xz xzVar) {
        boolean z = this.F;
        int i = this.k;
        try {
            Object a;
            this.F = true;
            this.k = 0;
            int size = list.size();
            for (int i2 = 0; i2 < size; i2++) {
                zp0 zp0 = (zp0) list.get(i2);
                xv0 xv0 = (xv0) zp0.e;
                Object obj = zp0.f;
                if (obj != null) {
                    b0(xv0, obj);
                } else {
                    b0(xv0, null);
                }
            }
            if (yjVar != null) {
                int intValue = num != null ? num.intValue() : -1;
                if (yjVar2 == null || yjVar2 == yjVar || intValue < 0) {
                    a = xzVar.a();
                } else {
                    yjVar.v = yjVar2;
                    yjVar.w = intValue;
                    try {
                        a = xzVar.a();
                    } finally {
                        yjVar.v = null;
                        yjVar.w = 0;
                    }
                }
            }
            a = xzVar.a();
            this.F = z;
            this.k = i;
            return a;
        } catch (Throwable th) {
            this.F = z;
            this.k = i;
        }
    }

    public final List E() {
        sj sjVar = this.b;
        rj h = sjVar.h();
        yj yjVar = fu0.M(h) ? (yj) h : null;
        if (yjVar != null) {
            x51 x51 = yjVar.j;
            w51 c = z51.d(x51).c();
            try {
                int i = 0;
                Integer w = wl1.w(c, sjVar, i, c.c);
                if (w != null) {
                    w51 c2 = z51.d(x51).c();
                    try {
                        Collection O = wl1.O(c2, w.intValue(), Integer.valueOf(i));
                        return tg.Z(O, yjVar.z.E());
                    } finally {
                        c2.c();
                    }
                }
            } finally {
                c.c();
            }
        }
        return ut.e;
    }

    public final boolean O(int i, boolean z) {
        if ((i & 1) == 0 && (this.S || this.y)) {
            l51 l51 = this.P;
            if (l51 != null) {
                xv0 x = x();
                if (x != null) {
                    if (l51.a()) {
                        i = x.b;
                        if ((i & 512) != 0) {
                            return true;
                        }
                        int i2 = i | 1;
                        x.b = i2;
                        x.b = (this.y ? i | 129 : i2 & -129) | 256;
                        zo0 zo0 = this.M.b.F;
                        zo0.C(lo0.c);
                        dd0.v(zo0, 0, x);
                        this.b.q(x);
                        return false;
                    }
                }
            }
        } else if (!z) {
            if (A()) {
                return false;
            }
        }
        return true;
    }

    public final void t() {
        boolean z = false;
        p(false);
        this.b.c();
        p(false);
        pj pjVar = this.M;
        if (pjVar.c) {
            pjVar.d(false);
            pjVar.d(false);
            pjVar.b.F.C(ao0.c);
            pjVar.c = false;
        }
        pjVar.b();
        if (pjVar.d.b != 0) {
            FileProvider.a("Missed recording an endGroup()");
        }
        if (!this.i.isEmpty()) {
            FileProvider.a("Start/end imbalance");
        }
        i();
        this.G.c();
        if (this.x.b() != 0) {
            z = true;
        }
        this.w = z;
    }

    public final void a() {
        i();
        this.i.clear();
        this.n.b = 0;
        this.t.b = 0;
        this.x.b = 0;
        this.v = null;
        bw bwVar = this.O;
        bwVar.c.z();
        bwVar.b.z();
        this.T = 0;
        this.A = 0;
        this.r = false;
        this.S = false;
        this.y = false;
        this.F = false;
        this.z = -1;
        w51 w51 = this.G;
        if (!w51.f) {
            w51.c();
        }
        if (!this.I.w) {
            v();
        }
    }

    public final void e0(int i, int i2) {
        int i0 = i0(i);
        if (i0 != i2) {
            i2 -= i0;
            ArrayList arrayList = this.i;
            int size = arrayList.size() - 1;
            while (i != -1) {
                int i02 = i0(i) + i2;
                d0(i, i02);
                for (int i3 = size; -1 < i3; i3--) {
                    g10 g10 = (g10) arrayList.get(i3);
                    if (g10 != null && g10.a(i, i02)) {
                        size = i3 - 1;
                        break;
                    }
                }
                w51 w51 = this.G;
                if (i < 0) {
                    i = w51.i;
                } else if (!w51.l(i)) {
                    i = this.G.q(i);
                } else {
                    return;
                }
            }
        }
    }

    public final void V(Object obj, boolean z) {
        if (z) {
            w51 w51 = this.G;
            if (w51.k <= 0) {
                if ((w51.b[(w51.g * 5) + 1] & 1073741824) == 0) {
                    FileProvider.a("Expected a node group");
                }
                w51.u();
            }
            return;
        }
        if (!(obj == null || this.G.f() == obj)) {
            pj pjVar = this.M;
            pjVar.getClass();
            pjVar.d(false);
            zo0 zo0 = pjVar.b.F;
            zo0.C(to0.c);
            dd0.v(zo0, 0, obj);
        }
        this.G.u();
    }

    public final void j0() {
        if (!this.r) {
            FileProvider.a("A call to createNode(), emitNode() or useNode() expected was not expected");
        }
        this.r = false;
        if (this.S) {
            FileProvider.a("useNode() called while inserting");
        }
        w51 w51 = this.G;
        Object n = w51.n(w51.i);
        pj pjVar = this.M;
        pjVar.c();
        pjVar.h.add(n);
        if (this.y && (n instanceof wi)) {
            pjVar.b();
            pjVar.b.F.C(wo0.c);
        }
    }

    public final void b(m00 m00, Object obj) {
        zo0 zo0;
        if (this.S) {
            zo0 = this.O.b;
            zo0.C(uo0.c);
            dd0.v(zo0, 0, obj);
            m00.getClass();
            vd1.e(2, m00);
            dd0.v(zo0, 1, m00);
            return;
        }
        pj pjVar = this.M;
        pjVar.b();
        zo0 = pjVar.b.F;
        zo0.C(uo0.c);
        m00.getClass();
        vd1.e(2, m00);
        dd0.w(zo0, 0, obj, 1, m00);
    }

    public final void i() {
        this.j = null;
        this.k = 0;
        this.l = 0;
        this.T = 0;
        this.r = false;
        pj pjVar = this.M;
        pjVar.c = false;
        pjVar.d.b = 0;
        pjVar.f = 0;
        pjVar.e = true;
        pjVar.g = 0;
        pjVar.h.clear();
        pjVar.i = -1;
        pjVar.j = -1;
        pjVar.k = -1;
        pjVar.l = 0;
        this.E.clear();
        this.o = null;
        this.p = null;
    }

    public final int i0(int i) {
        int c;
        if (i < 0) {
            qj0 qj0 = this.p;
            if (qj0 == null || qj0.c(i) < 0) {
                return 0;
            }
            c = qj0.c(i);
            if (c >= 0) {
                return qj0.c[c];
            }
            throw new dl1(fu0.E("Cannot find value for key ", i));
        }
        int[] iArr = this.o;
        if (iArr != null) {
            c = iArr[i];
            if (c >= 0) {
                return c;
            }
        }
        return this.G.o(i);
    }

    public final void R() {
        if (this.l != 0) {
            FileProvider.a("No nodes can be emitted before calling skipAndEndGroup");
        }
        if (!this.S) {
            xv0 x = x();
            if (x != null) {
                int i = x.b;
                if ((i & 128) == 0) {
                    x.b = i | 16;
                }
            }
            if (this.s.isEmpty()) {
                Q();
                return;
            }
            H();
        }
    }

    public final void Y(Object obj) {
        if (!this.S && this.G.g() == 207 && !k70.p(this.G.f(), obj) && this.z < 0) {
            this.z = this.G.g;
            this.y = true;
        }
        S(207, 0, null, obj);
    }

    public final void g0(Object obj) {
        if (obj instanceof ww0) {
            xw0 xw0 = new xw0((ww0) obj, this.m - 1);
            if (this.S) {
                zo0 zo0 = this.M.b.F;
                zo0.C(ko0.c);
                dd0.v(zo0, 0, xw0);
            }
            this.d.add(obj);
            obj = xw0;
        }
        h0(obj);
    }

    public final void d0(int i, int i2) {
        if (i0(i) != i2) {
            if (i < 0) {
                vd1 vd1 = this.p;
                if (vd1 == null) {
                    vd1 = new qj0();
                    this.p = vd1;
                }
                vd1.f(i, i2);
                return;
            }
            int[] iArr = this.o;
            if (iArr == null) {
                int i3 = this.G.c;
                int[] iArr2 = new int[i3];
                Arrays.fill(iArr2, 0, i3, -1);
                this.o = iArr2;
                iArr = iArr2;
            }
            iArr[i] = i2;
        }
    }

    public final Object L() {
        boolean z = this.S;
        nq0 nq0 = oj.a;
        if (!z) {
            Object m = this.G.m();
            if (!this.y || (m instanceof tx0)) {
                return m instanceof xw0 ? ((xw0) m).a : m;
            }
        } else if (this.r) {
            FileProvider.a("A call to createNode(), emitNode() or useNode() expected");
            return nq0;
        }
        return nq0;
    }

    public final void M(int i) {
        boolean l = this.G.l(i);
        pj pjVar = this.M;
        if (l) {
            pjVar.c();
            Object n = this.G.n(i);
            pjVar.c();
            pjVar.h.add(n);
        }
        d10.N(this, i, l, 0);
        pjVar.c();
        if (l) {
            pjVar.a();
        }
    }

    public final void v() {
        x51 x51 = new x51();
        if (this.C) {
            x51.b();
        }
        if (this.b.d()) {
            x51.o = new sj0();
        }
        this.H = x51;
        a61 e = x51.e();
        e.e(true);
        this.I = e;
    }

    public final qr0 f0(qr0 qr0, qr0 qr02) {
        qr0.getClass();
        pr0 pr0 = new pr0(qr0);
        pr0.putAll(qr02);
        qr0 = pr0.b();
        U(204, qj.d);
        D();
        h0(qr0);
        D();
        h0(qr02);
        p(false);
        return qr0;
    }

    public final void o(int i, int i2) {
        if (i > 0 && i != i2) {
            o(this.G.q(i), i2);
            if (this.G.l(i)) {
                Object n = this.G.n(i);
                pj pjVar = this.M;
                pjVar.c();
                pjVar.h.add(n);
            }
        }
    }

    public final void u(boolean z, g10 g10) {
        this.i.add(this.j);
        this.j = g10;
        int i = this.l;
        w60 w60 = this.n;
        w60.c(i);
        w60.c(this.m);
        w60.c(this.k);
        if (z) {
            this.k = 0;
        }
        this.l = 0;
        this.m = 0;
    }

    public final int F(int i) {
        int q = this.G.q(i) + 1;
        int i2 = 0;
        while (q < i) {
            if (!this.G.k(q)) {
                i2++;
            }
            q += this.G.b[(q * 5) + 3];
        }
        return i2;
    }

    public final Object D() {
        boolean z = this.S;
        nq0 nq0 = oj.a;
        if (!z) {
            Object m = this.G.m();
            if (!this.y || (m instanceof tx0)) {
                return m;
            }
        } else if (this.r) {
            FileProvider.a("A call to createNode(), emitNode() or useNode() expected");
            return nq0;
        }
        return nq0;
    }

    public final boolean A() {
        if (!(this.S || this.y || this.w)) {
            xv0 x = x();
            if (x != null) {
                if ((x.b & 8) == 0) {
                    return true;
                }
            }
        }
        return false;
    }

    public final boolean c(float f) {
        Object D = D();
        if ((D instanceof Float) && f == ((Number) D).floatValue()) {
            return false;
        }
        h0(Float.valueOf(f));
        return true;
    }

    public final boolean e(long j) {
        Object D = D();
        if ((D instanceof Long) && j == ((Number) D).longValue()) {
            return false;
        }
        h0(Long.valueOf(j));
        return true;
    }

    public final boolean d(int i) {
        Object D = D();
        if ((D instanceof Integer) && i == ((Number) D).intValue()) {
            return false;
        }
        h0(Integer.valueOf(i));
        return true;
    }

    public final boolean g(boolean z) {
        Object D = D();
        if ((D instanceof Boolean) && z == ((Boolean) D).booleanValue()) {
            return false;
        }
        h0(Boolean.valueOf(z));
        return true;
    }

    public final xv0 x() {
        if (this.A == 0) {
            ArrayList arrayList = this.E;
            if (!arrayList.isEmpty()) {
                return (xv0) arrayList.get(arrayList.size() - 1);
            }
        }
        return null;
    }

    public final boolean y() {
        if (A() && !this.w) {
            xv0 x = x();
            if (x == null || (x.b & 4) == 0) {
                return false;
            }
        }
        return true;
    }

    public final void Q() {
        w51 w51 = this.G;
        int i = w51.i;
        this.l = i >= 0 ? w51.b[(i * 5) + 1] & 67108863 : 0;
        w51.t();
    }

    public final void s() {
        if (this.F || this.z != 100) {
            FileProvider.a("Cannot disable reuse from root if it was caused by other groups");
        }
        this.z = -1;
        this.y = false;
    }

    public final void q() {
        p(false);
        xv0 x = x();
        if (x != null) {
            int i = x.b;
            if ((i & 1) != 0) {
                x.b = i | 2;
            }
        }
    }

    public final void J(qr0 qr0) {
        sj0 sj0 = this.v;
        if (sj0 == null) {
            sj0 = new sj0();
            this.v = sj0;
        }
        sj0.h(this.G.g, qr0);
    }

    public final AutofillManager$AutofillCallback f(Object obj) {
        if (k70.p(D(), obj)) {
            return null;
        }
        h0(obj);
        return 1;
    }

    public final uj w() {
        uj ujVar = this.U;
        if (ujVar != null) {
            return ujVar;
        }
        e10 e10 = new e10(this.h);
        this.U = e10;
        return e10;
    }

    public final AutofillValue h(Object obj) {
        if (D() == obj) {
            return null;
        }
        h0(obj);
        return 1;
    }

    public final wj z() {
        return this.b.k() ? this.Q : null;
    }

    public final void Z() {
        S(125, 2, null, null);
        this.r = true;
    }

    public final Object j(lv0 lv0) {
        return gh0.L(l(), lv0);
    }

    public final void T() {
        S(-127, 0, null, null);
    }

    public final void U(int i, qn0 qn0) {
        S(i, 0, qn0, null);
    }
}