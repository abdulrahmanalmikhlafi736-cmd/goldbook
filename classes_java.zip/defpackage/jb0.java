package defpackage;

import android.content.Context;
import android.graphics.Path.FillType;
import android.graphics.Typeface;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.text.Spannable;
import android.view.View;
import android.view.autofill.AutofillManager$AutofillCallback;
import android.view.autofill.AutofillValue;
import android.window.BackEvent;
import androidx.core.content.FileProvider;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.MappedByteBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: jb0 */
public abstract class jb0 {
    public static y30 a;

    public static List o(a61 a61, int i, a61 a612, boolean z, boolean z2, boolean z3) {
        int[] iArr;
        a91 h90;
        boolean z4;
        a61 a613 = a61;
        int i2 = i;
        a61 a614 = a612;
        int u = a61.u(i);
        int i3 = i2 + u;
        int f = a61.f(i);
        int f2 = a613.f(i3);
        int i4 = f2 - f;
        int i5 = (i2 < 0 || (a613.b[(a61.r(i) * 5) + 1] & 201326592) == 0) ? 0 : 1;
        a614.w(u);
        a614.x(i4, a614.t);
        if (a613.g < i3) {
            a613.B(i3);
        }
        if (a613.k < f2) {
            a613.C(f2, i3);
        }
        int[] iArr2 = a614.b;
        int i6 = a614.t;
        int i7 = i6 * 5;
        ba.W(a613.b, iArr2, i7, i2 * 5, i3 * 5);
        Object[] objArr = a614.c;
        int i8 = a614.i;
        System.arraycopy(a613.c, f, objArr, i8, i4);
        int i9 = a614.v;
        iArr2[i7 + 2] = i9;
        int i10 = i6 - i2;
        int i11 = i6 + u;
        int g = i8 - a614.g(iArr2, i6);
        int i12 = 1;
        int i13 = a614.m;
        int i14 = a614.l;
        int length = objArr.length;
        int i15 = i5;
        i5 = i13;
        i13 = i7;
        i7 = i6;
        while (i7 < i11) {
            int i16;
            if (i7 != i6) {
                i16 = (i7 * 5) + 2;
                iArr2[i16] = iArr2[i16] + i10;
            }
            iArr = iArr2;
            f2 = a614.g(iArr2, i7) + g;
            if (i5 < i7) {
                i16 = i6;
                i6 = 0;
            } else {
                i16 = i6;
                i6 = a614.k;
            }
            iArr[(i7 * 5) + 4] = a61.i(f2, i6, i14, length);
            if (i7 == i5) {
                i5++;
            }
            i7++;
            i6 = i16;
            iArr2 = iArr;
        }
        iArr = iArr2;
        a614.m = i5;
        f2 = z51.a(a613.d, i2, a613.p());
        i3 = z51.a(a613.d, i3, a613.p());
        if (f2 < i3) {
            ArrayList arrayList = a613.d;
            h90 = new h90(i3 - f2);
            for (i6 = f2; i6 < i3; i6++) {
                y00 y00 = (y00) arrayList.get(i6);
                y00.a += i10;
                h90.add(y00);
            }
            a614.d.addAll(z51.a(a614.d, a614.t, a614.p()), h90);
            arrayList.subList(f2, i3).clear();
        } else {
            h90 = ut.e;
        }
        if (!h90.isEmpty()) {
            HashMap hashMap = a613.e;
            HashMap hashMap2 = a614.e;
            if (!(hashMap == null || hashMap2 == null)) {
                for (i14 = 0; i14 < h90.size(); i14++) {
                    f10 f10 = (f10) hashMap.get((y00) h90.get(i14));
                }
            }
        }
        i3 = a614.v;
        a614.O(i9);
        i3 = a613.E(a613.b, i2);
        if (!z3) {
            z4 = false;
        } else if (z) {
            int i17 = i3 >= 0 ? i12 : 0;
            if (i17 != 0) {
                a613.P();
                a613.a(i3 - a613.t);
                a613.P();
            }
            a613.a(i2 - a613.t);
            boolean H = a613.H();
            if (i17 != 0) {
                a613.M();
                a613.j();
                a613.M();
                a613.j();
            }
            z4 = H;
        } else {
            boolean I = a613.I(i2, u);
            a613.J(f, i4, i2 - 1);
            z4 = I;
        }
        if (z4) {
            FileProvider.a("Unexpectedly removed anchors");
        }
        int i18 = a614.o;
        i2 = iArr[i13 + 1];
        a614.o = i18 + ((1073741824 & i2) != 0 ? i12 : i2 & 67108863);
        if (z2) {
            a614.t = i11;
            a614.i = i8 + i4;
        }
        if (i15 != 0) {
            a614.T(i9);
        }
        return h90;
    }

    public static final void f(s20 s20, xf1 xf1) {
        List list = xf1.n;
        int size = list.size();
        for (int i = 0; i < size; i++) {
            zf1 zf1 = (zf1) list.get(i);
            if (zf1 instanceof bg1) {
                pq0 pq0 = new pq0();
                bg1 bg1 = (bg1) zf1;
                pq0.d = bg1.f;
                pq0.n = true;
                pq0.c();
                pq0.s.a.setFillType(bg1.g == 1 ? FillType.EVEN_ODD : FillType.WINDING);
                pq0.c();
                pq0.c();
                pq0.b = bg1.h;
                pq0.c();
                pq0.c = bg1.i;
                pq0.c();
                pq0.g = bg1.j;
                pq0.c();
                pq0.e = bg1.k;
                pq0.c();
                pq0.f = bg1.l;
                pq0.o = true;
                pq0.c();
                pq0.h = bg1.m;
                pq0.o = true;
                pq0.c();
                pq0.i = bg1.n;
                pq0.o = true;
                pq0.c();
                pq0.j = bg1.o;
                pq0.o = true;
                pq0.c();
                pq0.k = bg1.p;
                pq0.p = true;
                pq0.c();
                pq0.l = bg1.q;
                pq0.p = true;
                pq0.c();
                pq0.m = bg1.r;
                pq0.p = true;
                pq0.c();
                s20.e(i, pq0);
            } else if (zf1 instanceof xf1) {
                s20 s202 = new s20();
                xf1 xf12 = (xf1) zf1;
                s202.k = xf12.e;
                s202.c();
                s202.l = xf12.f;
                s202.s = true;
                s202.c();
                s202.o = xf12.i;
                s202.s = true;
                s202.c();
                s202.p = xf12.j;
                s202.s = true;
                s202.c();
                s202.q = xf12.k;
                s202.s = true;
                s202.c();
                s202.r = xf12.l;
                s202.s = true;
                s202.c();
                s202.m = xf12.g;
                s202.s = true;
                s202.c();
                s202.n = xf12.h;
                s202.s = true;
                s202.c();
                s202.f = xf12.m;
                s202.g = true;
                s202.c();
                jb0.f(s202, xf12);
                s20.e(i, s202);
            }
        }
    }

    public static final long y(String str, long j, long j2, long j3) {
        String property;
        String str2 = str;
        long j4 = j2;
        long j5 = j3;
        int i = ga1.a;
        Number number = null;
        try {
            property = System.getProperty(str2);
        } catch (SecurityException unused) {
            property = null;
        }
        if (property == null) {
            return j;
        }
        int i2 = 10;
        a5.l(10);
        int length = property.length();
        if (length != 0) {
            int i3;
            int i4 = 0;
            char charAt = property.charAt(0);
            long j6 = -9223372036854775807L;
            if (k70.y(charAt, 48) < 0) {
                i3 = 1;
                if (length != 1) {
                    if (charAt == '+') {
                        i3 = 0;
                        i4 = 1;
                    } else if (charAt == '-') {
                        j6 = Long.MIN_VALUE;
                        i4 = 1;
                    }
                }
            } else {
                i3 = 0;
            }
            long j7 = 0;
            long j8 = -256204778801521550L;
            while (i4 < length) {
                int digit = Character.digit(property.charAt(i4), i2);
                if (digit < 0) {
                    break;
                }
                if (j7 < j8) {
                    if (j8 != -256204778801521550L) {
                        break;
                    }
                    j8 = j6 / 10;
                    if (j7 < j8) {
                        break;
                    }
                }
                j7 *= 10;
                int i5 = length;
                long j9 = (long) digit;
                if (j7 < j6 + j9) {
                    break;
                }
                j7 -= j9;
                i4++;
                length = i5;
                i2 = 10;
            }
            number = i3 != 0 ? Long.valueOf(j7) : Long.valueOf(-j7);
        }
        String str3 = "System property '";
        if (number != null) {
            long longValue = number.longValue();
            if (j4 <= longValue && longValue <= j5) {
                return longValue;
            }
            StringBuilder dl1 = new dl1(str3);
            dl1.append(str2);
            dl1.append("' should be in range ");
            dl1.append(j4);
            dl1.append("..");
            dl1.append(j5);
            dl1.append(", but is '");
            dl1.append(longValue);
            dl1.append('\'');
            throw new dl1(dl1.toString().toString());
        }
        StringBuilder dl12 = new dl1(str3);
        dl12.append(str2);
        dl12.append("' has unrecognized value '");
        dl12.append(property);
        dl12.append('\'');
        throw new dl1(dl12.toString().toString());
    }

    public static bi0 q(MappedByteBuffer mappedByteBuffer) {
        ByteBuffer duplicate = mappedByteBuffer.duplicate();
        duplicate.order(ByteOrder.BIG_ENDIAN);
        duplicate.position(duplicate.position() + 4);
        int i = duplicate.getShort() & 65535;
        String str = "Cannot read metadata.";
        if (i <= 100) {
            long j;
            duplicate.position(duplicate.position() + 6);
            int i2 = 0;
            for (int i3 = 0; i3 < i; i3++) {
                int i4 = duplicate.getInt();
                duplicate.position(duplicate.position() + 4);
                j = ((long) duplicate.getInt()) & 4294967295L;
                duplicate.position(duplicate.position() + 4);
                if (1835365473 == i4) {
                    break;
                }
            }
            j = -1;
            if (j != -1) {
                duplicate.position(duplicate.position() + ((int) (j - ((long) duplicate.position()))));
                duplicate.position(duplicate.position() + 12);
                long j2 = ((long) duplicate.getInt()) & 4294967295L;
                while (((long) i2) < j2) {
                    i = duplicate.getInt();
                    long j3 = ((long) duplicate.getInt()) & 4294967295L;
                    duplicate.getInt();
                    if (1164798569 != i) {
                        if (1701669481 != i) {
                            i2++;
                        }
                    }
                    duplicate.position((int) (j3 + j));
                    bi0 sg0 = new sg0();
                    duplicate.order(ByteOrder.LITTLE_ENDIAN);
                    int position = duplicate.position() + duplicate.getInt(duplicate.position());
                    sg0.h = duplicate;
                    sg0.e = position;
                    position -= duplicate.getInt(position);
                    sg0.f = position;
                    sg0.g = ((ByteBuffer) sg0.h).getShort(position);
                    return sg0;
                }
            }
            throw new dl1(str);
        }
        throw new dl1(str);
    }

    public static final ag1 s(y30 y30, d10 d10) {
        jp jpVar = (jp) d10.j(fk.h);
        boolean e = d10.e((((long) Float.floatToRawIntBits(jpVar.a())) & 4294967295L) | (((long) Float.floatToRawIntBits((float) y30.j)) << 32));
        Object L = d10.L();
        if (e || L == oj.a) {
            s20 s20 = new s20();
            jb0.f(s20, y30.f);
            float f = y30.b;
            float f2 = y30.c;
            long floatToRawIntBits = (((long) Float.floatToRawIntBits(jpVar.q(f))) << 32) | (((long) Float.floatToRawIntBits(jpVar.q(f2))) & 4294967295L);
            float f3 = y30.d;
            float f4 = y30.e;
            if (Float.isNaN(f3)) {
                f3 = Float.intBitsToFloat((int) (floatToRawIntBits >> 32));
            }
            if (Float.isNaN(f4)) {
                f4 = Float.intBitsToFloat((int) (floatToRawIntBits & 4294967295L));
            }
            long floatToRawIntBits2 = (((long) Float.floatToRawIntBits(f3)) << 32) | (4294967295L & ((long) Float.floatToRawIntBits(f4)));
            ag1 ag1 = new ag1(s20);
            String str = y30.a;
            long j = y30.g;
            Object p61 = j != 16 ? new p61(y30.h, j) : null;
            boolean z = y30.i;
            ag1.e.setValue(new ad(floatToRawIntBits));
            ag1.f.setValue(Boolean.valueOf(z));
            wf1 wf1 = ag1.g;
            wf1.g.setValue(p61);
            wf1.i.setValue(new ad(floatToRawIntBits2));
            wf1.c = str;
            d10.g0(ag1);
            L = ag1;
        }
        return (ag1) L;
    }

    public static final void b(hc0 hc0, Object obj, int i, Object obj2, d10 d10, int i2) {
        d10.X(1439843069);
        int i3 = ((((((AutofillManager$AutofillCallback) d10) != null ? 4 : 2) | i2) | (((AutofillManager$AutofillCallback) d10) != null ? 32 : 16)) | (d10.d(i) ? 256 : 128)) | (((AutofillManager$AutofillCallback) d10) != null ? 2048 : 1024);
        if (d10.O(i3 & 1, (i3 & 1171) != 1170)) {
            ((jz0) obj).b(obj2, vd1.A(980966366, new ib0(i, hc0, obj2), d10), d10, 48);
        } else {
            d10.R();
        }
        xv0 r = d10.r();
        if (r != null) {
            r.d = new nc(hc0, obj, i, obj2, i2);
        }
    }

    public static qz0 g(Bundle bundle, Bundle bundle2) {
        if (bundle == null) {
            bundle = bundle2;
        }
        qz0 obj;
        LinkedHashMap linkedHashMap;
        if (bundle == null) {
            obj = new Object();
            linkedHashMap = new LinkedHashMap();
            obj.a = new pa(vt.e);
            return obj;
        }
        ClassLoader classLoader = qz0.class.getClassLoader();
        classLoader.getClass();
        bundle.setClassLoader(classLoader);
        Map h90 = new h90(bundle.size());
        for (String str : bundle.keySet()) {
            str.getClass();
            h90.put(str, bundle.get(str));
        }
        h90.b();
        h90.q = true;
        if (h90.m <= 0) {
            h90 = tg0.r;
            h90.getClass();
        }
        obj = new Object();
        linkedHashMap = new LinkedHashMap();
        obj.a = new pa(h90);
        return obj;
    }

    public static final void x(Spannable spannable, if0 if0, int i, int i2) {
        if (if0 != null) {
            Object f;
            List<hf0> list = if0.e;
            if (VERSION.SDK_INT >= 24) {
                ArrayList h90 = new h90(ug.M(if0, 10));
                for (hf0 hf0 : list) {
                    h90.add(hf0.a);
                }
                Locale[] localeArr = (Locale[]) h90.toArray(new Locale[0]);
                f = 
/*
Method generation error in method: jb0.x(android.text.Spannable, if0, int, int):void, dex: 
jadx.core.utils.exceptions.CodegenException: Error generate insn: 0x003f: INVOKE  (r4_10 'f' java.lang.Object) = (wrap: android.os.LocaleList
  0x003b: INVOKE  (r4_9 android.os.LocaleList) = (wrap: java.util.Locale[]
  0x0039: CHECK_CAST  (r4_8 java.util.Locale[]) = (wrap: java.lang.Object[]
  0x0035: INVOKE  (r4_7 java.lang.Object[]) = (r4_6 'localeArr' java.util.Locale[]), (wrap: int
  0x0034: ARRAY_LENGTH  (r0_5 int) = (r4_6 'localeArr' java.util.Locale[])) java.util.Arrays.copyOf(java.lang.Object[], int):java.lang.Object[] type: STATIC) java.util.Locale[]) y0.e(java.util.Locale[]):android.os.LocaleList type: STATIC) y0.f(android.os.LocaleList):android.text.style.LocaleSpan type: STATIC in method: jb0.x(android.text.Spannable, if0, int, int):void, dex: 
	at jadx.core.codegen.InsnGen.makeInsn(Unknown Source:86)
	at jadx.core.codegen.InsnGen.makeInsn(Unknown Source:1)
	at jadx.core.codegen.RegionGen.makeSimpleBlock(Unknown Source:46)
	at jadx.core.codegen.RegionGen.makeRegion(Unknown Source:6)
	at jadx.core.codegen.RegionGen.makeSimpleRegion(Unknown Source:24)
	at jadx.core.codegen.RegionGen.makeRegion(Unknown Source:20)
	at jadx.core.codegen.RegionGen.makeRegionIndent(Unknown Source:3)
	at jadx.core.codegen.RegionGen.makeIf(Unknown Source:43)
	at jadx.core.codegen.RegionGen.makeRegion(Unknown Source:34)
	at jadx.core.codegen.RegionGen.makeSimpleRegion(Unknown Source:24)
	at jadx.core.codegen.RegionGen.makeRegion(Unknown Source:20)
	at jadx.core.codegen.RegionGen.makeRegionIndent(Unknown Source:3)
	at jadx.core.codegen.RegionGen.makeIf(Unknown Source:43)
	at jadx.core.codegen.RegionGen.makeRegion(Unknown Source:34)
	at jadx.core.codegen.RegionGen.makeSimpleRegion(Unknown Source:24)
	at jadx.core.codegen.RegionGen.makeRegion(Unknown Source:20)
	at jadx.core.codegen.RegionGen.makeSimpleRegion(Unknown Source:24)
	at jadx.core.codegen.RegionGen.makeRegion(Unknown Source:20)
	at jadx.core.codegen.MethodGen.addInstructions(Unknown Source:40)
	at jadx.core.codegen.ClassGen.addMethod(Unknown Source:103)
	at jadx.core.codegen.ClassGen.addMethods(Unknown Source:51)
	at jadx.core.codegen.ClassGen.addClassBody(Unknown Source:22)
	at jadx.core.codegen.ClassGen.addClassCode(Unknown Source:24)
	at jadx.core.codegen.ClassGen.makeClass(Unknown Source:5)
	at jadx.core.codegen.CodeGen.visit(Unknown Source:13)
	at jadx.core.ProcessClass.process(Unknown Source:71)
	at jadx.api.JadxDecompiler.processClass(Unknown Source:4)
	at jadx.api.JavaClass.decompile(Unknown Source:19)
Caused by: org.objenesis.ObjenesisException: java.lang.reflect.InvocationTargetException
	at android.s.ۥۡۡۢ.ۥ(Unknown Source:36)
	at android.s.ۥۡۡۢ.<init>(Unknown Source:11)
	at android.s.fk2.ۥ(Unknown Source:110)
	at android.s.c81.ۥ(Unknown Source:25)
	at android.s.c81.newInstance(Unknown Source:0)
	at com.rits.cloning.ObjenesisInstantiationStrategy.newInstance(Unknown Source:2)
	at com.rits.cloning.Cloner.newInstance(Unknown Source:2)
	at com.rits.cloning.Cloner.cloneObject(Unknown Source:0)
	at com.rits.cloning.Cloner.cloneInternal(Unknown Source:132)
	at com.rits.cloning.Cloner.deepClone(Unknown Source:27)
	at jadx.core.dex.nodes.InsnNode.copy(Unknown Source:26)
	at jadx.core.dex.nodes.InsnNode.copyCommonParams(Unknown Source:44)
	at jadx.core.dex.nodes.InsnNode.copy(Unknown Source:19)
	at jadx.core.codegen.InsnGen.inlineMethod(Unknown Source:54)
	at jadx.core.codegen.InsnGen.makeInvoke(Unknown Source:16)
	at jadx.core.codegen.InsnGen.makeInsnBody(Unknown Source:222)
	at jadx.core.codegen.InsnGen.makeInsn(Unknown Source:48)
	... 27 more
Caused by: java.lang.reflect.InvocationTargetException
	at java.lang.reflect.Method.invoke(Native Method)
	at android.s.ۥۡۡۢ.ۥ(Unknown Source:26)
	... 43 more
Caused by: java.lang.UnsupportedOperationException: ObjectStreamClass.getConstructorId(Class<?>) is not supported on SDK 30
	at java.io.ObjectStreamClass.getConstructorId(ObjectStreamClass.java:2498)
	... 45 more

*/

    public static final int A(rj0 rj0) {
        int i = rj0.b;
        int b = rj0.b(0);
        while (rj0.b != 0 && rj0.b(0) == b) {
            rj0.e(0, rj0.c());
            rj0.d(rj0.b - 1);
            int i2 = rj0.b;
            int i3 = i2 >>> 1;
            int i4 = 0;
            while (i4 < i3) {
                int b2 = rj0.b(i4);
                int i5 = (i4 + 1) * 2;
                int i6 = i5 - 1;
                int b3 = rj0.b(i6);
                if (i5 < i2) {
                    int b4 = rj0.b(i5);
                    if (b4 > b3) {
                        if (b4 <= b2) {
                            break;
                        }
                        rj0.e(i4, b4);
                        rj0.e(i5, b2);
                        i4 = i5;
                    }
                }
                if (b3 <= b2) {
                    break;
                }
                rj0.e(i4, b3);
                rj0.e(i6, b2);
                i4 = i6;
            }
        }
        return b;
    }

    public static final float r(d10 d10) {
        Object obj = (jp) d10.j(fk.h);
        Object obj2 = (View) d10.j(c5.f);
        Object L = d10.L();
        nq0 nq0 = oj.a;
        if (L == nq0) {
            L = mc0.t(new br0(0.0f));
            d10.g0(L);
        }
        L = (mk0) L;
        int h = ((AutofillValue) d10) | ((AutofillManager$AutofillCallback) d10);
        Object L2 = d10.L();
        if (h != 0 || L2 == nq0) {
            L2 = new z7(obj2, obj, L, 4);
            d10.g0(L2);
        }
        j70.b(obj2, (i00) L2, d10);
        return ((br) L.getValue()).e;
    }

    public static final float u(long j, float f, jp jpVar) {
        float c;
        long b = qb1.b(j);
        if (d90.a(b, 4294967296L)) {
            if (((double) jpVar.g()) <= 1.05d) {
                return jpVar.N(j);
            }
            c = qb1.c(j) / qb1.c(jpVar.V(f));
        } else if (!d90.a(b, 8589934592L)) {
            return Float.NaN;
        } else {
            c = qb1.c(j);
        }
        return c * f;
    }

    public static final void w(Spannable spannable, long j, jp jpVar, int i, int i2) {
        long b = qb1.b(j);
        if (d90.a(b, 4294967296L)) {
            spannable.setSpan(new ba0(gh0.P(jpVar.N(j)), false), i, i2, 33);
            return;
        }
        if (d90.a(b, 8589934592L)) {
            spannable.setSpan(new br0(qb1.c(j)), i, i2, 33);
        }
    }

    public static final String c(Object[] objArr, int i, int i2, z zVar) {
        StringBuilder h90 = new h90((i2 * 3) + 2);
        h90.append("[");
        for (int i3 = 0; i3 < i2; i3++) {
            if (i3 > 0) {
                h90.append(", ");
            }
            z zVar2 = objArr[i + i3];
            if (zVar2 == zVar) {
                h90.append("(this Collection)");
            } else {
                h90.append(zVar2);
            }
        }
        h90.append("]");
        return h90.toString();
    }

    public static final void d(rj0 rj0, int i) {
        if (rj0.b == 0 || !(rj0.b(0) == i || rj0.b(rj0.b - 1) == i)) {
            int i2 = rj0.b;
            rj0.a(i);
            while (i2 > 0) {
                int i3 = ((i2 + 1) >>> 1) - 1;
                int b = rj0.b(i3);
                if (i <= b) {
                    break;
                }
                rj0.e(i2, b);
                i2 = i3;
            }
            rj0.e(i2, i);
        }
    }

    public static final kh1 j(View view) {
        view.getClass();
        while (view != null) {
            Object tag = view.getTag(2131034233);
            kh1 kh1 = tag instanceof kh1 ? (kh1) tag : null;
            if (kh1 != null) {
                return kh1;
            }
            kh1 j = jb0.j(view);
            view = j instanceof View ? (View) j : null;
        }
        return null;
    }

    public static final dl0 a(BackEvent backEvent) {
        float a = backEvent.getTouchX();
        float e = backEvent.getTouchY();
        return new dl0(backEvent.getSwipeEdge(), backEvent.getProgress(), a, e, VERSION.SDK_INT >= 36 ? backEvent.getFrameTimeMillis() : 0);
    }

    public static final gw0 h(li0 li0, boolean z, boolean z2) {
        if (!li0.e.r) {
            return gw0.e;
        }
        if (z) {
            return k70.M(li0, 8).S0();
        }
        gm0 M = k70.M(li0, 8);
        return k70.D(M).z(M, z2);
    }

    public static rz i(rz[] rzVarArr) {
        rz rzVar = null;
        int i = Integer.MAX_VALUE;
        for (rz rzVar2 : rzVarArr) {
            int abs = (Math.abs(rzVar2.c - 400) * 2) + rzVar2.d;
            if (rzVar == null || i > abs) {
                rzVar = rzVar2;
                i = abs;
            }
        }
        return rzVar;
    }

    public static int z(int i, int i2, String str) {
        return (int) jb0.y(str, (long) i, 1, (long) ((i2 & 8) != 0 ? Integer.MAX_VALUE : 2097150));
    }

    public static final void v(Spannable spannable, long j, int i, int i2) {
        if (j != 16) {
            spannable.setSpan(new h90(wl1.L(j)), i, i2, 33);
        }
    }

    public static final long p(long j, float f) {
        j |= ((long) Float.floatToRawIntBits(f)) & 4294967295L;
        rb1[] rb1Arr = qb1.b;
        return j;
    }

    public static final g60 B(c60 c60) {
        return new g60(c60.a, c60.b, c60.c, c60.d);
    }

    public static final void t(Object[] objArr, int i, int i2) {
        objArr.getClass();
        while (i < i2) {
            objArr[i] = null;
            i++;
        }
    }

    public static final long l(double d) {
        return jb0.p(4294967296L, (float) d);
    }

    public static final long m(int i) {
        return jb0.p(4294967296L, (float) i);
    }

    public jb0() {
        ConcurrentHashMap concurrentHashMap = new ConcurrentHashMap();
    }

    public static final void n(g21 g21) {
        k70.O(g21).F();
    }

    public abstract Typeface e(Context context, rz[] rzVarArr);

    public abstract gw0 k();
}