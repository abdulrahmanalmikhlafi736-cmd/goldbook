package defpackage;

import android.view.autofill.AutofillValue;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bd */
public final class bd extends oa {
    public ne a;
    public i00 b;

    public final void b(Throwable th) {
        ne neVar = this.a;
        if (neVar != null) {
            ((AutofillValue) neVar);
        }
    }

    public final void a() {
        this.b = null;
        this.a = null;
    }
}