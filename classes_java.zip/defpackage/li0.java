package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: li0 */
public abstract class li0 implements cp {
    public li0 e = this;
    public ll f;
    public int g;
    public int h = 0;
    public li0 i;
    public li0 j;
    public wm0 k;
    public gm0 l;
    public boolean m;
    public boolean n;
    public boolean o;
    public boolean p;
    public g4 q;
    public boolean r;

    public void g0() {
        if (!this.r) {
            a5.b("Cannot detach a node that is not attached");
        }
        if (this.o) {
            a5.b("Must run runAttachLifecycle() before markAsDetached()");
        }
        if (this.p) {
            a5.b("Must run runDetachLifecycle() before markAsDetached()");
        }
        this.r = false;
        ll llVar = this.f;
        if (llVar != null) {
            pi0 f1Var = new f1("The Modifier.Node was detached", 2);
            a80 a80 = (a80) llVar.e.k(e3.S);
            if (a80 != null) {
                a80.a(f1Var);
                this.f = null;
                return;
            }
            od.l(llVar, "Scope cannot be cancelled because it does not have a job: ");
        }
    }

    public final bm d0() {
        bm bmVar = this.f;
        if (bmVar != null) {
            return bmVar;
        }
        ll a = vd1.a(((n4) k70.P(this)).getCoroutineContext().i(new c80((a80) ((n4) k70.P(this)).getCoroutineContext().k(e3.S))));
        this.f = a;
        return a;
    }

    public void o0() {
        if (!this.r) {
            a5.b("node detached multiple times");
        }
        if (this.l == null) {
            a5.b("detach invoked on a node without a coordinator");
        }
        if (!this.p) {
            a5.b("Must run runDetachLifecycle() once after runAttachLifecycle() and before markAsDetached()");
        }
        this.p = false;
        g4 g4Var = this.q;
        if (g4Var != null) {
            g4Var.a();
        }
        j0();
    }

    public void n0() {
        if (!this.r) {
            a5.b("Must run markAsAttached() prior to runAttachLifecycle");
        }
        if (!this.o) {
            a5.b("Must run runAttachLifecycle() only once after markAsAttached()");
        }
        this.o = false;
        h0();
        this.p = true;
    }

    public void f0() {
        if (this.r) {
            a5.b("node attached multiple times");
        }
        if (this.l == null) {
            a5.b("attach invoked on a node without a coordinator");
        }
        this.r = true;
        this.o = true;
    }

    public void m0() {
        if (!this.r) {
            a5.b("reset() called on an unattached node");
        }
        l0();
    }

    public boolean e0() {
        return (this instanceof bb) ^ 1;
    }

    public void p0(li0 li0) {
        this.e = li0;
    }

    public void q0(gm0 gm0) {
        this.l = gm0;
    }

    public void h0() {
    }

    public /* synthetic */ void i0() {
    }

    public void j0() {
    }

    public /* synthetic */ void k0() {
    }

    public void l0() {
    }
}