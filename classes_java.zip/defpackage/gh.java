package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: gh */
public abstract class gh {
    public final String a;
    public final long b;
    public final int c;

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.a);
        stringBuilder.append(" (id=");
        stringBuilder.append(this.c);
        stringBuilder.append(", model=");
        long j = this.b;
        Object obj = a5.r(j, 12884901888L) ? "Rgb" : a5.r(j, 12884901889L) ? "Xyz" : a5.r(j, 12884901890L) ? "Lab" : a5.r(j, 17179869187L) ? "Cmyk" : "Unknown";
        stringBuilder.append(obj);
        stringBuilder.append(')');
        return stringBuilder.toString();
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null) {
            if (getClass() == obj.getClass()) {
                gh ghVar = (gh) obj;
                if (this.c == ghVar.c) {
                    if (this.a.equals(ghVar.a)) {
                        return a5.r(this.b, ghVar.b);
                    }
                }
            }
        }
        return false;
    }

    public gh(String str, long j, int i) {
        this.a = str;
        this.b = j;
        this.c = i;
        if (str.length() == 0) {
            od.m("The name of a color space cannot be null and must contain at least 1 character");
            throw null;
        } else if (i < -1 || i > 63) {
            od.m("The id must be between -1 and 63");
            throw null;
        }
    }

    public int hashCode() {
        int hashCode = this.a.hashCode() * 31;
        long j = this.b;
        return ((hashCode + ((int) (j ^ (j >>> 32)))) * 31) + this.c;
    }

    public boolean c() {
        return false;
    }

    public abstract float a(int i);

    public abstract float b(int i);

    public abstract long d(float f, float f2, float f3);

    public abstract float e(float f, float f2, float f3);

    public abstract long f(float f, float f2, float f3, float f4, gh ghVar);
}