package defpackage;

import android.view.autofill.AutofillManager$AutofillCallback;
import android.view.autofill.AutofillValue;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: d3 */
public abstract class d3 {
    public static final up0 a = new up0(24.0f, 24.0f, 24.0f, 24.0f);
    public static final up0 b = ac.f(16.0f);
    public static final up0 c = ac.f(24.0f);
    public static final gk d = new ad0(new h90(2));

    public static final void d(xz xzVar, mi0 mi0, yp ypVar, pi piVar, d10 d10, int i) {
        int i2;
        d10.X(24925658);
        if ((i & 6) == 0) {
            i2 = (((AutofillValue) d10) != null ? 4 : 2) | i;
        } else {
            i2 = i;
        }
        if ((i & 48) == 0) {
            i2 |= ((AutofillManager$AutofillCallback) d10) != null ? 32 : 16;
        }
        if ((i & 384) == 0) {
            i2 |= ((AutofillManager$AutofillCallback) d10) != null ? 256 : 128;
        }
        if ((i & 3072) == 0) {
            i2 |= ((AutofillValue) d10) != null ? 2048 : 1024;
        }
        if (d10.O(i2 & 1, (i2 & 1171) != 1170)) {
            zn znVar = (zn) d10.j(d);
            p3 obj = new Object();
            obj.e = xzVar;
            obj.f = mi0;
            obj.g = ypVar;
            obj.h = piVar;
            znVar.a(obj, d10, 0);
        } else {
            d10.R();
        }
        xv0 r = d10.r();
        if (r != null) {
            r.d = new z2(xzVar, mi0, ypVar, piVar, i, 0);
        }
    }

    public static final void b(float f, pi piVar, d10 d10, int i) {
        d10.X(-917637668);
        int i2 = (d10.c(f) ? 32 : 16) | i;
        if (d10.O(i2 & 1, (i2 & 147) != 146)) {
            Object obj;
            k81 k81 = fk.n;
            o90 o90 = (o90) d10.j(k81);
            int ordinal = o90.ordinal();
            if (ordinal == 0) {
                obj = o90.f;
            } else if (ordinal == 1) {
                obj = o90.e;
            } else {
                od.k();
                return;
            }
            k70.c(k81.a(obj), vd1.A(-1986402020, new u2(f, o90, piVar), d10), d10, 56);
        } else {
            d10.R();
        }
        xv0 r = d10.r();
        if (r != null) {
            r.d = new v2(f, piVar, i);
        }
    }

    static {
        ac.f(16.0f);
    }

    /* JADX WARNING: Removed duplicated region for block: B:51:0x00e3  */
    /* JADX WARNING: Removed duplicated region for block: B:50:0x00b0  */
    /* JADX WARNING: Removed duplicated region for block: B:56:? A:{SYNTHETIC, RETURN} */
    /* JADX WARNING: Removed duplicated region for block: B:54:0x00ee  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final void a(pi piVar, mi0 mi0, m00 m00, m00 m002, y41 y41, long j, long j2, long j3, long j4, long j5, d10 d10, int i) {
        boolean z;
        xv0 r;
        d10 d102 = d10;
        d102.X(1378716401);
        m00 m003 = m00;
        m00 m004 = m002;
        long j6 = j;
        long j7 = j2;
        long j8 = j3;
        long j9 = j4;
        int i2 = ((((((((i | 48) | (((AutofillValue) d102) != null ? 256 : 128)) | (((AutofillValue) d102) != null ? 2048 : 1024)) | (((AutofillValue) d102) != null ? 16384 : 8192)) | (((AutofillManager$AutofillCallback) d102) != null ? 131072 : 65536)) | (d102.e(j6) ? 1048576 : 524288)) | (d102.c(0.0f) ? 8388608 : 4194304)) | (d102.e(j7) ? 67108864 : 33554432)) | (d102.e(j8) ? 536870912 : 268435456);
        long j10 = j5;
        int i3 = (d102.e(j9) ? 4 : 2) | (d102.e(j10) ? 32 : 16);
        if ((i2 & 306783379) == 306783378) {
            if ((i3 & 19) == 18) {
                mi0 mi02;
                z = false;
                if (d102.O(i2 & 1, z)) {
                    d10.R();
                    mi02 = mi0;
                } else {
                    pi A = vd1.A(-652798794, new a3(m003, m004, j8, j9, j10, j7, piVar), d102);
                    int i4 = i2 >> 12;
                    int i5 = ((i4 & 896) | ((i4 & 112) | 12582918)) | ((i2 >> 9) & 57344);
                    ji0 ji0 = ji0.a;
                    p91.a(ji0, y41, j6, 0, A, d102, i5, 104);
                    mi02 = ji0;
                }
                r = d10.r();
                if (r == null) {
                    r.d = new b3(piVar, mi02, m00, m002, y41, j, j2, j3, j4, j5, i);
                    return;
                }
                return;
            }
        }
        z = true;
        if (d102.O(i2 & 1, z)) {
        }
        r = d10.r();
        if (r == null) {
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:116:0x0183  */
    /* JADX WARNING: Removed duplicated region for block: B:115:0x014c  */
    /* JADX WARNING: Removed duplicated region for block: B:121:? A:{SYNTHETIC, RETURN} */
    /* JADX WARNING: Removed duplicated region for block: B:119:0x018c  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final void c(xz xzVar, pi piVar, mi0 mi0, m00 m00, m00 m002, m00 m003, y41 y41, long j, long j2, long j3, long j4, yp ypVar, d10 d10, int i, int i2) {
        int i3;
        pi piVar2;
        m00 m004;
        int i4;
        boolean z;
        xv0 r;
        d10 d102 = d10;
        int i5 = i;
        int i6 = i2;
        d102.X(-867616355);
        if ((i5 & 6) == 0) {
            i3 = (((AutofillValue) d102) != null ? 4 : 2) | i5;
        } else {
            xz xzVar2 = xzVar;
            i3 = i5;
        }
        if ((i5 & 48) == 0) {
            piVar2 = piVar;
            i3 |= ((AutofillValue) d102) != null ? 32 : 16;
        } else {
            piVar2 = piVar;
        }
        if ((i5 & 384) == 0) {
            i3 |= ((AutofillManager$AutofillCallback) d102) != null ? 256 : 128;
        } else {
            mi0 mi02 = mi0;
        }
        if ((i5 & 3072) == 0) {
            m004 = m00;
            i3 |= ((AutofillValue) d102) != null ? 2048 : 1024;
        } else {
            m004 = m00;
        }
        if ((i5 & 24576) == 0) {
            i3 |= ((AutofillValue) d102) != null ? 16384 : 8192;
        }
        if ((196608 & i5) == 0) {
            i3 |= ((AutofillValue) d102) != null ? 131072 : 65536;
        } else {
            m00 m005 = m002;
        }
        m00 m006 = m003;
        if ((i5 & 1572864) == 0) {
            i3 |= ((AutofillValue) d102) != null ? 1048576 : 524288;
        }
        y41 y412 = y41;
        if ((i5 & 12582912) == 0) {
            i3 |= ((AutofillManager$AutofillCallback) d102) != null ? 8388608 : 4194304;
        }
        long j5 = j;
        if ((i5 & 100663296) == 0) {
            i3 |= d102.e(j5) ? 67108864 : 33554432;
        }
        long j6 = j2;
        if ((i5 & 805306368) == 0) {
            i3 |= d102.e(j6) ? 536870912 : 268435456;
        }
        long j7 = j3;
        if ((i6 & 6) == 0) {
            i4 = i6 | (d102.e(j7) ? 4 : 2);
        } else {
            i4 = i6;
        }
        long j8 = j4;
        if ((i6 & 48) == 0) {
            i4 |= d102.e(j8) ? 32 : 16;
        }
        if ((i6 & 384) == 0) {
            i4 |= d102.c(0.0f) ? 256 : 128;
        }
        if ((i6 & 3072) == 0) {
            i4 |= ((AutofillManager$AutofillCallback) d102) != null ? 2048 : 1024;
        } else {
            yp ypVar2 = ypVar;
        }
        int i7 = i4;
        if ((i3 & 306783379) == 306783378) {
            if ((i7 & 1171) == 1170) {
                z = false;
                if (d102.O(i3 & 1, z)) {
                    d10.R();
                } else {
                    d3.d(xzVar, mi0, ypVar, vd1.A(527420759, new t2(m002, m003, y412, j, j6, j7, j4, piVar2, m004), d102), d102, (((i3 & 14) | 3072) | ((i3 >> 3) & 112)) | ((i7 >> 3) & 896));
                }
                r = d10.r();
                if (r == null) {
                    r.d = new x2(xzVar, piVar, mi0, m00, m002, m003, y41, j, j2, j3, j4, ypVar, i5, i6);
                    return;
                }
                return;
            }
        }
        z = true;
        if (d102.O(i3 & 1, z)) {
        }
        r = d10.r();
        if (r == null) {
        }
    }
}