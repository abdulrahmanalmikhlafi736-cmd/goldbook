package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: d01 */
public final class d01 implements a01 {
    public final /* synthetic */ m00 e;
    public final /* synthetic */ i00 f;

    public d01(m00 m00, i00 i00) {
        this.e = m00;
        this.f = i00;
    }

    public final Object e(Object obj) {
        return this.f.i(obj);
    }

    public final Object j(iz0 iz0, Object obj) {
        return this.e.f(iz0, obj);
    }
}