package defpackage;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Set;
import java.util.concurrent.CancellationException;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: h80 */
public class h80 implements a80 {
    public static final /* synthetic */ AtomicReferenceFieldUpdater e;
    public static final /* synthetic */ AtomicReferenceFieldUpdater f;
    private volatile /* synthetic */ Object _parentHandle$volatile;
    private volatile /* synthetic */ Object _state$volatile;

    public final boolean A(Object obj) {
        mt mtVar = zi1.p;
        if (K()) {
            do {
                Object obj2 = e.get(this);
                if (obj2 instanceof l40) {
                    if (obj2 instanceof g80) {
                        if (g80.f.get((g80) obj2) == 1) {
                        }
                    }
                    mtVar = c0(obj2, new e0(G(obj), false));
                }
                mtVar = zi1.p;
                break;
            } while (mtVar == zi1.r);
            if (mtVar == zi1.q) {
                return true;
            }
        }
        if (mtVar == zi1.p) {
            mt mtVar2;
            Throwable th = null;
            Throwable th2 = null;
            loop1:
            while (true) {
                AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = e;
                Object obj3 = atomicReferenceFieldUpdater.get(this);
                if (!(obj3 instanceof g80)) {
                    if (!(obj3 instanceof l40)) {
                        mtVar2 = zi1.s;
                        break;
                    }
                    if (th2 == null) {
                        th2 = G(obj);
                    }
                    l40 l40 = (l40) obj3;
                    if (l40.b()) {
                        im0 L = L(l40);
                        if (L != null) {
                            g80 g80 = new g80(L, th2);
                            while (!atomicReferenceFieldUpdater.compareAndSet(this, l40, g80)) {
                                if (atomicReferenceFieldUpdater.get(this) != l40) {
                                }
                            }
                            V(L, th2);
                            mtVar2 = zi1.p;
                            break loop1;
                        }
                    } else {
                        mt c0 = c0(obj3, new e0(th2, false));
                        if (c0 == zi1.p) {
                            od.l(obj3, "Cannot happen in ");
                            return false;
                        } else if (c0 != zi1.r) {
                            mtVar = c0;
                            break;
                        }
                    }
                } else {
                    synchronized (obj3) {
                        if (g80.h.get((g80) obj3) == zi1.t) {
                            mtVar2 = zi1.s;
                        } else {
                            boolean e = ((g80) obj3).e();
                            if (th2 == null) {
                                th2 = G(obj);
                            }
                            ((g80) obj3).a(th2);
                            Throwable c = ((g80) obj3).c();
                            if (!e) {
                                th = c;
                            }
                            if (th != null) {
                                V(((g80) obj3).e, th);
                            }
                            mtVar2 = zi1.p;
                        }
                    }
                }
            }
            mtVar = mtVar2;
        }
        if (mtVar != zi1.p) {
            if (mtVar != zi1.q) {
                if (mtVar == zi1.s) {
                    return false;
                }
                y(mtVar);
                return true;
            }
        }
        return true;
    }

    /* JADX WARNING: Missing block: B:68:0x00a6, code:
            if (r2 == null) goto L_0x00ab;
     */
    /* JADX WARNING: Missing block: B:69:0x00a8, code:
            V(r0, r2);
     */
    /* JADX WARNING: Missing block: B:70:0x00ab, code:
            r7 = defpackage.h80.U(r0);
     */
    /* JADX WARNING: Missing block: B:71:0x00af, code:
            if (r7 == null) goto L_0x00ba;
     */
    /* JADX WARNING: Missing block: B:73:0x00b5, code:
            if (d0(r1, r7, r8) == false) goto L_0x00ba;
     */
    /* JADX WARNING: Missing block: B:75:0x00b9, code:
            return defpackage.zi1.q;
     */
    /* JADX WARNING: Missing block: B:76:0x00ba, code:
            r0.e(new defpackage.h90(2), 2);
            r7 = defpackage.h80.U(r0);
     */
    /* JADX WARNING: Missing block: B:77:0x00c7, code:
            if (r7 == null) goto L_0x00d2;
     */
    /* JADX WARNING: Missing block: B:79:0x00cd, code:
            if (d0(r1, r7, r8) == false) goto L_0x00d2;
     */
    /* JADX WARNING: Missing block: B:81:0x00d1, code:
            return defpackage.zi1.q;
     */
    /* JADX WARNING: Missing block: B:83:0x00d6, code:
            return H(r1, r8);
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final Object c0(Object obj, Object obj2) {
        if (!(obj instanceof l40)) {
            return zi1.p;
        }
        if ((!(obj instanceof pt) && !(obj instanceof d80)) || (obj instanceof qf) || (obj2 instanceof xh)) {
            l40 l40 = (l40) obj;
            im0 L = L(l40);
            if (L == null) {
                return zi1.r;
            }
            Throwable th = null;
            l40 l402 = l40 instanceof g80 ? (g80) l40 : null;
            if (l402 == null) {
                l402 = new g80(L, null);
            }
            synchronized (l402) {
                AtomicIntegerFieldUpdater atomicIntegerFieldUpdater = g80.f;
                mt mtVar;
                if ((atomicIntegerFieldUpdater.get(l402) == 1 ? 1 : 0) != 0) {
                    mtVar = zi1.p;
                    return mtVar;
                }
                atomicIntegerFieldUpdater.set(l402, 1);
                if (l402 != l40) {
                    AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = e;
                    while (!atomicReferenceFieldUpdater.compareAndSet(this, l40, l402)) {
                        if (atomicReferenceFieldUpdater.get(this) != l40) {
                            mtVar = zi1.r;
                            return mtVar;
                        }
                    }
                }
                boolean e = l402.e();
                xh xhVar = obj2 instanceof xh ? (xh) obj2 : null;
                if (xhVar != null) {
                    l402.a(xhVar.a);
                }
                Throwable c = l402.c();
                if (!e) {
                    th = c;
                }
            }
        } else {
            l40 l403 = (l40) obj;
            AtomicReferenceFieldUpdater atomicReferenceFieldUpdater2 = e;
            Object m40 = obj2 instanceof l40 ? new m40((l40) obj2) : obj2;
            while (!atomicReferenceFieldUpdater2.compareAndSet(this, l403, m40)) {
                if (atomicReferenceFieldUpdater2.get(this) != l403) {
                    return zi1.r;
                }
            }
            W(obj2);
            F(l403, obj2);
            return obj2;
        }
    }

    public final void F(l40 l40, Object obj) {
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = f;
        pf pfVar = (pf) atomicReferenceFieldUpdater.get(this);
        if (pfVar != null) {
            pfVar.a();
            atomicReferenceFieldUpdater.set(this, nm0.e);
        }
        Throwable th = null;
        xh xhVar = obj instanceof xh ? (xh) obj : null;
        Throwable th2 = xhVar != null ? xhVar.a : null;
        String str = " for ";
        String str2 = "Exception in completion handler ";
        if (l40 instanceof d80) {
            try {
                ((d80) l40).l(th2);
            } catch (Throwable th22) {
                StringBuilder dl1 = new dl1(str2);
                dl1.append(l40);
                dl1.append(str);
                dl1.append(this);
                N(new RuntimeException(dl1.toString(), th22));
            }
        } else {
            im0 d = l40.d();
            if (d != null) {
                d.e(new h90(1), 1);
                Object obj2 = of0.e.get(d);
                obj2.getClass();
                for (a40 a40 = (of0) obj2; !a40.equals(d); a40 = a40.h()) {
                    if (a40 instanceof d80) {
                        try {
                            ((d80) a40).l(th22);
                        } catch (Throwable th3) {
                            if (th != null) {
                                ac.i(th, th3);
                            } else {
                                StringBuilder dl12 = new dl1(str2);
                                dl12.append(a40);
                                dl12.append(str);
                                dl12.append(this);
                                th = new RuntimeException(dl12.toString(), th3);
                            }
                        }
                    }
                }
                if (th != null) {
                    N(th);
                }
            }
        }
    }

    public final Object H(g80 g80, Object obj) {
        Throwable I;
        Throwable th = null;
        xh xhVar = obj instanceof xh ? (xh) obj : null;
        if (xhVar != null) {
            th = xhVar.a;
        }
        synchronized (g80) {
            g80.e();
            ArrayList f = g80.f(th);
            I = I(g80, f);
            if (I != null) {
                if (f.size() > 1) {
                    Set newSetFromMap = Collections.newSetFromMap(new h90(f.size()));
                    int size = f.size();
                    int i = 0;
                    while (i < size) {
                        Object obj2 = f.get(i);
                        i++;
                        Throwable th2 = (Throwable) obj2;
                        if (!(th2 == I || th2 == I || (th2 instanceof CancellationException) || !newSetFromMap.add(th2))) {
                            ac.i(I, th2);
                        }
                    }
                }
            }
        }
        if (I != null) {
            if (I != th) {
                obj = new e0(I, false);
            }
        }
        if (I != null && (C(I) || M(I))) {
            obj.getClass();
            xh.b.compareAndSet((xh) obj, 0, 1);
        }
        W(obj);
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = e;
        Object m40 = obj instanceof l40 ? new m40((l40) obj) : obj;
        while (!atomicReferenceFieldUpdater.compareAndSet(this, g80, m40)) {
            if (atomicReferenceFieldUpdater.get(this) != g80) {
                break;
            }
        }
        F(g80, obj);
        return obj;
    }

    public final pf g(h80 h80) {
        qf qfVar = new qf(h80);
        qfVar.h = this;
        loop0:
        while (true) {
            AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = e;
            Object obj = atomicReferenceFieldUpdater.get(this);
            if (obj instanceof pt) {
                pt ptVar = (pt) obj;
                if (ptVar.e) {
                    while (!atomicReferenceFieldUpdater.compareAndSet(this, obj, qfVar)) {
                        if (atomicReferenceFieldUpdater.get(this) != obj) {
                        }
                    }
                    break loop0;
                }
                Y(ptVar);
            } else {
                boolean z = obj instanceof l40;
                nm0 nm0 = nm0.e;
                Throwable th = null;
                Object obj2;
                xh xhVar;
                if (z) {
                    im0 d = ((l40) obj).d();
                    if (d == null) {
                        Z((d80) obj);
                    } else if (!d.e(qfVar, 7)) {
                        boolean e = d.e(qfVar, 3);
                        obj2 = atomicReferenceFieldUpdater.get(this);
                        if (obj2 instanceof g80) {
                            th = ((g80) obj2).c();
                        } else {
                            xhVar = obj2 instanceof xh ? (xh) obj2 : null;
                            if (xhVar != null) {
                                th = xhVar.a;
                            }
                        }
                        qfVar.l(th);
                        return e ? qfVar : nm0;
                    }
                } else {
                    obj2 = atomicReferenceFieldUpdater.get(this);
                    xhVar = obj2 instanceof xh ? (xh) obj2 : null;
                    if (xhVar != null) {
                        th = xhVar.a;
                    }
                    qfVar.l(th);
                    return nm0;
                }
            }
        }
    }

    public final sq P(boolean z, d80 d80) {
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater;
        nm0 nm0;
        int i;
        Throwable th;
        d80.h = this;
        loop0:
        while (true) {
            atomicReferenceFieldUpdater = e;
            Object obj = atomicReferenceFieldUpdater.get(this);
            boolean z2 = obj instanceof pt;
            nm0 = nm0.e;
            i = 1;
            th = null;
            if (!z2) {
                if (!(obj instanceof l40)) {
                    i = 0;
                    break;
                }
                l40 l40 = (l40) obj;
                im0 d = l40.d();
                if (d == null) {
                    Z((d80) obj);
                } else {
                    boolean e;
                    if (d80.k()) {
                        g80 g80 = l40 instanceof g80 ? (g80) l40 : null;
                        Throwable c = g80 != null ? g80.c() : null;
                        if (c == null) {
                            e = d.e(d80, 5);
                        } else if (z) {
                            d80.l(c);
                            return nm0;
                        }
                    }
                    e = d.e(d80, 1);
                    if (e) {
                        break;
                    }
                }
            } else {
                pt ptVar = (pt) obj;
                if (ptVar.e) {
                    while (!atomicReferenceFieldUpdater.compareAndSet(this, obj, d80)) {
                        if (atomicReferenceFieldUpdater.get(this) != obj) {
                        }
                    }
                    break loop0;
                }
                Y(ptVar);
            }
        }
        if (i != 0) {
            return d80;
        }
        if (z) {
            Object obj2 = atomicReferenceFieldUpdater.get(this);
            xh xhVar = obj2 instanceof xh ? (xh) obj2 : null;
            if (xhVar != null) {
                th = xhVar.a;
            }
            d80.l(th);
        }
        return nm0;
    }

    public final CancellationException o() {
        Object obj = e.get(this);
        String str = "Job is still new or active: ";
        CancellationException cancellationException = null;
        Throwable c;
        if (obj instanceof g80) {
            c = ((g80) obj).c();
            if (c != null) {
                String concat = getClass().getSimpleName().concat(" is cancelling");
                if (c instanceof CancellationException) {
                    cancellationException = (CancellationException) c;
                }
                return cancellationException == null ? new b80(concat, c, this) : cancellationException;
            } else {
                od.l(this, str);
                return null;
            }
        } else if (obj instanceof l40) {
            od.l(this, str);
            return null;
        } else if (!(obj instanceof xh)) {
            return new b80(getClass().getSimpleName().concat(" has completed normally"), null, this);
        } else {
            c = ((xh) obj).a;
            if (c instanceof CancellationException) {
                cancellationException = (CancellationException) c;
            }
            return cancellationException == null ? new b80(D(), c, this) : cancellationException;
        }
    }

    public final void V(im0 im0, Throwable th) {
        im0.e(new h90(4), 4);
        Object obj = of0.e.get(im0);
        obj.getClass();
        a40 a40 = (of0) obj;
        Throwable th2 = null;
        while (!a40.equals(im0)) {
            if ((a40 instanceof d80) && ((d80) a40).k()) {
                try {
                    ((d80) a40).l(th);
                } catch (Throwable th3) {
                    if (th2 != null) {
                        ac.i(th2, th3);
                    } else {
                        StringBuilder dl1 = new dl1("Exception in completion handler ");
                        dl1.append(a40);
                        dl1.append(" for ");
                        dl1.append(this);
                        th2 = new RuntimeException(dl1.toString(), th3);
                    }
                }
            }
            a40 = a40.h();
        }
        if (th2 != null) {
            N(th2);
        }
        C(th);
    }

    public final Throwable I(g80 g80, ArrayList arrayList) {
        Throwable th = null;
        if (arrayList.isEmpty()) {
            return g80.e() ? new b80(D(), null, this) : null;
        } else {
            Object obj;
            int size = arrayList.size();
            int i = 0;
            int i2 = 0;
            while (i2 < size) {
                obj = arrayList.get(i2);
                i2++;
                if (!(((Throwable) obj) instanceof CancellationException)) {
                    break;
                }
            }
            obj = null;
            Throwable th2 = (Throwable) obj;
            if (th2 != null) {
                return th2;
            }
            Throwable th3 = (Throwable) arrayList.get(0);
            if (th3 instanceof ic1) {
                i2 = arrayList.size();
                while (i < i2) {
                    th2 = arrayList.get(i);
                    i++;
                    Throwable th4 = th2;
                    if (th4 != th3 && (th4 instanceof ic1)) {
                        th = th2;
                        break;
                    }
                }
                th = th;
                if (th != null) {
                    return th;
                }
            }
            return th3;
        }
    }

    public final Throwable G(Object obj) {
        if (obj instanceof Throwable) {
            return (Throwable) obj;
        }
        Throwable c;
        h80 h80 = (h80) obj;
        Object obj2 = e.get(h80);
        Throwable th = null;
        if (obj2 instanceof g80) {
            c = ((g80) obj2).c();
        } else if (obj2 instanceof xh) {
            c = ((xh) obj2).a;
        } else if (obj2 instanceof l40) {
            od.l(obj2, "Cannot be cancelling child in this state: ");
            return null;
        } else {
            c = null;
        }
        if (c instanceof CancellationException) {
            th = (CancellationException) c;
        }
        if (th == null) {
            th = new b80("Parent job is ".concat(h80.b0(obj2)), c, h80);
        }
        return th;
    }

    public final Object v(nl nlVar) {
        we1 we1;
        Object obj;
        do {
            obj = e.get(this);
            boolean z = obj instanceof l40;
            we1 = we1.a;
            if (!z) {
                j70.B(nlVar.e());
                return we1;
            }
        } while (a0(obj) < 0);
        ne neVar = new ne(1, ac.x(nlVar));
        neVar.t();
        neVar.w(new je(1, j70.K(this, true, new of(neVar, 1))));
        cm s = neVar.s();
        cm cmVar = cm.e;
        if (s != cmVar) {
            s = we1;
        }
        return s == cmVar ? s : we1;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(T());
        stringBuilder2.append('{');
        stringBuilder2.append(h80.b0(e.get(this)));
        stringBuilder2.append('}');
        stringBuilder.append(stringBuilder2.toString());
        stringBuilder.append('@');
        stringBuilder.append(vn.y(this));
        return stringBuilder.toString();
    }

    public final int a0(Object obj) {
        boolean z = obj instanceof pt;
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = e;
        if (!z) {
            if (obj instanceof k40) {
                im0 im0 = ((k40) obj).e;
                while (!atomicReferenceFieldUpdater.compareAndSet(this, obj, im0)) {
                    if (atomicReferenceFieldUpdater.get(this) != obj) {
                    }
                }
                X();
                return 1;
            }
            return 0;
        } else if (((pt) obj).e) {
            return 0;
        } else {
            pt ptVar = zi1.v;
            while (!atomicReferenceFieldUpdater.compareAndSet(this, obj, ptVar)) {
                if (atomicReferenceFieldUpdater.get(this) != obj) {
                }
            }
            X();
            return 1;
        }
        return -1;
    }

    public final void Z(d80 d80) {
        im0 of0 = new of0();
        d80.getClass();
        of0.f.set(of0, d80);
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = of0.e;
        atomicReferenceFieldUpdater.set(of0, d80);
        loop0:
        while (atomicReferenceFieldUpdater.get(d80) == d80) {
            while (!atomicReferenceFieldUpdater.compareAndSet(d80, d80, of0)) {
                if (atomicReferenceFieldUpdater.get(d80) != d80) {
                }
            }
            of0.g(d80);
        }
        of0 h = d80.h();
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater2;
        do {
            atomicReferenceFieldUpdater2 = e;
            if (atomicReferenceFieldUpdater2.compareAndSet(this, d80, h)) {
                return;
            }
        } while (atomicReferenceFieldUpdater2.get(this) == d80);
    }

    public final void S(Object obj) {
        mt c0;
        do {
            c0 = c0(e.get(this), obj);
            if (c0 == zi1.p) {
                StringBuilder dl1 = new dl1("Job ");
                dl1.append(this);
                dl1.append(" is already complete or completing, but is being completed with ");
                dl1.append(obj);
                String stringBuilder = dl1.toString();
                Throwable th = null;
                xh xhVar = obj instanceof xh ? (xh) obj : null;
                if (xhVar != null) {
                    th = xhVar.a;
                }
                throw new IllegalStateException(stringBuilder, th);
            }
        } while (c0 == zi1.r);
    }

    public static qf U(of0 of0) {
        while (of0.i()) {
            AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = of0.f;
            of0 f = of0.f();
            if (f == null) {
                of0 = (of0) atomicReferenceFieldUpdater.get(of0);
                while (of0.i()) {
                    of0 = (of0) atomicReferenceFieldUpdater.get(of0);
                }
            } else {
                of0 = f;
            }
        }
        while (true) {
            of0 = of0.h();
            if (!of0.i()) {
                if (of0 instanceof qf) {
                    return (qf) of0;
                }
                if (of0 instanceof im0) {
                    return null;
                }
            }
        }
    }

    public static String b0(Object obj) {
        String str = "Active";
        if (!(obj instanceof g80)) {
            return obj instanceof l40 ? ((l40) obj).b() ? str : "New" : obj instanceof xh ? "Cancelled" : "Completed";
        } else {
            g80 g80 = (g80) obj;
            if (g80.e()) {
                return "Cancelling";
            }
            return g80.f.get(g80) == 1 ? "Completing" : str;
        }
    }

    public final boolean C(Throwable th) {
        if (!Q()) {
            boolean z = th instanceof CancellationException;
            pf pfVar = (pf) f.get(this);
            if (pfVar != null) {
                if (pfVar != nm0.e) {
                    if (!pfVar.c(th)) {
                        if (!z) {
                            return false;
                        }
                    }
                }
            }
            return z;
        }
        return true;
    }

    public final void O(a80 a80) {
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = f;
        nm0 nm0 = nm0.e;
        if (a80 == null) {
            atomicReferenceFieldUpdater.set(this, nm0);
            return;
        }
        a80.start();
        pf g = a80.g(this);
        atomicReferenceFieldUpdater.set(this, g);
        if (!(e.get(this) instanceof l40)) {
            g.a();
            atomicReferenceFieldUpdater.set(this, nm0);
        }
    }

    public final im0 L(l40 l40) {
        im0 d = l40.d();
        if (d != null) {
            return d;
        }
        if (l40 instanceof pt) {
            return new of0();
        }
        if (l40 instanceof d80) {
            Z((d80) l40);
            return null;
        }
        od.l(l40, "State should have list: ");
        return null;
    }

    public final void Y(pt ptVar) {
        Object of0 = new of0();
        if (!ptVar.e) {
            of0 = new k40(of0);
        }
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater;
        do {
            atomicReferenceFieldUpdater = e;
            if (atomicReferenceFieldUpdater.compareAndSet(this, ptVar, of0)) {
                return;
            }
        } while (atomicReferenceFieldUpdater.get(this) == ptVar);
    }

    public final boolean R(Object obj) {
        mt c0;
        do {
            c0 = c0(e.get(this), obj);
            if (c0 == zi1.p) {
                return false;
            }
            if (c0 == zi1.q) {
                return true;
            }
        } while (c0 == zi1.r);
        y(c0);
        return true;
    }

    public final boolean d0(g80 g80, qf qfVar, Object obj) {
        while (j70.K(qfVar.i, false, new f80(this, g80, qfVar, obj)) == nm0.e) {
            qfVar = h80.U(qfVar);
            if (qfVar == null) {
                return false;
            }
        }
        return true;
    }

    public boolean b() {
        Object obj = e.get(this);
        return (obj instanceof l40) && ((l40) obj).b();
    }

    static {
        Class cls = h80.class;
        Class cls2 = Object.class;
        e = AtomicReferenceFieldUpdater.newUpdater(cls, cls2, "_state$volatile");
        f = AtomicReferenceFieldUpdater.newUpdater(cls, cls2, "_parentHandle$volatile");
    }

    public boolean E(Throwable th) {
        if (!(th instanceof CancellationException)) {
            if (!(A(th) && J())) {
                return false;
            }
        }
        return true;
    }

    public final boolean start() {
        while (true) {
            int a0 = a0(e.get(this));
            if (a0 == 0) {
                return false;
            }
            if (a0 == 1) {
                return true;
            }
        }
    }

    public final sq w(boolean z, boolean z2, e eVar) {
        return P(z2, z ? new w70(eVar) : new vq(1, eVar));
    }

    public void a(CancellationException cancellationException) {
        if (cancellationException == null) {
            cancellationException = new b80(D(), null, this);
        }
        B(cancellationException);
    }

    public h80(boolean z) {
        this._state$volatile = z ? zi1.v : zi1.u;
    }

    public final sq r(i00 i00) {
        return P(true, new vq(1, i00));
    }

    public String T() {
        return getClass().getSimpleName();
    }

    public final sl i(sl slVar) {
        return vn.O(this, slVar);
    }

    public final ql k(rl rlVar) {
        return vn.t(this, rlVar);
    }

    public final Object p(m00 m00, Object obj) {
        return m00.f(obj, this);
    }

    public final sl t(rl rlVar) {
        return vn.J(this, rlVar);
    }

    public void B(CancellationException cancellationException) {
        A(cancellationException);
    }

    public void z(Object obj) {
        y(obj);
    }

    public String D() {
        return "Job was cancelled";
    }

    public boolean K() {
        return this instanceof uh;
    }

    public boolean Q() {
        return this instanceof sb;
    }

    public final rl getKey() {
        return e3.S;
    }

    public boolean J() {
        return true;
    }

    public boolean M(Throwable th) {
        return false;
    }

    public void N(yh yhVar) {
        throw yhVar;
    }

    public void W(Object obj) {
    }

    public void X() {
    }

    public String y(Object obj) {
        return;
    }
}