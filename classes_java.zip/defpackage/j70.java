package defpackage;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Paint;
import android.os.Build.VERSION;
import android.text.Layout;
import android.view.View;
import android.view.Window;
import android.view.autofill.AutofillManager;
import android.view.autofill.AutofillManager$AutofillCallback;
import android.view.autofill.AutofillValue;
import android.webkit.WebView;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.WeakHashMap;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import mod.Mod;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: j70 */
public abstract class j70 {
    public static final a51 A;
    public static final float B = 52.0f;
    public static final eh C;
    public static final eh D;
    public static final float E = 16.0f;
    public static final eh F;
    public static final eh G;
    public static y30 H;
    public static y30 I;
    public static y30 J;
    public static y30 K;
    public static final mt a = new f1("RESUME_TOKEN", 1);
    public static final mt b = new f1("CLOSED", 1);
    public static final rq c = new Object();
    public static final StackTraceElement[] d = new StackTraceElement[0];
    public static final by0 e = new Object();
    public static final eh f = eh.m;
    public static final float g = 1.0f;
    public static final eh h;
    public static final float i = 0.38f;
    public static final eh j;
    public static final float k = 0.12f;
    public static final eh l;
    public static final float m = 0.38f;
    public static final eh n;
    public static final float o = 0.38f;
    public static final eh p;
    public static final eh q;
    public static final a51 r;
    public static final float s = 28.0f;
    public static final eh t = eh.e;
    public static final float u = 24.0f;
    public static final eh v = eh.f;
    public static final eh w = eh.j;
    public static final float x = 40.0f;
    public static final float y = 32.0f;
    public static final float z = 2.0f;

    /* JADX WARNING: Missing block: B:221:0x0252, code:
            return "kotlin.Boolean";
     */
    /* JADX WARNING: Missing block: B:226:0x025f, code:
            return "kotlin.Long";
     */
    /* JADX WARNING: Missing block: B:231:0x026c, code:
            return "kotlin.Char";
     */
    /* JADX WARNING: Missing block: B:236:0x0279, code:
            return "kotlin.Byte";
     */
    /* JADX WARNING: Missing block: B:259:0x02b7, code:
            return "kotlin.Short";
     */
    /* JADX WARNING: Missing block: B:264:0x02c4, code:
            return "kotlin.Float";
     */
    /* JADX WARNING: Missing block: B:284:0x02f6, code:
            return "kotlin.Double";
     */
    /* JADX WARNING: Missing block: B:314:0x033e, code:
            return "kotlin.Int";
     */
    /* JADX WARNING: Missing block: B:318:0x0348, code:
            return null;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static String u(String str) {
        int hashCode = str.hashCode();
        switch (hashCode) {
            case -2061550653:
                if (str.equals("kotlin.jvm.internal.DoubleCompanionObject")) {
                    return "kotlin.Double.Companion";
                }
                break;
            case -2056817302:
                if (!str.equals("java.lang.Integer")) {
                    break;
                }
                break;
            case -2034166429:
                if (!str.equals("java.lang.Cloneable")) {
                    break;
                }
                return "kotlin.Cloneable";
            case -1979556166:
                if (!str.equals("java.lang.annotation.Annotation")) {
                    break;
                }
                return "kotlin.Annotation";
            case -1571515090:
                if (!str.equals("java.lang.Comparable")) {
                    break;
                }
                return "kotlin.Comparable";
            case -1383349348:
                if (!str.equals("java.util.Map")) {
                    break;
                }
                return "kotlin.collections.Map";
            case -1383343454:
                if (!str.equals("java.util.Set")) {
                    break;
                }
                return "kotlin.collections.Set";
            case -1325958191:
                if (!str.equals("double")) {
                    break;
                }
                break;
            case -1182275604:
                if (!str.equals("kotlin.jvm.internal.ByteCompanionObject")) {
                    break;
                }
                return "kotlin.Byte.Companion";
            case -1062240117:
                if (!str.equals("java.lang.CharSequence")) {
                    break;
                }
                return "kotlin.CharSequence";
            case -688322466:
                if (!str.equals("java.util.Collection")) {
                    break;
                }
                return "kotlin.collections.Collection";
            case -527879800:
                if (!str.equals("java.lang.Float")) {
                    break;
                }
                break;
            case -515992664:
                if (!str.equals("java.lang.Short")) {
                    break;
                }
                break;
            case -246476834:
                if (!str.equals("kotlin.jvm.internal.CharCompanionObject")) {
                    break;
                }
                return "kotlin.Char.Companion";
            case -207262728:
                if (!str.equals("kotlin.jvm.internal.LongCompanionObject")) {
                    break;
                }
                return "kotlin.Long.Companion";
            case -165139126:
                if (!str.equals("java.util.Map$Entry")) {
                    break;
                }
                return "kotlin.collections.Map.Entry";
            case 104431:
                if (!str.equals("int")) {
                    break;
                }
                break;
            case 3039496:
                if (!str.equals("byte")) {
                    break;
                }
                break;
            case 3052374:
                if (!str.equals("char")) {
                    break;
                }
                break;
            case 3327612:
                if (!str.equals("long")) {
                    break;
                }
                break;
            case 64711720:
                if (!str.equals("boolean")) {
                    break;
                }
                break;
            case 65821278:
                if (!str.equals("java.util.List")) {
                    break;
                }
                return "kotlin.collections.List";
            case 77230534:
                if (!str.equals("kotlin.jvm.internal.ShortCompanionObject")) {
                    break;
                }
                return "kotlin.Short.Companion";
            case 97526364:
                if (!str.equals("float")) {
                    break;
                }
                break;
            case 109413500:
                if (!str.equals("short")) {
                    break;
                }
                break;
            case 155276373:
                if (!str.equals("java.lang.Character")) {
                    break;
                }
                break;
            case 226173651:
                if (!str.equals("kotlin.jvm.internal.EnumCompanionObject")) {
                    break;
                }
                return "kotlin.Enum.Companion";
            case 344809556:
                if (!str.equals("java.lang.Boolean")) {
                    break;
                }
                break;
            case 398507100:
                if (!str.equals("java.lang.Byte")) {
                    break;
                }
                break;
            case 398585941:
                if (!str.equals("java.lang.Enum")) {
                    break;
                }
                return "kotlin.Enum";
            case 398795216:
                if (!str.equals("java.lang.Long")) {
                    break;
                }
                break;
            case 482629606:
                if (!str.equals("kotlin.jvm.internal.FloatCompanionObject")) {
                    break;
                }
                return "kotlin.Float.Companion";
            case 499831342:
                if (!str.equals("java.util.Iterator")) {
                    break;
                }
                return "kotlin.collections.Iterator";
            case 577341676:
                if (!str.equals("java.util.ListIterator")) {
                    break;
                }
                return "kotlin.collections.ListIterator";
            case 599019395:
                if (!str.equals("kotlin.jvm.internal.StringCompanionObject")) {
                    break;
                }
                return "kotlin.String.Companion";
            case 761287205:
                if (!str.equals("java.lang.Double")) {
                    break;
                }
                break;
            case 1052881309:
                if (!str.equals("java.lang.Number")) {
                    break;
                }
                return "kotlin.Number";
            case 1063877011:
                if (!str.equals("java.lang.Object")) {
                    break;
                }
                return "kotlin.Any";
            case 1195259493:
                if (!str.equals("java.lang.String")) {
                    break;
                }
                return "kotlin.String";
            case 1275614662:
                if (!str.equals("java.lang.Iterable")) {
                    break;
                }
                return "kotlin.collections.Iterable";
            case 1383693018:
                if (!str.equals("kotlin.jvm.internal.BooleanCompanionObject")) {
                    break;
                }
                return "kotlin.Boolean.Companion";
            case 1630335596:
                if (!str.equals("java.lang.Throwable")) {
                    break;
                }
                return "kotlin.Throwable";
            case 1877171123:
                if (!str.equals("kotlin.jvm.internal.IntCompanionObject")) {
                    break;
                }
                return "kotlin.Int.Companion";
            default:
                switch (hashCode) {
                    case -1811142716:
                        if (!str.equals("kotlin.jvm.functions.Function10")) {
                            break;
                        }
                        return "kotlin.Function10";
                    case -1811142715:
                        if (!str.equals("kotlin.jvm.functions.Function11")) {
                            break;
                        }
                        return "kotlin.Function11";
                    case -1811142714:
                        if (!str.equals("kotlin.jvm.functions.Function12")) {
                            break;
                        }
                        return "kotlin.Function12";
                    case -1811142713:
                        if (!str.equals("kotlin.jvm.functions.Function13")) {
                            break;
                        }
                        return "kotlin.Function13";
                    case -1811142712:
                        if (!str.equals("kotlin.jvm.functions.Function14")) {
                            break;
                        }
                        return "kotlin.Function14";
                    case -1811142711:
                        if (!str.equals("kotlin.jvm.functions.Function15")) {
                            break;
                        }
                        return "kotlin.Function15";
                    case -1811142710:
                        if (!str.equals("kotlin.jvm.functions.Function16")) {
                            break;
                        }
                        return "kotlin.Function16";
                    case -1811142709:
                        if (!str.equals("kotlin.jvm.functions.Function17")) {
                            break;
                        }
                        return "kotlin.Function17";
                    case -1811142708:
                        if (!str.equals("kotlin.jvm.functions.Function18")) {
                            break;
                        }
                        return "kotlin.Function18";
                    case -1811142707:
                        if (!str.equals("kotlin.jvm.functions.Function19")) {
                            break;
                        }
                        return "kotlin.Function19";
                    default:
                        switch (hashCode) {
                            case -1811142685:
                                if (!str.equals("kotlin.jvm.functions.Function20")) {
                                    break;
                                }
                                return "kotlin.Function20";
                            case -1811142684:
                                if (!str.equals("kotlin.jvm.functions.Function21")) {
                                    break;
                                }
                                return "kotlin.Function21";
                            case -1811142683:
                                if (!str.equals("kotlin.jvm.functions.Function22")) {
                                    break;
                                }
                                return "kotlin.Function22";
                            default:
                                switch (hashCode) {
                                    case 80123371:
                                        if (!str.equals("kotlin.jvm.functions.Function0")) {
                                            break;
                                        }
                                        return "kotlin.Function0";
                                    case 80123372:
                                        if (!str.equals("kotlin.jvm.functions.Function1")) {
                                            break;
                                        }
                                        return "kotlin.Function1";
                                    case 80123373:
                                        if (!str.equals("kotlin.jvm.functions.Function2")) {
                                            break;
                                        }
                                        return "kotlin.Function2";
                                    case 80123374:
                                        if (!str.equals("kotlin.jvm.functions.Function3")) {
                                            break;
                                        }
                                        return "kotlin.Function3";
                                    case 80123375:
                                        if (!str.equals("kotlin.jvm.functions.Function4")) {
                                            break;
                                        }
                                        return "kotlin.Function4";
                                    case 80123376:
                                        if (!str.equals("kotlin.jvm.functions.Function5")) {
                                            break;
                                        }
                                        return "kotlin.Function5";
                                    case 80123377:
                                        if (!str.equals("kotlin.jvm.functions.Function6")) {
                                            break;
                                        }
                                        return "kotlin.Function6";
                                    case 80123378:
                                        if (!str.equals("kotlin.jvm.functions.Function7")) {
                                            break;
                                        }
                                        return "kotlin.Function7";
                                    case 80123379:
                                        if (!str.equals("kotlin.jvm.functions.Function8")) {
                                            break;
                                        }
                                        return "kotlin.Function8";
                                    case 80123380:
                                        if (!str.equals("kotlin.jvm.functions.Function9")) {
                                            break;
                                        }
                                        return "kotlin.Function9";
                                    default:
                                        break;
                                }
                        }
                }
        }
    }

    /* JADX WARNING: Missing block: B:209:0x0240, code:
            return "Boolean";
     */
    /* JADX WARNING: Missing block: B:214:0x024d, code:
            return "Long";
     */
    /* JADX WARNING: Missing block: B:219:0x025a, code:
            return "Char";
     */
    /* JADX WARNING: Missing block: B:224:0x0267, code:
            return "Byte";
     */
    /* JADX WARNING: Missing block: B:243:0x029f, code:
            return "Short";
     */
    /* JADX WARNING: Missing block: B:248:0x02ac, code:
            return "Float";
     */
    /* JADX WARNING: Missing block: B:266:0x02db, code:
            return "Double";
     */
    /* JADX WARNING: Missing block: B:296:0x0323, code:
            return "Int";
     */
    /* JADX WARNING: Missing block: B:298:0x032a, code:
            if (r1.equals("kotlin.jvm.internal.DoubleCompanionObject") == false) goto L_0x032c;
     */
    /* JADX WARNING: Missing block: B:300:0x032d, code:
            return null;
     */
    /* JADX WARNING: Missing block: B:302:0x0330, code:
            return "Companion";
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static String O(String str) {
        int hashCode = str.hashCode();
        switch (hashCode) {
            case -2061550653:
                break;
            case -2056817302:
                if (!str.equals("java.lang.Integer")) {
                    break;
                }
                break;
            case -2034166429:
                if (!str.equals("java.lang.Cloneable")) {
                    break;
                }
                return "Cloneable";
            case -1979556166:
                if (!str.equals("java.lang.annotation.Annotation")) {
                    break;
                }
                return "Annotation";
            case -1571515090:
                if (!str.equals("java.lang.Comparable")) {
                    break;
                }
                return "Comparable";
            case -1383349348:
                if (!str.equals("java.util.Map")) {
                    break;
                }
                return "Map";
            case -1383343454:
                if (!str.equals("java.util.Set")) {
                    break;
                }
                return "Set";
            case -1325958191:
                if (!str.equals("double")) {
                    break;
                }
                break;
            case -1182275604:
                if (!str.equals("kotlin.jvm.internal.ByteCompanionObject")) {
                    break;
                }
                break;
            case -1062240117:
                if (!str.equals("java.lang.CharSequence")) {
                    break;
                }
                return "CharSequence";
            case -688322466:
                if (!str.equals("java.util.Collection")) {
                    break;
                }
                return "Collection";
            case -527879800:
                if (!str.equals("java.lang.Float")) {
                    break;
                }
                break;
            case -515992664:
                if (!str.equals("java.lang.Short")) {
                    break;
                }
                break;
            case -246476834:
                if (!str.equals("kotlin.jvm.internal.CharCompanionObject")) {
                    break;
                }
                break;
            case -207262728:
                if (!str.equals("kotlin.jvm.internal.LongCompanionObject")) {
                    break;
                }
                break;
            case -165139126:
                if (!str.equals("java.util.Map$Entry")) {
                    break;
                }
                return "Entry";
            case 104431:
                if (!str.equals("int")) {
                    break;
                }
                break;
            case 3039496:
                if (!str.equals("byte")) {
                    break;
                }
                break;
            case 3052374:
                if (!str.equals("char")) {
                    break;
                }
                break;
            case 3327612:
                if (!str.equals("long")) {
                    break;
                }
                break;
            case 64711720:
                if (!str.equals("boolean")) {
                    break;
                }
                break;
            case 65821278:
                if (!str.equals("java.util.List")) {
                    break;
                }
                return "List";
            case 77230534:
                if (!str.equals("kotlin.jvm.internal.ShortCompanionObject")) {
                    break;
                }
                break;
            case 97526364:
                if (!str.equals("float")) {
                    break;
                }
                break;
            case 109413500:
                if (!str.equals("short")) {
                    break;
                }
                break;
            case 155276373:
                if (!str.equals("java.lang.Character")) {
                    break;
                }
                break;
            case 226173651:
                if (!str.equals("kotlin.jvm.internal.EnumCompanionObject")) {
                    break;
                }
                break;
            case 344809556:
                if (!str.equals("java.lang.Boolean")) {
                    break;
                }
                break;
            case 398507100:
                if (!str.equals("java.lang.Byte")) {
                    break;
                }
                break;
            case 398585941:
                if (!str.equals("java.lang.Enum")) {
                    break;
                }
                return "Enum";
            case 398795216:
                if (!str.equals("java.lang.Long")) {
                    break;
                }
                break;
            case 482629606:
                if (!str.equals("kotlin.jvm.internal.FloatCompanionObject")) {
                    break;
                }
                break;
            case 499831342:
                if (!str.equals("java.util.Iterator")) {
                    break;
                }
                return "Iterator";
            case 577341676:
                if (!str.equals("java.util.ListIterator")) {
                    break;
                }
                return "ListIterator";
            case 599019395:
                if (!str.equals("kotlin.jvm.internal.StringCompanionObject")) {
                    break;
                }
                break;
            case 761287205:
                if (!str.equals("java.lang.Double")) {
                    break;
                }
                break;
            case 1052881309:
                if (!str.equals("java.lang.Number")) {
                    break;
                }
                return "Number";
            case 1063877011:
                if (!str.equals("java.lang.Object")) {
                    break;
                }
                return "Any";
            case 1195259493:
                if (!str.equals("java.lang.String")) {
                    break;
                }
                return "String";
            case 1275614662:
                if (!str.equals("java.lang.Iterable")) {
                    break;
                }
                return "Iterable";
            case 1383693018:
                if (!str.equals("kotlin.jvm.internal.BooleanCompanionObject")) {
                    break;
                }
                break;
            case 1630335596:
                if (!str.equals("java.lang.Throwable")) {
                    break;
                }
                return "Throwable";
            case 1877171123:
                if (!str.equals("kotlin.jvm.internal.IntCompanionObject")) {
                    break;
                }
                break;
            default:
                switch (hashCode) {
                    case -1811142716:
                        if (!str.equals("kotlin.jvm.functions.Function10")) {
                            break;
                        }
                        return "Function10";
                    case -1811142715:
                        if (!str.equals("kotlin.jvm.functions.Function11")) {
                            break;
                        }
                        return "Function11";
                    case -1811142714:
                        if (!str.equals("kotlin.jvm.functions.Function12")) {
                            break;
                        }
                        return "Function12";
                    case -1811142713:
                        if (!str.equals("kotlin.jvm.functions.Function13")) {
                            break;
                        }
                        return "Function13";
                    case -1811142712:
                        if (!str.equals("kotlin.jvm.functions.Function14")) {
                            break;
                        }
                        return "Function14";
                    case -1811142711:
                        if (!str.equals("kotlin.jvm.functions.Function15")) {
                            break;
                        }
                        return "Function15";
                    case -1811142710:
                        if (!str.equals("kotlin.jvm.functions.Function16")) {
                            break;
                        }
                        return "Function16";
                    case -1811142709:
                        if (!str.equals("kotlin.jvm.functions.Function17")) {
                            break;
                        }
                        return "Function17";
                    case -1811142708:
                        if (!str.equals("kotlin.jvm.functions.Function18")) {
                            break;
                        }
                        return "Function18";
                    case -1811142707:
                        if (!str.equals("kotlin.jvm.functions.Function19")) {
                            break;
                        }
                        return "Function19";
                    default:
                        switch (hashCode) {
                            case -1811142685:
                                if (!str.equals("kotlin.jvm.functions.Function20")) {
                                    break;
                                }
                                return "Function20";
                            case -1811142684:
                                if (!str.equals("kotlin.jvm.functions.Function21")) {
                                    break;
                                }
                                return "Function21";
                            case -1811142683:
                                if (!str.equals("kotlin.jvm.functions.Function22")) {
                                    break;
                                }
                                return "Function22";
                            default:
                                switch (hashCode) {
                                    case 80123371:
                                        if (!str.equals("kotlin.jvm.functions.Function0")) {
                                            break;
                                        }
                                        return "Function0";
                                    case 80123372:
                                        if (!str.equals("kotlin.jvm.functions.Function1")) {
                                            break;
                                        }
                                        return "Function1";
                                    case 80123373:
                                        if (!str.equals("kotlin.jvm.functions.Function2")) {
                                            break;
                                        }
                                        return "Function2";
                                    case 80123374:
                                        if (!str.equals("kotlin.jvm.functions.Function3")) {
                                            break;
                                        }
                                        return "Function3";
                                    case 80123375:
                                        if (!str.equals("kotlin.jvm.functions.Function4")) {
                                            break;
                                        }
                                        return "Function4";
                                    case 80123376:
                                        if (!str.equals("kotlin.jvm.functions.Function5")) {
                                            break;
                                        }
                                        return "Function5";
                                    case 80123377:
                                        if (!str.equals("kotlin.jvm.functions.Function6")) {
                                            break;
                                        }
                                        return "Function6";
                                    case 80123378:
                                        if (!str.equals("kotlin.jvm.functions.Function7")) {
                                            break;
                                        }
                                        return "Function7";
                                    case 80123379:
                                        if (!str.equals("kotlin.jvm.functions.Function8")) {
                                            break;
                                        }
                                        return "Function8";
                                    case 80123380:
                                        if (!str.equals("kotlin.jvm.functions.Function9")) {
                                            break;
                                        }
                                        return "Function9";
                                    default:
                                        break;
                                }
                        }
                }
        }
    }

    public static final void n(mi0 mi0, r41 r41, d10 d10, int i) {
        mi0 mi02 = mi0;
        r41 r412 = r41;
        d10 d102 = d10;
        r412.getClass();
        Boolean bool = r412.d;
        d102.X(-975571208);
        int i2 = (i | (((AutofillManager$AutofillCallback) d102) != null ? 4 : 2)) | (((AutofillManager$AutofillCallback) d102) != null ? 32 : 16);
        if (d102.O(i2 & 1, (i2 & 19) != 18)) {
            mi0 n = wl1.n(mi02, mc0.n(d102).F, vn.j);
            int i3 = i2 & 112;
            i2 = i3 == 32 ? 1 : 0;
            Object L = d102.L();
            nq0 nq0 = oj.a;
            if (i2 != 0 || L == nq0) {
                L = new l31(r412, 1);
                d102.g0(L);
            }
            mi0 E = ac.E(gh0.s(n, (xz) L), 24.0f, 16.0f);
            ty0 a = sy0.a(new q9(16.0f, new h90(0)), e3.p, d102, 54);
            long j = d102.T;
            int i4 = (int) (j ^ (j >>> 32));
            qr0 l = d102.l();
            E = vn.I(d102, E);
            ij.c.getClass();
            dk dkVar = hj.b;
            d102.Z();
            if (d102.S) {
                d102.k(dkVar);
            } else {
                d102.j0();
            }
            s7 s7Var = hj.f;
            mc0.B(s7Var, d102, a);
            s7 s7Var2 = hj.e;
            mc0.B(s7Var2, d102, l);
            Integer valueOf = Integer.valueOf(i4);
            s7 s7Var3 = hj.g;
            mc0.p(d102, valueOf, s7Var3);
            i4 i4Var = hj.h;
            mc0.w(d102, i4Var);
            s7 s7Var4 = hj.d;
            mc0.B(s7Var4, d102, E);
            int i5 = 32;
            Boolean bool2 = bool;
            s7 s7Var5 = s7Var3;
            dk dkVar2 = dkVar;
            s7 s7Var6 = s7Var2;
            s7 s7Var7 = s7Var;
            int i6 = i3;
            i4 i4Var2 = i4Var;
            nq0 nq02 = nq0;
            s7 s7Var8 = s7Var4;
            Boolean bool3 = bool2;
            t30.a(r412.a, null, null, mc0.n(d102).q, d102, 48, 4);
            ra0 ra0 = new ra0(1.0f, true);
            ph a2 = nh.a(zi1.b, e3.q, d102, 0);
            long j2 = d102.T;
            int i7 = (int) (j2 ^ (j2 >>> i5));
            qr0 l2 = d102.l();
            E = vn.I(d102, ra0);
            d102.Z();
            if (d102.S) {
                d102.k(dkVar2);
            } else {
                d102.j0();
            }
            mc0.B(s7Var7, d102, a2);
            mc0.B(s7Var6, d102, l2);
            mc0.p(d102, Integer.valueOf(i7), s7Var5);
            mc0.w(d102, i4Var2);
            mc0.B(s7Var8, d102, E);
            String str = r412.b;
            lv0 lv0 = fh0.a;
            Boolean bool4 = bool3;
            int i8 = i5;
            boolean z = true;
            int i9 = i6;
            lv0 lv02 = lv0;
            boolean z2 = false;
            nq0 nq03 = nq02;
            d10 d103 = d10;
            za1.b(str, null, mc0.n(d102).q, 0, null, null, 0, null, 0, 0, false, 0, 0, ((dh0) d102.j(lv0)).b.h, d103, 0, 0, 131066);
            d102 = d103;
            if (r412.c == null) {
                d102.W(-395424196);
                d102.p(z2);
            } else {
                d102.W(-395424195);
                d103 = d10;
                za1.b(r412.c, null, mc0.n(d102).s, 0, null, null, 0, null, 0, 0, false, 0, 0, ((dh0) d102.j(lv02)).b.k, d103, 0, 0, 131066);
                d102 = d103;
                d102.p(z2);
            }
            d102.p(true);
            if (bool4 != null) {
                d102.W(260822262);
                boolean booleanValue = bool4.booleanValue();
                boolean z3 = i9 == 32 ? true : z2;
                Object L2 = d102.L();
                if (z3 || L2 == nq03) {
                    L2 = new l31(r412, 1);
                    d102.g0(L2);
                }
                ca1.a(booleanValue, (i00) L2, ji0.a, false, null, d102, 384);
                d102.p(z2);
            } else {
                d102.W(261004232);
                y30 y30 = vn.o;
                if (y30 == null) {
                    x30 x30 = new x30("AutoMirrored.Filled.KeyboardArrowRight", 24.0f, 24.0f, 24.0f, 24.0f, 0, 0, true, 96);
                    i2 = yf1.a;
                    f71 adVar = new ad(zg.b);
                    ArrayList h90 = new h90(32);
                    h90.add(new aj1(8.59f, 16.59f));
                    h90.add(new aj1(13.17f, 12.0f));
                    h90.add(new aj1(8.59f, 7.41f));
                    h90.add(new aj1(10.0f, 6.0f));
                    h90.add(new aj1(6.0f, 6.0f));
                    h90.add(new aj1(-6.0f, 6.0f));
                    h90.add(new aj1(-1.41f, -1.41f));
                    h90.add(rq0.c);
                    x30.a(x30, h90, adVar);
                    y30 = x30.b();
                    vn.o = y30;
                }
                t30.a(y30, null, null, mc0.n(d102).f, d102, 48, 4);
                d102.p(z2);
            }
            d102.p(true);
        } else {
            d102.R();
        }
        xv0 r = d102.r();
        if (r != null) {
            r.d = new hi(i, 14, mi0, r412);
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:141:0x0205  */
    /* JADX WARNING: Removed duplicated region for block: B:140:0x0201  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final void g(mi0 mi0, p9 p9Var, r9 r9Var, e3 e3Var, pi piVar, d10 d10, int i) {
        int i2;
        Object obj;
        mi0 mi02 = mi0;
        p9 p9Var2 = p9Var;
        r9 r9Var2 = r9Var;
        pi piVar2 = piVar;
        d10 d102 = d10;
        int i3 = i;
        mb mbVar = e3.o;
        d102.X(-1956591841);
        if ((i3 & 6) == 0) {
            i2 = (((AutofillManager$AutofillCallback) d102) != null ? 4 : 2) | i3;
        } else {
            i2 = i3;
        }
        if ((i3 & 48) == 0) {
            i2 |= ((AutofillManager$AutofillCallback) d102) != null ? 32 : 16;
        }
        if ((i3 & 384) == 0) {
            i2 |= ((AutofillManager$AutofillCallback) d102) != null ? 256 : 128;
        }
        if ((i3 & 3072) == 0) {
            i2 |= ((AutofillManager$AutofillCallback) d102) != null ? 2048 : 1024;
        }
        if ((i3 & 24576) == 0) {
            i2 |= d102.d(Integer.MAX_VALUE) ? 16384 : 8192;
        }
        if ((196608 & i3) == 0) {
            i2 |= d102.d(Integer.MAX_VALUE) ? 131072 : 65536;
        }
        if ((1572864 & i3) == 0) {
            obj = e3Var;
            i2 |= ((AutofillManager$AutofillCallback) d102) != null ? 1048576 : 524288;
        } else {
            obj = e3Var;
        }
        if ((i3 & 12582912) == 0) {
            i2 |= ((AutofillValue) d102) != null ? 8388608 : 4194304;
        }
        int i4 = i2;
        if (d102.O(i4 & 1, (i4 & 4793491) != 4793490)) {
            boolean z;
            pi piVar3;
            AutofillManager$AutofillCallback f;
            Object L;
            mh0 mh0;
            long j;
            qr0 l;
            mi0 I;
            dk dkVar;
            int i5 = i4 & 3670016;
            Object obj2 = i5 == 1048576 ? 1 : null;
            Object L2 = d102.L();
            nq0 nq0 = oj.a;
            if (obj2 != null || L2 == nq0) {
                obj.getClass();
                L2 = new Object();
                d102.g0(L2);
            }
            qx qxVar = (qx) L2;
            i2 = i4 >> 3;
            int i6 = ((((i2 & 14) ^ 6) <= 4 || ((AutofillManager$AutofillCallback) d102) == null) && (i2 & 6) != 4) ? 0 : 1;
            int i7 = ((((i2 & 112) ^ 48) <= 32 || ((AutofillManager$AutofillCallback) d102) == null) && (i2 & 48) != 32) ? 0 : 1;
            i6 |= i7;
            int i8 = ((((i2 & 896) ^ 384) <= 256 || ((AutofillManager$AutofillCallback) d102) == null) && (i2 & 384) != 256) ? 0 : 1;
            i8 |= i6;
            i6 = ((((i2 & 7168) ^ 3072) <= 2048 || !d102.d(Integer.MAX_VALUE)) && (i2 & 3072) != 2048) ? 0 : 1;
            i8 |= i6;
            i2 = ((((57344 & i2) ^ 24576) <= 16384 || !d102.d(Integer.MAX_VALUE)) && (i2 & 24576) != 16384) ? 0 : 1;
            i8 = (i8 | i2) | ((AutofillManager$AutofillCallback) d102);
            obj2 = d102.L();
            if (i8 != 0 || obj2 == nq0) {
                sx sxVar = new sx(p9Var, r9Var2, p9Var2.a(), new Object(), r9Var2.a(), qxVar);
                d102.g0(sxVar);
                obj2 = sxVar;
            }
            sx sxVar2 = (sx) obj2;
            int i9 = ((i5 == 1048576 ? 1 : 0) | ((i4 & 29360128) == 8388608 ? 1 : 0)) | ((i4 & 458752) == 131072 ? 1 : 0);
            Object L3 = d102.L();
            if (i9 == 0) {
                if (L3 != nq0) {
                    z = true;
                    piVar3 = new pi(1271844412, z, new n(5, (List) L3));
                    f = ((AutofillManager$AutofillCallback) d102);
                    L = d102.L();
                    if (f != null || L == nq0) {
                        L = new hj0(sxVar2);
                        d102.g0(L);
                    }
                    mh0 = (mh0) L;
                    j = d102.T;
                    i9 = (int) (j ^ (j >>> 32));
                    l = d102.l();
                    I = vn.I(d102, mi02);
                    ij.c.getClass();
                    dkVar = hj.b;
                    d102.Z();
                    if (d102.S) {
                        d102.j0();
                    } else {
                        d102.k(dkVar);
                    }
                    mc0.B(hj.f, d102, mh0);
                    mc0.B(hj.e, d102, l);
                    mc0.p(d102, Integer.valueOf(i9), hj.g);
                    mc0.w(d102, hj.h);
                    mc0.B(hj.d, d102, I);
                    piVar3.f(d102, Integer.valueOf(0));
                    d102.p(true);
                }
            }
            L3 = new ArrayList();
            z = true;
            L3.add(new pi(-1192950673, true, new mx(piVar2, 0)));
            e3Var.getClass();
            d102.g0(L3);
            piVar3 = new pi(1271844412, z, new n(5, (List) L3));
            f = ((AutofillManager$AutofillCallback) d102);
            L = d102.L();
            L = new hj0(sxVar2);
            d102.g0(L);
            mh0 = (mh0) L;
            j = d102.T;
            i9 = (int) (j ^ (j >>> 32));
            l = d102.l();
            I = vn.I(d102, mi02);
            ij.c.getClass();
            dkVar = hj.b;
            d102.Z();
            if (d102.S) {
            }
            mc0.B(hj.f, d102, mh0);
            mc0.B(hj.e, d102, l);
            mc0.p(d102, Integer.valueOf(i9), hj.g);
            mc0.w(d102, hj.h);
            mc0.B(hj.d, d102, I);
            piVar3.f(d102, Integer.valueOf(0));
            d102.p(true);
        } else {
            d102.R();
        }
        xv0 r = d102.r();
        if (r != null) {
            r.d = new nx(mi02, p9Var, r9Var, e3Var, piVar, i3, 0);
        }
    }

    public static he E(int i) {
        int i2 = i;
        vz vzVar = vz.k;
        float G = vn.G((i2 >> 16) & 255);
        float G2 = vn.G((i2 >> 8) & 255);
        float G3 = vn.G(i2 & 255);
        double[][] dArr = vn.e;
        double d = (double) G;
        double[] dArr2 = dArr[0];
        double d2 = (double) G2;
        double d3 = (double) G3;
        double d4 = (dArr2[2] * d3) + ((dArr2[1] * d2) + (dArr2[0] * d));
        dArr2 = dArr[1];
        double d5 = (dArr2[2] * d3) + ((dArr2[1] * d2) + (dArr2[0] * d));
        double[] dArr3 = dArr[2];
        d2 = (d2 * dArr3[1]) + (d * dArr3[0]);
        float f = (float) d5;
        float f2 = (float) ((d3 * dArr3[2]) + d2);
        float[] fArr = new float[]{(float) d4, f, f2};
        float[][] fArr2 = vn.b;
        f = fArr[0];
        float[] fArr3 = fArr2[0];
        float f3 = fArr3[0] * f;
        float f4 = fArr[1];
        float f5 = (fArr3[1] * f4) + f3;
        float f6 = fArr[2];
        f2 = (fArr3[2] * f6) + f5;
        float[] fArr4 = fArr2[1];
        f3 = (fArr4[2] * f6) + ((fArr4[1] * f4) + (fArr4[0] * f));
        float[] fArr5 = fArr2[2];
        f6 = (f6 * fArr5[2]) + ((f4 * fArr5[1]) + (f * fArr5[0]));
        fArr5 = vzVar.g;
        f = vzVar.e;
        f4 = vzVar.b;
        G = fArr5[0] * f2;
        G2 = fArr5[1] * f3;
        G3 = fArr5[2] * f6;
        float f7 = vzVar.h;
        f2 = (float) Math.pow((double) ((Math.abs(G) * f7) / 100.0f), 0.41999998688697815d);
        f3 = (float) Math.pow((double) ((Math.abs(G2) * f7) / 100.0f), 0.41999998688697815d);
        f7 = (float) Math.pow((double) ((Math.abs(G3) * f7) / 100.0f), 0.41999998688697815d);
        G = ((Math.signum(G) * 400.0f) * f2) / (f2 + 27.13f);
        G2 = ((Math.signum(G2) * 400.0f) * f3) / (f3 + 27.13f);
        G3 = ((Math.signum(G3) * 400.0f) * f7) / (f7 + 27.13f);
        f3 = (((-12.0f * G2) + (G * 11.0f)) + G3) / 11.0f;
        f7 = ((G + G2) - (G3 * 2.0f)) / 9.0f;
        G2 *= 20.0f;
        float f8 = ((21.0f * G3) + ((G * 20.0f) + G2)) / 20.0f;
        G = (((G * 40.0f) + G2) + G3) / 20.0f;
        G3 = (((float) Math.atan2((double) f7, (double) f3)) * 180.0f) / 3.1415927f;
        if (G3 < 0.0f) {
            G3 += 360.0f;
        } else if (G3 >= 360.0f) {
            G3 -= 360.0f;
        }
        float f9 = G3;
        G3 = (f9 * 3.1415927f) / 180.0f;
        float f10 = f7;
        float f11 = 100.0f;
        float pow = ((float) Math.pow((double) ((G * vzVar.c) / f4), (double) (vzVar.j * f))) * f11;
        G = ((float) Math.pow((double) (((((((((float) Math.cos((double) ((((((double) f9) < 20.14d ? 360.0f + f9 : f9) * 3.1415927f) / 180.0f) + 2.0f))) + 3.8f) * 0.25f) * 3846.1538f) * vzVar.f) * vzVar.d) * ((float) Math.sqrt((double) ((f10 * f10) + (f3 * f3))))) / (f8 + 0.305f)), 0.8999999761581421d)) * ((float) Math.pow((double) (1.64f - ((float) Math.pow(0.28999999165534973d, (double) vzVar.a))), 0.7300000190734863d));
        float sqrt = G * ((float) Math.sqrt((double) (pow / f11)));
        float f12 = vzVar.i * sqrt;
        Math.sqrt((double) ((G * f) / (f4 + 4.0f)));
        f12 = ((float) Math.log((double) ((f12 * 0.0228f) + 1.0f))) * 43.85965f;
        double d6 = (double) G3;
        return new ar0(f9, sqrt, pow, (1.7f * pow) / ((0.007f * pow) + 1.0f), f12 * ((float) Math.cos(d6)), f12 * ((float) Math.sin(d6)));
    }

    public static final void a(i00 i00, mi0 mi0, i00 i002, i00 i003, i00 i004, d10 d10, int i) {
        int i2;
        i00 i005 = i00;
        mi0 mi02 = mi0;
        i00 i006 = i002;
        i00 i007 = i003;
        d10 d102 = d10;
        int i3 = i;
        i4 i4Var = i4.o;
        d102.X(-180024211);
        if ((i3 & 6) == 0) {
            i2 = (((AutofillValue) d102) != null ? 4 : 2) | i3;
        } else {
            i2 = i3;
        }
        if ((i3 & 48) == 0) {
            i2 |= ((AutofillManager$AutofillCallback) d102) != null ? 32 : 16;
        }
        if ((i3 & 384) == 0) {
            i2 |= ((AutofillValue) d102) != null ? 256 : 128;
        }
        if ((i3 & 3072) == 0) {
            i2 |= ((AutofillValue) d102) != null ? 2048 : 1024;
        }
        i2 |= 24576;
        if (d102.O(i2 & 1, (i2 & 9363) != 9362)) {
            long j = d102.T;
            int i4 = (int) ((j >>> 32) ^ j);
            mi0 I = vn.I(d102, mi02.b(vx.a).b(qy.a).b(sy.a).b(ny.a));
            jp jpVar = (jp) d102.j(fk.h);
            o90 o90 = (o90) d102.j(fk.n);
            qr0 l = d102.l();
            sd0 sd0 = (sd0) d102.j(bf0.a);
            xz0 xz0 = (xz0) d102.j(ff0.a);
            if (i006 != null) {
                d102.W(1313917368);
                xz x = j70.x(i005, d102, i2 & 14);
                d102.Z();
                if (d102.S) {
                    d102.k(x);
                } else {
                    d102.j0();
                }
                j70.Q(d102, I, i4, jpVar, sd0, xz0, o90, l);
                mc0.B(s7.g, d102, i006);
                mc0.B(s7.h, d102, i4Var);
                mc0.B(s7.i, d102, i007);
                d102.p(true);
                d102.p(false);
            } else {
                xz0 xz02 = xz0;
                sd0 sd02 = sd0;
                jp jpVar2 = jpVar;
                int i5 = i2;
                mi0 mi03 = I;
                int i6 = i4;
                d102.W(1314774735);
                xz x2 = j70.x(i005, d102, i5 & 14);
                d102.S(125, 1, null, null);
                d102.r = true;
                if (d102.S) {
                    d102.k(x2);
                } else {
                    d102.j0();
                }
                j70.Q(d102, mi03, i6, jpVar2, sd02, xz02, o90, l);
                mc0.B(s7.j, d102, i4Var);
                mc0.B(s7.k, d102, i007);
                d102.p(true);
                d102.p(false);
            }
        } else {
            d102.R();
            i4Var = i004;
        }
        xv0 r = d102.r();
        if (r != null) {
            r.d = new t7(i00, mi02, i006, i007, (i00) i4Var, i);
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:25:0x0074  */
    /* JADX WARNING: Removed duplicated region for block: B:29:0x00b7  */
    /* JADX WARNING: Removed duplicated region for block: B:28:0x00b3  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final void i(String str, t41 t41, d10 d10, int i) {
        Object obj;
        d10 d102;
        d10 d103 = d10;
        int i2 = i;
        d103.X(197033365);
        int i3 = ((((AutofillManager$AutofillCallback) d103) != null ? 4 : 2) | i2) | 16;
        if (d103.O(i3 & 1, (i3 & 19) != 18)) {
            t41 t412;
            Context context;
            Object[] objArr;
            Object L;
            mk0 mk0;
            kz0 u;
            uv uvVar;
            mh0 d;
            long j;
            int i4;
            qr0 l;
            mi0 I;
            dk dkVar;
            String str2;
            t41 t413;
            pi A;
            d103.T();
            if ((i2 & 1) != 0) {
                if (!d103.y()) {
                    d103.R();
                    t412 = t41;
                    d103.q();
                    context = (Context) d103.j(c5.b);
                    objArr = new Object[0];
                    L = d103.L();
                    if (L == oj.a) {
                        L = new h90(8);
                        d103.g0(L);
                    }
                    mk0 = (mk0) kb0.w(objArr, (xz) L, d103, 48);
                    u = wa0.u(d103);
                    uvVar = u51.b;
                    d = ic.d(e3.f, false);
                    j = d103.T;
                    i4 = (int) (j ^ (j >>> 32));
                    l = d103.l();
                    I = vn.I(d103, uvVar);
                    ij.c.getClass();
                    dkVar = hj.b;
                    d103.Z();
                    if (d103.S) {
                        d103.j0();
                    } else {
                        d103.k(dkVar);
                    }
                    mc0.B(hj.f, d103, d);
                    mc0.B(hj.e, d103, l);
                    mc0.p(d103, Integer.valueOf(i4), hj.g);
                    mc0.w(d103, hj.h);
                    mc0.B(hj.d, d103, I);
                    str2 = (String) mk0.getValue();
                    t413 = t412;
                    obj = t413;
                    A = vd1.A(-961397159, new b20(u, mk0, str, t413, context), d103);
                    d102 = d10;
                    wl1.h(str2, null, null, "goldbookScreen", A, d102, 27648);
                    d102.p(true);
                }
            }
            kh1 a = gf0.a(d103);
            if (a != null) {
                t412 = (t41) wc0.t(jh1.a(t41.class), a, null, a instanceof z20 ? ((ki) ((z20) a)).e() : hm.b, d103);
                d103.q();
                context = (Context) d103.j(c5.b);
                objArr = new Object[0];
                L = d103.L();
                if (L == oj.a) {
                }
                mk0 = (mk0) kb0.w(objArr, (xz) L, d103, 48);
                u = wa0.u(d103);
                uvVar = u51.b;
                d = ic.d(e3.f, false);
                j = d103.T;
                i4 = (int) (j ^ (j >>> 32));
                l = d103.l();
                I = vn.I(d103, uvVar);
                ij.c.getClass();
                dkVar = hj.b;
                d103.Z();
                if (d103.S) {
                }
                mc0.B(hj.f, d103, d);
                mc0.B(hj.e, d103, l);
                mc0.p(d103, Integer.valueOf(i4), hj.g);
                mc0.w(d103, hj.h);
                mc0.B(hj.d, d103, I);
                str2 = (String) mk0.getValue();
                t413 = t412;
                obj = t413;
                A = vd1.A(-961397159, new b20(u, mk0, str, t413, context), d103);
                d102 = d10;
                wl1.h(str2, null, null, "goldbookScreen", A, d102, 27648);
                d102.p(true);
            } else {
                od.p("No ViewModelStoreOwner was provided via LocalViewModelStoreOwner");
                return;
            }
        }
        d102 = d103;
        d102.R();
        obj = t41;
        xv0 r = d102.r();
        if (r != null) {
            r.d = new hi(i2, 5, str, obj);
        }
    }

    public static final void m(List list, mi0 mi0, d10 d10, int i) {
        Object obj;
        List list2 = list;
        d10 d102 = d10;
        int i2 = i;
        d102.X(-1479893836);
        int i3 = ((((AutofillValue) d102) != null ? 4 : 2) | i2) | 48;
        if (d102.O(i3 & 1, (i3 & 19) != 18)) {
            float f = 4.0f;
            ph a = nh.a(new q9(4.0f, new h90(0)), e3.q, d102, 6);
            long j = d102.T;
            int i4 = (int) (j ^ (j >>> 32));
            qr0 l = d102.l();
            obj = ji0.a;
            mi0 I = vn.I(d102, obj);
            ij.c.getClass();
            dk dkVar = hj.b;
            d102.Z();
            if (d102.S) {
                d102.k(dkVar);
            } else {
                d102.j0();
            }
            mc0.B(hj.f, d102, a);
            mc0.B(hj.e, d102, l);
            mc0.p(d102, Integer.valueOf(i4), hj.g);
            mc0.w(d102, hj.h);
            mc0.B(hj.d, d102, I);
            d102.W(-1320393940);
            i3 = list2.size();
            i4 = 0;
            while (i4 < i3) {
                y41 a2;
                float f2;
                r41 r41 = (r41) list2.get(i4);
                uv uvVar = u51.a;
                oy0 oy0;
                if (list2.size() - 1 == 0) {
                    a2 = py0.a(28.0f);
                } else if (i4 == 0) {
                    oy0 = py0.a;
                    a2 = new oy0(new br0(28.0f), new br0(28.0f), new br0(f), new br0(f));
                } else {
                    if (i4 == list2.size() - 1) {
                        oy0 = py0.a;
                        f2 = f;
                        a2 = new oy0(new br0(f), new br0(f), new br0(28.0f), new br0(28.0f));
                    } else {
                        f2 = f;
                        a2 = py0.a(f2);
                    }
                    j70.n(k70.x(uvVar, a2), r41, d102, 0);
                    i4++;
                    f = f2;
                }
                f2 = f;
                j70.n(k70.x(uvVar, a2), r41, d102, 0);
                i4++;
                f = f2;
            }
            d102.p(false);
            d102.p(true);
        } else {
            d102.R();
            obj = mi0;
        }
        xv0 r = d102.r();
        if (r != null) {
            r.d = new hi(i2, 13, list2, obj);
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:107:0x0358  */
    /* JADX WARNING: Removed duplicated region for block: B:123:0x042d  */
    /* JADX WARNING: Removed duplicated region for block: B:110:0x0379  */
    /* JADX WARNING: Removed duplicated region for block: B:132:0x0469  */
    /* JADX WARNING: Removed duplicated region for block: B:126:0x044d  */
    /* JADX WARNING: Removed duplicated region for block: B:139:0x04c0  */
    /* JADX WARNING: Removed duplicated region for block: B:147:0x0531  */
    /* JADX WARNING: Removed duplicated region for block: B:146:0x0524  */
    /* JADX WARNING: Removed duplicated region for block: B:34:0x00c9  */
    /* JADX WARNING: Removed duplicated region for block: B:37:0x00dc  */
    /* JADX WARNING: Removed duplicated region for block: B:40:0x00ed  */
    /* JADX WARNING: Removed duplicated region for block: B:49:0x0139  */
    /* JADX WARNING: Removed duplicated region for block: B:58:0x01a6  */
    /* JADX WARNING: Removed duplicated region for block: B:161:0x05d9  */
    /* JADX WARNING: Removed duplicated region for block: B:71:0x01ec  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final void d(String str, t41 t41, xz xzVar, d10 d10, int i) {
        xv0 r;
        String str2 = str;
        t41 t412 = t41;
        xz xzVar2 = xzVar;
        d10 d102 = d10;
        nq0 nq0 = oj.a;
        d102.X(76039143);
        int i2 = ((i | (((AutofillManager$AutofillCallback) d102) != null ? 4 : 2)) | (((AutofillValue) d102) != null ? 32 : 16)) | (((AutofillValue) d102) != null ? 256 : 128);
        if (d102.O(i2 & 1, (i2 & 147) != 146)) {
            Resources resources;
            ui1 ui1;
            ml mlVar;
            Object L;
            mk0 mk0;
            mk0 mk02;
            jq0 jq0;
            Object L2;
            Activity activity;
            y10 y10;
            mk0 mk03;
            Boolean bool;
            mk0 g;
            mk0 g2;
            wi1 wi1;
            boolean t;
            we1 we1;
            int g3;
            nq0 L3;
            a81 a81;
            ui1 ui12;
            Object obj;
            Object obj2;
            Activity activity2;
            ml mlVar2;
            f20 f20;
            Object[] objArr;
            Object L4;
            ci1 ci1;
            boolean z;
            int h;
            i00 i00;
            kh1 a;
            Context context = (Context) d102.j(c5.b);
            Activity activity3 = (Activity) d102.j(ze0.a);
            Resources resources2 = (Resources) d102.j(c5.c);
            i2 &= 14;
            String str3 = str2;
            wi1 a2 = xi1.a(str3, d102);
            int h2 = ((AutofillValue) d102) | ((AutofillValue) d102);
            Object L5 = d102.L();
            if (h2 != 0 || L5 == nq0) {
                L5 = new al(11, context, resources2);
                d102.g0(L5);
            }
            ui1 p = wc0.p(new al(xzVar2, (i00) L5), d102, 1);
            i2 = (i2 == 4 ? 1 : 0) | (((AutofillValue) d102) | ((AutofillManager$AutofillCallback) d102));
            L5 = d102.L();
            if (i2 == 0) {
                if (L5 != nq0) {
                    resources = resources2;
                    ui1 = p;
                    mlVar = null;
                    j70.j((m00) L5, d102, ui1);
                    L = d102.L();
                    if (L == nq0) {
                        L = mc0.t(Boolean.FALSE);
                        d102.g0(L);
                    }
                    mk0 = (mk0) L;
                    L = d102.L();
                    if (L == nq0) {
                        L = mc0.t(mlVar);
                        d102.g0(L);
                    }
                    mk02 = (mk0) L;
                    L = d102.L();
                    if (L == nq0) {
                        L = new ad(0);
                        d102.g0(L);
                    }
                    jq0 = (jq0) L;
                    i2 = ((AutofillValue) d102) | ((AutofillManager$AutofillCallback) d102);
                    L2 = d102.L();
                    if (i2 == 0 || L2 == nq0) {
                        activity = activity3;
                        y10 = new y10(mk0, mk02, jq0, ui1, activity);
                        L = mk0;
                        mk03 = mk02;
                        d102.g0(y10);
                        L2 = y10;
                    } else {
                        activity = activity3;
                        L = mk0;
                        mk03 = mk02;
                    }
                    gh0.e(false, (xz) L2, d102, 0, 1);
                    bool = (Boolean) L.getValue();
                    bool.getClass();
                    L5 = d102.L();
                    if (L5 == nq0) {
                        L5 = new ao(L, mlVar, 2);
                        d102.g0(L5);
                    }
                    j70.j((m00) L5, d102, bool);
                    g = mc0.g(t412.g, d102);
                    g2 = mc0.g(t412.r, d102);
                    wi1 = a2;
                    t = wa0.t(d102);
                    we1 = we1.a;
                    g3 = ((d102.g(t) | ((AutofillManager$AutofillCallback) d102)) | ((AutofillValue) d102)) | ((AutofillManager$AutofillCallback) d102);
                    L3 = d102.L();
                    if (g3 == 0 || L3 == nq0) {
                        a81 = g;
                        ui12 = ui1;
                        obj = t412;
                        obj2 = we1;
                        activity2 = activity;
                        mlVar2 = null;
                        f20 = new f20(t, obj, a81, g2, null);
                        d102.g0(f20);
                    } else {
                        nq0 nq02 = L3;
                        a81 = g;
                        f20 = nq02;
                        ui12 = ui1;
                        obj2 = we1;
                        obj = t412;
                        activity2 = activity;
                        mlVar2 = null;
                    }
                    j70.j(f20, d102, obj2);
                    objArr = new Object[0];
                    L4 = d102.L();
                    if (L4 == nq0) {
                        L4 = new h90(9);
                        d102.g0(L4);
                    }
                    g = (mk0) kb0.w(objArr, (xz) L4, d102, 48);
                    ci1 = (ci1) tg.X(wi1.e);
                    z = ci1 == null && ci1.c;
                    h = ((AutofillValue) d102) | ((AutofillValue) d102);
                    L5 = d102.L();
                    if (h != 0 || L5 == nq0) {
                        L5 = new al(9, resources, obj);
                        d102.g0(L5);
                    }
                    i00 = (i00) L5;
                    a = gf0.a(d102);
                    if (a == null) {
                        Class cls = lg0.class;
                        fh1 a3 = jh1.a(cls);
                        a81 a812 = a81;
                        LinkedHashMap linkedHashMap = new LinkedHashMap();
                        fh1 a4 = jh1.a(cls);
                        i00.getClass();
                        if (linkedHashMap.containsKey(a4)) {
                            String a5 = a4.a();
                            StringBuilder dl1 = new dl1("A `initializer` with the same `clazz` has already been added: ");
                            dl1.append(a5);
                            dl1.append('.');
                            throw new dl1(dl1.toString().toString());
                        }
                        wi1 wi12;
                        kv ajVar;
                        a81 a813;
                        mk0 mk04;
                        mk0 mk05;
                        Object obj3;
                        d10 d103;
                        Context context2;
                        a81 a814;
                        a81 a815;
                        Object obj4;
                        Boolean bool2;
                        WeakHashMap weakHashMap;
                        y7 y7Var;
                        jp jpVar;
                        float r2;
                        dh dhVar;
                        Object L6;
                        sb1 sb1;
                        a81 a816;
                        zg adVar;
                        zg adVar2;
                        int h3;
                        Object L7;
                        ji0 ji0;
                        mi0 n;
                        mi0 G;
                        mi0 b;
                        ws0 u;
                        Context context3;
                        int h4;
                        Object L8;
                        kc kcVar;
                        linkedHashMap.put(a4, new hh1(a4, i00));
                        Collection values = linkedHashMap.values();
                        values.getClass();
                        hh1[] hh1Arr = (hh1[]) values.toArray(new hh1[0]);
                        lg0 lg0 = (lg0) wc0.t(a3, a, new m50((hh1[]) Arrays.copyOf(hh1Arr, hh1Arr.length)), a instanceof z20 ? ((ki) ((z20) a)).e() : hm.b, d102);
                        a81 = lg0.c;
                        Object[] objArr2 = new Object[0];
                        AutofillValue h5 = ((AutofillValue) d102);
                        L5 = d102.L();
                        if (h5 != null || L5 == nq0) {
                            L5 = new x1(4, obj);
                            d102.g0(L5);
                        }
                        g2 = (mk0) kb0.w(objArr2, (xz) L5, d102, 0);
                        Boolean bool3 = (Boolean) g2.getValue();
                        bool3.getClass();
                        boolean z2 = z;
                        pe1 adVar3 = new ad(((zg) a81.getValue()).a);
                        int h6 = (((AutofillValue) d102) | ((AutofillManager$AutofillCallback) d102)) | ((AutofillManager$AutofillCallback) d102);
                        nq0 L9 = d102.L();
                        ml mlVar3;
                        if (h6 != 0 || L9 == nq0) {
                            wi12 = wi1;
                            ajVar = new aj(g2, activity2, a81, mlVar2, 2);
                            mlVar3 = mlVar2;
                            d102.g0(ajVar);
                        } else {
                            wi12 = wi1;
                            ajVar = L9;
                            mlVar3 = mlVar2;
                        }
                        j70.k(bool3, adVar3, ajVar, d102);
                        lq0 lq0 = lg0.e;
                        ye0 ye0 = (ye0) wi12.c.getValue();
                        String str4 = (String) lq0.getValue();
                        g3 = ((((AutofillValue) d102) | ((AutofillManager$AutofillCallback) d102)) | ((AutofillManager$AutofillCallback) d102)) | ((AutofillManager$AutofillCallback) d102);
                        Object L10 = d102.L();
                        if (g3 == 0) {
                            if (L10 != nq0) {
                                a813 = g;
                                L = ye0;
                                j70.k(L, str4, (m00) L10, d102);
                                if (z2 || !((Boolean) a813.getValue()).booleanValue()) {
                                    d102.W(1840654235);
                                    d102.p(false);
                                    objArr2 = new Object[0];
                                    L5 = d102.L();
                                    if (L5 == nq0) {
                                        L5 = new h90(10);
                                        d102.g0(L5);
                                    }
                                    mk04 = (mk0) kb0.w(objArr2, (xz) L5, d102, 48);
                                    if (((Boolean) mk04.getValue()).booleanValue()) {
                                        L10 = L;
                                        mk05 = g2;
                                        obj3 = lg0;
                                        d103 = d102;
                                        context2 = context;
                                        a814 = a812;
                                        a815 = a81;
                                        obj4 = mk04;
                                        d103.W(1841558939);
                                        d103.p(false);
                                    } else {
                                        long j;
                                        a81 a817;
                                        y10 y102;
                                        Activity activity4;
                                        d102.W(1840773802);
                                        j70.f(activity2, a81, g2, false);
                                        context2 = context;
                                        long j2 = ((zg) a81.getValue()).a;
                                        h = (((((AutofillValue) d102) | ((AutofillManager$AutofillCallback) d102)) | ((AutofillManager$AutofillCallback) d102)) | ((AutofillValue) d102)) | ((AutofillManager$AutofillCallback) d102);
                                        nq0 L11 = d102.L();
                                        if (h != 0 || L11 == nq0) {
                                            j = j2;
                                            a814 = a812;
                                            L10 = L;
                                            t41 t413 = obj;
                                            Activity activity5 = activity2;
                                            a817 = a813;
                                            y102 = new y10(t413, activity5, a81, g2, mk04);
                                            Activity activity6 = activity5;
                                            obj = t413;
                                            activity4 = activity6;
                                            obj4 = mk04;
                                            d102.g0(y102);
                                        } else {
                                            activity4 = activity2;
                                            j = j2;
                                            a817 = a813;
                                            L10 = L;
                                            obj4 = mk04;
                                            y102 = L11;
                                            a814 = a812;
                                        }
                                        xz xzVar3 = y102;
                                        i2 = ((((((((AutofillManager$AutofillCallback) d102) | ((AutofillValue) d102)) | ((AutofillValue) d102)) | ((AutofillManager$AutofillCallback) d102)) | ((AutofillManager$AutofillCallback) d102)) | ((AutofillValue) d102)) | ((AutofillValue) d102)) | ((AutofillManager$AutofillCallback) d102);
                                        L5 = d102.L();
                                        if (i2 == 0) {
                                            if (L5 != nq0) {
                                                mk05 = g2;
                                                a813 = a817;
                                                obj3 = lg0;
                                                a815 = a81;
                                                d103 = d102;
                                                wc0.b(j, xzVar3, (xz) L5, d103, 0);
                                                d103.p(false);
                                            }
                                        }
                                        a81 a818 = a817;
                                        activity2 = activity4;
                                        lg0 lg02 = lg0;
                                        a815 = a81;
                                        Resources resources3 = resources;
                                        mk05 = g2;
                                        z10 z10 = new z10(lg02, obj, resources3, ui12, a818, activity2, a815, mk05);
                                        obj3 = lg02;
                                        a813 = a818;
                                        d102.g0(z10);
                                        L5 = z10;
                                        d103 = d102;
                                        wc0.b(j, xzVar3, (xz) L5, d103, 0);
                                        d103.p(false);
                                    }
                                    if (((Boolean) a813.getValue()).booleanValue()) {
                                        d103.W(1841768251);
                                        d103.p(false);
                                    } else {
                                        d103.W(1841585661);
                                        m71.a(L10 instanceof xe0 ? ((xe0) L10).a : 0.8f, d103, 0);
                                        d103.p(false);
                                    }
                                    bool2 = (Boolean) a814.getValue();
                                    bool2.getClass();
                                    h = ((AutofillManager$AutofillCallback) d103) | ((AutofillValue) d103);
                                    obj = d103.L();
                                    if (h != 0 || obj == nq0) {
                                        obj = new d(wi12, a814, null, 1);
                                        d103.g0(obj);
                                    }
                                    j70.j((m00) obj, d103, bool2);
                                    weakHashMap = lk1.v;
                                    y7Var = av0.p(d103).g;
                                    jpVar = (jp) d103.j(fk.h);
                                    r2 = jb0.r(d103);
                                    dhVar = ((dh0) d103.j(fh0.a)).a;
                                    L6 = d103.L();
                                    if (L6 == nq0) {
                                        L6 = new Object();
                                        L6.a = -2838729;
                                        L6.b = -14935265;
                                        d103.g0(L6);
                                    }
                                    sb1 = (sb1) L6;
                                    a816 = a815;
                                    mk0 = mk05;
                                    adVar = new ad(dhVar.a);
                                    adVar2 = new ad(dhVar.b);
                                    h3 = ((AutofillValue) d103) | ((AutofillManager$AutofillCallback) d103);
                                    L7 = d103.L();
                                    if (h3 != 0 || L7 == nq0) {
                                        L7 = new d(sb1, dhVar, null, 2);
                                        d103.g0(L7);
                                    }
                                    j70.k(adVar, adVar2, (m00) L7, d103);
                                    ji0 = ji0.a;
                                    n = wl1.n(u51.b, ((zg) a816.getValue()).a, vn.j);
                                    if (((Boolean) mk0.getValue()).booleanValue()) {
                                        float f = r2;
                                        float b0 = jpVar.b0(y7Var.b(jpVar));
                                        br br0 = new br0(jpVar.b0(y7Var.a(jpVar)));
                                        br br02 = new br0(f);
                                        if (br0.compareTo(br02) < 0) {
                                            br0 = br02;
                                        }
                                        G = ac.G(ji0, 0.0f, b0, 0.0f, br0.e, 5);
                                    } else {
                                        G = ac.G(ji0, 0.0f, 0.0f, 0.0f, r2, 7);
                                    }
                                    b = n.b(G);
                                    u = gh0.u(d103);
                                    context3 = context2;
                                    h4 = (((((AutofillValue) d103) | ((AutofillManager$AutofillCallback) d103)) | ((AutofillValue) d103)) | ((AutofillValue) d103)) | ((AutofillValue) d103);
                                    L8 = d103.L();
                                    if (h4 == 0 || L8 == nq0) {
                                        wi1 = wi12;
                                        kcVar = new kc(wi1, mk03, context3, sb1, obj4, obj3, 1);
                                        d103.g0(kcVar);
                                        L8 = kcVar;
                                    } else {
                                        wi1 = wi12;
                                    }
                                    mc0.c(wi1, b, false, ui12, (i00) L8, null, u, d103, 392);
                                } else {
                                    d102.W(1840585043);
                                    AutofillValue h7 = ((AutofillValue) d102);
                                    L4 = d102.L();
                                    if (h7 != null || L4 == nq0) {
                                        L4 = new x1(5, (Object) activity2);
                                        d102.g0(L4);
                                    }
                                    kb0.a((xz) L4, d102, 0);
                                    d102.p(false);
                                    r = d102.r();
                                    if (r != null) {
                                        r.d = new x10(str, obj, xzVar, i, 0);
                                        return;
                                    }
                                }
                            }
                        }
                        a813 = g;
                        ye0 ye02 = ye0;
                        L10 = new g20(ye02, (a81) lq0, ui12, (mk0) a813, null);
                        L = ye02;
                        d102.g0(L10);
                        j70.k(L, str4, (m00) L10, d102);
                        if (z2) {
                        }
                        d102.W(1840654235);
                        d102.p(false);
                        objArr2 = new Object[0];
                        L5 = d102.L();
                        if (L5 == nq0) {
                        }
                        mk04 = (mk0) kb0.w(objArr2, (xz) L5, d102, 48);
                        if (((Boolean) mk04.getValue()).booleanValue()) {
                        }
                        if (((Boolean) a813.getValue()).booleanValue()) {
                        }
                        bool2 = (Boolean) a814.getValue();
                        bool2.getClass();
                        h = ((AutofillManager$AutofillCallback) d103) | ((AutofillValue) d103);
                        obj = d103.L();
                        obj = new d(wi12, a814, null, 1);
                        d103.g0(obj);
                        j70.j((m00) obj, d103, bool2);
                        weakHashMap = lk1.v;
                        y7Var = av0.p(d103).g;
                        jpVar = (jp) d103.j(fk.h);
                        r2 = jb0.r(d103);
                        dhVar = ((dh0) d103.j(fh0.a)).a;
                        L6 = d103.L();
                        if (L6 == nq0) {
                        }
                        sb1 = (sb1) L6;
                        a816 = a815;
                        mk0 = mk05;
                        adVar = new ad(dhVar.a);
                        adVar2 = new ad(dhVar.b);
                        h3 = ((AutofillValue) d103) | ((AutofillManager$AutofillCallback) d103);
                        L7 = d103.L();
                        L7 = new d(sb1, dhVar, null, 2);
                        d103.g0(L7);
                        j70.k(adVar, adVar2, (m00) L7, d103);
                        ji0 = ji0.a;
                        n = wl1.n(u51.b, ((zg) a816.getValue()).a, vn.j);
                        if (((Boolean) mk0.getValue()).booleanValue()) {
                        }
                        b = n.b(G);
                        u = gh0.u(d103);
                        context3 = context2;
                        h4 = (((((AutofillValue) d103) | ((AutofillManager$AutofillCallback) d103)) | ((AutofillValue) d103)) | ((AutofillValue) d103)) | ((AutofillValue) d103);
                        L8 = d103.L();
                        if (h4 == 0) {
                        }
                        wi1 = wi12;
                        kcVar = new kc(wi1, mk03, context3, sb1, obj4, obj3, 1);
                        d103.g0(kcVar);
                        L8 = kcVar;
                        mc0.c(wi1, b, false, ui12, (i00) L8, null, u, d103, 392);
                    } else {
                        od.p("No ViewModelStoreOwner was provided via LocalViewModelStoreOwner");
                        return;
                    }
                }
            }
            resources = resources2;
            ui1 = p;
            ml mlVar4 = null;
            kv ajVar2 = new aj(a2, ui1, str3, mlVar4, 1);
            mlVar = mlVar4;
            d102.g0(ajVar2);
            L5 = ajVar2;
            j70.j((m00) L5, d102, ui1);
            L = d102.L();
            if (L == nq0) {
            }
            mk0 = (mk0) L;
            L = d102.L();
            if (L == nq0) {
            }
            mk02 = (mk0) L;
            L = d102.L();
            if (L == nq0) {
            }
            jq0 = (jq0) L;
            i2 = ((AutofillValue) d102) | ((AutofillManager$AutofillCallback) d102);
            L2 = d102.L();
            if (i2 == 0) {
            }
            activity = activity3;
            y10 = new y10(mk0, mk02, jq0, ui1, activity);
            L = mk0;
            mk03 = mk02;
            d102.g0(y10);
            L2 = y10;
            gh0.e(false, (xz) L2, d102, 0, 1);
            bool = (Boolean) L.getValue();
            bool.getClass();
            L5 = d102.L();
            if (L5 == nq0) {
            }
            j70.j((m00) L5, d102, bool);
            g = mc0.g(t412.g, d102);
            g2 = mc0.g(t412.r, d102);
            wi1 = a2;
            t = wa0.t(d102);
            we1 = we1.a;
            g3 = ((d102.g(t) | ((AutofillManager$AutofillCallback) d102)) | ((AutofillValue) d102)) | ((AutofillManager$AutofillCallback) d102);
            L3 = d102.L();
            if (g3 == 0) {
            }
            a81 = g;
            ui12 = ui1;
            obj = t412;
            obj2 = we1;
            activity2 = activity;
            mlVar2 = null;
            f20 = new f20(t, obj, a81, g2, null);
            d102.g0(f20);
            j70.j(f20, d102, obj2);
            objArr = new Object[0];
            L4 = d102.L();
            if (L4 == nq0) {
            }
            g = (mk0) kb0.w(objArr, (xz) L4, d102, 48);
            ci1 = (ci1) tg.X(wi1.e);
            if (ci1 == null) {
            }
            h = ((AutofillValue) d102) | ((AutofillValue) d102);
            L5 = d102.L();
            L5 = new al(9, resources, obj);
            d102.g0(L5);
            i00 = (i00) L5;
            a = gf0.a(d102);
            if (a == null) {
            }
        } else {
            d10.R();
        }
        r = d10.r();
        if (r != null) {
            r.d = new x10(str, t41, xzVar, i, 1);
        }
    }

    static {
        eh ehVar = eh.g;
        h = ehVar;
        j = ehVar;
        l = ehVar;
        eh ehVar2 = eh.o;
        n = ehVar2;
        p = ehVar2;
        q = ehVar;
        a51 a51 = a51.f;
        r = a51;
        A = a51;
        ehVar = eh.i;
        C = ehVar;
        D = ehVar;
        F = ehVar2;
        G = ehVar2;
    }

    public static final void h(mi0 mi0, p9 p9Var, r9 r9Var, mb mbVar, int i, int i2, pi piVar, d10 d10, int i3) {
        int i4;
        mi0 mi02;
        mb mbVar2;
        int i5;
        d10 d102 = d10;
        d102.X(-1303174015);
        int i6 = (((i3 | 6) | (((AutofillManager$AutofillCallback) d102) != null ? 32 : 16)) | (((AutofillManager$AutofillCallback) d102) != null ? 256 : 128)) | 224256;
        if (d102.O(i6 & 1, (599187 & i6) != 599186)) {
            mb mbVar3 = e3.o;
            e3 e3Var = e3.M;
            i4 = ((i6 & 896) | ((i6 & 112) | 1572870)) | 12807168;
            ji0 ji0 = ji0.a;
            j70.g(ji0, p9Var, r9Var, e3Var, piVar, d102, i4);
            mi02 = ji0;
            i4 = Integer.MAX_VALUE;
            mbVar2 = mbVar3;
            i5 = i4;
        } else {
            d10.R();
            mi02 = mi0;
            mbVar2 = mbVar;
            i4 = i;
            i5 = i2;
        }
        xv0 r = d10.r();
        if (r != null) {
            r.d = new lx(mi02, p9Var, r9Var, mbVar2, i4, i5, piVar, i3);
        }
    }

    public static final xz x(i00 i00, d10 d10, int i) {
        long j = d10.T;
        int i2 = (int) (j ^ (j >>> 32));
        Context context = (Context) d10.j(c5.b);
        b10 E = zi1.E(d10);
        mz0 mz0 = (mz0) d10.j(oz0.a);
        View view = (View) d10.j(c5.f);
        AutofillValue h = ((AutofillValue) d10);
        i = ((((i & 14) ^ 6) <= 4 || ((AutofillManager$AutofillCallback) d10) == null) && (i & 6) != 4) ? 0 : 1;
        i = ((((i | h) | ((AutofillValue) d10)) | ((AutofillValue) d10)) | d10.d(i2)) | ((AutofillValue) d10);
        Object L = d10.L();
        if (i != 0 || L == oj.a) {
            u7 u7Var = new u7(context, i00, E, mz0, i2, view);
            d10.g0(u7Var);
            L = u7Var;
        }
        return (xz) L;
    }

    public static final void f(Activity activity, a81 a81, mk0 mk0, boolean z) {
        if (activity != null) {
            Window window = activity.getWindow();
            if (window != null) {
                cz0 cz0 = new cz0(window.getDecorView());
                int i = VERSION.SDK_INT;
                boolean z2 = false;
                wa0 ik1 = i >= 35 ? new ik1(window, cz0, 1) : i >= 30 ? new ik1(window, cz0, 1) : i >= 26 ? new ik1(window, cz0, 0) : new ik1(window, cz0, 0);
                if (z) {
                    ik1.p();
                    ik1.y();
                } else {
                    if (mh.b(wl1.L(((zg) a81.getValue()).a)) > 0.5d) {
                        z2 = true;
                    }
                    ik1.z();
                    ik1.x(z2);
                    ik1.w(z2);
                }
                mk0.setValue(Boolean.valueOf(z));
            }
        }
    }

    public static IOException s(File file, IOException iOException) {
        File parentFile = file.getParentFile();
        if (parentFile == null) {
            return j70.r(file, iOException);
        }
        if (parentFile.exists()) {
            return parentFile.isFile() ? parentFile.canRead() ? parentFile.canWrite() ? j70.r(file, iOException) : j70.r(file, iOException) : parentFile.canWrite() ? j70.r(file, iOException) : j70.r(file, iOException) : parentFile.canRead() ? parentFile.canWrite() ? j70.r(file, iOException) : j70.r(file, iOException) : parentFile.canWrite() ? j70.r(file, iOException) : j70.r(file, iOException);
        } else {
            return j70.r(file, iOException);
        }
    }

    public static final long w(long j, is isVar) {
        long j2;
        int ordinal = isVar.ordinal();
        if (ordinal == 2) {
            j2 = 1;
        } else if (ordinal == 3) {
            j2 = 1000;
        } else if (ordinal == 4) {
            j2 = 60000;
        } else if (ordinal == 5) {
            j2 = 3600000;
        } else if (ordinal == 6) {
            j2 = 86400000;
        } else {
            od.l(isVar, "Wrong unit for millisMultiplier: ");
            return 0;
        }
        if (j == 0) {
            return 0;
        }
        if (j == 1) {
            if (j2 <= 4611686018427387903L) {
                return j2;
            }
        } else if (j2 != 1) {
            int numberOfLeadingZeros = (128 - Long.numberOfLeadingZeros(j)) - Long.numberOfLeadingZeros(j2);
            if (numberOfLeadingZeros < 63) {
                return j * j2;
            }
            if (numberOfLeadingZeros <= 63) {
                j *= j2;
                return j > 4611686018427387903L ? 4611686018427387903L : j;
            }
        } else if (j <= 4611686018427387903L) {
            return j;
        }
    }

    public static he F(float f, float f2, float f3) {
        vz vzVar = vz.k;
        float f4 = vzVar.i * f2;
        Math.sqrt((double) (((f2 / ((float) Math.sqrt(((double) f) / 100.0d))) * vzVar.e) / (vzVar.b + 4.0f)));
        f4 = ((float) Math.log((((double) f4) * 0.0228d) + 1.0d)) * 43.85965f;
        double d = (double) ((3.1415927f * f3) / 180.0f);
        return new ar0(f3, f2, f, (1.7f * f) / ((0.007f * f) + 1.0f), f4 * ((float) Math.cos(d)), f4 * ((float) Math.sin(d)));
    }

    public static final sl D(sl slVar, sl slVar2, boolean z) {
        Boolean bool = Boolean.FALSE;
        boolean booleanValue = ((Boolean) slVar.p(new h90(14), bool)).booleanValue();
        z = ((Boolean) slVar2.p(new h90(14), bool)).booleanValue();
        if (!booleanValue && !z) {
            return slVar.i(slVar2);
        }
        o9 h90 = new h90(12);
        st stVar = st.e;
        slVar = (sl) slVar.p(h90, stVar);
        if (z) {
            slVar2 = slVar2.p(new h90(13), stVar);
        }
        return slVar.i(slVar2);
    }

    public static final Object C(a21 a21, long j, m00 m00) {
        while (true) {
            if (a21.c >= j) {
                if (!a21.c()) {
                    return a21;
                }
            }
            AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = kk.a;
            mt mtVar = atomicReferenceFieldUpdater.get(a21);
            mt mtVar2 = b;
            if (mtVar == mtVar2) {
                return mtVar2;
            }
            a21 a212 = (a21) ((kk) mtVar);
            if (a212 == null) {
                a212 = (a21) m00.f(Long.valueOf(a21.c + 1), a21);
                while (!atomicReferenceFieldUpdater.compareAndSet(a21, null, a212)) {
                    if (atomicReferenceFieldUpdater.get(a21) != null) {
                        break;
                    }
                }
                if (a21.c()) {
                    a21.d();
                }
            }
            a21 = a212;
        }
    }

    public static IOException r(File file, IOException iOException) {
        String str = " canonical[";
        StringBuilder dl1 = new dl1("Inoperable file:");
        try {
            StringBuilder dl12 = new dl1(str);
            dl12.append(file.getCanonicalPath());
            dl12.append("] freeSpace[");
            dl12.append(file.getFreeSpace());
            dl12.append(']');
            dl1.append(dl12.toString());
        } catch (IOException unused) {
            dl1.append(" failed to attach additional metadata");
        }
        return new IOException(dl1.toString(), iOException);
    }

    public static final int I(Layout layout, int i, boolean z) {
        if (i <= 0) {
            return 0;
        }
        if (i >= layout.getText().length()) {
            return layout.getLineCount() - 1;
        }
        int lineForOffset = layout.getLineForOffset(i);
        int lineStart = layout.getLineStart(lineForOffset);
        int lineEnd = layout.getLineEnd(lineForOffset);
        if (lineStart == i || lineEnd == i) {
            if (lineStart == i) {
                if (z) {
                    return lineForOffset - 1;
                }
            } else if (!z) {
                return lineForOffset + 1;
            }
        }
        return lineForOffset;
    }

    public static final Object A(long j, nl nlVar) {
        if (j > 0) {
            ne neVar = new ne(1, ac.x(nlVar));
            neVar.t();
            if (j < Long.MAX_VALUE) {
                j70.G(neVar.i).d(j, neVar);
            }
            cm s = neVar.s();
            if (s == cm.e) {
                return s;
            }
        }
        return we1.a;
    }

    public static final void e(ui1 ui1, Activity activity, mk0 mk0) {
        WebView webView = (WebView) mk0.getValue();
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else if (((Boolean) ui1.d.getValue()).booleanValue()) {
            wl1.B(ui1.a, null, new ti1(ui1, null, 0), 3);
        } else {
            Mod.warmExit(activity);
        }
    }

    public static final void N(hh0 hh0, sx sxVar, long j, i00 i00) {
        if (wc0.l(wc0.k(hh0)) == 0.0f) {
            wc0.k(hh0);
            ks0 e = hh0.e(j);
            i00.i(e);
            sxVar.getClass();
            e.P();
            e.M();
            return;
        }
        sxVar.getClass();
        hh0.L(hh0.C(Integer.MAX_VALUE));
    }

    public static final void Q(d10 d10, mi0 mi0, int i, jp jpVar, sd0 sd0, xz0 xz0, o90 o90, qr0 qr0) {
        ij.c.getClass();
        mc0.B(hj.e, d10, qr0);
        mc0.B(s7.l, d10, mi0);
        mc0.B(s7.m, d10, jpVar);
        mc0.B(s7.n, d10, sd0);
        mc0.B(s7.o, d10, xz0);
        mc0.B(s7.p, d10, o90);
        mc0.p(d10, Integer.valueOf(i), hj.g);
    }

    public static final te1 P(ml mlVar, sl slVar, Object obj) {
        te1 te1 = null;
        if (mlVar instanceof dm) {
            if (slVar.k(qe.g) != null) {
                dm dmVar = (dm) mlVar;
                while (!(dmVar instanceof hq)) {
                    dmVar = dmVar.d();
                    if (dmVar != null) {
                        if (dmVar instanceof te1) {
                            te1 = (te1) dmVar;
                            break;
                        }
                    }
                    break;
                }
                if (te1 != null) {
                    te1.k0(slVar, obj);
                }
            }
        }
        return te1;
    }

    public static final void q(l1 l1Var, i21 i21) {
        if (gh0.j(i21)) {
            d21 d21 = i21.d;
            AutofillManager g = ((AutofillManager) d21.e);
            if (g == null) {
                g = null;
            }
            o0 o0Var = (o0) g;
            if (o0Var != null) {
                l1Var.a(new f1(null, 16908349, o0Var.a, null));
            }
        }
    }

    public static final Paint J(k6 k6Var) {
        if (!(k6Var instanceof k6)) {
            StringBuilder dl1 = new dl1("Extracting native reference is only supported from androidx.compose.ui.graphics.AndroidPaint instances but received ");
            dl1.append(jh1.a(k6Var.getClass()).a());
            FileProvider.a(dl1.toString());
        }
        return k6Var.a;
    }

    public static final sq K(a80 a80, boolean z, d80 d80) {
        if (a80 instanceof h80) {
            return ((h80) a80).P(z, d80);
        }
        return a80.w(d80.k(), z, new e(1, d80, d80.class, "invoke", "invoke(Ljava/lang/Throwable;)V", 0, 0, 1));
    }

    public static final void k(Object obj, Object obj2, m00 m00, d10 d10) {
        sl slVar = d10.R;
        int f = ((AutofillManager$AutofillCallback) d10) | ((AutofillManager$AutofillCallback) d10);
        obj2 = d10.L();
        if (f != 0 || obj2 == oj.a) {
            obj2 = new j90(slVar, m00);
            d10.g0(obj2);
        }
        j90 j90 = (j90) obj2;
    }

    public static final void c(Object obj, Object obj2, i00 i00, d10 d10) {
        int f = ((AutofillManager$AutofillCallback) d10) | ((AutofillManager$AutofillCallback) d10);
        obj2 = d10.L();
        if (f != 0 || obj2 == oj.a) {
            obj2 = new pq(i00);
            d10.g0(obj2);
        }
        pq pqVar = (pq) obj2;
    }

    public static final Object z(ak akVar, lv0 lv0) {
        if (!((li0) akVar).e.r) {
            a5.b("Cannot read CompositionLocal because the Modifier node is not currently attached.");
        }
        qr0 qr0 = (qr0) k70.O(akVar).F;
        qr0.getClass();
        return gh0.L(qr0, lv0);
    }

    public static final void j(m00 m00, d10 d10, Object obj) {
        sl slVar = d10.R;
        AutofillManager$AutofillCallback f = ((AutofillManager$AutofillCallback) d10);
        Object L = d10.L();
        if (f != null || L == oj.a) {
            L = new j90(slVar, m00);
            d10.g0(L);
        }
        j90 j90 = (j90) L;
    }

    public static final void b(Object obj, i00 i00, d10 d10) {
        AutofillManager$AutofillCallback f = ((AutofillManager$AutofillCallback) d10);
        Object L = d10.L();
        if (f != null || L == oj.a) {
            L = new pq(i00);
            d10.g0(L);
        }
        pq pqVar = (pq) L;
    }

    public static final void B(sl slVar) {
        a80 a80 = (a80) slVar.k(e3.S);
        if (a80 == null) {
            return;
        }
        if (!a80.b()) {
            throw a80.o();
        }
    }

    public static final bp G(sl slVar) {
        ql k = slVar.k(e3.B);
        bp bpVar = k instanceof bp ? (bp) k : null;
        return bpVar == null ? go.a : bpVar;
    }

    public static final a80 H(sl slVar) {
        a80 a80 = (a80) slVar.k(e3.S);
        if (a80 != null) {
            return a80;
        }
        od.l(slVar, "Current context doesn't contain Job in it: ");
        return null;
    }

    public static final boolean L(sl slVar) {
        a80 a80 = (a80) slVar.k(e3.S);
        return a80 != null ? a80.b() : true;
    }

    public static int v(Comparable comparable, Comparable comparable2) {
        if (comparable == comparable2) {
            return 0;
        }
        if (comparable == null) {
            return -1;
        }
        return comparable2 == null ? 1 : comparable.compareTo(comparable2);
    }

    public static final void o(xz xzVar, d10 d10) {
        zo0 zo0 = d10.M.b.F;
        zo0.C(po0.c);
        dd0.v(zo0, 0, xzVar);
    }

    public static final k6 l() {
        return new k6(new h90(7));
    }

    public static final ah1 p(ba0 ba0) {
        ah1 ah1 = ba0.s;
        if (ah1 != null) {
            return ah1;
        }
        throw fu0.C("Required value was null.");
    }

    public static final byte t(char c) {
        return c < '~' ? kf.b[c] : (byte) 0;
    }

    public static final mi0 M(mi0 mi0, ic0 ic0, yb0 yb0, bp0 bp0, boolean z) {
        return mi0.b(new dc0(ic0, yb0, bp0, z));
    }

    public static final bm y(d10 d10) {
        return new ax0(d10.R);
    }
}