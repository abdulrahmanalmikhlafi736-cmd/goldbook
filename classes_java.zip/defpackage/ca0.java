package defpackage;

import java.util.HashMap;
import java.util.Map;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ca0 */
public final class ca0 {
    public final k3 a;
    public boolean b = true;
    public boolean c;
    public boolean d;
    public boolean e;
    public k3 f;
    public final HashMap g = new HashMap();
    public final /* synthetic */ int h;

    public static final void a(ca0 ca0, f3 f3Var, int i, gm0 gm0) {
        HashMap hashMap = ca0.g;
        float f = (float) i;
        long floatToRawIntBits = ((long) Float.floatToRawIntBits(f)) << 32;
        long floatToRawIntBits2 = ((long) Float.floatToRawIntBits(f)) & 4294967295L;
        while (true) {
            floatToRawIntBits |= floatToRawIntBits2;
            do {
                switch (ca0.h) {
                    case 0:
                        kp0 kp0 = gm0.P;
                        if (kp0 != null) {
                            l20 l20 = (l20) kp0;
                            float[] b = l20.b();
                            if (!l20.w) {
                                floatToRawIntBits = dd0.o(b, floatToRawIntBits);
                            }
                        }
                        floatToRawIntBits = vd1.z(floatToRawIntBits, gm0.D);
                        break;
                    default:
                        dg0 w0 = gm0.w0();
                        w0.getClass();
                        floatToRawIntBits2 = w0.t;
                        floatToRawIntBits = xm0.f((((long) Float.floatToRawIntBits((float) ((int) (floatToRawIntBits2 & 4294967295L)))) & 4294967295L) | (((long) Float.floatToRawIntBits((float) ((int) (floatToRawIntBits2 >> 32)))) << 32), floatToRawIntBits);
                        break;
                }
                gm0 = gm0.u;
                gm0.getClass();
                if (gm0.equals(ca0.a.o())) {
                    int round = Math.round(f3Var instanceof h30 ? Float.intBitsToFloat((int) (floatToRawIntBits & 4294967295L)) : Float.intBitsToFloat((int) (floatToRawIntBits >> 32)));
                    if (hashMap.containsKey(f3Var)) {
                        i = ((Number) ch0.x(f3Var, hashMap)).intValue();
                        h30 h30 = i3.a;
                        round = ((Number) f3Var.a.f(Integer.valueOf(i), Integer.valueOf(round))).intValue();
                    }
                    hashMap.put(f3Var, Integer.valueOf(round));
                    return;
                }
            } while (!ca0.b(gm0).containsKey(f3Var));
            float c = (float) ca0.c(gm0, f3Var);
            long floatToRawIntBits3 = (long) Float.floatToRawIntBits(c);
            floatToRawIntBits = ((long) Float.floatToRawIntBits(c)) << 32;
            floatToRawIntBits2 = floatToRawIntBits3 & 4294967295L;
        }
    }

    public final void h() {
        boolean d = d();
        k3 k3Var = this.a;
        if (!d) {
            k3 s = k3Var.s();
            if (s != null) {
                k3Var = s.c().f;
                if (k3Var == null || !k3Var.c().d()) {
                    s = this.f;
                    if (s == null) {
                        return;
                    }
                    if (!s.c().d()) {
                        k3Var = s.s();
                        if (k3Var != null) {
                            ml c = k3Var.c();
                            if (c != null) {
                                c.h();
                            }
                        }
                        s = s.s();
                        if (s != null) {
                            ml c2 = s.c();
                            if (c2 != null) {
                                k3Var = c2.f;
                            }
                        }
                        k3Var = null;
                    } else {
                        return;
                    }
                }
            } else {
                return;
            }
        }
        this.f = k3Var;
    }

    public final void f() {
        this.b = true;
        k3 k3Var = this.a;
        k3 s = k3Var.s();
        if (s != null) {
            if (this.c) {
                s.requestLayout();
            }
            if (this.d) {
                k3Var.H();
            }
            if (this.e) {
                k3Var.requestLayout();
            }
            s.c().f();
        }
    }

    public final Map b(gm0 gm0) {
        switch (this.h) {
            case 0:
                return gm0.g0().c();
            default:
                dg0 w0 = gm0.w0();
                w0.getClass();
                return w0.g0().c();
        }
    }

    public final void g() {
        HashMap hashMap = this.g;
        hashMap.clear();
        j3 j3Var = new j3(0, this);
        k3 k3Var = this.a;
        k3Var.l(j3Var);
        hashMap.putAll(b(k3Var.o()));
        this.b = false;
    }

    public final int c(gm0 gm0, f3 f3Var) {
        switch (this.h) {
            case 0:
                return gm0.Z(f3Var);
            default:
                dg0 w0 = gm0.w0();
                w0.getClass();
                return w0.Z(f3Var);
        }
    }

    public ca0(k3 k3Var, int i) {
        this.h = i;
        this.a = k3Var;
    }

    public final boolean d() {
        if (!(this.c || this.d)) {
            if (!this.e) {
                return false;
            }
        }
        return true;
    }

    public final boolean e() {
        h();
        return this.f != null;
    }
}