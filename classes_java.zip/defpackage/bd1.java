package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bd1 */
public final class bd1 implements a81 {
    public final ud1 e;
    public final lq0 f;
    public final lq0 g = mc0.t(zi1.G(0.0f, 0.0f, null, 7));
    public final lq0 h;
    public final lq0 i;
    public final hq0 j;
    public boolean k;
    public final lq0 l;
    public u8 m;
    public final jq0 n;
    public boolean o;
    public final p71 p;
    public final /* synthetic */ ed1 q;

    public final void e(Object obj, boolean z) {
        ed1 ed1 = this.q;
        lq0 lq0 = ed1.h;
        lq0 lq02 = this.f;
        boolean p = k70.p(null, lq02.getValue());
        jq0 jq0 = this.n;
        lq0 lq03 = this.h;
        ud1 ud1 = this.e;
        if (p) {
            lq03.setValue(new ja1(this.p, ud1, obj, obj, this.m.c()));
            this.k = true;
            jq0.h(a().c());
            return;
        }
        yv b = (!z || this.o) ? b() : b() instanceof p71 ? b() : this.p;
        long j = 0;
        lq03.setValue(new ja1(ed1.e() <= 0 ? b : new t71(b, ed1.e()), ud1, obj, lq02.getValue(), this.m));
        jq0.h(a().c());
        int i = 0;
        this.k = false;
        lq0.setValue(Boolean.TRUE);
        if (ed1.g()) {
            z61 z61 = ed1.i;
            int size = z61.size();
            while (i < size) {
                bd1 bd1 = (bd1) z61.get(i);
                j = Math.max(j, bd1.n.g());
                bd1.c();
                i++;
            }
            lq0.setValue(Boolean.FALSE);
        }
    }

    public final void g(Object obj, yv yvVar) {
        if (!this.k || !k70.p(obj, null)) {
            lq0 lq0 = this.f;
            boolean p = k70.p(lq0.getValue(), obj);
            hq0 hq0 = this.j;
            if (!(p && hq0.g() == -1.0f)) {
                lq0.setValue(obj);
                this.g.setValue(yvVar);
                int i = (hq0.g() > -3.0f ? 1 : (hq0.g() == -3.0f ? 0 : -1));
                lq0 lq02 = this.l;
                Object value = i == 0 ? obj : lq02.getValue();
                lq0 lq03 = this.i;
                boolean z = true;
                e(value, ((Boolean) lq03.getValue()).booleanValue() ^ 1);
                if (hq0.g() != -3.0f) {
                    z = false;
                }
                lq03.setValue(Boolean.valueOf(z));
                if (hq0.g() >= 0.0f) {
                    lq02.setValue(a().b((long) (hq0.g() * ((float) a().c()))));
                } else if (hq0.g() == -3.0f) {
                    lq02.setValue(obj);
                }
                this.k = false;
                hq0.h(-1.0f);
            }
        }
    }

    public bd1(ed1 ed1, Object obj, u8 u8Var, ud1 ud1) {
        this.q = ed1;
        this.e = ud1;
        lq0 t = mc0.t(obj);
        this.f = t;
        Object obj2 = null;
        Object obj3 = obj;
        u8 u8Var2 = u8Var;
        ud1 ud12 = ud1;
        this.h = mc0.t(new ja1(b(), ud12, obj3, t.getValue(), u8Var2));
        this.i = mc0.t(Boolean.TRUE);
        this.j = new br0(-1.0f);
        this.l = mc0.t(obj3);
        this.m = u8Var2;
        this.n = new ad(a().c());
        Float f = (Float) nh1.a.get(ud12);
        if (f != null) {
            float floatValue = f.floatValue();
            u8 u8Var3 = (u8) ud12.a.i(obj3);
            int b = u8Var3.b();
            for (int i = 0; i < b; i++) {
                u8Var3.e(floatValue, i);
            }
            obj2 = this.e.b.i(u8Var3);
        }
        this.p = zi1.G(0.0f, 0.0f, obj2, 3);
    }

    public final void c() {
        if (this.j.g() == -1.0f) {
            this.o = true;
            boolean p = k70.p(a().c, a().d);
            lq0 lq0 = this.l;
            if (p) {
                lq0.setValue(a().c);
            } else {
                lq0.setValue(a().b(0));
                this.m = a().f(0);
            }
        }
    }

    public final String toString() {
        StringBuilder dl1 = new dl1("current value: ");
        dl1.append(this.l.getValue());
        dl1.append(", target: ");
        dl1.append(this.f.getValue());
        dl1.append(", spec: ");
        dl1.append(b());
        return dl1.toString();
    }

    public final void f(Object obj, Object obj2, yv yvVar) {
        this.f.setValue(obj2);
        this.g.setValue(yvVar);
        if (!k70.p(a().d, obj) || !k70.p(a().c, obj2)) {
            e(obj, false);
        }
    }

    public final ja1 a() {
        return (ja1) this.h.getValue();
    }

    public final yv b() {
        return (yv) this.g.getValue();
    }

    public final Object getValue() {
        return this.l.getValue();
    }
}