package defpackage;

import android.view.View;
import android.view.View.AccessibilityDelegate;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: r0 */
public abstract class r0 {
    public static final AccessibilityDelegate g = new AccessibilityDelegate();
    public final AccessibilityDelegate e = g;
    public final q0 f = new q0(this);

    public pg0 a(View view) {
        Object accessibilityNodeProvider = this.e.getAccessibilityNodeProvider(view);
        return accessibilityNodeProvider != null ? new pg0(2, accessibilityNodeProvider) : null;
    }

    public void b(View view, l1 l1Var) {
        this.e.onInitializeAccessibilityNodeInfo(view, l1Var.a);
    }
}