package defpackage;

import java.nio.ByteBuffer;
import java.nio.charset.Charset;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: d70 */
public abstract class d70 {
    public static final Charset a = Class.forName("UTF-8");
    public static final byte[] b;

    static {
        Class.forName("US-ASCII");
        Class.forName("ISO-8859-1");
        byte[] bArr = new byte[0];
        b = bArr;
        ByteBuffer.wrap(bArr);
        try {
            new mg(bArr, 0, 0, false).j(0);
        } catch (s70 e) {
            throw new IllegalArgumentException(e);
        }
    }

    public static void a(Object obj, String str) {
        if (obj == null) {
            throw new dl1(str);
        }
    }

    public static int b(long j) {
        return (int) (j ^ (j >>> 32));
    }
}