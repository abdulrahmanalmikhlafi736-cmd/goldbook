package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bo */
public final class bo extends li0 implements ds {
    public final uj0 s;
    public boolean t;
    public boolean u;
    public boolean v;

    public final void C(da0 da0) {
        da0.c();
        te teVar = da0.e;
        if (this.t) {
            da0 da02 = da0;
            fu0.x(da02, zg.b(zg.b, 0.3f), teVar.f.t(), 122);
            return;
        }
        if (!this.u) {
            if (!this.v) {
                return;
            }
        }
        long b = zg.b(zg.b, 0.1f);
        fu0.x(da0, b, teVar.f.t(), 122);
    }

    public final void h0() {
        wl1.B(d0(), null, new ao((Object) this, null, 0), 3);
    }

    public bo(uj0 uj0) {
        this.s = uj0;
    }

    public final /* synthetic */ void Z() {
    }
}