package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: af1 */
public final class af1 extends av0 {
    public final boolean q(CharSequence charSequence) {
        return z0.q(charSequence);
    }
}