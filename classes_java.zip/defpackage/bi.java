package defpackage;

import android.window.OnBackInvokedDispatcher;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bi */
public final /* synthetic */ class bi implements qd0 {
    public final /* synthetic */ jn0 e;
    public final /* synthetic */ ki f;

    public final void h(sd0 sd0, id0 id0) {
        if (id0 == id0.ON_CREATE) {
            OnBackInvokedDispatcher g = this.f.getOnBackInvokedDispatcher();
            g.getClass();
            this.e.b(g);
        }
    }

    public /* synthetic */ bi(jn0 jn0, ki kiVar) {
        this.e = jn0;
        this.f = kiVar;
    }
}