package defpackage;

import androidx.core.content.FileProvider;
import java.util.Collection;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: a91 */
public final class a91 implements List, w80 {
    public final z61 e;
    public final int f;
    public int g;
    public int h;

    public final boolean retainAll(Collection collection) {
        a();
        z61 z61 = this.e;
        int i = this.f;
        int i2 = this.h + i;
        int size = z61.size();
        boolean n;
        do {
            g81 g81;
            int i3;
            c0 c0Var;
            synchronized (zi1.x) {
                g81 = z61.e;
                g81.getClass();
                g81 = (g81) n61.h(g81);
                i3 = g81.d;
                c0Var = g81.c;
            }
            c0Var.getClass();
            es0 f = c0Var.f();
            f.subList(i, i2).retainAll(collection);
            c0 c = f.c();
            if (k70.p(c, c0Var)) {
                break;
            }
            g61 j;
            g81 = z61.e;
            g81.getClass();
            synchronized (n61.c) {
                j = n61.j();
                n = zi1.n((g81) n61.x(g81, z61, j), i3, c, true);
            }
            n61.o(j, z61);
        } while (!n);
        size -= z61.size();
        if (size > 0) {
            this.g = zi1.v(this.e);
            this.h -= size;
        }
        return size > 0;
    }

    public final int indexOf(Object obj) {
        int nextInt;
        a();
        int i = this.h;
        int i2 = this.f;
        Iterator it = sb0.w(i2, i + i2).iterator();
        do {
            p60 p60 = (p60) it;
            if (!p60.g) {
                return -1;
            }
            nextInt = p60.nextInt();
        } while (!k70.p(obj, this.e.get(nextInt)));
        return nextInt - i2;
    }

    public final boolean containsAll(Collection collection) {
        Iterable<Object> iterable = collection;
        if ((iterable instanceof Collection) && ((Collection) iterable).isEmpty()) {
            return true;
        }
        for (Object contains : iterable) {
            if (!contains(contains)) {
                return false;
            }
        }
        return true;
    }

    public final int lastIndexOf(Object obj) {
        a();
        int i = this.h;
        int i2 = this.f;
        for (i = (i + i2) - 1; i >= i2; i--) {
            if (k70.p(obj, this.e.get(i))) {
                return i - i2;
            }
        }
        return -1;
    }

    public final boolean addAll(int i, Collection collection) {
        a();
        i += this.f;
        z61 z61 = this.e;
        boolean addAll = z61.addAll(i, collection);
        if (addAll) {
            this.h = collection.size() + this.h;
            this.g = zi1.v(z61);
        }
        return addAll;
    }

    public final List subList(int i, int i2) {
        if (i < 0 || i > i2 || i2 > this.h) {
            FileProvider.a("fromIndex or toIndex are out of bounds");
        }
        a();
        int i3 = this.f;
        return new a91(this.e, i + i3, i2 + i3);
    }

    public final void clear() {
        if (this.h > 0) {
            a();
            int i = this.h;
            int i2 = this.f;
            i += i2;
            z61 z61 = this.e;
            z61.e(i2, i);
            this.h = 0;
            this.g = zi1.v(z61);
        }
    }

    public final boolean removeAll(Collection collection) {
        while (true) {
            boolean z = false;
            for (Object remove : collection) {
                if (remove(remove) || z) {
                    z = true;
                }
            }
            return z;
        }
    }

    public final boolean add(Object obj) {
        a();
        int i = this.f + this.h;
        z61 z61 = this.e;
        z61.add(i, obj);
        this.h++;
        this.g = zi1.v(z61);
        return true;
    }

    public final Object remove(int i) {
        a();
        int i2 = this.f + i;
        z61 z61 = this.e;
        Object remove = z61.remove(i2);
        this.h--;
        this.g = zi1.v(z61);
        return remove;
    }

    public final Object set(int i, Object obj) {
        zi1.j(i, this.h);
        a();
        i += this.f;
        z61 z61 = this.e;
        Object obj2 = z61.set(i, obj);
        this.g = zi1.v(z61);
        return obj2;
    }

    public final Object get(int i) {
        a();
        zi1.j(i, this.h);
        return this.e.get(this.f + i);
    }

    public final ListIterator listIterator(int i) {
        a();
        lw0 obj = new Object();
        obj.e = i - 1;
        return new ux0(obj, this);
    }

    public a91(z61 z61, int i, int i2) {
        this.e = z61;
        this.f = i;
        this.g = zi1.v(z61);
        this.h = i2 - i;
    }

    public final void a() {
        if (zi1.v(this.e) != this.g) {
            throw new ConcurrentModificationException();
        }
    }

    public final boolean contains(Object obj) {
        return indexOf(obj) >= 0;
    }

    public final boolean isEmpty() {
        return this.h == 0;
    }

    public final Iterator iterator() {
        return listIterator(0);
    }

    public final void add(int i, Object obj) {
        a();
        int i2 = this.f + i;
        z61 z61 = this.e;
        z61.add(i2, obj);
        this.h++;
        this.g = zi1.v(z61);
    }

    public final Object[] toArray() {
        return vd1.G(this);
    }

    public final int size() {
        return this.h;
    }

    public final boolean addAll(Collection collection) {
        return addAll(this.h, collection);
    }

    public final boolean remove(Object obj) {
        int indexOf = indexOf(obj);
        if (indexOf < 0) {
            return false;
        }
        remove(indexOf);
        return true;
    }

    public final ListIterator listIterator() {
        return listIterator(0);
    }

    public final Object[] toArray(Object[] objArr) {
        return vd1.H(this, objArr);
    }
}