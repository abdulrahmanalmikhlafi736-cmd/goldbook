package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: be */
public final class be implements jp {
    public nd e = this;
    public pg0 f;

    public final pg0 c(i00 i00) {
        pg0 ba0 = new ba0(17, false);
        ba0.f = i00;
        this.f = ba0;
        return ba0;
    }

    public final float a() {
        return this.e.a().a();
    }

    public final float g() {
        return this.e.a().g();
    }

    public final long V(float f) {
        return fu0.q(c0(f), this);
    }

    public final float b0(int i) {
        return ((float) i) / a();
    }

    public final float c0(float f) {
        return f / a();
    }

    public final float q(float f) {
        return a() * f;
    }

    public final /* synthetic */ int F(float f) {
        return fu0.k(f, this);
    }

    public final /* synthetic */ long K(long j) {
        return fu0.p(j, this);
    }

    public final /* synthetic */ float N(long j) {
        return fu0.o(j, this);
    }

    public final /* synthetic */ float y(long j) {
        return fu0.m(j, this);
    }
}