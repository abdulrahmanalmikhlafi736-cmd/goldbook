package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cq0 */
public final class cq0 {
    public final q6 a;
    public final int b;
    public final int c;

    public final String toString() {
        StringBuilder dl1 = new dl1("ParagraphIntrinsicInfo(intrinsics=");
        dl1.append(this.a);
        dl1.append(", startIndex=");
        dl1.append(this.b);
        dl1.append(", endIndex=");
        return fu0.G(dl1, this.c, ')');
    }

    /* JADX WARNING: Missing block: B:12:0x001d, code:
            if (r3.c != r4.c) goto L_0x001f;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean equals(Object obj) {
        if (this != obj) {
            if (obj instanceof cq0) {
                cq0 cq0 = (cq0) obj;
                if (this.a != cq0.a) {
                    return false;
                }
                if (this.b != cq0.b) {
                }
            }
            return false;
        }
        return true;
    }

    public final int hashCode() {
        return (((this.a.hashCode() * 31) + this.b) * 31) + this.c;
    }

    public cq0(q6 q6Var, int i, int i2) {
        this.a = q6Var;
        this.b = i;
        this.c = i2;
    }
}