package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ox0 */
public abstract class ox0 extends nx0 implements v00 {
    public final int f;

    public final String toString() {
        if (this.e != null) {
            return super.toString();
        }
        ow0.a.getClass();
        return pw0.a(this);
    }

    public ox0(int i, ml mlVar) {
        super(mlVar);
        this.f = i;
    }

    public final int b() {
        return this.f;
    }
}