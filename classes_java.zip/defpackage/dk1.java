package defpackage;

import android.graphics.Rect;
import android.os.Build.VERSION;
import android.view.View;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dk1 */
public class dk1 {
    public static final hk1 b;
    public final hk1 a;

    static {
        int i = VERSION.SDK_INT;
        uj1 tj1 = i >= 36 ? new tj1() : i >= 35 ? new sj1() : i >= 34 ? new rj1() : i >= 31 ? new qj1() : i >= 30 ? new pj1() : i >= 29 ? new oj1() : new nj1();
        b = tj1.b().a.a().a.b().a.c();
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof dk1)) {
            return false;
        }
        dk1 dk1 = (dk1) obj;
        return t() == dk1.t() && s() == dk1.s() && Objects.equals(n(), dk1.n()) && Objects.equals(l(), dk1.l()) && Objects.equals(h(), dk1.h());
    }

    public int hashCode() {
        Boolean valueOf = Boolean.valueOf(t());
        Boolean valueOf2 = Boolean.valueOf(s());
        c60 n = n();
        c60 l = l();
        mq h = h();
        return Objects.hash(new Object[]{valueOf, valueOf2, n, l, h});
    }

    public c60 j(int i) {
        if ((i & 8) == 0) {
            return c60.e;
        }
        od.m("Unable to query the maximum insets for IME");
        return null;
    }

    public dk1(hk1 hk1) {
        this.a = hk1;
    }

    public c60 k() {
        return n();
    }

    public c60 m() {
        return n();
    }

    public c60 o() {
        return n();
    }

    public hk1 a() {
        return this.a;
    }

    public hk1 b() {
        return this.a;
    }

    public hk1 c() {
        return this.a;
    }

    public List<Rect> f(int i) {
        return Collections.EMPTY_LIST;
    }

    public List<Rect> g(int i) {
        return Collections.EMPTY_LIST;
    }

    public c60 i(int i) {
        return c60.e;
    }

    public c60 l() {
        return c60.e;
    }

    public c60 n() {
        return c60.e;
    }

    public hk1 r(int i, int i2, int i3, int i4) {
        return b;
    }

    public mq h() {
        return null;
    }

    public boolean s() {
        return false;
    }

    public boolean t() {
        return false;
    }

    public boolean u(int i) {
        return true;
    }

    public void A(int i) {
    }

    public void B(Rect[][] rectArr) {
    }

    public void C(Rect[][] rectArr) {
    }

    public void d(View view) {
    }

    public void e(hk1 hk1) {
    }

    public void p(View view) {
    }

    public void q() {
    }

    public void v(oq oqVar) {
    }

    public void w(c60[] c60Arr) {
    }

    public void x(c60 c60) {
    }

    public void y(hk1 hk1) {
    }

    public void z(c60 c60) {
    }
}