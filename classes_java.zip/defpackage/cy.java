package defpackage;

import android.view.autofill.AutofillManager;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cy */
public final class cy {
    public final hy a;
    public final n4 b;
    public final ik0 c = new ik0();
    public final ik0 d = new ik0();
    public boolean e;

    public final void a() {
        if (!this.e) {
            e4 e4Var = new e4(0, this, cy.class, "invalidateNodes", "invalidateNodes()V", 0, 0, 1);
            ak0 ak0 = this.b.D0;
            if (((AutofillManager) ak0) < null) {
                ak0.a(e4Var);
            }
            this.e = true;
        }
    }

    public cy(hy hyVar, n4 n4Var) {
        this.a = hyVar;
        this.b = n4Var;
        ik0 ik0 = o01.a;
    }
}