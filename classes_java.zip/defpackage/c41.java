package defpackage;

/* renamed from: c41 */
public final class c41 extends nl {
    public /* synthetic */ Object h;
    public int i;
    public final /* synthetic */ gn j;

    public final Object p(Object obj) {
        this.h = obj;
        this.i |= Integer.MIN_VALUE;
        return this.j.k(null, this);
    }

    public c41(gn gnVar, ml mlVar) {
        this.j = gnVar;
        super(mlVar);
    }
}