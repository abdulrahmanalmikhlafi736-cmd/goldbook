package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: jh1 */
public interface jh1 {
    fh1 a(Class cls);

    fh1 b(Class cls, pj0 pj0);

    fh1 c(wf wfVar, pj0 pj0);
}