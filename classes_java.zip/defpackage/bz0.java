package defpackage;

import android.view.autofill.AutofillValue;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bz0 */
public final class bz0 implements ml, dm {
    public static final AtomicReferenceFieldUpdater f = AtomicReferenceFieldUpdater.newUpdater(bz0.class, Object.class, "result");
    public final ml e;
    private volatile Object result;

    public final AutofillValue h(Object obj) {
        while (true) {
            cm cmVar = this.result;
            cm cmVar2 = cm.f;
            if (cmVar == cmVar2) {
                AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = f;
                while (!atomicReferenceFieldUpdater.compareAndSet(this, cmVar2, obj)) {
                    if (atomicReferenceFieldUpdater.get(this) != cmVar2) {
                    }
                }
                return;
            }
            cmVar2 = cm.e;
            if (cmVar == cmVar2) {
                AtomicReferenceFieldUpdater atomicReferenceFieldUpdater2 = f;
                cm cmVar3 = cm.g;
                while (!atomicReferenceFieldUpdater2.compareAndSet(this, cmVar2, cmVar3)) {
                    if (atomicReferenceFieldUpdater2.get(this) != cmVar2) {
                    }
                }
                ((AutofillValue) this.e);
                return;
            }
            od.p("Already resumed");
            return;
        }
    }

    public final String toString() {
        StringBuilder dl1 = new dl1("SafeContinuation for ");
        dl1.append(this.e);
        return dl1.toString();
    }

    public final dm d() {
        ml mlVar = this.e;
        return mlVar instanceof dm ? (dm) mlVar : null;
    }

    public bz0(ml mlVar) {
        cm cmVar = cm.e;
        this.e = mlVar;
        this.result = cmVar;
    }

    public final sl e() {
        return this.e.e();
    }
}