package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: c2 */
public final /* synthetic */ class c2 implements m00 {
    public final /* synthetic */ wi1 e;
    public final /* synthetic */ mi0 f;
    public final /* synthetic */ boolean g;
    public final /* synthetic */ ui1 h;
    public final /* synthetic */ i00 i;
    public final /* synthetic */ i00 j;
    public final /* synthetic */ w1 k;
    public final /* synthetic */ v1 l;
    public final /* synthetic */ i00 m;
    public final /* synthetic */ int n;

    public final Object f(Object obj, Object obj2) {
        d10 d10 = (d10) obj;
        ((Integer) obj2).getClass();
        zi1.a(this.e, this.f, this.g, this.h, this.i, this.j, this.k, this.l, this.m, d10, wc0.s(this.n | 1));
        return we1.a;
    }

    public /* synthetic */ c2(wi1 wi1, mi0 mi0, boolean z, ui1 ui1, i00 i00, i00 i002, w1 w1Var, v1 v1Var, i00 i003, int i) {
        this.e = wi1;
        this.f = mi0;
        this.g = z;
        this.h = ui1;
        this.i = i00;
        this.j = i002;
        this.k = w1Var;
        this.l = v1Var;
        this.m = i003;
        this.n = i;
    }
}