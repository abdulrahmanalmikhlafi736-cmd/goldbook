package defpackage;

import android.graphics.Rect;
import android.view.WindowInsets;
import java.util.List;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ck1 */
public final class ck1 extends bk1 {
    public List<Rect> f(int i) {
        return this.c.getBoundingRects(gk1.a(i));
    }

    public List<Rect> g(int i) {
        return this.c.getBoundingRectsIgnoringVisibility(gk1.a(i));
    }

    public ck1(hk1 hk1, WindowInsets windowInsets) {
        super(hk1, windowInsets);
    }

    public ck1(hk1 hk1, ck1 ck1) {
        super(hk1, (bk1) ck1);
    }

    public void q() {
    }
}