package defpackage;

import android.app.ActionBar;
import android.app.Activity;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.util.SparseArray;
import android.view.KeyEvent;
import android.view.KeyEvent.DispatcherState;
import android.view.View;
import android.view.ViewParent;
import android.view.Window;
import java.lang.ref.WeakReference;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.WeakHashMap;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ji */
public abstract class ji extends Activity implements sd0 {
    public final ud0 e = new ud0(this, true);

    /* JADX WARNING: Removed duplicated region for block: B:27:0x006f  */
    /* JADX WARNING: Removed duplicated region for block: B:24:? A:{SYNTHETIC, Splitter: B:20:0x005b, ExcHandler: java.lang.IllegalAccessException (unused java.lang.IllegalAccessException)} */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        keyEvent.getClass();
        View decorView = getWindow().getDecorView();
        decorView.getClass();
        boolean z = true;
        if (wl1.t(decorView, keyEvent)) {
            return true;
        }
        if (VERSION.SDK_INT >= 28) {
            return super.dispatchKeyEvent(keyEvent);
        }
        onUserInteraction();
        Window window = getWindow();
        int i = 0;
        if (window.hasFeature(8)) {
            ActionBar actionBar = getActionBar();
            if (keyEvent.getKeyCode() == 82 && actionBar != null) {
                boolean booleanValue;
                if (!wl1.x) {
                    try {
                        wl1.y = actionBar.getClass().getMethod("onMenuKeyEvent", new Class[]{KeyEvent.class});
                    } catch (NoSuchMethodException unused) {
                    }
                    wl1.x = true;
                }
                Method method = wl1.y;
                if (method != null) {
                    try {
                        Object invoke = method.invoke(actionBar, new Object[]{keyEvent});
                        if (invoke != null) {
                            booleanValue = ((Boolean) invoke).booleanValue();
                            if (booleanValue) {
                                return z;
                            }
                        }
                    } catch (IllegalAccessException unused2) {
                    }
                }
                booleanValue = false;
                if (booleanValue) {
                }
            }
        }
        if (!window.superDispatchKeyEvent(keyEvent)) {
            decorView = window.getDecorView();
            int i2 = vg1.a;
            DispatcherState dispatcherState = null;
            if (VERSION.SDK_INT < 28) {
                int size;
                ArrayList arrayList = ug1.d;
                ug1 ug1 = (ug1) decorView.getTag(2131034212);
                if (ug1 == null) {
                    ug1 = new Object();
                    ug1.a = null;
                    ug1.b = null;
                    ug1.c = null;
                    decorView.setTag(2131034212, ug1);
                }
                if (keyEvent.getAction() == 0) {
                    WeakHashMap weakHashMap = ug1.a;
                    if (weakHashMap != null) {
                        weakHashMap.clear();
                    }
                    arrayList = ug1.d;
                    if (!arrayList.isEmpty()) {
                        synchronized (arrayList) {
                            try {
                                if (ug1.a == null) {
                                    ug1.a = new WeakHashMap();
                                }
                                for (size = arrayList.size() - 1; size >= 0; size--) {
                                    ArrayList arrayList2 = ug1.d;
                                    View view = (View) ((WeakReference) arrayList2.get(size)).get();
                                    if (view == null) {
                                        arrayList2.remove(size);
                                    } else {
                                        ug1.a.put(view, Boolean.TRUE);
                                        for (ViewParent parent = view.getParent(); parent instanceof View; parent = parent.getParent()) {
                                            ug1.a.put((View) parent, Boolean.TRUE);
                                        }
                                    }
                                }
                            } finally {
                            }
                        }
                    }
                }
                View a = ug1.a(decorView);
                if (keyEvent.getAction() == 0) {
                    size = keyEvent.getKeyCode();
                    if (!(a == null || KeyEvent.isModifierKey(size))) {
                        if (ug1.b == null) {
                            ug1.b = new SparseArray();
                        }
                        ug1.b.put(size, new WeakReference(a));
                    }
                }
                if (a != null) {
                    i = 1;
                }
            }
            if (i == 0) {
                if (decorView != null) {
                    dispatcherState = decorView.getKeyDispatcherState();
                }
                z = keyEvent.dispatch(this, dispatcherState, this);
            }
        }
        return z;
    }

    public final boolean dispatchKeyShortcutEvent(KeyEvent keyEvent) {
        keyEvent.getClass();
        View decorView = getWindow().getDecorView();
        decorView.getClass();
        return wl1.t(decorView, keyEvent) ? true : super.dispatchKeyShortcutEvent(keyEvent);
    }

    public void onSaveInstanceState(Bundle bundle) {
        bundle.getClass();
        ud0 ud0 = this.e;
        ud0.c("setCurrentState");
        ud0.e(jd0.g);
        super.onSaveInstanceState(bundle);
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        int i = ix0.f;
        gx0.b(this);
    }
}