package defpackage;

import android.content.Context;
import android.graphics.Typeface;
import android.net.Uri;
import android.util.Log;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.util.List;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ae1 */
public final class ae1 extends jb0 {
    public static final Class b;
    public static final Constructor c;
    public static final Method d;
    public static final Method e;

    /* JADX WARNING: Removed duplicated region for block: B:19:? A:{SYNTHETIC, Splitter: B:16:0x0034, ExcHandler: java.lang.IllegalAccessException (unused java.lang.IllegalAccessException)} */
    /* JADX WARNING: Removed duplicated region for block: B:26:? A:{SYNTHETIC, Splitter: B:23:0x0064, ExcHandler: java.lang.IllegalAccessException (unused java.lang.IllegalAccessException)} */
    /* JADX WARNING: Removed duplicated region for block: B:4:? A:{SYNTHETIC, Splitter: B:1:0x0001, ExcHandler: java.lang.IllegalAccessException (unused java.lang.IllegalAccessException)} */
    /* JADX WARNING: Removed duplicated region for block: B:4:? A:{SYNTHETIC, Splitter: B:1:0x0001, ExcHandler: java.lang.IllegalAccessException (unused java.lang.IllegalAccessException)} */
    /* JADX WARNING: Missing block: B:3:0x0008, code:
            r0 = null;
     */
    /* JADX WARNING: Missing block: B:18:0x005d, code:
            r5 = false;
     */
    /* JADX WARNING: Missing block: B:25:0x007a, code:
            r13 = null;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final Typeface e(Context context, rz[] rzVarArr) {
        Object newInstance;
        try {
            newInstance = c.newInstance(null);
        } catch (IllegalAccessException unused) {
        }
        if (newInstance != null) {
            Typeface typeface;
            m51 m51 = new m51();
            for (rz rzVar : rzVarArr) {
                Uri uri = rzVar.a;
                ByteBuffer byteBuffer = (ByteBuffer) m51.get(uri);
                if (byteBuffer == null) {
                    byteBuffer = kb0.t(context, uri);
                    m51.put(uri, byteBuffer);
                }
                if (byteBuffer == null) {
                    break;
                }
                boolean booleanValue;
                int i = rzVar.b;
                int i2 = rzVar.c;
                boolean z = rzVar.d;
                try {
                    Method method = d;
                    Integer valueOf = Integer.valueOf(i);
                    Integer valueOf2 = Integer.valueOf(i2);
                    Boolean valueOf3 = Boolean.valueOf(z);
                    booleanValue = ((Boolean) method.invoke(newInstance, new Object[]{byteBuffer, valueOf, null, valueOf2, valueOf3})).booleanValue();
                } catch (IllegalAccessException unused2) {
                }
                if (!booleanValue) {
                    break;
                }
            }
            try {
                Array.set(Array.newInstance(b, 1), 0, newInstance);
                typeface = (Typeface) e.invoke(null, new Object[]{r13});
            } catch (IllegalAccessException unused3) {
            }
            if (typeface != null) {
                return Typeface.create(typeface, 0);
            }
        }
        return null;
    }

    static {
        Class cls;
        Method method;
        Method method2;
        Object e;
        Constructor constructor = null;
        try {
            cls = Class.forName("android.graphics.FontFamily");
            Constructor constructor2 = cls.getConstructor(null);
            r4 = new Class[5];
            Class cls2 = Integer.TYPE;
            r4[1] = cls2;
            r4[2] = List.class;
            r4[3] = cls2;
            r4[4] = Boolean.TYPE;
            method = cls.getMethod("addFontWeightStyle", r4);
            constructor = Typeface.class.getMethod("createFromFamiliesWithDefault", new Class[]{Array.newInstance(cls, 1).getClass()});
            Constructor constructor3 = constructor2;
            method2 = constructor;
            constructor = constructor3;
        } catch (ClassNotFoundException e2) {
            e = e2;
            Log.e("TypefaceCompatApi24Impl", e.getClass().getName(), e);
            cls = constructor;
            method2 = cls;
            method = method2;
            c = constructor;
            b = cls;
            d = method;
            e = method2;
        } catch (NoSuchMethodException e3) {
            e = e3;
            Log.e("TypefaceCompatApi24Impl", e.getClass().getName(), e);
            cls = constructor;
            method2 = cls;
            method = method2;
            c = constructor;
            b = cls;
            d = method;
            e = method2;
        }
        c = constructor;
        b = cls;
        d = method;
        e = method2;
    }
}