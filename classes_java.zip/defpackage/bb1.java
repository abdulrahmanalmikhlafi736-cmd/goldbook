package defpackage;

import java.util.List;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bb1 */
public final class bb1 {
    public final x8 a;
    public final ob1 b;
    public final List c;
    public final int d;
    public final boolean e;
    public final int f;
    public final jp g;
    public final o90 h;
    public final yy i;
    public final long j;

    public final String toString() {
        StringBuilder dl1 = new dl1("TextLayoutInput(text=");
        dl1.append(this.a);
        dl1.append(", style=");
        dl1.append(this.b);
        dl1.append(", placeholders=");
        dl1.append(this.c);
        dl1.append(", maxLines=");
        dl1.append(this.d);
        dl1.append(", softWrap=");
        dl1.append(this.e);
        dl1.append(", overflow=");
        int i = this.f;
        Object obj = i == 1 ? "Clip" : i == 2 ? "Ellipsis" : i == 5 ? "MiddleEllipsis" : i == 3 ? "Visible" : i == 4 ? "StartEllipsis" : "Invalid";
        dl1.append(obj);
        dl1.append(", density=");
        dl1.append(this.g);
        dl1.append(", layoutDirection=");
        dl1.append(this.h);
        dl1.append(", fontFamilyResolver=");
        dl1.append(this.i);
        dl1.append(", constraints=");
        dl1.append(sk.k(this.j));
        dl1.append(')');
        return dl1.toString();
    }

    public final boolean equals(Object obj) {
        if (this != obj) {
            if (obj instanceof bb1) {
                bb1 bb1 = (bb1) obj;
                if (k70.p(this.a, bb1.a)) {
                    if (k70.p(this.b, bb1.b)) {
                        if (this.c.equals(bb1.c)) {
                            if (this.d == bb1.d) {
                                if (this.e == bb1.e) {
                                    if (this.f == bb1.f) {
                                        if (k70.p(this.g, bb1.g)) {
                                            if (this.h == bb1.h) {
                                                if (k70.p(this.i, bb1.i)) {
                                                    if (n60.b(this.j, bb1.j) == null) {
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return false;
        }
        return true;
    }

    public final int hashCode() {
        int hashCode = (this.i.hashCode() + ((this.h.hashCode() + ((this.g.hashCode() + ((((((((this.c.hashCode() + fu0.B(this.b, this.a.hashCode() * 31, 31)) * 31) + this.d) * 31) + (this.e ? 1231 : 1237)) * 31) + this.f) * 31)) * 31)) * 31)) * 31;
        long j = this.j;
        return ((int) (j ^ (j >>> 32))) + hashCode;
    }

    public bb1(x8 x8Var, ob1 ob1, List list, int i, boolean z, int i2, jp jpVar, o90 o90, yy yyVar, long j) {
        this.a = x8Var;
        this.b = ob1;
        this.c = list;
        this.d = i;
        this.e = z;
        this.f = i2;
        this.g = jpVar;
        this.h = o90;
        this.i = yyVar;
        this.j = j;
    }
}