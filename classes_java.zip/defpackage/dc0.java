package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dc0 */
public final class dc0 extends li0 implements g21 {
    public xz s;
    public yb0 t;
    public bp0 u;
    public boolean v;
    public u01 w;
    public final ac0 x = new ac0(this, 0);
    public ac0 y;

    public final void Q(r21 r21) {
        a90[] a90Arr = p21.a;
        q21 q21 = n21.n;
        a90[] a90Arr2 = p21.a;
        a90 a90 = a90Arr2[6];
        r21.a(q21, Boolean.TRUE);
        r21.a(n21.L, this.x);
        bp0 bp0 = this.u;
        u01 u01 = this.w;
        String str = "scrollAxisRange";
        a90 a902;
        if (bp0 == bp0.e) {
            if (u01 != null) {
                q21 = n21.w;
                a902 = a90Arr2[13];
                r21.a(q21, u01);
            } else {
                k70.T(str);
                throw null;
            }
        } else if (u01 != null) {
            q21 = n21.v;
            a902 = a90Arr2[12];
            r21.a(q21, u01);
        } else {
            k70.T(str);
            throw null;
        }
        ac0 ac0 = this.y;
        if (ac0 != null) {
            r21.a(c21.f, new o0(null, ac0));
        }
        r21.a(c21.B, new o0(null, new j3(22, new bc0(this, 2))));
        yb0 yb0 = this.t;
        yb0.getClass();
        sg xo0 = new xo0(1, ((Number) yb0.a.getValue()).intValue());
        q21 q212 = n21.f;
        a90 a903 = a90Arr2[23];
        r21.a(q212, xo0);
    }

    public final void r0() {
        this.w = new u01(new bc0(this, 0), new bc0(this, 1));
        this.y = this.v ? new ac0(this, 1) : null;
    }

    public dc0(xz xzVar, yb0 yb0, bp0 bp0, boolean z) {
        this.s = xzVar;
        this.t = yb0;
        this.u = bp0;
        this.v = z;
        r0();
    }

    public final /* synthetic */ boolean S() {
        return false;
    }

    public final /* synthetic */ boolean T() {
        return false;
    }

    public final /* synthetic */ boolean e() {
        return true;
    }

    public final boolean e0() {
        return false;
    }
}