package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ar */
public final class ar implements sl {
    public final /* synthetic */ sl e;
    public final Throwable f;

    public ar(sl slVar, Throwable th) {
        this.e = slVar;
        this.f = th;
    }

    public final sl i(sl slVar) {
        return this.e.i(slVar);
    }

    public final ql k(rl rlVar) {
        return this.e.k(rlVar);
    }

    public final Object p(m00 m00, Object obj) {
        return this.e.p(m00, obj);
    }

    public final sl t(rl rlVar) {
        return this.e.t(rlVar);
    }
}