package defpackage;

import android.view.WindowInsetsController;
import android.view.WindowInsetsController.OnControllableInsetsChangedListener;
import java.util.concurrent.atomic.AtomicBoolean;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: d71 */
public final /* synthetic */ class d71 implements OnControllableInsetsChangedListener {
    public final /* synthetic */ AtomicBoolean a;

    public final void onControllableInsetsChanged(WindowInsetsController windowInsetsController, int i) {
        this.a.set((i & 8) != 0);
    }

    public /* synthetic */ d71(AtomicBoolean atomicBoolean) {
        this.a = atomicBoolean;
    }
}