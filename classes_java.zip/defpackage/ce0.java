package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ce0 */
public final class ce0 {
    public static final int b = 66305;
    public final int a;

    public static String a(int i) {
        StringBuilder dl1 = new dl1("LineBreak(strategy=");
        int i2 = i & 255;
        Object obj = "Invalid";
        Object obj2 = i2 == 1 ? "Strategy.Simple" : i2 == 2 ? "Strategy.HighQuality" : i2 == 3 ? "Strategy.Balanced" : i2 == 0 ? "Strategy.Unspecified" : obj;
        dl1.append(obj2);
        dl1.append(", strictness=");
        i2 = (i >> 8) & 255;
        obj2 = i2 == 1 ? "Strictness.None" : i2 == 2 ? "Strictness.Loose" : i2 == 3 ? "Strictness.Normal" : i2 == 4 ? "Strictness.Strict" : i2 == 0 ? "Strictness.Unspecified" : obj;
        dl1.append(obj2);
        dl1.append(", wordBreak=");
        i = (i >> 16) & 255;
        if (i == 1) {
            obj = "WordBreak.None";
        } else if (i == 2) {
            obj = "WordBreak.Phrase";
        } else if (i == 0) {
            obj = "WordBreak.Unspecified";
        }
        dl1.append(obj);
        dl1.append(')');
        return dl1.toString();
    }

    public final boolean equals(Object obj) {
        if (obj instanceof ce0) {
            if (this.a == ((ce0) obj).a) {
                return true;
            }
        }
        return false;
    }

    public final String toString() {
        return ce0.a(this.a);
    }

    public /* synthetic */ ce0(int i) {
        this.a = i;
    }

    public final int hashCode() {
        return this.a;
    }
}