package defpackage;

import android.content.Context;
import java.util.List;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: l50 */
public interface l50 {
    List a();

    Object b(Context context);
}