package defpackage;

import android.view.View;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: d */
public final class d extends u91 implements m00 {
    public final /* synthetic */ int i;
    public int j;
    public Object k;
    public final /* synthetic */ Object l;

    /* JADX WARNING: Removed duplicated region for block: B:100:0x01cc  */
    /* JADX WARNING: Missing block: B:8:0x0039, code:
            if (r0.b(r1, r15) == r11) goto L_0x003b;
     */
    /* JADX WARNING: Missing block: B:102:0x01d5, code:
            if (r0.f(r1, r15) == r11) goto L_0x01d7;
     */
    /* JADX WARNING: Missing block: B:170:0x0328, code:
            if (defpackage.tp.a(r1, r2, r3, r4, r5, r15) != r11) goto L_0x02ed;
     */
    /* JADX WARNING: Missing block: B:267:0x0497, code:
            if (r0 != r11) goto L_0x0455;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final Object p(Object obj) {
        int i = this.i;
        float f = 1.0f;
        Object obj2 = we1.a;
        Object obj3 = this.l;
        String str = "call to 'resume' before 'invoke' with coroutine";
        Object obj4 = cm.e;
        Object obj5 = null;
        uj0 uj0;
        g51 g51;
        int i2;
        Object a;
        Object b;
        m00 m00;
        nw nwVar;
        float f2;
        bm bmVar;
        float q;
        y11 y11;
        xq alVar;
        switch (i) {
            case 0:
                i = this.j;
                if (i == 0) {
                    nb0.t(obj);
                    uj0 = (uj0) this.k;
                    m30 m30 = (m30) obj3;
                    this.j = 1;
                    if (uj0.a(m30, this) == obj4) {
                        obj2 = obj4;
                    }
                } else if (i == 1) {
                    nb0.t(obj);
                } else {
                    od.p(str);
                    obj2 = null;
                }
                return obj2;
            case 1:
                i = this.j;
                if (i == 0) {
                    nb0.t(obj);
                    uj0 = (uj0) this.k;
                    n30 n30 = (n30) obj3;
                    this.j = 1;
                    if (uj0.a(n30, this) == obj4) {
                        obj2 = obj4;
                    }
                } else if (i == 1) {
                    nb0.t(obj);
                } else {
                    od.p(str);
                    obj2 = null;
                }
                return obj2;
            case 2:
                i = this.j;
                if (i == 0) {
                    nb0.t(obj);
                    rc rcVar = (rc) this.k;
                    f8 f8Var = new f8(1, (gw0) obj3);
                    this.j = 1;
                    if (vd1.g(rcVar, f8Var, this) == obj4) {
                        obj2 = obj4;
                    }
                } else if (i == 1) {
                    nb0.t(obj);
                } else {
                    od.p(str);
                    obj2 = null;
                }
                return obj2;
            case 3:
                i = this.j;
                if (i == 0) {
                    nb0.t(obj);
                    vc vcVar = (vc) this.k;
                    na naVar = (na) obj3;
                    this.j = 1;
                    if (vd1.g(vcVar, naVar, this) == obj4) {
                        obj2 = obj4;
                    }
                } else if (i == 1) {
                    nb0.t(obj);
                } else {
                    od.p(str);
                    obj2 = null;
                }
                return obj2;
            case gu0.LONG_FIELD_NUMBER /*4*/:
                i = this.j;
                if (i == 0) {
                    nb0.t(obj);
                    g51 = ((uj0) this.k).a;
                    rd rdVar = new rd(0, (z61) obj3);
                    this.j = 1;
                    g51.getClass();
                    g51.j(g51, rdVar, this);
                    obj2 = obj4;
                } else if (i == 1) {
                    nb0.t(obj);
                } else {
                    od.p(str);
                    obj2 = null;
                }
                return obj2;
            case gu0.STRING_FIELD_NUMBER /*5*/:
                cj cjVar = (cj) this.k;
                i2 = this.j;
                if (i2 == 0) {
                    nb0.t(obj);
                    tw0 tw0 = cjVar.f;
                    this.j = 1;
                    a = tw0.a(0.0f - tw0.c, this);
                    if (a != obj4) {
                        a = obj2;
                    }
                    if (a == obj4) {
                        obj2 = obj4;
                        return obj2;
                    }
                } else if (i2 == 1) {
                    nb0.t(obj);
                } else {
                    od.p(str);
                    obj2 = null;
                    return obj2;
                }
                cjVar.c.a.setValue(Boolean.FALSE);
                ((Runnable) obj3).run();
                return obj2;
            case gu0.STRING_SET_FIELD_NUMBER /*6*/:
                i = this.j;
                if (i == 0) {
                    nb0.t(obj);
                    zm zmVar = (zm) this.k;
                    List list = (List) obj3;
                    this.j = 1;
                    if (a5.f(list, zmVar, this) == obj4) {
                        obj2 = obj4;
                    }
                } else if (i == 1) {
                    nb0.t(obj);
                } else {
                    od.p(str);
                    obj2 = null;
                }
                return obj2;
            case gu0.DOUBLE_FIELD_NUMBER /*7*/:
                qh0 qh0 = (qh0) obj3;
                tn tnVar = (tn) this.k;
                i2 = this.j;
                m00 m002;
                sl slVar;
                if (i2 != 0) {
                    if (i2 != 1) {
                        if (i2 == 2) {
                            nb0.t(obj);
                            m002 = qh0.a;
                            slVar = qh0.d;
                            this.j = 3;
                            b = tnVar.h().b(new qn(tnVar, slVar, m002, null), this);
                            break;
                        } else if (i2 != 3) {
                            od.p(str);
                            return obj5;
                        }
                    }
                    nb0.t(obj);
                    obj5 = obj;
                    return obj5;
                }
                nb0.t(obj);
                z71 o = tnVar.k.o();
                if (o instanceof qm) {
                    m002 = qh0.a;
                    slVar = qh0.d;
                    this.j = 1;
                    b = tnVar.h().b(new qn(tnVar, slVar, m002, null), this);
                    if (b == obj4) {
                    }
                } else {
                    if (!(o instanceof sv0)) {
                        if (!(o instanceof qe1)) {
                            if (o instanceof xv) {
                                throw ((xv) o).b;
                            }
                            if (o instanceof am0) {
                                od.p("This is a bug in DataStore. Please file a bug at: https://issuetracker.google.com/issues/new?component=907884&template=1466542");
                            } else {
                                od.k();
                            }
                            return obj5;
                        }
                    }
                    if (o == qh0.c) {
                        this.j = 2;
                        if (tn.e(tnVar, this) == obj4) {
                        }
                        m002 = qh0.a;
                        slVar = qh0.d;
                        this.j = 3;
                        b = tnVar.h().b(new qn(tnVar, slVar, m002, null), this);
                    } else {
                        throw ((sv0) o).b;
                    }
                }
                obj5 = obj4;
                return obj5;
                obj5 = b;
                return obj5;
            case 8:
                i = this.j;
                if (i == 0) {
                    nb0.t(obj);
                    m00 = (m00) this.k;
                    a = ((qm) obj3).b;
                    this.j = 1;
                    b = m00.f(a, this);
                    if (b == obj4) {
                        b = obj4;
                    }
                } else if (i == 1) {
                    nb0.t(obj);
                    b = obj;
                } else {
                    od.p(str);
                    b = null;
                }
                return b;
            case 9:
                i = this.j;
                if (i == 0) {
                    nb0.t(obj);
                    qh0 qh02 = (qh0) this.k;
                    tn tnVar2 = (tn) obj3;
                    this.j = 1;
                    if (tn.b(tnVar2, qh02, this) == obj4) {
                        obj2 = obj4;
                    }
                } else if (i == 1) {
                    nb0.t(obj);
                } else {
                    od.p(str);
                    obj2 = null;
                }
                return obj2;
            case 10:
                i = this.j;
                if (i == 0) {
                    nb0.t(obj);
                    nwVar = (nw) this.k;
                    kw kwVar = (kw) obj3;
                    float f3 = kwVar.a;
                    float f4 = kwVar.b;
                    float f5 = kwVar.d;
                    f2 = kwVar.c;
                    this.j = 1;
                    nwVar.a = f3;
                    nwVar.b = f4;
                    nwVar.c = f5;
                    nwVar.d = f2;
                    b = nwVar.b(this);
                    if (b != obj4) {
                        b = obj2;
                    }
                    if (b == obj4) {
                        obj2 = obj4;
                    }
                } else if (i == 1) {
                    nb0.t(obj);
                } else {
                    od.p(str);
                    obj2 = null;
                }
                return obj2;
            case 11:
                i = this.j;
                if (i == 0) {
                    nb0.t(obj);
                    nwVar = (nw) this.k;
                    y60 y60 = (y60) obj3;
                    this.j = 1;
                    if (nwVar.a(y60, this) == obj4) {
                        obj2 = obj4;
                    }
                } else if (i == 1) {
                    nb0.t(obj);
                } else {
                    od.p(str);
                    obj2 = null;
                }
                return obj2;
            case 12:
                a80 B;
                i = this.j;
                if (i == 0) {
                    nb0.t(obj);
                    B = wl1.B((bm) this.k, null, new ao(2, null), 3);
                    ye yeVar = (ye) obj3;
                    this.k = B;
                    this.j = 1;
                    b = yeVar.m(this);
                    if (b == obj4) {
                        return obj4;
                    }
                } else if (i == 1) {
                    B = (a80) this.k;
                    try {
                        nb0.t(obj);
                        b = obj;
                    } catch (Throwable th) {
                        B.a(null);
                    }
                } else {
                    od.p(str);
                    obj4 = null;
                    return obj4;
                }
                obj4 = (aj0) b;
                B.a(null);
                return obj4;
            case 13:
                Object obj6;
                aj0 aj0;
                tp tpVar = (tp) obj3;
                i = this.j;
                if (i != 0) {
                    if (i == 1) {
                        bmVar = (bm) this.k;
                        nb0.t(obj);
                        obj6 = obj;
                        aj0 = (aj0) obj6;
                        f2 = ((jp) tpVar.e).q(6.0f);
                        q = ((jp) tpVar.e).q(1.0f);
                        y11 = (y11) tpVar.b;
                        this.k = bmVar;
                        this.j = 2;
                        break;
                    } else if (i == 2) {
                        bmVar = (bm) this.k;
                        try {
                            nb0.t(obj);
                        } catch (Throwable th2) {
                            tpVar.g = null;
                        }
                    } else {
                        od.p(str);
                        obj2 = null;
                        return obj2;
                    }
                }
                nb0.t(obj);
                bmVar = (bm) this.k;
                if (j70.L(bmVar.f())) {
                    id idVar = (id) tpVar.f;
                    this.k = bmVar;
                    this.j = 1;
                    obj6 = idVar.m(this);
                    if (obj6 == obj4) {
                        obj2 = obj4;
                        return obj2;
                    }
                    aj0 = (aj0) obj6;
                    f2 = ((jp) tpVar.e).q(6.0f);
                    q = ((jp) tpVar.e).q(1.0f);
                    y11 = (y11) tpVar.b;
                    this.k = bmVar;
                    this.j = 2;
                }
                tpVar.g = null;
                return obj2;
            case 14:
                i = this.j;
                if (i == 0) {
                    nb0.t(obj);
                    y11 y112 = (y11) this.k;
                    m00 m003 = (m00) obj3;
                    this.j = 1;
                    if (y112.f(tk0.f, m003, this) == obj4) {
                        obj2 = obj4;
                    }
                } else if (i == 1) {
                    nb0.t(obj);
                } else {
                    od.p(str);
                    obj2 = null;
                }
                return obj2;
            case 15:
                i = this.j;
                if (i == 0) {
                    nb0.t(obj);
                    bmVar = (bm) this.k;
                    y6 y6Var = (y6) obj3;
                    g51 g512 = y6Var.s.a;
                    alVar = new al(3, y6Var, bmVar);
                    this.j = 1;
                    g512.getClass();
                    g51.j(g512, alVar, this);
                    obj2 = obj4;
                } else if (i == 1) {
                    nb0.t(obj);
                } else {
                    od.p(str);
                    obj2 = null;
                }
                return obj2;
            case 16:
                i = this.j;
                if (i == 0) {
                    nb0.t(obj);
                    or orVar = (or) this.k;
                    if (orVar.b) {
                        f = -1.0f;
                    }
                    y11 = ((q11) obj3).R;
                    long j = orVar.a;
                    q = Float.intBitsToFloat((int) (j >> 32)) * f;
                    j = (((long) Float.floatToRawIntBits(q)) << 32) | (((long) Float.floatToRawIntBits(Float.intBitsToFloat((int) (j & 4294967295L)) * f)) & 4294967295L);
                    this.j = 1;
                    if (y11.b(j, false, this) == obj4) {
                        obj2 = obj4;
                    }
                } else if (i == 1) {
                    nb0.t(obj);
                } else {
                    od.p(str);
                    obj2 = null;
                }
                return obj2;
            case 17:
                i = this.j;
                if (i == 0) {
                    nb0.t(obj);
                    n41 n41 = ((t41) this.k).c;
                    obj3 = (String) obj3;
                    this.j = 1;
                    b = wa0.h(cl1.a(n41.a), new ao(obj3, null, 5), this);
                    if (b != obj4) {
                        b = obj2;
                    }
                    if (b == obj4) {
                        obj2 = obj4;
                    }
                } else if (i == 1) {
                    nb0.t(obj);
                } else {
                    od.p(str);
                    obj2 = null;
                }
                return obj2;
            case 18:
                p3 p3Var = (p3) obj3;
                i = this.j;
                id idVar2;
                if (i == 0) {
                    nb0.t(obj);
                    if (((AtomicInteger) ((pg0) p3Var.h).f).get() <= 0) {
                        od.p("Check failed.");
                    }
                    j70.B(((bm) p3Var.e).f());
                    m00 = (d) p3Var.f;
                    idVar2 = (id) p3Var.g;
                    this.k = m00;
                    this.j = 1;
                    a = idVar2.m(this);
                    if (a == obj4) {
                    }
                    this.k = null;
                    this.j = 2;
                } else if (i == 1) {
                    m00 = (d) this.k;
                    nb0.t(obj);
                    a = obj;
                    this.k = null;
                    this.j = 2;
                } else if (i == 2) {
                    nb0.t(obj);
                    if (((AtomicInteger) ((pg0) p3Var.h).f).decrementAndGet() == 0) {
                        return obj2;
                    }
                    j70.B(((bm) p3Var.e).f());
                    m00 = (d) p3Var.f;
                    idVar2 = (id) p3Var.g;
                    this.k = m00;
                    this.j = 1;
                    a = idVar2.m(this);
                    if (a == obj4) {
                        obj2 = obj4;
                        return obj2;
                    }
                    this.k = null;
                    this.j = 2;
                    break;
                } else {
                    od.p(str);
                }
                obj2 = null;
                return obj2;
            case 19:
                i = this.j;
                if (i == 0) {
                    nb0.t(obj);
                    tw twVar = (tw) this.k;
                    w61 w61 = new w61((xu0) obj3, 1);
                    this.j = 1;
                    if (twVar.b(w61, this) == obj4) {
                        obj2 = obj4;
                    }
                } else if (i == 1) {
                    nb0.t(obj);
                } else {
                    od.p(str);
                    obj2 = null;
                }
                return obj2;
            case 20:
                i = this.j;
                if (i == 0) {
                    nb0.t(obj);
                    j91 j91 = (j91) obj3;
                    alVar = new al(4, new Object(), (uw) this.k);
                    this.j = 1;
                    j91.b(alVar, this);
                } else if (i != 1) {
                    od.p(str);
                    obj4 = null;
                } else {
                    nb0.t(obj);
                    throw new RuntimeException();
                }
                return obj4;
            case 21:
                i = this.j;
                if (i == 0) {
                    nb0.t(obj);
                    c8 c8Var = (c8) ((rf) this.k).c;
                    Float br0 = new br0(0.0f);
                    o8 o8Var = (o8) obj3;
                    this.j = 1;
                    if (c8.c(c8Var, br0, o8Var, this) == obj4) {
                        obj2 = obj4;
                    }
                } else if (i == 1) {
                    nb0.t(obj);
                } else {
                    od.p(str);
                    obj2 = null;
                }
                return obj2;
            case 22:
                i = this.j;
                if (i == 0) {
                    nb0.t(obj);
                    b = this.k;
                    uw uwVar = (uw) obj3;
                    this.j = 1;
                    if (uwVar.k(b, this) == obj4) {
                        obj2 = obj4;
                    }
                } else if (i == 1) {
                    nb0.t(obj);
                } else {
                    od.p(str);
                    obj2 = null;
                }
                return obj2;
            case 23:
                i = this.j;
                if (i == 0) {
                    nb0.t(obj);
                    cz0 C = mc0.C(new x1(22, (wi1) this.k));
                    ki1 obj7 = new Object();
                    this.j = 1;
                    if (C.b(obj7, this) == obj4) {
                        obj2 = obj4;
                    }
                } else if (i == 1) {
                    nb0.t(obj);
                } else {
                    od.p(str);
                    obj2 = null;
                }
                return obj2;
            case 24:
                i = this.j;
                if (i == 0) {
                    nb0.t(obj);
                    g51 = ((ui1) this.k).c;
                    oi1 dl1 = new dl1((String) obj3);
                    this.j = 1;
                    if (g51.k(dl1, this) == obj4) {
                        obj2 = obj4;
                    }
                } else if (i == 1) {
                    nb0.t(obj);
                } else {
                    od.p(str);
                    obj2 = null;
                }
                return obj2;
            case 25:
                dw0 dw0 = (dw0) this.k;
                View view = (View) obj3;
                i = this.j;
                if (i == 0) {
                    nb0.t(obj);
                    this.j = 1;
                    b = wl1.y(dw0.u, new a7(2, null, 1), this);
                    if (b != obj4) {
                        b = obj2;
                    }
                    if (b == obj4) {
                        obj2 = obj4;
                        return obj2;
                    }
                } else if (i == 1) {
                    try {
                        nb0.t(obj);
                    } catch (Throwable th3) {
                        if (b9.b(view) == dw0) {
                            view.setTag(2131034155, null);
                        }
                    }
                } else {
                    od.p(str);
                    obj2 = null;
                    return obj2;
                }
                if (b9.b(view) == dw0) {
                    view.setTag(2131034155, null);
                }
                return obj2;
            default:
                i = this.j;
                if (i == 0) {
                    nb0.t(obj);
                    b81 b81 = (b81) this.k;
                    rd rdVar2 = new rd(4, (ti0) obj3);
                    this.j = 1;
                    break;
                } else if (i != 1) {
                    od.p(str);
                    obj4 = null;
                } else {
                    nb0.t(obj);
                    throw new RuntimeException();
                }
                return obj4;
        }
    }

    public final Object f(Object obj, Object obj2) {
        int i = this.i;
        cm cmVar = cm.e;
        we1 we1 = we1.a;
        switch (i) {
            case 0:
                return ((d) n((ml) obj2, (bm) obj)).p(we1);
            case 1:
                return ((d) n((ml) obj2, (bm) obj)).p(we1);
            case 2:
                return ((d) n((ml) obj2, (bm) obj)).p(we1);
            case 3:
                return ((d) n((ml) obj2, (bm) obj)).p(we1);
            case gu0.LONG_FIELD_NUMBER /*4*/:
                return ((d) n((ml) obj2, (bm) obj)).p(we1);
            case gu0.STRING_FIELD_NUMBER /*5*/:
                return ((d) n((ml) obj2, (bm) obj)).p(we1);
            case gu0.STRING_SET_FIELD_NUMBER /*6*/:
                return ((d) n((ml) obj2, (zm) obj)).p(we1);
            case gu0.DOUBLE_FIELD_NUMBER /*7*/:
                return ((d) n((ml) obj2, (bm) obj)).p(we1);
            case 8:
                return ((d) n((ml) obj2, (bm) obj)).p(we1);
            case 9:
                return ((d) n((ml) obj2, (qh0) obj)).p(we1);
            case 10:
                return ((d) n((ml) obj2, (bm) obj)).p(we1);
            case 11:
                return ((d) n((ml) obj2, (bm) obj)).p(we1);
            case 12:
                return ((d) n((ml) obj2, (bm) obj)).p(we1);
            case 13:
                return ((d) n((ml) obj2, (bm) obj)).p(we1);
            case 14:
                return ((d) n((ml) obj2, (bm) obj)).p(we1);
            case 15:
                return ((d) n((ml) obj2, (bm) obj)).p(we1);
            case 16:
                return ((d) n((ml) obj2, (bm) obj)).p(we1);
            case 17:
                return ((d) n((ml) obj2, (bm) obj)).p(we1);
            case 18:
                return ((d) n((ml) obj2, (bm) obj)).p(we1);
            case 19:
                return ((d) n((ml) obj2, (bm) obj)).p(we1);
            case 20:
                ((d) n((ml) obj2, (uw) obj)).p(we1);
                return cmVar;
            case 21:
                return ((d) n((ml) obj2, (bm) obj)).p(we1);
            case 22:
                return ((d) n((ml) obj2, obj)).p(we1);
            case 23:
                return ((d) n((ml) obj2, (bm) obj)).p(we1);
            case 24:
                return ((d) n((ml) obj2, (bm) obj)).p(we1);
            case 25:
                return ((d) n((ml) obj2, (bm) obj)).p(we1);
            default:
                ((d) n((ml) obj2, (bm) obj)).p(we1);
                return cmVar;
        }
    }

    public final ml n(ml mlVar, Object obj) {
        int i = this.i;
        Object obj2 = this.l;
        switch (i) {
            case 0:
                return new d((uj0) this.k, (m30) obj2, mlVar, 0);
            case 1:
                return new d((uj0) this.k, (n30) obj2, mlVar, 1);
            case 2:
                return new d((rc) this.k, (gw0) obj2, mlVar, 2);
            case 3:
                return new d((vc) this.k, (na) obj2, mlVar, 3);
            case gu0.LONG_FIELD_NUMBER /*4*/:
                return new d((uj0) this.k, (z61) obj2, mlVar, 4);
            case gu0.STRING_FIELD_NUMBER /*5*/:
                return new d((cj) this.k, (Runnable) obj2, mlVar, 5);
            case gu0.STRING_SET_FIELD_NUMBER /*6*/:
                this = new ao((List) obj2, mlVar, 6);
                this.k = obj;
                return this;
            case gu0.DOUBLE_FIELD_NUMBER /*7*/:
                return new d((tn) this.k, (qh0) obj2, mlVar, 7);
            case 8:
                return new d((m00) this.k, (qm) obj2, mlVar, 8);
            case 9:
                this = new ao((tn) obj2, mlVar, 9);
                this.k = obj;
                return this;
            case 10:
                return new d((nw) this.k, (kw) obj2, mlVar, 10);
            case 11:
                return new d((nw) this.k, (y60) obj2, mlVar, 11);
            case 12:
                this = new ao((ye) obj2, mlVar, 12);
                this.k = obj;
                return this;
            case 13:
                this = new ao((tp) obj2, mlVar, 13);
                this.k = obj;
                return this;
            case 14:
                return new d((y11) this.k, (m00) obj2, mlVar, 14);
            case 15:
                this = new ao((y6) obj2, mlVar, 15);
                this.k = obj;
                return this;
            case 16:
                return new d((or) this.k, (q11) obj2, mlVar, 16);
            case 17:
                return new d((t41) this.k, (String) obj2, mlVar, 17);
            case 18:
                return new ao((p3) obj2, mlVar, 18);
            case 19:
                return new d((tw) this.k, (xu0) obj2, mlVar, 19);
            case 20:
                this = new ao((j91) obj2, mlVar, 20);
                this.k = obj;
                return this;
            case 21:
                return new d((rf) this.k, (o8) obj2, mlVar, 21);
            case 22:
                this = new ao((uw) obj2, mlVar, 22);
                this.k = obj;
                return this;
            case 23:
                return new d((wi1) this.k, (x7) obj2, mlVar, 23);
            case 24:
                return new d((ui1) this.k, (String) obj2, mlVar, 24);
            case 25:
                return new d((dw0) this.k, (View) obj2, mlVar, 25);
            default:
                return new d((b81) this.k, (ti0) obj2, mlVar, 26);
        }
    }

    public /* synthetic */ d(Object obj, Object obj2, ml mlVar, int i) {
        this.i = i;
        this.k = obj;
        this.l = obj2;
        super(2, mlVar);
    }

    public /* synthetic */ d(Object obj, ml mlVar, int i) {
        this.i = i;
        this.l = obj;
        super(2, mlVar);
    }
}