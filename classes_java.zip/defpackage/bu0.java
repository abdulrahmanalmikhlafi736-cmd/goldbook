package defpackage;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Collections;
import java.util.Map;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bu0 */
public final class bu0 extends l10 {
    private static final bu0 DEFAULT_INSTANCE;
    private static volatile oq0 PARSER = null;
    public static final int PREFERENCES_FIELD_NUMBER = 1;
    private yg0 preferences_ = yg0.f;

    public static bu0 o(FileInputStream fileInputStream) {
        bu0 bu0 = DEFAULT_INSTANCE;
        ng ngVar = new ng(fileInputStream);
        yu a = yu.a();
        l10 i = bu0.i();
        try {
            jv0 jv0 = jv0.c;
            jv0.getClass();
            fh1 a2 = jv0.a(i.getClass());
            pg pgVar = (pg) ngVar.f;
            if (pgVar == null) {
                pgVar = new jj1(ngVar);
            }
            a2.h(i, pgVar, a);
            a2.c(i);
            if (l10.f(i, true)) {
                return (bu0) i;
            }
            throw new dl1(new ue1().getMessage());
        } catch (s70 e) {
            s70 e2 = e;
            if (e2.e) {
                e2 = new IOException(e2.getMessage(), e2);
            }
            throw e2;
        } catch (ue1 e3) {
            throw new dl1(e3.getMessage());
        } catch (IOException e4) {
            if (e4.getCause() instanceof s70) {
                throw ((s70) e4.getCause());
            }
            throw new IOException(e4.getMessage(), e4);
        } catch (RuntimeException e5) {
            if (e5.getCause() instanceof s70) {
                throw ((s70) e5.getCause());
            }
            throw e5;
        }
    }

    public final Object c(int i) {
        switch (fu0.N(i)) {
            case 0:
                return Byte.valueOf((byte) 1);
            case 1:
                return null;
            case 2:
                Object[] objArr = new Object[]{"preferences_", au0.a};
                return new rv0(DEFAULT_INSTANCE, "\u0001\u0001\u0000\u0000\u0001\u0001\u0001\u0001\u0000\u0000\u00012", objArr);
            case 3:
                return new bu0();
            case gu0.LONG_FIELD_NUMBER /*4*/:
                return new j10(DEFAULT_INSTANCE);
            case gu0.STRING_FIELD_NUMBER /*5*/:
                return DEFAULT_INSTANCE;
            case gu0.STRING_SET_FIELD_NUMBER /*6*/:
                oq0 oq0 = PARSER;
                if (oq0 != null) {
                    return oq0;
                }
                Object obj;
                synchronized (bu0.class) {
                    try {
                        obj = PARSER;
                        if (obj == null) {
                            obj = new Object();
                            PARSER = obj;
                        }
                    } finally {
                    }
                }
                return obj;
            default:
                throw new UnsupportedOperationException();
        }
    }

    public static yg0 l(bu0 bu0) {
        yg0 yg0 = bu0.preferences_;
        if (!yg0.e) {
            bu0.preferences_ = yg0.b();
        }
        return bu0.preferences_;
    }

    static {
        bu0 bu0 = new bu0();
        DEFAULT_INSTANCE = bu0;
        l10.j(bu0.class, bu0);
    }

    public static zt0 n() {
        return (zt0) ((j10) DEFAULT_INSTANCE.c(5));
    }

    public final Map m() {
        return Collections.unmodifiableMap(this.preferences_);
    }
}