package defpackage;

import android.graphics.Rect;
import android.graphics.text.LineBreakConfig;
import android.os.Build.VERSION;
import android.os.Trace;
import android.text.Layout.Alignment;
import android.text.Spanned;
import android.text.StaticLayout;
import android.text.StaticLayout.Builder;
import android.text.TextDirectionHeuristic;
import android.text.TextPaint;
import android.text.TextUtils.TruncateAt;
import android.text.style.MetricAffectingSpan;
import android.util.Log;
import android.view.View;
import android.view.autofill.AutofillManager$AutofillCallback;
import android.view.autofill.AutofillValue;
import android.webkit.WebView;
import androidx.core.content.FileProvider;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: sb0 */
public abstract class sb0 {
    public static long a;
    public static Method b;

    public static final void a(Object obj, int i, tb0 tb0, pi piVar, d10 d10, int i2) {
        int i3;
        Object obj2 = obj;
        int i4 = i;
        tb0 tb02 = tb0;
        pi piVar2 = piVar;
        d10 d102 = d10;
        int i5 = i2;
        d102.X(872548579);
        if ((i5 & 6) == 0) {
            i3 = (((AutofillValue) d102) != null ? 4 : 2) | i5;
        } else {
            i3 = i5;
        }
        if ((i5 & 48) == 0) {
            i3 |= d102.d(i4) ? 32 : 16;
        }
        if ((i5 & 384) == 0) {
            i3 |= ((AutofillValue) d102) != null ? 256 : 128;
        }
        if ((i5 & 3072) == 0) {
            i3 |= ((AutofillValue) d102) != null ? 2048 : 1024;
        }
        if (d102.O(i3 & 1, (i3 & 1171) != 1170)) {
            int f = ((AutofillManager$AutofillCallback) d102) | ((AutofillManager$AutofillCallback) d102);
            Object L = d102.L();
            nq0 nq0 = oj.a;
            if (f != 0 || L == nq0) {
                L = new qb0(obj2, tb02);
                d102.g0(L);
            }
            L = (qb0) L;
            L.c = i4;
            lq0 lq0 = L.g;
            gk gkVar = is0.a;
            qb0 qb0 = (qb0) d102.j(gkVar);
            g61 m = kb0.m();
            i00 e = m != null ? m.e() : null;
            g61 s = kb0.s(m);
            try {
                if (qb0 != ((qb0) lq0.getValue())) {
                    lq0.setValue(qb0);
                    if (L.d > 0) {
                        qb0 qb02 = L.e;
                        if (qb02 != null) {
                            qb02.b();
                        }
                        if (qb0 != null) {
                            qb0.a();
                        } else {
                            qb0 = null;
                        }
                        L.e = qb0;
                    }
                }
                kb0.z(m, s, e);
                AutofillManager$AutofillCallback f2 = ((AutofillManager$AutofillCallback) d102);
                Object L2 = d102.L();
                if (f2 != null || L2 == nq0) {
                    L2 = new l(8, L);
                    d102.g0(L2);
                }
                j70.b(L, (i00) L2, d102);
                k70.c(gkVar.a(L), piVar2, d102, ((i3 >> 6) & 112) | 8);
            } catch (Throwable th) {
                kb0.z(m, s, e);
            }
        } else {
            d102.R();
        }
        xv0 r = d102.r();
        if (r != null) {
            r.d = new rb0(obj2, i4, tb02, piVar2, i5);
        }
    }

    public static final Rect n(TextPaint textPaint, CharSequence charSequence, int i, int i2) {
        TextPaint textPaint2 = textPaint;
        CharSequence charSequence2 = charSequence;
        int i3 = i;
        int i4 = i2;
        if (charSequence2 instanceof Spanned) {
            Spanned spanned = (Spanned) charSequence2;
            Class cls = MetricAffectingSpan.class;
            if (spanned.nextSpanTransition(i3 - 1, i4, cls) != i4) {
                Rect rect = new Rect();
                Rect rect2 = new Rect();
                TextPaint textPaint3 = new TextPaint();
                while (i3 < i4) {
                    int nextSpanTransition = spanned.nextSpanTransition(i3, i4, cls);
                    MetricAffectingSpan[] metricAffectingSpanArr = (MetricAffectingSpan[]) spanned.getSpans(i3, nextSpanTransition, cls);
                    textPaint3.set(textPaint2);
                    for (Object obj : metricAffectingSpanArr) {
                        if (spanned.getSpanStart(obj) != spanned.getSpanEnd(obj)) {
                            obj.updateMeasureState(textPaint3);
                        }
                    }
                    if (VERSION.SDK_INT >= 29) {
                        textPaint3.getTextBounds(charSequence2, i3, nextSpanTransition, rect2);
                    } else {
                        textPaint3.getTextBounds(charSequence2.toString(), i3, nextSpanTransition, rect2);
                    }
                    rect.right = rect2.width() + rect.right;
                    rect.top = Math.min(rect.top, rect2.top);
                    rect.bottom = Math.max(rect.bottom, rect2.bottom);
                    i3 = nextSpanTransition;
                }
                return rect;
            }
        }
        Rect rect3 = new Rect();
        if (VERSION.SDK_INT >= 29) {
            textPaint2.getTextBounds(charSequence2, i3, i4, rect3);
            return rect3;
        }
        textPaint2.getTextBounds(charSequence2.toString(), i3, i4, rect3);
        return rect3;
    }

    public static boolean p() {
        if (VERSION.SDK_INT >= 29) {
            return sc1.a();
        }
        Class cls = Trace.class;
        try {
            if (b == null) {
                a = cls.getField("TRACE_TAG_APP").getLong(null);
                b = cls.getMethod("isTagEnabled", new Class[]{Long.TYPE});
            }
            return ((Boolean) b.invoke(null, new Object[]{Long.valueOf(a)})).booleanValue();
        } catch (Exception e) {
            if (e instanceof InvocationTargetException) {
                Throwable cause = e.getCause();
                if (cause instanceof RuntimeException) {
                    throw ((RuntimeException) cause);
                }
                throw new RuntimeException(cause);
            }
            Log.v("Trace", "Unable to call isTagEnabled via reflection", e);
            return false;
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:8:0x0038 A:{Splitter: B:3:0x000c, ExcHandler: java.lang.NoSuchMethodException (r0_7 'e' java.lang.NoSuchMethodException)} */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0038 A:{Splitter: B:3:0x000c, ExcHandler: java.lang.NoSuchMethodException (r0_7 'e' java.lang.NoSuchMethodException)} */
    /* JADX WARNING: Missing block: B:8:0x0038, code:
            r0 = move-exception;
     */
    /* JADX WARNING: Missing block: B:10:0x003e, code:
            throw new java.lang.RuntimeException(r0);
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static InvocationHandler l() {
        ClassLoader i;
        if (VERSION.SDK_INT >= 28) {
            i = WebView.getWebViewClassLoader();
        } else {
            try {
                Method declaredMethod = WebView.class.getDeclaredMethod("getFactory", null);
                declaredMethod.setAccessible(true);
                i = declaredMethod.invoke(null, null).getClass().getClassLoader();
            } catch (NoSuchMethodException e) {
            }
        }
        return (InvocationHandler) Class.forName("org.chromium.support_lib_glue.SupportLibReflectionUtil", false, i).getDeclaredMethod("createWebViewProviderFactory", null).invoke(null, null);
    }

    public static final long t(long j, long j2) {
        float intBitsToFloat = Float.intBitsToFloat((int) (j2 >> 32)) * Float.intBitsToFloat((int) (j >> 32));
        float intBitsToFloat2 = Float.intBitsToFloat((int) (j2 & 4294967295L)) * Float.intBitsToFloat((int) (j & 4294967295L));
        return (((long) Float.floatToRawIntBits(intBitsToFloat2)) & 4294967295L) | (((long) Float.floatToRawIntBits(intBitsToFloat)) << 32);
    }

    public static float b(float[] fArr) {
        if (fArr.length < 6) {
            return 0.0f;
        }
        float f = fArr[0];
        float f2 = fArr[1];
        float f3 = fArr[2];
        float f4 = fArr[3];
        float f5 = fArr[4];
        float f6 = fArr[5];
        float f7 = (((((f3 * f6) + ((f2 * f5) + (f * f4))) - (f4 * f5)) - (f2 * f3)) - (f * f6)) * 0.5f;
        return f7 < 0.0f ? -f7 : f7;
    }

    public static double f(double d, double d2, double d3) {
        if (d2 > d3) {
            StringBuilder dl1 = new dl1("Cannot coerce value to an empty range: maximum ");
            dl1.append(d3);
            dl1.append(" is less than minimum ");
            dl1.append(d2);
            dl1.append('.');
            throw new dl1(dl1.toString());
        } else if (d < d2) {
            return d2;
        } else {
            return d > d3 ? d3 : d;
        }
    }

    public static float g(float f, float f2, float f3) {
        if (f2 > f3) {
            StringBuilder dl1 = new dl1("Cannot coerce value to an empty range: maximum ");
            dl1.append(f3);
            dl1.append(" is less than minimum ");
            dl1.append(f2);
            dl1.append('.');
            throw new dl1(dl1.toString());
        } else if (f < f2) {
            return f2;
        } else {
            return f > f3 ? f3 : f;
        }
    }

    public static int h(int i, int i2, int i3) {
        if (i2 > i3) {
            StringBuilder dl1 = new dl1("Cannot coerce value to an empty range: maximum ");
            dl1.append(i3);
            dl1.append(" is less than minimum ");
            dl1.append(i2);
            dl1.append('.');
            throw new dl1(dl1.toString());
        } else if (i < i2) {
            return i2;
        } else {
            return i > i3 ? i3 : i;
        }
    }

    public static final void r(li0 li0, xz xzVar) {
        Object obj = li0.k;
        if (obj == null) {
            obj = new wm0((vm0) li0);
            li0.k = obj;
        }
        op0 snapshotObserver = ((n4) k70.P(li0)).getSnapshotObserver();
        snapshotObserver.a.b(obj, i4.I, xzVar);
    }

    public static StaticLayout j(CharSequence charSequence, TextPaint textPaint, int i, int i2, TextDirectionHeuristic textDirectionHeuristic, Alignment alignment, int i3, TruncateAt truncateAt, int i4, int i5, boolean z, int i6, int i7, int i8, int i9) {
        if (i2 < 0) {
            FileProvider.a("invalid start value");
        }
        int length = charSequence.length();
        if (i2 < 0 || i2 > length) {
            FileProvider.a("invalid end value");
        }
        if (i3 < 0) {
            FileProvider.a("invalid maxLines value");
        }
        if (i < 0) {
            FileProvider.a("invalid width value");
        }
        if (i4 < 0) {
            FileProvider.a("invalid ellipsizedWidth value");
        }
        Builder obtain = Builder.obtain(charSequence, 0, i2, textPaint, i);
        obtain.setTextDirection(textDirectionHeuristic);
        obtain.setAlignment(alignment);
        obtain.setMaxLines(i3);
        obtain.setEllipsize(truncateAt);
        obtain.setEllipsizedWidth(i4);
        obtain.setLineSpacing(0.0f, 1.0f);
        obtain.setIncludePad(z);
        obtain.setBreakStrategy(i6);
        obtain.setHyphenationFrequency(i9);
        obtain.setIndents(null, null);
        int i10 = VERSION.SDK_INT;
        if (i10 >= 26) {
            obtain.setJustificationMode(i5);
        }
        if (i10 >= 28) {
            obtain.setUseLineSpacingFromFallbacks(true);
        }
        if (i10 >= 33) {
            obtain.setLineBreakConfig(new LineBreakConfig.Builder().setLineBreakStyle(i7).setLineBreakWordStyle(i8).build());
        }
        if (i10 >= 35) {
            obtain.setUseBoundsForWidth(false);
        }
        return obtain.build();
    }

    public static final int d(long[] jArr, long j) {
        int length = jArr.length - 1;
        int i = 0;
        while (i <= length) {
            int i2 = (i + length) >>> 1;
            int i3 = (j > jArr[i2] ? 1 : (j == jArr[i2] ? 0 : -1));
            if (i3 > 0) {
                i = i2 + 1;
            } else if (i3 >= 0) {
                return i2;
            } else {
                length = i2 - 1;
            }
        }
        return -(i + 1);
    }

    public static long i(long j) {
        if (j < -4611686018427387903L) {
            return -4611686018427387903L;
        }
        return j > 4611686018427387903L ? 4611686018427387903L : j;
    }

    public static o60 s(q60 q60) {
        q60.getClass();
        return new o60(q60.e, q60.f, q60.g > 0 ? 2 : -2);
    }

    public static String u(long j) {
        StringBuilder dl1 = new dl1("PointerId(value=");
        dl1.append(j);
        dl1.append(')');
        return dl1.toString();
    }

    public static void c(String str) {
        if (str.length() > 127) {
            str = str.substring(0, 127);
        }
        Trace.beginSection(str);
    }

    public static k1 m(View view) {
        return VERSION.SDK_INT >= 26 ? new k1(b9.b(view)) : null;
    }

    public static final g7 o(sl slVar) {
        g7 g7Var = (g7) slVar.k(e3.U);
        if (g7Var != null) {
            return g7Var;
        }
        od.p("A MonotonicFrameClock is not available in this CoroutineContext. Callers should supply an appropriate MonotonicFrameClock using withContext.");
        return null;
    }

    public static q60 w(int i, int i2) {
        if (i2 > Integer.MIN_VALUE) {
            return new o60(i, i2 - 1, 1);
        }
        q60 q60 = q60.h;
        return q60.h;
    }

    public static final double v(long j) {
        return (((double) (j >>> 11)) * 2048.0d) + ((double) (j & 2047));
    }

    public static c31 q(m00 m00) {
        c31 obj = new Object();
        obj.g = ac.m(obj, obj, m00);
        return obj;
    }

    public static final int e(float f) {
        return Math.round((float) Math.ceil((double) f));
    }

    public static final boolean k(long j, long j2) {
        return j == j2;
    }
}