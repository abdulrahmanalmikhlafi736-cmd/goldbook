package defpackage;

import java.nio.ByteBuffer;
import java.util.ConcurrentModificationException;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: sg0 */
public abstract class sg0 {
    public int e;
    public int f;
    public int g;
    public Object h;

    public void remove() {
        tg0 tg0 = (tg0) this.h;
        b();
        if (this.f != -1) {
            tg0.b();
            tg0.j(this.f);
            this.f = -1;
            this.g = tg0.l;
            return;
        }
        od.p("Call next() before removing element from the iterator.");
    }

    public void c() {
        while (true) {
            int i = this.e;
            tg0 tg0 = (tg0) this.h;
            if (i < tg0.j && tg0.g[i] < 0) {
                this.e = i + 1;
            } else {
                return;
            }
        }
    }

    public int a(int i) {
        return i < this.g ? ((ByteBuffer) this.h).getShort(this.f + i) : 0;
    }

    public sg0() {
        if (av0.f == null) {
            av0.f = new h90(19);
        }
    }

    public void b() {
        if (((tg0) this.h).l != this.g) {
            throw new ConcurrentModificationException();
        }
    }

    public boolean hasNext() {
        return this.e < ((tg0) this.h).j;
    }
}