package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: js0 */
public abstract class js0 implements jp {
    public boolean e;

    public static void l(js0 js0, ks0 ks0, int i, int i2) {
        int i3 = ls0.b;
        np0 np0 = np0.m;
        long j = (((long) i) << 32) | (((long) i2) & 4294967295L);
        if (js0.e() != o90.e) {
            if (js0.f() != 0) {
                long f = (((long) ((js0.f() - ks0.e) - ((int) (j >> 32)))) << 32) | (((long) ((int) (j & 4294967295L))) & 4294967295L);
                js0.c(js0, ks0);
                ks0.R(n60.c(f, ks0.i), 0.0f, np0);
                return;
            }
        }
        js0.c(js0, ks0);
        ks0.R(n60.c(j, ks0.i), 0.0f, np0);
    }

    public static void j(js0 js0, ks0 ks0, int i, int i2) {
        long j = (((long) i) << 32) | (((long) i2) & 4294967295L);
        if (js0.e() != o90.e) {
            if (js0.f() != 0) {
                long f = (((long) ((js0.f() - ks0.e) - ((int) (j >> 32)))) << 32) | (((long) ((int) (j & 4294967295L))) & 4294967295L);
                js0.c(js0, ks0);
                ks0.R(n60.c(f, ks0.i), 0.0f, null);
                return;
            }
        }
        js0.c(js0, ks0);
        ks0.R(n60.c(j, ks0.i), 0.0f, null);
    }

    public static void h(js0 js0, ks0 ks0, int i, int i2) {
        js0.getClass();
        long j = (((long) i2) & 4294967295L) | (((long) i) << 32);
        js0.c(js0, ks0);
        ks0.R(n60.c(j, ks0.i), 0.0f, null);
    }

    public static void m(js0 js0, ks0 ks0, i00 i00) {
        js0.getClass();
        js0.c(js0, ks0);
        ks0.R(n60.c(0, ks0.i), 0.0f, i00);
    }

    public static void i(js0 js0, ks0 ks0, long j) {
        js0.getClass();
        js0.c(js0, ks0);
        ks0.R(n60.c(j, ks0.i), 0.0f, null);
    }

    public static final void c(js0 js0, ks0 ks0) {
        js0.getClass();
        if (ks0 instanceof xi0) {
            ((xi0) ks0).m(js0.e);
        }
    }

    public final long V(float f) {
        return fu0.q(f / a(), this);
    }

    public final float b0(int i) {
        return ((float) i) / a();
    }

    public final float c0(float f) {
        return f / a();
    }

    public final float q(float f) {
        return a() * f;
    }

    public final /* synthetic */ int F(float f) {
        return fu0.k(f, this);
    }

    public final /* synthetic */ long K(long j) {
        return fu0.p(j, this);
    }

    public final /* synthetic */ float N(long j) {
        return fu0.o(j, this);
    }

    public final /* synthetic */ float y(long j) {
        return fu0.m(j, this);
    }

    public float d(j30 j30) {
        return Float.NaN;
    }

    public abstract o90 e();

    public abstract int f();
}