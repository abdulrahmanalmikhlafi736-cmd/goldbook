package defpackage;

import androidx.core.content.FileProvider;
import java.util.ArrayList;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cb1 */
public final class cb1 {
    public final bb1 a;
    public final ij0 b;
    public final long c;
    public final float d;
    public final float e;
    public final ArrayList f;

    public final int b(float f) {
        int size;
        ArrayList arrayList = (ArrayList) this.b.e;
        int i = 0;
        if (f > 0.0f) {
            if (f >= ((bq0) tg.W(arrayList)).g) {
                i = arrayList.size() - 1;
            } else {
                size = arrayList.size() - 1;
                int i2 = 0;
                while (i2 <= size) {
                    int i3 = (i2 + size) >>> 1;
                    bq0 bq0 = (bq0) arrayList.get(i3);
                    int i4 = bq0.f > f ? 1 : bq0.g <= f ? -1 : 0;
                    if (i4 >= 0) {
                        if (i4 <= 0) {
                            i = i3;
                            break;
                        }
                        size = i3 - 1;
                    } else {
                        i2 = i3 + 1;
                    }
                }
                i = -(i2 + 1);
            }
        }
        bq0 bq02 = (bq0) arrayList.get(i);
        size = bq02.c;
        i = bq02.d;
        if (size - bq02.b == 0) {
            return i;
        }
        f -= bq02.f;
        ab1 ab1 = bq02.a.d;
        return ab1.e.getLineForVertical(((int) f) - ab1.g) + i;
    }

    public final lx0 e(int i) {
        ij0 ij0 = this.b;
        x8 x8Var = (x8) ((pa) ij0.c).a;
        if (i < 0 || i > x8Var.f.length()) {
            StringBuilder H = fu0.H(i, "offset(", ") is out of bounds [0, ");
            H.append(x8Var.f.length());
            H.append(']');
            FileProvider.a(H.toString());
        }
        int length = ((x8) ((pa) ij0.c).a).f.length();
        ArrayList arrayList = (ArrayList) ij0.e;
        bq0 bq0 = (bq0) arrayList.get(i == length ? zi1.t(arrayList) : dd0.h(i, arrayList));
        m6 m6Var = bq0.a;
        int a = bq0.a(i);
        ab1 ab1 = m6Var.d;
        return ab1.e.getParagraphDirection(ab1.e.getLineForOffset(a)) == 1 ? lx0.e : lx0.f;
    }

    public cb1(bb1 bb1, ij0 ij0, long j) {
        this.a = bb1;
        this.b = ij0;
        this.c = j;
        ArrayList arrayList = (ArrayList) ij0.e;
        float f = 0.0f;
        this.d = arrayList.isEmpty() ? 0.0f : ((bq0) arrayList.get(0)).a.d.c(0);
        if (!arrayList.isEmpty()) {
            bq0 bq0 = (bq0) tg.W(arrayList);
            ab1 ab1 = bq0.a.d;
            f = ab1.c(ab1.f - 1) + bq0.f;
        }
        this.e = f;
        this.f = (ArrayList) ij0.d;
    }

    public final String toString() {
        StringBuilder dl1 = new dl1("TextLayoutResult(layoutInput=");
        dl1.append(this.a);
        dl1.append(", multiParagraph=");
        dl1.append(this.b);
        dl1.append(", size=");
        dl1.append(v60.b(this.c));
        dl1.append(", firstBaseline=");
        dl1.append(this.d);
        dl1.append(", lastBaseline=");
        dl1.append(this.e);
        dl1.append(", placeholderRects=");
        dl1.append(this.f);
        dl1.append(')');
        return dl1.toString();
    }

    public final boolean equals(Object obj) {
        if (this != obj) {
            if (obj instanceof cb1) {
                cb1 cb1 = (cb1) obj;
                if (k70.p(this.a, cb1.a)) {
                    if (this.b != cb1.b) {
                        return false;
                    }
                    if (d90.a(this.c, cb1.c)) {
                        if (this.d == cb1.d && this.e == cb1.e) {
                            if (!k70.p(this.f, cb1.f)) {
                            }
                        }
                    }
                }
            }
            return false;
        }
        return true;
    }

    public final int a(int i) {
        ij0 ij0 = this.b;
        ArrayList arrayList = (ArrayList) ij0.e;
        int t = i >= ((x8) ((pa) ij0.c).a).f.length() ? zi1.t(arrayList) : i < 0 ? 0 : dd0.h(i, arrayList);
        bq0 bq0 = (bq0) arrayList.get(t);
        return bq0.a.d.e.getLineForOffset(bq0.a(i)) + bq0.d;
    }

    public final int hashCode() {
        int hashCode = (this.b.hashCode() + (this.a.hashCode() * 31)) * 31;
        long j = this.c;
        return this.f.hashCode() + fu0.z(this.e, fu0.z(this.d, (((int) (j ^ (j >>> 32))) + hashCode) * 31, 31), 31);
    }

    public final int c(int i) {
        ij0 ij0 = this.b;
        ij0.b(i);
        ArrayList arrayList = (ArrayList) ij0.e;
        bq0 bq0 = (bq0) arrayList.get(dd0.i(i, arrayList));
        return bq0.a.d.e.getLineStart(i - bq0.d) + bq0.b;
    }

    public final float d(int i) {
        ij0 ij0 = this.b;
        ij0.b(i);
        ArrayList arrayList = (ArrayList) ij0.e;
        bq0 bq0 = (bq0) arrayList.get(dd0.i(i, arrayList));
        return bq0.a.d.f(i - bq0.d) + bq0.f;
    }
}