package defpackage;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.function.UnaryOperator;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: d30 */
public final class d30 implements List, w80 {
    public final int e;
    public final int f;
    public final /* synthetic */ e30 g;

    public final int indexOf(Object obj) {
        if (obj instanceof li0) {
            li0 li0 = (li0) obj;
            int i = this.e;
            int i2 = this.f;
            if (i <= i2) {
                int i3 = i;
                while (!k70.p(this.g.e.f(i3), li0)) {
                    if (i3 != i2) {
                        i3++;
                    }
                }
                return i3 - i;
            }
        }
        return -1;
    }

    public final int lastIndexOf(Object obj) {
        if (obj instanceof li0) {
            li0 li0 = (li0) obj;
            int i = this.f;
            int i2 = this.e;
            if (i2 <= i) {
                while (!k70.p(this.g.e.f(i), li0)) {
                    if (i != i2) {
                        i--;
                    }
                }
                return i - i2;
            }
        }
        return -1;
    }

    public final boolean containsAll(Collection collection) {
        for (li0 contains : collection) {
            if (!contains(contains)) {
                return false;
            }
        }
        return true;
    }

    public final boolean contains(Object obj) {
        return (obj instanceof li0) && indexOf((li0) obj) != -1;
    }

    public final Object get(int i) {
        Object f = this.g.e.f(i + this.e);
        f.getClass();
        return (li0) f;
    }

    public final ListIterator listIterator(int i) {
        int i2 = this.e;
        return new c30(this.g, i + i2, i2, this.f);
    }

    public final Iterator iterator() {
        int i = this.e;
        return new c30(this.g, i, i, this.f);
    }

    public final List subList(int i, int i2) {
        int i3 = this.e;
        return new c30(this.g, i + i3, i3 + i2);
    }

    public d30(e30 e30, int i, int i2) {
        this.g = e30;
        this.e = i;
        this.f = i2;
    }

    public final boolean isEmpty() {
        return size() == 0;
    }

    public final /* bridge */ /* synthetic */ void add(int i, Object obj) {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final boolean addAll(int i, Collection collection) {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final /* bridge */ /* synthetic */ void addFirst(Object obj) {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final /* bridge */ /* synthetic */ void addLast(Object obj) {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final void clear() {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final boolean removeAll(Collection collection) {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final /* bridge */ /* synthetic */ Object removeFirst() {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final /* bridge */ /* synthetic */ Object removeLast() {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final void replaceAll(UnaryOperator unaryOperator) {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final boolean retainAll(Collection collection) {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final /* bridge */ /* synthetic */ Object set(int i, Object obj) {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final void sort(Comparator comparator) {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final int size() {
        return this.f - this.e;
    }

    public final Object[] toArray() {
        return vd1.G(this);
    }

    public final /* bridge */ /* synthetic */ boolean add(Object obj) {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final boolean addAll(Collection collection) {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final ListIterator listIterator() {
        int i = this.e;
        return new c30(this.g, i, i, this.f);
    }

    public final boolean remove(Object obj) {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final Object[] toArray(Object[] objArr) {
        return vd1.H(this, objArr);
    }
}