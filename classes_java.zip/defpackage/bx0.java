package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bx0 */
public final class bx0 {
    public final of0 a;

    public final String toString() {
        StringBuilder dl1 = new dl1("Removed[");
        dl1.append(this.a);
        dl1.append(']');
        return dl1.toString();
    }

    public bx0(of0 of0) {
        this.a = of0;
    }
}