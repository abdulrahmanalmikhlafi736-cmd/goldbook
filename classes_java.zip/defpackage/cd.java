package defpackage;

import java.util.List;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cd */
public final class cd implements i00 {
    public final /* synthetic */ int e;
    public Object f;

    public final Object i(Object obj) {
        switch (this.e) {
            case 0:
                Throwable th = (Throwable) obj;
                ((oe) this.f).cancel();
                return we1.a;
            case 1:
                long j;
                l61 l61 = (l61) obj;
                synchronized (n61.c) {
                    j = n61.e;
                    n61.e = 1 + j;
                }
                return new uv0(j, l61, (i00) this.f);
            case 2:
                boolean booleanValue = ((Boolean) obj).booleanValue();
                jt0 jt0 = (jt0) this.f;
                if (jt0 != null) {
                    jt0.c = booleanValue;
                }
                return we1.a;
            default:
                ((List) this.f).get(((Number) obj).intValue());
                return null;
        }
    }

    public /* synthetic */ cd(int i, Object obj) {
        this.e = i;
        this.f = obj;
    }

    public /* synthetic */ cd() {
        this.e = 2;
    }
}