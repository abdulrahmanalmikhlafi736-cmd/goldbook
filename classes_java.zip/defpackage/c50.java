package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: c50 */
public final class c50 {
    public final q11 a;
    public x40 b;
    public a50 c;
    public z40 d;
    public y40 e;
    public j70 f;
    public cz0 g;
    public long h = 9205357640488583168L;
    public rc1 i;
    public final zh j;
    public final zh k;
    public long l;

    public final void e(v40 v40, u40 u40, long j) {
        long j2 = j;
        q11 q11 = this.a;
        long d = k70.N(q11).d(0);
        if (n60.b(this.h, 9205357640488583168L) == null && n60.b(d, this.h) == null) {
            this.l = xm0.f(this.l, gg1.e(d, this.h));
        }
        this.h = d;
        bp0 bp0 = q11.u;
        bp0.getClass();
        if (Math.abs(Float.intBitsToFloat((int) (bp0 == bp0.e ? j2 & 4294967295L : j2 >> 32))) > 2.0f) {
            k70.h(d(), v40, q11.u, u40, this.j, this.l);
            zh zhVar = this.k;
            vj0 vj0 = (vj0) zhVar.f;
            int i = vj0.b;
            if (i == 3) {
                int i2 = zhVar.e;
                zhVar.e = i2 + 1;
                if (i2 < 0 || i2 >= i) {
                    od.f("Index must be between 0 and size");
                    return;
                }
                long[] jArr = vj0.a;
                long j3 = jArr[i2];
                jArr[i2] = j2;
            } else {
                vj0.a(j2);
            }
            int i3 = 0;
            if (zhVar.e == 3) {
                zhVar.e = 0;
            }
            long[] jArr2 = vj0.a;
            float f = 0.0f;
            float f2 = 0.0f;
            for (int i4 = 0; i4 < vj0.b; i4++) {
                f2 += Float.intBitsToFloat((int) (jArr2[i4] >> 32));
            }
            int i5 = vj0.b;
            f2 /= (float) i5;
            long[] jArr3 = vj0.a;
            while (i3 < i5) {
                f += Float.intBitsToFloat((int) (jArr3[i3] & 4294967295L));
                i3++;
            }
            q11.B0(new ka1((((long) Float.floatToRawIntBits(f2)) << 32) | (((long) Float.floatToRawIntBits(f / ((float) vj0.b))) & 4294967295L), true));
        }
    }

    public final void f(v40 v40, v40 v402, u40 u40, long j) {
        if (this.g == null) {
            this.g = new h90(11);
        }
        this.l = 0;
        cz0 d = d();
        q11 q11 = this.a;
        u40 u402 = u40;
        k70.h(d, v40, q11.u, u402, this.j, this.l);
        long e = gg1.e(k70.L(v402, q11.u, u402), j);
        q11.v.getClass();
        this.h = k70.N(q11).d(0);
        q11.B0(new ad(e));
        zh zhVar = this.k;
        zhVar.e = 0;
        ((vj0) zhVar.f).b = 0;
    }

    public static void c(c50 c50, v40 v40, long j, long j2, int i) {
        if ((i & 4) != 0) {
            j2 = 0;
        }
        q11 q11 = c50.a;
        z40 z40 = c50.d;
        if (z40 == null) {
            z40 = new Object();
            z40.L = null;
            z40.M = Long.MAX_VALUE;
            z40.N = false;
            c50.d = z40;
        }
        z40.L = v40;
        z40.M = j;
        rc1 rc1 = c50.i;
        bp0 bp0 = q11.u;
        if (rc1 == null) {
            c50.i = new rc1(bp0, 0);
        } else {
            rc1.a = bp0;
            rc1.b = j2;
        }
        z40.N = false;
        c50.f = z40;
    }

    public c50(q11 q11) {
        this.a = q11;
        zh obj = new Object();
        obj.f = new ak0();
        this.j = obj;
        obj = new Object();
        obj.f = new vj0();
        this.k = obj;
        this.l = 0;
    }

    public final void b(v40 v40, long j, rc1 rc1) {
        y40 y40 = this.e;
        if (y40 == null) {
            y40 = new Object();
            y40.L = null;
            y40.M = Long.MAX_VALUE;
            this.e = y40;
        }
        y40.L = v40;
        y40.M = j;
        rc1.b = 0;
        this.f = y40;
    }

    public final void a() {
        x40 x40 = this.b;
        w40 w40 = w40.g;
        if (x40 == null) {
            x40 = new Object();
            x40.L = w40;
            x40.M = false;
            this.b = x40;
        }
        x40.L = w40;
        x40.M = false;
        this.f = x40;
    }

    public final cz0 d() {
        cz0 cz0 = this.g;
        if (cz0 != null) {
            return cz0;
        }
        od.m("Velocity Tracker not initialized.");
        return null;
    }
}