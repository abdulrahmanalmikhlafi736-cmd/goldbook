package defpackage;

import java.io.Serializable;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: da1 */
public final class da1 implements ta0, Serializable {
    public xz e;
    public volatile Object f = nq0.k;
    public final Object g = this;

    public final Object getValue() {
        nq0 nq0 = this.f;
        nq0 nq02 = nq0.k;
        if (nq0 != nq02) {
            return nq0;
        }
        Object obj;
        synchronized (this.g) {
            obj = this.f;
            if (obj == nq02) {
                xz xzVar = this.e;
                xzVar.getClass();
                obj = xzVar.a();
                this.f = obj;
                this.e = null;
            }
        }
        return obj;
    }

    public final String toString() {
        return this.f != nq0.k ? String.valueOf(getValue()) : "Lazy value not initialized yet.";
    }

    public da1(xz xzVar) {
        xzVar.getClass();
        this.e = xzVar;
    }
}