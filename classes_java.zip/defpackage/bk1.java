package defpackage;

import android.view.View;
import android.view.WindowInsets;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bk1 */
public class bk1 extends ak1 {
    public static final hk1 x = hk1.c(null, WindowInsets.CONSUMED);

    public c60 i(int i) {
        return c60.c(this.c.getInsets(gk1.a(i)));
    }

    public c60 j(int i) {
        return c60.c(this.c.getInsetsIgnoringVisibility(gk1.a(i)));
    }

    public boolean u(int i) {
        return this.c.isVisible(gk1.a(i));
    }

    public bk1(hk1 hk1, WindowInsets windowInsets) {
        super(hk1, windowInsets);
    }

    public bk1(hk1 hk1, bk1 bk1) {
        super(hk1, (ak1) bk1);
    }

    public void p(View view) {
    }
}