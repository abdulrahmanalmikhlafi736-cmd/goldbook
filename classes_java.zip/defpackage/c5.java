package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: c5 */
public abstract class c5 {
    public static final gk a = new ad0(b5.g);
    public static final k81 b = new ad0(b5.h);
    public static final gk c = new gk(i4.i);
    public static final k81 d = new ad0(b5.i);
    public static final k81 e = new ad0(b5.j);
    public static final k81 f = new ad0(b5.k);

    public static final String a(String str) {
        StringBuilder dl1 = new dl1("CompositionLocal ");
        dl1.append(str);
        dl1.append(" not present");
        throw new dl1(dl1.toString().toString());
    }
}