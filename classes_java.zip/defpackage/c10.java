package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: c10 */
public final class c10 {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;

    public final void a() {
        int i = this.a;
        Object obj = this.b;
        switch (i) {
            case 0:
                d10 d10 = (d10) obj;
                d10.A--;
                return;
            default:
                a71 a71 = (a71) obj;
                a71.k--;
                return;
        }
    }

    public final void b() {
        int i = this.a;
        Object obj = this.b;
        switch (i) {
            case 0:
                d10 d10 = (d10) obj;
                d10.A++;
                return;
            default:
                a71 a71 = (a71) obj;
                a71.k++;
                return;
        }
    }

    public /* synthetic */ c10(int i, Object obj) {
        this.a = i;
        this.b = obj;
    }
}