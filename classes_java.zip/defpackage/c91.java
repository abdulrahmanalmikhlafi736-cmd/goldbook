package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: c91 */
public final class c91 extends h90 implements m00 {
    public final /* synthetic */ f91 f;
    public final /* synthetic */ mi0 g;
    public final /* synthetic */ m00 h;
    public final /* synthetic */ int i;

    public final Object f(Object obj, Object obj2) {
        d10 d10 = (d10) obj;
        ((Number) obj2).intValue();
        vn.c(this.f, this.g, this.h, d10, wc0.s(this.i | 1));
        return we1.a;
    }

    public c91(f91 f91, mi0 mi0, m00 m00, int i) {
        this.f = f91;
        this.g = mi0;
        this.h = m00;
        this.i = i;
        super(2);
    }
}