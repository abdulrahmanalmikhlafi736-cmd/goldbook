package defpackage;

import java.io.Serializable;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ge */
public abstract class ge implements u80, Serializable {
    public transient u80 e;
    public final Object f;
    public final Class g;
    public final String h;
    public final String i;
    public final boolean j;

    public final uf e() {
        boolean z = this.j;
        Class cls = this.g;
        if (!z) {
            return jh1.a(cls);
        }
        ow0.a.getClass();
        return new pp0(cls);
    }

    public ge(Object obj, Class cls, String str, String str2, boolean z) {
        this.f = obj;
        this.g = cls;
        this.h = str;
        this.i = str2;
        this.j = z;
    }

    public abstract u80 d();
}