package defpackage;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.net.Uri;
import android.view.View;
import android.view.autofill.AutofillManager;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CancellationException;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: c */
public final /* synthetic */ class c implements i00 {
    public final /* synthetic */ int e;
    public final /* synthetic */ Object f;
    public final /* synthetic */ Object g;

    public final Object i(Object obj) {
        Object obj2 = null;
        boolean z = false;
        Throwable th;
        rq rqVar;
        zi1 zi1;
        da0 da0;
        jw0 jw0;
        boolean A;
        ik0 ik0;
        int i;
        i00 i00;
        ed1 ed1;
        switch (this.e) {
            case 0:
                th = (Throwable) obj;
                ((uj0) this.f).b((nu0) this.g);
                return we1.a;
            case 1:
                la laVar = (la) this.f;
                ma maVar = (ma) this.g;
                rw0 rw0 = (rw0) obj;
                we1 we1 = we1.a;
                bc1 bc1 = laVar.s;
                if (bc1 != null) {
                    bc1.b();
                }
                laVar.s = null;
                uh uhVar = maVar.b;
                if (uhVar != null) {
                    uhVar.R(we1);
                }
                maVar.b = null;
                return we1;
            case 2:
                ta taVar = (ta) this.f;
                ui uiVar = (ui) this.g;
                rqVar = (rq) obj;
                p3 p3Var = taVar.a;
                if (p3Var != null) {
                    p3.b(p3Var, uiVar.b);
                } else {
                    jn0 jn0 = taVar.b;
                    if (jn0 != null) {
                        sa saVar = uiVar.a;
                        saVar.getClass();
                        en0 en0 = new en0(saVar, new fn0(saVar, null));
                        saVar.a.add(en0);
                        p3.b(jn0.a(), en0);
                    } else {
                        od.p("Unreachable");
                        return obj2;
                    }
                }
                obj2 = new al(0, taVar, uiVar);
                return obj2;
            case 3:
                r6 r6Var = (r6) this.f;
                zi1 = (zi1) this.g;
                da0 = (da0) obj;
                da0.c();
                fu0.w(da0, r6Var, zi1, 0.0f, null, 60);
                return we1.a;
            case gu0.LONG_FIELD_NUMBER /*4*/:
                dp0 dp0 = (dp0) this.f;
                zi1 = (zi1) this.g;
                da0 = (da0) obj;
                da0.c();
                fu0.w(da0, dp0.b, zi1, 0.0f, null, 60);
                return we1.a;
            case gu0.STRING_FIELD_NUMBER /*5*/:
                th = (Throwable) obj;
                ((sc) this.f).a.j((dl) this.g);
                return we1.a;
            case gu0.STRING_SET_FIELD_NUMBER /*6*/:
                v40 v40 = (v40) this.f;
                jw0 = (jw0) this.g;
                A = ((o10) obj).A(v40);
                if (jw0.e || A) {
                    z = true;
                }
                jw0.e = z;
                return Boolean.valueOf(z ^ 1);
            case gu0.DOUBLE_FIELD_NUMBER /*7*/:
                dt0 dt0 = (dt0) this.f;
                jw0 = (jw0) this.g;
                A = ((o10) obj).c(dt0);
                if (jw0.e || A) {
                    z = true;
                }
                jw0.e = z;
                return Boolean.valueOf(z ^ 1);
            case 8:
                th = (Throwable) obj;
                ((uj0) this.f).b((y60) this.g);
                return we1.a;
            case 9:
                Resources resources = (Resources) this.f;
                t41 t41 = (t41) this.g;
                ((im) obj).getClass();
                return new lg0(resources, t41);
            case 10:
                lg0 lg0 = (lg0) this.f;
                mk0 mk0 = (mk0) this.g;
                int intValue = ((Integer) obj).intValue();
                if (!((Boolean) mk0.getValue()).booleanValue()) {
                    lg0.b.setValue(new ad(wl1.d(intValue)));
                }
                return we1.a;
            case 11:
                Object obj3;
                Context context = (Context) this.f;
                Resources resources2 = (Resources) this.g;
                String str = (String) obj;
                we1 we12 = we1.a;
                str.getClass();
                try {
                    context.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(str)));
                    obj3 = we12;
                } catch (Throwable th2) {
                    obj3 = new px0(th2);
                }
                if (ak0.a(obj3) != null) {
                    Toast.makeText(context, resources2.getString(2131361937), 0).show();
                }
                return we12;
            case 12:
                th = (Throwable) obj;
                ((w20) this.f).g.removeCallbacks((e5) this.g);
                return we1.a;
            case 13:
                j50 j50 = (j50) this.f;
                h50 h50 = (h50) this.g;
                rqVar = (rq) obj;
                j50.a.b(h50);
                j50.b.setValue(Boolean.TRUE);
                return new al(1, j50, h50);
            case 14:
                vc0 vc0 = (vc0) this.f;
                Object obj4 = this.g;
                rqVar = (rq) obj;
                vc0.g.i(obj4);
                return new al(2, vc0, obj4);
            case 15:
                return new vc0((mz0) this.f, (Map) obj, (jz0) this.g);
            case 16:
                Set set = (Set) this.f;
                nj0 nj0 = (nj0) this.g;
                if (set.contains(obj)) {
                    hk0 hk0 = nj0.b;
                    ik0 = nj0.d;
                    AutofillManager g = ((AutofillManager) hk0);
                    if (g != null) {
                        if (g instanceof ik0) {
                            ik0 ik02 = (ik0) g;
                            Object[] objArr = ik02.b;
                            long[] jArr = ik02.a;
                            int length = jArr.length - 2;
                            if (length >= 0) {
                                i = 0;
                                while (true) {
                                    long j = jArr[i];
                                    if (((((~j) << 7) & j) & -9187201950435737472L) != -9187201950435737472L) {
                                        int i2 = 8 - ((~(i - length)) >>> 31);
                                        for (int i3 = 0; i3 < i2; i3++) {
                                            if ((255 & j) < 128) {
                                                ik0.a((z21) objArr[(i << 3) + i3]);
                                            }
                                            j >>= 8;
                                        }
                                        if (i2 != 8) {
                                        }
                                    }
                                    if (i != length) {
                                        i++;
                                    }
                                }
                            }
                        } else {
                            ik0.a((z21) g);
                        }
                    }
                }
                return we1.a;
            case 17:
                ((nj0) this.f).c.add(new kj0(obj, (z21) this.g));
                return we1.a;
            case 18:
                rp0 rp0 = (rp0) this.f;
                ks0 ks0 = (ks0) this.g;
                js0 js0 = (js0) obj;
                boolean z2 = rp0.w;
                float f = rp0.s;
                if (z2) {
                    js0.getClass();
                    js0.j(js0, ks0, fu0.k(f, js0), fu0.k(rp0.t, js0));
                } else {
                    js0.getClass();
                    js0.h(js0, ks0, fu0.k(f, js0), fu0.k(rp0.t, js0));
                }
                return we1.a;
            case 19:
                yj yjVar = (yj) this.f;
                ik0 = (ik0) this.g;
                yjVar.z(obj);
                if (ik0 != null) {
                    ik0.a(obj);
                }
                return we1.a;
            case 20:
                dw0 dw0 = (dw0) this.f;
                Throwable th3 = (Throwable) this.g;
                th = (Throwable) obj;
                synchronized (dw0.c) {
                    if (th3 == null) {
                        th3 = null;
                    } else if (th != null) {
                        try {
                            if (th instanceof CancellationException) {
                                th = null;
                            }
                            if (th != null) {
                                ac.i(th3, th);
                            }
                        } catch (Throwable th22) {
                            th3 = th22;
                        }
                    }
                    dw0.e = th3;
                    d81 d81 = dw0.u;
                    aw0 aw0 = aw0.e;
                    d81.getClass();
                    d81.i(null, aw0);
                }
                return we1.a;
            case 21:
                ((sk0) this.f).a.setValue(new uu((dj1) this.g, (dj1) obj));
                return we1.a;
            case 22:
                w11 w11 = (w11) this.f;
                y11 y11 = (y11) this.g;
                mr mrVar = (mr) obj;
                float f2 = mrVar.b ? -1.0f : 1.0f;
                long j2 = mrVar.a;
                w11.a(1, xm0.g(y11.d == bp0.f ? kc0.a(1, j2) : kc0.a(2, j2), f2));
                return we1.a;
            case 23:
                String str2 = (String) this.f;
                i00 = (i00) this.g;
                fc0 fc0 = (fc0) obj;
                fc0.getClass();
                List list = ub1.d;
                i = list.size();
                cd cdVar = new cd(3, list);
                pi piVar = new pi(802480018, true, new r31(list, str2, i00));
                i6 i6Var = fc0.a;
                al alVar = new al(9, cdVar, piVar);
                i6Var.getClass();
                if (i < 0) {
                    FileProvider.a("size should be >=0");
                }
                if (i != 0) {
                    f70 f70 = new f70(i6Var.b, i, alVar);
                    i6Var.b += i;
                    ((qk0) i6Var.c).b(f70);
                }
                return we1.a;
            case 24:
                rqVar = (rq) obj;
                wl1.B((bm) this.f, null, new f81((ed1) this.g, null), 1);
                return new h90(0);
            case 25:
                ed1 = (ed1) this.f;
                ed1 ed12 = (ed1) this.g;
                rqVar = (rq) obj;
                ed1.j.add(ed12);
                return new al(4, ed1, ed12);
            case 26:
                rqVar = (rq) obj;
                return new al(5, (ed1) this.f, (zc1) this.g);
            case 27:
                ed1 = (ed1) this.f;
                bd1 bd1 = (bd1) this.g;
                rqVar = (rq) obj;
                ed1.i.add(bd1);
                return new al(6, ed1, bd1);
            case 28:
                mf1 mf1 = (mf1) this.f;
                i00 = (i00) this.g;
                ((Long) obj).getClass();
                float f3 = mf1.e;
                mf1.e = 0.0f;
                i00.i(Float.valueOf(f3));
                return we1.a;
            default:
                lk1 lk1 = (lk1) this.f;
                View view = (View) this.g;
                rqVar = (rq) obj;
                f60 f60 = lk1.u;
                if (lk1.t == 0) {
                    i = vg1.a;
                    qg1.b(view, f60);
                    if (view.isAttachedToWindow()) {
                        view.requestApplyInsets();
                    }
                    view.addOnAttachStateChangeListener(f60);
                    vg1.b(view, f60);
                }
                lk1.t++;
                return new al(7, lk1, view);
        }
    }

    public /* synthetic */ c(int i, Object obj, Object obj2) {
        this.e = i;
        this.f = obj;
        this.g = obj2;
    }
}