package defpackage;

import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: be0 */
public final class be0 extends ul implements bp {
    public static final /* synthetic */ AtomicIntegerFieldUpdater l = AtomicIntegerFieldUpdater.newUpdater(be0.class, "runningWorkers$volatile");
    public final /* synthetic */ bp g;
    public final ul h;
    public final int i;
    public final pf0 j;
    public final Object k;
    private volatile /* synthetic */ int runningWorkers$volatile;

    public final void e(sl slVar, Runnable runnable) {
        this.j.a(runnable);
        AtomicIntegerFieldUpdater atomicIntegerFieldUpdater = l;
        if (atomicIntegerFieldUpdater.get(this) < this.i) {
            Object obj;
            synchronized (this.k) {
                AtomicIntegerFieldUpdater atomicIntegerFieldUpdater2 = l;
                if (atomicIntegerFieldUpdater2.get(this) >= this.i) {
                    obj = null;
                } else {
                    atomicIntegerFieldUpdater2.incrementAndGet(this);
                    obj = 1;
                }
            }
            if (obj != null) {
                runnable = j();
                if (runnable != null) {
                    try {
                        wl1.H(this.h, this, new ae0(this, runnable));
                    } catch (Throwable th) {
                        atomicIntegerFieldUpdater.decrementAndGet(this);
                    }
                }
            }
        }
    }

    public final Runnable j() {
        while (true) {
            Runnable runnable = (Runnable) this.j.d();
            if (runnable != null) {
                return runnable;
            }
            synchronized (this.k) {
                AtomicIntegerFieldUpdater atomicIntegerFieldUpdater = l;
                atomicIntegerFieldUpdater.decrementAndGet(this);
                if (this.j.c() == 0) {
                    return null;
                }
                atomicIntegerFieldUpdater.incrementAndGet(this);
            }
        }
    }

    public be0(ul ulVar, int i) {
        bp bpVar = ulVar instanceof bp ? (bp) ulVar : null;
        if (bpVar == null) {
            bpVar = go.a;
        }
        this.g = bpVar;
        this.h = ulVar;
        this.i = i;
        this.j = new pf0();
        this.k = new Object();
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.h);
        stringBuilder.append(".limitedParallelism(");
        return fu0.G(stringBuilder, this.i, ')');
    }

    public final sq c(long j, jc1 jc1, sl slVar) {
        return this.g.c(j, jc1, slVar);
    }

    public final void d(long j, ne neVar) {
        this.g.d(j, neVar);
    }
}