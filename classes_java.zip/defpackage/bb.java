package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bb */
public final class bb extends li0 implements ds, vm0, g21 {
    public long s;
    public y41 t;
    public long u;
    public o90 v;
    public jb0 w;
    public y41 x;
    public jb0 y;

    public final void C(da0 da0) {
        da0 da02;
        da0 da03 = da0;
        te teVar = da03.e;
        long j;
        if (this.t != vn.j) {
            jb0 jb0;
            tv tvVar = tv.F;
            if (d90.a(teVar.f.t(), this.u) && da03.getLayoutDirection() == this.v && k70.p(this.x, this.t)) {
                jb0 = this.w;
                jb0.getClass();
            } else {
                sb0.r(this, new al(1, this, da03));
                jb0 = this.y;
                this.y = null;
            }
            this.w = jb0;
            this.u = teVar.f.t();
            this.v = da03.getLayoutDirection();
            this.x = this.t;
            jb0.getClass();
            if (n60.c(this.s, zg.i) == null) {
                long j2 = this.s;
                long floatToRawIntBits;
                long floatToRawIntBits2;
                if (jb0 instanceof ep0) {
                    gw0 gw0 = ((ep0) jb0).b;
                    float f = gw0.a;
                    floatToRawIntBits = (long) Float.floatToRawIntBits(f);
                    floatToRawIntBits2 = 4294967295L & ((long) Float.floatToRawIntBits(gw0.d - gw0.b));
                    j = j2;
                    da02 = da0;
                    da02.k(j, (((long) Float.floatToRawIntBits(gw0.b)) & 4294967295L) | (floatToRawIntBits << 32), floatToRawIntBits2 | (((long) Float.floatToRawIntBits(gw0.c - gw0.a)) << 32), tvVar, 3);
                } else {
                    r6 r6Var;
                    da02 = da03;
                    if (jb0 instanceof fp0) {
                        fp0 fp0 = (fp0) jb0;
                        r6Var = fp0.c;
                        if (r6Var == null) {
                            my0 my0 = fp0.b;
                            float f2 = my0.b;
                            float f3 = my0.a;
                            float intBitsToFloat = Float.intBitsToFloat((int) (my0.h >> 32));
                            long floatToRawIntBits3 = (((long) Float.floatToRawIntBits(f3)) << 32) | (((long) Float.floatToRawIntBits(f2)) & 4294967295L);
                            float f4 = my0.c - f3;
                            long j3 = 4294967295L;
                            floatToRawIntBits2 = ((long) Float.floatToRawIntBits(my0.d - f2)) & j3;
                            floatToRawIntBits2 |= ((long) Float.floatToRawIntBits(f4)) << 32;
                            floatToRawIntBits = ((long) Float.floatToRawIntBits(intBitsToFloat)) & j3;
                            floatToRawIntBits |= ((long) Float.floatToRawIntBits(intBitsToFloat)) << 32;
                            re reVar = teVar.e.c;
                            int i = (int) (floatToRawIntBits3 >> 32);
                            int i2 = (int) (floatToRawIntBits3 & j3);
                            re reVar2 = reVar;
                            reVar2.h(Float.intBitsToFloat(i), Float.intBitsToFloat(i2), Float.intBitsToFloat((int) (floatToRawIntBits2 >> 32)) + Float.intBitsToFloat(i), Float.intBitsToFloat((int) (floatToRawIntBits2 & j3)) + Float.intBitsToFloat(i2), Float.intBitsToFloat((int) (floatToRawIntBits >> 32)), Float.intBitsToFloat((int) (floatToRawIntBits & j3)), te.c(teVar, j2, tvVar, 3));
                        }
                    } else if (jb0 instanceof dp0) {
                        r6Var = ((dp0) jb0).b;
                    } else {
                        od.k();
                        return;
                    }
                    da02.e(r6Var, j2, tvVar);
                }
                da02.c();
            }
        } else if (n60.c(this.s, zg.i) == null) {
            j = this.s;
            da02 = da0;
            fu0.x(da02, j, 0, 126);
            da03 = da02;
        }
        da02 = da03;
        da02.c();
    }

    public final void z() {
        this.u = 9205357640488583168L;
        this.v = null;
        this.w = null;
        this.x = null;
        a5.x(this);
    }

    public final void Q(r21 r21) {
        p21.b(r21, this.t);
    }

    public final /* synthetic */ boolean S() {
        return false;
    }

    public final /* synthetic */ boolean T() {
        return false;
    }

    public final boolean e() {
        return false;
    }

    public final /* synthetic */ void Z() {
    }
}