package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ba1 */
public final /* synthetic */ class ba1 implements m00 {
    public final /* synthetic */ mi0 e;
    public final /* synthetic */ boolean f;
    public final /* synthetic */ boolean g;
    public final /* synthetic */ z91 h;
    public final /* synthetic */ uj0 i;
    public final /* synthetic */ y41 j;
    public final /* synthetic */ int k;

    public final Object f(Object obj, Object obj2) {
        d10 d10 = (d10) obj;
        ((Integer) obj2).getClass();
        ca1.b(this.e, this.f, this.g, this.h, this.i, this.j, d10, wc0.s(this.k | 1));
        return we1.a;
    }

    public /* synthetic */ ba1(mi0 mi0, boolean z, boolean z2, z91 z91, uj0 uj0, y41 y41, int i) {
        this.e = mi0;
        this.f = z;
        this.g = z2;
        this.h = z91;
        this.i = uj0;
        this.j = y41;
        this.k = i;
    }
}