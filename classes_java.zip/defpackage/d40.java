package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: d40 */
public final class d40 {
    public static final /* synthetic */ int e = 0;
    public final boolean a = true;
    public final int b = 1;
    public final int c = 1;
    public final if0 d;

    public final String toString() {
        StringBuilder dl1 = new dl1("ImeOptions(singleLine=false, capitalization=");
        Object obj = "None";
        dl1.append(obj);
        dl1.append(", autoCorrect=");
        dl1.append(this.a);
        dl1.append(", keyboardType=");
        String str = "Invalid";
        String str2 = "Unspecified";
        int i = this.b;
        Object obj2 = i == 0 ? str2 : i == 1 ? "Text" : i == 2 ? "Ascii" : i == 3 ? "Number" : i == 4 ? "Phone" : i == 5 ? "Uri" : i == 6 ? "Email" : i == 7 ? "Password" : i == 8 ? "NumberPassword" : i == 9 ? "Decimal" : str;
        dl1.append(obj2);
        dl1.append(", imeAction=");
        int i2 = this.c;
        if (i2 == -1) {
            obj = str2;
        } else if (i2 != 0) {
            obj = i2 == 1 ? "Default" : i2 == 2 ? "Go" : i2 == 3 ? "Search" : i2 == 4 ? "Send" : i2 == 5 ? "Previous" : i2 == 6 ? "Next" : i2 == 7 ? "Done" : str;
        }
        dl1.append(obj);
        dl1.append(", platformImeOptions=null, hintLocales=");
        dl1.append(this.d);
        dl1.append(')');
        return dl1.toString();
    }

    public final boolean equals(Object obj) {
        if (this != obj) {
            if (obj instanceof d40) {
                d40 d40 = (d40) obj;
                if (this.a == d40.a) {
                    if (this.b == d40.b && this.c == d40.c) {
                        if (!k70.p(this.d, d40.d)) {
                        }
                    }
                }
            }
            return false;
        }
        return true;
    }

    public final int hashCode() {
        return this.d.e.hashCode() + ((((((1188757 + (this.a ? 1231 : 1237)) * 31) + this.b) * 31) + this.c) * 961);
    }

    public d40() {
        if0 if0 = if0.g;
        this.d = if0;
    }

    static {
        d40 d40 = new d40();
    }
}