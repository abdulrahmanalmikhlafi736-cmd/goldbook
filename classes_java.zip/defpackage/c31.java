package defpackage;

import android.view.autofill.AutofillValue;
import java.util.Iterator;
import java.util.NoSuchElementException;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: c31 */
public final class c31 implements Iterator, ml, w80 {
    public int e;
    public Object f;
    public ml g;

    public final Object next() {
        int i = this.e;
        if (i == 0 || i == 1) {
            if (hasNext()) {
                return next();
            }
            od.n();
            return null;
        } else if (i == 2) {
            this.e = 1;
            throw null;
        } else if (i == 3) {
            this.e = 0;
            Object obj = this.f;
            this.f = null;
            return obj;
        } else {
            throw a();
        }
    }

    public final RuntimeException a() {
        int i = this.e;
        if (i == 4) {
            return new NoSuchElementException();
        }
        if (i == 5) {
            return new dl1("Iterator has failed.");
        }
        StringBuilder dl1 = new dl1("Unexpected state of the iterator: ");
        dl1.append(this.e);
        return new dl1(dl1.toString());
    }

    public final boolean hasNext() {
        int i;
        while (true) {
            i = this.e;
            if (i != 0) {
                break;
            }
            this.e = 5;
            ml mlVar = this.g;
            mlVar.getClass();
            this.g = null;
            ((AutofillValue) mlVar);
        }
        if (i == 1) {
            throw null;
        } else if (i == 2 || i == 3) {
            return true;
        } else {
            if (i == 4) {
                return false;
            }
            throw a();
        }
    }

    public final void b(Object obj, ox0 ox0) {
        this.f = obj;
        this.e = 3;
        this.g = ox0;
    }

    public final void remove() {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final AutofillValue h(Object obj) {
        nb0.t(obj);
        this.e = 4;
        return;
    }

    public final sl e() {
        return st.e;
    }
}