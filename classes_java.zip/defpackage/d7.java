package defpackage;

import android.os.Handler;
import android.view.Choreographer;
import java.util.ArrayList;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: d7 */
public final class d7 extends ul {
    public static final da1 q = new ad0(b5.o);
    public static final b7 r = new h90(0);
    public final Choreographer g;
    public final Handler h;
    public final Object i = new Object();
    public final t9 j = new t9();
    public ArrayList k = new ArrayList();
    public ArrayList l = new ArrayList();
    public boolean m;
    public boolean n;
    public final c7 o = new c7(this);
    public final g7 p;

    public d7(Choreographer choreographer, Handler handler) {
        this.g = choreographer;
        this.h = handler;
        this.p = new g7(choreographer, this);
    }

    public final void e(sl slVar, Runnable runnable) {
        synchronized (this.i) {
            this.j.addLast(runnable);
            if (!this.m) {
                this.m = true;
                this.h.post(this.o);
                if (!this.n) {
                    this.n = true;
                    this.g.postFrameCallback(this.o);
                }
            }
        }
    }

    public static final void j(d7 d7Var) {
        boolean z;
        do {
            Runnable l = d7Var.l();
            while (l != null) {
                l.run();
                l = d7Var.l();
            }
            synchronized (d7Var.i) {
                if (d7Var.j.isEmpty()) {
                    z = false;
                    d7Var.m = false;
                } else {
                    z = true;
                }
            }
        } while (z);
    }

    public final Runnable l() {
        Runnable runnable;
        synchronized (this.i) {
            t9 t9Var = this.j;
            runnable = (Runnable) (t9Var.isEmpty() ? null : t9Var.removeFirst());
        }
        return runnable;
    }
}