package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: a10 */
public final class a10 implements ww0 {
    public final b10 e;

    public a10(b10 b10) {
        this.e = b10;
    }

    public final void d() {
        this.e.w();
    }

    public final void e() {
        this.e.w();
    }

    public final void c() {
    }
}