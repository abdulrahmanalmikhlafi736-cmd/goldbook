package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: da */
public final class da {
    public final int a;

    public final String toString() {
        StringBuilder dl1 = new dl1("AutoClearFocusBehavior(value=");
        dl1.append(this.a);
        dl1.append(')');
        return dl1.toString();
    }

    public final boolean equals(Object obj) {
        if (obj instanceof da) {
            if (this.a == ((da) obj).a) {
                return true;
            }
        }
        return false;
    }

    public /* synthetic */ da(int i) {
        this.a = i;
    }

    public final int hashCode() {
        return this.a;
    }
}