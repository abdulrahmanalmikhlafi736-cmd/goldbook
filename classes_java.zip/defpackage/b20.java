package defpackage;

import android.content.Context;
import android.view.autofill.AutofillManager$AutofillCallback;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: b20 */
public final /* synthetic */ class b20 implements n00 {
    public final /* synthetic */ jz0 e;
    public final /* synthetic */ mk0 f;
    public final /* synthetic */ String g;
    public final /* synthetic */ t41 h;
    public final /* synthetic */ Context i;

    public final Object c(Object obj, Object obj2, Object obj3) {
        String str = (String) obj;
        d10 d10 = (d10) obj2;
        int intValue = ((Integer) obj3).intValue();
        str.getClass();
        if ((intValue & 6) == 0) {
            intValue |= ((AutofillManager$AutofillCallback) d10) != null ? 4 : 2;
        }
        if (d10.O(intValue & 1, (intValue & 19) != 18)) {
            this.e.b(str, vd1.A(95990074, new d20(str, this.f, this.g, this.h, this.i), d10), d10, (intValue & 14) | 48);
        } else {
            d10.R();
        }
        return we1.a;
    }

    public /* synthetic */ b20(kz0 kz0, mk0 mk0, String str, t41 t41, Context context) {
        this.e = kz0;
        this.f = mk0;
        this.g = str;
        this.h = t41;
        this.i = context;
    }
}