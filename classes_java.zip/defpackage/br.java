package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: br */
public final class br implements Comparable {
    public final float e;

    public static String c(float f) {
        if (Float.isNaN(f)) {
            return "Dp.Unspecified";
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(f);
        stringBuilder.append(".dp");
        return stringBuilder.toString();
    }

    public final boolean equals(Object obj) {
        if (obj instanceof br) {
            if (Float.compare(this.e, ((br) obj).e) == 0) {
                return true;
            }
        }
        return false;
    }

    public static int a(float f, float f2) {
        if (!Float.isNaN(f)) {
            if (!Float.isNaN(f2)) {
                return Float.compare(f, f2);
            }
        }
        return 0;
    }

    public final int compareTo(Object obj) {
        return br.a(this.e, ((br) obj).e);
    }

    public static final boolean b(float f, float f2) {
        return Float.compare(f, f2) == 0;
    }

    public final int hashCode() {
        return Float.floatToIntBits(this.e);
    }

    public final String toString() {
        return br.c(this.e);
    }

    public /* synthetic */ br(float f) {
        this.e = f;
    }
}