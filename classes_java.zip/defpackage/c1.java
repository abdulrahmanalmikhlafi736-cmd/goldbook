package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: c1 */
public abstract /* synthetic */ class c1 {
    /*  JADX ERROR: IndexOutOfBoundsException in pass: MethodInlineVisitor
        java.lang.IndexOutOfBoundsException: Index 0 out of bounds for length 0
        	at jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        	at jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        	at jdk.internal.util.Preconditions.checkIndex(Preconditions.java:266)
        	at java.util.Objects.checkIndex(Objects.java:391)
        	at java.util.ArrayList.get(ArrayList.java:434)
        	at jadx.core.dex.visitors.MethodInlineVisitor.inlineMth(Unknown Source:26)
        	at jadx.core.dex.visitors.MethodInlineVisitor.visit(Unknown Source:67)
        	at jadx.core.dex.visitors.DepthTraversal.visit(Unknown Source:9)
        	at jadx.core.dex.visitors.DepthTraversal.visit(Unknown Source:41)
        	at jadx.core.ProcessClass.process(Unknown Source:54)
        	at jadx.core.ProcessClass.processDependencies(Unknown Source:22)
        	at jadx.core.ProcessClass.process(Unknown Source:68)
        	at jadx.api.JadxDecompiler.processClass(Unknown Source:4)
        	at jadx.api.JavaClass.decompile(Unknown Source:19)
        */
    public static /* synthetic */ void m() {
        /*
        r0 = new android.view.WindowInsetsAnimation$Bounds;
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: c1.m():void");
    }
}