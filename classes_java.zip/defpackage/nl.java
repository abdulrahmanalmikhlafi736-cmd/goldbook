package defpackage;

import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: nl */
public abstract class nl extends db {
    public final sl f;
    public transient ml g;

    public void q() {
        Object obj = this.g;
        if (!(obj == null || obj == this)) {
            ql k = e().k(e3.B);
            k.getClass();
            ul ulVar = (ul) k;
            gq gqVar = (gq) obj;
            AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = gq.l;
            do {
            } while (atomicReferenceFieldUpdater.get(gqVar) == wl1.d);
            obj = atomicReferenceFieldUpdater.get(gqVar);
            ne neVar = obj instanceof ne ? (ne) obj : null;
            if (neVar != null) {
                neVar.p();
            }
        }
        this.g = wh.f;
    }

    public nl(ml mlVar) {
        this(mlVar, mlVar != null ? mlVar.e() : null);
    }

    public sl e() {
        sl slVar = this.f;
        slVar.getClass();
        return slVar;
    }

    public nl(ml mlVar, sl slVar) {
        super(mlVar);
        this.f = slVar;
    }
}