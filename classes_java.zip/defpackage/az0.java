package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: az0 */
public abstract class az0 {
    public static final n00 a;

    static {
        zy0 zy0 = zy0.l;
        vd1.e(3, zy0);
        a = zy0;
    }
}