package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: zd1 */
public class zd1 extends jb0 {
    /*  JADX ERROR: NullPointerException in pass: BlockSplitter
        java.lang.NullPointerException: Attempt to invoke virtual method 'boolean jadx.core.dex.attributes.AttrNode.contains(jadx.core.dex.attributes.AType)' on a null object reference
        	at jadx.core.dex.visitors.blocksmaker.BlockSplitter.connectExceptionHandlers(Unknown Source:64)
        	at jadx.core.dex.visitors.blocksmaker.BlockSplitter.setupConnections(Unknown Source:58)
        	at jadx.core.dex.visitors.blocksmaker.BlockSplitter.splitBasicBlocks(Unknown Source:22)
        	at jadx.core.dex.visitors.blocksmaker.BlockSplitter.visit(Unknown Source:13)
        	at jadx.core.dex.visitors.DepthTraversal.visit(Unknown Source:9)
        	at jadx.core.dex.visitors.DepthTraversal.visit(Unknown Source:41)
        	at jadx.core.ProcessClass.process(Unknown Source:54)
        	at jadx.api.JadxDecompiler.processClass(Unknown Source:4)
        	at jadx.api.JavaClass.decompile(Unknown Source:19)
        */
    public android.graphics.Typeface e(android.content.Context r3, defpackage.rz[] r4) {
        /*
        r2 = this;
        r2 = r4.length;
        r0 = 1;
        r1 = 0;
        if (r2 >= r0) goto L_0x0007;
    L_0x0005:
        goto L_0x00a1;
    L_0x0007:
        r2 = defpackage.jb0.i(r4);
        r4 = r3.getContentResolver();
        r2 = r2.a;	 Catch:{ IOException -> 0x00a1 }
        r0 = "r";	 Catch:{ IOException -> 0x00a1 }
        r2 = r4.openFileDescriptor(r2, r0, r1);	 Catch:{ IOException -> 0x00a1 }
        if (r2 != 0) goto L_0x001f;	 Catch:{ IOException -> 0x00a1 }
    L_0x0019:
        if (r2 == 0) goto L_0x00a1;	 Catch:{ IOException -> 0x00a1 }
    L_0x001b:
        r2.close();	 Catch:{ IOException -> 0x00a1 }
        return r1;
    L_0x001f:
        r4 = "/proc/self/fd/";	 Catch:{ all -> 0x0059 }
        r0 = new java.lang.StringBuilder;	 Catch:{ ErrnoException -> 0x0047 }
        r0.<init>(r4);	 Catch:{ ErrnoException -> 0x0047 }
        r4 = r2.getFd();	 Catch:{ ErrnoException -> 0x0047 }
        r0.append(r4);	 Catch:{ ErrnoException -> 0x0047 }
        r4 = r0.toString();	 Catch:{ ErrnoException -> 0x0047 }
        r4 = android.system.Os.readlink(r4);	 Catch:{ ErrnoException -> 0x0047 }
        r0 = android.system.Os.stat(r4);	 Catch:{ ErrnoException -> 0x0047 }
        r0 = r0.st_mode;	 Catch:{ ErrnoException -> 0x0047 }
        r0 = android.system.OsConstants.S_ISREG(r0);	 Catch:{ ErrnoException -> 0x0047 }
        if (r0 == 0) goto L_0x0047;	 Catch:{ ErrnoException -> 0x0047 }
    L_0x0041:
        r0 = new java.io.File;	 Catch:{ ErrnoException -> 0x0047 }
        r0.<init>(r4);	 Catch:{ ErrnoException -> 0x0047 }
        goto L_0x0048;
    L_0x0047:
        r0 = r1;
    L_0x0048:
        if (r0 == 0) goto L_0x005b;
    L_0x004a:
        r4 = r0.canRead();
        if (r4 != 0) goto L_0x0051;
    L_0x0050:
        goto L_0x005b;
    L_0x0051:
        r3 = android.graphics.Typeface.createFromFile(r0);
        r2.close();
        return r3;
        r3 = move-exception;
        goto L_0x0098;
    L_0x005b:
        r4 = new java.io.FileInputStream;
        r0 = r2.getFileDescriptor();
        r4.<init>(r0);
        r3 = defpackage.kb0.o(r3);	 Catch:{ all -> 0x008e }
        if (r3 != 0) goto L_0x006c;
    L_0x006a:
        r0 = r1;
        goto L_0x0087;
    L_0x006c:
        r0 = defpackage.kb0.i(r3, r4);	 Catch:{ RuntimeException -> 0x0072, all -> 0x0082 }
        if (r0 != 0) goto L_0x0076;
    L_0x0072:
        r3.delete();
        goto L_0x006a;
    L_0x0076:
        r0 = r3.getPath();
        r0 = android.graphics.Typeface.createFromFile(r0);
        r3.delete();
        goto L_0x0087;
        r0 = move-exception;
        r3.delete();
        throw r0;
    L_0x0087:
        r4.close();
        r2.close();
        return r0;
        r3 = move-exception;
        r4.close();	 Catch:{ all -> 0x0093 }
        goto L_0x0097;
        r4 = move-exception;
        r3.addSuppressed(r4);
    L_0x0097:
        throw r3;
    L_0x0098:
        r2.close();	 Catch:{ all -> 0x009c }
        goto L_0x00a0;
        r2 = move-exception;
        r3.addSuppressed(r2);
    L_0x00a0:
        throw r3;
    L_0x00a1:
        return r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: zd1.e(android.content.Context, rz[]):android.graphics.Typeface");
    }
}