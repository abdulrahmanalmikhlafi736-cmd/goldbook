package defpackage;

import android.view.DisplayCutout;
import android.view.WindowInsets;
import java.util.Objects;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: xj1 */
public class xj1 extends wj1 {
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof xj1)) {
            return false;
        }
        xj1 xj1 = (xj1) obj;
        return Objects.equals(this.c, xj1.c) && Objects.equals(this.g, xj1.g) && vj1.M(this.h, xj1.h);
    }

    public mq h() {
        DisplayCutout d = this.c.getDisplayCutout();
        return d == null ? null : new mq(d);
    }

    public hk1 a() {
        return hk1.c(null, this.c.consumeDisplayCutout());
    }

    public int hashCode() {
        return this.c.hashCode();
    }

    public xj1(hk1 hk1, WindowInsets windowInsets) {
        super(hk1, windowInsets);
    }

    public xj1(hk1 hk1, xj1 xj1) {
        super(hk1, (wj1) xj1);
    }
}