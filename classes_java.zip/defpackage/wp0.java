package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: wp0 */
public abstract class wp0 {
    public k6 a;
    public pb b;
    public float c = 1.0f;
    public o90 d = o90.e;

    public final void c(da0 da0, long j, float f, pb pbVar) {
        te teVar = da0.e;
        if (this.c != f) {
            a(f);
            this.c = f;
        }
        if (!k70.p(this.b, pbVar)) {
            b(pbVar);
            this.b = pbVar;
        }
        o90 layoutDirection = da0.getLayoutDirection();
        if (this.d != layoutDirection) {
            this.d = layoutDirection;
        }
        int i = (int) (j >> 32);
        float intBitsToFloat = Float.intBitsToFloat((int) (da0.b() >> 32)) - Float.intBitsToFloat(i);
        int i2 = (int) (j & 4294967295L);
        float intBitsToFloat2 = Float.intBitsToFloat((int) (da0.b() & 4294967295L)) - Float.intBitsToFloat(i2);
        ((pg0) teVar.f.f).s(0.0f, 0.0f, intBitsToFloat, intBitsToFloat2);
        if (f > 0.0f) {
            try {
                if (Float.intBitsToFloat(i) > 0.0f && Float.intBitsToFloat(i2) > 0.0f) {
                    e(da0);
                }
            } catch (Throwable th) {
                ((pg0) teVar.f.f).s(-0.0f, -0.0f, -intBitsToFloat, -intBitsToFloat2);
            }
        }
        ((pg0) teVar.f.f).s(-0.0f, -0.0f, -intBitsToFloat, -intBitsToFloat2);
    }

    public abstract void a(float f);

    public abstract void b(pb pbVar);

    public abstract long d();

    public abstract void e(da0 da0);
}