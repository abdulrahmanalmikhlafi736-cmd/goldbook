package defpackage;

import java.io.Serializable;
import java.util.Iterator;
import java.util.List;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: an */
public final class an extends u91 implements i00 {
    public Object i;
    public Serializable j;
    public Object k;
    public Object l;
    public Iterator m;
    public int n;
    public int o;
    public final /* synthetic */ tn p;
    public final /* synthetic */ p3 q;

    /* JADX WARNING: Removed duplicated region for block: B:34:0x00e8  */
    /* JADX WARNING: Removed duplicated region for block: B:33:0x00e3  */
    /* JADX WARNING: Removed duplicated region for block: B:38:0x00fe  */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x00a5  */
    /* JADX WARNING: Removed duplicated region for block: B:29:0x00d8  */
    /* JADX WARNING: Removed duplicated region for block: B:28:0x00d7  */
    /* JADX WARNING: Removed duplicated region for block: B:28:0x00d7  */
    /* JADX WARNING: Removed duplicated region for block: B:29:0x00d8  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final Object p(Object obj) {
        cl0 cl0;
        jw0 obj2;
        nw0 obj3;
        Serializable serializable;
        Iterator it;
        Object obj4;
        Serializable serializable2;
        Serializable serializable3;
        a01 a01;
        a01 a012;
        int i = this.o;
        p3 p3Var = this.q;
        tn tnVar = this.p;
        Object obj5 = cm.e;
        nw0 nw0;
        jw0 jw0;
        q51 h;
        Integer a;
        Object obj6;
        if (i == 0) {
            nb0.t(obj);
            cl0 = new cl0();
            obj2 = new Object();
            obj3 = new Object();
            this.i = cl0;
            this.j = obj2;
            this.k = obj3;
            this.l = obj3;
            this.o = 1;
            obj = tn.g(tnVar, true, this);
            if (obj == obj5) {
                return obj5;
            }
            serializable = obj3;
        } else if (i == 1) {
            obj3 = (nw0) this.l;
            serializable = (nw0) this.k;
            obj2 = (jw0) this.j;
            cl0 = (cl0) this.i;
            nb0.t(obj);
        } else if (i == 2) {
            it = this.m;
            obj4 = (zm) this.l;
            serializable2 = (nw0) this.k;
            serializable3 = (jw0) this.j;
            a01 = (cl0) this.i;
            nb0.t(obj);
            while (it.hasNext()) {
                m00 m00 = (m00) it.next();
                this.i = a01;
                this.j = serializable3;
                this.k = serializable2;
                this.l = obj4;
                this.m = it;
                this.o = 2;
                if (m00.f(obj4, this) == obj5) {
                    break;
                }
            }
            serializable = serializable2;
            obj2 = serializable3;
            a012 = a01;
            p3Var.g = null;
            this.i = obj2;
            this.j = serializable;
            this.k = a012;
            this.l = null;
            this.m = null;
            this.o = 3;
            if (a012.c(this) == obj5) {
                return obj5;
            }
            nw0 = serializable;
            jw0 = obj2;
            jw0.e = true;
            obj = nw0.e;
            if (obj == null) {
            }
            h = tnVar.h();
            this.i = obj;
            this.j = null;
            this.k = null;
            this.n = i;
            this.o = 4;
            a = h.a();
            if (a != obj5) {
            }
            return obj5;
        } else if (i == 3) {
            a012 = (cl0) this.k;
            nw0 = (nw0) this.j;
            jw0 = (jw0) this.i;
            nb0.t(obj);
            try {
                jw0.e = true;
                obj = nw0.e;
                i = obj == null ? obj.hashCode() : 0;
                h = tnVar.h();
                this.i = obj;
                this.j = null;
                this.k = null;
                this.n = i;
                this.o = 4;
                a = h.a();
                if (a != obj5) {
                    Object obj7 = obj;
                    obj = a;
                    obj6 = obj7;
                    return new hc(i, ((Number) obj).intValue(), obj6);
                }
                return obj5;
            } finally {
                a012.e(null);
            }
        } else if (i == 4) {
            i = this.n;
            obj6 = this.i;
            nb0.t(obj);
            return new hc(i, ((Number) obj).intValue(), obj6);
        } else {
            od.p("call to 'resume' before 'invoke' with coroutine");
            return null;
        }
        obj3.e = ((qm) obj).b;
        zm zmVar = new zm(cl0, obj2, serializable, tnVar);
        List list = (List) p3Var.g;
        if (list != null) {
            it = list.iterator();
            a01 = cl0;
            serializable3 = obj2;
            serializable2 = serializable;
            obj4 = zmVar;
            while (it.hasNext()) {
            }
            serializable = serializable2;
            obj2 = serializable3;
            a012 = a01;
            p3Var.g = null;
            this.i = obj2;
            this.j = serializable;
            this.k = a012;
            this.l = null;
            this.m = null;
            this.o = 3;
            if (a012.c(this) == obj5) {
            }
        } else {
            a012 = cl0;
            p3Var.g = null;
            this.i = obj2;
            this.j = serializable;
            this.k = a012;
            this.l = null;
            this.m = null;
            this.o = 3;
            if (a012.c(this) == obj5) {
            }
        }
    }

    public final Object i(Object obj) {
        return new an(this.p, this.q, (ml) obj).p(we1.a);
    }

    public an(tn tnVar, p3 p3Var, ml mlVar) {
        this.p = tnVar;
        this.q = p3Var;
        super(1, mlVar);
    }
}