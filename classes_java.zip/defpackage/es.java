package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: es */
public interface es extends jp {
    void D(h6 h6Var, long j, long j2, long j3, float f, pb pbVar, int i);

    long b();

    o90 getLayoutDirection();

    void k(long j, long j2, long j3, ac acVar, int i);

    void p(r6 r6Var, zi1 zi1, float f, ac acVar, int i);

    k9 u();
}