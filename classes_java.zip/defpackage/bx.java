package defpackage;

/* renamed from: bx */
public final class bx extends nl {
    public /* synthetic */ Object h;
    public int i;
    public final /* synthetic */ al j;
    public xq k;

    public final Object p(Object obj) {
        this.h = obj;
        this.i |= Integer.MIN_VALUE;
        return this.j.b(null, this);
    }

    public bx(al alVar, ml mlVar) {
        this.j = alVar;
        super(mlVar);
    }
}