package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ah */
public abstract class ah {
    public static final long A;
    public static final long B = aq0.h;
    public static final long C;
    public static final long D;
    public static final long E;
    public static final long F;
    public static final long G = aq0.o;
    public static final long H = aq0.k;
    public static final long I = aq0.l;
    public static final long J = aq0.n;
    public static final long K = aq0.i;
    public static final long L = aq0.p;
    public static final long M;
    public static final long N;
    public static final long O;
    public static final long P;
    public static final long Q;
    public static final long R;
    public static final long a = aq0.f;
    public static final long b = aq0.d;
    public static final long c = aq0.m;
    public static final long d = aq0.H;
    public static final long e;
    public static final long f = aq0.c;
    public static final long g = aq0.g;
    public static final long h = aq0.F;
    public static final long i;
    public static final long j = aq0.D;
    public static final long k;
    public static final long l = aq0.M;
    public static final long m;
    public static final long n = aq0.K;
    public static final long o;
    public static final long p;
    public static final long q = aq0.B;
    public static final long r = aq0.T;
    public static final long s;
    public static final long t = aq0.R;
    public static final long u;
    public static final long v = aq0.A;
    public static final long w;
    public static final long x;
    public static final long y;
    public static final long z;

    static {
        long j = aq0.q;
        long j2 = aq0.s;
        e = j2;
        long j3 = aq0.J;
        i = j3;
        long j4 = aq0.G;
        k = j4;
        long j5 = aq0.Q;
        m = j5;
        long j6 = aq0.N;
        o = j6;
        p = j2;
        j2 = aq0.X;
        s = j2;
        long j7 = aq0.U;
        u = j7;
        long j8 = aq0.y;
        w = j8;
        long j9 = aq0.I;
        x = j9;
        y = j4;
        z = j3;
        A = j9;
        j3 = aq0.P;
        C = j6;
        D = j5;
        E = j3;
        F = j;
        M = j;
        N = j8;
        j = aq0.W;
        O = j;
        P = j7;
        Q = j2;
        R = j;
    }
}