package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cg0 */
public final class cg0 extends js0 {
    public final /* synthetic */ int f;
    public final Object g;

    /* JADX WARNING: Removed duplicated region for block: B:25:0x00a6  */
    /* JADX WARNING: Removed duplicated region for block: B:30:0x0048 A:{SYNTHETIC} */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public float d(j30 j30) {
        switch (this.f) {
            case 0:
                m00 m00 = j30.a;
                float f = Float.NaN;
                if (m00 != null) {
                    f = ((Number) m00.f(this, Float.valueOf(Float.NaN))).floatValue();
                } else {
                    bg0 bg0 = (bg0) this.g;
                    if (!bg0.o) {
                        bg0 bg02 = bg0;
                        while (true) {
                            float f2;
                            wy0 wy0 = bg02.q;
                            if (wy0 != null) {
                                int f0 = ba.f0((j30[]) wy0.b, j30);
                                if (f0 >= 0) {
                                    f2 = ((float[]) wy0.c)[f0];
                                    if (Float.isNaN(f2)) {
                                        float intBitsToFloat;
                                        bg02.U(bg0.f0(), j30);
                                        n90 d0 = bg02.d0();
                                        n90 d02 = bg0.d0();
                                        long floatToRawIntBits;
                                        switch (j30.b) {
                                            case 0:
                                                floatToRawIntBits = ((long) Float.floatToRawIntBits(f2)) & 4294967295L;
                                                intBitsToFloat = Float.intBitsToFloat((int) (d02.v(d0, floatToRawIntBits | (((long) Float.floatToRawIntBits(((float) ((int) (d0.A() >> 32))) / 2.0f)) << 32)) & 4294967295L));
                                                break;
                                            default:
                                                floatToRawIntBits = (long) Float.floatToRawIntBits(f2);
                                                intBitsToFloat = Float.intBitsToFloat((int) (d02.v(d0, (floatToRawIntBits << 32) | (4294967295L & ((long) Float.floatToRawIntBits(((float) ((int) (d0.A() & 4294967295L))) / 2.0f)))) >> 32));
                                                break;
                                        }
                                        f = intBitsToFloat;
                                    } else {
                                        bg0 h0 = bg02.h0();
                                        if (h0 == null) {
                                            bg02.U(bg0.f0(), j30);
                                        } else {
                                            bg02 = h0;
                                        }
                                    }
                                }
                            }
                            f2 = Float.NaN;
                            if (Float.isNaN(f2)) {
                            }
                        }
                    }
                }
                return f;
            default:
                return super.d(j30);
        }
    }

    public final int f() {
        int i = this.f;
        Object obj = this.g;
        switch (i) {
            case 0:
                return ((bg0) obj).P();
            default:
                return ((n4) obj).getRoot().K.p.e;
        }
    }

    public final float a() {
        int i = this.f;
        Object obj = this.g;
        switch (i) {
            case 0:
                return ((bg0) obj).a();
            default:
                return ((n4) obj).getDensity().a();
        }
    }

    public final float g() {
        int i = this.f;
        Object obj = this.g;
        switch (i) {
            case 0:
                return ((bg0) obj).g();
            default:
                return ((n4) obj).getDensity().g();
        }
    }

    public final o90 e() {
        int i = this.f;
        Object obj = this.g;
        switch (i) {
            case 0:
                return ((bg0) obj).getLayoutDirection();
            default:
                return ((n4) obj).getLayoutDirection();
        }
    }

    public /* synthetic */ cg0(int i, Object obj) {
        this.f = i;
        this.g = obj;
    }
}