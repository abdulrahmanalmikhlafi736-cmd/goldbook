package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bg */
final class bg extends qi0 {
    public final uj0 a;
    public final t40 b;
    public final boolean c;
    public final boolean d;
    public final iy0 e;
    public final xz f;

    /* JADX WARNING: Missing block: B:23:0x0044, code:
            if (r2.f != r3.f) goto L_0x0046;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean equals(Object obj) {
        if (this != obj) {
            if (obj != null) {
                if (bg.class == obj.getClass()) {
                    bg bgVar = (bg) obj;
                    if (k70.p(this.a, bgVar.a)) {
                        if (k70.p(this.b, bgVar.b)) {
                            if (this.c == bgVar.c) {
                                if (this.d == bgVar.d) {
                                    if (k70.p(this.e, bgVar.e)) {
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return false;
        }
        return true;
    }

    public final int hashCode() {
        int i = 0;
        uj0 uj0 = this.a;
        int hashCode = (uj0 != null ? uj0.hashCode() : 0) * 31;
        t40 t40 = this.b;
        int i2 = 1237;
        hashCode = (((hashCode + (t40 != null ? t40.hashCode() : 0)) * 31) + (this.c ? 1231 : 1237)) * 31;
        if (this.d) {
            i2 = 1231;
        }
        hashCode = (hashCode + i2) * 961;
        iy0 iy0 = this.e;
        if (iy0 != null) {
            i = iy0.a;
        }
        return this.f.hashCode() + ((hashCode + i) * 31);
    }

    public final void f(li0 li0) {
        ((dg) li0).z0(this.a, this.b, this.c, this.d, this.e, this.f);
    }

    public final li0 e() {
        return new bg(this.a, this.b, this.c, this.d, this.e, this.f);
    }

    public bg(uj0 uj0, t40 t40, boolean z, boolean z2, iy0 iy0, xz xzVar) {
        this.a = uj0;
        this.b = t40;
        this.c = z;
        this.d = z2;
        this.e = iy0;
        this.f = xzVar;
    }
}