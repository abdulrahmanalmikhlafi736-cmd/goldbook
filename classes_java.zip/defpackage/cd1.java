package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cd1 */
public final /* synthetic */ class cd1 implements i00 {
    public final /* synthetic */ ed1 e;
    public final /* synthetic */ float f;

    public final Object i(Object obj) {
        long longValue = ((Long) obj).longValue();
        ed1 ed1 = this.e;
        boolean g = ed1.g();
        jq0 jq0 = ed1.g;
        if (!g) {
            if (jq0.g() == Long.MIN_VALUE) {
                jq0.h(longValue);
                ((lq0) ed1.a.f).setValue(Boolean.TRUE);
            }
            longValue -= jq0.g();
            float f = this.f;
            int i = (f > 0.0f ? 1 : (f == 0.0f ? 0 : -1));
            if (i != 0) {
                longValue = gh0.Q(((double) longValue) / ((double) f));
            }
            if (ed1.b == null) {
                ed1.f.h(longValue);
            }
            ed1.h(longValue, i == 0);
        }
        return we1.a;
    }

    public /* synthetic */ cd1(ed1 ed1, float f) {
        this.e = ed1;
        this.f = f;
    }
}