package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bf */
public final class bf extends af {
    public final Object e(uw uwVar, ml mlVar) {
        cm b = this.h.b(uwVar, mlVar);
        return b == cm.e ? b : we1.a;
    }

    public final af a(sl slVar, int i, gd gdVar) {
        return new af(this.h, slVar, i, gdVar);
    }

    public final tw d() {
        return this.h;
    }
}