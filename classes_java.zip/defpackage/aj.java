package defpackage;

import android.content.res.Resources;
import android.graphics.Rect;
import android.view.ScrollCaptureSession;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: aj */
public final class aj extends u91 implements m00 {
    public final /* synthetic */ int i;
    public int j;
    public Object k;
    public /* synthetic */ Object l;
    public final /* synthetic */ Object m;
    public final /* synthetic */ Object n;

    /* JADX WARNING: Removed duplicated region for block: B:61:0x0155  */
    /* JADX WARNING: Removed duplicated region for block: B:53:0x0123  */
    /* JADX WARNING: Removed duplicated region for block: B:58:0x0139  */
    /* JADX WARNING: Removed duplicated region for block: B:61:0x0155  */
    /* JADX WARNING: Removed duplicated region for block: B:53:0x0123  */
    /* JADX WARNING: Removed duplicated region for block: B:61:0x0155  */
    /* JADX WARNING: Removed duplicated region for block: B:53:0x0123  */
    /* JADX WARNING: Missing block: B:92:0x01f2, code:
            if (r0 == r8) goto L_0x01f4;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final Object p(Object obj) {
        int i = this.i;
        int i2 = 0;
        Object obj2 = we1.a;
        mt mtVar = this.n;
        Object obj3 = this.m;
        String str = "call to 'resume' before 'invoke' with coroutine";
        Object obj4 = cm.e;
        Object a;
        switch (i) {
            case 0:
                i = this.j;
                if (i == 0) {
                    nb0.t(obj);
                    cj cjVar = (cj) this.k;
                    ScrollCaptureSession scrollCaptureSession = (ScrollCaptureSession) this.l;
                    Rect rect = (Rect) obj3;
                    r60 r60 = new r60(rect.left, rect.top, rect.right, rect.bottom);
                    this.j = 1;
                    a = cj.a(cjVar, scrollCaptureSession, r60, this);
                    if (a == obj4) {
                        obj2 = obj4;
                        return obj2;
                    }
                } else if (i == 1) {
                    nb0.t(obj);
                    a = obj;
                } else {
                    od.p(str);
                    obj2 = null;
                    return obj2;
                }
                ((Consumer) mtVar).accept(dd0.x((r60) a));
                return obj2;
            case 1:
                d81 d81 = (d81) obj3;
                i = this.j;
                if (i == 0) {
                    nb0.t(obj);
                    i = ((i51) this.k).ordinal();
                    if (i == 0) {
                        tw twVar = (tw) this.l;
                        this.j = 1;
                        if (twVar.b(d81, this) == obj4) {
                            obj2 = obj4;
                        }
                    } else if (i != 1) {
                        if (i != 2) {
                            od.k();
                        } else if (mtVar != k70.t) {
                            d81.i(null, mtVar);
                        } else {
                            throw new dl1("MutableStateFlow.resetReplayCache is not supported");
                        }
                    }
                    return obj2;
                } else if (i == 1) {
                    nb0.t(obj);
                    return obj2;
                } else {
                    od.p(str);
                }
                obj2 = null;
                return obj2;
            case 2:
                tw twVar2 = (tw) this.l;
                d81 d812 = (d81) obj3;
                i = this.j;
                if (i != 0) {
                    if (i != 1) {
                        if (i == 2) {
                            nb0.t(obj);
                        } else if (!(i == 3 || i == 4)) {
                            od.p(str);
                            obj2 = null;
                            return obj2;
                        }
                    }
                    nb0.t(obj);
                    return obj2;
                }
                nb0.t(obj);
                k51 k51 = (k51) this.k;
                if (k51 == j51.a) {
                    this.j = 1;
                    if (twVar2.b(d812, this) == obj4) {
                        obj2 = obj4;
                    }
                    return obj2;
                }
                if (k51 != j51.b) {
                    tw u = wl1.u(k51.b(d812.g()));
                    aj ajVar = new aj(twVar2, d812, this.n, null, 1);
                    this.j = 4;
                    i = ex.a;
                    dx dxVar = new dx(ajVar, null);
                    dx dxVar2 = dxVar;
                    a = wl1.o(new ff(dxVar2, u, st.e, -2, gd.e), 0).b(om0.e, this);
                    if (a != obj4) {
                        a = obj2;
                    }
                    if (a != obj4) {
                        a = obj2;
                        break;
                    }
                    break;
                }
                j91 g = d812.g();
                ix u91 = new u91(2, null);
                this.j = 2;
                if (wl1.y(g, u91, this) == obj4) {
                }
                obj2 = obj4;
                return obj2;
                this.j = 3;
                if (twVar2.b(d812, this) == obj4) {
                    obj2 = obj4;
                }
                return obj2;
            case 3:
                i = this.j;
                bm bmVar;
                kw0 obj5;
                ho hoVar;
                kw0 kw0;
                bm bmVar2;
                bm bmVar3;
                if (i == 0) {
                    nb0.t(obj);
                    bmVar = (bm) this.l;
                    obj5 = new Object();
                    obj5.e = 1.0f;
                    hoVar = new ho((mk0) obj3, (j50) mtVar, obj5, bmVar);
                    this.l = bmVar;
                    this.k = obj5;
                    this.j = 1;
                    if (e().k(e3.R) != null) {
                    }
                    od.d();
                } else if (i == 1) {
                    kw0 = (kw0) this.k;
                    bmVar2 = (bm) this.l;
                    nb0.t(obj);
                    bmVar3 = bmVar2;
                    obj5 = kw0;
                    bmVar = bmVar3;
                    if (obj5.e == 0.0f) {
                    }
                    hoVar = new ho((mk0) obj3, (j50) mtVar, obj5, bmVar);
                    this.l = bmVar;
                    this.k = obj5;
                    this.j = 1;
                    if (e().k(e3.R) != null) {
                    }
                    od.d();
                } else if (i == 2) {
                    kw0 = (kw0) this.k;
                    bmVar2 = (bm) this.l;
                    nb0.t(obj);
                    bmVar3 = bmVar2;
                    obj5 = kw0;
                    bmVar = bmVar3;
                    hoVar = new ho((mk0) obj3, (j50) mtVar, obj5, bmVar);
                    this.l = bmVar;
                    this.k = obj5;
                    this.j = 1;
                    if (e().k(e3.R) != null) {
                        od.d();
                    } else {
                        if (sb0.o(e()).c(hoVar, this) == obj4) {
                            return obj4;
                        }
                        if (obj5.e == 0.0f) {
                            cz0 C = mc0.C(new x1(6, bmVar));
                            i50 u912 = new u91(2, null);
                            this.l = bmVar;
                            this.k = obj5;
                            this.j = 2;
                            if (wl1.y(C, u912, this) == obj4) {
                                return obj4;
                            }
                        }
                        hoVar = new ho((mk0) obj3, (j50) mtVar, obj5, bmVar);
                        this.l = bmVar;
                        this.k = obj5;
                        this.j = 1;
                        if (e().k(e3.R) != null) {
                        }
                    }
                    od.d();
                } else {
                    od.p(str);
                }
                obj4 = null;
                return obj4;
            default:
                mk0 mk0;
                i = this.j;
                if (i == 0) {
                    nb0.t(obj);
                    mk0 = ((lg0) this.l).d;
                    List list = (List) obj3;
                    Resources resources = (Resources) mtVar;
                    this.k = mk0;
                    this.j = 1;
                    StringBuilder stringBuilder = new StringBuilder();
                    ArrayList arrayList = new ArrayList();
                    for (Object obj32 : list) {
                        if (((t01) obj32).a) {
                            arrayList.add(obj32);
                        }
                    }
                    int size = arrayList.size();
                    while (i2 < size) {
                        a = arrayList.get(i2);
                        i2++;
                        try {
                            InputStream openRawResource = resources.openRawResource(new h90(((t01) a).b).intValue());
                            openRawResource.getClass();
                            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(openRawResource, mf.a), 8192);
                            try {
                                a = ua0.v(bufferedReader);
                                bufferedReader.close();
                                if (ak0.a(a) != null) {
                                    a = "";
                                }
                                stringBuilder.append((String) a);
                                stringBuilder.append("\n");
                            } catch (Throwable th) {
                                gh0.t(bufferedReader, th);
                            }
                        } catch (Throwable th2) {
                            a = new px0(th2);
                        }
                    }
                    a = stringBuilder.toString();
                    if (a == obj4) {
                        obj2 = obj4;
                        return obj2;
                    }
                } else if (i == 1) {
                    lq0 lq0 = (lq0) this.k;
                    nb0.t(obj);
                    mk0 = lq0;
                    a = obj;
                } else {
                    od.p(str);
                    obj2 = null;
                    return obj2;
                }
                mk0.setValue(a);
                return obj2;
        }
    }

    public final ml n(ml mlVar, Object obj) {
        int i = this.i;
        Object obj2 = this.n;
        Object obj3 = this.m;
        switch (i) {
            case 0:
                return new aj((cj) this.k, (ScrollCaptureSession) this.l, (Rect) obj3, (Consumer) obj2, mlVar, 0);
            case 1:
                aj ajVar = new aj((tw) this.l, (d81) obj3, this.n, mlVar, 1);
                ajVar.k = obj;
                return ajVar;
            case 2:
                return new aj((k51) this.k, (tw) this.l, (d81) obj3, this.n, mlVar, 2);
            case 3:
                this = new aj((mk0) obj3, (j50) obj2, mlVar);
                this.l = obj;
                return this;
            default:
                return new aj((lg0) this.l, (List) obj3, (Resources) obj2, mlVar, 4);
        }
    }

    public final Object f(Object obj, Object obj2) {
        int i = this.i;
        we1 we1 = we1.a;
        switch (i) {
            case 0:
                return ((aj) n((ml) obj2, (bm) obj)).p(we1);
            case 1:
                return ((aj) n((ml) obj2, (i51) obj)).p(we1);
            case 2:
                return ((aj) n((ml) obj2, (bm) obj)).p(we1);
            case 3:
                ((aj) n((ml) obj2, (bm) obj)).p(we1);
                return cm.e;
            default:
                return ((aj) n((ml) obj2, (bm) obj)).p(we1);
        }
    }

    public /* synthetic */ aj(Object obj, Object obj2, Object obj3, Object obj4, ml mlVar, int i) {
        this.i = i;
        this.k = obj;
        this.l = obj2;
        this.m = obj3;
        this.n = obj4;
        super(2, mlVar);
    }

    public /* synthetic */ aj(Object obj, Object obj2, Object obj3, ml mlVar, int i) {
        this.i = i;
        this.l = obj;
        this.m = obj2;
        this.n = obj3;
        super(2, mlVar);
    }

    public aj(mk0 mk0, j50 j50, ml mlVar) {
        this.i = 3;
        this.m = mk0;
        this.n = j50;
        super(2, mlVar);
    }
}