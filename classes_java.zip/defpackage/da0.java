package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: da0 */
public final class da0 implements es {
    public final te e = new te();
    public ds f;

    public final void c() {
        te teVar = this.e;
        re q = teVar.f.q();
        ds dsVar = this.f;
        if (dsVar != null) {
            int i;
            li0 li0 = (li0) dsVar;
            Object obj = li0.e.j;
            if (obj != null) {
                if ((obj.h & 4) != 0) {
                    while (r2 != null) {
                        i = r2.g;
                        if ((i & 2) != 0) {
                            break;
                        } else if ((i & 4) != 0) {
                            break;
                        } else {
                            obj = r2.j;
                        }
                    }
                }
            }
            li0 li02 = null;
            if (obj != null) {
                hb0 hb0 = null;
                while (li02 != null) {
                    if (li02 instanceof ds) {
                        ds dsVar2 = (ds) li02;
                        i20 i20 = (i20) teVar.f.g;
                        gm0 M = k70.M(dsVar2, 4);
                        long M2 = wl1.M(M.g);
                        ba0 ba0 = M.s;
                        ba0.getClass();
                        ((n4) ea0.a(ba0)).getSharedDrawScope().d(q, M2, M, dsVar2, i20);
                    } else if ((li02.g & 4) != 0 && (li02 instanceof dp)) {
                        i = 0;
                        for (li0 = ((dp) li02).t; li0 != null; li0 = li0.j) {
                            if ((li0.g & 4) != 0) {
                                i++;
                                if (i == 1) {
                                    li02 = li0;
                                } else {
                                    if (hb0 == null) {
                                        hb0 = new qk0(new li0[16]);
                                    }
                                    if (obj != null) {
                                        r11.b(obj);
                                        obj = null;
                                    }
                                    r11.b(li0);
                                }
                            }
                        }
                        if (i == 1) {
                        }
                    }
                    obj = k70.m(hb0);
                }
                return;
            }
            gm0 M3 = k70.M(dsVar, 4);
            if (M3.y0() == li0.e) {
                M3 = M3.t;
                M3.getClass();
            }
            M3.N0(q, (i20) teVar.f.g);
            return;
        }
        throw fu0.C("Attempting to drawContent for a `null` node. This usually means that a call to ContentDrawScope#drawContent() has been captured inside a lambda, and is being invoked outside of the draw pass. Capturing the scope this way is unsupported - if you are trying to record drawContent with graphicsLayer.record(), make sure you are using the GraphicsLayer#record function within DrawScope, instead of the member function on GraphicsLayer.");
    }

    public final void d(re reVar, long j, gm0 gm0, ds dsVar, i20 i20) {
        ds dsVar2 = this.f;
        this.f = dsVar;
        o90 o90 = gm0.s.D;
        te teVar = this.e;
        k9 k9Var = teVar.f;
        se seVar = ((te) k9Var.h).e;
        jp jpVar = seVar.a;
        o90 o902 = seVar.b;
        re q = k9Var.q();
        k9 k9Var2 = teVar.f;
        long t = k9Var2.t();
        i20 i202 = (i20) k9Var2.g;
        k9Var2.C(gm0);
        k9Var2.D(o90);
        k9Var2.B(reVar);
        k9Var2.E(j);
        k9Var2.g = i20;
        reVar.i();
        try {
            dsVar.C(this);
            this.f = dsVar2;
        } finally {
            reVar.g();
            k9Var2.C(jpVar);
            k9Var2.D(o902);
            k9Var2.B(q);
            k9Var2.E(t);
            k9Var2.g = i202;
        }
    }

    public final void e(r6 r6Var, long j, ac acVar) {
        te teVar = this.e;
        teVar.e.c.f(r6Var, te.c(teVar, j, acVar, 3));
    }

    public final int F(float f) {
        te teVar = this.e;
        teVar.getClass();
        return fu0.k(f, teVar);
    }

    public final long K(long j) {
        te teVar = this.e;
        teVar.getClass();
        return fu0.p(j, teVar);
    }

    public final float N(long j) {
        te teVar = this.e;
        teVar.getClass();
        return fu0.o(j, teVar);
    }

    public final float y(long j) {
        te teVar = this.e;
        teVar.getClass();
        return fu0.m(j, teVar);
    }

    public final long b() {
        return this.e.f.t();
    }

    public final float c0(float f) {
        return f / this.e.a();
    }

    public final float q(float f) {
        return this.e.a() * f;
    }

    public final long V(float f) {
        return this.e.V(f);
    }

    public final float a() {
        return this.e.a();
    }

    public final float b0(int i) {
        return this.e.b0(i);
    }

    public final float g() {
        return this.e.g();
    }

    public final o90 getLayoutDirection() {
        return this.e.e.b;
    }

    public final void D(h6 h6Var, long j, long j2, long j3, float f, pb pbVar, int i) {
        this.e.D(h6Var, j, j2, j3, f, pbVar, i);
    }

    public final void k(long j, long j2, long j3, ac acVar, int i) {
        this.e.k(j, j2, j3, acVar, i);
    }

    public final void p(r6 r6Var, zi1 zi1, float f, ac acVar, int i) {
        this.e.p(r6Var, zi1, f, acVar, i);
    }

    public final k9 u() {
        return this.e.f;
    }
}