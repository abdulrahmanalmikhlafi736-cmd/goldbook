package defpackage;

import androidx.core.content.FileProvider;
import java.util.Arrays;
import java.util.List;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ba0 */
public final class ba0 implements wi, mp0, ij {
    public static final ly0 V = new f1("Undefined intrinsics block and it is required", 1);
    public static final w90 W = new Object();
    public static final v6 X = new h90(4);
    public mh0 A;
    public al B;
    public jp C;
    public o90 D;
    public yg1 E;
    public ck F;
    public z90 G;
    public z90 H;
    public boolean I;
    public final em0 J;
    public final fa0 K;
    public pa0 L;
    public gm0 M;
    public boolean N;
    public mi0 O;
    public mi0 P;
    public k7 Q;
    public l7 R;
    public boolean S;
    public int T;
    public boolean U;
    public final boolean e;
    public int f;
    public boolean g;
    public long h;
    public boolean i;
    public boolean j;
    public boolean k;
    public ba0 l;
    public int m;
    public final al n;
    public qk0 o;
    public boolean p;
    public ba0 q;
    public lp0 r;
    public ah1 s;
    public int t;
    public boolean u;
    public boolean v;
    public d21 w;
    public boolean x;
    public final qk0 y;
    public boolean z;

    /* JADX WARNING: Removed duplicated region for block: B:100:0x018d  */
    /* JADX WARNING: Removed duplicated region for block: B:99:0x0189  */
    /* JADX WARNING: Removed duplicated region for block: B:104:0x0195  */
    /* JADX WARNING: Removed duplicated region for block: B:103:0x0194  */
    /* JADX WARNING: Removed duplicated region for block: B:108:0x01a2  */
    /* JADX WARNING: Removed duplicated region for block: B:107:0x01a1  */
    /* JADX WARNING: Removed duplicated region for block: B:111:0x01ab  */
    /* JADX WARNING: Removed duplicated region for block: B:121:0x01e5  */
    /* JADX WARNING: Removed duplicated region for block: B:99:0x0189  */
    /* JADX WARNING: Removed duplicated region for block: B:100:0x018d  */
    /* JADX WARNING: Removed duplicated region for block: B:103:0x0194  */
    /* JADX WARNING: Removed duplicated region for block: B:104:0x0195  */
    /* JADX WARNING: Removed duplicated region for block: B:107:0x01a1  */
    /* JADX WARNING: Removed duplicated region for block: B:108:0x01a2  */
    /* JADX WARNING: Removed duplicated region for block: B:111:0x01ab  */
    /* JADX WARNING: Removed duplicated region for block: B:121:0x01e5  */
    /* JADX WARNING: Removed duplicated region for block: B:100:0x018d  */
    /* JADX WARNING: Removed duplicated region for block: B:99:0x0189  */
    /* JADX WARNING: Removed duplicated region for block: B:104:0x0195  */
    /* JADX WARNING: Removed duplicated region for block: B:103:0x0194  */
    /* JADX WARNING: Removed duplicated region for block: B:108:0x01a2  */
    /* JADX WARNING: Removed duplicated region for block: B:107:0x01a1  */
    /* JADX WARNING: Removed duplicated region for block: B:111:0x01ab  */
    /* JADX WARNING: Removed duplicated region for block: B:121:0x01e5  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final mi0 b(mi0 mi0) {
        int i;
        li0 li0;
        em0 em0;
        qk0 qk0;
        Object obj;
        li0 li02;
        boolean d;
        boolean d2;
        iw0 rectManager;
        mi0 mi02 = mi0;
        em0 em02 = this.J;
        boolean d3 = em02.d(16);
        li0 li03 = em02.e;
        boolean d4 = em02.d(1024);
        this.O = mi02;
        gm0 gm0 = em02.c;
        ba0 ba0 = em02.a;
        li0 li04 = em02.f;
        li0 li05 = em02.b;
        if (li04 == li05) {
            a5.b("padChain called on already padded chain");
        }
        li04 = em02.f;
        li04.i = li05;
        li05.j = li04;
        gm0 gm02 = gm0;
        qk0 qk02 = em02.g;
        int i2 = qk02 != null ? qk02.g : 0;
        hb0 hb0 = em02.h;
        if (hb0 == null) {
            hb0 = new qk0(new ki0[16]);
        }
        qk0 qk03 = em02.i;
        qk03.b(mi02);
        i00 i00 = null;
        while (true) {
            i = qk03.g;
            if (i == 0) {
                break;
            }
            mi02 = (mi0) qk03.k(i - 1);
            if (mi02 instanceof rh) {
                rh rhVar = (rh) mi02;
                qk03.b(rhVar.b);
                qk03.b(rhVar.a);
            } else if (mi02 instanceof ki0) {
                hb0.b(mi02);
            } else {
                i00 j3Var;
                if (i00 == null) {
                    j3Var = new j3(18, hb0);
                    i00 = j3Var;
                } else {
                    j3Var = i00;
                }
                mi02.d(j3Var);
            }
        }
        i = hb0.g;
        String str = "expected prior modifier list to be non-empty";
        li0 li06;
        if (i == i2) {
            qk0 qk04;
            li06 = li05.j;
            em0 em03 = em02;
            int i3 = 0;
            while (li06 != null && i3 < i2) {
                if (qk02 != null) {
                    int i4;
                    ki0 ki0 = (ki0) qk02.e[i3];
                    ki0 ki02 = (ki0) hb0.e[i3];
                    if (k70.p(ki0, ki02)) {
                        qk04 = qk02;
                        i4 = 2;
                    } else {
                        qk04 = qk02;
                        i4 = ki0.getClass() == ki02.getClass() ? 1 : 0;
                    }
                    if (i4 == 0) {
                        li06 = li06.i;
                        break;
                    }
                    if (i4 == 1) {
                        em0.h(ki0, ki02, li06);
                    }
                    li06 = li06.j;
                    i3++;
                    qk02 = qk04;
                } else {
                    throw fu0.C(str);
                }
            }
            qk04 = qk02;
            if (i3 >= i2) {
                em02 = em03;
                qk02 = qk04;
                li0 = null;
                em0 = em02;
                li04 = li05;
                qk0 = hb0;
                obj = null;
                em0.g = qk0;
                if (qk02 == null) {
                    qk02.g();
                } else {
                    qk02 = li0;
                }
                em0.h = qk02;
                li02 = li04.j;
                if (li02 == null) {
                    li03 = li02;
                }
                li03.i = li0;
                li04.j = li0;
                li04.h = -1;
                li04.l = li0;
                if (li03 != li04) {
                    a5.b("trimChain did not update the head");
                }
                em0.f = li03;
                if (obj != null) {
                    em0.g();
                }
                d = em0.d(16);
                d2 = em0.d(1024);
                this.K.j();
                if (this.l == null && em0.d(512)) {
                    b0(this);
                }
                if (!(d3 == d && d4 == d2)) {
                    rectManager = ((n4) ea0.a(this)).getRectManager();
                    rectManager.getClass();
                    if (H()) {
                        i6 i6Var = rectManager.a;
                        int i5 = this.f & 33554431;
                        long[] jArr = (long[]) i6Var.c;
                        i = i6Var.b;
                        int i6 = 0;
                        while (i6 < jArr.length - 2 && i6 < i) {
                            i2 = i6 + 2;
                            long j = jArr[i2];
                            if ((((int) j) & 33554431) == i5) {
                                jArr[i2] = ((-6917529027641081857L & j) | (((long) d2) * 2305843009213693952L)) | (((long) d) * 4611686018427387904L);
                                return;
                            }
                            i6 += 3;
                        }
                    }
                }
                return;
            } else if (qk04 == null) {
                throw fu0.C(str);
            } else if (li06 != null) {
                int i7 = ba0.P != null ? 1 : 0;
                em0 em04 = em03;
                li04 = li06;
                em0 = em04;
                qk0 = hb0;
                qk02 = qk04;
                li0 = null;
                em0.f(i3, qk02, qk0, li04, i7 ^ 1);
                li04 = li05;
            } else {
                throw fu0.C("structuralUpdate requires a non-null tail");
            }
        }
        li0 = null;
        mi0 mi03 = ba0.P;
        if (mi03 != null && i2 == 0) {
            li0 li07 = li05;
            for (i = 0; i < hb0.g; i++) {
                li07 = em0.b((ki0) hb0.e[i], li07);
            }
            li06 = li03.i;
            int i8 = 0;
            while (li06 != null && li06 != li05) {
                i8 |= li06.g;
                li06.h = i8;
                li06 = li06.i;
            }
            em0 = em02;
            li04 = li05;
            Object obj2 = hb0;
        } else if (i != 0) {
            if (qk02 == null) {
                qk02 = new qk0(new ki0[16]);
            }
            em0 = em02;
            li04 = li05;
            qk0 = hb0;
            em0.f(0, qk02, qk0, li04, (mi03 != null ? 1 : 0) ^ 1);
            obj = 1;
            em0.g = qk0;
            if (qk02 == null) {
            }
            em0.h = qk02;
            li02 = li04.j;
            if (li02 == null) {
            }
            li03.i = li0;
            li04.j = li0;
            li04.h = -1;
            li04.l = li0;
            if (li03 != li04) {
            }
            em0.f = li03;
            if (obj != null) {
            }
            d = em0.d(16);
            d2 = em0.d(1024);
            this.K.j();
            b0(this);
            rectManager = ((n4) ea0.a(this)).getRectManager();
            rectManager.getClass();
            if (H()) {
            }
            return;
        } else if (qk02 != null) {
            li06 = li05.j;
            i2 = 0;
            while (li06 != null && i2 < qk02.g) {
                li06 = em0.c(li06).j;
                i2++;
            }
            ba0 v = ba0.v();
            gm02.u = v != null ? v.J.c : null;
            em02.d = gm02;
            em0 = em02;
            li04 = li05;
            qk0 = hb0;
            obj = null;
            em0.g = qk0;
            if (qk02 == null) {
            }
            em0.h = qk02;
            li02 = li04.j;
            if (li02 == null) {
            }
            li03.i = li0;
            li04.j = li0;
            li04.h = -1;
            li04.l = li0;
            if (li03 != li04) {
            }
            em0.f = li03;
            if (obj != null) {
            }
            d = em0.d(16);
            d2 = em0.d(1024);
            this.K.j();
            b0(this);
            rectManager = ((n4) ea0.a(this)).getRectManager();
            rectManager.getClass();
            if (H()) {
            }
            return;
        } else {
            throw fu0.C(str);
        }
        obj = 1;
        em0.g = qk0;
        if (qk02 == null) {
        }
        em0.h = qk02;
        li02 = li04.j;
        if (li02 == null) {
        }
        li03.i = li0;
        li04.j = li0;
        li04.h = -1;
        li04.l = li0;
        if (li03 != li04) {
        }
        em0.f = li03;
        if (obj != null) {
        }
        d = em0.d(16);
        d2 = em0.d(1024);
        this.K.j();
        b0(this);
        rectManager = ((n4) ea0.a(this)).getRectManager();
        rectManager.getClass();
        if (H()) {
        }
        return;
    }

    /* JADX WARNING: Missing block: B:37:0x00c5, code:
            if (r2 == null) goto L_0x00c7;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void d(lp0 lp0) {
        StringBuilder dl1;
        int i = 0;
        if (this.r != null) {
            dl1 = new dl1("Cannot attach ");
            dl1.append(this);
            dl1.append(" as it already is attached.  Tree: ");
            dl1.append(g(0));
            a5.b(dl1.toString());
        }
        ba0 ba0 = this.q;
        if (ba0 != null) {
            if (!k70.p(ba0.r, lp0)) {
                dl1 = new dl1("Attaching to a different owner(");
                dl1.append(lp0);
                dl1.append(") than the parent's owner(");
                ba0 v = v();
                dl1.append(v != null ? v.r : null);
                dl1.append("). This tree: ");
                dl1.append(g(0));
                dl1.append(" Parent tree: ");
                v = this.q;
                dl1.append(v != null ? v.g(0) : null);
                a5.b(dl1.toString());
            }
        }
        ba0 = v();
        fa0 fa0 = this.K;
        if (ba0 == null) {
            fa0.p.v = true;
            ((n4) lp0).getRectManager().f(this);
            hg0 hg0 = fa0.q;
            if (hg0 != null) {
                hg0.t = fg0.e;
            }
        }
        em0 em0 = this.J;
        em0.d.u = ba0 != null ? ba0.J.c : null;
        this.r = lp0;
        this.t = (ba0 != null ? ba0.t : -1) + 1;
        mi0 mi0 = this.P;
        if (mi0 != null) {
            b(mi0);
        }
        this.P = null;
        ((n4) lp0).getLayoutNodes().h(this.f, this);
        ba0 ba02 = this.q;
        if (ba02 != null) {
            ba02 = ba02.l;
        }
        ba02 = this.l;
        b0(ba02);
        if (this.l == null && em0.d(512)) {
            b0(this);
        }
        if (!this.U) {
            for (li0 li0 = em0.f; li0 != null; li0 = li0.j) {
                li0.f0();
            }
        }
        qk0 qk0 = (qk0) this.n.f;
        Object[] objArr = qk0.e;
        int i2 = qk0.g;
        while (i < i2) {
            ((ba0) objArr[i]).d(lp0);
            i++;
        }
        if (!this.U) {
            em0.e();
        }
        E();
        if (ba0 != null) {
            ba0.E();
        }
        k7 k7Var = this.Q;
        if (k7Var != null) {
            k7Var.i(lp0);
        }
        fa0.j();
        if (!this.U && em0.d(8)) {
            F();
        }
        n4 n4Var = (n4) lp0;
        if (n4.l()) {
            r3 r3Var = n4Var.S;
            if (r3Var != null) {
                d21 x = x();
                if (x != null && x.e.b(n21.r) == 1) {
                    r3Var.k.a(this.f);
                    r3Var.e.x(r3Var.g, this.f, true);
                }
            }
        }
    }

    public final void h() {
        lp0 lp0 = this.r;
        String str = null;
        if (lp0 == null) {
            StringBuilder dl1 = new dl1("Cannot detach node that is already detached!  Tree: ");
            this = v();
            if (this != null) {
                str = this.g(0);
            }
            dl1.append(str);
            p50.c(dl1.toString());
            throw new RuntimeException();
        }
        hg0 hg0;
        ba0 v = v();
        fa0 fa0 = this.K;
        if (v != null) {
            v.C();
            v.E();
            lh0 lh0 = fa0.p;
            z90 z90 = z90.g;
            lh0.p = z90;
            hg0 = fa0.q;
            if (hg0 != null) {
                hg0.n = z90;
            }
        }
        ca0 ca0 = fa0.p.A;
        ca0.b = true;
        ca0.c = false;
        ca0.d = false;
        ca0.e = false;
        ca0.f = null;
        hg0 = fa0.q;
        if (hg0 != null) {
            ca0 = hg0.u;
            if (ca0 != null) {
                ca0.b = true;
                ca0.c = false;
                ca0.d = false;
                ca0.e = false;
                ca0.f = null;
            }
        }
        em0 em0 = this.J;
        Object obj = em0.d;
        li0 li0 = em0.e;
        gm0 gm0 = em0.c.t;
        while (!k70.p(obj, gm0) && obj != null) {
            obj.Q0();
            if (obj.s.I()) {
                obj.L0();
            }
            obj = obj.t;
        }
        l7 l7Var = this.R;
        if (l7Var != null) {
            l7Var.i(lp0);
        }
        for (li0 li02 = li0; li02 != null; li02 = li02.i) {
            if (li02.r) {
                li02.o0();
            }
        }
        this.u = true;
        qk0 qk0 = (qk0) this.n.f;
        Object[] objArr = qk0.e;
        int i = qk0.g;
        for (int i2 = 0; i2 < i; i2++) {
            ((ba0) objArr[i2]).h();
        }
        this.u = false;
        while (li0 != null) {
            if (li0.r) {
                li0.g0();
            }
            li0 = li0.i;
        }
        n4 n4Var = (n4) lp0;
        n4Var.getLayoutNodes().g(this.f);
        jh0 jh0 = n4Var.e0;
        k9 k9Var = jh0.b;
        ((pg0) k9Var.f).B(this);
        ((pg0) k9Var.g).B(this);
        ((pg0) k9Var.h).B(this);
        ((qk0) jh0.e.f).j(this);
        n4Var.T = true;
        if (n4.l()) {
            r3 r3Var = n4Var.S;
            if (r3Var != null && r3Var.k.e(this.f)) {
                r3Var.e.x(r3Var.g, this.f, false);
            }
        }
        n4Var.getRectManager().g(this);
        this.r = null;
        b0(null);
        this.t = 0;
        lh0 lh02 = fa0.p;
        lh02.m = Integer.MAX_VALUE;
        lh02.l = Integer.MAX_VALUE;
        lh02.v = false;
        hg0 hg02 = fa0.q;
        if (hg02 != null) {
            hg02.m = Integer.MAX_VALUE;
            hg02.l = Integer.MAX_VALUE;
            hg02.t = fg0.g;
        }
        if (em0.d(8)) {
            d21 d21 = this.w;
            this.w = null;
            this.v = false;
            n4Var.getSemanticsOwner().b(this, d21);
            n4Var.E();
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:21:0x003a  */
    /* JADX WARNING: Removed duplicated region for block: B:18:0x0032  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void N(gm0 gm0) {
        int i;
        lp0 lp0 = this.r;
        iw0 rectManager = lp0 != null ? ((n4) lp0).getRectManager() : null;
        fa0 fa0 = this.K;
        int i2 = 0;
        if (fa0.d == x90.i && !q()) {
            if (!p()) {
                i = 0;
                if (this.k && rectManager != null) {
                    if (gm0 != this.J.d) {
                        this.j = true;
                        if (i == 0) {
                            rectManager.f(this);
                        }
                    } else {
                        this.i = true;
                        qk0 z = z();
                        Object[] objArr = z.e;
                        int i3 = z.g;
                        for (int i4 = 0; i4 < i3; i4++) {
                            ba0 ba0 = (ba0) objArr[i4];
                            ba0.j = true;
                            if (i == 0) {
                                rectManager.f(ba0);
                            }
                        }
                        if (this.k) {
                            rectManager.d = true;
                            i6 i6Var = rectManager.a;
                            int i5 = this.f & 33554431;
                            long[] jArr = (long[]) i6Var.c;
                            i3 = i6Var.b;
                            while (i2 < jArr.length - 2 && i2 < i3) {
                                int i6 = i2 + 2;
                                long j = jArr[i6];
                                if ((((int) j) & 33554431) == i5) {
                                    jArr[i6] = (((j >> 63) & 1) << 60) | j;
                                    break;
                                }
                                i2 += 3;
                            }
                        }
                        rectManager.i();
                    }
                }
                fa0.p.e0();
            }
        }
        i = true;
        if (gm0 != this.J.d) {
        }
        fa0.p.e0();
    }

    public static void T(ba0 ba0, boolean z, int i) {
        boolean z2 = false;
        if ((i & 1) != 0) {
            z = false;
        }
        boolean z3 = (i & 2) != 0;
        if ((i & 4) != 0) {
            z2 = true;
        }
        if (ba0.l == null) {
            a5.b("Lookahead measure cannot be requested on a node that is not a part of the LookaheadScope");
        }
        lp0 lp0 = ba0.r;
        if (lp0 != null) {
            if (!(ba0.u || ba0.e)) {
                ((n4) lp0).C(ba0, true, z, z3);
                if (z2) {
                    hg0 hg0 = ba0.K.q;
                    hg0.getClass();
                    fa0 fa0 = hg0.j;
                    ba0 v = fa0.a.v();
                    z90 z90 = fa0.a.G;
                    if (!(v == null || z90 == z90.g)) {
                        while (v.G == z90) {
                            ba0 v2 = v.v();
                            if (v2 == null) {
                                break;
                            }
                            v = v2;
                        }
                        int ordinal = z90.ordinal();
                        if (ordinal != 0) {
                            if (ordinal != 1) {
                                od.p("Intrinsics isn't used by the parent");
                            } else if (v.l != null) {
                                v.S(z);
                            } else {
                                v.U(z);
                            }
                        } else if (v.l != null) {
                            ba0.T(v, z, 6);
                        } else {
                            ba0.V(v, z, 6);
                        }
                    }
                }
            }
        }
    }

    public final void e0(yg1 yg1) {
        if (!k70.p(this.E, yg1)) {
            this.E = yg1;
            li0 li0 = this.J.f;
            if ((li0.h & 16) != 0) {
                while (li0 != null) {
                    if ((li0.g & 16) != 0) {
                        Object obj = li0;
                        hb0 hb0 = null;
                        li0 li02;
                        while (li02 != null) {
                            if (li02 instanceof gt0) {
                                ((gt0) li02).L();
                            } else if ((li02.g & 16) != 0 && (li02 instanceof dp)) {
                                int i = 0;
                                for (li0 li03 = ((dp) li02).t; li03 != null; li03 = li03.j) {
                                    if ((li03.g & 16) != 0) {
                                        i++;
                                        if (i == 1) {
                                            li02 = li03;
                                        } else {
                                            if (hb0 == null) {
                                                hb0 = new qk0(new li0[16]);
                                            }
                                            if (obj != null) {
                                                r2.b(obj);
                                                obj = null;
                                            }
                                            r2.b(li03);
                                        }
                                    }
                                }
                                if (i == 1) {
                                }
                            }
                            obj = k70.m(hb0);
                        }
                    }
                    if ((li0.h & 16) != 0) {
                        li0 = li0.j;
                    } else {
                        return;
                    }
                }
            }
        }
    }

    public final void c() {
        li0 li0;
        ah1 ah1 = this.s;
        if (ah1 != null) {
            ah1.c();
        }
        pa0 pa0 = this.L;
        if (pa0 != null) {
            pa0.i(true);
        }
        this.U = true;
        li0 li02 = this.J.e;
        for (li0 = li02; li0 != null; li0 = li0.i) {
            if (li0.r) {
                li0.m0();
            }
        }
        for (li0 = li02; li0 != null; li0 = li0.i) {
            if (li0.r) {
                li0.o0();
            }
        }
        while (li02 != null) {
            if (li02.r) {
                li02.g0();
            }
            li02 = li02.i;
        }
        if (H()) {
            this.w = null;
            this.v = false;
        }
        lp0 lp0 = this.r;
        if (lp0 != null) {
            n4 n4Var = (n4) lp0;
            if (n4.l()) {
                r3 r3Var = n4Var.S;
                if (r3Var != null && r3Var.k.e(this.f)) {
                    r3Var.e.x(r3Var.g, this.f, false);
                }
            }
        }
    }

    public ba0(int i, boolean z) {
        this.e = z;
        this.f = i;
        this.h = 9223372034707292159L;
        this.i = true;
        this.j = true;
        this.n = new al(12, new qk0(new ba0[16]), new f8(5, this));
        this.y = new qk0(new ba0[16]);
        this.z = true;
        this.A = V;
        this.C = ea0.a;
        this.D = o90.e;
        this.E = W;
        ck.d.getClass();
        this.F = bk.b;
        z90 z90 = z90.g;
        this.G = z90;
        this.H = z90;
        this.J = new em0(this);
        this.K = new fa0(this);
        this.N = true;
        this.O = ji0.a;
    }

    public static void V(ba0 ba0, boolean z, int i) {
        if ((i & 1) != 0) {
            z = false;
        }
        boolean z2 = (i & 2) != 0;
        boolean z3 = (i & 4) != 0;
        if (!(ba0.u || ba0.e)) {
            lp0 lp0 = ba0.r;
            if (lp0 != null) {
                ((n4) lp0).C(ba0, false, z, z2);
                if (z3) {
                    fa0 fa0 = ba0.K.p.j;
                    ba0 v = fa0.a.v();
                    z90 z90 = fa0.a.G;
                    if (!(v == null || z90 == z90.g)) {
                        while (v.G == z90) {
                            ba0 v2 = v.v();
                            if (v2 == null) {
                                break;
                            }
                            v = v2;
                        }
                        int ordinal = z90.ordinal();
                        if (ordinal == 0) {
                            ba0.V(v, z, 6);
                        } else if (ordinal == 1) {
                            v.U(z);
                        } else {
                            od.p("Intrinsics isn't used by the parent");
                        }
                    }
                }
            }
        }
    }

    public final List l() {
        hg0 hg0 = this.K.q;
        hg0.getClass();
        qk0 qk0 = hg0.v;
        fa0 fa0 = hg0.j;
        fa0.a.n();
        if (!hg0.w) {
            return qk0.f();
        }
        ba0 ba0 = fa0.a;
        qk0 z = ba0.z();
        Object[] objArr = z.e;
        int i = z.g;
        for (int i2 = 0; i2 < i; i2++) {
            ba0 ba02 = (ba0) objArr[i2];
            hg0 hg02;
            if (qk0.g <= i2) {
                hg02 = ba02.K.q;
                hg02.getClass();
                qk0.b(hg02);
            } else {
                hg02 = ba02.K.q;
                hg02.getClass();
                Object[] objArr2 = qk0.e;
                Object obj = objArr2[i2];
                objArr2[i2] = hg02;
            }
        }
        qk0.l(((nk0) ba0.n()).e.g, qk0.g);
        hg0.w = false;
        return qk0.f();
    }

    public final void F() {
        if (!this.x) {
            if (this.J.b.j == null) {
                if (this.P == null) {
                    d21 d21 = this.w;
                    this.x = true;
                    nw0 obj = new Object();
                    obj.e = new d21();
                    op0 snapshotObserver = ((n4) ea0.a(this)).getSnapshotObserver();
                    g4 alVar = new al(7, this, obj);
                    snapshotObserver.a.b(this, snapshotObserver.d, alVar);
                    this.x = false;
                    this.w = (d21) obj.e;
                    this.v = false;
                    n4 n4Var = (n4) ea0.a(this);
                    n4Var.getSemanticsOwner().b(this, d21);
                    n4Var.E();
                    return;
                }
            }
            this.v = true;
        }
    }

    public final void M(ba0 ba0) {
        if (ba0.K.l > 0) {
            fa0 fa0 = this.K;
            fa0.d(fa0.l - 1);
        }
        if (this.r != null) {
            ba0.h();
        }
        ba0.q = null;
        if (ba0.T > 0) {
            a0(this.T - 1);
        }
        ba0.J.d.u = null;
        if (ba0.e) {
            this.m--;
            qk0 qk0 = (qk0) ba0.n.f;
            Object[] objArr = qk0.e;
            int i = qk0.g;
            for (int i2 = 0; i2 < i; i2++) {
                ((ba0) objArr[i2]).J.d.u = null;
            }
        }
        G();
        O();
    }

    public final void B(int i, ba0 ba0) {
        if (ba0.q != null) {
            if (ba0.r != null) {
                a5.b(j(ba0));
            }
        }
        ba0.q = this;
        al alVar = this.n;
        ((qk0) alVar.f).a(i, ba0);
        ((f8) alVar.g).a();
        O();
        if (ba0.e) {
            this.m++;
        }
        G();
        lp0 lp0 = this.r;
        if (lp0 != null) {
            ba0.d(lp0);
        }
        if (ba0.K.l > 0) {
            fa0 fa0 = this.K;
            fa0.d(fa0.l + 1);
        }
        if (ba0.T > 0) {
            a0(this.T + 1);
        }
    }

    public final void C() {
        gm0 gm0;
        if (this.N) {
            em0 em0 = this.J;
            Object obj = em0.c;
            gm0 = em0.d.u;
            this.M = null;
            while (!k70.p(obj, gm0)) {
                if ((obj != null ? obj.P : null) != null) {
                    this.M = obj;
                    break;
                }
                obj = obj != null ? obj.u : null;
            }
            this.N = false;
        }
        gm0 = this.M;
        if (gm0 != null) {
            if (gm0.P == null) {
                throw fu0.C("layer was not set");
            }
        }
        if (gm0 != null) {
            gm0.F0();
            return;
        }
        ba0 v = v();
        if (v != null) {
            v.C();
            return;
        }
        lp0 lp0 = this.r;
        if (lp0 != null) {
            ((n4) lp0).invalidate();
        }
    }

    public final void f0() {
        if (this.m > 0 && this.p) {
            int i = 0;
            this.p = false;
            qk0 qk0 = this.o;
            if (qk0 == null) {
                qk0 = new qk0(new ba0[16]);
                this.o = qk0;
            }
            qk0.g();
            qk0 qk02 = (qk0) this.n.f;
            Object[] objArr = qk02.e;
            int i2 = qk02.g;
            while (i < i2) {
                ba0 ba0 = (ba0) objArr[i];
                if (ba0.e) {
                    qk0.c(qk0.g, ba0.z());
                } else {
                    qk0.b(ba0);
                }
                i++;
            }
            fa0 fa0 = this.K;
            fa0.p.C = true;
            hg0 hg0 = fa0.q;
            if (hg0 != null) {
                hg0.w = true;
            }
        }
    }

    public final String g(int i) {
        StringBuilder stringBuilder = new StringBuilder();
        for (int i2 = 0; i2 < i; i2++) {
            stringBuilder.append("  ");
        }
        stringBuilder.append("|-");
        stringBuilder.append(toString());
        stringBuilder.append(10);
        qk0 z = z();
        Object[] objArr = z.e;
        int i3 = z.g;
        for (int i4 = 0; i4 < i3; i4++) {
            stringBuilder.append(((ba0) objArr[i4]).g(i + 1));
        }
        String stringBuilder2 = stringBuilder.toString();
        return i == 0 ? stringBuilder2.substring(0, stringBuilder2.length() - 1) : stringBuilder2;
    }

    public final void K() {
        if (this.G == z90.g) {
            f();
        }
        hg0 hg0 = this.K.q;
        hg0.getClass();
        boolean z = true;
        try {
            hg0.k = true;
            if (!hg0.o) {
                a5.b("replace() called on item that was not placed");
            }
            hg0.E = false;
            if (hg0.t == fg0.g) {
                z = false;
            }
            hg0.d0(hg0.r, hg0.s);
            if (z && !hg0.E) {
                ba0 v = hg0.j.a.v();
                if (v != null) {
                    v.S(false);
                }
            }
            hg0.k = false;
        } catch (Throwable th) {
            hg0.k = false;
        }
    }

    public final void R() {
        if (this.G == z90.g) {
            f();
        }
        lh0 lh0 = this.K.p;
        fa0 fa0 = lh0.j;
        try {
            lh0.k = true;
            if (!lh0.o) {
                a5.b("replace called on unplaced item");
            }
            boolean z = lh0.v;
            lh0.a0(lh0.q, lh0.s, lh0.r);
            if (z && !lh0.I) {
                ba0 v = fa0.a.v();
                if (v != null) {
                    v.U(false);
                }
            }
            lh0.k = false;
        } catch (Throwable th) {
            lh0.k = false;
        }
    }

    public final void Q(int i, int i2) {
        if (i2 < 0) {
            StringBuilder dl1 = new dl1("count (");
            dl1.append(i2);
            dl1.append(") must be greater than 0");
            FileProvider.a(dl1.toString());
        }
        i2 = (i2 + i) - 1;
        if (i <= i2) {
            while (true) {
                al alVar = this.n;
                M((ba0) ((qk0) alVar.f).e[i2]);
                Object k = ((qk0) alVar.f).k(i2);
                ((f8) alVar.g).a();
                ba0 ba0 = (ba0) k;
                if (i2 != i) {
                    i2--;
                } else {
                    return;
                }
            }
        }
    }

    public final void L(int i, int i2, int i3) {
        if (i != i2) {
            int i4 = 0;
            while (i4 < i3) {
                int i5 = i > i2 ? i + i4 : i;
                int i6 = i > i2 ? i2 + i4 : (i2 + i3) - 2;
                al alVar = this.n;
                f8 f8Var = (f8) alVar.g;
                Object k = ((qk0) alVar.f).k(i5);
                f8Var.a();
                ((qk0) alVar.f).a(i6, (ba0) k);
                f8Var.a();
                i4++;
            }
            O();
            G();
            E();
        }
    }

    public static void W(ba0 ba0) {
        int i = aa0.a[ba0.K.d.ordinal()];
        fa0 fa0 = ba0.K;
        if (i != 1) {
            od.o(fa0.d, "Unexpected state ");
        } else if (fa0.e) {
            ba0.T(ba0, true, 6);
        } else {
            if (fa0.f) {
                ba0.S(true);
            }
            if (ba0.q()) {
                ba0.V(ba0, true, 6);
                return;
            }
            if (ba0.p()) {
                ba0.U(true);
            }
        }
    }

    public final void b0(ba0 ba0) {
        if (!k70.p(ba0, this.l)) {
            this.l = ba0;
            fa0 fa0 = this.K;
            if (ba0 != null) {
                if (fa0.q == null) {
                    fa0.q = new hg0(fa0);
                }
                em0 em0 = this.J;
                Object obj = em0.d;
                gm0 gm0 = em0.c.t;
                while (!k70.p(obj, gm0) && obj != null) {
                    obj.t0();
                    obj = obj.t;
                }
            } else {
                fa0.q = null;
                fa0.f = false;
                fa0.e = false;
            }
            E();
        }
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(a61.S(this));
        stringBuilder.append(" children: ");
        stringBuilder.append(((nk0) n()).e.g);
        stringBuilder.append(" measurePolicy: ");
        stringBuilder.append(this.A);
        stringBuilder.append(" deactivated: ");
        stringBuilder.append(this.U);
        return stringBuilder.toString();
    }

    public final void k() {
        if (this.l != null) {
            ba0.T(this, false, 5);
        } else {
            ba0.V(this, false, 5);
        }
        lh0 lh0 = this.K.p;
        sk adVar = lh0.n ? new ad(lh0.h) : null;
        lp0 lp0 = this.r;
        if (adVar != null) {
            if (lp0 != null) {
                ((n4) lp0).y(this, adVar.a);
            }
        } else if (lp0 != null) {
            ((n4) lp0).x(true);
        }
    }

    public final void Z(jp jpVar) {
        if (!k70.p(this.C, jpVar)) {
            this.C = jpVar;
            E();
            ba0 v = v();
            if (v != null) {
                v.C();
            } else {
                lp0 lp0 = this.r;
                if (lp0 != null) {
                    ((n4) lp0).invalidate();
                }
            }
            D();
            for (li0 li0 = this.J.f; li0 != null; li0 = li0.j) {
                li0.i0();
            }
        }
    }

    private final String j(ba0 ba0) {
        StringBuilder dl1 = new dl1("Cannot insert ");
        dl1.append(ba0);
        dl1.append(" because it already has a parent or an owner. This tree: ");
        dl1.append(g(0));
        dl1.append(" Other tree: ");
        this = ba0.q;
        dl1.append(this != null ? this.g(0) : null);
        return dl1.toString();
    }

    public final void d0(mi0 mi0) {
        if (this.e) {
            if (this.O != ji0.a) {
                FileProvider.a("Modifiers are not supported on virtual LayoutNodes");
            }
        }
        if (this.U) {
            FileProvider.a("modifier is updated when deactivated");
        }
        if (H()) {
            b(mi0);
            if (this.v) {
                F();
            }
            return;
        }
        this.P = mi0;
    }

    public final void a0(int i) {
        int i2 = this.T;
        if (i2 != i) {
            ba0 v;
            if (i > 0 && i2 == 0) {
                v = v();
                if (v != null) {
                    v.a0(v.T + 1);
                }
            }
            if (i == 0 && this.T > 0) {
                v = v();
                if (v != null) {
                    v.a0(v.T - 1);
                }
            }
            this.T = i;
        }
    }

    public final void P() {
        al alVar = this.n;
        int i = ((qk0) alVar.f).g - 1;
        while (true) {
            qk0 qk0 = (qk0) alVar.f;
            if (-1 < i) {
                M((ba0) qk0.e[i]);
                i--;
            } else {
                qk0.g();
                ((f8) alVar.g).a();
                return;
            }
        }
    }

    public final void D() {
        em0 em0 = this.J;
        v50 v50 = em0.d;
        v50 v502 = em0.c;
        while (v50 != v502) {
            v50.getClass();
            v90 v90 = (v90) v50;
            kp0 kp0 = v90.P;
            if (kp0 != null) {
                ((l20) kp0).c();
            }
            v50 = v90.t;
        }
        kp0 kp02 = em0.c.P;
        if (kp02 != null) {
            ((l20) kp02).c();
        }
    }

    public final void a() {
        ah1 ah1 = this.s;
        if (ah1 != null) {
            ah1.a();
        }
        pa0 pa0 = this.L;
        if (pa0 != null) {
            pa0.a();
        }
        em0 em0 = this.J;
        Object obj = em0.d;
        gm0 gm0 = em0.c.t;
        while (!k70.p(obj, gm0) && obj != null) {
            obj.K0();
            obj = obj.t;
        }
    }

    public final void f() {
        this.H = this.G;
        this.G = z90.g;
        qk0 z = z();
        Object[] objArr = z.e;
        int i = z.g;
        for (int i2 = 0; i2 < i; i2++) {
            ba0 ba0 = (ba0) objArr[i2];
            if (ba0.G == z90.f) {
                ba0.f();
            }
        }
    }

    public final void e() {
        this.H = this.G;
        z90 z90 = z90.g;
        this.G = z90;
        qk0 z = z();
        Object[] objArr = z.e;
        int i = z.g;
        for (int i2 = 0; i2 < i; i2++) {
            ba0 ba0 = (ba0) objArr[i2];
            if (ba0.G != z90) {
                ba0.e();
            }
        }
    }

    public final qk0 y() {
        boolean z = this.z;
        qk0 qk0 = this.y;
        if (z) {
            qk0.g();
            qk0.c(qk0.g, z());
            Arrays.sort(qk0.e, 0, qk0.g, X);
            this.z = false;
        }
        return qk0;
    }

    public final void X() {
        qk0 z = z();
        Object[] objArr = z.e;
        int i = z.g;
        for (int i2 = 0; i2 < i; i2++) {
            ba0 ba0 = (ba0) objArr[i2];
            z90 z90 = ba0.H;
            ba0.G = z90;
            if (z90 != z90.g) {
                ba0.X();
            }
        }
    }

    public final void E() {
        if (this.e) {
            this = v();
            if (this != null) {
                this.E();
            }
        } else if (this.l != null) {
            ba0.T(this, false, 7);
        } else {
            ba0.V(this, false, 7);
        }
    }

    public final void Y(Throwable th) {
        ck ckVar = this.F;
        k81 k81 = xj.a;
        qr0 qr0 = (qr0) ckVar;
        qr0.getClass();
        wj wjVar = (wj) gh0.L(qr0, k81);
        if (wjVar != null) {
            a5.P(th, new al(2, wjVar, this));
        }
        throw th;
    }

    public final d21 x() {
        if (H() && !this.U) {
            if (this.J.d(8)) {
                return this.w;
            }
        }
        return null;
    }

    public final void c0(mh0 mh0) {
        if (!k70.p(this.A, mh0)) {
            this.A = mh0;
            al alVar = this.B;
            if (alVar != null) {
                ((lq0) alVar.g).setValue(mh0);
            }
            E();
        }
    }

    public final Boolean J() {
        hg0 hg0 = this.K.q;
        if (hg0 == null) {
            return null;
        }
        return Boolean.valueOf(hg0.t != fg0.g);
    }

    public final void A(long j, e30 e30, int i, boolean z) {
        em0 em0 = this.J;
        gm0 gm0 = em0.d;
        sx0 sx0 = gm0.Q;
        em0.d.D0(gm0.S, gm0.v0(j), e30, i, z);
    }

    public final qk0 z() {
        f0();
        if (this.m == 0) {
            return (qk0) this.n.f;
        }
        qk0 qk0 = this.o;
        qk0.getClass();
        return qk0;
    }

    public final void G() {
        if (this.m > 0) {
            this.p = true;
        }
        if (this.e) {
            this = this.q;
            if (this != null) {
                this.G();
            }
        }
    }

    public final void O() {
        if (this.e) {
            this = v();
            if (this != null) {
                this.O();
            }
            return;
        }
        this.z = true;
    }

    public final void S(boolean z) {
        if (!this.e) {
            lp0 lp0 = this.r;
            if (lp0 != null) {
                ((n4) lp0).D(this, true, z);
            }
        }
    }

    public final void U(boolean z) {
        if (!this.e) {
            lp0 lp0 = this.r;
            if (lp0 != null) {
                ((n4) lp0).D(this, false, z);
            }
        }
    }

    public final z90 t() {
        hg0 hg0 = this.K.q;
        if (hg0 != null) {
            z90 z90 = hg0.n;
            if (z90 != null) {
                return z90;
            }
        }
        return z90.g;
    }

    public final void i(re reVar, i20 i20) {
        try {
            this.J.d.r0(reVar, i20);
        } catch (Throwable th) {
            Y(th);
        }
    }

    public final al u() {
        al alVar = this.B;
        if (alVar != null) {
            return alVar;
        }
        alVar = new al(this, this.A);
        this.B = alVar;
        return alVar;
    }

    public final ba0 v() {
        this = this.q;
        while (this != null && this.e) {
            this = this.q;
        }
        return this;
    }

    public final List o() {
        return ((qk0) this.n.f).f();
    }

    public final List m() {
        return this.K.p.U();
    }

    public final List n() {
        return z().f();
    }

    public final boolean H() {
        return this.r != null;
    }

    public final boolean I() {
        return this.K.p.v;
    }

    public final boolean p() {
        return this.K.p.y;
    }

    public final boolean q() {
        return this.K.p.x;
    }

    public final z90 s() {
        return this.K.p.p;
    }

    public final int w() {
        return this.K.p.m;
    }

    public final boolean r() {
        return H();
    }

    public ba0(int i) {
        this(f21.a.addAndGet(1), (i & 1) == 0);
    }
}