package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ks0 */
public abstract class ks0 {
    public int e;
    public int f;
    public long g = 0;
    public long h = ls0.a;
    public long i = 0;

    public final void Q() {
        this.e = sb0.h((int) (this.g >> 32), sk.j(this.h), sk.h(this.h));
        int h = sb0.h((int) (this.g & 4294967295L), sk.i(this.h), sk.g(this.h));
        this.f = h;
        int i = this.e;
        long j = this.g;
        this.i = (((long) ((i - ((int) (j >> 32))) / 2)) << 32) | (4294967295L & ((long) ((h - ((int) (j & 4294967295L))) / 2)));
    }

    public final void S(long j) {
        if (!d90.a(this.g, j)) {
            this.g = j;
            Q();
        }
    }

    public final void T(long j) {
        if (n60.b(this.h, j) == null) {
            this.h = j;
            Q();
        }
    }

    public int M() {
        return (int) (this.g & 4294967295L);
    }

    public int P() {
        return (int) (this.g >> 32);
    }

    public Object i() {
        return null;
    }

    public abstract void R(long j, float f, i00 i00);
}