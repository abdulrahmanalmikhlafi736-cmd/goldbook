package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: as */
final class as extends qi0 {
    public final n7 a;

    /* JADX WARNING: Missing block: B:6:0x000e, code:
            if (r1.a != ((defpackage.as) r2).a) goto L_0x0010;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean equals(Object obj) {
        if (this != obj) {
            if (obj instanceof as) {
            }
            return false;
        }
        return true;
    }

    public final li0 e() {
        zr li0 = new li0();
        li0.s = this.a;
        return li0;
    }

    public final void f(li0 li0) {
        ((zr) li0).s = this.a;
    }

    public final int hashCode() {
        return this.a.hashCode();
    }

    public as(n7 n7Var) {
        this.a = n7Var;
    }
}