package defpackage;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: b10 */
public final class b10 extends sj {
    public final long a;
    public final boolean b;
    public final boolean c;
    public HashSet d;
    public final ik0 e = new ik0();
    public final lq0 f = new lq0(qr0.h, nq0.h);
    public final /* synthetic */ d10 g;

    public final void w() {
        ik0 ik0 = this.e;
        if (ik0.h()) {
            HashSet hashSet = this.d;
            if (hashSet != null) {
                Object[] objArr = ik0.b;
                long[] jArr = ik0.a;
                int length = jArr.length - 2;
                if (length >= 0) {
                    int i = 0;
                    while (true) {
                        long j = jArr[i];
                        if (((((~j) << 7) & j) & -9187201950435737472L) != -9187201950435737472L) {
                            int i2 = 8 - ((~(i - length)) >>> 31);
                            for (int i3 = 0; i3 < i2; i3++) {
                                if ((255 & j) < 128) {
                                    d10 d10 = (d10) objArr[(i << 3) + i3];
                                    Iterator it = hashSet.iterator();
                                    while (it.hasNext()) {
                                        ((Set) it.next()).remove(d10.w());
                                    }
                                }
                                j >>= 8;
                            }
                            if (i2 != 8) {
                                break;
                            }
                        }
                        if (i == length) {
                            break;
                        }
                        i++;
                    }
                }
            }
            ik0.b();
        }
    }

    public final void u(d10 d10) {
        HashSet hashSet = this.d;
        if (hashSet != null) {
            Iterator it = hashSet.iterator();
            while (it.hasNext()) {
                Set set = (Set) it.next();
                d10.getClass();
                set.remove(d10.w());
            }
        }
        if (fu0.M(d10)) {
            this.e.l(d10);
        }
    }

    public b10(d10 d10, long j, boolean z, boolean z2, pg0 pg0) {
        this.g = d10;
        this.a = j;
        this.b = z;
        this.c = z2;
        ik0 ik0 = o01.a;
    }

    public final void l(yj yjVar) {
        d10 d10 = this.g;
        d10.b.l(d10.h);
        d10.b.l(yjVar);
    }

    public final void o(Set set) {
        Set set2 = this.d;
        if (set2 == null) {
            set2 = new HashSet();
            this.d = set2;
        }
        set2.add(set);
    }

    public final ik0 b(yj yjVar, l51 l51, m00 m00) {
        return this.g.b.b(yjVar, l51, m00);
    }

    public final void c() {
        d10 d10 = this.g;
        d10.A--;
    }

    public final boolean d() {
        return this.g.b.d();
    }

    public final qr0 i() {
        return (qr0) this.f.getValue();
    }

    public final sl j() {
        return this.g.b.j();
    }

    public final boolean k() {
        return this.g.b.k();
    }

    public final fj0 m(gj0 gj0) {
        return this.g.b.m(gj0);
    }

    public final ik0 n(yj yjVar, l51 l51, ik0 ik0) {
        return this.g.b.n(yjVar, l51, ik0);
    }

    public final oe s(f8 f8Var) {
        return this.g.b.s(f8Var);
    }

    public final void t() {
        d10 d10 = this.g;
        d10.A++;
    }

    public final void a(yj yjVar, m00 m00) {
        this.g.b.a(yjVar, m00);
    }

    public final void q(xv0 xv0) {
        this.g.b.q(xv0);
    }

    public final void r(yj yjVar) {
        this.g.b.r(yjVar);
    }

    public final void v(yj yjVar) {
        this.g.b.v(yjVar);
    }

    public final void p(d10 d10) {
        this.e.a(d10);
    }

    public final rj h() {
        return this.g.h;
    }

    public final boolean e() {
        return this.b;
    }

    public final boolean f() {
        return this.c;
    }

    public final long g() {
        return this.a;
    }
}