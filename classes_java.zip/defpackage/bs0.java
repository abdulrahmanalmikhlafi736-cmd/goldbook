package defpackage;

import java.util.Iterator;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bs0 */
public final class bs0 extends m {
    public final rr0 e;

    public final Iterator iterator() {
        od1 od1 = this.e.e;
        pd1[] pd1Arr = new pd1[8];
        for (int i = 0; i < 8; i++) {
            pd1Arr[i] = new h90(2);
        }
        return new sr0(od1, pd1Arr);
    }

    public final int a() {
        rr0 rr0 = this.e;
        rr0.getClass();
        return rr0.f;
    }

    public final boolean contains(Object obj) {
        return this.e.containsValue(obj);
    }

    public bs0(rr0 rr0) {
        this.e = rr0;
    }
}