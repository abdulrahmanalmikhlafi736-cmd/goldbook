package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cu */
public final class cu extends h90 implements i00 {
    public final /* synthetic */ int f;
    public final /* synthetic */ ju g;
    public final /* synthetic */ wu h;

    /* JADX WARNING: Missing block: B:7:0x0025, code:
            if (r10.a.c != null) goto L_0x0027;
     */
    /* JADX WARNING: Missing block: B:34:0x0072, code:
            if (r10.a.a != null) goto L_0x0074;
     */
    /* JADX WARNING: Missing block: B:47:0x0096, code:
            if (r10 == null) goto L_0x0098;
     */
    /* JADX WARNING: Missing block: B:54:0x00a9, code:
            if (r10 == null) goto L_0x00ab;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final Object i(Object obj) {
        int i = this.f;
        zt ztVar = zt.g;
        zt ztVar2 = zt.f;
        zt ztVar3 = zt.e;
        Object obj2 = null;
        float f = 1.0f;
        ju juVar = this.g;
        wu wuVar = this.h;
        ad1 ad1;
        Object obj3;
        int ordinal;
        switch (i) {
            case 0:
                ad1 = (ad1) obj;
                cv cvVar;
                if (ad1.a(ztVar3, ztVar2)) {
                    cvVar = juVar.a.a;
                    if (cvVar != null) {
                        obj3 = cvVar.a;
                        break;
                    }
                    obj3 = eu.b;
                } else if (ad1.a(ztVar2, ztVar)) {
                    cvVar = wuVar.a.a;
                    if (cvVar != null) {
                        obj3 = cvVar.a;
                        break;
                    }
                    obj3 = eu.b;
                } else {
                    obj3 = eu.b;
                }
                return obj3;
            case 1:
                ordinal = ((zt) obj).ordinal();
                if (ordinal != 0) {
                    if (ordinal != 1) {
                        if (ordinal == 2) {
                            break;
                        }
                        od.k();
                        return obj2;
                    }
                    obj2 = Float.valueOf(f);
                    return obj2;
                }
                if (juVar.a.a != null) {
                }
                obj2 = Float.valueOf(f);
                return obj2;
                f = 0.0f;
                obj2 = Float.valueOf(f);
                return obj2;
            case 2:
                ad1 = (ad1) obj;
                l01 l01;
                if (ad1.a(ztVar3, ztVar2)) {
                    l01 = juVar.a.c;
                    obj3 = l01 != null ? l01.b : eu.b;
                } else if (ad1.a(ztVar2, ztVar)) {
                    l01 = wuVar.a.c;
                    obj3 = l01 != null ? l01.b : eu.b;
                } else {
                    obj3 = eu.b;
                }
                return obj3;
            default:
                ordinal = ((zt) obj).ordinal();
                if (ordinal != 0) {
                    if (ordinal != 1) {
                        if (ordinal == 2) {
                            break;
                        }
                        od.k();
                        return obj2;
                    }
                    obj2 = Float.valueOf(f);
                    return obj2;
                }
                if (juVar.a.c != null) {
                }
                obj2 = Float.valueOf(f);
                return obj2;
                f = 0.0f;
                obj2 = Float.valueOf(f);
                return obj2;
        }
    }

    public /* synthetic */ cu(ju juVar, wu wuVar, int i) {
        this.f = i;
        this.g = juVar;
        this.h = wuVar;
        super(1);
    }
}