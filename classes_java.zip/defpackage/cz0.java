package defpackage;

import android.graphics.Region;
import android.os.Build.VERSION;
import android.view.View;
import java.util.ArrayList;
import java.util.Arrays;
import org.chromium.support_lib_boundary.StaticsBoundaryInterface;
import org.chromium.support_lib_boundary.WebSettingsBoundaryInterface;
import org.chromium.support_lib_boundary.WebViewProviderFactoryBoundaryInterface;
import org.chromium.support_lib_boundary.WebkitToCompatConverterBoundaryInterface;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cz0 */
public class cz0 implements tw, cg1, vi1 {
    public final /* synthetic */ int e;
    public Object f;

    public Object m(ye yeVar, xz xzVar) {
        ye yeVar2 = yeVar;
        if (((fj) this.f) == null) {
            a5.b("Called runAndWatch on a manager that has been disposed of");
        }
        fj fjVar = (fj) this.f;
        if (fjVar instanceof r51) {
            r51 r51 = (r51) fjVar;
            z21 z21 = r51.f;
            if (!(z21 == null || z21.equals(yeVar2))) {
                nj0 nj0 = new nj0();
                z21 z212 = r51.f;
                if (z212 == null) {
                    a5.b("promote must only be called when a manager is managing subscriptions for one channel and needs to start managing them for a second");
                }
                ik0 ik0 = r51.d;
                ArrayList arrayList = nj0.c;
                if (ik0 == null) {
                    Object obj = r51.b;
                    obj.getClass();
                    arrayList.add(new kj0(obj, z212));
                } else {
                    Object[] objArr = ik0.b;
                    long[] jArr = ik0.a;
                    int length = jArr.length - 2;
                    if (length >= 0) {
                        int i = 0;
                        while (true) {
                            long j = jArr[i];
                            if (((((~j) << 7) & j) & -9187201950435737472L) != -9187201950435737472L) {
                                int i2 = 8;
                                int i3 = 8 - ((~(i - length)) >>> 31);
                                int i4 = 0;
                                while (i4 < i3) {
                                    long j2;
                                    if ((j & 255) < 128) {
                                        j2 = i2;
                                        arrayList.add(new kj0(objArr[(i << 3) + i4], z212));
                                    } else {
                                        j2 = i2;
                                    }
                                    j >>= j2;
                                    i4++;
                                    i2 = j2;
                                }
                                if (i3 != i2) {
                                    break;
                                }
                            }
                            if (i == length) {
                                break;
                            }
                            i++;
                        }
                    }
                }
                nj0.d();
                r51.e();
                this.f = nj0;
            }
        }
        fj fjVar2 = (fj) this.f;
        fjVar2.getClass();
        i00 g = fjVar2.g(yeVar2);
        Object j3 = n61.j();
        g61 u = j3.u(g);
        fjVar2.c(yeVar2);
        try {
            g61 j4 = u.j();
            try {
                j3 = xzVar.a();
                fjVar2.d();
                return j3;
            } finally {
                g61.q(j4);
            }
        } finally {
            u.c();
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:15:0x0032  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0021  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public Object b(uw uwVar, ml mlVar) {
        r rVar;
        int i;
        Object obj;
        we1 we1;
        Throwable th;
        nl nlVar;
        if (mlVar instanceof r) {
            rVar = (r) mlVar;
            i = rVar.k;
            if ((i & Integer.MIN_VALUE) != 0) {
                rVar.k = i - Integer.MIN_VALUE;
                obj = rVar.i;
                i = rVar.k;
                we1 = we1.a;
                if (i != 0) {
                    nb0.t(obj);
                    sl slVar = rVar.f;
                    slVar.getClass();
                    nl g8Var = new g8(uwVar, slVar);
                    try {
                        rVar.h = g8Var;
                        rVar.k = 1;
                    } catch (Throwable th2) {
                        th = th2;
                        nlVar = g8Var;
                        nlVar.q();
                        throw th;
                    }
                    try {
                        cm f = ((m00) this.f).f(g8Var, rVar);
                        cm cmVar = cm.e;
                        if (f != cmVar) {
                            f = we1;
                        }
                        if (f == cmVar) {
                            return cmVar;
                        }
                        nlVar = g8Var;
                    } catch (Throwable th3) {
                        th = th3;
                        nlVar = g8Var;
                        nlVar.q();
                        throw th;
                    }
                } else if (i == 1) {
                    nlVar = rVar.h;
                    try {
                        nb0.t(obj);
                    } catch (Throwable th4) {
                        th = th4;
                    }
                } else {
                    od.p("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                nlVar.q();
                return we1;
            }
        }
        rVar = new r(this, mlVar);
        obj = rVar.i;
        i = rVar.k;
        we1 = we1.a;
        if (i != 0) {
        }
        nlVar.q();
        return we1;
    }

    public cz0(long[] jArr) {
        Object h90;
        this.e = 3;
        if (jArr != null) {
            jArr = Arrays.copyOf(jArr, jArr.length);
            h90 = new h90(jArr.length);
            int i = h90.b;
            if (i < 0) {
                od.f("");
                throw null;
            } else if (jArr.length != 0) {
                int length = jArr.length + i;
                long[] jArr2 = h90.a;
                if (jArr2.length < length) {
                    h90.a = Arrays.copyOf(jArr2, Math.max(length, (jArr2.length * 3) / 2));
                }
                long[] jArr3 = h90.a;
                length = h90.b;
                if (i != length) {
                    ba.X(jArr3, jArr3, jArr.length + i, i, length);
                }
                ba.X(jArr, jArr3, i, 0, jArr.length);
                h90.b += jArr.length;
            }
        } else {
            h90 = new vj0();
        }
        this.f = h90;
    }

    public long g(long j) {
        zo zoVar = (zo) this.f;
        zoVar.getClass();
        if (gg1.b(j) <= 0.0f || gg1.c(j) <= 0.0f) {
            StringBuilder dl1 = new dl1("maximumVelocity should be a positive value. You specified=");
            dl1.append(gg1.f(j));
            a5.b(dl1.toString());
        }
        return kb0.c(zoVar.a.b(gg1.b(j)), zoVar.b.b(gg1.c(j)));
    }

    public hw l(int i) {
        switch (this.e) {
            case gu0.DOUBLE_FIELD_NUMBER /*7*/:
                return ((iw[]) this.f)[i];
            case 8:
                return (iw) this.f;
            default:
                return (hw) this.f;
        }
    }

    public StaticsBoundaryInterface getStatics() {
        return (StaticsBoundaryInterface) ac.k(StaticsBoundaryInterface.class, ((WebViewProviderFactoryBoundaryInterface) this.f).getStatics());
    }

    public WebkitToCompatConverterBoundaryInterface getWebkitToCompatConverter() {
        return (WebkitToCompatConverterBoundaryInterface) ac.k(WebkitToCompatConverterBoundaryInterface.class, ((WebViewProviderFactoryBoundaryInterface) this.f).getWebkitToCompatConverter());
    }

    public void n(r60 r60) {
        ((Region) this.f).set(r60.a, r60.b, r60.c, r60.d);
    }

    public u8 f(long j, u8 u8Var, u8 u8Var2, u8 u8Var3) {
        return ((p3) this.f).f(j, u8Var, u8Var2, u8Var3);
    }

    public u8 i(long j, u8 u8Var, u8 u8Var2, u8 u8Var3) {
        return ((p3) this.f).i(j, u8Var, u8Var2, u8Var3);
    }

    public boolean a() {
        ((p3) this.f).getClass();
        return false;
    }

    public String[] e() {
        return ((WebViewProviderFactoryBoundaryInterface) this.f).getSupportedFeatures();
    }

    public u8 j(u8 u8Var, u8 u8Var2, u8 u8Var3) {
        return ((p3) this.f).j(u8Var, u8Var2, u8Var3);
    }

    public long k(u8 u8Var, u8 u8Var2, u8 u8Var3) {
        return ((p3) this.f).k(u8Var, u8Var2, u8Var3);
    }

    public void p() {
        ((WebSettingsBoundaryInterface) this.f).setForceDarkBehavior(1);
    }

    public void o(int i) {
        ((WebSettingsBoundaryInterface) this.f).setForceDark(i);
    }

    public cz0(View view) {
        this.e = 4;
        if (VERSION.SDK_INT >= 30) {
            e71 x50 = new x50(view, 1);
            x50.b = view;
            this.f = x50;
            return;
        }
        this.f = new x50(view, 1);
    }

    public cz0(float f, float f2, u8 u8Var) {
        this.e = 10;
        int i = dg1.a;
        this.f = new p3(u8Var != null ? new cz0(u8Var, f, f2) : new aj1(f, f2));
    }

    public cz0(int i) {
        this.e = i;
        switch (i) {
            case 11:
                this.f = new zo();
                return;
            default:
                this.f = new Region();
                return;
        }
    }

    public cz0(float f, float f2) {
        this.e = 8;
        this.f = new iw(f, f2, 0.01f);
    }

    public cz0(jp jpVar) {
        this.e = 5;
        this.f = new dw(n71.a, jpVar);
    }

    public cz0(u8 u8Var, float f, float f2) {
        this.e = 7;
        int b = u8Var.b();
        iw[] iwVarArr = new iw[b];
        for (int i = 0; i < b; i++) {
            iwVarArr[i] = new iw(f, f2, u8Var.a(i));
        }
        this.f = iwVarArr;
    }
}