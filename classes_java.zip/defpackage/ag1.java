package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ag1 */
public final class ag1 extends wp0 {
    public final lq0 e = mc0.t(new ad(0));
    public final lq0 f = mc0.t(Boolean.FALSE);
    public final wf1 g;
    public final lq0 h;
    public float i;
    public pb j;

    public final void e(da0 da0) {
        te teVar = da0.e;
        pb pbVar = this.j;
        wf1 wf1 = this.g;
        if (pbVar == null) {
            pbVar = (pb) wf1.g.getValue();
        }
        if (((Boolean) this.f.getValue()).booleanValue() && da0.getLayoutDirection() == o90.f) {
            long e = teVar.e();
            k9 k9Var = teVar.f;
            long t = k9Var.t();
            k9Var.q().i();
            try {
                ((pg0) k9Var.f).C(-1.0f, 1.0f, e);
                wf1.e(da0, this.i, pbVar);
            } finally {
                k9Var.q().g();
                k9Var.E(t);
            }
        } else {
            wf1.e(da0, this.i, pbVar);
        }
        this.h.getValue();
    }

    public ag1(s20 s20) {
        wf1 wf1 = new wf1(s20);
        wf1.f = new f8(13, this);
        this.g = wf1;
        this.h = new lq0(we1.a, e3.X);
        this.i = 1.0f;
    }

    public final long d() {
        return ((s51) this.e.getValue()).a;
    }

    public final void a(float f) {
        this.i = f;
    }

    public final void b(pb pbVar) {
        this.j = pbVar;
    }
}