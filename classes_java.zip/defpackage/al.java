package defpackage;

import android.os.Build.VERSION;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableString;
import android.view.View;
import android.view.WindowInsetsAnimation.Bounds;
import android.view.autofill.AutofillId;
import java.lang.ref.Reference;
import java.lang.ref.ReferenceQueue;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.Objects;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: al */
public final class al implements lt, tw, i91, oe, yo0, a01 {
    public final /* synthetic */ int e;
    public Object f;
    public Object g;

    /* JADX WARNING: Removed duplicated region for block: B:16:0x003b  */
    /* JADX WARNING: Removed duplicated region for block: B:10:0x002c  */
    /* JADX WARNING: Removed duplicated region for block: B:48:0x00b6  */
    /* JADX WARNING: Removed duplicated region for block: B:40:0x009d  */
    /* JADX WARNING: Missing block: B:57:0x00eb, code:
            if (r10.b(r11, r0) != r6) goto L_0x00ee;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public Object b(uw uwVar, ml mlVar) {
        nl nlVar;
        Throwable th;
        a e;
        xq xqVar;
        int i = this.e;
        String str = "call to 'resume' before 'invoke' with coroutine";
        Object obj = we1.a;
        cm cmVar = cm.e;
        Object obj2;
        switch (i) {
            case 3:
                zw zwVar;
                int i2;
                al alVar;
                tw twVar;
                if (mlVar instanceof zw) {
                    zwVar = (zw) mlVar;
                    int i3 = zwVar.i;
                    if ((i3 & Integer.MIN_VALUE) != 0) {
                        zwVar.i = i3 - Integer.MIN_VALUE;
                        obj2 = zwVar.h;
                        i2 = zwVar.i;
                        if (i2 != 0) {
                            nb0.t(obj2);
                            sl slVar = zwVar.f;
                            slVar.getClass();
                            nl g8Var = new g8(uwVar, slVar);
                            try {
                                bn bnVar = (bn) this.f;
                                try {
                                    zwVar.k = this;
                                    zwVar.l = uwVar;
                                    zwVar.m = g8Var;
                                    zwVar.i = 1;
                                    if (bnVar.f(g8Var, zwVar) == cmVar) {
                                        obj = cmVar;
                                        return obj;
                                    }
                                    alVar = this;
                                    nlVar = g8Var;
                                } catch (Throwable th2) {
                                    th = th2;
                                    nlVar = g8Var;
                                    nlVar.q();
                                    throw th;
                                }
                            } catch (Throwable th3) {
                                th = th3;
                                nlVar = g8Var;
                                nlVar.q();
                                throw th;
                            }
                        } else if (i2 != 1) {
                            if (i2 == 2) {
                                nb0.t(obj2);
                            } else {
                                od.p(str);
                                obj = null;
                            }
                            return obj;
                        } else {
                            nlVar = zwVar.m;
                            uwVar = zwVar.l;
                            alVar = zwVar.k;
                            try {
                                nb0.t(obj2);
                            } catch (Throwable th4) {
                                th = th4;
                            }
                        }
                        nlVar.q();
                        twVar = (tw) alVar.g;
                        zwVar.k = null;
                        zwVar.l = null;
                        zwVar.m = null;
                        zwVar.i = 2;
                        break;
                    }
                }
                zwVar = new bx(this, mlVar);
                obj2 = zwVar.h;
                i2 = zwVar.i;
                if (i2 != 0) {
                }
                nlVar.q();
                twVar = (tw) alVar.g;
                zwVar.k = null;
                zwVar.l = null;
                zwVar.m = null;
                zwVar.i = 2;
            case gu0.LONG_FIELD_NUMBER /*4*/:
                cm b = ((tw) this.f).b(new g8(new Object(), uwVar, (m00) this.g, 2), mlVar);
                if (b == cmVar) {
                    obj = b;
                }
                return obj;
            default:
                bx bxVar;
                int i4;
                if (mlVar instanceof bx) {
                    bxVar = (bx) mlVar;
                    i4 = bxVar.i;
                    if ((i4 & Integer.MIN_VALUE) != 0) {
                        bxVar.i = i4 - Integer.MIN_VALUE;
                        obj2 = bxVar.h;
                        i4 = bxVar.i;
                        if (i4 != 0) {
                            nb0.t(obj2);
                            al alVar2 = (al) this.f;
                            xq alVar3 = new al(1, (cn) this.g, uwVar);
                            try {
                                bxVar.k = alVar3;
                                bxVar.i = 1;
                                if (alVar2.b(alVar3, bxVar) == cmVar) {
                                    obj = cmVar;
                                }
                            } catch (a e2) {
                                e = e2;
                                xqVar = alVar3;
                                if (e.e == xqVar) {
                                    sl slVar2 = bxVar.f;
                                    slVar2.getClass();
                                    j70.B(slVar2);
                                    return obj;
                                }
                                throw e;
                            }
                        } else if (i4 == 1) {
                            xqVar = bxVar.k;
                            try {
                                nb0.t(obj2);
                            } catch (a e3) {
                                e = e3;
                            }
                        } else {
                            od.p(str);
                            obj = null;
                        }
                        return obj;
                    }
                }
                bxVar = new bx(this, mlVar);
                obj2 = bxVar.h;
                i4 = bxVar.i;
                if (i4 != 0) {
                }
                return obj;
        }
    }

    public static void m(ba0 ba0) {
        if (ba0.T > 0) {
            int i = 0;
            if (ba0.K.d == x90.i && !ba0.p() && !ba0.q()) {
                if (!ba0.U) {
                    if (ba0.I()) {
                        li0 li0 = ba0.J.f;
                        if ((li0.h & 256) != 0) {
                            while (li0 != null) {
                                if ((li0.g & 256) != 0) {
                                    Object obj = li0;
                                    hb0 hb0 = null;
                                    li0 li02;
                                    while (li02 != null) {
                                        if (li02 instanceof q10) {
                                            q10 q10 = (q10) li02;
                                            q10.o(k70.M(q10, 256));
                                        } else if ((li02.g & 256) != 0 && (li02 instanceof dp)) {
                                            int i2 = 0;
                                            for (li0 li03 = ((dp) li02).t; li03 != null; li03 = li03.j) {
                                                if ((li03.g & 256) != 0) {
                                                    i2++;
                                                    if (i2 == 1) {
                                                        li02 = li03;
                                                    } else {
                                                        if (hb0 == null) {
                                                            hb0 = new qk0(new li0[16]);
                                                        }
                                                        if (obj != null) {
                                                            r5.b(obj);
                                                            obj = null;
                                                        }
                                                        r5.b(li03);
                                                    }
                                                }
                                            }
                                            if (i2 == 1) {
                                            }
                                        }
                                        obj = k70.m(hb0);
                                    }
                                }
                                if ((li0.h & 256) == 0) {
                                    break;
                                }
                                li0 = li0.j;
                            }
                        }
                    }
                }
            }
            ba0.S = false;
            qk0 z = ba0.z();
            Object[] objArr = z.e;
            int i3 = z.g;
            while (i < i3) {
                al.m((ba0) objArr[i]);
                i++;
            }
        }
    }

    public al(int i) {
        this.e = i;
        switch (i) {
            case 10:
                this.f = new h90(0);
                this.g = new h90(0);
                return;
            case 11:
                this.f = mc0.t(Boolean.FALSE);
                return;
            case 13:
                this.f = new hk0();
                this.g = new hk0();
                return;
            case 14:
                this.f = new qk0(new ba0[16]);
                return;
            case 18:
                this.f = new LinkedHashMap();
                this.g = new LinkedHashMap();
                return;
            case 23:
                this.f = new h90(16);
                this.g = new h90(16);
                return;
            case 24:
                this.f = new qk0(new Reference[16]);
                this.g = new ReferenceQueue();
                return;
            default:
                return;
        }
    }

    public void r(Bundle bundle) {
        wz0 wz0 = (wz0) this.f;
        Bundle j = a5.j((zp0[]) Arrays.copyOf(new zp0[0], 0));
        Bundle bundle2 = wz0.f;
        if (bundle2 != null) {
            j.putAll(bundle2);
        }
        synchronized (wz0.c) {
            for (Entry entry : wz0.d.entrySet()) {
                String str = (String) entry.getKey();
                Bundle a = ((vz0) entry.getValue()).a();
                str.getClass();
                j.putBundle(str, a);
            }
        }
        if (!j.isEmpty()) {
            bundle.putBundle("androidx.lifecycle.BundlableSavedStateRegistry.key", j);
        }
    }

    public void q(Bundle bundle) {
        wz0 wz0 = (wz0) this.f;
        xz0 xz0 = wz0.a;
        if (!wz0.e) {
            wz0.a();
        }
        if (xz0.g().d.compareTo(jd0.h) >= 0) {
            jd0 jd0 = xz0.g().d;
            StringBuilder dl1 = new dl1("performRestore cannot be called when owner is ");
            dl1.append(jd0);
            throw new dl1(dl1.toString().toString());
        } else if (wz0.g) {
            od.p("SavedStateRegistry was already restored.");
        } else {
            Bundle bundle2 = null;
            if (bundle != null) {
                String str = "androidx.lifecycle.BundlableSavedStateRegistry.key";
                if (bundle.containsKey(str)) {
                    bundle2 = kb0.n(bundle, str);
                }
            }
            wz0.f = bundle2;
            wz0.g = true;
        }
    }

    public void t() {
        Class cls = cd0.class;
        if (((wz0) this.f).h) {
            Object obj = (ew0) this.g;
            if (obj == null) {
                obj = new ew0(this);
            }
            this.g = obj;
            try {
                cls.getDeclaredConstructor(null);
                ew0 ew0 = (ew0) this.g;
                if (ew0 != null) {
                    ew0.a.add(cls.getName());
                }
                return;
            } catch (NoSuchMethodException e) {
                String simpleName = cls.getSimpleName();
                StringBuilder dl1 = new dl1("Class ");
                dl1.append(simpleName);
                dl1.append(" must have default constructor in order to be automatically recreated");
                throw new IllegalArgumentException(dl1.toString(), e);
            }
        }
        od.p("Can not perform this action after onSaveInstanceState");
    }

    public void l() {
        qk0 qk0 = (qk0) this.f;
        int i = 0;
        Arrays.sort(qk0.e, 0, qk0.g, uy.d);
        int i2 = qk0.g;
        ba0[] ba0Arr = (ba0[]) this.g;
        if (ba0Arr == null || ba0Arr.length < i2) {
            ba0Arr = new ba0[Math.max(16, i2)];
        }
        this.g = null;
        while (i < i2) {
            ba0Arr[i] = qk0.e[i];
            i++;
        }
        qk0.g();
        for (i2--; -1 < i2; i2--) {
            Object obj = ba0Arr[i2];
            obj.getClass();
            if (obj.S) {
                al.m(obj);
            }
            ba0Arr[i2] = null;
        }
        this.g = ba0Arr;
    }

    public void f(h91 h91) {
        zj0 zj0 = (zj0) this.g;
        zj0.a();
        bk0 bk0 = (bk0) h91.f;
        Object[] objArr = bk0.b;
        long[] jArr = bk0.c;
        int i = bk0.e;
        while (i != Integer.MAX_VALUE) {
            int i2 = (int) ((jArr[i] >> 31) & 2147483647L);
            Object obj = objArr[i];
            Object b = ((hb0) this.f).b(obj);
            int d = zj0.d(b);
            d = d >= 0 ? zj0.c[d] : 0;
            if (d == 7) {
                h91.remove(obj);
            } else {
                zj0.g(d + 1, b);
            }
            i = i2;
        }
    }

    public vz0 o(String str) {
        vz0 vz0;
        wz0 wz0 = (wz0) this.f;
        synchronized (wz0.c) {
            Iterator it = wz0.d.entrySet().iterator();
            do {
                vz0 = null;
                if (!it.hasNext()) {
                    break;
                }
                Entry entry = (Entry) it.next();
                String str2 = (String) entry.getKey();
                vz0 vz02 = (vz0) entry.getValue();
                if (k70.p(str2, str)) {
                    vz0 = vz02;
                    continue;
                }
            } while (vz0 == null);
        }
        return vz0;
    }

    public boolean g(CharSequence charSequence, int i, int i2, fe1 fe1) {
        if ((fe1.c & 4) > 0) {
            return true;
        }
        if (((bf1) this.f) == null) {
            this.f = new bf1(charSequence instanceof Spannable ? (Spannable) charSequence : new SpannableString(charSequence));
        }
        ((vj) this.g).getClass();
        ((bf1) this.f).setSpan(new ge1(fe1), i, i2, 33);
        return true;
    }

    public String toString() {
        switch (this.e) {
            case 25:
                StringBuilder dl1 = new dl1("Bounds{lower=");
                dl1.append((c60) this.f);
                dl1.append(" upper=");
                dl1.append((c60) this.g);
                dl1.append("}");
                return dl1.toString();
            default:
                return super.toString();
        }
    }

    public Bundle k(String str) {
        wz0 wz0 = (wz0) this.f;
        if (wz0.g) {
            Bundle bundle = wz0.f;
            if (bundle == null) {
                return null;
            }
            Bundle n = bundle.containsKey(str) ? kb0.n(bundle, str) : null;
            bundle.remove(str);
            if (bundle.isEmpty()) {
                wz0.f = null;
            }
            return n;
        }
        od.p("You can 'consumeRestoredStateForKey' only after the corresponding component has moved to the 'CREATED' state");
        return null;
    }

    public List d(Integer num) {
        List d = ((yo0) this.f).d(null);
        a61 a61 = (a61) this.g;
        int i = a61.v;
        return i < 0 ? d : tg.Z(wl1.p(a61, num, i, Integer.valueOf(a61.E(a61.b, i))), d);
    }

    public void s(String str, vz0 vz0) {
        vz0.getClass();
        wz0 wz0 = (wz0) this.f;
        synchronized (wz0.c) {
            if (wz0.d.containsKey(str)) {
                throw new dl1("SavedStateProvider with the given key is already registered");
            }
            wz0.d.put(str, vz0);
        }
    }

    public AutofillId p(long j) {
        if (VERSION.SDK_INT < 29) {
            return null;
        }
        Object e = a01.e(this.f);
        k1 m = sb0.m((View) this.g);
        Objects.requireNonNull(m);
        return zk.b(e, bk0.d(m.a), j);
    }

    public void cancel() {
        if (!((ca) this.g).compareAndSet(1, 1)) {
            ((na) this.f).a();
        }
    }

    public boolean i(Object obj, Object obj2) {
        hb0 hb0 = (hb0) this.f;
        return k70.p(hb0.b(obj), hb0.b(obj2));
    }

    public mh0 n() {
        return (mh0) ((lq0) this.g).getValue();
    }

    public Object e(Object obj) {
        return ((i00) this.g).i(obj);
    }

    public boolean h() {
        return ((yo0) this.f).h();
    }

    public Object j(iz0 iz0, Object obj) {
        return ((m00) this.f).f(iz0, obj);
    }

    public al(Bounds bounds) {
        this.e = 25;
        this.f = c60.c(bounds.getLowerBound());
        this.g = c60.c(bounds.getUpperBound());
    }

    public Object a() {
        return (bf1) this.f;
    }

    public al(hb0 hb0) {
        this.e = 7;
        this.f = hb0;
        zj0 zj0 = sm0.a;
        this.g = new zj0();
    }

    public al(na naVar) {
        this.e = 15;
        this.f = naVar;
        this.g = new h90(0);
    }

    public al(Object obj) {
        this.e = 11;
        super(11);
        this.g = mc0.t(obj);
        mc0.t(obj);
    }

    public al(wz0 wz0, int i) {
        this.e = i;
        switch (i) {
            case 20:
                this.f = wz0;
                this.g = new al(wz0, 19);
                return;
            default:
                this.f = wz0;
                return;
        }
    }

    public al(xz xzVar, i00 i00) {
        this.e = 2;
        i00.getClass();
        this.f = i00;
        this.g = xzVar;
    }

    public al(ba0 ba0, mh0 mh0) {
        this.e = 6;
        this.f = ba0;
        this.g = mc0.t(mh0);
    }

    public /* synthetic */ al(int i, Object obj, Object obj2) {
        this.e = i;
        this.f = obj;
        this.g = obj2;
    }
}