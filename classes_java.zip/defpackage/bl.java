package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bl */
public final class bl implements xz {
    public static final bl e = new Object();

    public final Object a() {
        return new ad(zg.b);
    }
}