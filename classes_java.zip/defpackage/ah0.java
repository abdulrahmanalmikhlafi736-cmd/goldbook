package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ah0 */
public abstract class ah0 {
    public static final zg0 a;
    public static final zg0 b = new Object();

    static {
        jv0 jv0 = jv0.c;
        zg0 zg0 = null;
        try {
            zg0 = (zg0) Class.forName("androidx.datastore.preferences.protobuf.MapFieldSchemaFull").getDeclaredConstructor(null).newInstance(null);
        } catch (Exception unused) {
        }
        a = zg0;
    }
}