package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cy0 */
public final class cy0 {
    public final long a = zg.i;

    public final String toString() {
        StringBuilder dl1 = new dl1("RippleConfiguration(color=");
        dl1.append(zg.i(this.a));
        dl1.append(", rippleAlpha=null)");
        return dl1.toString();
    }

    /* JADX WARNING: Missing block: B:6:0x0012, code:
            if (defpackage.n60.c(r2.a, ((defpackage.cy0) r3).a) == null) goto L_0x0014;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean equals(Object obj) {
        if (this != obj) {
            if (obj instanceof cy0) {
            }
            return false;
        }
        return true;
    }

    public final int hashCode() {
        int i = zg.j;
        return pe1.a(this.a) * 31;
    }
}