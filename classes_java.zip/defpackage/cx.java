package defpackage;

/* renamed from: cx */
public final class cx extends nl {
    public xq h;
    public /* synthetic */ Object i;
    public int j;
    public final /* synthetic */ xq k;
    public Object l;

    public final Object p(Object obj) {
        this.i = obj;
        this.j |= Integer.MIN_VALUE;
        return this.k.k(null, this);
    }

    public cx(xq xqVar, ml mlVar) {
        this.k = xqVar;
        super(mlVar);
    }
}