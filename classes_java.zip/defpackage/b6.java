package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: b6 */
public final class b6 {
    public final float a;
    public final float b;

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof b6)) {
            return false;
        }
        b6 b6Var = (b6) obj;
        return Float.compare(this.a, b6Var.a) == 0 && Float.compare(this.b, b6Var.b) == 0;
    }

    public final String toString() {
        StringBuilder dl1 = new dl1("FlingResult(distanceCoefficient=");
        dl1.append(this.a);
        dl1.append(", velocityCoefficient=");
        return fu0.F(dl1, this.b, ')');
    }

    public final int hashCode() {
        return Float.floatToIntBits(this.b) + (Float.floatToIntBits(this.a) * 31);
    }

    public b6(float f, float f2) {
        this.a = f;
        this.b = f2;
    }
}