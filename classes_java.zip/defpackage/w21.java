package defpackage;

import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicLongFieldUpdater;
import java.util.concurrent.atomic.AtomicReferenceArray;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: w21 */
public class w21 {
    public static final /* synthetic */ AtomicReferenceFieldUpdater b;
    public static final /* synthetic */ AtomicLongFieldUpdater c;
    public static final /* synthetic */ AtomicReferenceFieldUpdater d;
    public static final /* synthetic */ AtomicLongFieldUpdater e;
    public static final /* synthetic */ AtomicIntegerFieldUpdater f;
    private volatile /* synthetic */ int _availablePermits$volatile = 1;
    public final me a = new me(2, (Object) this);
    private volatile /* synthetic */ long deqIdx$volatile;
    private volatile /* synthetic */ long enqIdx$volatile;
    private volatile /* synthetic */ Object head$volatile;
    private volatile /* synthetic */ Object tail$volatile;

    public final void b() {
        int i;
        do {
            AtomicIntegerFieldUpdater atomicIntegerFieldUpdater = f;
            long andIncrement = atomicIntegerFieldUpdater.getAndIncrement(this);
            i = 1;
            if (andIncrement >= 1) {
                while (true) {
                    int i2 = atomicIntegerFieldUpdater.get(this);
                    if (i2 <= 1 || atomicIntegerFieldUpdater.compareAndSet(this, i2, 1)) {
                    }
                }
                throw new dl1("The number of released permits cannot be greater than 1".toString());
            } else if (andIncrement >= null) {
                break;
            } else {
                Object C;
                AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = b;
                y21 y21 = (y21) atomicReferenceFieldUpdater.get(this);
                long andIncrement2 = c.getAndIncrement(this);
                long j = andIncrement2 / ((long) x21.f);
                v21 v21 = v21.l;
                while (true) {
                    C = j70.C(y21, j, v21);
                    if (dd0.l(C)) {
                        break;
                    }
                    a21 k = dd0.k(C);
                    while (true) {
                        a21 a21 = (a21) atomicReferenceFieldUpdater.get(this);
                        if (a21.c >= k.c) {
                            break;
                        } else if (!k.i()) {
                            break;
                        } else {
                            while (!atomicReferenceFieldUpdater.compareAndSet(this, a21, k)) {
                                if (atomicReferenceFieldUpdater.get(this) != a21) {
                                    if (k.e()) {
                                        k.d();
                                    }
                                }
                            }
                            if (a21.e()) {
                                a21.d();
                            }
                        }
                    }
                }
                y21 y212 = (y21) dd0.k(C);
                AtomicReferenceArray atomicReferenceArray = y212.e;
                y212.a();
                int i3 = (y212.c > j ? 1 : (y212.c == j ? 0 : -1));
                int i4 = 0;
                if (i3 <= 0) {
                    i3 = (int) (andIncrement2 % ((long) x21.f));
                    mt andSet = atomicReferenceArray.getAndSet(i3, x21.b);
                    if (andSet == null) {
                        int i5 = x21.a;
                        for (int i6 = 0; i6 < i5; i6++) {
                            if (atomicReferenceArray.get(i3) == x21.c) {
                                continue;
                                break;
                            }
                        }
                        mt mtVar = x21.b;
                        mt mtVar2 = x21.d;
                        while (!atomicReferenceArray.compareAndSet(i3, mtVar, mtVar2)) {
                            if (atomicReferenceArray.get(i3) != mtVar) {
                                break;
                            }
                        }
                        i4 = 1;
                        i = 1 ^ i4;
                        continue;
                    } else if (andSet != x21.e) {
                        if (andSet instanceof le) {
                            le leVar = (le) andSet;
                            mt j2 = leVar.j(we1.a, this.a);
                            if (j2 != null) {
                                leVar.x(j2);
                                continue;
                            }
                        } else {
                            od.l(andSet, "unexpected: ");
                            return;
                        }
                    }
                }
                i = 0;
                continue;
            }
        } while (i == 0);
    }

    public final void a(bl0 bl0) {
        bl0 bl02 = bl0;
        ne neVar = bl02.e;
        cl0 cl0 = bl02.f;
        while (true) {
            int andDecrement = f.getAndDecrement(this);
            if (andDecrement <= 1) {
                we1 we1 = we1.a;
                if (andDecrement > 0) {
                    cl0.g.set(cl0, null);
                    neVar.D(we1, neVar.g, new me(0, new l(cl0, bl02)));
                    return;
                }
                Object C;
                AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = d;
                a21 a21 = (y21) atomicReferenceFieldUpdater.get(this);
                long andIncrement = e.getAndIncrement(this);
                u21 u21 = u21.l;
                long j = andIncrement / ((long) x21.f);
                while (true) {
                    a21 a212;
                    C = j70.C(a21, j, u21);
                    if (dd0.l(C)) {
                        break;
                    }
                    a21 k = dd0.k(C);
                    while (true) {
                        a21 a213 = (a21) atomicReferenceFieldUpdater.get(this);
                        a212 = a21;
                        if (a213.c >= k.c) {
                            break;
                        } else if (!k.i()) {
                            break;
                        } else {
                            while (!atomicReferenceFieldUpdater.compareAndSet(this, a213, k)) {
                                if (atomicReferenceFieldUpdater.get(this) != a213) {
                                    if (k.e()) {
                                        k.d();
                                    }
                                    a21 = a212;
                                }
                            }
                            if (a213.e()) {
                                a213.d();
                            }
                        }
                    }
                    a21 = a212;
                }
                y21 y21 = (y21) dd0.k(C);
                AtomicReferenceArray atomicReferenceArray = y21.e;
                int i = (int) (andIncrement % ((long) x21.f));
                while (!atomicReferenceArray.compareAndSet(i, null, bl02)) {
                    if (atomicReferenceArray.get(i) != null) {
                        mt mtVar = x21.b;
                        mt mtVar2 = x21.c;
                        while (!atomicReferenceArray.compareAndSet(i, mtVar, mtVar2)) {
                            if (atomicReferenceArray.get(i) != mtVar) {
                            }
                        }
                        cl0.g.set(cl0, null);
                        neVar.D(we1, neVar.g, new me(0, new l(cl0, bl02)));
                        return;
                    }
                }
                bl02.a(y21, i);
                return;
            }
        }
    }

    static {
        Class cls = w21.class;
        Class cls2 = Object.class;
        b = AtomicReferenceFieldUpdater.newUpdater(cls, cls2, "head$volatile");
        c = AtomicLongFieldUpdater.newUpdater(cls, "deqIdx$volatile");
        d = AtomicReferenceFieldUpdater.newUpdater(cls, cls2, "tail$volatile");
        e = AtomicLongFieldUpdater.newUpdater(cls, "enqIdx$volatile");
        f = AtomicIntegerFieldUpdater.newUpdater(cls, "_availablePermits$volatile");
    }

    public w21() {
        y21 y21 = new y21(0, null, 2);
        this.head$volatile = y21;
        this.tail$volatile = y21;
    }
}