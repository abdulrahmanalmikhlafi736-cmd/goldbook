package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cr */
public final class cr implements pl {
    public final float a;

    /* JADX WARNING: Missing block: B:6:0x0012, code:
            if (defpackage.br.b(r1.a, ((defpackage.cr) r2).a) == false) goto L_0x0014;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean equals(Object obj) {
        if (this != obj) {
            if (obj instanceof cr) {
            }
            return false;
        }
        return true;
    }

    public final String toString() {
        StringBuilder dl1 = new dl1("CornerSize(size = ");
        dl1.append(this.a);
        dl1.append(".dp)");
        return dl1.toString();
    }

    public final float a(long j, jp jpVar) {
        return jpVar.q(this.a);
    }

    public final int hashCode() {
        return Float.floatToIntBits(this.a);
    }

    public cr(float f) {
        this.a = f;
    }
}