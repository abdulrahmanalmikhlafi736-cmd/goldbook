package defpackage;

import android.graphics.Typeface;
import java.lang.reflect.Array;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ce1 */
public final class ce1 extends be1 {
    /* JADX WARNING: Removed duplicated region for block: B:11:0x002b A:{Splitter: B:1:0x0005, ExcHandler: java.lang.IllegalAccessException (e java.lang.IllegalAccessException)} */
    /* JADX WARNING: Missing block: B:11:0x002b, code:
            r4 = e;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final Typeface C(Object obj) {
        Integer valueOf = Integer.valueOf(-1);
        try {
            Array.set(Array.newInstance(this.b, 1), 0, obj);
            try {
                return (Typeface) this.h.invoke(null, new Object[]{Array.newInstance(this.b, 1), "sans-serif", valueOf, valueOf});
            } catch (InvocationTargetException e) {
                Throwable e2 = e;
                throw new RuntimeException(e2);
            }
        } catch (IllegalAccessException e3) {
        }
    }

    public final Method E(Class cls) {
        r0 = new Class[4];
        Class cls2 = Integer.TYPE;
        r0[2] = cls2;
        r0[3] = cls2;
        Method declaredMethod = Typeface.class.getDeclaredMethod("createFromFamiliesWithDefault", r0);
        declaredMethod.setAccessible(true);
        return declaredMethod;
    }
}