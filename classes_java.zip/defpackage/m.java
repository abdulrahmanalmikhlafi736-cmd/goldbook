package defpackage;

import java.util.Collection;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: m */
public abstract class m implements Collection, w80 {
    public boolean containsAll(Collection collection) {
        collection.getClass();
        Iterable<Object> iterable = collection;
        if (!((Collection) iterable).isEmpty()) {
            for (Object contains : iterable) {
                if (!contains(contains)) {
                    return false;
                }
            }
        }
        return true;
    }

    public boolean contains(Object obj) {
        if (isEmpty()) {
            return false;
        }
        for (Object p : this) {
            if (k70.p(p, obj)) {
                return true;
            }
        }
        return false;
    }

    public final String toString() {
        return tg.V(this, ", ", "[", "]", new l(0, (Object) this), 24);
    }

    public final boolean isEmpty() {
        return a() == 0;
    }

    public final boolean add(Object obj) {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final boolean addAll(Collection collection) {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final void clear() {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final boolean remove(Object obj) {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final boolean removeAll(Collection collection) {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final boolean retainAll(Collection collection) {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final Object[] toArray(Object[] objArr) {
        objArr.getClass();
        return vd1.H(this, objArr);
    }

    public final /* bridge */ int size() {
        return a();
    }

    public final Object[] toArray() {
        return vd1.G(this);
    }

    public abstract int a();
}