package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: nx0 */
public abstract class nx0 extends db {
    public nx0(ml mlVar) {
        super(mlVar);
        if (mlVar == null) {
            return;
        }
        if (mlVar.e() != st.e) {
            od.m("Coroutines with restricted suspension must have EmptyCoroutineContext");
            throw null;
        }
    }

    public final sl e() {
        return st.e;
    }
}