package defpackage;

import android.graphics.Rect;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: b4 */
public final class b4 extends li0 implements qc, g21, f90, t90, kd1 {
    public final j3 s = new j3(2, this);
    public final /* synthetic */ n4 t;

    public final boolean I(KeyEvent keyEvent) {
        ux h90;
        int[] iArr = ay.a;
        long b = ac.b(keyEvent.getKeyCode());
        int i = 1;
        int i2 = 2;
        if (d90.a(b, d90.b)) {
            h90 = new h90(2);
        } else if (d90.a(b, d90.c)) {
            h90 = new h90(1);
        } else if (d90.a(b, d90.i)) {
            h90 = new h90(keyEvent.isShiftPressed() ? 2 : 1);
        } else if (d90.a(b, d90.g)) {
            h90 = new h90(4);
        } else if (d90.a(b, d90.f)) {
            h90 = new h90(3);
        } else {
            if (!d90.a(b, d90.d)) {
                if (!d90.a(b, d90.m)) {
                    if (!d90.a(b, d90.e)) {
                        if (!d90.a(b, d90.n)) {
                            if (!(d90.a(b, d90.h) || d90.a(b, d90.k))) {
                                if (!d90.a(b, d90.o)) {
                                    if (!d90.a(b, d90.a)) {
                                        if (!d90.a(b, d90.l)) {
                                            h90 = null;
                                        }
                                    }
                                    h90 = new h90(8);
                                }
                            }
                            h90 = new h90(7);
                        }
                    }
                    h90 = new h90(6);
                }
            }
            h90 = new h90(5);
        }
        if (h90 != null) {
            int i3 = h90.a;
            if (a5.v(keyEvent) == 2) {
                n4 n4Var = this.t;
                ry f = ((hy) n4Var.getFocusOwner()).f();
                if (f == null || !f.s || !n4Var.z(i3)) {
                    Boolean e = ((hy) n4Var.getFocusOwner()).e(i3, n4Var.getEmbeddedViewFocusRect(), new j3(1, h90));
                    if (!(e != null ? e.booleanValue() : true)) {
                        if (i3 != 1) {
                            if (i3 != 2) {
                                i = 0;
                            }
                        }
                        if (i != 0) {
                            Integer c = ay.c(i3);
                            if (c != null) {
                                i2 = c.intValue();
                            }
                            FocusFinder instance = FocusFinder.getInstance();
                            View rootView = n4Var.getRootView();
                            rootView.getClass();
                            View findNextFocus = instance.findNextFocus((ViewGroup) rootView, n4Var.getView(), i2);
                            if (findNextFocus == null || findNextFocus.equals(n4Var)) {
                                return ((hy) n4Var.getFocusOwner()).g(i3);
                            }
                        }
                    }
                }
                return true;
            }
        }
        return false;
    }

    public final Object W(gm0 gm0, g4 g4Var, u91 u91) {
        long B = gm0.B(0);
        gw0 gw0 = (gw0) g4Var.a();
        gw0 = gw0 != null ? gw0.e(B) : null;
        if (gw0 != null) {
            this.t.requestRectangleOnScreen(new Rect((int) gw0.a, (int) gw0.b, (int) gw0.c, (int) gw0.d), false);
        }
        return we1.a;
    }

    public final nh0 U(oh0 oh0, hh0 hh0, long j) {
        ks0 e = hh0.e(j);
        return oh0.E(e.e, e.f, vt.e, this.s, new a4(e, 0));
    }

    public b4(n4 n4Var) {
        this.t = n4Var;
    }

    public final /* synthetic */ int G(bg0 bg0, hh0 hh0, int i) {
        return fu0.i(this, bg0, hh0, i);
    }

    public final /* synthetic */ int d(bg0 bg0, hh0 hh0, int i) {
        return fu0.d(this, bg0, hh0, i);
    }

    public final /* synthetic */ int h(bg0 bg0, hh0 hh0, int i) {
        return fu0.b(this, bg0, hh0, i);
    }

    public final /* synthetic */ int t(bg0 bg0, hh0 hh0, int i) {
        return fu0.g(this, bg0, hh0, i);
    }

    public final Object j() {
        return "androidx.compose.ui.layout.WindowInsetsRulers";
    }

    public final /* synthetic */ boolean S() {
        return false;
    }

    public final /* synthetic */ boolean T() {
        return false;
    }

    public final /* synthetic */ boolean e() {
        return true;
    }

    public final void Q(r21 r21) {
    }
}