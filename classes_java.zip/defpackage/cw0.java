package defpackage;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cw0 */
public final class cw0 extends u91 implements n00 {
    public List i;
    public List j;
    public List k;
    public ik0 l;
    public ik0 m;
    public ik0 n;
    public Set o;
    public ik0 p;
    public int q;
    public /* synthetic */ g7 r;
    public final /* synthetic */ dw0 s;

    /* JADX WARNING: Removed duplicated region for block: B:12:0x0098 A:{SKIP} */
    /* JADX WARNING: Removed duplicated region for block: B:16:0x00b9  */
    /* JADX WARNING: Removed duplicated region for block: B:12:0x0098 A:{SKIP} */
    /* JADX WARNING: Removed duplicated region for block: B:15:0x00b8  */
    /* JADX WARNING: Removed duplicated region for block: B:16:0x00b9  */
    /* JADX WARNING: Removed duplicated region for block: B:12:0x0098 A:{SKIP} */
    /* JADX WARNING: Removed duplicated region for block: B:16:0x00b9  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final Object p(Object obj) {
        g7 g7Var;
        ik0 ik0;
        ik0 ik02;
        List list;
        Set set;
        List list2;
        ik0 ik03;
        List list3;
        ik0 ik04;
        dw0 dw0;
        ik0 ik05;
        List list4;
        ik0 ik06;
        k9 k9Var;
        List list5;
        cm cmVar = cm.e;
        int i = this.q;
        ik0 ik07;
        g7 g7Var2;
        if (i == 0) {
            nb0.t(obj);
            g7Var = this.r;
            ArrayList arrayList = new ArrayList();
            ArrayList arrayList2 = new ArrayList();
            ArrayList arrayList3 = new ArrayList();
            ik0 = o01.a;
            ik0 = new ik0();
            ik0 ik08 = new ik0();
            ik0 ik09 = new ik0();
            p01 p01 = new p01(ik09);
            ik02 = new ik0();
            p01 p012 = p01;
            list = arrayList;
            set = p012;
            ik0 ik010 = ik09;
            list2 = arrayList2;
            ik03 = ik010;
            ik010 = ik08;
            list3 = arrayList3;
            ik04 = ik010;
            synchronized (this.s.c) {
            }
            dw0 = this.s;
            this.r = g7Var;
            this.i = list;
            this.j = list2;
            this.k = list3;
            this.l = ik0;
            this.m = ik04;
            this.n = ik03;
            this.o = set;
            this.p = ik02;
            this.q = 1;
            if (dw0.w(dw0, this) == cmVar) {
            }
            return cmVar;
        } else if (i == 1) {
            ik07 = this.p;
            set = this.o;
            ik03 = this.n;
            ik04 = this.m;
            ik0 = this.l;
            list3 = this.k;
            list2 = this.j;
            list = this.i;
            g7Var2 = this.r;
            nb0.t(obj);
            ik05 = ik0;
            ik0 = ik07;
            g7Var = g7Var2;
            list4 = list3;
            list3 = list;
            ik06 = ik05;
        } else if (i == 2) {
            ik07 = this.p;
            set = this.o;
            ik03 = this.n;
            ik04 = this.m;
            ik0 = this.l;
            list3 = this.k;
            list2 = this.j;
            list = this.i;
            g7Var2 = this.r;
            nb0.t(obj);
            g7 g7Var3 = g7Var2;
            ik02 = ik07;
            g7Var = g7Var3;
            dw0.x(this.s);
            k9Var = this.s.b;
            ((ca) k9Var.f).set(0);
            ((pa) k9Var.g).f(new h90(18));
            synchronized (this.s.c) {
            }
            dw0 = this.s;
            this.r = g7Var;
            this.i = list;
            this.j = list2;
            this.k = list3;
            this.l = ik0;
            this.m = ik04;
            this.n = ik03;
            this.o = set;
            this.p = ik02;
            this.q = 1;
            if (dw0.w(dw0, this) == cmVar) {
                List list6 = list;
                ik06 = ik0;
                ik0 = ik02;
                list4 = list3;
                list3 = list6;
            }
            return cmVar;
        } else {
            od.p("call to 'resume' before 'invoke' with coroutine");
            return null;
        }
        Set set2 = set;
        ik05 = ik04;
        ik04 = ik03;
        dw0 dw02 = this.s;
        d81 d81 = dw0.z;
        if (dw02.Q()) {
            bw0 bw0 = new bw0(this.s, ik04, ik0, list3, list2, ik06, list4, ik05, set2);
            this.r = g7Var;
            this.i = list3;
            this.j = list2;
            this.k = list4;
            this.l = ik06;
            this.m = ik05;
            this.n = ik04;
            this.o = set2;
            this.p = ik0;
            this.q = 2;
            if (g7Var.c(bw0, this) != cmVar) {
                list5 = list4;
                ik02 = ik0;
                ik0 = ik06;
                list = list3;
                list3 = list5;
                ik03 = ik04;
                ik04 = ik05;
                set = set2;
                dw0.x(this.s);
                k9Var = this.s.b;
                ((ca) k9Var.f).set(0);
                ((pa) k9Var.g).f(new h90(18));
                synchronized (this.s.c) {
                }
                dw0 = this.s;
                this.r = g7Var;
                this.i = list;
                this.j = list2;
                this.k = list3;
                this.l = ik0;
                this.m = ik04;
                this.n = ik03;
                this.o = set;
                this.p = ik02;
                this.q = 1;
                if (dw0.w(dw0, this) == cmVar) {
                }
            }
            return cmVar;
        }
        list5 = list4;
        ik02 = ik0;
        ik0 = ik06;
        list = list3;
        list3 = list5;
        ik03 = ik04;
        ik04 = ik05;
        set = set2;
        synchronized (this.s.c) {
        }
        dw0 = this.s;
        this.r = g7Var;
        this.i = list;
        this.j = list2;
        this.k = list3;
        this.l = ik0;
        this.m = ik04;
        this.n = ik03;
        this.o = set;
        this.p = ik02;
        this.q = 1;
        if (dw0.w(dw0, this) == cmVar) {
        }
        return cmVar;
    }

    public static final void r(dw0 dw0, List list, List list2, List list3, ik0 ik0, ik0 ik02, ik0 ik03, ik0 ik04) {
        dw0 dw02 = dw0;
        ik0 ik05 = ik0;
        ik0 ik06 = ik02;
        ik0 ik07 = ik04;
        synchronized (dw02.c) {
            try {
                int i;
                int i2;
                long j;
                long j2;
                long j3;
                long j4;
                int i3;
                list.clear();
                list2.clear();
                int size = list3.size();
                for (i = 0; i < size; i++) {
                    yj yjVar = (yj) list3.get(i);
                    yjVar.a();
                    dw02.R(yjVar);
                }
                list3.clear();
                Object[] objArr = ik05.b;
                long[] jArr = ik05.a;
                int length = jArr.length - 2;
                if (length >= 0) {
                    i2 = 0;
                    j = 255;
                    while (true) {
                        j2 = jArr[i2];
                        j3 = 7;
                        j4 = -9187201950435737472L;
                        if (((((~j2) << 7) & j2) & -9187201950435737472L) != -9187201950435737472L) {
                            i3 = 8 - ((~(i2 - length)) >>> 31);
                            for (int i4 = 0; i4 < i3; i4++) {
                                if ((j2 & 255) < 128) {
                                    yj yjVar2 = (yj) objArr[(i2 << 3) + i4];
                                    yjVar2.a();
                                    dw02.R(yjVar2);
                                }
                                j2 >>= 8;
                            }
                            if (i3 != 8) {
                                break;
                            }
                        }
                        if (i2 == length) {
                            break;
                        }
                        i2++;
                    }
                } else {
                    j3 = 7;
                    j = 255;
                    j4 = -9187201950435737472L;
                }
                ik05.b();
                Object[] objArr2 = ik06.b;
                long[] jArr2 = ik06.a;
                i = jArr2.length - 2;
                if (i >= 0) {
                    length = 0;
                    while (true) {
                        j2 = jArr2[length];
                        if (((((~j2) << j3) & j2) & j4) != j4) {
                            i2 = 8 - ((~(length - i)) >>> 31);
                            for (i3 = 0; i3 < i2; i3++) {
                                if ((j2 & j) < 128) {
                                    ((yj) objArr2[(length << 3) + i3]).g();
                                }
                                j2 >>= 8;
                            }
                            if (i2 != 8) {
                                break;
                            }
                        }
                        if (length == i) {
                            break;
                        }
                        length++;
                    }
                }
                ik06.b();
                ik03.b();
                objArr2 = ik07.b;
                long[] jArr3 = ik07.a;
                size = jArr3.length - 2;
                if (size >= 0) {
                    i = 0;
                    while (true) {
                        long j5 = jArr3[i];
                        if (((((~j5) << j3) & j5) & j4) != j4) {
                            int i5 = 8 - ((~(i - size)) >>> 31);
                            for (int i6 = 0; i6 < i5; i6++) {
                                if ((j5 & j) < 128) {
                                    yj yjVar3 = (yj) objArr2[(i << 3) + i6];
                                    yjVar3.a();
                                    dw02.R(yjVar3);
                                }
                                j5 >>= 8;
                            }
                            if (i5 != 8) {
                                break;
                            }
                        }
                        if (i == size) {
                            break;
                        }
                        i++;
                    }
                }
                ik07.b();
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public static final void s(List list, dw0 dw0) {
        list.clear();
        synchronized (dw0.c) {
            try {
                ArrayList arrayList = dw0.k;
                int size = arrayList.size();
                for (int i = 0; i < size; i++) {
                    list.add((gj0) arrayList.get(i));
                }
                dw0.k.clear();
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final Object c(Object obj, Object obj2, Object obj3) {
        bm bmVar = (bm) obj;
        g7 g7Var = (g7) obj2;
        cw0 cw0 = new cw0(this.s, (ml) obj3);
        cw0.r = g7Var;
        cw0.p(we1.a);
        return cm.e;
    }

    public cw0(dw0 dw0, ml mlVar) {
        this.s = dw0;
        super(3, mlVar);
    }
}