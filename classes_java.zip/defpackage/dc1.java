package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dc1 */
public final class dc1 implements uw {
    public final Throwable e;

    public dc1(Throwable th) {
        this.e = th;
    }

    public final Object k(Object obj, ml mlVar) {
        throw this.e;
    }
}