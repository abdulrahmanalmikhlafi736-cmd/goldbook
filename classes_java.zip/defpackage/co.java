package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: co */
public final class co implements t40 {
    public static final co a = new Object();

    public final cp a(uj0 uj0) {
        return new bo(uj0);
    }

    public final boolean equals(Object obj) {
        return obj == this;
    }

    public final int hashCode() {
        return -1;
    }
}