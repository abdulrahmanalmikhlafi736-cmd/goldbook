package defpackage;

import java.util.Arrays;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ay0 */
public final class ay0 extends gh {
    public static final od r = new h90(19);
    public final aj1 d;
    public final float e;
    public final float f;
    public final vc1 g;
    public final float[] h;
    public final float[] i;
    public final float[] j;
    public final zq k;
    public final zx0 l;
    public final wx0 m;
    public final zq n;
    public final zx0 o;
    public final wx0 p;
    public final boolean q;

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null) {
            if (ay0.class == obj.getClass()) {
                if (!super.equals(obj)) {
                    return false;
                }
                ay0 ay0 = (ay0) obj;
                if (Float.compare(ay0.e, this.e) != 0 || Float.compare(ay0.f, this.f) != 0 || !k70.p(this.d, ay0.d) || !Arrays.equals(this.h, ay0.h)) {
                    return false;
                }
                vc1 vc1 = ay0.g;
                vc1 vc12 = this.g;
                if (vc12 != null) {
                    return k70.p(vc12, vc1);
                }
                if (vc1 == null) {
                    return true;
                }
                return !k70.p(this.k, ay0.k) ? false : k70.p(this.n, ay0.n);
            }
        }
        return false;
    }

    public final int hashCode() {
        int hashCode = (Arrays.hashCode(this.h) + ((this.d.hashCode() + (super.hashCode() * 31)) * 31)) * 31;
        float f = this.e;
        int i = 0;
        hashCode = (hashCode + (f == 0.0f ? 0 : Float.floatToIntBits(f))) * 31;
        f = this.f;
        hashCode = (hashCode + (f == 0.0f ? 0 : Float.floatToIntBits(f))) * 31;
        vc1 vc1 = this.g;
        if (vc1 != null) {
            i = vc1.hashCode();
        }
        hashCode += i;
        if (vc1 != null) {
            return hashCode;
        }
        return this.n.hashCode() + ((this.k.hashCode() + (hashCode * 31)) * 31);
    }

    public final long d(float f, float f2, float f3) {
        double d = (double) f;
        wx0 wx0 = this.p;
        float c = (float) wx0.c(d);
        f2 = (float) wx0.c((double) f2);
        f = (float) wx0.c((double) f3);
        float[] fArr = this.i;
        if (fArr.length < 9) {
            return 0;
        }
        f3 = (fArr[6] * f) + ((fArr[3] * f2) + (fArr[0] * c));
        float f4 = (fArr[7] * f) + ((fArr[4] * f2) + (fArr[1] * c));
        return (((long) Float.floatToRawIntBits(f3)) << 32) | (4294967295L & ((long) Float.floatToRawIntBits(f4)));
    }

    /* JADX WARNING: Removed duplicated region for block: B:40:0x01eb  */
    /* JADX WARNING: Removed duplicated region for block: B:39:0x01e9  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public ay0(String str, float[] fArr, aj1 aj1, float[] fArr2, zq zqVar, zq zqVar2, float f, float f2, vc1 vc1, int i) {
        Object obj = fArr;
        aj1 aj12 = aj1;
        float[] fArr3 = fArr2;
        zq zqVar3 = zqVar;
        zq zqVar4 = zqVar2;
        float f3 = f;
        float f4 = f2;
        int i2 = i;
        super(str, 12884901888L, i2);
        this.d = aj12;
        this.e = f3;
        this.f = f4;
        this.g = vc1;
        this.k = zqVar3;
        this.l = new wx0(this, 1);
        this.m = new wx0(this, 0);
        this.n = zqVar4;
        this.o = new wx0(this, 0);
        this.p = new wx0(this, 1);
        if (obj.length != 6) {
            if (obj.length != 9) {
                od.m("The color space's primaries must be defined as an array of 6 floats in xyY or 9 floats in XYZ");
                throw null;
            }
        }
        if (f3 < f4) {
            float f5;
            float f6;
            float f7;
            float f8;
            float f9;
            float f10;
            float f11;
            boolean z;
            float f12;
            float f13;
            float f14;
            int length;
            float f15;
            boolean z2;
            float[] fArr4 = new float[6];
            if (obj.length == 9) {
                f5 = obj[0];
                f6 = obj[1];
                f7 = (f5 + f6) + obj[2];
                fArr4[0] = f5 / f7;
                fArr4[1] = f6 / f7;
                f5 = obj[3];
                f6 = obj[4];
                f7 = (f5 + f6) + obj[5];
                fArr4[2] = f5 / f7;
                fArr4[3] = f6 / f7;
                f5 = obj[6];
                f6 = obj[7];
                f7 = (f5 + f6) + obj[8];
                fArr4[4] = f5 / f7;
                fArr4[5] = f6 / f7;
            } else {
                System.arraycopy(obj, 0, fArr4, 0, 6);
            }
            this.h = fArr4;
            float f16;
            if (fArr3 == null) {
                f8 = fArr4[0];
                f5 = fArr4[1];
                f6 = fArr4[2];
                f7 = fArr4[3];
                f9 = fArr4[4];
                f10 = fArr4[5];
                f16 = 1.0f;
                f11 = aj12.a;
                z = true;
                f12 = aj12.b;
                f13 = 1.0f - f8;
                f14 = f13 / f5;
                float f17 = 1.0f - f6;
                float f18 = 1.0f - f9;
                float f19 = f8 / f5;
                float f20 = (f6 / f7) - f19;
                f11 = (f11 / f12) - f19;
                float f21 = (f17 / f7) - f14;
                float f22 = (f9 / f10) - f19;
                float f23 = (((((1.0f - f11) / f12) - f14) * f20) - (f11 * f21)) / ((((f18 / f10) - f14) * f20) - (f21 * f22));
                f11 = (f11 - (f22 * f23)) / f20;
                f21 = f11 / f7;
                float f24 = f23 / f10;
                f13 = (f13 - f5) * (((1.0f - f11) - f23) / f5);
                f6 *= f21;
                f17 = (f17 - f7) * f21;
                f9 *= f24;
                f18 = (f18 - f10) * f24;
                this.i = new float[]{f8 * (((1.0f - f11) - f23) / f5), (1.0f - f11) - f23, f13, f6, f11, f17, f9, f23, f18};
            } else {
                z = true;
                f16 = 1.0f;
                if (fArr3.length == 9) {
                    this.i = fArr3;
                } else {
                    length = fArr3.length;
                    StringBuilder dl1 = new dl1("Transform must have 9 entries! Has ");
                    dl1.append(length);
                    throw new dl1(dl1.toString());
                }
            }
            this.j = vn.B(this.i);
            f11 = sb0.b(fArr4);
            fArr3 = jh.a;
            if (f11 / sb0.b(jh.b) > 0.9f) {
                float[] fArr5 = jh.a;
                f12 = fArr4[0];
                float f25 = fArr5[0];
                f12 -= f25;
                f5 = fArr4[z];
                float f26 = fArr5[z];
                f5 -= f26;
                float f27 = fArr4[2];
                f6 = fArr5[2];
                f27 -= f6;
                f7 = fArr4[3];
                f9 = fArr5[3];
                f7 -= f9;
                f10 = fArr4[4];
                f13 = fArr5[4];
                f10 -= f13;
                f14 = fArr4[5];
                f11 = fArr5[5];
                f14 -= f11;
                f15 = 0.0f;
                fArr3 = new float[]{f12, f5, f27, f7, f10, f14};
                f12 = fArr3[0];
                f5 = fArr3[z];
                if (((f26 - f11) * f12) - ((f25 - f13) * f5) >= 0.0f) {
                    if (((f25 - f6) * f5) - ((f26 - f9) * f12) >= 0.0f) {
                        f12 = fArr3[2];
                        f5 = fArr3[3];
                        if (((f9 - f26) * f12) - ((f6 - f25) * f5) >= 0.0f) {
                            if (((f6 - f13) * f5) - ((f9 - f11) * f12) >= 0.0f) {
                                f12 = fArr3[4];
                                f8 = fArr3[5];
                                if (((f11 - f9) * f12) - ((f13 - f6) * f8) >= 0.0f && ((f13 - f25) * f8) - ((f11 - f26) * f12) >= 0.0f) {
                                    if (i2 == 0) {
                                        fArr5 = jh.a;
                                        if (fArr4 != fArr5) {
                                            int i3 = 0;
                                            while (i3 < 6) {
                                                if (Float.compare(fArr4[i3], fArr5[i3]) != 0 && Math.abs(fArr4[i3] - fArr5[i3]) > 0.001f) {
                                                    break;
                                                }
                                                i3++;
                                            }
                                        }
                                        if (vn.l(aj12, vd1.i)) {
                                            if (f3 == f15 && f4 == f16) {
                                                fArr5 = jh.a;
                                                ay0 ay0 = jh.e;
                                                double d = 0.0d;
                                                while (d <= 1.0d) {
                                                    if (Math.abs(zqVar3.c(d) - ay0.k.c(d)) <= 0.001d) {
                                                        if (Math.abs(zqVar4.c(d) - ay0.n.c(d)) <= 0.001d) {
                                                            d += 0.00392156862745098d;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        z2 = false;
                                        this.q = z2;
                                        return;
                                    }
                                    z2 = z;
                                    this.q = z2;
                                    return;
                                }
                            }
                        }
                    }
                }
            } else {
                f15 = 0.0f;
            }
            length = (f3 > f15 ? 1 : (f3 == f15 ? 0 : -1));
            if (i2 == 0) {
            }
            z2 = z;
            this.q = z2;
            return;
        }
        StringBuilder dl12 = new dl1("Invalid range: min=");
        dl12.append(f3);
        dl12.append(", max=");
        dl12.append(f4);
        dl12.append("; min must be strictly < max");
        throw new dl1(dl12.toString());
    }

    public final long f(float f, float f2, float f3, float f4, gh ghVar) {
        float[] fArr = this.j;
        float f5 = (fArr[6] * f3) + ((fArr[3] * f2) + (fArr[0] * f));
        float f6 = (fArr[7] * f3) + ((fArr[4] * f2) + (fArr[1] * f));
        f2 = (fArr[8] * f3) + ((fArr[5] * f2) + (fArr[2] * f));
        double d = (double) f5;
        wx0 wx0 = this.m;
        return wl1.c((float) wx0.c(d), (float) wx0.c((double) f6), (float) wx0.c((double) f2), f4, ghVar);
    }

    public final float e(float f, float f2, float f3) {
        double d = (double) f;
        wx0 wx0 = this.p;
        float c = (float) wx0.c(d);
        f2 = (float) wx0.c((double) f2);
        f = (float) wx0.c((double) f3);
        float[] fArr = this.i;
        return (fArr[8] * f) + ((fArr[5] * f2) + (fArr[2] * c));
    }

    public ay0(String str, float[] fArr, aj1 aj1, vc1 vc1, int i) {
        double d;
        yx0 yx0;
        vc1 vc12 = vc1;
        double d2 = vc12.a;
        int i2 = d2 == -3.0d ? 1 : 0;
        double d3 = vc12.g;
        double d4 = vc12.f;
        if (i2 != 0) {
            d = -3.0d;
            yx0 = new yx0(vc12, 4);
        } else {
            d = -3.0d;
            yx0 = d2 == -2.0d ? new yx0(vc12, 5) : (d4 == 0.0d && d3 == 0.0d) ? new yx0(vc12, 6) : new yx0(vc12, 7);
        }
        yx0 yx02 = d2 == d ? new yx0(vc12, 0) : d2 == -2.0d ? new yx0(vc12, 1) : (d4 == 0.0d && d3 == 0.0d) ? new yx0(vc12, 2) : new yx0(vc12, 3);
        yx0 yx03 = yx02;
        this(str, fArr, aj1, null, yx0, yx03, 0.0f, 1.0f, vc12, i);
    }

    public ay0(String str, float[] fArr, aj1 aj1, double d, float f, float f2, int i) {
        double d2 = d;
        int i2 = (d2 > 1.0d ? 1 : (d2 == 1.0d ? 0 : -1));
        od odVar = r;
        zq xx0 = i2 == 0 ? odVar : new xx0(d2, 0);
        if (i2 != 0) {
            odVar = new xx0(d2, 1);
        }
        this(str, fArr, aj1, null, xx0, odVar, f, f2, new vc1(d2, 1.0d, 0.0d, 0.0d, 0.0d), i);
    }

    public final float a(int i) {
        return this.f;
    }

    public final float b(int i) {
        return this.e;
    }

    public final boolean c() {
        return this.q;
    }
}