package defpackage;

import java.util.ArrayList;
import java.util.List;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: c01 */
public final /* synthetic */ class c01 implements m00 {
    public final /* synthetic */ int e;

    public final Object f(Object obj, Object obj2) {
        Object obj3 = obj;
        Object obj4 = null;
        int i = 0;
        int i2;
        int i3;
        iz0 iz0;
        w41 w41;
        Object a;
        Float valueOf;
        int i4;
        int i5;
        int i6;
        Object a2;
        Object a3;
        Object a4;
        Object a5;
        Object a6;
        Object a7;
        Object a8;
        al alVar;
        switch (this.e) {
            case 0:
                i2 = 1;
                i3 = 0;
                iz0 = (iz0) obj3;
                w41 = (w41) obj2;
                a = e01.a(new ad(w41.a), e01.p, iz0);
                obj3 = e01.a(new ad(w41.b), e01.x, iz0);
                valueOf = Float.valueOf(w41.c);
                return zi1.m(a, obj3, valueOf);
            case 1:
                iz0 = (iz0) obj3;
                return Integer.valueOf(((na1) obj2).a);
            case 2:
                iz0 = (iz0) obj3;
                return Integer.valueOf(((sa1) obj2).a);
            case 3:
                iz0 = (iz0) obj3;
                return Integer.valueOf(((o30) obj2).a);
            case gu0.LONG_FIELD_NUMBER /*4*/:
                iz0 = (iz0) obj3;
                return Integer.valueOf(((nz) obj2).a);
            case gu0.STRING_FIELD_NUMBER /*5*/:
                iz0 = (iz0) obj3;
                return Integer.valueOf(((oz) obj2).a);
            case gu0.STRING_SET_FIELD_NUMBER /*6*/:
                i2 = 1;
                iz0 = (iz0) obj3;
                qb1 qb1 = (qb1) obj2;
                if (qb1 == null ? false : d90.a(qb1.a, qb1.c)) {
                    obj3 = Boolean.FALSE;
                } else {
                    Float valueOf2 = Float.valueOf(qb1.c(qb1.a));
                    obj3 = e01.a(new ad(qb1.b(qb1.a)), e01.w, iz0);
                    obj3 = zi1.m(valueOf2, obj3);
                }
                return obj3;
            case gu0.DOUBLE_FIELD_NUMBER /*7*/:
                i2 = 1;
                i3 = 0;
                iz0 = (iz0) obj3;
                le0 le0 = (le0) obj2;
                String str = le0.a;
                obj3 = e01.a(le0.b, e01.i, iz0);
                return zi1.m(str, obj3);
            case 8:
                i2 = 1;
                i3 = 0;
                iz0 = (iz0) obj3;
                long j = ((rb1) obj2).a;
                obj3 = d90.a(j, 8589934592L) ? Integer.valueOf(i3) : d90.a(j, 4294967296L) ? Integer.valueOf(i2) : Boolean.FALSE;
                return obj3;
            case 9:
                i4 = 2;
                i2 = 1;
                i3 = 0;
                iz0 = (iz0) obj3;
                xm0 xm0 = (xm0) obj2;
                if ((xm0 == null ? i3 : n60.b(xm0.a, 9205357640488583168L)) != null) {
                    obj3 = Boolean.FALSE;
                } else {
                    valueOf = Float.valueOf(Float.intBitsToFloat((int) (xm0.a >> 32)));
                    Float valueOf3 = Float.valueOf(Float.intBitsToFloat((int) (xm0.a & 4294967295L)));
                    Float[] fArr = new Float[i4];
                    fArr[i3] = valueOf;
                    fArr[i2] = valueOf3;
                    obj3 = zi1.m(fArr);
                }
                return obj3;
            case 10:
                Enum enumR;
                String a9;
                i5 = 4;
                i4 = 2;
                i2 = 1;
                i3 = 0;
                iz0 = (iz0) obj3;
                w8 w8Var = (w8) obj2;
                a = w8Var.a;
                if (a instanceof fq0) {
                    enumR = z8.e;
                } else if (a instanceof i71) {
                    enumR = z8.f;
                } else if (a instanceof jg1) {
                    enumR = z8.g;
                } else if (a instanceof of1) {
                    enumR = z8.h;
                } else if (a instanceof me0) {
                    enumR = z8.i;
                } else if (a instanceof le0) {
                    enumR = z8.j;
                } else if (a instanceof n81) {
                    enumR = z8.k;
                } else {
                    throw new UnsupportedOperationException();
                }
                switch (enumR.ordinal()) {
                    case 0:
                        a.getClass();
                        a9 = e01.a((fq0) a, e01.g, iz0);
                        break;
                    case 1:
                        a.getClass();
                        a9 = e01.a((i71) a, e01.h, iz0);
                        break;
                    case 2:
                        a.getClass();
                        a9 = e01.a((jg1) a, e01.c, iz0);
                        break;
                    case 3:
                        a.getClass();
                        a9 = e01.a((of1) a, e01.d, iz0);
                        break;
                    case gu0.LONG_FIELD_NUMBER /*4*/:
                        a.getClass();
                        a9 = e01.a((me0) a, e01.e, iz0);
                        break;
                    case gu0.STRING_FIELD_NUMBER /*5*/:
                        a.getClass();
                        a9 = e01.a((le0) a, e01.f, iz0);
                        break;
                    case gu0.STRING_SET_FIELD_NUMBER /*6*/:
                        a.getClass();
                        a9 = ((n81) a).a;
                        break;
                    default:
                        od.k();
                        break;
                }
                Integer valueOf4 = Integer.valueOf(w8Var.b);
                Integer valueOf5 = Integer.valueOf(w8Var.c);
                String str2 = w8Var.d;
                obj4 = zi1.m(enumR, a9, valueOf4, valueOf5, str2);
                return obj4;
            case 11:
                i3 = 0;
                iz0 = (iz0) obj3;
                List list = ((if0) obj2).e;
                ArrayList h90 = new h90(list.size());
                int size = list.size();
                while (i < size) {
                    h90.add(e01.a((hf0) list.get(i), e01.z, iz0));
                    i++;
                }
                return h90;
            case 12:
                iz0 = (iz0) obj3;
                return ((hf0) obj2).a.toLanguageTag();
            case 13:
                i6 = 3;
                i4 = 2;
                i2 = 1;
                i3 = 0;
                iz0 = (iz0) obj3;
                he0 he0 = (he0) obj2;
                a = e01.a(new br0(he0.a), e01.B, iz0);
                a2 = e01.a(new h90(he0.b), e01.C, iz0);
                obj3 = e01.a(new h90(he0.c), e01.D, iz0);
                Object[] objArr = new Object[i6];
                objArr[i3] = a;
                objArr[i2] = a2;
                objArr[i4] = obj3;
                return zi1.m(objArr);
            case 14:
                iz0 = (iz0) obj3;
                return Float.valueOf(((ee0) obj2).a);
            case 15:
                iz0 = (iz0) obj3;
                return Integer.valueOf(((ge0) obj2).a);
            case 16:
                iz0 = (iz0) obj3;
                return Integer.valueOf(((fe0) obj2).a);
            case 17:
                iz0 = (iz0) obj3;
                return ((jg1) obj2).a;
            case 18:
                i5 = 4;
                i6 = 3;
                i4 = 2;
                i2 = 1;
                i3 = 0;
                iz0 = (iz0) obj3;
                fq0 fq0 = (fq0) obj2;
                a2 = e01.a(new h90(fq0.a), e01.q, iz0);
                a3 = e01.a(new h90(fq0.b), e01.r, iz0);
                a4 = e01.a(new ad(fq0.c), e01.v, iz0);
                wa1 wa1 = fq0.d;
                wa1 wa12 = wa1.c;
                a5 = e01.a(wa1, e01.l, iz0);
                obj4 = e01.a(fq0.e, vd1.m, iz0);
                he0 he02 = fq0.f;
                he0 he03 = he0.d;
                a6 = e01.a(he02, e01.A, iz0);
                a7 = e01.a(new h90(fq0.g), vd1.o, iz0);
                a8 = e01.a(new h90(fq0.h), e01.s, iz0);
                obj3 = e01.a(fq0.i, vd1.p, iz0);
                return zi1.m(a2, a3, a4, a5, obj4, a6, a7, a8, obj3);
            case 19:
                iz0 = (iz0) obj3;
                return ((of1) obj2).a;
            case 20:
                iz0 = (iz0) obj3;
                i71 i71 = (i71) obj2;
                zg adVar = new ad(i71.a.b());
                d01 d01 = e01.p;
                obj4 = e01.a(adVar, d01, iz0);
                qb1 adVar2 = new ad(i71.b);
                d01 d012 = e01.v;
                a2 = e01.a(adVar2, d012, iz0);
                pz pzVar = i71.c;
                pz pzVar2 = pz.f;
                a3 = e01.a(pzVar, e01.m, iz0);
                a4 = e01.a(i71.d, e01.t, iz0);
                i5 = 4;
                a6 = e01.a(i71.e, e01.u, iz0);
                Integer valueOf6 = Integer.valueOf(-1);
                i2 = 1;
                i4 = 2;
                String str3 = i71.g;
                i3 = 0;
                a8 = e01.a(new ad(i71.h), d012, iz0);
                Object a10 = e01.a(i71.i, e01.n, iz0);
                Object a11 = e01.a(i71.j, e01.k, iz0);
                if0 if0 = i71.k;
                if0 if02 = if0.g;
                a5 = e01.a(if0, e01.y, iz0);
                obj2 = a8;
                i6 = 3;
                a7 = e01.a(new ad(i71.l), d01, iz0);
                a8 = e01.a(i71.m, e01.j, iz0);
                w41 = i71.n;
                w41 w412 = w41.d;
                obj3 = e01.a(w41, e01.o, iz0);
                return zi1.m(obj4, a2, a3, a4, a6, valueOf6, str3, obj2, a10, a11, a5, a7, a8, obj3);
            case 21:
                iz0 = (iz0) obj3;
                eb1 eb1 = (eb1) obj2;
                i71 i712 = eb1.a;
                alVar = e01.h;
                a = e01.a(i712, alVar, iz0);
                a3 = e01.a(eb1.b, alVar, iz0);
                a4 = e01.a(eb1.c, alVar, iz0);
                obj3 = e01.a(eb1.d, alVar, iz0);
                return zi1.m(a, a3, a4, obj3);
            case 22:
                iz0 = (iz0) obj3;
                ss0 ss0 = (ss0) obj2;
                Boolean valueOf7 = Boolean.valueOf(ss0.a);
                alVar = e01.a;
                obj3 = e01.a(new h90(ss0.b), vd1.n, iz0);
                return zi1.m(valueOf7, obj3);
            case 23:
                iz0 = (iz0) obj3;
                return Integer.valueOf(((ot) obj2).a);
            case 24:
                iz0 = (iz0) obj3;
                return Integer.valueOf(((ce0) obj2).a);
            case 25:
                gb1 gb1 = (gb1) obj2;
                obj3 = e01.a(new h90(gb1.a), vd1.q, (iz0) obj3);
                Boolean valueOf8 = Boolean.valueOf(gb1.b);
                return zi1.m(obj3, valueOf8);
            case 26:
                iz0 = (iz0) obj3;
                return Integer.valueOf(((fb1) obj2).a);
            case 27:
                iz0 = (iz0) obj3;
                return Integer.valueOf(((c11) obj2).a.g());
            case 28:
                ql qlVar = (ql) obj2;
                if (qlVar instanceof uc1) {
                    Integer num;
                    if (obj3 instanceof Integer) {
                        num = (Integer) obj3;
                    }
                    int intValue = num != null ? num.intValue() : 1;
                    obj3 = intValue == 0 ? qlVar : Integer.valueOf(intValue + 1);
                }
                return obj3;
            default:
                uc1 uc1 = (uc1) obj3;
                ql qlVar2 = (ql) obj2;
                if (qlVar2 instanceof uc1) {
                    obj4 = (uc1) qlVar2;
                }
                return obj4;
        }
    }

    public /* synthetic */ c01(int i) {
        this.e = i;
    }
}