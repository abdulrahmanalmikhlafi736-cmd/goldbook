package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: a60 */
public final class a60 implements z50 {
    public final lq0 a;

    public a60(int i) {
        this.a = mc0.t(new h90(i));
    }
}