package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cf */
public final class cf extends u91 implements m00 {
    public final /* synthetic */ int i = 0;
    public int j;
    public /* synthetic */ Object k;
    public final /* synthetic */ ff l;
    public final /* synthetic */ uw m;

    public final Object p(Object obj) {
        int i = this.i;
        Object obj2 = we1.a;
        String str = "call to 'resume' before 'invoke' with coroutine";
        cm cmVar = cm.e;
        switch (i) {
            case 0:
                i = this.j;
                if (i == 0) {
                    nb0.t(obj);
                    n00 n00 = this.l.i;
                    Object obj3 = this.k;
                    this.j = 1;
                    if (n00.c(this.m, obj3, this) == cmVar) {
                        obj2 = cmVar;
                    }
                } else if (i == 1) {
                    nb0.t(obj);
                } else {
                    od.p(str);
                    obj2 = null;
                }
                return obj2;
            default:
                i = this.j;
                if (i == 0) {
                    nb0.t(obj);
                    bm bmVar = (bm) this.k;
                    nw0 obj4 = new Object();
                    ff ffVar = this.l;
                    tw twVar = ffVar.h;
                    ef efVar = new ef(obj4, bmVar, ffVar, this.m, 0);
                    this.j = 1;
                    if (twVar.b(efVar, this) == cmVar) {
                        obj2 = cmVar;
                    }
                } else if (i == 1) {
                    nb0.t(obj);
                } else {
                    od.p(str);
                    obj2 = null;
                }
                return obj2;
        }
    }

    public final Object f(Object obj, Object obj2) {
        int i = this.i;
        we1 we1 = we1.a;
        bm bmVar = (bm) obj;
        ml mlVar = (ml) obj2;
        switch (i) {
            case 0:
                return ((cf) n(mlVar, bmVar)).p(we1);
            default:
                return ((cf) n(mlVar, bmVar)).p(we1);
        }
    }

    public final ml n(ml mlVar, Object obj) {
        int i = this.i;
        uw uwVar = this.m;
        ff ffVar = this.l;
        switch (i) {
            case 0:
                return new cf(ffVar, uwVar, this.k, mlVar);
            default:
                this = new cf(ffVar, uwVar, mlVar);
                this.k = obj;
                return this;
        }
    }

    public cf(ff ffVar, uw uwVar, Object obj, ml mlVar) {
        this.l = ffVar;
        this.m = uwVar;
        this.k = obj;
        super(2, mlVar);
    }

    public cf(ff ffVar, uw uwVar, ml mlVar) {
        this.l = ffVar;
        this.m = uwVar;
        super(2, mlVar);
    }
}