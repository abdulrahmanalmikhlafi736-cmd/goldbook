package defpackage;

import android.view.WindowInsets;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: yj1 */
public class yj1 extends xj1 {
    public c60 t = null;
    public c60 u = null;
    public c60 v = null;

    public c60 k() {
        if (this.u == null) {
            this.u = c60.c(this.c.getMandatorySystemGestureInsets());
        }
        return this.u;
    }

    public c60 m() {
        if (this.t == null) {
            this.t = c60.c(this.c.getSystemGestureInsets());
        }
        return this.t;
    }

    public c60 o() {
        if (this.v == null) {
            this.v = c60.c(this.c.getTappableElementInsets());
        }
        return this.v;
    }

    public hk1 r(int i, int i2, int i3, int i4) {
        return hk1.c(null, this.c.inset(i, i2, i3, i4));
    }

    public yj1(hk1 hk1, WindowInsets windowInsets) {
        super(hk1, windowInsets);
    }

    public yj1(hk1 hk1, yj1 yj1) {
        super(hk1, (xj1) yj1);
    }

    public void z(c60 c60) {
    }
}