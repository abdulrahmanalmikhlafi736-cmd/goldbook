package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: b51 */
public abstract class b51 {
    public static final oy0 a = py0.a(48.0f);
    public static final oy0 b = py0.a(28.0f);
    public static final oy0 c = py0.a(32.0f);
    public static final oy0 d = py0.a(4.0f);
    public static final oy0 e = py0.a(16.0f);
    public static final oy0 f = py0.a(20.0f);
    public static final oy0 g = py0.a(12.0f);
    public static final oy0 h = py0.a(8.0f);
    public static final cr i = new br0(0.0f);

    static {
        cr br0 = new br0(48.0f);
        cr br02 = new br0(28.0f);
        br02 = new br0(32.0f);
        br02 = new br0(4.0f);
        br02 = new br0(16.0f);
        br02 = new br0(20.0f);
        br02 = new br0(12.0f);
        br02 = new br0(8.0f);
    }
}