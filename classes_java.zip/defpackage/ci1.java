package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ci1 */
public final class ci1 {
    public final int a;
    public final String b;
    public final boolean c;

    public final String toString() {
        StringBuilder dl1 = new dl1("WebViewError(code=");
        dl1.append(this.a);
        dl1.append(", description=");
        dl1.append(this.b);
        dl1.append(", isFromMainFrame=");
        dl1.append(this.c);
        dl1.append(")");
        return dl1.toString();
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof ci1)) {
            return false;
        }
        ci1 ci1 = (ci1) obj;
        return this.a == ci1.a && k70.p(this.b, ci1.b) && this.c == ci1.c;
    }

    public final int hashCode() {
        return ((this.b.hashCode() + (this.a * 31)) * 31) + (this.c ? 1231 : 1237);
    }

    public ci1(int i, String str, boolean z) {
        str.getClass();
        this.a = i;
        this.b = str;
        this.c = z;
    }
}