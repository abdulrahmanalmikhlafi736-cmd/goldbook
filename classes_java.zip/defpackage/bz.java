package defpackage;

import android.graphics.Typeface;
import android.text.TextPaint;
import android.text.style.MetricAffectingSpan;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bz */
public final class bz extends MetricAffectingSpan {
    public final /* synthetic */ int e;
    public final Object f;

    public final void updateDrawState(TextPaint textPaint) {
        int i = this.e;
        Object obj = this.f;
        switch (i) {
            case 0:
                textPaint.setFontFeatureSettings((String) obj);
                return;
            default:
                textPaint.setTypeface((Typeface) obj);
                return;
        }
    }

    public final void updateMeasureState(TextPaint textPaint) {
        int i = this.e;
        Object obj = this.f;
        switch (i) {
            case 0:
                textPaint.setFontFeatureSettings((String) obj);
                return;
            default:
                textPaint.setTypeface((Typeface) obj);
                return;
        }
    }

    public /* synthetic */ bz(int i, Object obj) {
        this.e = i;
        this.f = obj;
    }
}