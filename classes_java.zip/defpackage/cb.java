package defpackage;

import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.autofill.AutofillManager;
import java.util.List;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cb */
public final class cb extends li0 implements t90, ds, g21, gt0, oi0, mq0, l90, q10, ky, mp0, nd {
    public ki0 s;

    /* JADX WARNING: Removed duplicated region for block: B:85:0x0116 A:{LOOP_END, LOOP:6: B:84:0x0114->B:85:0x0116} */
    /* JADX WARNING: Removed duplicated region for block: B:35:0x007d  */
    /* JADX WARNING: Removed duplicated region for block: B:63:0x00c5  */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x0050  */
    /* JADX WARNING: Removed duplicated region for block: B:35:0x007d  */
    /* JADX WARNING: Removed duplicated region for block: B:63:0x00c5  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void x(zs0 zs0, at0 at0, long j) {
        int i;
        boolean z;
        it0 it0;
        it0 it02;
        at0 at02;
        ki0 ki0 = this.s;
        ki0.getClass();
        p3 p3Var = ((jt0) ki0).d;
        jt0 jt0 = (jt0) p3Var.h;
        List list = zs0.a;
        int size = list.size();
        int i2 = 0;
        for (i = 0; i < size; i++) {
            dt0 dt0 = (dt0) list.get(i);
            if (nb0.g(dt0) || nb0.h(dt0)) {
                size = 0;
                break;
            }
        }
        size = true;
        if (size != 0) {
            i = list.size();
            int i3 = 0;
            while (i3 < i) {
                if (!((dt0) list.get(i3)).b()) {
                    i3++;
                }
            }
            z = true;
            if (!jt0.c) {
                i3 = list.size();
                int i4 = 0;
                while (i4 < i3) {
                    dt0 dt02 = (dt0) list.get(i4);
                    if (nb0.g(dt02)) {
                        break;
                    } else if (nb0.h(dt02)) {
                        break;
                    } else {
                        i4++;
                    }
                }
                if (!z) {
                    i = 0;
                    it0 = (it0) p3Var.f;
                    it02 = it0.g;
                    at02 = at0.g;
                    if (it0 != it02) {
                        if (at0 == at0.e && r2 != 0) {
                            boolean z2;
                            p3Var.g = zs0;
                            if (size != 0) {
                                if (!jt0.c) {
                                    z2 = false;
                                    p3Var.l(zs0, z2);
                                }
                            }
                            z2 = true;
                            p3Var.l(zs0, z2);
                        }
                        if (at0 == at0.f && size != 0) {
                            if (zs0 == ((zs0) p3Var.g)) {
                                if (jt0.c) {
                                    i3 = list.size();
                                    for (i4 = 0; i4 < i3; i4++) {
                                        ((dt0) list.get(i4)).a();
                                    }
                                }
                            }
                        }
                        if (at0 == at02 && r2 == 0 && zs0 != ((zs0) p3Var.g)) {
                            p3Var.l(zs0, true);
                        }
                    }
                    if (at0 == at02) {
                        int size2 = list.size();
                        for (i = 0; i < size2; i++) {
                            if (!nb0.h((dt0) list.get(i))) {
                                break;
                            }
                        }
                        p3Var.f = it0.e;
                        ((jt0) p3Var.h).c = false;
                        p3Var.g = null;
                        if (zs0 == ((zs0) p3Var.g)) {
                            if (size != 0) {
                                int size3;
                                size2 = list.size();
                                size = 0;
                                while (size < size2) {
                                    if (((dt0) list.get(size)).b()) {
                                        if (!jt0.c) {
                                            p3Var.q(zs0);
                                            return;
                                        }
                                        size3 = list.size();
                                        while (i2 < size3) {
                                            ((dt0) list.get(i2)).a();
                                            i2++;
                                        }
                                    } else {
                                        size++;
                                    }
                                }
                                size3 = list.size();
                                while (i2 < size3) {
                                }
                            }
                        }
                    }
                }
            }
            i = true;
            it0 = (it0) p3Var.f;
            it02 = it0.g;
            at02 = at0.g;
            if (it0 != it02) {
            }
            if (at0 == at02) {
            }
        }
        z = false;
        if (!jt0.c) {
        }
        i = true;
        it0 = (it0) p3Var.f;
        it02 = it0.g;
        at02 = at0.g;
        if (it0 != it02) {
        }
        if (at0 == at02) {
        }
    }

    public final void Q(r21 r21) {
        ki0 ki0 = this.s;
        ki0.getClass();
        d21 c = ((e21) ki0).c();
        r21.getClass();
        d21 d21 = (d21) r21;
        hk0 hk0 = d21.e;
        if (c.g) {
            d21.g = true;
        }
        if (c.h) {
            d21.h = true;
        }
        hk0 hk02 = c.e;
        Object[] objArr = hk02.b;
        Object[] objArr2 = hk02.c;
        long[] jArr = hk02.a;
        int length = jArr.length - 2;
        if (length >= 0) {
            int i = 0;
            while (true) {
                long j = jArr[i];
                if (((((~j) << 7) & j) & -9187201950435737472L) != -9187201950435737472L) {
                    int i2 = 8 - ((~(i - length)) >>> 31);
                    for (int i3 = 0; i3 < i2; i3++) {
                        if ((255 & j) < 128) {
                            int i4 = (i << 3) + i3;
                            Object obj = objArr[i4];
                            Object obj2 = objArr2[i4];
                            q21 q21 = (q21) obj;
                            if (hk0.b(q21) == null) {
                                hk0.m(q21, obj2);
                            } else if (obj2 instanceof o0) {
                                AutofillManager g = ((AutofillManager) hk0);
                                g.getClass();
                                o0 o0Var = (o0) g;
                                String str = o0Var.a;
                                if (str == null) {
                                    str = ((o0) obj2).a;
                                }
                                u00 u00 = o0Var.b;
                                if (u00 == null) {
                                    u00 = ((o0) obj2).b;
                                }
                                hk0.m(q21, new o0(str, u00));
                            }
                        }
                        j >>= 8;
                    }
                    if (i2 != 8) {
                        return;
                    }
                }
                if (i != length) {
                    i++;
                } else {
                    return;
                }
            }
        }
    }

    public final void r0(boolean z) {
        if (!this.r) {
            a5.b("initializeModifier called on unattached node");
        }
        ki0 ki0 = this.s;
        if (!((this.g & 4) == 0 || z)) {
            k70.M(this, 2).F0();
        }
        if ((this.g & 2) != 0) {
            ha1 ha1 = k70.O(this).J.e;
            ha1.getClass();
            if (ha1.s) {
                gm0 gm0 = this.l;
                gm0.getClass();
                ((v90) gm0).W0(this);
                kp0 kp0 = gm0.P;
                if (kp0 != null) {
                    ((l20) kp0).c();
                }
            }
            if (!z) {
                k70.M(this, 2).F0();
                k70.O(this).E();
            }
        }
        if (ki0 instanceof qc0) {
            ((qc0) ki0).a.k = k70.O(this);
        }
        int i = this.g;
        if ((i & 16) != 0 && (ki0 instanceof jt0)) {
            ((jt0) ki0).d.e = this.l;
        }
        if ((i & 8) != 0) {
            ((n4) k70.P(this)).E();
        }
    }

    public final void R() {
        ki0 ki0 = this.s;
        ki0.getClass();
        p3 p3Var = ((jt0) ki0).d;
        jt0 jt0 = (jt0) p3Var.h;
        if (((it0) p3Var.f) == it0.f) {
            long uptimeMillis = SystemClock.uptimeMillis();
            MotionEvent obtain = MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0);
            obtain.setSource(0);
            ((l7) jt0.e()).i(obtain);
            obtain.recycle();
            p3Var.f = it0.e;
            jt0.c = false;
            p3Var.g = null;
        }
    }

    public final void j0() {
        if (!this.r) {
            a5.b("unInitializeModifier called on unattached node");
        }
        if ((this.g & 8) != 0) {
            ((n4) k70.P(this)).E();
        }
    }

    public final void H(iy iyVar) {
        ki0 ki0 = this.s;
        a5.b("applyFocusProperties called on wrong node");
        ki0.getClass();
        throw new ClassCastException();
    }

    public final void s0() {
        ki0 ki0 = this.s;
        a5.b("onFocusEvent called on wrong node");
        ki0.getClass();
        throw new ClassCastException();
    }

    public final boolean J() {
        ki0 ki0 = this.s;
        ki0.getClass();
        ((jt0) ki0).d.getClass();
        return true;
    }

    public final void a0() {
        ki0 ki0 = this.s;
        ki0.getClass();
        ((jt0) ki0).d.getClass();
    }

    public final long b() {
        return wl1.M(k70.M(this, 128).g);
    }

    public final int G(bg0 bg0, hh0 hh0, int i) {
        this.s.getClass();
        throw new ClassCastException();
    }

    public final nh0 U(oh0 oh0, hh0 hh0, long j) {
        this.s.getClass();
        throw new ClassCastException();
    }

    public final Object Y(Object obj) {
        this.s.getClass();
        throw new ClassCastException();
    }

    public final int d(bg0 bg0, hh0 hh0, int i) {
        this.s.getClass();
        throw new ClassCastException();
    }

    public final int h(bg0 bg0, hh0 hh0, int i) {
        this.s.getClass();
        throw new ClassCastException();
    }

    public final void o(gm0 gm0) {
        this.s.getClass();
        throw new ClassCastException();
    }

    public final int t(bg0 bg0, hh0 hh0, int i) {
        this.s.getClass();
        throw new ClassCastException();
    }

    public final void i0() {
        if (this.s instanceof jt0) {
            R();
        }
    }

    public final void C(da0 da0) {
        ki0 ki0 = this.s;
        ki0.getClass();
        q40 q40 = (q40) ki0;
        throw null;
    }

    public final jp a() {
        return k70.O(this).C;
    }

    public final o90 getLayoutDirection() {
        return k70.O(this).D;
    }

    public final String toString() {
        return this.s.toString();
    }

    public final void h0() {
        r0(true);
    }

    public final void L() {
        R();
    }

    public final void Z() {
        a5.x(this);
    }

    public final e3 f() {
        return e3.K;
    }

    public final long l() {
        return zi1.y;
    }

    public final boolean r() {
        return this.r;
    }

    public final /* synthetic */ boolean S() {
        return false;
    }

    public final /* synthetic */ boolean T() {
        return false;
    }

    public final /* synthetic */ boolean e() {
        return true;
    }

    public final void i(n90 n90) {
    }

    public final void m(long j) {
    }
}