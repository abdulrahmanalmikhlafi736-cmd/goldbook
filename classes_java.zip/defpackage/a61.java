package defpackage;

import androidx.core.content.FileProvider;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: a61 */
public final class a61 {
    public final x51 a;
    public int[] b;
    public Object[] c;
    public ArrayList d;
    public HashMap e;
    public sj0 f;
    public int g;
    public int h;
    public int i;
    public int j;
    public int k;
    public int l;
    public int m;
    public int n;
    public int o;
    public final w60 p = new w60();
    public final w60 q = new w60();
    public final w60 r = new w60();
    public sj0 s;
    public int t;
    public int u;
    public int v;
    public boolean w;
    public rj0 x;

    public final void n(int i, m00 m00) {
        int i2 = i;
        m00 m002 = m00;
        int E = E(this.b, i2);
        int p = p();
        int u = u(i) + i2;
        tj0 tj0 = null;
        int i3 = i2;
        rj0 rj0 = null;
        loop0:
        while (i3 < u) {
            int i4;
            int u2;
            int i5;
            int i6;
            int i7;
            int f = f(i3);
            int i8 = i3 + 1;
            int f2 = f(i8);
            while (f < f2) {
                Object obj = this.c[h(f)];
                if (obj instanceof xw0) {
                    i4 = ((xw0) obj).b;
                    if (i4 >= 0) {
                        int[] iArr;
                        u2 = u(i3) + i3;
                        i5 = i8;
                        i6 = 0;
                        while (i5 < u2 && i6 < i4) {
                            int r = r(i5);
                            i7 = E;
                            iArr = this.b;
                            r *= 5;
                            i5 = iArr[r + 3] + i5;
                            if (i5 < u2) {
                                if ((iArr[r + 1] & 536870912) == 0) {
                                    i6++;
                                }
                            }
                            E = i7;
                        }
                        i7 = E;
                        if (tj0 == null) {
                            iArr = u60.a;
                            tj0 = new tj0();
                        }
                        if (rj0 == null) {
                            rj0 = new rj0();
                        }
                        tj0.a(i5);
                        rj0.a(i5);
                        rj0.a(f);
                        f++;
                        E = i7;
                    }
                }
                i7 = E;
                m002.f(Integer.valueOf(f), obj);
                f++;
                E = i7;
            }
            i7 = E;
            E = i8 < p ? E(this.b, i8) : -1;
            if (E != i3) {
                f = i3;
                i3 = i7;
                while (true) {
                    if (rj0 != null && tj0 != null && tj0.e(f)) {
                        int i9;
                        f2 = rj0.b;
                        u2 = f2 / 2;
                        i4 = 0;
                        i5 = 0;
                        while (i4 < u2) {
                            i6 = i4 * 2;
                            i7 = p;
                            p = rj0.b(i6);
                            if (p == f) {
                                p = rj0.b(i6 + 1);
                                m002.f(Integer.valueOf(p), this.c[h(p)]);
                            } else if (i6 != i5) {
                                i9 = i5 + 1;
                                rj0.e(i5, p);
                                i5 += 2;
                                rj0.e(i9, rj0.b(i6 + 1));
                            } else {
                                i5 += 2;
                            }
                            i4++;
                            m002 = m00;
                            p = i7;
                        }
                        i7 = p;
                        if (i5 != f2) {
                            if (i5 < 0) {
                                break loop0;
                            }
                            i9 = rj0.b;
                            if (i5 > i9 || f2 < 0 || f2 > i9) {
                                break loop0;
                            } else if (f2 < i5) {
                                od.m("The end index must be < start index");
                                return;
                            } else if (f2 != i5) {
                                if (f2 < i9) {
                                    int[] iArr2 = rj0.a;
                                    ba.W(iArr2, iArr2, i5, f2, i9);
                                }
                                rj0.b -= f2 - i5;
                            }
                        }
                    } else {
                        i7 = p;
                    }
                    if (f == i2 || i3 == E) {
                        break;
                    }
                    f = i3;
                    p = i7;
                    i3 = E(this.b, i3);
                    m002 = m00;
                }
                od.f("Index must be between 0 and size");
                return;
            }
            i7 = p;
            m002 = m00;
            i3 = i8;
            p = i7;
        }
    }

    public final void j() {
        int i = 0;
        int i2 = this.n > 0 ? 1 : 0;
        int i3 = this.t;
        int i4 = this.u;
        int i5 = this.v;
        int r = r(i5);
        int i6 = this.o;
        int i7 = i3 - i5;
        int i8 = r * 5;
        int i9 = i8 + 1;
        int i10 = (this.b[i9] & 1073741824) != 0 ? 1 : 0;
        w60 w60 = this.r;
        int[] iArr;
        if (i2 != 0) {
            sj0 sj0 = this.s;
            if (sj0 != null) {
                ak0 ak0 = (ak0) sj0.b(i5);
                if (ak0 != null) {
                    Object[] objArr = ak0.a;
                    i3 = ak0.b;
                    for (i9 = 0; i9 < i3; i9++) {
                        F(objArr[i9]);
                    }
                    ak0 ak02 = (ak0) sj0.g(i5);
                }
            }
            iArr = this.b;
            iArr[i8 + 3] = i7;
            z51.c(iArr, r, i6);
            i2 = w60.b();
            if (i10 != 0) {
                i6 = 1;
            }
            this.o = i2 + i6;
            i2 = E(this.b, i5);
            this.v = i2;
            i2 = i2 < 0 ? p() : r(i2 + 1);
            if (i2 >= 0) {
                i = g(this.b, i2);
            }
            this.i = i;
            this.j = i;
            return;
        }
        if (i3 != i4) {
            FileProvider.a("Expected to be at the end of a group");
        }
        iArr = this.b;
        i8 += 3;
        i3 = iArr[i8];
        i4 = iArr[i9] & 67108863;
        iArr[i8] = i7;
        z51.c(iArr, r, i6);
        i2 = this.p.b();
        this.u = (o() - this.h) - this.q.b();
        this.v = i2;
        i5 = E(this.b, i5);
        r = w60.b();
        this.o = r;
        if (i5 == i2) {
            if (i10 == 0) {
                i = i6 - i4;
            }
            this.o = r + i;
            return;
        }
        i7 -= i3;
        i6 = i10 != 0 ? 0 : i6 - i4;
        if (!(i7 == 0 && i6 == 0)) {
            while (i5 != 0 && i5 != i2 && (i6 != 0 || i7 != 0)) {
                int[] iArr2;
                i3 = r(i5);
                if (i7 != 0) {
                    iArr2 = this.b;
                    r = (i3 * 5) + 3;
                    iArr2[r] = iArr2[r] + i7;
                }
                if (i6 != 0) {
                    iArr2 = this.b;
                    z51.c(iArr2, i3, (iArr2[(i3 * 5) + 1] & 67108863) + i6);
                }
                iArr2 = this.b;
                if ((iArr2[(i3 * 5) + 1] & 1073741824) != 0) {
                    i6 = 0;
                }
                i5 = E(iArr2, i5);
            }
        }
        this.o += i6;
    }

    public final void Q(int i, Object obj, boolean z, Object obj2) {
        int i2 = this.v;
        int i3 = this.n > 0 ? 1 : 0;
        this.r.c(this.o);
        nq0 nq0 = oj.a;
        int i4;
        if (i3 != 0) {
            i3 = this.t;
            int g = g(this.b, r(i3));
            w(1);
            this.i = g;
            this.j = g;
            int r = r(i3);
            int i5 = obj != nq0 ? 1 : 0;
            int i6 = (z || obj2 == nq0) ? 0 : 1;
            g = a61.i(g, this.k, this.l, this.c.length);
            if (g >= 0 && this.m < i3) {
                g = -(((this.c.length - this.l) - g) + 1);
            }
            int[] iArr = this.b;
            int i7 = this.v;
            r *= 5;
            iArr[r] = i;
            iArr[r + 1] = ((z << 30) | (i5 << 29)) | (i6 << 28);
            iArr[r + 2] = i7;
            iArr[r + 3] = 0;
            iArr[r + 4] = g;
            i = (z + i5) + i6;
            if (i > 0) {
                int i8;
                x(i, i3);
                Object[] objArr = this.c;
                int i9 = this.i;
                if (z) {
                    i8 = i9 + 1;
                    objArr[i9] = obj2;
                    i9 = i8;
                }
                if (i5 != 0) {
                    i8 = i9 + 1;
                    objArr[i9] = obj;
                    i9 = i8;
                }
                if (i6 != 0) {
                    i4 = i9 + 1;
                    objArr[i9] = obj2;
                    i9 = i4;
                }
                this.i = i9;
            }
            this.o = 0;
            i = i3 + 1;
            this.v = i3;
            this.t = i;
            if (i2 >= 0) {
                O(i2);
            }
        } else {
            this.p.c(i2);
            this.q.c((o() - this.h) - this.u);
            i = this.t;
            i4 = r(i);
            if (!k70.p(obj2, nq0)) {
                if (z) {
                    U(this.t, obj2);
                } else {
                    S(obj2);
                }
            }
            this.i = N(this.b, i4);
            this.j = g(this.b, r(this.t + 1));
            int[] iArr2 = this.b;
            i4 *= 5;
            this.o = iArr2[i4 + 1] & 67108863;
            this.v = i;
            this.t = i + 1;
            i += iArr2[i4 + 3];
        }
        this.u = i;
    }

    public final void B(int i) {
        int i2 = this.h;
        int i3 = this.g;
        if (i3 != i) {
            int o;
            int a;
            int i4;
            int i5;
            if (!this.d.isEmpty()) {
                o = o() - this.h;
                ArrayList arrayList = this.d;
                y00 y00;
                if (i3 >= i) {
                    for (a = z51.a(arrayList, i, o); a < this.d.size(); a++) {
                        y00 = (y00) this.d.get(a);
                        i4 = y00.a;
                        if (i4 < 0) {
                            break;
                        }
                        y00.a = -(o - i4);
                    }
                } else {
                    for (a = z51.a(arrayList, i3, o); a < this.d.size(); a++) {
                        y00 = (y00) this.d.get(a);
                        i4 = y00.a;
                        if (i4 >= 0) {
                            break;
                        }
                        i4 += o;
                        if (i4 >= i) {
                            break;
                        }
                        y00.a = i4;
                    }
                }
            }
            if (i2 > 0) {
                int[] iArr = this.b;
                o = i * 5;
                i5 = i2 * 5;
                i4 = i3 * 5;
                if (i < i3) {
                    ba.W(iArr, iArr, i5 + o, o, i4);
                } else {
                    ba.W(iArr, iArr, i4, i4 + i5, o + i5);
                }
            }
            if (i < i3) {
                i3 = i + i2;
            }
            a = o();
            if (i3 >= a) {
                FileProvider.a("Check failed");
            }
            while (i3 < a) {
                i5 = (i3 * 5) + 2;
                o = this.b[i5];
                int p = o > -2 ? o : (p() + o) - -2;
                if (p >= i) {
                    p = -((p() - p) - -2);
                }
                if (p != o) {
                    this.b[i5] = p;
                }
                i3++;
                if (i3 == i) {
                    i3 += i2;
                }
            }
        }
        this.g = i;
    }

    public final boolean I(int i, int i2) {
        boolean z = false;
        if (i2 > 0) {
            ArrayList arrayList = this.d;
            B(i);
            if (!arrayList.isEmpty()) {
                HashMap hashMap = this.e;
                int i3 = i + i2;
                int a = z51.a(this.d, i3, o() - this.h);
                if (a >= this.d.size()) {
                    a--;
                }
                int i4 = a + 1;
                int i5 = 0;
                while (a >= 0) {
                    y00 y00 = (y00) this.d.get(a);
                    int c = c(y00);
                    if (c < i) {
                        break;
                    }
                    if (c < i3) {
                        y00.a = Integer.MIN_VALUE;
                        if (hashMap != null) {
                            f10 f10 = (f10) hashMap.remove(y00);
                        }
                        if (i5 == 0) {
                            i5 = a + 1;
                        }
                        i4 = a;
                    }
                    a--;
                }
                if (i4 < i5) {
                    z = true;
                }
                if (z) {
                    this.d.subList(i4, i5).clear();
                }
            }
            this.g = i;
            this.h += i2;
            int i6 = this.m;
            if (i6 > i) {
                this.m = Math.max(i, i6 - i2);
            }
            i = this.u;
            if (i >= this.g) {
                this.u = i - i2;
            }
            i = this.v;
            if (i >= 0 && (this.b[(r(i) * 5) + 1] & 67108864) != 0) {
                T(i);
            }
        }
        return z;
    }

    public final void C(int i, int i2) {
        int i3;
        int i4 = this.l;
        int i5 = this.k;
        int i6 = this.m;
        if (i5 != i) {
            Object[] objArr = this.c;
            if (i < i5) {
                System.arraycopy(objArr, i, objArr, i + i4, i5 - i);
            } else {
                i3 = i5 + i4;
                System.arraycopy(objArr, i3, objArr, i5, (i + i4) - i3);
            }
        }
        i2 = Math.min(i2 + 1, p());
        if (i6 != i2) {
            i5 = this.c.length - i4;
            int i7;
            if (i2 < i6) {
                i4 = r(i2);
                i6 = r(i6);
                i7 = this.g;
                while (i4 < i6) {
                    int i8 = (i4 * 5) + 4;
                    i3 = this.b[i8];
                    if (i3 < 0) {
                        FileProvider.a("Unexpected anchor value, expected a positive anchor");
                    }
                    this.b[i8] = -((i5 - i3) + 1);
                    i4++;
                    if (i4 == i7) {
                        i4 += this.h;
                    }
                }
            } else {
                i4 = r(i6);
                i6 = r(i2);
                while (i4 < i6) {
                    i3 = (i4 * 5) + 4;
                    i7 = this.b[i3];
                    if (i7 >= 0) {
                        FileProvider.a("Unexpected anchor value, expected a negative anchor");
                    }
                    this.b[i3] = (i7 + i5) + 1;
                    i4++;
                    if (i4 == this.g) {
                        i4 += this.h;
                    }
                }
            }
            this.m = i2;
        }
        this.k = i;
    }

    public final void A(x51 x51, int i) {
        x51 x512 = x51;
        if (this.n <= 0) {
            FileProvider.a("Check failed");
        }
        if (i == 0 && this.t == 0 && this.a.f == 0) {
            int[] iArr = x512.e;
            int i2 = iArr[(i * 5) + 3];
            int i3 = x512.f;
            if (i2 == i3) {
                int[] iArr2 = this.b;
                Object[] objArr = this.c;
                ArrayList arrayList = this.d;
                HashMap hashMap = this.e;
                sj0 sj0 = this.f;
                Object[] objArr2 = x512.g;
                int i4 = x512.h;
                HashMap hashMap2 = x512.n;
                sj0 sj02 = x512.o;
                this.b = iArr;
                this.c = objArr2;
                this.d = x512.m;
                this.g = i3;
                this.h = (iArr.length / 5) - i3;
                this.k = i4;
                this.l = objArr2.length - i4;
                this.m = i3;
                this.e = hashMap2;
                this.f = sj02;
                x512.e = iArr2;
                x512.f = 0;
                x512.g = objArr;
                x512.h = 0;
                x512.m = arrayList;
                x512.n = hashMap;
                x512.o = sj0;
                return;
            }
        }
        a61 e = x512.e();
        try {
            jb0.o(e, i, this, true, true, false);
        } finally {
            e.e(false);
        }
    }

    public final void w(int i) {
        if (i > 0) {
            int i2 = this.t;
            B(i2);
            int i3 = this.g;
            int i4 = this.h;
            int[] iArr = this.b;
            int length = iArr.length / 5;
            int i5 = length - i4;
            int i6 = 0;
            if (i4 < i) {
                int max = Math.max(Math.max(length * 2, i5 + i), 32);
                int[] iArr2 = new int[(max * 5)];
                max -= i5;
                i4 += i3;
                int i7 = i3 + max;
                ba.W(iArr, iArr2, 0, 0, i3 * 5);
                ba.W(iArr, iArr2, i7 * 5, i4 * 5, length * 5);
                this.b = iArr2;
                i4 = max;
            }
            int i8 = this.u;
            if (i8 >= i3) {
                this.u = i8 + i;
            }
            i8 = i3 + i;
            this.g = i8;
            this.h = i4 - i;
            i2 = i5 > 0 ? f(i2 + i) : 0;
            if (this.m >= i3) {
                i6 = this.k;
            }
            i2 = a61.i(i2, i6, this.l, this.c.length);
            for (i4 = i3; i4 < i8; i4++) {
                this.b[(i4 * 5) + 4] = i2;
            }
            i2 = this.m;
            if (i2 >= i3) {
                this.m = i2 + i;
            }
        }
    }

    public final void G() {
        rj0 rj0 = this.x;
        if (rj0 != null) {
            while (rj0.b != 0) {
                int i;
                int A = jb0.A(rj0);
                int r = r(A);
                int i2 = A + 1;
                int u = u(A) + A;
                while (true) {
                    i = 0;
                    if (i2 >= u) {
                        i2 = 0;
                        break;
                    } else if ((this.b[(r(i2) * 5) + 1] & 201326592) != 0) {
                        i2 = 1;
                        break;
                    } else {
                        i2 += u(i2);
                    }
                }
                int[] iArr = this.b;
                r = (r * 5) + 1;
                int i3 = iArr[r];
                if ((67108864 & i3) != 0) {
                    i = 1;
                }
                if (i != i2) {
                    iArr[r] = (i2 << 26) | (-67108865 & i3);
                    A = E(iArr, A);
                    if (A >= 0) {
                        jb0.d(rj0, A);
                    }
                }
            }
        }
    }

    public final boolean H() {
        if (this.n != 0) {
            FileProvider.a("Cannot remove group while inserting");
        }
        int i = this.t;
        int i2 = this.i;
        int g = g(this.b, r(i));
        int L = L();
        O(this.v);
        rj0 rj0 = this.x;
        if (rj0 != null) {
            while (true) {
                int i3 = rj0.b;
                if (i3 == 0) {
                    break;
                } else if (i3 != 0) {
                    if (rj0.a[0] < i) {
                        break;
                    }
                    jb0.A(rj0);
                } else {
                    throw new dl1("IntList is empty.");
                }
            }
        }
        boolean I = I(i, this.t - i);
        J(g, this.i - g, i - 1);
        this.t = i;
        this.i = i2;
        this.o -= L;
        return I;
    }

    public final void e(boolean z) {
        this.w = true;
        if (z && this.p.b == 0) {
            B(p());
            C(this.c.length - this.l, this.g);
            int i = this.k;
            Arrays.fill(this.c, i, this.l + i, null);
            G();
        }
        int[] iArr = this.b;
        int i2 = this.g;
        Object[] objArr = this.c;
        int i3 = this.k;
        ArrayList arrayList = this.d;
        HashMap hashMap = this.e;
        sj0 sj0 = this.f;
        x51 x51 = this.a;
        if (!x51.k) {
            FileProvider.a("Unexpected writer close()");
        }
        x51.k = false;
        x51.e = iArr;
        x51.f = i2;
        x51.g = objArr;
        x51.h = i3;
        x51.m = arrayList;
        x51.n = hashMap;
        x51.o = sj0;
    }

    public final void a(int i) {
        if (i < 0) {
            FileProvider.a("Cannot seek backwards");
        }
        if (this.n > 0) {
            a5.b("Cannot call seek() while inserting");
        }
        if (i != 0) {
            int i2 = this.t + i;
            if (i2 < this.v || i2 > this.u) {
                StringBuilder dl1 = new dl1("Cannot seek outside the current group (");
                dl1.append(this.v);
                dl1.append('-');
                dl1.append(this.u);
                dl1.append(')');
                FileProvider.a(dl1.toString());
            }
            this.t = i2;
            i = g(this.b, r(i2));
            this.i = i;
            this.j = i;
        }
    }

    public a61(x51 x51) {
        this.a = x51;
        int[] iArr = x51.e;
        this.b = iArr;
        Object[] objArr = x51.g;
        this.c = objArr;
        this.d = x51.m;
        this.e = x51.n;
        this.f = x51.o;
        int i = x51.f;
        this.g = i;
        this.h = (iArr.length / 5) - i;
        int i2 = x51.h;
        this.k = i2;
        this.l = objArr.length - i2;
        this.m = i;
        this.u = i;
        this.v = -1;
    }

    public final void l(int i) {
        Object obj = null;
        if ((this.n <= 0 ? 1 : null) == null) {
            FileProvider.a("Cannot call ensureStarted() while inserting");
        }
        int i2 = this.v;
        if (i2 != i) {
            if (i >= i2 && i < this.u) {
                obj = 1;
            }
            if (obj == null) {
                StringBuilder dl1 = new dl1("Started group at ");
                dl1.append(i);
                dl1.append(" must be a subgroup of the group at ");
                dl1.append(i2);
                FileProvider.a(dl1.toString());
            }
            i2 = this.t;
            int i3 = this.i;
            int i4 = this.j;
            this.t = i;
            P();
            this.t = i2;
            this.i = i3;
            this.j = i4;
        }
    }

    public final boolean v(int i, int i2) {
        int i3;
        if (i2 == this.v) {
            i3 = this.u;
        } else {
            w60 w60 = this.p;
            if (i2 > w60.a(0)) {
                i3 = u(i2);
            } else {
                int[] iArr = w60.a;
                int min = Math.min(iArr.length, w60.b);
                int i4 = 0;
                while (i4 < min) {
                    if (iArr[i4] == i2) {
                        break;
                    }
                    i4++;
                }
                i4 = -1;
                i3 = i4 < 0 ? u(i2) : (o() - this.h) - this.q.a[i4];
            }
            i3 += i2;
        }
        return i > i2 && i < i3;
    }

    public final void x(int i, int i2) {
        if (i > 0) {
            C(this.i, i2);
            i2 = this.k;
            int i3 = this.l;
            if (i3 < i) {
                Object[] objArr = this.c;
                int length = objArr.length;
                int i4 = length - i3;
                int max = Math.max(Math.max(length * 2, i4 + i), 32);
                Object[] objArr2 = new Object[max];
                for (int i5 = 0; i5 < max; i5++) {
                    objArr2[i5] = null;
                }
                max -= i4;
                i3 += i2;
                i4 = i2 + max;
                System.arraycopy(objArr, 0, objArr2, 0, i2);
                System.arraycopy(objArr, i3, objArr2, i4, length - i3);
                this.c = objArr2;
                i3 = max;
            }
            int i6 = this.j;
            if (i6 >= i2) {
                this.j = i6 + i;
            }
            this.k = i2 + i;
            this.l = i3 - i;
        }
    }

    public final String toString() {
        StringBuilder dl1 = new dl1("SlotWriter(current = ");
        dl1.append(this.t);
        dl1.append(" end=");
        dl1.append(this.u);
        dl1.append(" size = ");
        dl1.append(p());
        dl1.append(" gap=");
        dl1.append(this.g);
        dl1.append('-');
        dl1.append(this.g + this.h);
        dl1.append(')');
        return dl1.toString();
    }

    public final Object K(int i, int i2, Object obj) {
        int N = N(this.b, r(i));
        int g = g(this.b, r(i + 1));
        int i3 = N + i2;
        if (i3 < N || i3 >= g) {
            StringBuilder dl1 = new dl1("Write to an invalid slot index ");
            dl1.append(i2);
            dl1.append(" for group ");
            dl1.append(i);
            FileProvider.a(dl1.toString());
        }
        i = h(i3);
        Object[] objArr = this.c;
        Object obj2 = objArr[i];
        objArr[i] = obj;
        return obj2;
    }

    public final void U(int i, Object obj) {
        int r = r(i);
        int[] iArr = this.b;
        if (r >= iArr.length || (iArr[(r * 5) + 1] & 1073741824) == 0) {
            StringBuilder dl1 = new dl1("Updating the node of a group at ");
            dl1.append(i);
            dl1.append(" that was not created with as a node group");
            FileProvider.a(dl1.toString());
        }
        this.c[h(g(this.b, r))] = obj;
    }

    public final void k() {
        if (this.n <= 0) {
            a5.b("Unbalanced begin/end insert");
        }
        int i = this.n - 1;
        this.n = i;
        if (i == 0) {
            if (this.r.b != this.p.b) {
                FileProvider.a("startGroup/endGroup mismatch while inserting");
            }
            this.u = (o() - this.h) - this.q.b();
        }
    }

    public final void S(Object obj) {
        int r = r(this.t);
        int i = (r * 5) + 1;
        if ((this.b[i] & 268435456) == 0) {
            FileProvider.a("Updating the data of a group that was not created with a data slot");
        }
        Object[] objArr = this.c;
        int[] iArr = this.b;
        objArr[h(Integer.bitCount(iArr[i] >> 29) + g(iArr, r))] = obj;
    }

    public final Object F(Object obj) {
        if (this.n > 0) {
            x(1, this.v);
        }
        Object[] objArr = this.c;
        int i = this.i;
        this.i = i + 1;
        Object obj2 = objArr[h(i)];
        if (this.i > this.j) {
            FileProvider.a("Writing to an invalid slot");
        }
        this.c[h(this.i - 1)] = obj;
        return obj2;
    }

    public final void m(int i, int i2, int i3) {
        if (i >= this.g) {
            i = -((p() - i) + 2);
        }
        while (i3 < i2) {
            this.b[(r(i3) * 5) + 2] = i;
            int i4 = this.b[(r(i3) * 5) + 3] + i3;
            m(i3, i4, i3 + 1);
            i3 = i4;
        }
    }

    public final int L() {
        int r = r(this.t);
        int i = this.t;
        int[] iArr = this.b;
        r *= 5;
        int i2 = iArr[r + 3] + i;
        this.t = i2;
        this.i = g(iArr, r(i2));
        int i3 = this.b[r + 1];
        return (1073741824 & i3) != 0 ? 1 : i3 & 67108863;
    }

    public static void z(a61 a61) {
        int i = a61.v;
        int r = a61.r(i);
        int[] iArr = a61.b;
        r = (r * 5) + 1;
        int i2 = iArr[r];
        if ((i2 & 134217728) == 0) {
            i2 = (i2 & -134217729) | 134217728;
            iArr[r] = i2;
            if ((67108864 & i2) == 0) {
                a61.T(a61.E(iArr, i));
            }
        }
    }

    public final y00 b(int i) {
        ArrayList arrayList = this.d;
        int e = z51.e(arrayList, i, p());
        if (e >= 0) {
            return (y00) arrayList.get(e);
        }
        if (i > this.g) {
            i = -(p() - i);
        }
        y00 h90 = new h90(i);
        arrayList.add(-(e + 1), h90);
        return h90;
    }

    public final Object q(int i) {
        i = r(i);
        int[] iArr = this.b;
        int i2 = (i * 5) + 1;
        if ((iArr[i2] & 268435456) == 0) {
            return oj.a;
        }
        return this.c[Integer.bitCount(iArr[i2] >> 29) + g(iArr, i)];
    }

    public final Object t(int i) {
        i = r(i);
        int[] iArr = this.b;
        i *= 5;
        int i2 = iArr[i + 1];
        if ((536870912 & i2) == 0) {
            return null;
        }
        return this.c[Integer.bitCount(i2 >> 30) + iArr[i + 4]];
    }

    public final Object D(int i) {
        i = r(i);
        int[] iArr = this.b;
        return (iArr[(i * 5) + 1] & 1073741824) != 0 ? this.c[h(g(iArr, i))] : null;
    }

    public final int g(int[] iArr, int i) {
        if (i >= o()) {
            return this.c.length - this.l;
        }
        int i2 = iArr[(i * 5) + 4];
        return i2 < 0 ? ((this.c.length - this.l) + i2) + 1 : i2;
    }

    public final int N(int[] iArr, int i) {
        if (i >= o()) {
            return this.c.length - this.l;
        }
        Object b = w51.b(iArr, i);
        return b < null ? ((this.c.length - this.l) + b) + 1 : b;
    }

    public final y00 R(int i) {
        if (i >= 0 && i < p()) {
            ArrayList arrayList = this.d;
            int e = z51.e(arrayList, i, p());
            if (e >= 0) {
                return (y00) arrayList.get(e);
            }
        }
        return null;
    }

    public final void J(int i, int i2, int i3) {
        if (i2 > 0) {
            int i4 = this.l;
            int i5 = i + i2;
            C(i5, i3);
            this.k = i;
            this.l = i4 + i2;
            Arrays.fill(this.c, i, i5, null);
            i3 = this.j;
            if (i3 >= i) {
                this.j = i3 - i2;
            }
        }
    }

    public final void d() {
        int i = this.n;
        this.n = i + 1;
        if (i == 0) {
            this.q.c((o() - this.h) - this.u);
        }
    }

    public final int E(int[] iArr, int i) {
        int i2 = iArr[(r(i) * 5) + 2];
        return i2 > -2 ? i2 : (p() + i2) - -2;
    }

    public final boolean y(int i) {
        return (this.b[(r(i) * 5) + 1] & 1073741824) != 0;
    }

    public final f10 O(int i) {
        HashMap hashMap = this.e;
        if (hashMap != null) {
            y00 R = R(i);
            if (R != null) {
                return (f10) hashMap.get(R);
            }
        }
        return null;
    }

    public final void M() {
        int i = this.u;
        this.t = i;
        this.i = g(this.b, r(i));
    }

    public final void P() {
        if (this.n != 0) {
            FileProvider.a("Key must be supplied when inserting");
        }
        nq0 nq0 = oj.a;
        Q(0, nq0, false, nq0);
    }

    public final void T(int i) {
        if (i >= 0) {
            rj0 rj0 = this.x;
            if (rj0 == null) {
                rj0 = new rj0();
                this.x = rj0;
            }
            jb0.d(rj0, i);
        }
    }

    public final int u(int i) {
        return this.b[(r(i) * 5) + 3];
    }

    public final int h(int i) {
        return (this.l * (i < this.k ? 0 : 1)) + i;
    }

    public final int r(int i) {
        return (this.h * (i < this.g ? 0 : 1)) + i;
    }

    public final int c(y00 y00) {
        int i = y00.a;
        return i < 0 ? p() + i : i;
    }

    public final int f(int i) {
        return g(this.b, r(i));
    }

    public final int s(int i) {
        return this.b[r(i) * 5];
    }

    public static int i(int i, int i2, int i3, int i4) {
        return i > i2 ? -(((i4 - i3) - i) + 1) : i;
    }

    public final int p() {
        return o() - this.h;
    }

    public final int o() {
        return this.b.length / 5;
    }
}