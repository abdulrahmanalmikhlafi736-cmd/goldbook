package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ds */
public interface ds extends cp {
    void C(da0 da0);

    void Z();
}