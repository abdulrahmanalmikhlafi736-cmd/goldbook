package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: b91 */
public final class b91 extends h90 implements m00 {
    public final /* synthetic */ mi0 f;
    public final /* synthetic */ m00 g;
    public final /* synthetic */ int h;
    public final /* synthetic */ int i;

    public final Object f(Object obj, Object obj2) {
        d10 d10 = (d10) obj;
        ((Number) obj2).intValue();
        vn.b(this.f, this.g, d10, wc0.s(this.h | 1), this.i);
        return we1.a;
    }

    public b91(mi0 mi0, m00 m00, int i, int i2) {
        this.f = mi0;
        this.g = m00;
        this.h = i;
        this.i = i2;
        super(2);
    }
}