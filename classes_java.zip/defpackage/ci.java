package defpackage;

import android.view.View;
import android.view.Window;
import com.almekhlafi.goldbook.MainActivity;
import java.util.LinkedHashMap;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ci */
public final /* synthetic */ class ci implements qd0 {
    public final /* synthetic */ int e;
    public final /* synthetic */ Object f;

    public final void h(sd0 sd0, id0 id0) {
        int i = this.e;
        Object obj = this.f;
        MainActivity mainActivity;
        switch (i) {
            case 0:
                mainActivity = (MainActivity) obj;
                if (id0 == id0.ON_STOP) {
                    Window window = mainActivity.getWindow();
                    if (window != null) {
                        View peekDecorView = window.peekDecorView();
                        if (peekDecorView != null) {
                            peekDecorView.cancelPendingInputEvents();
                        }
                    }
                }
                return;
            case 1:
                mainActivity = (MainActivity) obj;
                if (id0 == id0.ON_DESTROY) {
                    mainActivity.f.b = null;
                    if (!mainActivity.isChangingConfigurations()) {
                        LinkedHashMap linkedHashMap = mainActivity.f().a;
                        for (fh1 b : linkedHashMap.values()) {
                            b.b();
                        }
                        linkedHashMap.clear();
                    }
                    gi giVar = mainActivity.j;
                    MainActivity mainActivity2 = giVar.h;
                    mainActivity2.getWindow().getDecorView().removeCallbacks(giVar);
                    mainActivity2.getWindow().getDecorView().getViewTreeObserver().removeOnDrawListener(giVar);
                }
                return;
            default:
                wz0 wz0 = (wz0) obj;
                if (id0 == id0.ON_START) {
                    wz0.h = true;
                } else if (id0 == id0.ON_STOP) {
                    wz0.h = false;
                }
                return;
        }
    }

    public /* synthetic */ ci(int i, Object obj) {
        this.e = i;
        this.f = obj;
    }
}