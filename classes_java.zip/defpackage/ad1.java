package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ad1 */
public final class ad1 {
    public final Object a;
    public final Object b;

    public final boolean equals(Object obj) {
        if (obj instanceof ad1) {
            ad1 ad1 = (ad1) obj;
            if (k70.p(this.a, ad1.a) && k70.p(this.b, ad1.b)) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        int i = 0;
        Object obj = this.a;
        int hashCode = (obj != null ? obj.hashCode() : 0) * 31;
        Object obj2 = this.b;
        if (obj2 != null) {
            i = obj2.hashCode();
        }
        return hashCode + i;
    }

    public final boolean a(zt ztVar, zt ztVar2) {
        return ztVar.equals(this.a) && ztVar2.equals(this.b);
    }

    public ad1(Object obj, Object obj2) {
        this.a = obj;
        this.b = obj2;
    }
}