package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bw */
public final class bw extends ua0 {
    public final zo0 b = new zo0();
    public final zo0 c = new zo0();
}