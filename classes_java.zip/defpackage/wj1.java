package defpackage;

import android.view.WindowInsets;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: wj1 */
public class wj1 extends vj1 {
    public c60 s = null;

    public final c60 l() {
        if (this.s == null) {
            WindowInsets windowInsets = this.c;
            this.s = c60.b(windowInsets.getStableInsetLeft(), windowInsets.getStableInsetTop(), windowInsets.getStableInsetRight(), windowInsets.getStableInsetBottom());
        }
        return this.s;
    }

    public hk1 b() {
        return hk1.c(null, this.c.consumeStableInsets());
    }

    public hk1 c() {
        return hk1.c(null, this.c.consumeSystemWindowInsets());
    }

    public wj1(hk1 hk1, wj1 wj1) {
        super(hk1, (vj1) wj1);
        this.s = wj1.s;
    }

    public boolean s() {
        return this.c.isConsumed();
    }

    public void z(c60 c60) {
        this.s = c60;
    }

    public wj1(hk1 hk1, WindowInsets windowInsets) {
        super(hk1, windowInsets);
    }
}