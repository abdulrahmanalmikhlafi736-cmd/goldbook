package defpackage;

import android.os.Build.VERSION;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bn0 */
public final class bn0 extends hl0 {
    public final OnBackInvokedDispatcher c;
    public final int d;
    public final OnBackInvokedCallback e;
    public boolean f;

    public final void b(boolean z) {
        OnBackInvokedCallback onBackInvokedCallback = this.e;
        if (!z || this.f) {
            if (!z && this.f) {
                this.c.unregisterOnBackInvokedCallback(onBackInvokedCallback);
                this.f = false;
            }
            return;
        }
        this.c.registerOnBackInvokedCallback(this.d, onBackInvokedCallback);
        this.f = true;
    }

    public bn0(OnBackInvokedDispatcher onBackInvokedDispatcher, int i) {
        this.c = onBackInvokedDispatcher;
        this.d = i;
        this.e = VERSION.SDK_INT == 33 ? new cn0(this) : new dn0(this);
    }
}