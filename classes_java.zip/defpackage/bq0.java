package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bq0 */
public final class bq0 {
    public final m6 a;
    public final int b;
    public final int c;
    public final int d;
    public final int e;
    public final float f;
    public final float g;

    public final String toString() {
        StringBuilder dl1 = new dl1("ParagraphInfo(paragraph=");
        dl1.append(this.a);
        dl1.append(", startIndex=");
        dl1.append(this.b);
        dl1.append(", endIndex=");
        dl1.append(this.c);
        dl1.append(", startLineIndex=");
        dl1.append(this.d);
        dl1.append(", endLineIndex=");
        dl1.append(this.e);
        dl1.append(", top=");
        dl1.append(this.f);
        dl1.append(", bottom=");
        return fu0.F(dl1, this.g, ')');
    }

    /* JADX WARNING: Missing block: B:24:0x0041, code:
            if (java.lang.Float.compare(r3.g, r4.g) != 0) goto L_0x0043;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean equals(Object obj) {
        if (this != obj) {
            if (obj instanceof bq0) {
                bq0 bq0 = (bq0) obj;
                if (this.a != bq0.a) {
                    return false;
                }
                if (this.b == bq0.b) {
                    if (this.c == bq0.c) {
                        if (this.d == bq0.d) {
                            if (this.e == bq0.e) {
                                if (Float.compare(this.f, bq0.f) != 0) {
                                }
                            }
                        }
                    }
                }
            }
            return false;
        }
        return true;
    }

    public final int hashCode() {
        return Float.floatToIntBits(this.g) + fu0.z(this.f, ((((((((this.a.hashCode() * 31) + this.b) * 31) + this.c) * 31) + this.d) * 31) + this.e) * 31, 31);
    }

    public bq0(m6 m6Var, int i, int i2, int i3, int i4, float f, float f2) {
        this.a = m6Var;
        this.b = i;
        this.c = i2;
        this.d = i3;
        this.e = i4;
        this.f = f;
        this.g = f2;
    }

    public final int a(int i) {
        int i2 = this.c;
        int i3 = this.b;
        return sb0.h(i, i3, i2) - i3;
    }
}