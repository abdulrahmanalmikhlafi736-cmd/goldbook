package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: g70 */
public interface g70 extends jp {
    o90 getLayoutDirection();

    boolean n();
}