package defpackage;

import java.io.Serializable;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cj0 */
public final class cj0 extends u91 implements m00 {
    public jw0 i;
    public jw0 j;
    public int k;
    public int l;
    public /* synthetic */ Object m;
    public final /* synthetic */ kw0 n;
    public final /* synthetic */ nw0 o;
    public final /* synthetic */ nw0 p;
    public final /* synthetic */ float q;
    public final /* synthetic */ tp r;
    public final /* synthetic */ float s;
    public final /* synthetic */ y11 t;

    /* JADX WARNING: Removed duplicated region for block: B:13:0x0073  */
    /* JADX WARNING: Removed duplicated region for block: B:33:0x0175  */
    /* JADX WARNING: Removed duplicated region for block: B:13:0x0073  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final Object p(Object obj) {
        w11 w11;
        jw0 obj2;
        jw0 jw0;
        int i;
        boolean z;
        cm cmVar;
        w11 w112;
        Object obj3;
        int i2;
        nw0 nw0;
        Serializable serializable;
        cm cmVar2;
        nw0 nw02;
        long j;
        Object obj4;
        nw0 nw03;
        long j2;
        Serializable serializable2;
        cj0 cj0 = this;
        int i3 = cj0.l;
        nw0 nw04 = cj0.p;
        kw0 kw0 = cj0.n;
        int i4 = 3;
        int i5 = 2;
        boolean z2 = true;
        nw0 nw05 = cj0.o;
        cm cmVar3 = cm.e;
        jw0 jw02;
        w11 w113;
        if (i3 == 0) {
            nb0.t(obj);
            w11 = (w11) cj0.m;
            obj2 = new Object();
            obj2.e = true;
            jw0 = obj2;
        } else if (i3 == 1) {
            jw02 = cj0.j;
            obj2 = cj0.i;
            w113 = (w11) cj0.m;
            nb0.t(obj);
            jw0 = jw02;
            i = 3;
            z = true;
            cmVar = cmVar3;
            w112 = w113;
            obj3 = obj;
            i2 = 2;
            nw0 = nw05;
            jw0.e = ((Boolean) obj3).booleanValue();
            cj0 = this;
            nw05 = nw0;
            w11 = w112;
            jw0 = obj2;
            i5 = i2;
            z2 = z;
            cmVar3 = cmVar;
            i4 = i;
        } else if (i3 == 2) {
            i3 = cj0.k;
            obj2 = cj0.i;
            w113 = (w11) cj0.m;
            nb0.t(obj);
            serializable = kw0;
            cmVar2 = cmVar3;
            jw0 = obj2;
            w112 = w113;
            nw02 = nw04;
            if (jw0.e) {
                j = 50 - ((long) i3);
                cj0.m = w112;
                cj0.i = jw0;
                cj0.j = jw0;
                cj0.l = 3;
                i = 3;
                obj4 = cmVar2;
                z = true;
                nw03 = nw02;
                i2 = i5;
                nw0 = nw05;
                j2 = j;
                nw04 = nw03;
                kw0 = serializable;
                obj3 = tp.b(cj0.r, nw04, kw0, cj0.t, nw0, j2, cj0);
                if (obj3 == obj4) {
                    obj2 = jw0;
                    jw0.e = ((Boolean) obj3).booleanValue();
                    nw05 = nw0;
                    w11 = w112;
                    jw0 = obj2;
                    i5 = i2;
                    z2 = z;
                    cmVar3 = cmVar;
                    i4 = i;
                }
                return obj4;
            }
            nw04 = nw02;
            i = 3;
            w11 = w112;
            serializable2 = serializable;
            z2 = true;
            cmVar3 = cmVar2;
            i4 = i;
        } else if (i3 == 3) {
            jw02 = cj0.j;
            obj2 = cj0.i;
            w113 = (w11) cj0.m;
            nb0.t(obj);
            jw0 = jw02;
            i = 3;
            z = true;
            cmVar = cmVar3;
            w112 = w113;
            obj3 = obj;
            i2 = 2;
            nw0 = nw05;
            jw0.e = ((Boolean) obj3).booleanValue();
            nw05 = nw0;
            w11 = w112;
            jw0 = obj2;
            i5 = i2;
            z2 = z;
            cmVar3 = cmVar;
            i4 = i;
        } else {
            od.p("call to 'resume' before 'invoke' with coroutine");
            return null;
        }
        boolean z3 = jw0.e;
        we1 we1 = we1.a;
        if (z3) {
            jw0.e = false;
            float floatValue = kw0.e - ((Number) ((p8) nw05.e).f.getValue()).floatValue();
            boolean z4 = ((aj0) nw04.e).c;
            tp tpVar = cj0.r;
            if (!z4) {
                float abs = Math.abs(floatValue);
                float f = cj0.q;
                if (abs >= f) {
                    floatValue = Math.signum(floatValue) * f;
                    tpVar.c(w11, floatValue);
                    p8 p8Var = (p8) nw05.e;
                    p8 r = wl1.r(p8Var, ((Number) p8Var.f.getValue()).floatValue() + floatValue);
                    nw05.e = r;
                    int P = gh0.P(Math.abs(kw0.e - ((Number) r.f.getValue()).floatValue()) / cj0.s);
                    if (P > 100) {
                        P = 100;
                    }
                    p8Var = (p8) nw05.e;
                    float f2 = kw0.e;
                    int i6 = P;
                    tp tpVar2 = cj0.r;
                    cmVar2 = cmVar3;
                    float f3 = f2;
                    serializable = kw0;
                    p8 p8Var2 = p8Var;
                    nw02 = nw04;
                    int i7 = i6;
                    l2 l2Var = new l2(tpVar2, nw02, serializable, cj0.t, jw0, 1);
                    tp tpVar3 = tpVar2;
                    cj0.m = w11;
                    cj0.i = jw0;
                    cj0.j = null;
                    cj0.k = i7;
                    cj0.l = i5;
                    tpVar3.getClass();
                    kw0 obj5 = new Object();
                    obj5.e = ((Number) p8Var2.f.getValue()).floatValue();
                    w11 w114 = w11;
                    w112 = w114;
                    cm c = wa0.c(p8Var2, new br0(f3), zi1.I(i7, ls.b, i5), new ho(obj5, tpVar3, w114, l2Var, 3), cj0);
                    if (c != cmVar2) {
                        c = we1;
                    }
                    if (c == cmVar2) {
                        obj4 = cmVar2;
                    } else {
                        i3 = i7;
                        if (jw0.e) {
                            nw04 = nw02;
                            i = 3;
                            w11 = w112;
                            serializable2 = serializable;
                            z2 = true;
                            cmVar3 = cmVar2;
                            i4 = i;
                            boolean z32 = jw0.e;
                            we1 we12 = we1.a;
                            if (z32) {
                                return we12;
                            }
                        }
                        j = 50 - ((long) i3);
                        cj0.m = w112;
                        cj0.i = jw0;
                        cj0.j = jw0;
                        cj0.l = 3;
                        i = 3;
                        obj4 = cmVar2;
                        z = true;
                        nw03 = nw02;
                        i2 = i5;
                        nw0 = nw05;
                        j2 = j;
                        nw04 = nw03;
                        kw0 = serializable;
                        obj3 = tp.b(cj0.r, nw04, kw0, cj0.t, nw0, j2, cj0);
                        if (obj3 == obj4) {
                        }
                        return obj4;
                    }
                    obj4 = cmVar2;
                    return obj4;
                }
            }
            i = i4;
            i2 = i5;
            z = z2;
            nw0 = nw05;
            cmVar = cmVar3;
            w112 = w11;
            tpVar.c(w112, floatValue);
            cj0.m = w112;
            cj0.i = jw0;
            cj0.j = jw0;
            cj0.l = z;
            obj3 = tp.b(cj0.r, nw04, kw0, cj0.t, nw0, 50, cj0);
            if (obj3 != cmVar) {
                obj2 = jw0;
                jw0.e = ((Boolean) obj3).booleanValue();
                cj0 = this;
                nw05 = nw0;
                w11 = w112;
                jw0 = obj2;
                i5 = i2;
                z2 = z;
                cmVar3 = cmVar;
                i4 = i;
                boolean z322 = jw0.e;
                we1 we122 = we1.a;
                if (z322) {
                }
            }
            return obj4;
        }
        return we122;
    }

    public final ml n(ml mlVar, Object obj) {
        cj0 cj0 = new cj0(this.n, this.o, this.p, this.q, this.r, this.s, this.t, mlVar);
        cj0.m = obj;
        return cj0;
    }

    public cj0(kw0 kw0, nw0 nw0, nw0 nw02, float f, tp tpVar, float f2, y11 y11, ml mlVar) {
        this.n = kw0;
        this.o = nw0;
        this.p = nw02;
        this.q = f;
        this.r = tpVar;
        this.s = f2;
        this.t = y11;
        super(2, mlVar);
    }

    public final Object f(Object obj, Object obj2) {
        return ((cj0) n((ml) obj2, (w11) obj)).p(we1.a);
    }
}