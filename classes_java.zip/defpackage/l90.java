package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: l90 */
public interface l90 extends ph0, cp {
    void i(n90 n90);
}