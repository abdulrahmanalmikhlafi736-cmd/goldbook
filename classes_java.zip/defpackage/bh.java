package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bh */
public abstract class bh {
    public static final long A;
    public static final long B;
    public static final long C;
    public static final long D = aq0.h;
    public static final long E = aq0.O;
    public static final long F;
    public static final long G;
    public static final long H = aq0.P;
    public static final long I;
    public static final long J;
    public static final long K = aq0.u;
    public static final long L = aq0.t;
    public static final long M = aq0.s;
    public static final long N = aq0.w;
    public static final long O = aq0.j;
    public static final long P = aq0.r;
    public static final long Q = aq0.C;
    public static final long R = aq0.V;
    public static final long S;
    public static final long T;
    public static final long U = aq0.W;
    public static final long a;
    public static final long b = aq0.e;
    public static final long c = aq0.g;
    public static final long d = aq0.v;
    public static final long e;
    public static final long f = aq0.m;
    public static final long g;
    public static final long h = aq0.b;
    public static final long i = aq0.a;
    public static final long j = aq0.E;
    public static final long k;
    public static final long l;
    public static final long m = aq0.G;
    public static final long n = aq0.L;
    public static final long o;
    public static final long p;
    public static final long q = aq0.N;
    public static final long r;
    public static final long s = aq0.y;
    public static final long t = aq0.S;
    public static final long u;
    public static final long v;
    public static final long w = aq0.U;
    public static final long x = aq0.z;
    public static final long y = aq0.B;
    public static final long z = aq0.H;

    static {
        long j = aq0.x;
        a = j;
        long j2 = aq0.I;
        e = j2;
        long j3 = aq0.i;
        g = j3;
        long j4 = aq0.D;
        k = j4;
        l = j4;
        j4 = aq0.K;
        o = j4;
        p = j4;
        r = j3;
        j3 = aq0.R;
        u = j3;
        v = j3;
        j3 = aq0.J;
        A = j3;
        B = j3;
        C = j2;
        j2 = aq0.Q;
        F = j2;
        G = j2;
        I = j;
        J = j;
        j = aq0.X;
        S = j;
        T = j;
    }
}