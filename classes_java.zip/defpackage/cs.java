package defpackage;

import android.graphics.Rect;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cs */
public abstract class cs extends ViewGroup {
    public final void a(re reVar, View view, long j) {
        super.drawChild(u3.a(reVar), view, j);
    }

    public final void onMeasure(int i, int i2) {
        setMeasuredDimension(0, 0);
    }

    public int getChildCount() {
        return 0;
    }

    public final ViewParent invalidateChildInParent(int[] iArr, Rect rect) {
        return null;
    }

    public final void forceLayout() {
    }

    public final void onLayout(boolean z, int i, int i2, int i3, int i4) {
    }

    public final void requestLayout() {
    }
}