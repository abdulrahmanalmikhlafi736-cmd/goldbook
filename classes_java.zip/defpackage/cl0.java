package defpackage;

import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cl0 */
public final class cl0 extends w21 {
    public static final /* synthetic */ AtomicReferenceFieldUpdater g = AtomicReferenceFieldUpdater.newUpdater(cl0.class, Object.class, "owner$volatile");
    private volatile /* synthetic */ Object owner$volatile = vd1.k;

    public final Object e(Object obj) {
        while (Math.max(w21.f.get(this), 0) == 0) {
            AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = g;
            mt mtVar = atomicReferenceFieldUpdater.get(this);
            mt mtVar2 = vd1.k;
            if (mtVar != mtVar2) {
                if (mtVar != obj) {
                    if (obj != null) {
                        StringBuilder dl1 = new dl1("This mutex is locked by ");
                        dl1.append(mtVar);
                        dl1.append(", but ");
                        dl1.append(obj);
                        dl1.append(" is expected");
                        throw new dl1(dl1.toString().toString());
                    }
                }
                while (!atomicReferenceFieldUpdater.compareAndSet(this, mtVar, mtVar2)) {
                    if (atomicReferenceFieldUpdater.get(this) != mtVar) {
                    }
                }
                b();
                return;
            }
        }
        od.p("This mutex is not locked");
        return;
    }

    public final String toString() {
        StringBuilder dl1 = new dl1("Mutex@");
        dl1.append(vn.y(this));
        dl1.append("[isLocked=");
        boolean z = false;
        if (Math.max(w21.f.get(this), 0) == 0) {
            z = true;
        }
        dl1.append(z);
        dl1.append(",owner=");
        dl1.append(g.get(this));
        dl1.append(']');
        return dl1.toString();
    }

    public final Object c(nl nlVar) {
        boolean d = d();
        we1 we1 = we1.a;
        if (!d) {
            ne y = gh0.y(ac.x(nlVar));
            try {
                a(new bl0(this, y));
                cm s = y.s();
                cm cmVar = cm.e;
                if (s != cmVar) {
                    s = we1;
                }
                if (s == cmVar) {
                    return s;
                }
            } catch (Throwable th) {
                y.B();
            }
        }
        return we1;
    }

    public final boolean d() {
        while (true) {
            AtomicIntegerFieldUpdater atomicIntegerFieldUpdater = w21.f;
            int i = atomicIntegerFieldUpdater.get(this);
            if (i > 1) {
                do {
                    i = atomicIntegerFieldUpdater.get(this);
                    if (i <= 1) {
                        break;
                    }
                } while (!atomicIntegerFieldUpdater.compareAndSet(this, i, 1));
            } else if (i <= 0) {
                return false;
            } else {
                if (atomicIntegerFieldUpdater.compareAndSet(this, i, i - 1)) {
                    g.set(this, null);
                    return true;
                }
            }
        }
    }
}