package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: av */
public abstract class av {
    public static final zu a = new Object();
    public static final zu b;

    static {
        jv0 jv0 = jv0.c;
        zu zuVar = null;
        try {
            zuVar = (zu) Class.forName("androidx.datastore.preferences.protobuf.ExtensionSchemaFull").getDeclaredConstructor(null).newInstance(null);
        } catch (Exception unused) {
        }
        b = zuVar;
    }
}