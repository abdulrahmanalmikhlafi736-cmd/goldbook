package defpackage;

import androidx.core.content.FileProvider;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ac0 */
public final /* synthetic */ class ac0 implements i00 {
    public final /* synthetic */ int e;
    public final /* synthetic */ dc0 f;

    public final Object i(Object obj) {
        int i = this.e;
        dc0 dc0 = this.f;
        switch (i) {
            case 0:
                hc0 hc0 = (hc0) dc0.s.a();
                i = hc0.c();
                int i2 = 0;
                while (i2 < i) {
                    if (hc0.d(i2).equals(obj)) {
                        return Integer.valueOf(i2);
                    }
                    i2++;
                }
                i2 = -1;
                return Integer.valueOf(i2);
            default:
                int intValue = ((Integer) obj).intValue();
                hc0 hc02 = (hc0) dc0.s.a();
                if (intValue < 0 || intValue >= hc02.c()) {
                    StringBuilder H = fu0.H(intValue, "Can't scroll to index ", ", it is out of bounds [0, ");
                    H.append(hc02.c());
                    H.append(')');
                    FileProvider.a(H.toString());
                }
                wl1.B(dc0.d0(), null, new cc0(dc0, intValue, null), 3);
                return Boolean.TRUE;
        }
    }

    public /* synthetic */ ac0(dc0 dc0, int i) {
        this.e = i;
        this.f = dc0;
    }
}