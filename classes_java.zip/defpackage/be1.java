package defpackage;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.fonts.FontVariationAxis;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.util.Log;
import java.io.FileInputStream;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: be1 */
public class be1 extends zd1 {
    public final Class b;
    public final Constructor c;
    public final Method d;
    public final Method e;
    public final Method f;
    public final Method g;
    public final Method h;

    /* JADX WARNING: Removed duplicated region for block: B:34:? A:{SYNTHETIC, Splitter: B:31:0x0062, ExcHandler: java.lang.IllegalAccessException (unused java.lang.IllegalAccessException)} */
    /* JADX WARNING: Removed duplicated region for block: B:73:? A:{SYNTHETIC, Splitter: B:36:0x008e, ExcHandler: java.lang.IllegalAccessException (unused java.lang.IllegalAccessException)} */
    /* JADX WARNING: Removed duplicated region for block: B:45:? A:{SYNTHETIC, Splitter: B:42:0x009c, ExcHandler: java.lang.IllegalAccessException (unused java.lang.IllegalAccessException)} */
    /* JADX WARNING: Removed duplicated region for block: B:21:? A:{SYNTHETIC, Splitter: B:18:0x003c, ExcHandler: java.lang.IllegalAccessException (unused java.lang.IllegalAccessException)} */
    /* JADX WARNING: Removed duplicated region for block: B:21:? A:{SYNTHETIC, Splitter: B:18:0x003c, ExcHandler: java.lang.IllegalAccessException (unused java.lang.IllegalAccessException)} */
    /* JADX WARNING: Missing block: B:20:0x0043, code:
            r0 = null;
     */
    /* JADX WARNING: Missing block: B:33:0x008b, code:
            r6 = false;
     */
    /* JADX WARNING: Missing block: B:44:0x00a9, code:
            r14 = false;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final Typeface e(Context context, rz[] rzVarArr) {
        if (rzVarArr.length >= 1) {
            Method method = this.d;
            if (method == null) {
                Log.w("TypefaceCompatApi26Impl", "Unable to collect necessary private methods. Fallback to legacy implementation.");
            }
            if (method != null) {
                int i;
                int length;
                Object newInstance;
                HashMap hashMap = new HashMap();
                for (rz rzVar : rzVarArr) {
                    if (rzVar.f == 0) {
                        Uri uri = rzVar.a;
                        if (!hashMap.containsKey(uri)) {
                            hashMap.put(uri, kb0.t(context, uri));
                        }
                    }
                }
                Map unmodifiableMap = Collections.unmodifiableMap(hashMap);
                try {
                    newInstance = this.c.newInstance(null);
                } catch (IllegalAccessException unused) {
                }
                if (newInstance != null) {
                    length = rzVarArr.length;
                    i = 0;
                    int i2 = i;
                    while (true) {
                        Method method2 = this.g;
                        if (i < length) {
                            rz rzVar2 = rzVarArr[i];
                            if (((ByteBuffer) unmodifiableMap.get(rzVar2.a)) != null) {
                                boolean booleanValue;
                                i2 = rzVar2.b;
                                int i3 = rzVar2.c;
                                boolean z = rzVar2.d;
                                try {
                                    Method method3 = this.e;
                                    Integer valueOf = Integer.valueOf(i2);
                                    Integer valueOf2 = Integer.valueOf(i3);
                                    Integer valueOf3 = Integer.valueOf(z);
                                    booleanValue = ((Boolean) method3.invoke(newInstance, new Object[]{r9, valueOf, null, valueOf2, valueOf3})).booleanValue();
                                } catch (IllegalAccessException unused2) {
                                }
                                if (booleanValue) {
                                    i2 = 1;
                                } else {
                                    try {
                                        method2.invoke(newInstance, null);
                                        break;
                                    } catch (IllegalAccessException unused3) {
                                    }
                                }
                            }
                            i++;
                        } else if (i2 == 0) {
                            method2.invoke(newInstance, null);
                        } else {
                            boolean booleanValue2;
                            try {
                                booleanValue2 = ((Boolean) this.f.invoke(newInstance, null)).booleanValue();
                            } catch (IllegalAccessException unused4) {
                            }
                            if (booleanValue2) {
                                Typeface C = C(newInstance);
                                if (C != null) {
                                    return Typeface.create(C, 0);
                                }
                            }
                        }
                    }
                }
            } else {
                rz i4 = jb0.i(rzVarArr);
                ParcelFileDescriptor openFileDescriptor = context.getContentResolver().openFileDescriptor(i4.a, "r", null);
                if (openFileDescriptor != null) {
                    try {
                        Uri build = new FileInputStream(openFileDescriptor.getFileDescriptor()).setWeight(i4.c).setItalic(i4.d).build();
                        openFileDescriptor.close();
                        return build;
                    } catch (Throwable th) {
                        th.addSuppressed(th);
                    }
                } else if (openFileDescriptor != null) {
                    openFileDescriptor.close();
                    return null;
                }
            }
        }
        return null;
    }

    public be1() {
        Constructor constructor;
        Method D;
        Method method;
        Method method2;
        Method method3;
        Method method4;
        Object e;
        Class cls = null;
        try {
            Class cls2 = Class.forName("android.graphics.FontFamily");
            constructor = cls2.getConstructor(null);
            D = be1.D(cls2);
            r5 = new Class[5];
            Class cls3 = Integer.TYPE;
            r5[1] = cls3;
            r5[2] = FontVariationAxis[].class;
            r5[3] = cls3;
            r5[4] = cls3;
            method = cls2.getMethod("addFontFromBuffer", r5);
            method2 = cls2.getMethod("freeze", null);
            method3 = cls2.getMethod("abortCreation", null);
            cls = E(cls2);
            Class cls4 = cls2;
            method4 = cls;
            cls = cls4;
        } catch (ClassNotFoundException e2) {
            e = e2;
            Log.e("TypefaceCompatApi26Impl", "Unable to collect necessary methods for class ".concat(e.getClass().getName()), e);
            method4 = cls;
            constructor = method4;
            D = constructor;
            method = D;
            method2 = method;
            method3 = method2;
            this.b = cls;
            this.c = constructor;
            this.d = D;
            this.e = method;
            this.f = method2;
            this.g = method3;
            this.h = method4;
        } catch (NoSuchMethodException e3) {
            e = e3;
            Log.e("TypefaceCompatApi26Impl", "Unable to collect necessary methods for class ".concat(e.getClass().getName()), e);
            method4 = cls;
            constructor = method4;
            D = constructor;
            method = D;
            method2 = method;
            method3 = method2;
            this.b = cls;
            this.c = constructor;
            this.d = D;
            this.e = method;
            this.f = method2;
            this.g = method3;
            this.h = method4;
        }
        this.b = cls;
        this.c = constructor;
        this.d = D;
        this.e = method;
        this.f = method2;
        this.g = method3;
        this.h = method4;
    }

    public static Method D(Class cls) {
        r0 = new Class[8];
        Class cls2 = Integer.TYPE;
        r0[2] = cls2;
        r0[3] = Boolean.TYPE;
        r0[4] = cls2;
        r0[5] = cls2;
        r0[6] = cls2;
        r0[7] = FontVariationAxis[].class;
        return cls.getMethod("addFontFromAssetManager", r0);
    }

    /* JADX WARNING: Removed duplicated region for block: B:5:? A:{SYNTHETIC, Splitter: B:1:0x0006, ExcHandler: java.lang.IllegalAccessException (unused java.lang.IllegalAccessException)} */
    /* JADX WARNING: Missing block: B:4:0x0024, code:
            return null;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public Typeface C(Object obj) {
        Integer valueOf = Integer.valueOf(-1);
        try {
            Array.set(Array.newInstance(this.b, 1), 0, obj);
            return (Typeface) this.h.invoke(null, new Object[]{r2, valueOf, valueOf});
        } catch (IllegalAccessException unused) {
        }
    }

    public Method E(Class cls) {
        r0 = new Class[3];
        cls = Integer.TYPE;
        r0[1] = cls;
        r0[2] = cls;
        Method declaredMethod = Typeface.class.getDeclaredMethod("createFromFamiliesWithDefault", r0);
        declaredMethod.setAccessible(true);
        return declaredMethod;
    }
}