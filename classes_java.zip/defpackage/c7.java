package defpackage;

import android.view.Choreographer.FrameCallback;
import java.util.ArrayList;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: c7 */
public final class c7 implements FrameCallback, Runnable {
    public final /* synthetic */ d7 e;

    /* JADX WARNING: Missing block: B:11:0x0023, code:
            r4 = r2.size();
     */
    /* JADX WARNING: Missing block: B:12:0x0027, code:
            if (r1 >= r4) goto L_0x0035;
     */
    /* JADX WARNING: Missing block: B:13:0x0029, code:
            ((android.view.Choreographer.FrameCallback) r2.get(r1)).doFrame(r5);
            r1 = r1 + 1;
     */
    /* JADX WARNING: Missing block: B:14:0x0035, code:
            r2.clear();
     */
    /* JADX WARNING: Missing block: B:15:0x0038, code:
            return;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void doFrame(long j) {
        this.e.h.removeCallbacks(this);
        d7.j(this.e);
        d7 d7Var = this.e;
        synchronized (d7Var.i) {
            if (d7Var.n) {
                int i = 0;
                d7Var.n = false;
                ArrayList arrayList = d7Var.k;
                d7Var.k = d7Var.l;
                d7Var.l = arrayList;
            }
        }
    }

    public final void run() {
        d7.j(this.e);
        d7 d7Var = this.e;
        synchronized (d7Var.i) {
            if (d7Var.k.isEmpty()) {
                d7Var.g.removeFrameCallback(this);
                d7Var.n = false;
            }
        }
    }

    public c7(d7 d7Var) {
        this.e = d7Var;
    }
}