package defpackage;

import java.util.ArrayList;
import java.util.List;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: d8 */
public final class d8 implements mh0 {
    public final j8 a;
    public boolean b;

    public final nh0 f(oh0 oh0, List list, long j) {
        ArrayList h90 = new h90(list.size());
        int size = list.size();
        int i = 0;
        int i2 = 0;
        int i3 = i2;
        while (i < size) {
            ks0 e = ((hh0) list.get(i)).e(j);
            i2 = Math.max(i2, e.e);
            i3 = Math.max(i3, e.f);
            h90.add(e);
            i++;
        }
        boolean n = oh0.n();
        j8 j8Var = this.a;
        if (n) {
            this.b = true;
            j8Var.a.setValue(new ad((4294967295L & ((long) i3)) | (((long) i2) << 32)));
        } else if (!this.b) {
            j8Var.a.setValue(new ad((4294967295L & ((long) i3)) | (((long) i2) << 32)));
        }
        return oh0.O(i2, i3, vt.e, new o5(1, h90));
    }

    public final int a(g70 g70, List list, int i) {
        if (list.isEmpty()) {
            return 0;
        }
        int f = ((hh0) list.get(0)).f(i);
        int i2 = 1;
        int size = list.size() - 1;
        if (1 <= size) {
            while (true) {
                int f2 = ((hh0) list.get(i2)).f(i);
                if (f2 > f) {
                    f = f2;
                }
                if (i2 == size) {
                    break;
                }
                i2++;
            }
        }
        return f;
    }

    public final int c(g70 g70, List list, int i) {
        if (list.isEmpty()) {
            return 0;
        }
        int J = ((hh0) list.get(0)).J(i);
        int i2 = 1;
        int size = list.size() - 1;
        if (1 <= size) {
            while (true) {
                int J2 = ((hh0) list.get(i2)).J(i);
                if (J2 > J) {
                    J = J2;
                }
                if (i2 == size) {
                    break;
                }
                i2++;
            }
        }
        return J;
    }

    public final int g(g70 g70, List list, int i) {
        if (list.isEmpty()) {
            return 0;
        }
        int L = ((hh0) list.get(0)).L(i);
        int i2 = 1;
        int size = list.size() - 1;
        if (1 <= size) {
            while (true) {
                int L2 = ((hh0) list.get(i2)).L(i);
                if (L2 > L) {
                    L = L2;
                }
                if (i2 == size) {
                    break;
                }
                i2++;
            }
        }
        return L;
    }

    public final int i(g70 g70, List list, int i) {
        if (list.isEmpty()) {
            return 0;
        }
        int C = ((hh0) list.get(0)).C(i);
        int i2 = 1;
        int size = list.size() - 1;
        if (1 <= size) {
            while (true) {
                int C2 = ((hh0) list.get(i2)).C(i);
                if (C2 > C) {
                    C = C2;
                }
                if (i2 == size) {
                    break;
                }
                i2++;
            }
        }
        return C;
    }

    public d8(j8 j8Var) {
        this.a = j8Var;
    }
}