package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: az */
public abstract class az {
    public static final al a = new h90(23);

    static {
        nq0 nq0 = new nq0();
    }
}