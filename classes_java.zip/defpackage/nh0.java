package defpackage;

import java.util.Map;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: nh0 */
public interface nh0 {
    void a();

    int b();

    Map c();

    i00 d();

    int e();
}