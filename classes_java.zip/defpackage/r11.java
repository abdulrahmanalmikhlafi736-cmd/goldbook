package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: r11 */
public interface r11 {
    boolean a();

    boolean b();

    boolean c();

    Object d(tk0 tk0, m00 m00, nl nlVar);

    float e(float f);
}