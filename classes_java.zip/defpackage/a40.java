package defpackage;

import android.content.res.Resources.Theme;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: a40 */
public final class a40 {
    public final Theme a;

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof a40) {
            if (k70.p(this.a, ((a40) obj).a)) {
                return true;
            }
        }
        return false;
    }

    public final String toString() {
        StringBuilder dl1 = new dl1("Key(theme=");
        dl1.append(this.a);
        dl1.append(", id=2130968576)");
        return dl1.toString();
    }

    public final int hashCode() {
        return (this.a.hashCode() * 31) + 2130968576;
    }

    public a40(Theme theme) {
        this.a = theme;
    }
}