package defpackage;

import android.content.Context;
import android.webkit.WebView;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: a2 */
public final /* synthetic */ class a2 implements i00 {
    public final /* synthetic */ int e;
    public final /* synthetic */ i00 f;

    public final Object i(Object obj) {
        int i = this.e;
        i00 i00 = this.f;
        switch (i) {
            case 0:
                WebView webView = (WebView) obj;
                webView.getClass();
                i00.i(webView);
                return we1.a;
            case 1:
                Object obj2;
                kd1 kd1 = (kd1) obj;
                if (kd1 instanceof p10) {
                    obj2 = (Boolean) i00.i(((p10) kd1).s);
                    obj2.getClass();
                } else {
                    od.p("Node is not a GestureNode instance");
                    obj2 = null;
                }
                return obj2;
            case 2:
                g61 g61 = (g61) i00.i((l61) obj);
                synchronized (n61.c) {
                    n61.d = n61.d.f(g61.g());
                }
                return g61;
            case 3:
                Long l = (Long) obj;
                l.getClass();
                return i00.i(l);
            default:
                Context context = (Context) obj;
                context.getClass();
                return (WebView) i00.i(new di1(context));
        }
    }

    public /* synthetic */ a2(i00 i00, int i) {
        this.e = i;
        this.f = i00;
    }
}