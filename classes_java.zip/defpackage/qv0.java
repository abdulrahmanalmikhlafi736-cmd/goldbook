package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: qv0 */
public abstract class qv0 {
    public static final d0 e;

    static {
        d0 dvVar;
        Integer num = y70.a;
        if (num != null) {
            if (num.intValue() < 34) {
                dvVar = new dv();
                e = dvVar;
            }
        }
        dvVar = new Object();
        e = dvVar;
    }
}