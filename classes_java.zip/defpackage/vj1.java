package defpackage;

import android.graphics.Point;
import android.graphics.Rect;
import android.os.Build.VERSION;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.WindowInsets;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: vj1 */
public class vj1 extends dk1 {
    public static boolean n;
    public static Method o;
    public static Class p;
    public static Field q;
    public static Field r;
    public final WindowInsets c;
    public c60[] d;
    public c60 e;
    public hk1 f;
    public c60 g;
    public int h;
    public oq i;
    public int j;
    public int k;
    public Rect[][] l;
    public Rect[][] m;

    public c60 H(int i, boolean z) {
        c60 c60 = c60.e;
        int i2 = 0;
        if (i != 1) {
            c60 c602 = null;
            c60 n;
            int i3;
            if (i != 2) {
                if (i == 8) {
                    c60[] c60Arr = this.d;
                    if (c60Arr != null) {
                        c602 = c60Arr[ua0.p(8)];
                    }
                    if (c602 != null) {
                        return c602;
                    }
                    n = n();
                    c60 I = I();
                    i = n.d;
                    if (i > I.d) {
                        return c60.b(0, 0, 0, i);
                    }
                    n = this.g;
                    if (!(n == null || n.equals(c60))) {
                        i3 = this.g.d;
                        if (i3 > I.d) {
                            return c60.b(0, 0, 0, i3);
                        }
                    }
                } else if (i == 16) {
                    return m();
                } else {
                    if (i == 32) {
                        return k();
                    }
                    if (i == 64) {
                        return o();
                    }
                    if (i == 128) {
                        hk1 hk1 = this.f;
                        mq h = hk1 != null ? hk1.a.h() : h();
                        if (h != null) {
                            i = VERSION.SDK_INT;
                            int e = i >= 28 ? lq.e(h.a) : 0;
                            int g = i >= 28 ? lq.g(h.a) : 0;
                            int f = i >= 28 ? lq.f(h.a) : 0;
                            if (i >= 28) {
                                i2 = lq.d(h.a);
                            }
                            return c60.b(e, g, f, i2);
                        }
                    }
                }
            } else if (z) {
                n = I();
                c60 l = l();
                return c60.b(Math.max(n.a, l.a), 0, Math.max(n.c, l.c), Math.max(n.d, l.d));
            } else if ((this.h & 2) == 0) {
                n = n();
                hk1 hk12 = this.f;
                if (hk12 != null) {
                    c602 = hk12.a.l();
                }
                i3 = n.d;
                if (c602 != null) {
                    i3 = Math.min(i3, c602.d);
                }
                return c60.b(n.a, 0, n.c, i3);
            }
        } else if (z) {
            return c60.b(0, Math.max(I().b, n().b), 0, 0);
        } else {
            if ((this.h & 4) == 0) {
                return c60.b(0, n().b, 0, 0);
            }
        }
        return c60;
    }

    private c60 J(View view) {
        String str = "WindowInsetsCompat";
        if (VERSION.SDK_INT < 30) {
            if (!n) {
                vj1.L();
            }
            Method method = o;
            if (!(method == null || p == null)) {
                if (q != null) {
                    try {
                        Object invoke = method.invoke(view, null);
                        if (invoke == null) {
                            Log.w(str, "Failed to get visible insets. getViewRootImpl() returned null from the provided view. This means that the view is either not attached or the method has been overridden", new NullPointerException());
                            return null;
                        }
                        Rect rect = (Rect) q.get(r.get(invoke));
                        return rect != null ? c60.b(rect.left, rect.top, rect.right, rect.bottom) : null;
                    } catch (ReflectiveOperationException e) {
                        StringBuilder dl1 = new dl1("Failed to get visible insets. (Reflection error). ");
                        dl1.append(e.getMessage());
                        Log.e(str, dl1.toString(), e);
                    }
                }
            }
            return null;
        }
        throw new dl1("getVisibleInsets() should not be called on API >= 30. Use WindowInsets.isVisible() instead.");
    }

    public hk1 r(int i, int i2, int i3, int i4) {
        hk1 c = hk1.c(null, this.c);
        int i5 = VERSION.SDK_INT;
        uj1 tj1 = i5 >= 36 ? new tj1(c) : i5 >= 35 ? new sj1(c) : i5 >= 34 ? new rj1(c) : i5 >= 31 ? new qj1(c) : i5 >= 30 ? new pj1(c) : i5 >= 29 ? new oj1(c) : new nj1(c);
        tj1.h(hk1.a(n(), i, i2, i3, i4));
        tj1.f(hk1.a(l(), i, i2, i3, i4));
        return tj1.b();
    }

    private oq D(View view) {
        if (view == null) {
            return null;
        }
        Display display = view.getDisplay();
        if (display == null) {
            return null;
        }
        Point point = new Point();
        display.getRealSize(point);
        if (this.a.a.t()) {
            return oq.a(point.x, point.y, true, 0, 0, 0, 0);
        }
        int i = 0;
        ny0 u = ac.u(display, 0);
        ny0 u2 = ac.u(display, 1);
        ny0 u3 = ac.u(display, 2);
        ny0 u4 = ac.u(display, 3);
        int i2 = point.x;
        int i3 = point.y;
        int i4 = u != null ? u.b : 0;
        int i5 = u2 != null ? u2.b : 0;
        int i6 = u3 != null ? u3.b : 0;
        if (u4 != null) {
            i = u4.b;
        }
        return oq.a(i2, i3, false, i4, i5, i6, i);
    }

    private Rect[] F(c60 c60) {
        ArrayList arrayList = new ArrayList();
        int i = c60.a;
        int i2 = c60.d;
        int i3 = c60.c;
        int i4 = c60.b;
        if (i != 0) {
            arrayList.add(new Rect(0, 0, c60.a, this.j));
        }
        if (i4 != 0) {
            arrayList.add(new Rect(0, 0, this.k, i4));
        }
        if (i3 != 0) {
            i = this.k;
            arrayList.add(new Rect(i - i3, 0, i, this.j));
        }
        if (i2 != 0) {
            i = this.j;
            arrayList.add(new Rect(0, i - i2, this.k, i));
        }
        return (Rect[]) arrayList.toArray(new Rect[arrayList.size()]);
    }

    private static void L() {
        try {
            o = View.class.getDeclaredMethod("getViewRootImpl", null);
            Class cls = Class.forName("android.view.View$AttachInfo");
            p = cls;
            q = cls.getDeclaredField("mVisibleInsets");
            r = Class.forName("android.view.ViewRootImpl").getDeclaredField("mAttachInfo");
            q.setAccessible(true);
            r.setAccessible(true);
        } catch (ReflectiveOperationException e) {
            StringBuilder dl1 = new dl1("Failed to get visible insets. (Reflection error). ");
            dl1.append(e.getMessage());
            Log.e("WindowInsetsCompat", dl1.toString(), e);
        }
        n = true;
    }

    private static List<Rect> E(Rect[][] rectArr, int i) {
        Object obj = null;
        for (int i2 = 1; i2 <= 512; i2 <<= 1) {
            if ((i & i2) != 0) {
                Object obj2 = rectArr[ua0.p(i2)];
                if (obj2 != null) {
                    if (obj == null) {
                        obj = obj2;
                    } else {
                        Object obj3 = new Rect[(obj.length + obj2.length)];
                        System.arraycopy(obj, 0, obj3, 0, obj.length);
                        System.arraycopy(obj2, 0, obj3, obj.length, obj2.length);
                        obj = obj3;
                    }
                }
            }
        }
        return obj == null ? Collections.EMPTY_LIST : Arrays.asList(obj);
    }

    public void q() {
        for (int i = 1; i <= 512; i <<= 1) {
            int p = ua0.p(i);
            this.l[p] = F(i(i));
            if (i != 8) {
                this.m[p] = F(j(i));
            }
        }
    }

    public void e(hk1 hk1) {
        hk1.a.y(this.f);
        c60 c60 = this.g;
        dk1 dk1 = hk1.a;
        dk1.x(c60);
        dk1.A(this.h);
        dk1.v(this.i);
        dk1.B(this.l);
        dk1.C(this.m);
    }

    public boolean equals(Object obj) {
        if (!super.equals(obj)) {
            return false;
        }
        vj1 vj1 = (vj1) obj;
        return Objects.equals(this.g, vj1.g) && vj1.M(this.h, vj1.h);
    }

    public boolean K(int i) {
        if (!(i == 1 || i == 2)) {
            if (i == 4) {
                return false;
            }
            if (!(i == 8 || i == 128)) {
                return true;
            }
        }
        return H(i, false).equals(c60.e) ^ 1;
    }

    public final c60 n() {
        if (this.e == null) {
            WindowInsets windowInsets = this.c;
            this.e = c60.b(windowInsets.getSystemWindowInsetLeft(), windowInsets.getSystemWindowInsetTop(), windowInsets.getSystemWindowInsetRight(), windowInsets.getSystemWindowInsetBottom());
        }
        return this.e;
    }

    private c60 G(int i, boolean z) {
        c60 c60 = c60.e;
        for (int i2 = 1; i2 <= 512; i2 <<= 1) {
            if ((i & i2) != 0) {
                c60 = c60.a(c60, H(i2, z));
            }
        }
        return c60;
    }

    public void d(View view) {
        this.k = view.getWidth();
        this.j = view.getHeight();
        c60 J = J(view);
        if (J == null) {
            J = c60.e;
        }
        x(J);
    }

    public boolean u(int i) {
        for (int i2 = 1; i2 <= 512; i2 <<= 1) {
            if ((i & i2) != 0) {
                if (!K(i2)) {
                    return false;
                }
            }
        }
        return true;
    }

    public vj1(hk1 hk1, WindowInsets windowInsets) {
        super(hk1);
        this.e = null;
        this.l = new Rect[10][];
        this.m = new Rect[10][];
        this.c = windowInsets;
    }

    private c60 I() {
        hk1 hk1 = this.f;
        return hk1 != null ? hk1.a.l() : c60.e;
    }

    public void B(Rect[][] rectArr) {
        Objects.requireNonNull(rectArr);
        this.l = (Rect[][]) rectArr.clone();
    }

    public void C(Rect[][] rectArr) {
        Objects.requireNonNull(rectArr);
        this.m = (Rect[][]) rectArr.clone();
    }

    public static boolean M(int i, int i2) {
        return (i & 6) == (i2 & 6);
    }

    public List<Rect> f(int i) {
        return vj1.E(this.l, i);
    }

    public List<Rect> g(int i) {
        return vj1.E(this.m, i);
    }

    public void p(View view) {
        this.i = D(view);
    }

    public boolean t() {
        return this.c.isRound();
    }

    public c60 i(int i) {
        return G(i, false);
    }

    public c60 j(int i) {
        return G(i, true);
    }

    public void A(int i) {
        this.h = i;
    }

    public void v(oq oqVar) {
        this.i = oqVar;
    }

    public void w(c60[] c60Arr) {
        this.d = c60Arr;
    }

    public void x(c60 c60) {
        this.g = c60;
    }

    public void y(hk1 hk1) {
        this.f = hk1;
    }

    public vj1(hk1 hk1, vj1 vj1) {
        this(hk1, new WindowInsets(vj1.c));
    }
}