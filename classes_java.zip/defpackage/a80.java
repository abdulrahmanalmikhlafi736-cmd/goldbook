package defpackage;

import java.util.concurrent.CancellationException;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: a80 */
public interface a80 extends ql {
    void a(CancellationException cancellationException);

    boolean b();

    pf g(h80 h80);

    CancellationException o();

    sq r(i00 i00);

    boolean start();

    Object v(nl nlVar);

    sq w(boolean z, boolean z2, e eVar);
}