package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ul */
public abstract class ul extends q implements ql {
    public static final tl f = new tl(e3.B, new h90(6));

    public final ql k(rl rlVar) {
        rlVar.getClass();
        if (!(rlVar instanceof tl)) {
            return e3.B == rlVar ? this : null;
        } else {
            rlVar = (tl) rlVar;
            rl rlVar2 = this.e;
            if (rlVar2 != rlVar) {
                if (rlVar.f != rlVar2) {
                    return null;
                }
            }
            ql qlVar = (ql) rlVar.e.i(this);
            return qlVar != null ? qlVar : null;
        }
    }

    /* JADX WARNING: Missing block: B:12:0x0020, code:
            if (defpackage.e3.B == r3) goto L_0x0022;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final sl t(rl rlVar) {
        rlVar.getClass();
        if (rlVar instanceof tl) {
            rlVar = (tl) rlVar;
            rl rlVar2 = this.e;
            if (rlVar2 != rlVar) {
                if (rlVar.f != rlVar2) {
                    return this;
                }
            }
            if (((ql) rlVar.e.i(this)) != null) {
            }
            return this;
        }
        sl thisR = st.e;
        return thisR;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(getClass().getSimpleName());
        stringBuilder.append('@');
        stringBuilder.append(vn.y(this));
        return stringBuilder.toString();
    }

    public ul h(int i) {
        wa0.d(i);
        return new be0(this, i);
    }

    public ul() {
        super(e3.B);
    }

    public boolean f(sl slVar) {
        return (this instanceof se1) ^ 1;
    }

    public abstract void e(sl slVar, Runnable runnable);
}