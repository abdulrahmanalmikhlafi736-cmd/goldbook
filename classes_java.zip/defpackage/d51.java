package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: d51 */
public abstract class d51 {
    public static final y41 a(a51 a51, d10 d10) {
        c51 c51 = ((dh0) d10.j(fh0.a)).c;
        oy0 oy0;
        switch (a51.ordinal()) {
            case 0:
                return c51.h;
            case 1:
                return c51.e;
            case 2:
                return c51.g;
            case 3:
                return d51.b(c51.e);
            case gu0.LONG_FIELD_NUMBER /*4*/:
                return c51.a;
            case gu0.STRING_FIELD_NUMBER /*5*/:
                return d51.b(c51.a);
            case gu0.STRING_SET_FIELD_NUMBER /*6*/:
                return py0.a;
            case gu0.DOUBLE_FIELD_NUMBER /*7*/:
                return c51.d;
            case 8:
                oy0 = c51.d;
                cr crVar = z41.i;
                return oy0.b(oy0, crVar, null, null, crVar, 6);
            case 9:
                return c51.f;
            case 10:
                oy0 = c51.d;
                cr crVar2 = z41.i;
                return oy0.b(oy0, null, crVar2, crVar2, null, 9);
            case 11:
                return d51.b(c51.d);
            case 12:
                return c51.c;
            case 13:
                return vn.j;
            case 14:
                return c51.b;
            default:
                od.k();
                return null;
        }
    }

    static {
        ad0 ad0 = new ad0(new h90(11));
    }

    public static oy0 b(oy0 oy0) {
        cr crVar = z41.i;
        return oy0.b(oy0, null, null, crVar, crVar, 3);
    }
}