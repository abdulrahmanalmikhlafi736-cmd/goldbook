package defpackage;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: b01 */
public final /* synthetic */ class b01 implements i00 {
    public final /* synthetic */ int e;

    public final Object i(Object obj) {
        Object obj2 = obj;
        int i = 0;
        Object obj3 = null;
        List list;
        int intValue;
        Object obj4;
        Object obj5;
        int i2;
        al alVar;
        eb1 eb1;
        ArrayList h90;
        int size;
        Object obj6;
        float floatValue;
        d01 d01;
        d01 d012;
        Object obj7;
        rb1[] rb1Arr;
        long j;
        Object obj8;
        switch (this.e) {
            case 0:
                obj2.getClass();
                list = (List) obj2;
                obj2 = list.get(0);
                obj2 = obj2 != null ? (Integer) obj2 : null;
                obj2.getClass();
                intValue = obj2.intValue();
                obj4 = list.get(1);
                if (obj4 != null) {
                    obj3 = (Integer) obj4;
                }
                obj3.getClass();
                return new ad(dd0.b(intValue, obj3.intValue()));
            case 1:
                obj2.getClass();
                list = (List) obj2;
                obj5 = list.get(0);
                i2 = zg.j;
                Boolean bool = Boolean.FALSE;
                k70.p(obj5, bool);
                obj5 = obj5 != null ? k70.p(obj5, Boolean.FALSE) ? new ad(zg.i) : new ad(wl1.d(((Integer) obj5).intValue())) : null;
                obj5.getClass();
                long j2 = obj5.a;
                obj5 = list.get(1);
                d01 d013 = e01.x;
                k70.p(obj5, bool);
                obj5 = obj5 != null ? (xm0) d013.f.i(obj5) : null;
                obj5.getClass();
                long j3 = obj5.a;
                obj4 = list.get(2);
                if (obj4 != null) {
                    obj3 = (Float) obj4;
                }
                obj3.getClass();
                return new w41(j2, j3, obj3.floatValue());
            case 2:
                obj2.getClass();
                return new h90(((Integer) obj2).intValue());
            case 3:
                obj2.getClass();
                list = (List) obj2;
                obj2 = list.get(0);
                obj2 = obj2 != null ? (String) obj2 : null;
                obj2.getClass();
                obj4 = list.get(1);
                alVar = e01.i;
                if (!k70.p(obj4, Boolean.FALSE)) {
                    if (obj4 != null) {
                        eb1 = (eb1) ((i00) alVar.g).i(obj4);
                    }
                }
                return new me0(obj2, eb1);
            case gu0.LONG_FIELD_NUMBER /*4*/:
                obj2.getClass();
                return new h90(((Integer) obj2).intValue());
            case gu0.STRING_FIELD_NUMBER /*5*/:
                obj2.getClass();
                return new h90(((Integer) obj2).intValue());
            case gu0.STRING_SET_FIELD_NUMBER /*6*/:
                obj2.getClass();
                list = (List) obj2;
                h90 = new h90(list.size());
                size = list.size();
                while (i < size) {
                    obj6 = list.get(i);
                    obj6 = (k70.p(obj6, Boolean.FALSE) || obj6 == null) ? null : (w8) ((i00) e01.b.g).i(obj6);
                    obj6.getClass();
                    h90.add(obj6);
                    i++;
                }
                return h90;
            case gu0.DOUBLE_FIELD_NUMBER /*7*/:
                obj2.getClass();
                return new h90(((Integer) obj2).intValue());
            case 8:
                obj2.getClass();
                return new h90(((Integer) obj2).intValue());
            case 9:
                Boolean bool2 = Boolean.FALSE;
                if (k70.p(obj2, bool2)) {
                    obj5 = new ad(qb1.c);
                } else {
                    obj2.getClass();
                    List list2 = (List) obj2;
                    obj5 = list2.get(0);
                    obj5 = obj5 != null ? (Float) obj5 : null;
                    obj5.getClass();
                    floatValue = obj5.floatValue();
                    obj2 = list2.get(1);
                    d01 = e01.w;
                    k70.p(obj2, bool2);
                    if (obj2 != null) {
                        obj3 = (rb1) d01.f.i(obj2);
                    }
                    obj3.getClass();
                    obj5 = new ad(jb0.p(obj3.a, floatValue));
                }
                return obj5;
            case 10:
                obj4 = k70.p(obj2, Integer.valueOf(0)) ? new ad(8589934592L) : k70.p(obj2, Integer.valueOf(1)) ? new ad(4294967296L) : new ad(0);
                return obj4;
            case 11:
                if (k70.p(obj2, Boolean.FALSE)) {
                    obj4 = new ad(9205357640488583168L);
                } else {
                    obj2.getClass();
                    list = (List) obj2;
                    obj2 = list.get(0);
                    obj2 = obj2 != null ? (Float) obj2 : null;
                    obj2.getClass();
                    float floatValue2 = obj2.floatValue();
                    obj4 = list.get(1);
                    if (obj4 != null) {
                        obj3 = (Float) obj4;
                    }
                    obj3.getClass();
                    obj4 = new ad((((long) Float.floatToRawIntBits(floatValue2)) << 32) | (((long) Float.floatToRawIntBits(obj3.floatValue())) & 4294967295L));
                }
                return obj4;
            case 12:
                obj2.getClass();
                list = (List) obj2;
                h90 = new h90(list.size());
                size = list.size();
                while (i < size) {
                    obj6 = list.get(i);
                    obj6 = (k70.p(obj6, Boolean.FALSE) || obj6 == null) ? null : (hf0) ((i00) e01.z.g).i(obj6);
                    obj6.getClass();
                    h90.add(obj6);
                    i++;
                }
                return new if0(h90);
            case 13:
                obj2.getClass();
                String str = (String) obj2;
                Locale forLanguageTag = Locale.forLanguageTag(str);
                if (k70.p(forLanguageTag.toLanguageTag(), "und")) {
                    PrintStream printStream = System.err;
                    StringBuilder dl1 = new dl1("The language tag ");
                    dl1.append(str);
                    dl1.append(" is not well-formed. Locale is resolved to Undetermined. Note that underscore '_' is not a valid subtag delimiter and must be replaced with '-'.");
                    printStream.println(dl1.toString());
                }
                return new hf0(forLanguageTag);
            case 14:
                obj2.getClass();
                list = (List) obj2;
                obj2 = list.get(0);
                obj2 = obj2 != null ? (String) obj2 : null;
                obj2.getClass();
                obj4 = list.get(1);
                alVar = e01.i;
                if (!k70.p(obj4, Boolean.FALSE)) {
                    if (obj4 != null) {
                        eb1 = (eb1) ((i00) alVar.g).i(obj4);
                    }
                }
                return new le0(obj2, eb1);
            case 15:
                obj2.getClass();
                list = (List) obj2;
                obj5 = list.get(0);
                float f = ee0.b;
                d01 = e01.B;
                Boolean bool3 = Boolean.FALSE;
                k70.p(obj5, bool3);
                obj5 = obj5 != null ? (ee0) d01.f.i(obj5) : null;
                obj5.getClass();
                floatValue = obj5.a;
                obj6 = list.get(1);
                d012 = e01.C;
                k70.p(obj6, bool3);
                obj6 = obj6 != null ? (ge0) d012.f.i(obj6) : null;
                obj6.getClass();
                i2 = obj6.a;
                obj4 = list.get(2);
                d012 = e01.D;
                k70.p(obj4, bool3);
                if (obj4 != null) {
                    obj3 = (fe0) d012.f.i(obj4);
                }
                obj3.getClass();
                return new he0(floatValue, i2, obj3.a);
            case 16:
                obj2.getClass();
                float floatValue3 = ((Float) obj2).floatValue();
                ee0.a(floatValue3);
                return new br0(floatValue3);
            case 17:
                obj2.getClass();
                return new h90(((Integer) obj2).intValue());
            case 18:
                w8 w8Var;
                obj2.getClass();
                list = (List) obj2;
                obj2 = list.get(0);
                obj2 = obj2 != null ? (z8) obj2 : null;
                obj2.getClass();
                obj5 = list.get(2);
                obj5 = obj5 != null ? (Integer) obj5 : null;
                obj5.getClass();
                size = obj5.intValue();
                obj6 = list.get(3);
                obj6 = obj6 != null ? (Integer) obj6 : null;
                obj6.getClass();
                i2 = obj6.intValue();
                obj7 = list.get(4);
                obj7 = obj7 != null ? (String) obj7 : null;
                obj7.getClass();
                al alVar2;
                switch (obj2.ordinal()) {
                    case 0:
                        obj4 = list.get(1);
                        alVar2 = e01.g;
                        if (!k70.p(obj4, Boolean.FALSE)) {
                            if (obj4 != null) {
                                obj3 = (fq0) ((i00) alVar2.g).i(obj4);
                            }
                        }
                        obj3.getClass();
                        w8Var = new w8(obj3, size, i2, obj7);
                        break;
                    case 1:
                        obj4 = list.get(1);
                        alVar2 = e01.h;
                        if (!k70.p(obj4, Boolean.FALSE)) {
                            if (obj4 != null) {
                                obj3 = (i71) ((i00) alVar2.g).i(obj4);
                            }
                        }
                        obj3.getClass();
                        w8Var = new w8(obj3, size, i2, obj7);
                        break;
                    case 2:
                        obj4 = list.get(1);
                        alVar2 = e01.c;
                        if (!k70.p(obj4, Boolean.FALSE)) {
                            if (obj4 != null) {
                                obj3 = (jg1) ((i00) alVar2.g).i(obj4);
                            }
                        }
                        obj3.getClass();
                        w8Var = new w8(obj3, size, i2, obj7);
                        break;
                    case 3:
                        obj4 = list.get(1);
                        alVar2 = e01.d;
                        if (!k70.p(obj4, Boolean.FALSE)) {
                            if (obj4 != null) {
                                obj3 = (of1) ((i00) alVar2.g).i(obj4);
                            }
                        }
                        obj3.getClass();
                        w8Var = new w8(obj3, size, i2, obj7);
                        break;
                    case gu0.LONG_FIELD_NUMBER /*4*/:
                        obj4 = list.get(1);
                        alVar2 = e01.e;
                        if (!k70.p(obj4, Boolean.FALSE)) {
                            if (obj4 != null) {
                                obj3 = (me0) ((i00) alVar2.g).i(obj4);
                            }
                        }
                        obj3.getClass();
                        w8Var = new w8(obj3, size, i2, obj7);
                        break;
                    case gu0.STRING_FIELD_NUMBER /*5*/:
                        obj4 = list.get(1);
                        alVar2 = e01.f;
                        if (!k70.p(obj4, Boolean.FALSE)) {
                            if (obj4 != null) {
                                obj3 = (le0) ((i00) alVar2.g).i(obj4);
                            }
                        }
                        obj3.getClass();
                        w8Var = new w8(obj3, size, i2, obj7);
                        break;
                    case gu0.STRING_SET_FIELD_NUMBER /*6*/:
                        obj4 = list.get(1);
                        if (obj4 != null) {
                            obj3 = (String) obj4;
                        }
                        obj3.getClass();
                        w8Var = new w8(new dl1(obj3), size, i2, obj7);
                        break;
                    default:
                        od.k();
                        break;
                }
                obj3 = w8Var;
                return obj3;
            case 19:
                obj2.getClass();
                return new h90(((Integer) obj2).intValue());
            case 20:
                if (obj2 != null) {
                    obj3 = (String) obj2;
                }
                obj3.getClass();
                return new dl1(obj3);
            case 21:
                if (obj2 != null) {
                    obj3 = (String) obj2;
                }
                obj3.getClass();
                return new dl1(obj3);
            case 22:
                gb1 gb1;
                obj2.getClass();
                list = (List) obj2;
                obj2 = list.get(0);
                d01 d014 = e01.q;
                Boolean bool4 = Boolean.FALSE;
                k70.p(obj2, bool4);
                obj2 = obj2 != null ? (na1) d014.f.i(obj2) : null;
                obj2.getClass();
                intValue = obj2.a;
                Object obj9 = list.get(1);
                d014 = e01.r;
                k70.p(obj9, bool4);
                obj9 = obj9 != null ? (sa1) d014.f.i(obj9) : null;
                obj9.getClass();
                int i3 = obj9.a;
                Object obj10 = list.get(2);
                rb1Arr = qb1.b;
                d01 d015 = e01.v;
                k70.p(obj10, bool4);
                obj10 = obj10 != null ? (qb1) d015.f.i(obj10) : null;
                obj10.getClass();
                j = obj10.a;
                Object obj11 = list.get(3);
                wa1 wa1 = wa1.c;
                wa1 wa12 = (k70.p(obj11, bool4) || obj11 == null) ? null : (wa1) ((i00) e01.l.g).i(obj11);
                obj8 = list.get(4);
                ss0 ss0 = (k70.p(obj8, bool4) || obj8 == null) ? null : (ss0) ((i00) vd1.m.g).i(obj8);
                obj8 = list.get(5);
                he0 he0 = he0.d;
                he0 he02 = (k70.p(obj8, bool4) || obj8 == null) ? null : (he0) ((i00) e01.A.g).i(obj8);
                obj7 = list.get(6);
                obj7 = (k70.p(obj7, bool4) || obj7 == null) ? null : (ce0) ((i00) vd1.o.g).i(obj7);
                obj7.getClass();
                int i4 = obj7.a;
                obj6 = list.get(7);
                d012 = e01.s;
                k70.p(obj6, bool4);
                obj6 = obj6 != null ? (o30) d012.f.i(obj6) : null;
                obj6.getClass();
                i2 = obj6.a;
                obj4 = list.get(8);
                alVar = vd1.p;
                if (!(k70.p(obj4, bool4) || obj4 == null)) {
                    gb1 = (gb1) ((i00) alVar.g).i(obj4);
                }
                return new fq0(intValue, i3, j, wa12, ss0, he02, i4, i2, gb1);
            case 23:
                w41 w41;
                obj2.getClass();
                list = (List) obj2;
                obj2 = list.get(0);
                i = zg.j;
                Boolean bool5 = Boolean.FALSE;
                k70.p(obj2, bool5);
                obj2 = obj2 != null ? obj2.equals(bool5) ? new ad(zg.i) : new ad(wl1.d(((Integer) obj2).intValue())) : null;
                obj2.getClass();
                long j4 = obj2.a;
                obj2 = list.get(1);
                rb1Arr = qb1.b;
                i00 i00 = e01.v.f;
                k70.p(obj2, bool5);
                obj2 = obj2 != null ? (qb1) i00.i(obj2) : null;
                obj2.getClass();
                j = obj2.a;
                obj2 = list.get(2);
                pz pzVar = pz.f;
                pz pzVar2 = (k70.p(obj2, bool5) || obj2 == null) ? null : (pz) ((i00) e01.m.g).i(obj2);
                obj2 = list.get(3);
                nz nzVar = (k70.p(obj2, bool5) || obj2 == null) ? null : (nz) ((i00) e01.t.g).i(obj2);
                obj2 = list.get(4);
                oz ozVar = (k70.p(obj2, bool5) || obj2 == null) ? null : (oz) ((i00) e01.u.g).i(obj2);
                obj2 = list.get(6);
                String str2 = obj2 != null ? (String) obj2 : null;
                obj2 = list.get(7);
                k70.p(obj2, bool5);
                obj2 = obj2 != null ? (qb1) i00.i(obj2) : null;
                obj2.getClass();
                long j5 = obj2.a;
                obj2 = list.get(8);
                fb fbVar = (k70.p(obj2, bool5) || obj2 == null) ? null : (fb) ((i00) e01.n.g).i(obj2);
                obj2 = list.get(9);
                va1 va1 = (k70.p(obj2, bool5) || obj2 == null) ? null : (va1) ((i00) e01.k.g).i(obj2);
                obj2 = list.get(10);
                if0 if0 = if0.g;
                if0 if02 = (k70.p(obj2, bool5) || obj2 == null) ? null : (if0) ((i00) e01.y.g).i(obj2);
                obj2 = list.get(11);
                k70.p(obj2, bool5);
                obj8 = obj2 != null ? obj2.equals(bool5) ? new ad(zg.i) : new ad(wl1.d(((Integer) obj2).intValue())) : null;
                obj8.getClass();
                long j6 = obj8.a;
                obj8 = list.get(12);
                qa1 qa1 = (k70.p(obj8, bool5) || obj8 == null) ? null : (qa1) ((i00) e01.j.g).i(obj8);
                obj4 = list.get(13);
                w41 w412 = w41.d;
                al alVar3 = e01.o;
                if (!(k70.p(obj4, bool5) || obj4 == null)) {
                    w41 = (w41) ((i00) alVar3.g).i(obj4);
                }
                return new i71(j4, j, pzVar2, nzVar, ozVar, null, str2, j5, fbVar, va1, if02, j6, qa1, w41, 49184);
            case 24:
                obj2.getClass();
                list = (List) obj2;
                obj2 = list.get(0);
                obj2 = obj2 != null ? (Boolean) obj2 : null;
                obj2.getClass();
                boolean booleanValue = obj2.booleanValue();
                obj4 = list.get(1);
                alVar = vd1.n;
                if (!k70.p(obj4, Boolean.FALSE)) {
                    if (obj4 != null) {
                        obj3 = (ot) ((i00) alVar.g).i(obj4);
                    }
                }
                obj3.getClass();
                return new ba0(obj3.a, booleanValue);
            case 25:
                obj2.getClass();
                return new h90(((Integer) obj2).intValue());
            case 26:
                obj2.getClass();
                return new h90(((Integer) obj2).intValue());
            case 27:
                obj2.getClass();
                list = (List) obj2;
                obj5 = list.get(0);
                obj5 = (k70.p(obj5, Boolean.FALSE) || obj5 == null) ? null : (fb1) ((i00) vd1.q.g).i(obj5);
                obj5.getClass();
                size = obj5.a;
                obj4 = list.get(1);
                if (obj4 != null) {
                    obj3 = (Boolean) obj4;
                }
                obj3.getClass();
                return new ba0(size, obj3.booleanValue());
            case 28:
                obj2.getClass();
                return new h90(((Integer) obj2).intValue());
            default:
                return new h90(((Integer) obj2).intValue());
        }
    }

    public /* synthetic */ b01(int i) {
        this.e = i;
    }
}