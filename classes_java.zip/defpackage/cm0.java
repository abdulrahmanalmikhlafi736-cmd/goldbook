package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cm0 */
public final class cm0 {
    public li0 a;
    public int b;
    public qk0 c;
    public qk0 d;
    public boolean e;
    public final /* synthetic */ em0 f;

    public final boolean a(int i, int i2) {
        qk0 qk0 = this.c;
        int i3 = this.b;
        ki0 ki0 = (ki0) qk0.e[i + i3];
        ki0 ki02 = (ki0) this.d.e[i3 + i2];
        if (!k70.p(ki0, ki02)) {
            if (ki0.getClass() != ki02.getClass()) {
                return false;
            }
        }
        return true;
    }

    public cm0(em0 em0, li0 li0, int i, qk0 qk0, qk0 qk02, boolean z) {
        this.f = em0;
        this.a = li0;
        this.b = i;
        this.c = qk0;
        this.d = qk02;
        this.e = z;
    }
}