package defpackage;

import android.view.autofill.AutofillManager$AutofillCallback;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: d2 */
public final class d2 implements n00 {
    public final /* synthetic */ wi1 e;
    public final /* synthetic */ boolean f;
    public final /* synthetic */ ui1 g;
    public final /* synthetic */ i00 h;
    public final /* synthetic */ i00 i;
    public final /* synthetic */ w1 j;
    public final /* synthetic */ v1 k;
    public final /* synthetic */ i00 l;

    public final Object c(Object obj, Object obj2, Object obj3) {
        oc ocVar = (oc) obj;
        d10 d10 = (d10) obj2;
        int intValue = ((Number) obj3).intValue();
        ocVar.getClass();
        long j = ocVar.b;
        if ((intValue & 6) == 0) {
            intValue |= ((AutofillManager$AutofillCallback) d10) != null ? 4 : 2;
        }
        if ((intValue & 19) == 18) {
            if (d10.A()) {
                d10.R();
                return we1.a;
            }
        }
        intValue = -2;
        int i = sk.f(j) ? -1 : -2;
        if (sk.e(j)) {
            intValue = -1;
        }
        zi1.b(this.e, new xo0(i, intValue), this.f, this.g, this.h, this.i, this.j, this.k, this.l, d10, 384);
        return we1.a;
    }

    public d2(wi1 wi1, boolean z, ui1 ui1, i00 i00, i00 i002, w1 w1Var, v1 v1Var, i00 i003) {
        this.e = wi1;
        this.f = z;
        this.g = ui1;
        this.h = i00;
        this.i = i002;
        this.j = w1Var;
        this.k = v1Var;
        this.l = i003;
    }
}