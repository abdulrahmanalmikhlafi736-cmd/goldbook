package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: le */
public interface le extends ml {
    mt j(Object obj, n00 n00);

    boolean l(Throwable th);

    void x(Object obj);
}