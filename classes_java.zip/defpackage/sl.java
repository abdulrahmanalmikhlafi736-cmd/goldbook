package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: sl */
public interface sl {
    sl i(sl slVar);

    ql k(rl rlVar);

    Object p(m00 m00, Object obj);

    sl t(rl rlVar);
}