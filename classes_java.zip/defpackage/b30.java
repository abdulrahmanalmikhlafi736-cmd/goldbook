package defpackage;

import java.util.List;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: b30 */
public final class b30 {
    public final n90 a;
    public boolean b;
    public boolean c;
    public boolean d;
    public boolean e;
    public final ak0 f = new ak0();
    public final lm0 g = new lm0();
    public final wj0 h = new h90(10);

    public final void a(long j, List list, boolean z) {
        wj0 wj0;
        int i;
        long j2 = j;
        int size = list.size();
        lm0 lm0 = this.g;
        lm0 lm02 = lm0;
        boolean z2 = true;
        int i2 = 0;
        while (true) {
            wj0 = this.h;
            if (i2 >= size) {
                break;
            }
            li0 li0 = (li0) list.get(i2);
            if (li0.r) {
                lm0 lm03;
                li0.q = new al(6, this, li0);
                if (z2) {
                    Object obj;
                    qk0 qk0 = lm02.a;
                    Object[] objArr = qk0.e;
                    int i3 = qk0.g;
                    for (i = 0; i < i3; i++) {
                        obj = objArr[i];
                        if (k70.p(((bm0) obj).c, li0)) {
                            break;
                        }
                    }
                    obj = null;
                    lm03 = (bm0) obj;
                    if (lm03 != null) {
                        lm03.i = true;
                        lm03.d.b(j2);
                        if (z) {
                            Object d = wj0.d(j2);
                            if (d == null) {
                                d = new ak0();
                                wj0.f(j2, d);
                            }
                            ((ak0) d).a(lm03);
                        }
                        lm02 = lm03;
                    } else {
                        z2 = false;
                    }
                }
                lm03 = new bm0(li0);
                lm03.d.b(j2);
                if (z) {
                    Object d2 = wj0.d(j2);
                    if (d2 == null) {
                        d2 = new ak0();
                        wj0.f(j2, d2);
                    }
                    ((ak0) d2).a(lm03);
                }
                lm02.a.b(lm03);
                lm02 = lm03;
            }
            i2++;
        }
        if (z) {
            long[] jArr = wj0.b;
            Object[] objArr2 = wj0.c;
            long[] jArr2 = wj0.a;
            size = jArr2.length - 2;
            if (size >= 0) {
                int i4 = 0;
                while (true) {
                    long[] jArr3;
                    long j3 = jArr2[i4];
                    if (((((~j3) << 7) & j3) & -9187201950435737472L) != -9187201950435737472L) {
                        int i5 = 8;
                        int i6 = 8 - ((~(i4 - size)) >>> 31);
                        int i7 = 0;
                        while (i7 < i6) {
                            long j4;
                            if ((255 & j3) < 128) {
                                int i8 = (i4 << 3) + i7;
                                long j5 = jArr[i8];
                                ak0 ak0 = (ak0) objArr2[i8];
                                qk0 qk02 = lm0.a;
                                j4 = i5;
                                Object[] objArr3 = qk02.e;
                                i = qk02.g;
                                jArr3 = jArr;
                                int i9 = 0;
                                while (i9 < i) {
                                    int i10 = i9;
                                    ((bm0) objArr3[i9]).f(j5, ak0);
                                    i9 = i10 + 1;
                                }
                            } else {
                                jArr3 = jArr;
                                j4 = i5;
                            }
                            j3 >>= j4;
                            i7++;
                            i5 = j4;
                            jArr = jArr3;
                        }
                        jArr3 = jArr;
                        if (i6 != i5) {
                            break;
                        }
                    } else {
                        jArr3 = jArr;
                    }
                    if (i4 == size) {
                        break;
                    }
                    i4++;
                    jArr = jArr3;
                }
            }
        }
        wj0.a();
    }

    public final boolean b(e70 e70, boolean z) {
        xf0 xf0 = e70.a;
        n90 n90 = this.a;
        lm0 lm0 = this.g;
        boolean a = lm0.a(xf0, n90, e70, z);
        qk0 qk0 = lm0.a;
        if (!a) {
            return false;
        }
        a = true;
        this.b = true;
        Object[] objArr = qk0.e;
        int i = qk0.g;
        int i2 = 0;
        int i3 = i2;
        while (i2 < i) {
            if (!((bm0) objArr[i2]).e(e70, z)) {
                if (i3 == 0) {
                    i3 = false;
                    i2++;
                }
            }
            i3 = true;
            i2++;
        }
        Object[] objArr2 = qk0.e;
        int i4 = qk0.g;
        int i5 = 0;
        i = i5;
        while (i5 < i4) {
            if (!((bm0) objArr2[i5]).d(e70)) {
                if (i == 0) {
                    i = false;
                    i5++;
                }
            }
            i = true;
            i5++;
        }
        lm0.b(e70);
        if (i == 0) {
            if (i3 == 0) {
                a = false;
            }
        }
        this.b = false;
        if (this.e) {
            this.e = false;
            ak0 ak0 = this.f;
            int i6 = ak0.b;
            for (i4 = 0; i4 < i6; i4++) {
                d((li0) ak0.f(i4));
            }
            ak0.d();
        }
        if (this.c) {
            this.c = false;
            c();
        }
        if (this.d) {
            this.d = false;
            lm0.a.g();
        }
        return a;
    }

    public final void d(li0 li0) {
        if (this.b) {
            this.e = true;
            this.f.a(li0);
            return;
        }
        lm0 lm0 = this.g;
        ak0 ak0 = lm0.b;
        ak0.d();
        ak0.a(lm0);
        while (ak0.i()) {
            lm0 = (lm0) ak0.k(ak0.b - 1);
            int i = 0;
            while (true) {
                qk0 qk0 = lm0.a;
                if (i < qk0.g) {
                    bm0 bm0 = (bm0) qk0.e[i];
                    if (k70.p(bm0.c, li0)) {
                        lm0.a.j(bm0);
                        bm0.c();
                    } else {
                        ak0.a(bm0);
                        i++;
                    }
                }
            }
        }
    }

    public final void c() {
        if (this.b) {
            this.c = true;
            return;
        }
        lm0 lm0 = this.g;
        qk0 qk0 = lm0.a;
        Object[] objArr = qk0.e;
        int i = qk0.g;
        for (int i2 = 0; i2 < i; i2++) {
            ((bm0) objArr[i2]).c();
        }
        if (this.d) {
            this.d = true;
        } else {
            lm0.a.g();
        }
    }

    public b30(n90 n90) {
        this.a = n90;
    }
}