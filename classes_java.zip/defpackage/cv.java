package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cv */
public final class cv {
    public final yv a;

    /* JADX WARNING: Missing block: B:9:0x001a, code:
            if (defpackage.k70.p(r1.a, r2.a) == false) goto L_0x001c;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean equals(Object obj) {
        if (this != obj) {
            if (obj instanceof cv) {
                cv cvVar = (cv) obj;
                if (Float.compare(0.0f, 0.0f) != 0) {
                }
            }
            return false;
        }
        return true;
    }

    public final String toString() {
        StringBuilder dl1 = new dl1("Fade(alpha=0.0, animationSpec=");
        dl1.append(this.a);
        dl1.append(')');
        return dl1.toString();
    }

    public final int hashCode() {
        return this.a.hashCode() + (Float.floatToIntBits(0.0f) * 31);
    }

    public cv(yv yvVar) {
        this.a = yvVar;
    }
}