package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: a3 */
public final /* synthetic */ class a3 implements m00 {
    public final /* synthetic */ m00 e;
    public final /* synthetic */ m00 f;
    public final /* synthetic */ long g;
    public final /* synthetic */ long h;
    public final /* synthetic */ long i;
    public final /* synthetic */ pi j;

    public final Object f(Object obj, Object obj2) {
        d10 d10 = (d10) obj;
        int intValue = ((Integer) obj2).intValue();
        if (d10.O(intValue & 1, (intValue & 3) != 2)) {
            mi0 C = ac.C(ji0.a, d3.a);
            ph a = nh.a(zi1.b, e3.q, d10, 0);
            long j = d10.T;
            int i = (int) (j ^ (j >>> 32));
            qr0 l = d10.l();
            C = vn.I(d10, C);
            ij.c.getClass();
            dk dkVar = hj.b;
            d10.Z();
            if (d10.S) {
                d10.k(dkVar);
            } else {
                d10.j0();
            }
            s7 s7Var = hj.f;
            mc0.B(s7Var, d10, a);
            s7 s7Var2 = hj.e;
            mc0.B(s7Var2, d10, l);
            Integer valueOf = Integer.valueOf(i);
            s7 s7Var3 = hj.g;
            mc0.p(d10, valueOf, s7Var3);
            i4 i4Var = hj.h;
            mc0.w(d10, i4Var);
            s7 s7Var4 = hj.d;
            mc0.B(s7Var4, d10, C);
            d10.W(346092326);
            d10.p(false);
            m00 m00 = this.e;
            if (m00 == null) {
                d10.W(346396529);
                d10.p(false);
            } else {
                d10.W(346396530);
                nb0.b(this.g, me1.a(zi1.k, d10), vd1.A(71284337, new c3(0, m00), d10), d10, 384);
                d10.p(false);
            }
            m00 = this.f;
            if (m00 == null) {
                d10.W(347174009);
                d10.p(false);
            } else {
                d10.W(347174010);
                nb0.b(this.h, me1.a(zi1.m, d10), vd1.A(705583346, new c3(1, m00), d10), d10, 384);
                d10.p(false);
            }
            f30 f30 = new f30(e3.s);
            mh0 d = ic.d(e3.f, false);
            j = d10.T;
            i = (int) (j ^ (j >>> 32));
            l = d10.l();
            mi0 I = vn.I(d10, f30);
            d10.Z();
            if (d10.S) {
                d10.k(dkVar);
            } else {
                d10.j0();
            }
            mc0.B(s7Var, d10, d);
            mc0.B(s7Var2, d10, l);
            mc0.p(d10, Integer.valueOf(i), s7Var3);
            mc0.w(d10, i4Var);
            mc0.B(s7Var4, d10, I);
            d10 d102 = d10;
            nb0.b(this.i, me1.a(zi1.g, d10), this.j, d102, 0);
            d10 = d102;
            d10.p(true);
            d10.p(true);
        } else {
            d10.R();
        }
        return we1.a;
    }

    public /* synthetic */ a3(m00 m00, m00 m002, long j, long j2, long j3, long j4, pi piVar) {
        this.e = m00;
        this.f = m002;
        this.g = j2;
        this.h = j3;
        this.i = j4;
        this.j = piVar;
    }
}