package defpackage;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.Set;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: aa */
public final class aa implements Collection, Set, w80, y80 {
    public int[] e = k70.j;
    public Object[] f = k70.l;
    public int g;

    public final boolean add(Object obj) {
        int v;
        int i;
        int i2 = this.g;
        if (obj == null) {
            v = ac.v(this, null, 0);
            i = 0;
        } else {
            v = obj.hashCode();
            i = v;
            v = ac.v(this, obj, v);
        }
        if (v >= 0) {
            return false;
        }
        v = ~v;
        int[] iArr = this.e;
        if (i2 >= iArr.length) {
            int i3 = 8;
            if (i2 >= 8) {
                i3 = (i2 >> 1) + i2;
            } else if (i2 < 4) {
                i3 = 4;
            }
            Object[] objArr = this.f;
            int[] iArr2 = new int[i3];
            this.e = iArr2;
            this.f = new Object[i3];
            if (i2 != this.g) {
                throw new ConcurrentModificationException();
            } else if (iArr2.length != 0) {
                ba.Z(iArr, iArr2, 0, iArr.length, 6);
                ba.a0(objArr, this.f, 0, objArr.length, 6);
            }
        }
        if (v < i2) {
            int[] iArr3 = this.e;
            int i4 = v + 1;
            ba.W(iArr3, iArr3, i4, v, i2);
            Object[] objArr2 = this.f;
            ba.Y(objArr2, objArr2, i4, v, i2);
        }
        int i5 = this.g;
        if (i2 == i5) {
            int[] iArr4 = this.e;
            if (v < iArr4.length) {
                iArr4[v] = i;
                this.f[v] = obj;
                this.g = i5 + 1;
                return true;
            }
        }
        throw new ConcurrentModificationException();
    }

    public final Object a(int i) {
        int i2 = this.g;
        Object[] objArr = this.f;
        Object obj = objArr[i];
        if (i2 <= 1) {
            clear();
            return obj;
        }
        int i3 = i2 - 1;
        int[] iArr = this.e;
        int i4 = 8;
        if (iArr.length <= 8 || i2 >= iArr.length / 3) {
            if (i < i3) {
                int i5 = i + 1;
                ba.W(iArr, iArr, i, i5, i2);
                Object[] objArr2 = this.f;
                ba.Y(objArr2, objArr2, i, i5, i2);
            }
            this.f[i3] = null;
        } else {
            if (i2 > 8) {
                i4 = i2 + (i2 >> 1);
            }
            int[] iArr2 = new int[i4];
            this.e = iArr2;
            this.f = new Object[i4];
            if (i > 0) {
                ba.Z(iArr, iArr2, 0, i, 6);
                ba.a0(objArr, this.f, 0, i, 6);
            }
            if (i < i3) {
                i4 = i + 1;
                ba.W(iArr, this.e, i, i4, i2);
                ba.Y(objArr, this.f, i, i4, i2);
            }
        }
        if (i2 == this.g) {
            this.g = i3;
            return obj;
        }
        throw new ConcurrentModificationException();
    }

    public final boolean addAll(Collection collection) {
        collection.getClass();
        int size = collection.size() + this.g;
        int i = this.g;
        int[] iArr = this.e;
        int i2 = 0;
        if (iArr.length < size) {
            Object[] objArr = this.f;
            int[] iArr2 = new int[size];
            this.e = iArr2;
            this.f = new Object[size];
            if (i > 0) {
                ba.Z(iArr, iArr2, 0, i, 6);
                ba.a0(objArr, this.f, 0, this.g, 6);
            }
        }
        if (this.g == i) {
            for (Object add : collection) {
                i2 |= add(add);
            }
            return i2;
        }
        throw new ConcurrentModificationException();
    }

    public final String toString() {
        if (isEmpty()) {
            return "{}";
        }
        StringBuilder h90 = new h90(this.g * 14);
        h90.append('{');
        int i = this.g;
        for (int i2 = 0; i2 < i; i2++) {
            if (i2 > 0) {
                h90.append(", ");
            }
            aa aaVar = this.f[i2];
            if (aaVar != this) {
                h90.append(aaVar);
            } else {
                h90.append("(this Set)");
            }
        }
        h90.append('}');
        return h90.toString();
    }

    /* JADX WARNING: Removed duplicated region for block: B:17:? A:{SYNTHETIC, Splitter: B:8:0x0015, ExcHandler: java.lang.NullPointerException (unused java.lang.NullPointerException)} */
    /* JADX WARNING: Missing block: B:16:0x002c, code:
            return false;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Set) || this.g != ((Set) obj).size()) {
            return false;
        }
        try {
            int i = this.g;
            for (int i2 = 0; i2 < i; i2++) {
                if (!((Set) obj).contains(this.f[i2])) {
                    return false;
                }
            }
            return true;
        } catch (NullPointerException unused) {
        }
    }

    public final Object[] toArray(Object[] objArr) {
        objArr.getClass();
        int i = this.g;
        if (objArr.length < i) {
            objArr = (Object[]) Array.newInstance(objArr.getClass().getComponentType(), i);
        } else if (objArr.length > i) {
            objArr[i] = null;
        }
        ba.Y(this.f, objArr, 0, 0, this.g);
        return objArr;
    }

    public final boolean retainAll(Collection collection) {
        collection.getClass();
        boolean z = false;
        for (int i = this.g - 1; -1 < i; i--) {
            if (!tg.P(collection, this.f[i])) {
                a(i);
                z = true;
            }
        }
        return z;
    }

    public final boolean containsAll(Collection collection) {
        collection.getClass();
        for (Object contains : collection) {
            if (!contains(contains)) {
                return false;
            }
        }
        return true;
    }

    public final void clear() {
        if (this.g != 0) {
            this.e = k70.j;
            this.f = k70.l;
            this.g = 0;
        }
        if (this.g != 0) {
            throw new ConcurrentModificationException();
        }
    }

    public final boolean remove(Object obj) {
        int v = obj == null ? ac.v(this, null, 0) : ac.v(this, obj, obj.hashCode());
        if (v < 0) {
            return false;
        }
        a(v);
        return true;
    }

    public final boolean removeAll(Collection collection) {
        collection.getClass();
        int i = 0;
        for (Object remove : collection) {
            i |= remove(remove);
        }
        return i;
    }

    public final boolean contains(Object obj) {
        return (obj == null ? ac.v(this, null, 0) : ac.v(this, obj, obj.hashCode())) >= 0;
    }

    public final int hashCode() {
        int[] iArr = this.e;
        int i = 0;
        int i2 = 0;
        while (i < this.g) {
            i2 += iArr[i];
            i++;
        }
        return i2;
    }

    public final boolean isEmpty() {
        return this.g <= 0;
    }

    public final Iterator iterator() {
        return new v9(this);
    }

    public final int size() {
        return this.g;
    }

    public final Object[] toArray() {
        return ba.b0(this.f, 0, this.g);
    }
}