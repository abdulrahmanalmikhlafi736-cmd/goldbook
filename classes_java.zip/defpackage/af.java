package defpackage;

import java.util.ArrayList;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: af */
public abstract class af implements x00 {
    public final sl e;
    public final int f;
    public final gd g;
    public final tw h;

    public final Object b(uw uwVar, ml mlVar) {
        cm e;
        int i = this.f;
        cm cmVar = cm.e;
        we1 we1 = we1.a;
        if (i == -3) {
            sl e2 = mlVar.e();
            Boolean bool = Boolean.FALSE;
            o9 h90 = new h90(14);
            sl slVar = this.e;
            Object i2 = !((Boolean) slVar.p(h90, bool)).booleanValue() ? e2.i(slVar) : j70.D(e2, slVar, false);
            if (k70.p(i2, e2)) {
                e = e(uwVar, mlVar);
                if (e == cmVar) {
                    return e;
                }
            }
            e3 e3Var = e3.B;
            if (k70.p(i2.k(e3Var), e2.k(e3Var))) {
                Object uwVar2;
                e2 = mlVar.e();
                if (!(uwVar2 instanceof a31)) {
                    if (!(uwVar2 instanceof om0)) {
                        uwVar2 = new g8(uwVar2, e2);
                    }
                }
                e = zi1.L(i2, uwVar2, gh0.U(i2), new ze(this, null, 1), mlVar);
                if (e == cmVar) {
                    return e;
                }
            }
        }
        e = vd1.i(new d(uwVar2, this, null, 3), mlVar);
        if (e != cmVar) {
            e = we1;
        }
        return e == cmVar ? e : we1;
    }

    public final String f() {
        StringBuilder dl1;
        ArrayList h90 = new h90(4);
        sl slVar = st.e;
        sl slVar2 = this.e;
        if (slVar2 != slVar) {
            dl1 = new dl1("context=");
            dl1.append(slVar2);
            h90.add(dl1.toString());
        }
        int i = this.f;
        if (i != -3) {
            dl1 = new dl1("capacity=");
            dl1.append(i);
            h90.add(dl1.toString());
        }
        gd gdVar = gd.e;
        gd gdVar2 = this.g;
        if (gdVar2 != gdVar) {
            dl1 = new dl1("onBufferOverflow=");
            dl1.append(gdVar2);
            h90.add(dl1.toString());
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(getClass().getSimpleName());
        stringBuilder.append('[');
        stringBuilder.append(tg.V(h90, ", ", null, null, null, 62));
        stringBuilder.append(']');
        return stringBuilder.toString();
    }

    public final tw c(sl slVar, int i, gd gdVar) {
        sl slVar2 = this.e;
        slVar = slVar.i(slVar2);
        gd gdVar2 = gd.e;
        gd gdVar3 = this.g;
        int i2 = this.f;
        if (gdVar == gdVar2) {
            if (i2 != -3) {
                if (i != -3) {
                    if (i2 != -2) {
                        if (i != -2) {
                            i += i2;
                            if (i < 0) {
                                i = Integer.MAX_VALUE;
                            }
                        }
                    }
                }
                i = i2;
            }
            gdVar = gdVar3;
        }
        return (k70.p(slVar, slVar2) && i == i2 && gdVar == gdVar3) ? this : a(slVar, i, gdVar);
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.h);
        stringBuilder.append(" -> ");
        stringBuilder.append(f());
        return stringBuilder.toString();
    }

    public af(tw twVar, sl slVar, int i, gd gdVar) {
        this.e = slVar;
        this.f = i;
        this.g = gdVar;
        this.h = twVar;
    }

    public tw d() {
        return null;
    }

    public abstract af a(sl slVar, int i, gd gdVar);

    public abstract Object e(uw uwVar, ml mlVar);
}