package defpackage;

import android.widget.FrameLayout.LayoutParams;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: b2 */
public final /* synthetic */ class b2 implements m00 {
    public final /* synthetic */ int e = 1;
    public final /* synthetic */ boolean f;
    public final /* synthetic */ i00 g;
    public final /* synthetic */ Object h;
    public final /* synthetic */ Object i;
    public final /* synthetic */ Object j;
    public final /* synthetic */ Object k;
    public final /* synthetic */ Object l;
    public final /* synthetic */ Object m;
    public final /* synthetic */ Object n;

    public final Object f(Object obj, Object obj2) {
        int i = this.e;
        we1 we1 = we1.a;
        Object obj3 = this.n;
        Object obj4 = this.m;
        Object obj5 = this.l;
        Object obj6 = this.k;
        Object obj7 = this.j;
        Object obj8 = this.i;
        Object obj9 = this.h;
        switch (i) {
            case 0:
                wi1 wi1 = (wi1) obj9;
                LayoutParams layoutParams = (LayoutParams) obj8;
                ui1 ui1 = (ui1) obj7;
                i00 i00 = (i00) obj6;
                w1 w1Var = (w1) obj4;
                v1 v1Var = (v1) obj3;
                i00 i002 = (i00) obj5;
                d10 d10 = (d10) obj;
                ((Integer) obj2).getClass();
                int s = wc0.s(385);
                zi1.b(wi1, layoutParams, this.f, ui1, this.g, i00, w1Var, v1Var, i002, d10, s);
                return we1;
            default:
                mi0 mi0 = (mi0) obj9;
                sc0 sc0 = (sc0) obj8;
                up0 up0 = (up0) obj7;
                p9 p9Var = (p9) obj6;
                mb mbVar = (mb) obj5;
                jo joVar = (jo) obj4;
                x5 x5Var = (x5) obj3;
                d10 d102 = (d10) obj;
                ((Integer) obj2).getClass();
                int s2 = wc0.s(24961);
                ua0.a(mi0, sc0, up0, p9Var, mbVar, joVar, this.f, x5Var, this.g, d102, s2);
                return we1;
        }
    }
}