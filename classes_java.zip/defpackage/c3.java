package defpackage;

import java.util.ArrayList;
import java.util.List;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: c3 */
public final /* synthetic */ class c3 implements m00 {
    public final /* synthetic */ int e;
    public final /* synthetic */ m00 f;

    public final Object f(Object obj, Object obj2) {
        int i = this.e;
        ji0 ji0 = ji0.a;
        we1 we1 = we1.a;
        int i2 = 0;
        m00 m00 = this.f;
        d10 d10;
        int intValue;
        mi0 b;
        mh0 d;
        long j;
        int i3;
        qr0 l;
        dk dkVar;
        mh0 d2;
        mi0 I;
        switch (i) {
            case 0:
                d10 = (d10) obj;
                intValue = ((Integer) obj2).intValue();
                if (d10.O(intValue & 1, (intValue & 3) != 2)) {
                    b = ac.C(ji0, d3.b).b(new f30(e3.q));
                    d = ic.d(e3.f, false);
                    j = d10.T;
                    i3 = (int) ((j >>> 32) ^ j);
                    l = d10.l();
                    b = vn.I(d10, b);
                    ij.c.getClass();
                    dkVar = hj.b;
                    d10.Z();
                    if (d10.S) {
                        d10.k(dkVar);
                    } else {
                        d10.j0();
                    }
                    mc0.B(hj.f, d10, d);
                    mc0.B(hj.e, d10, l);
                    mc0.p(d10, Integer.valueOf(i3), hj.g);
                    mc0.w(d10, hj.h);
                    mc0.B(hj.d, d10, b);
                    m00.f(d10, Integer.valueOf(0));
                    d10.p(true);
                } else {
                    d10.R();
                }
                return we1;
            case 1:
                d10 = (d10) obj;
                intValue = ((Integer) obj2).intValue();
                if (d10.O(intValue & 1, (intValue & 3) != 2)) {
                    b = ac.C(new ra0(1.0f, false), d3.c).b(new f30(e3.q));
                    d = ic.d(e3.f, false);
                    j = d10.T;
                    i3 = (int) ((j >>> 32) ^ j);
                    l = d10.l();
                    b = vn.I(d10, b);
                    ij.c.getClass();
                    dkVar = hj.b;
                    d10.Z();
                    if (d10.S) {
                        d10.k(dkVar);
                    } else {
                        d10.j0();
                    }
                    mc0.B(hj.f, d10, d);
                    mc0.B(hj.e, d10, l);
                    mc0.p(d10, Integer.valueOf(i3), hj.g);
                    mc0.w(d10, hj.h);
                    mc0.B(hj.d, d10, b);
                    m00.f(d10, Integer.valueOf(0));
                    d10.p(true);
                } else {
                    d10.R();
                }
                return we1;
            case 2:
                iz0 iz0 = (iz0) obj;
                List list = (List) m00.f(iz0, obj2);
                intValue = list.size();
                while (i2 < intValue) {
                    Object obj3 = list.get(i2);
                    if (obj3 != null) {
                        mz0 mz0 = iz0.f;
                        if (mz0 == null) {
                            continue;
                        } else if (mz0.d(obj3) == 0) {
                            StringBuilder dl1 = new dl1("item at index ");
                            dl1.append(i2);
                            dl1.append(" can't be saved: ");
                            dl1.append(obj3);
                            throw new dl1(dl1.toString().toString());
                        }
                    }
                    i2++;
                }
                return !list.isEmpty() ? new ArrayList(list) : null;
            case 3:
                d10 = (d10) obj;
                intValue = ((Integer) obj2).intValue();
                if (d10.O(intValue & 1, (intValue & 3) != 2)) {
                    d2 = ic.d(e3.f, false);
                    j = d10.T;
                    i = (int) ((j >>> 32) ^ j);
                    l = d10.l();
                    I = vn.I(d10, ji0);
                    ij.c.getClass();
                    dkVar = hj.b;
                    d10.Z();
                    if (d10.S) {
                        d10.k(dkVar);
                    } else {
                        d10.j0();
                    }
                    mc0.B(hj.f, d10, d2);
                    mc0.B(hj.e, d10, l);
                    mc0.p(d10, Integer.valueOf(i), hj.g);
                    mc0.w(d10, hj.h);
                    mc0.B(hj.d, d10, I);
                    m00.f(d10, Integer.valueOf(0));
                    d10.p(true);
                } else {
                    d10.R();
                }
                return we1;
            default:
                d10 = (d10) obj;
                intValue = ((Integer) obj2).intValue();
                if (d10.O(intValue & 1, (intValue & 3) != 2)) {
                    d2 = ic.d(e3.f, false);
                    j = d10.T;
                    i = (int) ((j >>> 32) ^ j);
                    l = d10.l();
                    I = vn.I(d10, ji0);
                    ij.c.getClass();
                    dkVar = hj.b;
                    d10.Z();
                    if (d10.S) {
                        d10.k(dkVar);
                    } else {
                        d10.j0();
                    }
                    mc0.B(hj.f, d10, d2);
                    mc0.B(hj.e, d10, l);
                    mc0.p(d10, Integer.valueOf(i), hj.g);
                    mc0.w(d10, hj.h);
                    mc0.B(hj.d, d10, I);
                    m00.f(d10, Integer.valueOf(0));
                    d10.p(true);
                } else {
                    d10.R();
                }
                return we1;
        }
    }

    public /* synthetic */ c3(int i, m00 m00) {
        this.e = i;
        this.f = m00;
    }
}