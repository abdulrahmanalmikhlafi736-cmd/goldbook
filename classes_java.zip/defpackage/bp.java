package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bp */
public interface bp {
    sq c(long j, jc1 jc1, sl slVar);

    void d(long j, ne neVar);
}