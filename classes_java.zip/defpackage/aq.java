package defpackage;

import android.app.Dialog;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager.LayoutParams;
import android.window.OnBackInvokedDispatcher;
import java.util.UUID;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: aq */
public final class aq extends Dialog implements sd0, kn0, el0, xz0 {
    public ud0 e;
    public final al f;
    public final da1 g;
    public final da1 h;
    public xz i;
    public yp j;
    public final View k;
    public final xp l;
    public boolean m;

    public aq(xz xzVar, yp ypVar, View view, o90 o90, jp jpVar, UUID uuid) {
        super(new dv0(view.getContext(), ypVar.e ? 2131427328 : 2131427331), 0);
        this.f = new al(new wz0(this, new x1(13, (Object) this)), 20);
        this.g = new ad0(new mi(this, 0));
        this.h = new ad0(new mi(this, 1));
        this.i = xzVar;
        this.j = ypVar;
        this.k = view;
        Window window = getWindow();
        ViewGroup viewGroup = null;
        if (window != null) {
            window.requestFeature(1);
            window.setBackgroundDrawableResource(17170445);
            dd0.u(window, this.j.e);
            window.setGravity(17);
            if (!this.j.e) {
                window.addFlags(65792);
                LayoutParams attributes = window.getAttributes();
                int i = VERSION.SDK_INT;
                if (i >= 28) {
                    c9.a.a(attributes);
                }
                if (i >= 30) {
                    d9 d9Var = d9.a;
                    d9Var.b(attributes, 0);
                    d9Var.c(attributes, 0);
                }
                window.setAttributes(attributes);
            }
            View xpVar = new xp(getContext(), window);
            setTitle(this.j.f);
            StringBuilder dl1 = new dl1("Dialog:");
            dl1.append(uuid);
            xpVar.setTag(2131034163, dl1.toString());
            xpVar.setClipChildren(false);
            xpVar.setElevation(jpVar.q(8.0f));
            xpVar.setOutlineProvider(new h90(0));
            this.l = xpVar;
            View decorView = window.getDecorView();
            if (decorView instanceof ViewGroup) {
                viewGroup = (ViewGroup) decorView;
            }
            if (viewGroup != null) {
                aq.e(viewGroup);
            }
            setContentView(xpVar);
            xpVar.setTag(2131034229, ua0.o(view));
            xpVar.setTag(2131034233, jb0.j(view));
            xpVar.setTag(2131034232, jb0.j(view));
            i(this.i, this.j, o90);
            jn0 b = b();
            l5 l5Var = new l5(this, 1);
            b.getClass();
            sa saVar = new sa(l5Var);
            ud0 f = f();
            if (f.d != jd0.e) {
                en0 en0 = new en0(saVar, new fn0(saVar, this));
                saVar.a.add(en0);
                en0.g(false);
                p3.b(b.a(), en0);
                to toVar = new to(en0, b, f);
                f.a(toVar);
                saVar.c.add(new gn0(f, toVar));
                return;
            }
            return;
        }
        od.p("Dialog has no window");
        throw null;
    }

    /* JADX WARNING: Removed duplicated region for block: B:41:0x007a  */
    /* JADX WARNING: Removed duplicated region for block: B:52:0x009c  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void i(xz xzVar, yp ypVar, o90 o90) {
        int i;
        Window window;
        this.i = xzVar;
        this.j = ypVar;
        z11 z11 = ypVar.c;
        int i2 = u6.a;
        ViewGroup.LayoutParams layoutParams = this.k.getRootView().getLayoutParams();
        LayoutParams layoutParams2 = layoutParams instanceof LayoutParams ? (LayoutParams) layoutParams : null;
        int i3 = 0;
        boolean z = (layoutParams2 == null || (layoutParams2.flags & 8192) == 0) ? false : true;
        int ordinal = z11.ordinal();
        if (ordinal != 0) {
            if (ordinal == 1) {
                z = true;
            } else if (ordinal == 2) {
                z = false;
            } else {
                od.k();
                return;
            }
        }
        Window window2 = getWindow();
        window2.getClass();
        window2.setFlags(z ? 8192 : -8193, 8192);
        ordinal = o90.ordinal();
        if (ordinal == 0) {
            ordinal = 0;
        } else if (ordinal == 1) {
            ordinal = 1;
        } else {
            od.k();
            return;
        }
        xp xpVar = this.l;
        xpVar.setLayoutDirection(ordinal);
        boolean z2 = ypVar.e;
        z = ypVar.d;
        Window window3 = xpVar.n;
        if (xpVar.r && z == xpVar.p) {
            if (z2 == xpVar.q) {
                i = 0;
                xpVar.p = z;
                xpVar.q = z2;
                if (i != 0) {
                    LayoutParams attributes = window3.getAttributes();
                    i2 = z ? -2 : -1;
                    if (!(i2 == attributes.width && xpVar.r)) {
                        window3.setLayout(i2, -2);
                        xpVar.r = true;
                    }
                }
                setCanceledOnTouchOutside(ypVar.b);
                window = getWindow();
                if (window != null) {
                    if (!z2) {
                        i3 = VERSION.SDK_INT < 31 ? 16 : 48;
                    }
                    window.setSoftInputMode(i3);
                }
            }
        }
        i = true;
        xpVar.p = z;
        xpVar.q = z2;
        if (i != 0) {
        }
        setCanceledOnTouchOutside(ypVar.b);
        window = getWindow();
        if (window != null) {
        }
    }

    public final boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked;
        boolean onTouchEvent = super.onTouchEvent(motionEvent);
        if (this.j.b) {
            xp xpVar = this.l;
            xpVar.getClass();
            if (Math.abs(motionEvent.getX()) <= Float.MAX_VALUE && Math.abs(motionEvent.getY()) <= Float.MAX_VALUE) {
                View childAt = xpVar.getChildAt(0);
                if (childAt != null) {
                    int left = childAt.getLeft() + xpVar.getLeft();
                    int width = childAt.getWidth() + left;
                    int top = childAt.getTop() + xpVar.getTop();
                    int height = childAt.getHeight() + top;
                    int P = gh0.P(motionEvent.getX());
                    if (left <= P && P <= width) {
                        P = gh0.P(motionEvent.getY());
                        if (top <= P && P <= height) {
                        }
                    }
                }
            }
            actionMasked = motionEvent.getActionMasked();
            if (actionMasked != 0) {
                if (actionMasked != 1) {
                    if (actionMasked == 3) {
                        this.m = false;
                        return onTouchEvent;
                    }
                } else if (this.m) {
                    this.i.a();
                    this.m = false;
                    return true;
                }
                return onTouchEvent;
            }
            this.m = true;
            return true;
        }
        actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0 || actionMasked == 1 || actionMasked == 3) {
            this.m = false;
            return onTouchEvent;
        }
        return onTouchEvent;
    }

    public final void h() {
        Window window = getWindow();
        window.getClass();
        View decorView = window.getDecorView();
        decorView.getClass();
        decorView.setTag(2131034229, this);
        window = getWindow();
        window.getClass();
        decorView = window.getDecorView();
        decorView.getClass();
        decorView.setTag(2131034231, this);
        window = getWindow();
        window.getClass();
        decorView = window.getDecorView();
        decorView.getClass();
        decorView.setTag(2131034232, this);
        window = getWindow();
        window.getClass();
        decorView = window.getDecorView();
        decorView.getClass();
        decorView.setTag(2131034230, this);
    }

    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        if (VERSION.SDK_INT >= 33) {
            jn0 b = b();
            OnBackInvokedDispatcher h = getOnBackInvokedDispatcher();
            h.getClass();
            b.b(h);
        }
        this.f.q(bundle);
        f().d(id0.ON_CREATE);
    }

    public static final void e(ViewGroup viewGroup) {
        int i = 0;
        viewGroup.setClipChildren(false);
        if (!(viewGroup instanceof xp)) {
            int childCount = viewGroup.getChildCount();
            while (i < childCount) {
                View childAt = viewGroup.getChildAt(i);
                ViewGroup viewGroup2 = childAt instanceof ViewGroup ? (ViewGroup) childAt : null;
                if (viewGroup2 != null) {
                    aq.e(viewGroup2);
                }
                i++;
            }
        }
    }

    public final boolean onKeyUp(int i, KeyEvent keyEvent) {
        if (!this.j.a || !keyEvent.isTracking() || keyEvent.isCanceled() || i != 111) {
            return super.onKeyUp(i, keyEvent);
        }
        this.i.a();
        return true;
    }

    public final void onStop() {
        f().d(id0.ON_DESTROY);
        this.e = null;
        super.onStop();
    }

    public final ud0 f() {
        ud0 ud0 = this.e;
        if (ud0 != null) {
            return ud0;
        }
        ud0 = new ud0(this, true);
        this.e = ud0;
        return ud0;
    }

    public final Bundle onSaveInstanceState() {
        Bundle onSaveInstanceState = super.onSaveInstanceState();
        onSaveInstanceState.getClass();
        this.f.r(onSaveInstanceState);
        return onSaveInstanceState;
    }

    public final void onStart() {
        super.onStart();
        f().d(id0.ON_RESUME);
    }

    public final void onBackPressed() {
        ((cq) this.g.getValue()).a();
    }

    public final void addContentView(View view, ViewGroup.LayoutParams layoutParams) {
        view.getClass();
        h();
        super.addContentView(view, layoutParams);
    }

    public final void setContentView(View view) {
        view.getClass();
        h();
        super.setContentView(view);
    }

    public final p3 a() {
        return b().a();
    }

    public final jn0 b() {
        return (jn0) this.h.getValue();
    }

    public final al c() {
        return (al) this.f.g;
    }

    public final ud0 g() {
        return f();
    }

    public static void d(aq aqVar) {
        super.onBackPressed();
    }

    public final void setContentView(int i) {
        h();
        super.setContentView(i);
    }

    public final void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        view.getClass();
        h();
        super.setContentView(view, layoutParams);
    }

    public final void cancel() {
    }
}