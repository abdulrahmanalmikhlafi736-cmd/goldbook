package defpackage;

import androidx.core.content.FileProvider;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: b */
public final /* synthetic */ class b implements xz {
    public final /* synthetic */ int e;
    public final /* synthetic */ dg f;

    public final Object a() {
        int i = this.e;
        dg dgVar = this.f;
        switch (i) {
            case 0:
                t40 t40 = (t40) j70.z(dgVar, p40.a);
                if (t40 == null) {
                    StringBuilder dl1 = new dl1("clickable only supports IndicationNodeFactory instances provided to LocalIndication, but Indication was provided instead. Either migrate the Indication implementation to implement IndicationNodeFactory, or use the other clickable overload that takes an Indication parameter, and explicitly pass LocalIndication.current there. The Indication instance provided here was: ");
                    dl1.append(t40);
                    FileProvider.a(dl1.toString());
                }
                t40 t402 = dgVar.B;
                dgVar.B = t40;
                if (!(t402 == null || k70.p(t40, t402))) {
                    cp cpVar = dgVar.D;
                    if (!(cpVar == null && dgVar.K)) {
                        if (cpVar != null) {
                            dgVar.s0(cpVar);
                        }
                        dgVar.D = null;
                        dgVar.y0();
                    }
                }
                return we1.a;
            default:
                dgVar.z.a();
                return Boolean.TRUE;
        }
    }

    public /* synthetic */ b(dg dgVar, int i) {
        this.e = i;
        this.f = dgVar;
    }
}