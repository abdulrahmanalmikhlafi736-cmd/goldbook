package defpackage;

import java.util.Collection;
import java.util.List;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: b0 */
public final /* synthetic */ class b0 implements i00 {
    public final /* synthetic */ int e;
    public final /* synthetic */ Collection f;

    public final Object i(Object obj) {
        boolean contains;
        int i = this.e;
        Collection collection = this.f;
        switch (i) {
            case 0:
                contains = collection.contains(obj);
                break;
            case 1:
                contains = collection.contains(obj);
                break;
            default:
                contains = ((List) obj).retainAll(collection);
                break;
        }
        return Boolean.valueOf(contains);
    }

    public /* synthetic */ b0(int i, Collection collection) {
        this.e = i;
        this.f = collection;
    }
}