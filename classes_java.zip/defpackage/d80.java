package defpackage;

import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: d80 */
public abstract class d80 extends of0 implements sq, l40 {
    public h80 h;

    public final void a() {
        h80 j = j();
        loop0:
        while (true) {
            AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = h80.e;
            d80 d80 = atomicReferenceFieldUpdater.get(j);
            if (d80 instanceof d80) {
                if (d80 == this) {
                    pt ptVar = zi1.v;
                    while (!atomicReferenceFieldUpdater.compareAndSet(j, d80, ptVar)) {
                        if (atomicReferenceFieldUpdater.get(j) != d80) {
                        }
                    }
                    break loop0;
                }
                break;
            } else if ((d80 instanceof l40) && d80.d() != null) {
                while (true) {
                    AtomicReferenceFieldUpdater atomicReferenceFieldUpdater2 = of0.e;
                    d80 d802 = atomicReferenceFieldUpdater2.get(this);
                    if (d802 instanceof bx0) {
                        break;
                    } else if (d802 == this) {
                        of0 of0 = d802;
                        return;
                    } else {
                        d802.getClass();
                        of0 of02 = d802;
                        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater3 = of0.g;
                        Object obj = (bx0) atomicReferenceFieldUpdater3.get(of02);
                        if (obj == null) {
                            obj = new bx0(of02);
                            atomicReferenceFieldUpdater3.set(of02, obj);
                        }
                        while (!atomicReferenceFieldUpdater2.compareAndSet(this, d802, obj)) {
                            if (atomicReferenceFieldUpdater2.get(this) != d802) {
                            }
                        }
                        of02.f();
                        return;
                    }
                }
            }
        }
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(getClass().getSimpleName());
        stringBuilder.append('@');
        stringBuilder.append(vn.y(this));
        stringBuilder.append("[job@");
        stringBuilder.append(vn.y(j()));
        stringBuilder.append(']');
        return stringBuilder.toString();
    }

    public final h80 j() {
        h80 h80 = this.h;
        if (h80 != null) {
            return h80;
        }
        k70.T("job");
        throw null;
    }

    public a80 getParent() {
        return j();
    }

    public final boolean b() {
        return true;
    }

    public final im0 d() {
        return null;
    }

    public abstract boolean k();

    public abstract boolean l(Throwable th);
}