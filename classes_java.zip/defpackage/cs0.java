package defpackage;

import java.util.Collection;
import java.util.Iterator;
import java.util.Set;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cs0 */
public final class cs0 extends l0 implements Set, Collection, w80 {
    public static final cs0 h;
    public final Object e;
    public final Object f;
    public final rr0 g;

    static {
        e3 e3Var = e3.L;
        h = new cs0(e3Var, e3Var, rr0.g);
    }

    public cs0(Object obj, Object obj2, rr0 rr0) {
        this.e = obj;
        this.f = obj2;
        this.g = rr0;
    }

    public final Iterator iterator() {
        return new m10(this.e, this.g);
    }

    public final boolean contains(Object obj) {
        return this.g.containsKey(obj);
    }

    public final int a() {
        return this.g.f;
    }
}