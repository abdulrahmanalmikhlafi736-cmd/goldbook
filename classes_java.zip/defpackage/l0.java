package defpackage;

import java.util.Set;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: l0 */
public abstract class l0 extends m implements Set {
    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof Set)) {
            return false;
        }
        Set set = (Set) obj;
        return size() != set.size() ? false : containsAll(set);
    }

    public final int hashCode() {
        int i = 0;
        for (Object next : this) {
            i += next != null ? next.hashCode() : 0;
        }
        return i;
    }
}