package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bc1 */
public final class bc1 {
    public final int a;
    public final la b;
    public final c c;
    public bc1 d;
    public long e;
    public long f;
    public long g = Long.MIN_VALUE;
    public final /* synthetic */ cc1 h;

    public final void b() {
        bc1 bc1;
        bc1 bc12;
        cc1 cc1 = this.h;
        sj0 sj0 = cc1.a;
        int i = this.a;
        bc1 bc13 = (bc1) sj0.g(i);
        if (bc13 != null) {
            if (bc13 != this) {
                int d = sj0.d(i);
                Object[] objArr = sj0.c;
                Object obj = objArr[d];
                sj0.b[d] = i;
                objArr[d] = bc13;
                while (true) {
                    bc1 = bc13.d;
                    if (bc1 == null) {
                        break;
                    } else if (bc1 == this) {
                        bc13.d = this.d;
                        this.d = null;
                        return;
                    } else {
                        bc13 = bc1;
                    }
                }
            } else {
                bc12 = this.d;
                this.d = null;
                if (bc12 != null) {
                    int d2 = sj0.d(i);
                    Object[] objArr2 = sj0.c;
                    Object obj2 = objArr2[d2];
                    sj0.b[d2] = i;
                    objArr2[d2] = bc12;
                    return;
                }
                ba0 O = k70.O(this.b.e);
                if (O.k) {
                    ((n4) ea0.a(O)).getRectManager().a.f(O.f, false);
                }
            }
        }
        bc1 = cc1.b;
        if (bc1 == this) {
            cc1.b = bc1.d;
            this.d = null;
            return;
        }
        bc12 = bc1 != null ? bc1.d : null;
        while (true) {
            bc1 bc14 = bc1;
            bc1 = bc12;
            bc12 = bc14;
            if (bc1 == null) {
                break;
            } else if (bc1 == this) {
                if (bc12 != null) {
                    bc12.d = bc1.d;
                }
                this.d = null;
                return;
            } else {
                bc12 = bc1.d;
            }
        }
    }

    public final void a(long j, long j2, long j3, long j4, float[] fArr) {
        Object obj;
        long j5 = this.h.f;
        la laVar = this.b;
        gm0 M = k70.M(laVar, 2);
        ba0 O = k70.O(laVar);
        boolean I = O.I();
        em0 em0 = O.J;
        if (I) {
            rw0 rw0;
            if (em0.d != M) {
                int i = 32;
                long floatToRawIntBits = ((long) Float.floatToRawIntBits((float) ((int) (j & 4294967295L)))) & 4294967295L;
                floatToRawIntBits |= ((long) Float.floatToRawIntBits((float) ((int) (j >> 32)))) << i;
                long j6 = M.g;
                gm0 gm0 = em0.d;
                gm0.getClass();
                floatToRawIntBits = vd1.C(gm0.x(M, floatToRawIntBits));
                long j7 = 4294967295L & ((long) (((int) (floatToRawIntBits & 4294967295L)) + ((int) (j6 & 4294967295L))));
                rw0 = new rw0(floatToRawIntBits, j7 | (((long) (((int) (floatToRawIntBits >> i)) + ((int) (j6 >> i)))) << i), j3, j4, j5, fArr, laVar);
            } else {
                rw0 = new rw0(j, j2, j3, j4, j5, fArr, laVar);
            }
            obj = rw0;
        } else {
            obj = null;
        }
        if (obj != null) {
            this.c.i(obj);
        }
    }

    public bc1(cc1 cc1, int i, la laVar, c cVar) {
        this.h = cc1;
        this.a = i;
        this.b = laVar;
        this.c = cVar;
    }
}