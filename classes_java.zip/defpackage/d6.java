package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: d6 */
public final class d6 {
    public final int a;

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof d6)) {
            return false;
        }
        return this.a == ((d6) obj).a;
    }

    public final String toString() {
        return fu0.G(new dl1("AndroidFontResolveInterceptor(fontWeightAdjustment="), this.a, ')');
    }

    public d6(int i) {
        this.a = i;
    }

    public final int hashCode() {
        return this.a;
    }
}