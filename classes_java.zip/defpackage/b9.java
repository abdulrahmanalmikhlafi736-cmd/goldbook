package defpackage;

import android.graphics.ColorSpace;
import android.graphics.ColorSpace.Named;
import android.graphics.ColorSpace.Rgb;
import android.graphics.ColorSpace.Rgb.TransferParameters;
import android.os.Build.VERSION;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.autofill.AutofillId;
import java.io.File;
import java.io.IOException;
import java.nio.file.CopyOption;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: b9 */
public abstract class b9 {
    public static final ColorSpace a(gh ghVar) {
        gh ghVar2 = ghVar;
        ColorSpace colorSpace;
        ColorSpace colorSpace2;
        if (k70.p(ghVar2, jh.e)) {
            colorSpace = ColorSpace.get(Named.SRGB);
            colorSpace2 = colorSpace;
            return colorSpace;
        } else if (k70.p(ghVar2, jh.q)) {
            colorSpace = ColorSpace.get(Named.ACES);
            colorSpace2 = colorSpace;
            return colorSpace;
        } else if (k70.p(ghVar2, jh.r)) {
            colorSpace = ColorSpace.get(Named.ACESCG);
            colorSpace2 = colorSpace;
            return colorSpace;
        } else if (k70.p(ghVar2, jh.o)) {
            colorSpace = ColorSpace.get(Named.ADOBE_RGB);
            colorSpace2 = colorSpace;
            return colorSpace;
        } else if (k70.p(ghVar2, jh.j)) {
            colorSpace = ColorSpace.get(Named.BT2020);
            colorSpace2 = colorSpace;
            return colorSpace;
        } else if (k70.p(ghVar2, jh.i)) {
            colorSpace = ColorSpace.get(Named.BT709);
            colorSpace2 = colorSpace;
            return colorSpace;
        } else if (k70.p(ghVar2, jh.t)) {
            colorSpace = ColorSpace.get(Named.CIE_LAB);
            colorSpace2 = colorSpace;
            return colorSpace;
        } else if (k70.p(ghVar2, jh.s)) {
            colorSpace = ColorSpace.get(Named.CIE_XYZ);
            colorSpace2 = colorSpace;
            return colorSpace;
        } else if (k70.p(ghVar2, jh.k)) {
            colorSpace = ColorSpace.get(Named.DCI_P3);
            colorSpace2 = colorSpace;
            return colorSpace;
        } else if (k70.p(ghVar2, jh.l)) {
            colorSpace = ColorSpace.get(Named.DISPLAY_P3);
            colorSpace2 = colorSpace;
            return colorSpace;
        } else if (k70.p(ghVar2, jh.g)) {
            colorSpace = ColorSpace.get(Named.EXTENDED_SRGB);
            colorSpace2 = colorSpace;
            return colorSpace;
        } else if (k70.p(ghVar2, jh.h)) {
            colorSpace = ColorSpace.get(Named.LINEAR_EXTENDED_SRGB);
            colorSpace2 = colorSpace;
            return colorSpace;
        } else if (k70.p(ghVar2, jh.f)) {
            colorSpace = ColorSpace.get(Named.LINEAR_SRGB);
            colorSpace2 = colorSpace;
            return colorSpace;
        } else if (k70.p(ghVar2, jh.m)) {
            colorSpace = ColorSpace.get(Named.NTSC_1953);
            colorSpace2 = colorSpace;
            return colorSpace;
        } else if (k70.p(ghVar2, jh.p)) {
            colorSpace = ColorSpace.get(Named.PRO_PHOTO_RGB);
            colorSpace2 = colorSpace;
            return colorSpace;
        } else if (k70.p(ghVar2, jh.n)) {
            colorSpace = ColorSpace.get(Named.SMPTE_C);
            colorSpace2 = colorSpace;
            return colorSpace;
        } else {
            TransferParameters transferParameters = null;
            if (VERSION.SDK_INT >= 34) {
                colorSpace2 = k70.p(ghVar2, jh.v) ? ColorSpace.get(Named.BT2020_HLG) : k70.p(ghVar2, jh.w) ? ColorSpace.get(Named.BT2020_PQ) : null;
                if (colorSpace2 != null) {
                    colorSpace = colorSpace2;
                    return colorSpace2;
                }
            }
            if (ghVar2 instanceof ay0) {
                String str = ghVar2.a;
                ay0 ay0 = (ay0) ghVar2;
                float[] a = ay0.d.a();
                vc1 vc1 = ay0.g;
                if (vc1 != null) {
                    transferParameters = new TransferParameters(vc1.b, vc1.c, vc1.d, vc1.e, vc1.f, vc1.g, vc1.a);
                }
                float[] fArr = ay0.i;
                if (transferParameters == null) {
                    return (ColorSpace) new Rgb(str, ay0.h, a, new hh(ay0.l, 0), new hh(ay0.o, 1), ay0.e, ay0.f);
                }
                Rgb rgb = new Rgb(str, ay0.h, a, transferParameters);
                if (!Float.isNaN(fArr[0])) {
                    if (!Arrays.equals(rgb.getTransform(), fArr)) {
                        return (ColorSpace) new Rgb(str, fArr, transferParameters);
                    }
                }
                return (ColorSpace) rgb;
            }
            colorSpace = ColorSpace.get(Named.SRGB);
            colorSpace2 = colorSpace;
            return colorSpace;
        }
    }

    public static boolean g(File file, File file2) {
        try {
            Files.move(file.toPath(), file2.toPath(), new CopyOption[]{StandardCopyOption.REPLACE_EXISTING});
            return true;
        } catch (IOException unused) {
            return false;
        }
    }

    public static AutofillId b(View view) {
        return view.getAutofillId();
    }

    public static float c(ViewConfiguration viewConfiguration) {
        return viewConfiguration.getScaledHorizontalScrollFactor();
    }

    public static float d(ViewConfiguration viewConfiguration) {
        return viewConfiguration.getScaledHorizontalScrollFactor();
    }

    public static float e(ViewConfiguration viewConfiguration) {
        return viewConfiguration.getScaledVerticalScrollFactor();
    }

    public static float f(ViewConfiguration viewConfiguration) {
        return viewConfiguration.getScaledVerticalScrollFactor();
    }
}