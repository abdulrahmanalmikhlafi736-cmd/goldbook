package defpackage;

import android.view.autofill.AutofillManager;
import java.io.Closeable;
import java.lang.Thread.State;
import java.util.ArrayList;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicLongFieldUpdater;
import java.util.concurrent.locks.LockSupport;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: am */
public final class am implements Executor, Closeable {
    public static final /* synthetic */ AtomicLongFieldUpdater l;
    public static final /* synthetic */ AtomicLongFieldUpdater m;
    public static final /* synthetic */ AtomicIntegerFieldUpdater n;
    public static final mt o = new f1("NOT_IN_STACK", 1);
    private volatile /* synthetic */ int _isTerminated$volatile;
    private volatile /* synthetic */ long controlState$volatile;
    public final int e;
    public final int f;
    public final long g;
    public final String h;
    public final r10 i;
    public final r10 j;
    public final jx0 k;
    private volatile /* synthetic */ long parkedWorkersStack$volatile;

    public final String toString() {
        int i;
        ArrayList arrayList = new ArrayList();
        jx0 jx0 = this.k;
        int a = jx0.a();
        int i2 = 0;
        int i3 = 0;
        int i4 = i3;
        int i5 = i4;
        int i6 = i5;
        for (i = 1; i < a; i++) {
            yl ylVar = (yl) jx0.b(i);
            if (ylVar != null) {
                kl1 kl1 = ylVar.e;
                kl1.getClass();
                int i7 = kl1.b.get(kl1) != null ? (kl1.c.get(kl1) - kl1.d.get(kl1)) + 1 : kl1.c.get(kl1) - kl1.d.get(kl1);
                int ordinal = ylVar.g.ordinal();
                StringBuilder stringBuilder;
                if (ordinal == 0) {
                    i2++;
                    stringBuilder = new StringBuilder();
                    stringBuilder.append(i7);
                    stringBuilder.append('c');
                    arrayList.add(stringBuilder.toString());
                } else if (ordinal == 1) {
                    i3++;
                    stringBuilder = new StringBuilder();
                    stringBuilder.append(i7);
                    stringBuilder.append('b');
                    arrayList.add(stringBuilder.toString());
                } else if (ordinal == 2) {
                    i4++;
                } else if (ordinal == 3) {
                    i5++;
                    if (i7 > 0) {
                        stringBuilder = new StringBuilder();
                        stringBuilder.append(i7);
                        stringBuilder.append('d');
                        arrayList.add(stringBuilder.toString());
                    }
                } else if (ordinal == 4) {
                    i6++;
                } else {
                    od.k();
                    return null;
                }
            }
        }
        long j = m.get(this);
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(this.h);
        stringBuilder2.append('@');
        stringBuilder2.append(vn.y(this));
        stringBuilder2.append("[Pool Size {core = ");
        i = this.e;
        stringBuilder2.append(i);
        stringBuilder2.append(", max = ");
        stringBuilder2.append(this.f);
        stringBuilder2.append("}, Worker States {CPU = ");
        stringBuilder2.append(i2);
        stringBuilder2.append(", blocking = ");
        stringBuilder2.append(i3);
        stringBuilder2.append(", parked = ");
        stringBuilder2.append(i4);
        stringBuilder2.append(", dormant = ");
        stringBuilder2.append(i5);
        stringBuilder2.append(", terminated = ");
        stringBuilder2.append(i6);
        stringBuilder2.append("}, running workers queues = ");
        stringBuilder2.append(arrayList);
        stringBuilder2.append(", global CPU queue size = ");
        stringBuilder2.append(this.i.c());
        stringBuilder2.append(", global blocking queue size = ");
        stringBuilder2.append(this.j.c());
        stringBuilder2.append(", Control State {created workers= ");
        stringBuilder2.append((int) (2097151 & j));
        stringBuilder2.append(", blocking tasks = ");
        stringBuilder2.append((int) ((4398044413952L & j) >> 21));
        stringBuilder2.append(", CPUs acquired = ");
        stringBuilder2.append(i - ((int) ((j & 9223367638808264704L) >> 42)));
        stringBuilder2.append("}]");
        return stringBuilder2.toString();
    }

    public final void b(Runnable runnable, boolean z, boolean z2) {
        ka1 ka1;
        ma1.f.getClass();
        long nanoTime = System.nanoTime();
        if (runnable instanceof ka1) {
            ka1 = (ka1) runnable;
            ka1.e = nanoTime;
            ka1.f = z;
        } else {
            ka1 = new la1(runnable, nanoTime, z);
        }
        z = ka1.f;
        AtomicLongFieldUpdater atomicLongFieldUpdater = m;
        long addAndGet = z ? atomicLongFieldUpdater.addAndGet(this, 2097152) : 0;
        Thread currentThread = Thread.currentThread();
        yl ylVar = currentThread instanceof yl ? (yl) currentThread : null;
        if (ylVar == null || ylVar.l != this) {
            ylVar = null;
        }
        if (ylVar != null) {
            zl zlVar = ylVar.g;
            if (zlVar != zl.i) {
                if (ka1.f || zlVar != zl.f) {
                    ylVar.k = true;
                    kl1 kl1 = ylVar.e;
                    if (z2) {
                        ka1 = kl1.a(ka1);
                    } else {
                        kl1.getClass();
                        ka1 = (ka1) kl1.b.getAndSet(kl1, ka1);
                        ka1 = ka1 == null ? null : kl1.a(ka1);
                    }
                }
            }
        }
        if (ka1 != null) {
            if (!(ka1.f ? this.j.a(ka1) : this.i.a(ka1))) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(this.h);
                stringBuilder.append(" was terminated");
                throw new dl1(stringBuilder.toString());
            }
        }
        if (z) {
            if (!f()) {
                if (!e(addAndGet)) {
                    f();
                }
            }
        } else if (!f()) {
            if (!e(atomicLongFieldUpdater.get(this))) {
                f();
            }
        }
    }

    /* JADX WARNING: Missing block: B:36:0x0083, code:
            if (r1 == null) goto L_0x0085;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void close() {
        if (n.compareAndSet(this, 0, 1)) {
            int i;
            Thread currentThread = Thread.currentThread();
            yl ylVar = currentThread instanceof yl ? (yl) currentThread : null;
            if (ylVar == null || ylVar.l != this) {
                ylVar = null;
            }
            synchronized (this.k) {
                i = (int) (m.get(this) & 2097151);
            }
            if (1 <= i) {
                int i2 = 1;
                while (true) {
                    Object b = this.k.b(i2);
                    b.getClass();
                    yl ylVar2 = (yl) b;
                    if (ylVar2 != ylVar) {
                        while (ylVar2.getState() != State.TERMINATED) {
                            LockSupport.unpark(ylVar2);
                            ylVar2.join(10000);
                        }
                        kl1 kl1 = ylVar2.e;
                        r10 r10 = this.j;
                        kl1.getClass();
                        ka1 ka1 = (ka1) kl1.b.getAndSet(kl1, null);
                        if (ka1 != null) {
                            r10.a(ka1);
                        }
                        while (true) {
                            ka1 = kl1.b();
                            if (ka1 == null) {
                                break;
                            }
                            r10.a(ka1);
                        }
                    }
                    if (i2 == i) {
                        break;
                    }
                    i2++;
                }
            }
            this.j.b();
            this.i.b();
            while (true) {
                Runnable a;
                if (ylVar != null) {
                    a = ylVar.a(true);
                }
                a = (ka1) this.i.d();
                if (a == null) {
                    a = (ka1) this.j.d();
                    if (a == null) {
                        break;
                    }
                }
                try {
                    a.run();
                } catch (Throwable th) {
                    Thread currentThread2 = Thread.currentThread();
                    currentThread2.getUncaughtExceptionHandler().uncaughtException(currentThread2, th);
                }
            }
            if (ylVar != null) {
                ylVar.h(zl.i);
            }
            l.set(this, 0);
            m.set(this, 0);
        }
    }

    public am(int i, int i2, long j, String str) {
        this.e = i;
        this.f = i2;
        this.g = j;
        this.h = str;
        if (i >= 1) {
            str = "Max pool size ";
            if (i2 < i) {
                throw new dl1(fu0.D(i2, i, str, " should be greater than or equals to core pool size ").toString());
            } else if (i2 > 2097150) {
                od.g(str, i2, " should not exceed maximal supported number of threads 2097150");
                throw null;
            } else if (j > 0) {
                this.i = new pf0();
                this.j = new pf0();
                this.k = new h90((i + 1) * 2);
                this.controlState$volatile = ((long) i) << 42;
                return;
            } else {
                StringBuilder dl1 = new dl1("Idle worker keep alive time ");
                dl1.append(j);
                dl1.append(" must be positive");
                throw new dl1(dl1.toString().toString());
            }
        }
        od.g("Core pool size ", i, " should be at least 1");
        throw null;
    }

    public final int a() {
        synchronized (this.k) {
            if ((n.get(this) == 1 ? 1 : 0) != 0) {
                return -1;
            }
            AtomicLongFieldUpdater atomicLongFieldUpdater = m;
            long j = atomicLongFieldUpdater.get(this);
            int i = (int) (j & 2097151);
            int i2 = i - ((int) ((j & 4398044413952L) >> 21));
            if (i2 < 0) {
                i2 = 0;
            }
            if (i2 >= this.e) {
                return 0;
            } else if (i >= this.f) {
                return 0;
            } else {
                int i3 = ((int) (atomicLongFieldUpdater.get(this) & 2097151)) + 1;
                if (i3 <= 0 || this.k.b(i3) != null) {
                    throw new dl1("Failed requirement.");
                }
                yl ylVar = new yl(this, i3);
                this.k.c(i3, ylVar);
                if (i3 == ((int) (2097151 & atomicLongFieldUpdater.incrementAndGet(this)))) {
                    i2++;
                    ylVar.start();
                    return i2;
                }
                throw new dl1("Failed requirement.");
            }
        }
    }

    public final boolean f() {
        while (true) {
            Object thisR;
            Object obj;
            long j = l.get(thisR);
            Object obj2 = (yl) thisR.k.b((int) (2097151 & j));
            if (obj2 == null) {
                obj2 = null;
                obj = thisR;
            } else {
                mt mtVar;
                int i;
                long j2 = (2097152 + j) & -2097152;
                mt c = obj2.c();
                while (true) {
                    mtVar = o;
                    if (c == mtVar) {
                        i = -1;
                        break;
                    } else if (c == null) {
                        i = 0;
                        break;
                    } else {
                        yl ylVar = (yl) c;
                        i = ylVar.b();
                        if (i != 0) {
                            break;
                        }
                        long j3 = j;
                        obj = thisR;
                        c = ylVar.c();
                        j = j3;
                    }
                }
                if (i >= 0) {
                    Object obj3 = thisR;
                    boolean compareAndSet = l.compareAndSet(obj3, j, ((long) i) | j2);
                    obj = obj3;
                    if (compareAndSet) {
                        ((AutofillManager) obj2);
                    }
                    thisR = obj;
                } else {
                    continue;
                }
            }
            if (obj2 == null) {
                return false;
            }
            if (yl.m.compareAndSet(obj2, -1, 0)) {
                LockSupport.unpark(obj2);
                return true;
            }
            thisR = obj;
        }
    }

    public final void d(yl ylVar, int i, int i2) {
        while (true) {
            Object thisR;
            long j = l.get(thisR);
            int i3 = (int) (2097151 & j);
            long j2 = (2097152 + j) & -2097152;
            if (i3 == i) {
                if (i2 == 0) {
                    mt c = ylVar.c();
                    while (c != o) {
                        if (c == null) {
                            i3 = 0;
                            break;
                        }
                        yl ylVar2 = (yl) c;
                        int b = ylVar2.b();
                        if (b != 0) {
                            i3 = b;
                            break;
                        }
                        c = ylVar2.c();
                    }
                    i3 = -1;
                } else {
                    i3 = i2;
                }
            }
            if (i3 >= 0) {
                Object obj = thisR;
                if (!l.compareAndSet(obj, j, ((long) i3) | j2)) {
                    thisR = obj;
                } else {
                    return;
                }
            }
        }
    }

    public final boolean e(long j) {
        int i = ((int) (2097151 & j)) - ((int) ((j & 4398044413952L) >> 21));
        if (i < 0) {
            i = 0;
        }
        int i2 = this.e;
        if (i < i2) {
            i = a();
            if (i == 1 && i2 > 1) {
                a();
            }
            if (i > 0) {
                return true;
            }
        }
        return false;
    }

    static {
        Class cls = am.class;
        l = AtomicLongFieldUpdater.newUpdater(cls, "parkedWorkersStack$volatile");
        m = AtomicLongFieldUpdater.newUpdater(cls, "controlState$volatile");
        n = AtomicIntegerFieldUpdater.newUpdater(cls, "_isTerminated$volatile");
    }

    public static /* synthetic */ void c(am amVar, Runnable runnable, int i) {
        amVar.b(runnable, false, (i & 4) == 0);
    }

    public final void execute(Runnable runnable) {
        am.c(this, runnable, 6);
    }
}