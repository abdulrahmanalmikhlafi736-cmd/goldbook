package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: u91 */
public abstract class u91 extends nl implements v00 {
    public final int h;

    public final String toString() {
        if (this.e != null) {
            return super.toString();
        }
        ow0.a.getClass();
        return pw0.a(this);
    }

    public u91(int i, ml mlVar) {
        super(mlVar);
        this.h = i;
    }

    public final int b() {
        return this.h;
    }
}