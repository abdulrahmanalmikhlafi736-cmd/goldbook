package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: lm0 */
public class lm0 {
    public final qk0 a = new qk0(new bm0[16]);
    public final ak0 b = new h90(10);

    public boolean a(xf0 xf0, n90 n90, e70 e70, boolean z) {
        qk0 qk0 = this.a;
        Object[] objArr = qk0.e;
        int i = qk0.g;
        int i2 = 0;
        boolean z2 = i2;
        while (i2 < i) {
            if (!((bm0) objArr[i2]).a(xf0, n90, e70, z)) {
                if (!z2) {
                    z2 = false;
                    i2++;
                }
            }
            z2 = true;
            i2++;
        }
        return z2;
    }

    public void b(e70 e70) {
        qk0 qk0 = this.a;
        for (int i = qk0.g - 1; -1 < i; i--) {
            if (((bm0) qk0.e[i]).d.e == 0) {
                qk0.k(i);
            }
        }
    }
}