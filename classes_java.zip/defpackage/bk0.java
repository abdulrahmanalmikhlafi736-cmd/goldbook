package defpackage;

import android.view.autofill.AutofillManager;
import java.util.Arrays;
import java.util.Collection;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bk0 */
public final class bk0 {
    public long[] a = n01.a;
    public Object[] b = k70.l;
    public long[] c = gh0.l;
    public int d = Integer.MAX_VALUE;
    public int e = Integer.MAX_VALUE;
    public int f;
    public int g;
    public int h;

    public final int d(Object obj) {
        Object obj2 = obj;
        int i = -862048943;
        int hashCode = (obj2 != null ? obj2.hashCode() : 0) * -862048943;
        hashCode ^= hashCode << 16;
        int i2 = hashCode >>> 7;
        hashCode &= 127;
        int i3 = this.f;
        int i4 = i2 & i3;
        int i5 = 0;
        while (true) {
            int i6;
            long[] jArr = this.a;
            int i7 = i4 >> 3;
            int i8 = (i4 & 7) << 3;
            int i9 = 1;
            long j = ((jArr[i7 + 1] << (64 - i8)) & ((-((long) i8)) >> 63)) | (jArr[i7] >>> i8);
            long j2 = (long) hashCode;
            long j3 = j ^ (j2 * 72340172838076673L);
            j3 = ((j3 - 72340172838076673L) & (~j3)) & -9187201950435737472L;
            while (j3 != 0) {
                int numberOfTrailingZeros = ((Long.numberOfTrailingZeros(j3) >> 3) + i4) & i3;
                i6 = i;
                if (k70.p(this.b[numberOfTrailingZeros], obj2)) {
                    return numberOfTrailingZeros;
                }
                j3 &= j3 - 1;
                i = i6;
            }
            i6 = i;
            int i10;
            int i11;
            if (((j & ((~j) << 6)) & -9187201950435737472L) != 0) {
                long j4;
                long j5;
                long j6;
                int i12;
                int e = e(i2);
                j3 = 255;
                if (this.h != 0 || ((this.a[e >> 3] >> ((e & 7) << 3)) & 255) == 254) {
                    i10 = 0;
                    j4 = j2;
                    j5 = 255;
                    j6 = 128;
                } else {
                    long j7;
                    long[] jArr2;
                    int i13;
                    long j8;
                    e = this.f;
                    if (e > 8) {
                        j7 = 31;
                        j6 = 128;
                        if (Long.compare((((long) this.g) * 32) ^ Long.MIN_VALUE, (((long) e) * 25) ^ Long.MIN_VALUE) <= 0) {
                            jArr2 = this.a;
                            if (jArr2 == null) {
                                i10 = 0;
                                j4 = j2;
                                j5 = 255;
                            } else {
                                hashCode = this.f;
                                Object[] objArr = this.b;
                                long[] jArr3 = this.c;
                                long[] jArr4 = new long[hashCode];
                                i11 = 8;
                                Arrays.fill(jArr4, 0, hashCode, 9223372034707292159L);
                                i10 = 0;
                                i12 = (hashCode + 7) >> 3;
                                long j9 = 9223372034707292159L;
                                int i14 = i10;
                                while (i14 < i12) {
                                    j5 = j3;
                                    j3 = jArr2[i14] & -9187201950435737472L;
                                    int i15 = i14;
                                    jArr2[i15] = ((~j3) + (j3 >>> 7)) & -72340172838076674L;
                                    i14 = i15 + 1;
                                    j3 = j5;
                                }
                                j5 = j3;
                                i12 = jArr2.length;
                                i5 = i12 - 1;
                                i12 -= 2;
                                jArr2[i12] = (jArr2[i12] & 72057594037927935L) | -72057594037927936L;
                                jArr2[i5] = jArr2[i10];
                                i12 = i10;
                                while (i12 != hashCode) {
                                    int i16 = i12 >> 3;
                                    i13 = (i12 & 7) << 3;
                                    long j10 = (jArr2[i16] >> i13) & j5;
                                    if (j10 != 128) {
                                        if (j10 == 254) {
                                            Object obj3 = objArr[i12];
                                            int hashCode2 = (obj3 != null ? obj3.hashCode() : i10) * i6;
                                            hashCode2 ^= hashCode2 << 16;
                                            i5 = hashCode2 >>> 7;
                                            i14 = e(i5);
                                            i5 &= hashCode;
                                            int i17;
                                            Object[] objArr2;
                                            long j11;
                                            if (((i14 - i5) & hashCode) / 8 == ((i12 - i5) & hashCode) / 8) {
                                                i17 = hashCode;
                                                objArr2 = objArr;
                                                jArr2[i16] = (jArr2[i16] & (~(j5 << i13))) | (((long) (hashCode2 & 127)) << i13);
                                                if (jArr4[i12] == j9) {
                                                    j11 = (long) i12;
                                                    jArr4[i12] = j11 | (j11 << 32);
                                                }
                                                jArr2[jArr2.length - 1] = jArr2[i10];
                                                i12++;
                                                hashCode = i17;
                                                objArr = objArr2;
                                            } else {
                                                i17 = hashCode;
                                                objArr2 = objArr;
                                                hashCode = i14 >> 3;
                                                long j12 = jArr2[hashCode];
                                                i = (i14 & 7) << 3;
                                                int i18;
                                                if (((j12 >> i) & j5) == 128) {
                                                    i18 = i;
                                                    jArr2[hashCode] = (j12 & (~(j5 << i18))) | (((long) (hashCode2 & 127)) << i18);
                                                    jArr2[i16] = (jArr2[i16] & (~(j5 << i13))) | (128 << i13);
                                                    objArr2[i14] = objArr2[i12];
                                                    objArr2[i12] = null;
                                                    jArr3[i14] = jArr3[i12];
                                                    jArr3[i12] = 4611686018427387903L;
                                                    hashCode = (int) ((jArr4[i12] >> 32) & 4294967295L);
                                                    if (hashCode != Integer.MAX_VALUE) {
                                                        j4 = j2;
                                                        jArr4[hashCode] = ((long) i14) | (jArr4[hashCode] & -4294967296L);
                                                        jArr4[i12] = (jArr4[i12] & 4294967295L) | -4294967296L;
                                                    } else {
                                                        j4 = j2;
                                                        jArr4[i12] = 9223372032559808512L | ((long) i14);
                                                    }
                                                    jArr4[i14] = (((long) i12) << 32) | 2147483647L;
                                                } else {
                                                    i18 = i;
                                                    j4 = j2;
                                                    jArr2[hashCode] = (((long) (hashCode2 & 127)) << i18) | (j12 & (~(j5 << i18)));
                                                    Object obj4 = objArr2[i14];
                                                    objArr2[i14] = objArr2[i12];
                                                    objArr2[i12] = obj4;
                                                    j11 = jArr3[i14];
                                                    jArr3[i14] = jArr3[i12];
                                                    jArr3[i12] = j11;
                                                    hashCode = (int) ((jArr4[i12] >> 32) & 4294967295L);
                                                    if (hashCode != Integer.MAX_VALUE) {
                                                        j3 = (long) i14;
                                                        jArr4[hashCode] = (jArr4[hashCode] & -4294967296L) | j3;
                                                        jArr4[i12] = (jArr4[i12] & 4294967295L) | (j3 << 32);
                                                    } else {
                                                        j11 = (long) i14;
                                                        jArr4[i12] = j11 | (j11 << 32);
                                                        hashCode = i12;
                                                    }
                                                    jArr4[i14] = (((long) hashCode) << 32) | ((long) i12);
                                                    i12--;
                                                }
                                                jArr2[jArr2.length - 1] = jArr2[i10];
                                                i12++;
                                                hashCode = i17;
                                                objArr = objArr2;
                                                j2 = j4;
                                            }
                                        }
                                    }
                                    i12++;
                                }
                                j4 = j2;
                                this.h = n01.a(this.f) - this.g;
                                jArr2 = this.c;
                                i12 = jArr2.length;
                                for (hashCode = i10; hashCode < i12; hashCode++) {
                                    j8 = jArr2[hashCode];
                                    i = (int) ((j8 >> 31) & 2147483647L);
                                    i3 = (int) (j8 & 2147483647L);
                                    jArr2[hashCode] = (((j8 & -4611686018427387904L) | ((long) (i == Integer.MAX_VALUE ? Integer.MAX_VALUE : (int) (jArr4[i] & 4294967295L)))) << 31) | ((long) (i3 == Integer.MAX_VALUE ? Integer.MAX_VALUE : (int) (jArr4[i3] & 4294967295L)));
                                }
                                e = this.d;
                                if (e != Integer.MAX_VALUE) {
                                    this.d = (int) (jArr4[e] & 4294967295L);
                                }
                                e = this.e;
                                if (e != Integer.MAX_VALUE) {
                                    this.e = (int) (jArr4[e] & 4294967295L);
                                }
                            }
                            e = e(i2);
                        }
                    } else {
                        j7 = 31;
                        j6 = 128;
                    }
                    i10 = 0;
                    j4 = j2;
                    j5 = 255;
                    e = n01.b(this.f);
                    long[] jArr5 = this.a;
                    Object[] objArr3 = this.b;
                    long[] jArr6 = this.c;
                    i3 = this.f;
                    int[] iArr = new int[i3];
                    f(e);
                    jArr2 = this.a;
                    Object[] objArr4 = this.b;
                    jArr = this.c;
                    i8 = this.f;
                    int i19 = i10;
                    while (i19 < i3) {
                        long[] jArr7;
                        long[] jArr8;
                        if (((jArr5[i19 >> 3] >> ((i19 & 7) << 3)) & j5) < j6) {
                            Object obj5 = objArr3[i19];
                            i13 = (obj5 != null ? obj5.hashCode() : i10) * i6;
                            i13 ^= i13 << 16;
                            i7 = e(i13 >>> 7);
                            jArr7 = jArr2;
                            jArr8 = jArr5;
                            long j13 = (long) (i13 & 127);
                            i13 = i7 >> 3;
                            int i20 = (i7 & 7) << 3;
                            j13 = (jArr7[i13] & (~(j5 << i20))) | (j13 << i20);
                            jArr7[i13] = j13;
                            jArr7[(((i7 - 7) & i8) + (i8 & 7)) >> 3] = j13;
                            objArr4[i7] = obj5;
                            jArr[i7] = jArr6[i19];
                            iArr[i19] = i7;
                        } else {
                            jArr7 = jArr2;
                            jArr8 = jArr5;
                        }
                        i19++;
                        jArr5 = jArr8;
                        jArr2 = jArr7;
                    }
                    jArr2 = this.c;
                    i12 = jArr2.length;
                    for (hashCode = i10; hashCode < i12; hashCode++) {
                        j8 = jArr2[hashCode];
                        i = (int) ((j8 >> j7) & 2147483647L);
                        i3 = (int) (j8 & 2147483647L);
                        jArr2[hashCode] = (((j8 & -4611686018427387904L) | ((long) (i == Integer.MAX_VALUE ? Integer.MAX_VALUE : iArr[i]))) << j7) | ((long) (i3 == Integer.MAX_VALUE ? Integer.MAX_VALUE : iArr[i3]));
                    }
                    e = this.d;
                    if (e != Integer.MAX_VALUE) {
                        this.d = iArr[e];
                    }
                    e = this.e;
                    if (e != Integer.MAX_VALUE) {
                        this.e = iArr[e];
                    }
                    e = e(i2);
                }
                this.g++;
                i12 = this.h;
                long[] jArr9 = this.a;
                i = e >> 3;
                long j14 = jArr9[i];
                i4 = (e & 7) << 3;
                if (((j14 >> i4) & j5) == j6) {
                    i10 = i9;
                }
                this.h = i12 - i10;
                int i21 = this.f;
                j14 = (j14 & (~(j5 << i4))) | (j4 << i4);
                jArr9[i] = j14;
                jArr9[(((e - 7) & i21) + (i21 & 7)) >> 3] = j14;
                return e;
            }
            i10 = 0;
            i11 = 8;
            i5 += 8;
            i4 = (i4 + i5) & i3;
            i = i6;
        }
    }

    public final AutofillManager g(Object obj) {
        int numberOfTrailingZeros;
        Object obj2 = obj;
        AutofillManager autofillManager = null;
        int hashCode = (obj2 != null ? obj2.hashCode() : 0) * -862048943;
        hashCode ^= hashCode << 16;
        int i = hashCode & 127;
        int i2 = this.f;
        hashCode = (hashCode >>> 7) & i2;
        int i3 = 0;
        loop0:
        while (true) {
            long[] jArr = this.a;
            int i4 = hashCode >> 3;
            int i5 = (hashCode & 7) << 3;
            long j = ((jArr[i4 + 1] << (64 - i5)) & ((-((long) i5)) >> 63)) | (jArr[i4] >>> i5);
            long j2 = (((long) i) * 72340172838076673L) ^ j;
            for (j2 = ((~j2) & (j2 - 72340172838076673L)) & -9187201950435737472L; j2 != 0; j2 &= j2 - 1) {
                numberOfTrailingZeros = ((Long.numberOfTrailingZeros(j2) >> 3) + hashCode) & i2;
                if (k70.p(this.b[numberOfTrailingZeros], obj2)) {
                    break loop0;
                }
            }
            if (((j & ((~j) << 6)) & -9187201950435737472L) != 0) {
                numberOfTrailingZeros = -1;
                break;
            }
            i3 += 8;
            hashCode = (hashCode + i3) & i2;
        }
        if (numberOfTrailingZeros >= 0) {
            autofillManager = 1;
        }
        if (autofillManager != null) {
            h(numberOfTrailingZeros);
        }
        return autofillManager;
    }

    public final d81 c(Object obj) {
        int numberOfTrailingZeros;
        Object obj2 = obj;
        int hashCode = (obj2 != null ? obj2.hashCode() : 0) * -862048943;
        hashCode ^= hashCode << 16;
        int i = hashCode & 127;
        int i2 = this.f;
        hashCode = (hashCode >>> 7) & i2;
        int i3 = 0;
        loop0:
        while (true) {
            long[] jArr = this.a;
            int i4 = hashCode >> 3;
            int i5 = (hashCode & 7) << 3;
            long j = ((jArr[i4 + 1] << (64 - i5)) & ((-((long) i5)) >> 63)) | (jArr[i4] >>> i5);
            long j2 = (((long) i) * 72340172838076673L) ^ j;
            for (j2 = ((~j2) & (j2 - 72340172838076673L)) & -9187201950435737472L; j2 != 0; j2 &= j2 - 1) {
                numberOfTrailingZeros = ((Long.numberOfTrailingZeros(j2) >> 3) + hashCode) & i2;
                if (k70.p(this.b[numberOfTrailingZeros], obj2)) {
                    break loop0;
                }
            }
            if (((j & ((~j) << 6)) & -9187201950435737472L) != 0) {
                numberOfTrailingZeros = -1;
                break;
            }
            i3 += 8;
            hashCode = (hashCode + i3) & i2;
        }
        return numberOfTrailingZeros >= 0 ? 1 : null;
    }

    public final void h(int i) {
        this.g--;
        long[] jArr = this.a;
        int i2 = this.f;
        int i3 = i >> 3;
        int i4 = (i & 7) << 3;
        long j = (jArr[i3] & (~(255 << i4))) | (254 << i4);
        jArr[i3] = j;
        jArr[(((i - 7) & i2) + (i2 & 7)) >> 3] = j;
        this.b[i] = null;
        jArr = this.c;
        long j2 = jArr[i];
        int i5 = (int) ((j2 >> 31) & 2147483647L);
        i2 = (int) (j2 & 2147483647L);
        if (i5 != Integer.MAX_VALUE) {
            jArr[i5] = (jArr[i5] & -2147483648L) | (((long) i2) & 2147483647L);
        } else {
            this.d = i2;
        }
        if (i2 != Integer.MAX_VALUE) {
            jArr[i2] = ((((long) i5) & 2147483647L) << 31) | (jArr[i2] & -4611686016279904257L);
        } else {
            this.e = i5;
        }
        jArr[i] = 4611686018427387903L;
    }

    public final void f(int i) {
        long[] jArr;
        long[] jArr2;
        i = i > 0 ? Math.max(7, n01.c(i)) : 0;
        this.f = i;
        if (i == 0) {
            jArr = n01.a;
        } else {
            int i2 = ((i + 15) & -8) >> 3;
            long[] jArr3 = new long[i2];
            Arrays.fill(jArr3, 0, i2, -9187201950435737472L);
            jArr = jArr3;
        }
        this.a = jArr;
        int i3 = i >> 3;
        long j = 255 << ((i & 7) << 3);
        jArr[i3] = (jArr[i3] & (~j)) | j;
        this.h = n01.a(this.f) - this.g;
        this.b = i == 0 ? k70.l : new Object[i];
        if (i == 0) {
            jArr2 = gh0.l;
        } else {
            jArr = new long[i];
            Arrays.fill(jArr, 0, i, 4611686018427387903L);
            jArr2 = jArr;
        }
        this.c = jArr2;
    }

    public final boolean i(Collection collection) {
        collection.getClass();
        Object[] objArr = this.b;
        int i = this.g;
        long[] jArr = this.a;
        int length = jArr.length - 2;
        if (length >= 0) {
            int i2 = 0;
            while (true) {
                long j = jArr[i2];
                if (((((~j) << 7) & j) & -9187201950435737472L) != -9187201950435737472L) {
                    int i3 = 8 - ((~(i2 - length)) >>> 31);
                    for (int i4 = 0; i4 < i3; i4++) {
                        if ((255 & j) < 128) {
                            int i5 = (i2 << 3) + i4;
                            if (!tg.P(collection, objArr[i5])) {
                                h(i5);
                            }
                        }
                        j >>= 8;
                    }
                    if (i3 != 8) {
                        break;
                    }
                }
                if (i2 == length) {
                    break;
                }
                i2++;
            }
        }
        return i != this.g;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof bk0)) {
            return false;
        }
        bk0 bk0 = (bk0) obj;
        if (bk0.g != this.g) {
            return false;
        }
        Object[] objArr = this.b;
        long[] jArr = this.a;
        int length = jArr.length - 2;
        if (length >= 0) {
            int i = 0;
            while (true) {
                long j = jArr[i];
                if (((((~j) << 7) & j) & -9187201950435737472L) != -9187201950435737472L) {
                    int i2 = 8 - ((~(i - length)) >>> 31);
                    int i3 = 0;
                    while (i3 < i2) {
                        if ((255 & j) < 128 && bk0.c(objArr[(i << 3) + i3]) == null) {
                            return false;
                        }
                        j >>= 8;
                        i3++;
                    }
                    if (i2 != 8) {
                        break;
                    }
                }
                if (i == length) {
                    break;
                }
                i++;
            }
        }
        return true;
    }

    public final int hashCode() {
        int i = (this.f * 31) + this.g;
        Object[] objArr = this.b;
        long[] jArr = this.a;
        int length = jArr.length - 2;
        if (length >= 0) {
            int i2 = 0;
            while (true) {
                long j = jArr[i2];
                if (((((~j) << 7) & j) & -9187201950435737472L) != -9187201950435737472L) {
                    int i3 = 8 - ((~(i2 - length)) >>> 31);
                    for (int i4 = 0; i4 < i3; i4++) {
                        if ((255 & j) < 128) {
                            Object obj = objArr[(i2 << 3) + i4];
                            if (!k70.p(obj, this)) {
                                i += obj != null ? obj.hashCode() : 0;
                            }
                        }
                        j >>= 8;
                    }
                    if (i3 != 8) {
                        return i;
                    }
                }
                if (i2 == length) {
                    break;
                }
                i2++;
            }
        }
        return i;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("[");
        Object[] objArr = this.b;
        long[] jArr = this.c;
        int i = this.e;
        int i2 = 0;
        while (i != Integer.MAX_VALUE) {
            int i3 = (int) ((jArr[i] >> 31) & 2147483647L);
            bk0 bk0 = objArr[i];
            if (i2 == -1) {
                stringBuilder.append("...");
                break;
            }
            if (i2 != 0) {
                stringBuilder.append(", ");
            }
            stringBuilder.append(bk0 == this ? "(this)" : String.valueOf(bk0));
            i2++;
            i = i3;
        }
        stringBuilder.append("]");
        return stringBuilder.toString();
    }

    public final void b() {
        this.g = 0;
        long[] jArr = this.a;
        if (jArr != n01.a) {
            ba.d0(jArr, -9187201950435737472L);
            jArr = this.a;
            int i = this.f;
            int i2 = i >> 3;
            long j = 255 << ((i & 7) << 3);
            jArr[i2] = (jArr[i2] & (~j)) | j;
        }
        ba.c0(this.b, 0, this.f);
        ba.d0(this.c, 4611686018427387903L);
        this.d = Integer.MAX_VALUE;
        this.e = Integer.MAX_VALUE;
        this.h = n01.a(this.f) - this.g;
    }

    public final void a(Object obj) {
        int i = this.g;
        int d = d(obj);
        this.b[d] = obj;
        long[] jArr = this.c;
        int i2 = this.d;
        jArr[d] = (((long) i2) & 2147483647L) | 4611686016279904256L;
        if (i2 != Integer.MAX_VALUE) {
            jArr[i2] = ((2147483647L & ((long) d)) << 31) | (jArr[i2] & -4611686016279904257L);
        }
        this.d = d;
        if (this.e == Integer.MAX_VALUE) {
            this.e = d;
        }
        if (this.g == i) {
        }
    }

    public final int e(int i) {
        int i2 = this.f;
        i &= i2;
        int i3 = 0;
        while (true) {
            long[] jArr = this.a;
            int i4 = i >> 3;
            int i5 = (i & 7) << 3;
            long j = ((jArr[i4 + 1] << (64 - i5)) & ((-((long) i5)) >> 63)) | (jArr[i4] >>> i5);
            j = (j & ((~j) << 7)) & -9187201950435737472L;
            if (j != 0) {
                return (i + (Long.numberOfTrailingZeros(j) >> 3)) & i2;
            }
            i3 += 8;
            i = (i + i3) & i2;
        }
    }

    public bk0(int i) {
        if (i >= 0) {
            f(n01.d(i));
        } else {
            od.m("Capacity must be a positive value.");
            throw null;
        }
    }
}