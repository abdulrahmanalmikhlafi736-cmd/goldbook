package defpackage;

import android.view.autofill.AutofillManager;
import java.util.ArrayList;
import java.util.List;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bm0 */
public final class bm0 extends lm0 {
    public final li0 c;
    public final zh d;
    public final xf0 e = new h90(2);
    public gm0 f;
    public zs0 g;
    public boolean h;
    public boolean i = true;
    public boolean j = true;

    /* JADX WARNING: Missing block: B:140:0x02d1, code:
            if (r8 == 5) goto L_0x02d3;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean a(xf0 xf0, n90 n90, e70 e70, boolean z) {
        xf0 xf02 = xf0;
        n90 n902 = n90;
        e70 e702 = e70;
        boolean a = super.a(xf0, n90, e70, z);
        Object obj = this.c;
        boolean z2 = true;
        if (obj.r) {
            int i;
            hb0 hb0 = null;
            li0 li0;
            while (li0 != null) {
                if (li0 instanceof gt0) {
                    this.f = k70.M((gt0) li0, 16);
                } else if ((li0.g & 16) != 0 && (li0 instanceof dp)) {
                    i = 0;
                    for (li0 li02 = ((dp) li0).t; li02 != null; li02 = li02.j) {
                        if ((li02.g & 16) != 0) {
                            i++;
                            if (i == 1) {
                                li0 = li02;
                            } else {
                                if (hb0 == null) {
                                    hb0 = new qk0(new li0[16]);
                                }
                                if (obj != null) {
                                    r8.b(obj);
                                    obj = null;
                                }
                                r8.b(li02);
                            }
                        }
                    }
                    if (i == 1) {
                    }
                }
                obj = k70.m(hb0);
            }
            if (this.f != null) {
                zh zhVar;
                xf0 xf03;
                long j;
                boolean z3;
                boolean z4;
                gm0 gm0;
                int d = xf02.d();
                int i2 = 0;
                while (true) {
                    zhVar = this.d;
                    xf03 = this.e;
                    if (i2 >= d) {
                        break;
                    }
                    int i3;
                    int i4;
                    long a2 = xf02.a(i2);
                    dt0 dt0 = (dt0) xf02.e(i2);
                    if (zhVar.c(a2)) {
                        boolean z5 = z2;
                        j = dt0.g;
                        ArrayList arrayList = dt0.m;
                        long j2 = dt0.c;
                        if ((((j & 9223372034707292159L) + 36028792732385279L) & -9223372034707292160L) == 0 && (((j2 & 9223372034707292159L) + 36028792732385279L) & -9223372034707292160L) == 0) {
                            List list;
                            a91 a91;
                            xf0 xf04;
                            long j3;
                            dt0 dt02;
                            z3 = z5;
                            ut utVar = ut.e;
                            if (arrayList == null) {
                                list = utVar;
                            } else {
                                Object list2 = arrayList;
                            }
                            z4 = a;
                            ArrayList h90 = new h90(list2.size());
                            if (arrayList == null) {
                                a91 = utVar;
                            } else {
                                Object a912 = arrayList;
                            }
                            i3 = d;
                            d = a912.size();
                            i4 = i2;
                            i2 = 0;
                            while (i2 < d) {
                                int i5;
                                a91 a913 = a912;
                                a30 a30 = (a30) a912.get(i2);
                                xf04 = xf03;
                                j3 = a2;
                                long j4 = a30.b;
                                if ((((j4 & 9223372034707292159L) + 36028792732385279L) & -9223372034707292160L) == 0) {
                                    dt02 = dt0;
                                    long j5 = a30.a;
                                    i5 = d;
                                    gm0 gm02 = this.f;
                                    gm02.getClass();
                                    h90.add(new a30(j5, gm02.x(n902, j4), a30.c, a30.d, a30.e));
                                } else {
                                    i5 = d;
                                    dt02 = dt0;
                                }
                                i2++;
                                d = i5;
                                a912 = a913;
                                xf03 = xf04;
                                a2 = j3;
                                dt0 = dt02;
                            }
                            xf04 = xf03;
                            j3 = a2;
                            dt02 = dt0;
                            gm0 = this.f;
                            gm0.getClass();
                            long x = gm0.x(n902, j);
                            gm0 = this.f;
                            gm0.getClass();
                            long x2 = gm0.x(n902, j2);
                            dt0 dt03 = new dt0(dt0.a, dt0.b, x2, dt0.d, dt0.e, dt0.f, x, dt0.h, dt0.i, h90, dt0.j, dt0.k, dt0.l, dt0.n);
                            dt0 dt04 = dt0.q;
                            if (dt04 == null) {
                                dt04 = dt0;
                            }
                            dt03.q = dt04;
                            dt04 = dt0.q;
                            if (dt04 != null) {
                                dt0 = dt04;
                            }
                            dt03.q = dt0;
                            xf04.b(j3, dt03);
                        } else {
                            z4 = a;
                            i3 = d;
                            i4 = i2;
                            z3 = z5;
                        }
                    } else {
                        z4 = a;
                        i3 = d;
                        z3 = z2;
                        i4 = i2;
                    }
                    i2 = i4 + 1;
                    n902 = n90;
                    d = i3;
                    z2 = z3;
                    a = z4;
                }
                z4 = a;
                z3 = z2;
                xf0 xf05 = xf03;
                if (xf05.d() == 0) {
                    zhVar.e = 0;
                    this.a.g();
                    return z3;
                }
                int i6;
                int i7;
                Object obj2;
                boolean z6;
                for (i6 = zhVar.e - 1; -1 < i6; i6--) {
                    long j6 = ((long[]) zhVar.f)[i6];
                    if (xf02.e) {
                        d = xf02.h;
                        long[] jArr = xf02.f;
                        Object[] objArr = xf02.g;
                        int i8 = 0;
                        for (int i9 = 0; i9 < d; i9++) {
                            Object obj3 = objArr[i9];
                            if (obj3 != k70.o) {
                                if (i9 != i8) {
                                    jArr[i8] = jArr[i9];
                                    objArr[i8] = obj3;
                                    objArr[i9] = null;
                                }
                                i8++;
                            }
                        }
                        xf02.e = false;
                        xf02.h = i8;
                    }
                    if (k70.s(xf02.f, xf02.h, j6) < 0) {
                        d = zhVar.e;
                        if (i6 < d) {
                            d--;
                            int i10 = i6;
                            while (i10 < d) {
                                long[] jArr2 = (long[]) zhVar.f;
                                i = i10 + 1;
                                jArr2[i10] = jArr2[i];
                                i10 = i;
                            }
                            zhVar.e--;
                        }
                    }
                }
                ArrayList h902 = new h90(xf05.d());
                i6 = xf05.d();
                for (i7 = 0; i7 < i6; i7++) {
                    h902.add(xf05.e(i7));
                }
                zs0 zs0 = new zs0(h902, e702);
                i7 = h902.size();
                for (d = 0; d < i7; d++) {
                    obj2 = h902.get(d);
                    if (e702.a(((dt0) obj2).a)) {
                        break;
                    }
                }
                obj2 = null;
                dt0 dt05 = (dt0) obj2;
                if (dt05 != null) {
                    boolean z7 = dt05.d;
                    if (z) {
                        z6 = false;
                        if (!this.i && (z7 || dt05.h)) {
                            gm0 = this.f;
                            gm0.getClass();
                            long j7 = gm0.g;
                            j = dt05.c;
                            float intBitsToFloat = Float.intBitsToFloat((int) (j >> 32));
                            float intBitsToFloat2 = Float.intBitsToFloat((int) (j & 4294967295L));
                            this.i = ((intBitsToFloat2 > ((float) ((int) (j7 & 4294967295L))) ? z3 : 0) | ((intBitsToFloat2 < 0.0f ? z3 : 0) | ((intBitsToFloat > ((float) ((int) (j7 >> 32))) ? z3 : 0) | (intBitsToFloat < 0.0f ? z3 : 0)))) ^ 1;
                        }
                    } else {
                        z6 = false;
                        this.i = false;
                    }
                    a = this.i;
                    boolean z8 = this.h;
                    int i11 = 5;
                    if (a != z8) {
                        i2 = zs0.c;
                        if (i2 != 3) {
                            if (i2 == 4) {
                            }
                        }
                        if (a) {
                            i11 = 4;
                        }
                        zs0.c = i11;
                    }
                    i2 = zs0.c;
                    if (i2 == 4 && z8 && !this.j) {
                        zs0.c = 3;
                    } else if (i2 == 5 && a && z7) {
                        zs0.c = 3;
                    }
                } else {
                    z6 = false;
                }
                if (!z4 && zs0.c == 3) {
                    zs0 zs02 = this.g;
                    if (zs02 != null) {
                        List list3 = zs02.a;
                        int size = list3.size();
                        List list4 = zs0.a;
                        if (size == list4.size()) {
                            size = list4.size();
                            d = z6;
                            while (d < size) {
                                if (n60.b(((dt0) list3.get(d)).c, ((dt0) list4.get(d)).c) != null) {
                                    d++;
                                }
                            }
                            z2 = z6;
                            this.g = zs0;
                            return z2;
                        }
                    }
                }
                z2 = z3;
                this.g = zs0;
                return z2;
            }
        }
        return true;
    }

    /* JADX WARNING: Removed duplicated region for block: B:14:0x0022  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean e(e70 e70, boolean z) {
        if (this.e.d() == 0) {
            return false;
        }
        Object obj = this.c;
        if (obj.r) {
            boolean I;
            gm0 gm0 = obj.l;
            if (gm0 != null) {
                ba0 ba0 = gm0.s;
                if (ba0 != null) {
                    I = ba0.I();
                    if (I) {
                        zs0 zs0 = this.g;
                        zs0.getClass();
                        gm0 gm02 = this.f;
                        gm02.getClass();
                        long j = gm02.g;
                        Object obj2 = obj;
                        hb0 hb0 = null;
                        li0 li0;
                        while (li0 != null) {
                            boolean z2;
                            if (li0 instanceof gt0) {
                                ((gt0) li0).x(zs0, at0.e, j);
                                z2 = false;
                            } else {
                                z2 = true;
                            }
                            if (z2) {
                                if (((li0.g & 16) != 0) && (li0 instanceof dp)) {
                                    int i = 0;
                                    for (li0 li02 = ((dp) li0).t; li02 != null; li02 = li02.j) {
                                        if ((li02.g & 16) != 0) {
                                            i++;
                                            if (i == 1) {
                                                li0 = li02;
                                            } else {
                                                if (hb0 == null) {
                                                    hb0 = new qk0(new li0[16]);
                                                }
                                                if (obj2 != null) {
                                                    r7.b(obj2);
                                                    obj2 = null;
                                                }
                                                r7.b(li02);
                                            }
                                        }
                                    }
                                    if (i == 1) {
                                    }
                                }
                            }
                            obj2 = k70.m(hb0);
                        }
                        if (obj.r) {
                            qk0 qk0 = this.a;
                            Object[] objArr = qk0.e;
                            int i2 = qk0.g;
                            for (int i3 = 0; i3 < i2; i3++) {
                                bm0 bm0 = (bm0) objArr[i3];
                                this.f.getClass();
                                bm0.e(e70, z);
                            }
                        }
                        if (obj.r) {
                            hb0 hb02 = null;
                            li0 li03;
                            while (li03 != null) {
                                boolean z3;
                                if (li03 instanceof gt0) {
                                    ((gt0) li03).x(zs0, at0.f, j);
                                    z3 = false;
                                } else {
                                    z3 = true;
                                }
                                if (z3) {
                                    if (((li03.g & 16) != 0) && (li03 instanceof dp)) {
                                        int i4 = 0;
                                        for (li0 li04 = ((dp) li03).t; li04 != null; li04 = li04.j) {
                                            if ((li04.g & 16) != 0) {
                                                i4++;
                                                if (i4 == 1) {
                                                    li03 = li04;
                                                } else {
                                                    if (hb02 == null) {
                                                        hb02 = new qk0(new li0[16]);
                                                    }
                                                    if (obj != null) {
                                                        r13.b(obj);
                                                        obj = null;
                                                    }
                                                    r13.b(li04);
                                                }
                                            }
                                        }
                                        if (i4 == 1) {
                                        }
                                    }
                                }
                                obj = k70.m(hb02);
                            }
                        }
                        return true;
                    }
                }
            }
            I = false;
            if (I) {
            }
        }
        return false;
    }

    /* JADX WARNING: Removed duplicated region for block: B:14:0x0025  */
    /* JADX WARNING: Removed duplicated region for block: B:13:0x0024  */
    /* JADX WARNING: Removed duplicated region for block: B:55:0x00ad A:{LOOP_END, LOOP:3: B:54:0x00ab->B:55:0x00ad} */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean d(e70 e70) {
        boolean z;
        int i;
        Object[] objArr;
        int i2;
        xf0 xf0 = this.e;
        if (xf0.d() != 0) {
            li0 li0 = this.c;
            if (li0.r) {
                boolean I;
                gm0 gm0 = li0.l;
                if (gm0 != null) {
                    ba0 ba0 = gm0.s;
                    if (ba0 != null) {
                        I = ba0.I();
                        if (!I) {
                            zs0 zs0 = this.g;
                            zs0.getClass();
                            gm0 gm02 = this.f;
                            gm02.getClass();
                            long j = gm02.g;
                            Object obj = li0;
                            hb0 hb0 = null;
                            while (true) {
                                z = true;
                                li0 li02;
                                if (li02 == null) {
                                    break;
                                }
                                int i3;
                                if (li02 instanceof gt0) {
                                    ((gt0) li02).x(zs0, at0.g, j);
                                    i3 = 0;
                                } else {
                                    i3 = true;
                                }
                                if (i3 != 0) {
                                    if (((li02.g & 16) != 0) && (li02 instanceof dp)) {
                                        int i4 = 0;
                                        for (li0 li03 = ((dp) li02).t; li03 != null; li03 = li03.j) {
                                            if ((li03.g & 16) != 0) {
                                                i4++;
                                                if (i4 == 1) {
                                                    li02 = li03;
                                                } else {
                                                    if (hb0 == null) {
                                                        hb0 = new qk0(new li0[16]);
                                                    }
                                                    if (obj != null) {
                                                        r8.b(obj);
                                                        obj = null;
                                                    }
                                                    r8.b(li03);
                                                }
                                            }
                                        }
                                        if (i4 == 1) {
                                        }
                                    }
                                }
                                obj = k70.m(hb0);
                            }
                            if (li0.r) {
                                qk0 qk0 = this.a;
                                Object[] objArr2 = qk0.e;
                                int i5 = qk0.g;
                                for (int i6 = 0; i6 < i5; i6++) {
                                    ((bm0) objArr2[i6]).d(e70);
                                }
                            }
                            b(e70);
                            i = xf0.h;
                            objArr = xf0.g;
                            for (i2 = 0; i2 < i; i2++) {
                                objArr[i2] = null;
                            }
                            xf0.h = 0;
                            xf0.e = false;
                            this.f = null;
                            return z;
                        }
                    }
                }
                I = false;
                if (!I) {
                }
            }
        }
        z = false;
        b(e70);
        i = xf0.h;
        objArr = xf0.g;
        while (i2 < i) {
        }
        xf0.h = 0;
        xf0.e = false;
        this.f = null;
        return z;
    }

    public final void c() {
        qk0 qk0 = this.a;
        Object[] objArr = qk0.e;
        int i = qk0.g;
        for (int i2 = 0; i2 < i; i2++) {
            ((bm0) objArr[i2]).c();
        }
        Object obj = this.c;
        hb0 hb0 = null;
        li0 li0;
        while (li0 != null) {
            if (li0 instanceof gt0) {
                ((gt0) li0).R();
            } else if ((li0.g & 16) != 0 && (li0 instanceof dp)) {
                int i3 = 0;
                for (li0 li02 = ((dp) li0).t; li02 != null; li02 = li02.j) {
                    if ((li02.g & 16) != 0) {
                        i3++;
                        if (i3 == 1) {
                            li0 = li02;
                        } else {
                            if (hb0 == null) {
                                hb0 = new qk0(new li0[16]);
                            }
                            if (obj != null) {
                                r1.b(obj);
                                obj = null;
                            }
                            r1.b(li02);
                        }
                    }
                }
                if (i3 == 1) {
                }
            }
            obj = k70.m(hb0);
        }
    }

    public final void b(e70 e70) {
        super.b(e70);
        zs0 zs0 = this.g;
        if (zs0 != null) {
            this.h = this.i;
            List list = zs0.a;
            int size = list.size();
            boolean z = false;
            for (int i = 0; i < size; i++) {
                dt0 dt0 = (dt0) list.get(i);
                boolean z2 = dt0.d;
                long j = dt0.a;
                boolean a = e70.a(j);
                boolean z3 = this.i;
                if (!((z2 || a) && (z2 || z3))) {
                    this.d.g(j);
                }
            }
            this.i = false;
            if (zs0.c == 5) {
                z = true;
            }
            this.j = z;
        }
    }

    public final void f(long j, ak0 ak0) {
        zh zhVar = this.d;
        if (zhVar.c(j)) {
            if (((AutofillManager) ak0) < null) {
                zhVar.g(j);
                this.e.c(j);
            }
        }
        qk0 qk0 = this.a;
        Object[] objArr = qk0.e;
        int i = qk0.g;
        for (int i2 = 0; i2 < i; i2++) {
            ((bm0) objArr[i2]).f(j, ak0);
        }
    }

    public final String toString() {
        StringBuilder dl1 = new dl1("Node(modifierNode=");
        dl1.append(this.c);
        dl1.append(", children=");
        dl1.append(this.a);
        dl1.append(", pointerIds=");
        dl1.append(this.d);
        dl1.append(')');
        return dl1.toString();
    }

    public bm0(li0 li0) {
        this.c = li0;
        zh obj = new Object();
        obj.f = new long[2];
        this.d = obj;
    }
}