package defpackage;

import java.util.ArrayList;
import java.util.List;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bt */
public final class bt implements Runnable {
    public final ArrayList e;
    public final int f;

    public final void run() {
        ArrayList arrayList = this.e;
        int size = arrayList.size();
        int i = 0;
        if (this.f != 1) {
            while (i < size) {
                ((mo) arrayList.get(i)).b.f = k70.m;
                i++;
            }
            return;
        }
        while (i < size) {
            mo moVar = (mo) arrayList.get(i);
            moVar.a.setValue(Boolean.TRUE);
            moVar.b.f = new h80(true);
            i++;
        }
    }

    public bt(List list, int i, Throwable th) {
        ua0.i(list, "initCallbacks cannot be null");
        this.e = new ArrayList(list);
        this.f = i;
    }
}