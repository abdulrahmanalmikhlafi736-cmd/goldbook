package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: jp */
public interface jp {
    int F(float f);

    long K(long j);

    float N(long j);

    long V(float f);

    float a();

    float b0(int i);

    float c0(float f);

    float g();

    float q(float f);

    float y(long j);
}