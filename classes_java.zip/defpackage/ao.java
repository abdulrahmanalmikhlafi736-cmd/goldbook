package defpackage;

import androidx.compose.ui.input.pointer.PointerInputEventHandler;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ao */
public final class ao extends u91 implements m00 {
    public final /* synthetic */ int i;
    public int j;
    public /* synthetic */ Object k;

    public final Object p(Object obj) {
        int i = this.i;
        Object obj2 = we1.a;
        String str = "call to 'resume' before 'invoke' with coroutine";
        cm cmVar = cm.e;
        int i2;
        switch (i) {
            case 0:
                i = this.j;
                if (i == 0) {
                    nb0.t(obj);
                    lw0 obj3 = new Object();
                    lw0 obj4 = new Object();
                    lw0 obj5 = new Object();
                    bo boVar = (bo) this.k;
                    g51 g51 = boVar.s.a;
                    ef efVar = new ef(obj3, obj4, obj5, boVar, 1);
                    this.j = 1;
                    g51.getClass();
                    g51.j(g51, efVar, this);
                    obj2 = cmVar;
                } else if (i == 1) {
                    nb0.t(obj);
                } else {
                    od.p(str);
                    obj2 = null;
                }
                return obj2;
            case 1:
                i = this.j;
                if (i == 0) {
                    nb0.t(obj);
                    vy vyVar = (vy) this.k;
                    this.j = 1;
                    if (vd1.g(vyVar, null, this) == cmVar) {
                        obj2 = cmVar;
                    }
                } else if (i == 1) {
                    nb0.t(obj);
                } else {
                    od.p(str);
                    obj2 = null;
                }
                return obj2;
            case 2:
                mk0 mk0 = (mk0) this.k;
                i2 = this.j;
                if (i2 == 0) {
                    nb0.t(obj);
                    if (((Boolean) mk0.getValue()).booleanValue()) {
                        this.j = 1;
                        if (j70.A(1500, this) == cmVar) {
                            obj2 = cmVar;
                        }
                    }
                    return obj2;
                } else if (i2 == 1) {
                    nb0.t(obj);
                } else {
                    od.p(str);
                    obj2 = null;
                    return obj2;
                }
                mk0.setValue(Boolean.FALSE);
                return obj2;
            case 3:
                i = this.j;
                if (i == 0) {
                    nb0.t(obj);
                    p8 p8Var = (p8) ((al) this.k).g;
                    Float br0 = new br0(0.0f);
                    p71 G = zi1.G(0.0f, 400.0f, new br0(0.5f), 1);
                    this.j = 1;
                    if (wa0.c(p8Var, br0, G, new h90(3), this) == cmVar) {
                        obj2 = cmVar;
                    }
                } else if (i == 1) {
                    nb0.t(obj);
                } else {
                    od.p(str);
                    obj2 = null;
                }
                return obj2;
            case gu0.LONG_FIELD_NUMBER /*4*/:
                nb0.t(obj);
                sc0 sc0 = (sc0) this.k;
                int i3 = this.j;
                rf rfVar = sc0.e;
                if (!(((iq0) rfVar.b).g() == i3 && ((iq0) rfVar.c).g() == 0)) {
                    fb0 fb0 = sc0.n;
                    fb0.c();
                    fb0.b = null;
                }
                rfVar.b(i3, 0);
                rfVar.d = null;
                ba0 ba0 = sc0.k;
                if (ba0 != null) {
                    ba0.k();
                }
                return obj2;
            case gu0.STRING_FIELD_NUMBER /*5*/:
                bm bmVar;
                i = this.j;
                if (i == 0) {
                    nb0.t(obj);
                    bmVar = (bm) this.k;
                } else if (i == 1) {
                    bmVar = (bm) this.k;
                    nb0.t(obj);
                } else {
                    od.p(str);
                    obj2 = null;
                    return obj2;
                }
                while (j70.L(bmVar.f())) {
                    z1 h90 = new h90(15);
                    this.k = bmVar;
                    this.j = 1;
                    sl slVar = this.f;
                    slVar.getClass();
                    if (sb0.o(slVar).c(h90, this) == cmVar) {
                        obj2 = cmVar;
                        return obj2;
                    }
                }
                return obj2;
            case gu0.STRING_SET_FIELD_NUMBER /*6*/:
                i = this.j;
                if (i == 0) {
                    nb0.t(obj);
                    obj = (id) ((tp) this.k).f;
                    this.j = 1;
                    obj = vd1.i(new ao(obj, null, 12), this);
                    if (obj == cmVar) {
                        obj = cmVar;
                    }
                } else if (i == 1) {
                    nb0.t(obj);
                } else {
                    od.p(str);
                    obj = null;
                }
                return obj;
            case gu0.DOUBLE_FIELD_NUMBER /*7*/:
                i = this.j;
                if (i == 0) {
                    nb0.t(obj);
                    tw twVar = ((t41) this.k).c.b;
                    this.j = 1;
                    obj = wl1.x(twVar, this);
                    if (obj == cmVar) {
                        obj = cmVar;
                    }
                } else if (i == 1) {
                    nb0.t(obj);
                } else {
                    od.p(str);
                    obj = null;
                }
                return obj;
            case 8:
                y91 y91 = (y91) this.k;
                i2 = this.j;
                if (i2 == 0) {
                    nb0.t(obj);
                    PointerInputEventHandler pointerInputEventHandler = y91.u;
                    this.j = 2;
                    if (pointerInputEventHandler.invoke(y91, this) == cmVar) {
                        obj2 = cmVar;
                    }
                } else if (i2 == 1 || i2 == 2) {
                    nb0.t(obj);
                } else {
                    od.p(str);
                    obj2 = null;
                }
                return obj2;
            default:
                i = this.j;
                if (i == 0) {
                    nb0.t(obj);
                    lw0 obj6 = new Object();
                    hc1 hc1 = (hc1) this.k;
                    g51 g512 = hc1.s.a;
                    xq alVar = new al(5, obj6, hc1);
                    this.j = 1;
                    g512.getClass();
                    g51.j(g512, alVar, this);
                    obj2 = cmVar;
                } else if (i == 1) {
                    nb0.t(obj);
                } else {
                    od.p(str);
                    obj2 = null;
                }
                return obj2;
        }
    }

    public final Object f(Object obj, Object obj2) {
        int i = this.i;
        we1 we1 = we1.a;
        switch (i) {
            case 0:
                return ((ao) n((ml) obj2, (bm) obj)).p(we1);
            case 1:
                return ((ao) n((ml) obj2, (bm) obj)).p(we1);
            case 2:
                return ((ao) n((ml) obj2, (bm) obj)).p(we1);
            case 3:
                return ((ao) n((ml) obj2, (bm) obj)).p(we1);
            case gu0.LONG_FIELD_NUMBER /*4*/:
                ((ao) n((ml) obj2, (a11) obj)).p(we1);
                return we1;
            case gu0.STRING_FIELD_NUMBER /*5*/:
                return ((ao) n((ml) obj2, (bm) obj)).p(we1);
            case gu0.STRING_SET_FIELD_NUMBER /*6*/:
                return ((ao) n((ml) obj2, (bm) obj)).p(we1);
            case gu0.DOUBLE_FIELD_NUMBER /*7*/:
                return ((ao) n((ml) obj2, (bm) obj)).p(we1);
            case 8:
                return ((ao) n((ml) obj2, (bm) obj)).p(we1);
            default:
                return ((ao) n((ml) obj2, (bm) obj)).p(we1);
        }
    }

    public final ml n(ml mlVar, Object obj) {
        switch (this.i) {
            case 0:
                return new ao((bo) this.k, mlVar, 0);
            case 1:
                return new ao((vy) this.k, mlVar, 1);
            case 2:
                return new ao((mk0) this.k, mlVar, 2);
            case 3:
                return new ao((al) this.k, mlVar, 3);
            case gu0.LONG_FIELD_NUMBER /*4*/:
                return new ao((sc0) this.k, this.j, mlVar);
            case gu0.STRING_FIELD_NUMBER /*5*/:
                this = new ao(2, mlVar);
                this.k = obj;
                return this;
            case gu0.STRING_SET_FIELD_NUMBER /*6*/:
                return new ao((tp) this.k, mlVar, 6);
            case gu0.DOUBLE_FIELD_NUMBER /*7*/:
                return new ao((t41) this.k, mlVar, 7);
            case 8:
                return new ao((y91) this.k, mlVar, 8);
            default:
                return new ao((hc1) this.k, mlVar, 9);
        }
    }

    public ao(sc0 sc0, int i, ml mlVar) {
        this.i = 4;
        this.k = sc0;
        this.j = i;
        super(2, mlVar);
    }

    public /* synthetic */ ao(int i, ml mlVar) {
        this.i = 5;
        super(i, mlVar);
    }
}