package defpackage;

import android.view.View;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ch1 */
public abstract class ch1 extends View implements kp0 {
    public static final /* synthetic */ int e = 0;

    static {
        zp h90 = new h90(2);
    }
}