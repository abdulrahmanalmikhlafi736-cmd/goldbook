package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: gt0 */
public interface gt0 extends cp {
    boolean J();

    void L();

    void R();

    void a0();

    long l();

    void x(zs0 zs0, at0 at0, long j);
}