package defpackage;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: c0 */
public abstract class c0 extends v {
    public final boolean containsAll(Collection collection) {
        Iterable<Object> iterable = collection;
        if ((iterable instanceof Collection) && ((Collection) iterable).isEmpty()) {
            return true;
        }
        for (Object contains : iterable) {
            if (!contains(contains)) {
                return false;
            }
        }
        return true;
    }

    public c0 e(Collection collection) {
        es0 f = f();
        f.addAll(collection);
        return f.c();
    }

    public final boolean contains(Object obj) {
        return indexOf(obj) != -1;
    }

    public final Iterator iterator() {
        return listIterator(0);
    }

    public final ListIterator listIterator() {
        return listIterator(0);
    }

    public final List subList(int i, int i2) {
        return new j40(this, i, i2);
    }

    public abstract c0 b(int i, Object obj);

    public abstract d81 c(Object obj);

    public abstract es0 f();

    public abstract c0 g(b0 b0Var);

    public abstract c0 h(int i);

    public abstract c0 i(int i, Object obj);
}