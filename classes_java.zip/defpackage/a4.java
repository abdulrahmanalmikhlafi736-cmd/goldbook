package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: a4 */
public final class a4 extends h90 implements i00 {
    public final /* synthetic */ int f;
    public final /* synthetic */ ks0 g;

    public final Object i(Object obj) {
        int i = this.f;
        we1 we1 = we1.a;
        ks0 ks0 = this.g;
        switch (i) {
            case 0:
                js0.h((js0) obj, ks0, 0, 0);
                return we1;
            case 1:
                js0.h((js0) obj, ks0, 0, 0);
                return we1;
            case 2:
                js0.h((js0) obj, ks0, 0, 0);
                return we1;
            case 3:
                js0.h((js0) obj, ks0, 0, 0);
                return we1;
            case gu0.LONG_FIELD_NUMBER /*4*/:
                js0.j((js0) obj, ks0, 0, 0);
                return we1;
            default:
                js0.l((js0) obj, ks0, 0, 0);
                return we1;
        }
    }

    public /* synthetic */ a4(ks0 ks0, int i) {
        this.f = i;
        this.g = ks0;
        super(1);
    }
}