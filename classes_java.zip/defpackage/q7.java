package defpackage;

import android.content.Context;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.Region.Op;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewParent;
import java.util.Arrays;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: q7 */
public abstract class q7 extends ViewGroup implements wi, mp0, an0 {
    public int A;
    public final vj B;
    public boolean C;
    public final ba0 D;
    public final rl0 e;
    public final View f;
    public final lp0 g;
    public xz h = b5.r;
    public boolean i;
    public xz j = b5.q;
    public xz k = b5.p;
    public mi0 l = ji0.a;
    public i00 m;
    public jp n = vd1.b();
    public i00 o;
    public sd0 p;
    public xz0 q;
    public final int[] r = new int[2];
    public long s = 0;
    public hk1 t;
    public i00 u;
    public final p7 v;
    public final p7 w;
    public i00 x;
    public final int[] y;
    public int z;

    public q7(Context context, b10 b10, int i, rl0 rl0, View view, lp0 lp0) {
        super(context);
        this.e = rl0;
        this.f = view;
        this.g = lp0;
        hk0 hk0 = cl1.a;
        setTag(2131034155, b10);
        setSaveFromParentEnabled(false);
        addView(view);
        ah1 ah1 = (ah1) this;
        vg1.b(this, new j7(ah1, 0));
        qg1.b(this, this);
        this.v = new l7(ah1, 1);
        this.w = new l7(ah1, 0);
        this.y = new int[2];
        this.z = Integer.MIN_VALUE;
        this.A = Integer.MIN_VALUE;
        this.B = new h90(21);
        ba0 h90 = new h90(3);
        h90.s = ah1;
        mi0 b = ((qi0) zi1.B(rl0)).b(new l9(i4.n, true));
        jt0 jt0 = new jt0();
        jt0.a = new l7(ah1, 2);
        cd cdVar = new cd();
        cd cdVar2 = jt0.b;
        if (cdVar2 != null) {
            cdVar2.f = null;
        }
        jt0.b = cdVar;
        cdVar.f = jt0;
        setOnRequestDisallowInterceptTouchEvent$ui(cdVar);
        b = a5.B(vn.q(b.b(jt0), new n7(ah1, h90, ah1)), new k7(ah1, h90, 2)).b(new pc(new l7(ah1, 1)));
        h90.d0(this.l.b(b));
        this.m = new al(2, h90, b);
        h90.Z(this.n);
        this.o = new j3(5, h90);
        h90.Q = new k7(ah1, h90, 0);
        h90.R = new l7(ah1, 0);
        h90.c0(new m7(ah1, h90));
        this.D = h90;
    }

    /* JADX WARNING: Removed duplicated region for block: B:29:0x008b  */
    /* JADX WARNING: Removed duplicated region for block: B:28:0x0088  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        b71 b71 = getSnapshotObserver().a;
        synchronized (b71.g) {
            qk0 qk0 = b71.f;
            int i = qk0.g;
            int i2 = 0;
            int i3 = 0;
            while (true) {
                Object[] objArr = qk0.e;
                if (i2 < i) {
                    int i4;
                    a71 a71 = (a71) objArr[i2];
                    zj0 zj0 = (zj0) a71.f.k(this);
                    if (zj0 != null) {
                        Object[] objArr2 = zj0.b;
                        int[] iArr = zj0.c;
                        long[] jArr = zj0.a;
                        int length = jArr.length - 2;
                        if (length >= 0) {
                            int i5 = 0;
                            while (true) {
                                long j = jArr[i5];
                                i4 = i2;
                                if (((((~j) << 7) & j) & -9187201950435737472L) != -9187201950435737472L) {
                                    i2 = 8;
                                    int i6 = 8 - ((~(i5 - length)) >>> 31);
                                    int i7 = 0;
                                    while (i7 < i6) {
                                        long j2;
                                        if ((j & 255) < 128) {
                                            int i8 = (i5 << 3) + i7;
                                            j2 = i2;
                                            Object obj = objArr2[i8];
                                            i8 = iArr[i8];
                                            a71.c(this, obj);
                                        } else {
                                            j2 = i2;
                                        }
                                        j >>= j2;
                                        i7++;
                                        i2 = j2;
                                    }
                                    if (i6 != i2) {
                                        break;
                                    }
                                }
                                if (i5 == length) {
                                    break;
                                }
                                i5++;
                                i2 = i4;
                            }
                            if (a71.f.j()) {
                                i3++;
                            } else if (i3 > 0) {
                                Object[] objArr3 = qk0.e;
                                objArr3[i4 - i3] = objArr3[i4];
                            }
                            i2 = i4 + 1;
                        }
                    }
                    i4 = i2;
                    if (a71.f.j()) {
                    }
                    i2 = i4 + 1;
                } else {
                    int i9 = i - i3;
                    Arrays.fill(objArr, i9, i, null);
                    qk0.g = i9;
                }
            }
        }
    }

    public final hk1 g(hk1 hk1) {
        dk1 dk1 = hk1.a;
        c60 i = dk1.i(-1);
        c60 c60 = c60.e;
        if (!(i.equals(c60) && dk1.j(-9).equals(c60) && dk1.h() == null)) {
            v50 v50 = this.D.J.c;
            if (v50.U.r) {
                long C = vd1.C(v50.B(0));
                int i2 = (int) (C >> 32);
                int i3 = 0;
                if (i2 < 0) {
                    i2 = 0;
                }
                int i4 = (int) (C & 4294967295L);
                if (i4 < 0) {
                    i4 = 0;
                }
                long A = k70.D(v50).A();
                int i5 = (int) (A >> 32);
                int i6 = (int) (A & 4294967295L);
                long j = v50.g;
                j = vd1.C(v50.B((((long) Float.floatToRawIntBits((float) ((int) (j >> 32)))) << 32) | (((long) Float.floatToRawIntBits((float) ((int) (j & 4294967295L)))) & 4294967295L)));
                i5 -= (int) (j >> 32);
                if (i5 < 0) {
                    i5 = 0;
                }
                i6 -= (int) (4294967295L & j);
                if (i6 >= 0) {
                    i3 = i6;
                }
                if (!(i2 == 0 && i4 == 0 && i5 == 0 && i3 == 0)) {
                    return hk1.a.r(i2, i4, i5, i3);
                }
            }
        }
        return hk1;
    }

    public final void onMeasure(int i, int i2) {
        View view = this.f;
        if (view.getParent() != this) {
            setMeasuredDimension(MeasureSpec.getSize(i), MeasureSpec.getSize(i2));
        } else if (view.getVisibility() == 8) {
            setMeasuredDimension(0, 0);
        } else {
            view.measure(i, i2);
            setMeasuredDimension(view.getMeasuredWidth(), view.getMeasuredHeight());
            this.z = i;
            this.A = i2;
        }
    }

    public static final int e(ah1 ah1, int i, int i2, int i3) {
        if (i3 < 0) {
            if (i != i2) {
                if (i3 != -2 || i2 == Integer.MAX_VALUE) {
                    return (i3 != -1 || i2 == Integer.MAX_VALUE) ? MeasureSpec.makeMeasureSpec(0, 0) : MeasureSpec.makeMeasureSpec(i2, 1073741824);
                } else {
                    return MeasureSpec.makeMeasureSpec(i2, Integer.MIN_VALUE);
                }
            }
        }
        return MeasureSpec.makeMeasureSpec(sb0.h(i3, i, i2), 1073741824);
    }

    public final boolean onNestedFling(View view, float f, float f2, boolean z) {
        if (!this.f.isNestedScrollingEnabled()) {
            return false;
        }
        boolean z2 = z;
        wl1.B(this.e.c(), null, new o7(z2, this, kb0.c(f * -1.0f, f2 * -1.0f), null), 3);
        return false;
    }

    public final boolean onNestedPreFling(View view, float f, float f2) {
        if (!this.f.isNestedScrollingEnabled()) {
            return false;
        }
        wl1.B(this.e.c(), null, new o11(this, kb0.c(f * -1.0f, f2 * -1.0f), null, 3), 3);
        return false;
    }

    public final boolean gatherTransparentRegion(Region region) {
        if (region == null) {
            return true;
        }
        int[] iArr = this.y;
        getLocationInWindow(iArr);
        int i = iArr[0];
        Region region2 = region;
        region2.op(i, iArr[1], getWidth() + i, getHeight() + iArr[1], Op.DIFFERENCE);
        return true;
    }

    public static c60 f(c60 c60, int i, int i2, int i3, int i4) {
        int i5 = c60.a - i;
        i = 0;
        if (i5 < 0) {
            i5 = 0;
        }
        int i6 = c60.b - i2;
        if (i6 < 0) {
            i6 = 0;
        }
        i2 = c60.c - i3;
        if (i2 < 0) {
            i2 = 0;
        }
        int i7 = c60.d - i4;
        if (i7 >= 0) {
            i = i7;
        }
        return c60.b(i5, i6, i2, i);
    }

    public final boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z) {
        i00 i00 = this.u;
        if (i00 != null) {
            i00.i(rect != null ? new gw0((float) rect.left, (float) rect.top, (float) rect.right, (float) rect.bottom) : null);
        }
        return true;
    }

    public final ViewParent invalidateChildInParent(int[] iArr, Rect rect) {
        super.invalidateChildInParent(iArr, rect);
        if (this.C) {
            this.f.postOnAnimation(new p2(this.w, 2));
        } else {
            this.D.C();
        }
        return null;
    }

    public final void onDescendantInvalidated(View view, View view2) {
        super.onDescendantInvalidated(view, view2);
        if (this.C) {
            this.f.postOnAnimation(new p2(this.w, 2));
            return;
        }
        this.D.C();
    }

    private final op0 getSnapshotObserver() {
        if (!isAttachedToWindow()) {
            a5.b("Expected AndroidViewHolder to be attached when observing reads.");
        }
        return ((n4) this.g).getSnapshotObserver();
    }

    public LayoutParams getLayoutParams() {
        LayoutParams layoutParams = this.f.getLayoutParams();
        return layoutParams == null ? new xo0(-1, -1) : layoutParams;
    }

    public final void requestDisallowInterceptTouchEvent(boolean z) {
        i00 i00 = this.x;
        if (i00 != null) {
            i00.i(Boolean.valueOf(z));
        }
        super.requestDisallowInterceptTouchEvent(z);
    }

    public final void setDensity(jp jpVar) {
        if (jpVar != this.n) {
            this.n = jpVar;
            i00 i00 = this.o;
            if (i00 != null) {
                i00.i(jpVar);
            }
        }
    }

    public final void setModifier(mi0 mi0) {
        if (mi0 != this.l) {
            this.l = mi0;
            i00 i00 = this.m;
            if (i00 != null) {
                i00.i(mi0);
            }
        }
    }

    public final void setLifecycleOwner(sd0 sd0) {
        if (sd0 != this.p) {
            this.p = sd0;
            setTag(2131034229, sd0);
        }
    }

    public final void setSavedStateRegistryOwner(xz0 xz0) {
        if (xz0 != this.q) {
            this.q = xz0;
            setTag(2131034232, xz0);
        }
    }

    public final hk1 b(View view, hk1 hk1) {
        this.t = new hk1(hk1);
        return g(hk1);
    }

    public final void setUpdate(xz xzVar) {
        this.h = xzVar;
        this.i = true;
        this.v.a();
    }

    public final void c() {
        this.j.a();
        removeAllViewsInLayout();
    }

    public CharSequence getAccessibilityClassName() {
        return getClass().getName();
    }

    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.v.a();
    }

    public final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        this.f.layout(0, 0, i3 - i, i4 - i2);
    }

    public int getNestedScrollAxes() {
        this.B.getClass();
        return 0;
    }

    public final boolean isNestedScrollingEnabled() {
        return this.f.isNestedScrollingEnabled();
    }

    public final void a() {
        this.k.a();
    }

    public final boolean r() {
        return isAttachedToWindow();
    }

    public final void onWindowVisibilityChanged(int i) {
        super.onWindowVisibilityChanged(i);
    }

    public final jp getDensity() {
        return this.n;
    }

    public final View getInteropView() {
        return this.f;
    }

    public final ba0 getLayoutNode() {
        return this.D;
    }

    public final sd0 getLifecycleOwner() {
        return this.p;
    }

    public final mi0 getModifier() {
        return this.l;
    }

    public final i00 getOnDensityChanged$ui() {
        return this.o;
    }

    public final i00 getOnModifierChanged$ui() {
        return this.m;
    }

    public final i00 getOnRequestDisallowInterceptTouchEvent$ui() {
        return this.x;
    }

    public final xz getRelease() {
        return this.k;
    }

    public final xz getReset() {
        return this.j;
    }

    public final xz0 getSavedStateRegistryOwner() {
        return this.q;
    }

    public final xz getUpdate() {
        return this.h;
    }

    public final View getView() {
        return this.f;
    }

    public final void setOnDensityChanged$ui(i00 i00) {
        this.o = i00;
    }

    public final void setOnModifierChanged$ui(i00 i00) {
        this.m = i00;
    }

    public final void setOnRequestDisallowInterceptTouchEvent$ui(i00 i00) {
        this.x = i00;
    }

    public final void setRelease(xz xzVar) {
        this.k = xzVar;
    }

    public final void setReset(xz xzVar) {
        this.j = xzVar;
    }

    public final boolean shouldDelayChildPressedState() {
        return true;
    }
}