package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: aa1 */
public final /* synthetic */ class aa1 implements m00 {
    public final /* synthetic */ boolean e;
    public final /* synthetic */ i00 f;
    public final /* synthetic */ mi0 g;
    public final /* synthetic */ boolean h;
    public final /* synthetic */ z91 i;

    public final Object f(Object obj, Object obj2) {
        d10 d10 = (d10) obj;
        ((Integer) obj2).getClass();
        ca1.a(this.e, this.f, this.g, this.h, this.i, d10, wc0.s(385));
        return we1.a;
    }

    public /* synthetic */ aa1(boolean z, i00 i00, mi0 mi0, boolean z2, z91 z91, int i) {
        this.e = z;
        this.f = i00;
        this.g = mi0;
        this.h = z2;
        this.i = z91;
    }
}