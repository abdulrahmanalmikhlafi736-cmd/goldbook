package defpackage;

import java.util.Set;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: sj */
public abstract class sj {
    public qr0 i() {
        return tj.a;
    }

    public void c() {
    }

    public void p(d10 d10) {
    }

    public void t() {
    }

    public void u(d10 d10) {
    }

    public abstract void a(yj yjVar, m00 m00);

    public abstract ik0 b(yj yjVar, l51 l51, m00 m00);

    public abstract boolean d();

    public abstract boolean e();

    public abstract boolean f();

    public abstract long g();

    public abstract rj h();

    public abstract sl j();

    public abstract boolean k();

    public abstract void l(yj yjVar);

    public abstract fj0 m(gj0 gj0);

    public abstract ik0 n(yj yjVar, l51 l51, ik0 ik0);

    public abstract void o(Set set);

    public abstract void q(xv0 xv0);

    public abstract void r(yj yjVar);

    public abstract oe s(f8 f8Var);

    public abstract void v(yj yjVar);
}