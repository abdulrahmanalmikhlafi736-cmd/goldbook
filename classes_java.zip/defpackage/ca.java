package defpackage;

import java.util.concurrent.atomic.AtomicInteger;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ca */
public final class ca extends AtomicInteger {
    public final byte byteValue() {
        return (byte) super.intValue();
    }

    public final short shortValue() {
        return (short) super.intValue();
    }
}