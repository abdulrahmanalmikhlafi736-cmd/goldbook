package defpackage;

import java.util.Map;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: oh0 */
public interface oh0 extends g70 {
    nh0 E(int i, int i2, Map map, i00 i00, i00 i002);

    nh0 O(int i, int i2, Map map, i00 i00);
}