package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: c11 */
public final class c11 implements r11 {
    public static final al j = new al(21, new h90(27), new h90(29));
    public final iq0 a;
    public final iq0 b = new h90(0);
    public final iq0 c = new h90(0);
    public final uj0 d = new uj0();
    public final iq0 e = new h90(Integer.MAX_VALUE);
    public float f;
    public final wo g = new wo(new l(20, (Object) this));
    public final sp h = mc0.j(new b11(this, 0));
    public final sp i = mc0.j(new b11(this, 1));

    public c11(int i) {
        this.a = new h90(i);
    }

    public final Object d(tk0 tk0, m00 m00, nl nlVar) {
        cm d = this.g.d(tk0, m00, nlVar);
        return d == cm.e ? d : we1.a;
    }

    public final boolean a() {
        return ((Boolean) this.i.getValue()).booleanValue();
    }

    public final boolean c() {
        return ((Boolean) this.h.getValue()).booleanValue();
    }

    public final boolean b() {
        return this.g.b();
    }

    public final float e(float f) {
        return this.g.e(f);
    }
}