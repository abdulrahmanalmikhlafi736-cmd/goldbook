package defpackage;

import android.view.autofill.AutofillManager;
import java.util.ArrayList;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: co0 */
public final class co0 extends xo0 {
    public static final co0 c = new xo0(0, 1, 1);

    public final void a(pg pgVar, m9 m9Var, a61 a61, uw0 uw0, yo0 yo0) {
        xv0 xv0 = (xv0) pgVar.c(0);
        hk0 hk0 = uw0.i;
        if (hk0 != null && ((mr0) ((AutofillManager) hk0)) != null) {
            ArrayList arrayList = uw0.j;
            if (arrayList != null) {
                qk0 qk0 = (qk0) arrayList.remove(arrayList.size() - 1);
                if (qk0 != null) {
                    uw0.e = qk0;
                }
            }
            hk0.k(xv0);
        }
    }
}