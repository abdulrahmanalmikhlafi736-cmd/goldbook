package defpackage;

import android.content.res.ColorStateList;
import android.graphics.Rect;
import android.graphics.drawable.RippleDrawable;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cf1 */
public final class cf1 extends RippleDrawable {
    public final boolean e;
    public zg f;
    public Integer g;
    public boolean h;

    public cf1(boolean z) {
        super(ColorStateList.valueOf(-16777216), null, z ? new h90(-1) : null);
        this.e = z;
    }

    public final Rect getDirtyBounds() {
        if (!this.e) {
            this.h = true;
        }
        Rect dirtyBounds = super.getDirtyBounds();
        this.h = false;
        return dirtyBounds;
    }

    public final boolean isProjected() {
        return this.h;
    }
}