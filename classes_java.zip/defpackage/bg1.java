package defpackage;

import java.util.List;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bg1 */
public final class bg1 extends zf1 {
    public final String e;
    public final List f;
    public final int g;
    public final zi1 h;
    public final float i;
    public final zi1 j;
    public final float k;
    public final float l;
    public final int m;
    public final int n;
    public final float o;
    public final float p;
    public final float q;
    public final float r;

    public final boolean equals(Object obj) {
        if (this != obj) {
            if (obj != null) {
                if (bg1.class == obj.getClass()) {
                    bg1 bg1 = (bg1) obj;
                    if (this.e.equals(bg1.e)) {
                        if (k70.p(this.h, bg1.h)) {
                            if (this.i == bg1.i) {
                                if (k70.p(this.j, bg1.j)) {
                                    if (this.k == bg1.k && this.l == bg1.l && this.m == bg1.m && this.n == bg1.n && this.o == bg1.o && this.p == bg1.p && this.q == bg1.q && this.r == bg1.r && this.g == bg1.g) {
                                        if (!k70.p(this.f, bg1.f)) {
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return false;
        }
        return true;
    }

    public final int hashCode() {
        int hashCode = (this.f.hashCode() + (this.e.hashCode() * 31)) * 31;
        int i = 0;
        zi1 zi1 = this.h;
        hashCode = fu0.z(this.i, (hashCode + (zi1 != null ? zi1.hashCode() : 0)) * 31, 31);
        zi1 = this.j;
        if (zi1 != null) {
            i = zi1.hashCode();
        }
        return fu0.z(this.r, fu0.z(this.q, fu0.z(this.p, fu0.z(this.o, (((fu0.z(this.l, fu0.z(this.k, (hashCode + i) * 31, 31), 31) + this.m) * 31) + this.n) * 31, 31), 31), 31), 31) + this.g;
    }

    public bg1(String str, List list, int i, zi1 zi1, float f, zi1 zi12, float f2, float f3, int i2, int i3, float f4, float f5, float f6, float f7) {
        this.e = str;
        this.f = list;
        this.g = i;
        this.h = zi1;
        this.i = f;
        this.j = zi12;
        this.k = f2;
        this.l = f3;
        this.m = i2;
        this.n = i3;
        this.o = f4;
        this.p = f5;
        this.q = f6;
        this.r = f7;
    }
}