package defpackage;

import android.view.autofill.AutofillManager$AutofillCallback;
import android.view.autofill.AutofillValue;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ca1 */
public abstract class ca1 {
    public static final float a;
    public static final float b = j70.E;
    public static final float c = j70.B;
    public static final float d;
    public static final float e;
    public static final f61 f = new Object();

    public static final void b(mi0 mi0, boolean z, boolean z2, z91 z91, uj0 uj0, y41 y41, d10 d10, int i) {
        int i2;
        mi0 mi02 = mi0;
        boolean z3 = z;
        boolean z4 = z2;
        z91 z912 = z91;
        uj0 uj02 = uj0;
        y41 y412 = y41;
        d10 d102 = d10;
        int i3 = i;
        d102.X(-670917213);
        if ((i3 & 6) == 0) {
            i2 = (((AutofillManager$AutofillCallback) d102) != null ? 4 : 2) | i3;
        } else {
            i2 = i3;
        }
        if ((i3 & 48) == 0) {
            i2 |= d102.g(z3) ? 32 : 16;
        }
        if ((i3 & 384) == 0) {
            i2 |= d102.g(z4) ? 256 : 128;
        }
        if ((i3 & 3072) == 0) {
            i2 |= ((AutofillManager$AutofillCallback) d102) != null ? 2048 : 1024;
        }
        if ((i3 & 24576) == 0) {
            i2 |= ((AutofillValue) d102) != null ? 16384 : 8192;
        }
        if ((196608 & i3) == 0) {
            i2 |= ((AutofillManager$AutofillCallback) d102) != null ? 131072 : 65536;
        }
        if ((1572864 & i3) == 0) {
            i2 |= ((AutofillManager$AutofillCallback) d102) != null ? 1048576 : 524288;
        }
        if (d102.O(i2 & 1, (599187 & i2) != 599186)) {
            Object obj;
            long j;
            Object obj2;
            long j2;
            if (!z4) {
                obj = 32;
                j = z3 ? z912.j : z912.n;
            } else if (z3) {
                obj = 32;
                j = z912.b;
            } else {
                obj = 32;
                j = z912.f;
            }
            if (z4) {
                obj2 = obj;
                j2 = z3 ? z912.a : z912.e;
            } else {
                obj2 = obj;
                j2 = z3 ? z912.i : z912.m;
            }
            y41 a = d51.a(j70.A, d102);
            Object obj3 = obj2;
            float f = j70.z;
            long j3 = z4 ? z3 ? z912.c : z912.g : z3 ? z912.k : z912.o;
            mi0 n = wl1.n(mi02.b(new yb(f, new ad(j3), a)), j, a);
            mh0 d = ic.d(e3.f, false);
            j = d102.T;
            int i4 = (int) (j ^ (j >>> obj3));
            qr0 l = d102.l();
            n = vn.I(d102, n);
            ij.c.getClass();
            dk dkVar = hj.b;
            d102.Z();
            if (d102.S) {
                d102.k(dkVar);
            } else {
                d102.j0();
            }
            s7 s7Var = hj.f;
            mc0.B(s7Var, d102, d);
            s7 s7Var2 = hj.e;
            mc0.B(s7Var2, d102, l);
            Integer valueOf = Integer.valueOf(i4);
            s7 s7Var3 = hj.g;
            mc0.p(d102, valueOf, s7Var3);
            i4 i4Var = hj.h;
            mc0.w(d102, i4Var);
            s7 s7Var4 = hj.d;
            mc0.B(s7Var4, d102, n);
            mi02 = wl1.n(p40.a(fu0.l((qi0) e3.x.j(e3.i), new ec1(uj02, z3, mc0.H(zi0.f, d102))), uj02, fy0.a(j70.x / 2.0f, 4)), j2, y412);
            mh0 d2 = ic.d(e3.j, false);
            j2 = d102.T;
            int i5 = (int) (j2 ^ (j2 >>> obj3));
            qr0 l2 = d102.l();
            mi02 = vn.I(d102, mi02);
            d102.Z();
            if (d102.S) {
                d102.k(dkVar);
            } else {
                d102.j0();
            }
            mc0.B(s7Var, d102, d2);
            mc0.B(s7Var2, d102, l2);
            mc0.p(d102, Integer.valueOf(i5), s7Var3);
            mc0.w(d102, i4Var);
            mc0.B(s7Var4, d102, mi02);
            d102.W(1236071411);
            d102.p(false);
            d102.p(true);
            d102.p(true);
        } else {
            d102.R();
        }
        xv0 r = d102.r();
        if (r != null) {
            r.d = new ba1(mi0, z, z2, z912, uj02, y412, i3);
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:28:0x0125  */
    /* JADX WARNING: Removed duplicated region for block: B:33:0x014b  */
    /* JADX WARNING: Removed duplicated region for block: B:31:0x0135  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final void a(boolean z, i00 i00, mi0 mi0, boolean z2, z91 z91, d10 d10, int i) {
        mi0 mi02;
        boolean z3;
        z91 z912;
        i00 i002 = i00;
        d10 d102 = d10;
        d102.X(-263339167);
        boolean z4 = z;
        int i2 = ((i | (d102.g(z4) ? 4 : 2)) | (((AutofillValue) d102) != null ? 32 : 16)) | 1666048;
        if (d102.O(i2 & 1, (599187 & i2) != 599186)) {
            boolean z5;
            z91 z913;
            int i3;
            Object L;
            uj0 uj0;
            mi0 I;
            boolean z6;
            float f;
            float f2;
            z91 z914;
            int i4;
            d102.T();
            if ((i & 1) != 0) {
                if (!d102.y()) {
                    d102.R();
                    i2 &= -458753;
                    z5 = z2;
                    z913 = z91;
                    i3 = i2;
                    d102.q();
                    d102.W(1768510810);
                    L = d102.L();
                    if (L == oj.a) {
                        L = new uj0();
                        d102.g0(L);
                    }
                    uj0 = (uj0) L;
                    d102.p(false);
                    if (i002 == null) {
                        h30 h30 = b70.a;
                        uj0 uj02 = uj0;
                        I = vd1.I(fi0.a, z4, uj02, z5, new h90(2), i00);
                        uj0 = uj02;
                        z6 = z5;
                    } else {
                        z6 = z5;
                        I = ji0.a;
                    }
                    mi02 = mi0;
                    I = u51.g(mi02.b(I));
                    f = c;
                    f2 = d;
                    z914 = z913;
                    ca1.b(I.b(new t51(f, f2, f, f2, false)), z, z6, z914, uj0, d51.a(j70.r, d102), d102, ((i3 << 3) & 112) | 24960);
                    z3 = z6;
                    z912 = z914;
                }
            }
            dh dhVar = ((dh0) d102.j(fh0.a)).a;
            z913 = dhVar.Z;
            long j = dhVar.p;
            if (z913 == null) {
                long c = fh.c(dhVar, j70.t);
                long c2 = fh.c(dhVar, j70.w);
                long j2 = zg.h;
                long c3 = fh.c(dhVar, j70.v);
                long c4 = fh.c(dhVar, j70.D);
                long c5 = fh.c(dhVar, j70.G);
                long c6 = fh.c(dhVar, j70.C);
                long c7 = fh.c(dhVar, j70.F);
                i4 = -458753;
                long q = wl1.q(zg.b(fh.c(dhVar, j70.f), j70.g), j);
                long c8 = fh.c(dhVar, j70.j);
                float f3 = j70.k;
                z91 z915 = new z91(c, c2, j2, c3, c4, c5, c6, c7, q, wl1.q(zg.b(c8, f3), j), j2, wl1.q(zg.b(fh.c(dhVar, j70.h), j70.i), j), wl1.q(zg.b(fh.c(dhVar, j70.l), j70.m), j), wl1.q(zg.b(fh.c(dhVar, j70.p), f3), j), wl1.q(zg.b(fh.c(dhVar, j70.q), f3), j), wl1.q(zg.b(fh.c(dhVar, j70.n), j70.o), j));
                dhVar.Z = z915;
                z913 = z915;
            } else {
                i4 = -458753;
            }
            i2 &= i4;
            z5 = true;
            i3 = i2;
            d102.q();
            d102.W(1768510810);
            L = d102.L();
            if (L == oj.a) {
            }
            uj0 = (uj0) L;
            d102.p(false);
            if (i002 == null) {
            }
            mi02 = mi0;
            I = u51.g(mi02.b(I));
            f = c;
            f2 = d;
            z914 = z913;
            ca1.b(I.b(new t51(f, f2, f, f2, false)), z, z6, z914, uj0, d51.a(j70.r, d102), d102, ((i3 << 3) & 112) | 24960);
            z3 = z6;
            z912 = z914;
        } else {
            mi02 = mi0;
            d10.R();
            z3 = z2;
            z912 = z91;
        }
        xv0 r = d10.r();
        if (r != null) {
            r.d = new aa1(z, i00, mi02, z3, z912, i);
        }
    }

    static {
        float f = j70.u;
        a = f;
        float f2 = j70.y;
        d = f2;
        e = (f2 - f) / 2.0f;
    }
}