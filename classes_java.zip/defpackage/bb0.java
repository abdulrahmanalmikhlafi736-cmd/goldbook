package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bb0 */
public final class bb0 extends li0 implements t90 {
    public static final za0 v = new Object();
    public ec0 s;
    public sc t;
    public bp0 u;

    /* JADX WARNING: Removed duplicated region for block: B:25:0x003a  */
    /* JADX WARNING: Removed duplicated region for block: B:22:0x002a  */
    /* JADX WARNING: Removed duplicated region for block: B:22:0x002a  */
    /* JADX WARNING: Removed duplicated region for block: B:25:0x003a  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean r0(xa0 xa0, int i) {
        if (i != 5) {
            if (i != 6) {
                if (i != 3) {
                    if (i != 4) {
                        if (i != 1) {
                            if (i != 2) {
                                od.p("Lazy list does not support beyond bounds layout for the specified direction");
                                return false;
                            }
                        }
                        if (!s0(i)) {
                            return xa0.a > 0;
                        } else {
                            if (xa0.b < this.s.a.g().n - 1) {
                            }
                        }
                    }
                }
                if (this.u == bp0.e) {
                }
                if (!s0(i)) {
                }
            }
        }
        if (this.u == bp0.f) {
        }
        if (!s0(i)) {
        }
    }

    public final boolean s0(int i) {
        if (i == 1) {
            return false;
        }
        if (i == 2) {
            return true;
        }
        if (i == 5) {
            return false;
        }
        if (i == 6) {
            return true;
        }
        int ordinal;
        if (i == 3) {
            ordinal = k70.O(this).D.ordinal();
            if (ordinal == 0) {
                return false;
            }
            if (ordinal == 1) {
                return true;
            }
            od.k();
        } else if (i == 4) {
            ordinal = k70.O(this).D.ordinal();
            if (ordinal == 0) {
                return true;
            }
            if (ordinal == 1) {
                return false;
            }
            od.k();
        } else {
            od.p("Lazy list does not support beyond bounds layout for the specified direction");
        }
        return false;
    }

    public final nh0 U(oh0 oh0, hh0 hh0, long j) {
        ks0 e = hh0.e(j);
        return oh0.O(e.e, e.f, vt.e, new a4(e, 1));
    }

    public final /* synthetic */ int G(bg0 bg0, hh0 hh0, int i) {
        return fu0.i(this, bg0, hh0, i);
    }

    public final /* synthetic */ int d(bg0 bg0, hh0 hh0, int i) {
        return fu0.d(this, bg0, hh0, i);
    }

    public final /* synthetic */ int h(bg0 bg0, hh0 hh0, int i) {
        return fu0.b(this, bg0, hh0, i);
    }

    public final /* synthetic */ int t(bg0 bg0, hh0 hh0, int i) {
        return fu0.g(this, bg0, hh0, i);
    }
}