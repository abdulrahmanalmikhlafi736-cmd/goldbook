package defpackage;

import java.util.List;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: mh0 */
public interface mh0 {
    int a(g70 g70, List list, int i);

    int c(g70 g70, List list, int i);

    nh0 f(oh0 oh0, List list, long j);

    int g(g70 g70, List list, int i);

    int i(g70 g70, List list, int i);
}