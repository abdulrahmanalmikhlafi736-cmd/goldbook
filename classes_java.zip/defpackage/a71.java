package defpackage;

import android.view.autofill.AutofillManager;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: a71 */
public final class a71 {
    public final i00 a;
    public Object b;
    public zj0 c;
    public int d = -1;
    public final hk0 e = mc0.h();
    public final hk0 f = new hk0();
    public final ik0 g = new ik0();
    public final qk0 h = new qk0(new sp[16]);
    public final c10 i = new c10(1, this);
    public boolean j;
    public int k;
    public final hk0 l = mc0.h();
    public final HashMap m = new HashMap();

    /* JADX WARNING: Removed duplicated region for block: B:327:0x01a0 A:{SYNTHETIC, EDGE_INSN: B:327:0x01a0->B:74:0x01a0 ?: BREAK  } */
    /* JADX WARNING: Removed duplicated region for block: B:77:0x01af A:{LOOP_END, Catch:{ all -> 0x0128 }, LOOP:2: B:30:0x0097->B:77:0x01af} */
    /* JADX WARNING: Removed duplicated region for block: B:347:0x047f A:{SYNTHETIC, EDGE_INSN: B:347:0x047f->B:214:0x047f ?: BREAK  } */
    /* JADX WARNING: Removed duplicated region for block: B:217:0x048b A:{LOOP_END, Catch:{ all -> 0x041a }, LOOP:11: B:166:0x0384->B:217:0x048b} */
    /* JADX WARNING: Removed duplicated region for block: B:259:0x053c  */
    /* JADX WARNING: Removed duplicated region for block: B:259:0x053c  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean a(Set set) {
        long j;
        boolean z;
        long j2;
        Object[] objArr;
        int length;
        int i;
        int i2;
        int i3;
        int i4;
        int i5;
        int i6;
        Object obj;
        Set set2 = set;
        nq0 nq0 = nq0.j;
        boolean z2 = set2 instanceof p01;
        qk0 qk0 = this.h;
        ac acVar = this.l;
        HashMap hashMap = this.m;
        hk0 hk0 = this.e;
        ik0 ik0 = this.g;
        ik0 ik02;
        long[] jArr;
        int length2;
        int i7;
        long j3;
        int i8;
        long[] jArr2;
        nq0 nq02;
        ac acVar2;
        HashMap hashMap2;
        AutofillManager g;
        long j4;
        AutofillManager g2;
        ik0 ik03;
        Object[] objArr2;
        long[] jArr3;
        int length3;
        int i9;
        sp spVar;
        a71 a71;
        long j5;
        if (z2) {
            ik02 = ((p01) set2).e;
            Object[] objArr3 = ik02.b;
            jArr = ik02.a;
            j = 7;
            length2 = jArr.length - 2;
            if (length2 >= 0) {
                i7 = 0;
                z = false;
                j2 = -9187201950435737472L;
                while (true) {
                    Object[] objArr4;
                    long j6 = 8;
                    j3 = jArr[i7];
                    int i10 = i7;
                    if (((((~j3) << 7) & j3) & -9187201950435737472L) != -9187201950435737472L) {
                        int i11;
                        i8 = 8 - ((~(i10 - length2)) >>> 31);
                        i7 = 0;
                        while (i7 < i8) {
                            int i12;
                            int i13;
                            long j7;
                            if ((j3 & 255) < 128) {
                                long j8;
                                Object obj2 = objArr3[(i10 << 3) + i7];
                                jArr2 = jArr;
                                if (obj2 instanceof i81) {
                                    nq02 = nq0;
                                    if (!((i81) obj2).e(2)) {
                                        objArr4 = objArr3;
                                        acVar2 = acVar;
                                        hashMap2 = hashMap;
                                        i11 = length2;
                                        i12 = i8;
                                        i13 = i7;
                                        j7 = j3;
                                    }
                                } else {
                                    nq02 = nq0;
                                }
                                if (this.j || acVar.c(obj2) == null) {
                                    objArr4 = objArr3;
                                    acVar2 = acVar;
                                    hashMap2 = hashMap;
                                    i11 = length2;
                                    i12 = i8;
                                    i13 = i7;
                                    j7 = j3;
                                } else {
                                    this.j = true;
                                    try {
                                        g = ((AutofillManager) acVar);
                                        if (g == null) {
                                            objArr4 = objArr3;
                                            acVar2 = acVar;
                                            hashMap2 = hashMap;
                                            i11 = length2;
                                            i12 = i8;
                                            i13 = i7;
                                            j7 = j3;
                                        } else if (g instanceof ik0) {
                                            HashMap hashMap3;
                                            ik02 = (ik0) g;
                                            objArr = ik02.b;
                                            jArr = ik02.a;
                                            Object[] objArr5 = objArr;
                                            length = jArr.length - 2;
                                            if (length >= 0) {
                                                long[] jArr4 = jArr;
                                                i13 = i7;
                                                boolean z3 = z;
                                                i = 0;
                                                while (true) {
                                                    j4 = jArr4[i];
                                                    j7 = j3;
                                                    if (((((~j4) << 7) & j4) & -9187201950435737472L) != -9187201950435737472L) {
                                                        i2 = 8 - ((~(i - length)) >>> 31);
                                                        i3 = 0;
                                                        while (i3 < i2) {
                                                            long j9;
                                                            int i14;
                                                            if ((j4 & 255) < 128) {
                                                                objArr4 = objArr3;
                                                                sp spVar2 = (sp) objArr5[(i << 3) + i3];
                                                                spVar2.getClass();
                                                                j9 = j4;
                                                                Object obj3 = hashMap.get(spVar2);
                                                                a71 a712 = spVar2.g;
                                                                if (a712 == null) {
                                                                    a712 = nq02;
                                                                }
                                                                i14 = i3;
                                                                if (a712.c(spVar2.h().f, obj3) == null) {
                                                                    g2 = ((AutofillManager) hk0);
                                                                    if (g2 != null) {
                                                                        if (g2 instanceof ik0) {
                                                                            ik03 = (ik0) g2;
                                                                            objArr2 = ik03.b;
                                                                            jArr3 = ik03.a;
                                                                            length3 = jArr3.length - 2;
                                                                            if (length3 >= 0) {
                                                                                i11 = length2;
                                                                                i12 = i8;
                                                                                i3 = 0;
                                                                                while (true) {
                                                                                    long[] jArr5;
                                                                                    j8 = jArr3[i3];
                                                                                    acVar2 = acVar;
                                                                                    hashMap3 = hashMap;
                                                                                    if (((((~j8) << 7) & j8) & -9187201950435737472L) != -9187201950435737472L) {
                                                                                        i4 = 8 - ((~(i3 - length3)) >>> 31);
                                                                                        i9 = 0;
                                                                                        while (i9 < i4) {
                                                                                            if ((j8 & 255) < 128) {
                                                                                                jArr5 = jArr3;
                                                                                                ik0.a(objArr2[(i3 << 3) + i9]);
                                                                                                z3 = true;
                                                                                            } else {
                                                                                                jArr5 = jArr3;
                                                                                            }
                                                                                            j8 >>= j6;
                                                                                            i9++;
                                                                                            jArr3 = jArr5;
                                                                                        }
                                                                                        jArr5 = jArr3;
                                                                                        if (i4 != j6) {
                                                                                            break;
                                                                                        }
                                                                                    } else {
                                                                                        jArr5 = jArr3;
                                                                                    }
                                                                                    if (i3 == length3) {
                                                                                        break;
                                                                                    }
                                                                                    i3++;
                                                                                    acVar = acVar2;
                                                                                    hashMap = hashMap3;
                                                                                    jArr3 = jArr5;
                                                                                    j6 = 8;
                                                                                }
                                                                            }
                                                                        } else {
                                                                            acVar2 = acVar;
                                                                            hashMap3 = hashMap;
                                                                            i11 = length2;
                                                                            i12 = i8;
                                                                            ik0.a(g2);
                                                                            z3 = true;
                                                                        }
                                                                    }
                                                                    acVar2 = acVar;
                                                                    hashMap3 = hashMap;
                                                                    i11 = length2;
                                                                    i12 = i8;
                                                                } else {
                                                                    acVar2 = acVar;
                                                                    hashMap3 = hashMap;
                                                                    i11 = length2;
                                                                    i12 = i8;
                                                                    qk0.b(spVar2);
                                                                }
                                                            } else {
                                                                objArr4 = objArr3;
                                                                acVar2 = acVar;
                                                                hashMap3 = hashMap;
                                                                i11 = length2;
                                                                i12 = i8;
                                                                j9 = j4;
                                                                i14 = i3;
                                                            }
                                                            j4 = j9 >> 8;
                                                            i3 = i14 + 1;
                                                            j6 = 8;
                                                            objArr3 = objArr4;
                                                            length2 = i11;
                                                            i8 = i12;
                                                            acVar = acVar2;
                                                            hashMap = hashMap3;
                                                        }
                                                        objArr4 = objArr3;
                                                        acVar2 = acVar;
                                                        hashMap3 = hashMap;
                                                        i11 = length2;
                                                        i12 = i8;
                                                        if (i2 == j6) {
                                                            if (i != length) {
                                                                break;
                                                            }
                                                            i++;
                                                            j3 = j7;
                                                            objArr3 = objArr4;
                                                            length2 = i11;
                                                            i8 = i12;
                                                            acVar = acVar2;
                                                            hashMap = hashMap3;
                                                            j6 = 8;
                                                        } else {
                                                            break;
                                                        }
                                                    }
                                                    objArr4 = objArr3;
                                                    acVar2 = acVar;
                                                    hashMap3 = hashMap;
                                                    i11 = length2;
                                                    i12 = i8;
                                                    if (i != length) {
                                                    }
                                                }
                                                z = z3;
                                            } else {
                                                objArr4 = objArr3;
                                                acVar2 = acVar;
                                                hashMap3 = hashMap;
                                                i11 = length2;
                                                i12 = i8;
                                                i13 = i7;
                                                j7 = j3;
                                            }
                                            hashMap2 = hashMap3;
                                        } else {
                                            objArr4 = objArr3;
                                            acVar2 = acVar;
                                            i11 = length2;
                                            i12 = i8;
                                            i13 = i7;
                                            j7 = j3;
                                            spVar = (sp) g;
                                            hashMap2 = hashMap;
                                            Object obj4 = hashMap2.get(spVar);
                                            a71 = spVar.g;
                                            if (a71 == null) {
                                                a71 = nq02;
                                            }
                                            if (a71.c(spVar.h().f, obj4) == null) {
                                                g = ((AutofillManager) hk0);
                                                if (g != null) {
                                                    if (g instanceof ik0) {
                                                        ik02 = (ik0) g;
                                                        objArr3 = ik02.b;
                                                        jArr = ik02.a;
                                                        i4 = jArr.length - 2;
                                                        if (i4 >= 0) {
                                                            i9 = 0;
                                                            while (true) {
                                                                j8 = jArr[i9];
                                                                if (((((~j8) << 7) & j8) & -9187201950435737472L) != -9187201950435737472L) {
                                                                    i2 = 8 - ((~(i9 - i4)) >>> 31);
                                                                    for (i7 = 0; i7 < i2; i7++) {
                                                                        if ((j8 & 255) < 128) {
                                                                            ik0.a(objArr3[(i9 << 3) + i7]);
                                                                            z = true;
                                                                        }
                                                                        j8 >>= 8;
                                                                    }
                                                                    if (i2 != 8) {
                                                                        break;
                                                                    }
                                                                }
                                                                if (i9 == i4) {
                                                                    break;
                                                                }
                                                                i9++;
                                                            }
                                                        }
                                                    } else {
                                                        ik0.a(g);
                                                        z = true;
                                                    }
                                                }
                                            } else {
                                                qk0.b(spVar);
                                            }
                                        }
                                        this.j = false;
                                    } catch (Throwable th) {
                                        this.j = false;
                                        throw th;
                                    }
                                }
                                g = ((AutofillManager) hk0);
                                if (g != null) {
                                    if (g instanceof ik0) {
                                        ik02 = (ik0) g;
                                        objArr3 = ik02.b;
                                        jArr = ik02.a;
                                        i4 = jArr.length - 2;
                                        if (i4 >= 0) {
                                            i9 = 0;
                                            while (true) {
                                                j8 = jArr[i9];
                                                if (((((~j8) << 7) & j8) & -9187201950435737472L) != -9187201950435737472L) {
                                                    i2 = 8 - ((~(i9 - i4)) >>> 31);
                                                    j5 = j8;
                                                    for (length2 = 0; length2 < i2; length2++) {
                                                        if ((j5 & 255) < 128) {
                                                            ik0.a(objArr3[(i9 << 3) + length2]);
                                                            z = true;
                                                        }
                                                        j5 >>= 8;
                                                    }
                                                    if (i2 != 8) {
                                                        break;
                                                    }
                                                }
                                                if (i9 == i4) {
                                                    break;
                                                }
                                                i9++;
                                            }
                                        }
                                    } else {
                                        ik0.a(g);
                                        z = true;
                                    }
                                }
                            } else {
                                jArr2 = jArr;
                                nq02 = nq0;
                                objArr4 = objArr3;
                                acVar2 = acVar;
                                hashMap2 = hashMap;
                                i11 = length2;
                                i12 = i8;
                                i13 = i7;
                                j7 = j3;
                            }
                            i7 = i13 + 1;
                            j6 = 8;
                            jArr = jArr2;
                            objArr3 = objArr4;
                            length2 = i11;
                            i8 = i12;
                            j3 = j7 >> 8;
                            acVar = acVar2;
                            hashMap = hashMap2;
                            nq0 = nq02;
                        }
                        jArr2 = jArr;
                        nq02 = nq0;
                        objArr4 = objArr3;
                        acVar2 = acVar;
                        hashMap2 = hashMap;
                        i11 = length2;
                        if (i8 != j6) {
                            break;
                        }
                        length2 = i11;
                    } else {
                        jArr2 = jArr;
                        nq02 = nq0;
                        objArr4 = objArr3;
                        acVar2 = acVar;
                        hashMap2 = hashMap;
                    }
                    int i15 = i10;
                    if (i15 == length2) {
                        break;
                    }
                    i7 = i15 + 1;
                    hashMap = hashMap2;
                    jArr = jArr2;
                    nq0 = nq02;
                    objArr3 = objArr4;
                    acVar = acVar2;
                }
            } else {
                j2 = -9187201950435737472L;
                z = false;
            }
        } else {
            nq02 = nq0;
            acVar2 = acVar;
            hashMap2 = hashMap;
            j = 7;
            j2 = -9187201950435737472L;
            Iterator it = set2.iterator();
            z2 = false;
            while (it.hasNext()) {
                Iterator it2;
                Object next = it.next();
                if (!(next instanceof i81) || ((i81) next).e(2)) {
                    Object obj5;
                    boolean z4;
                    boolean z5;
                    if (!this.j) {
                        ac acVar3 = acVar2;
                        if (acVar3.c(next) != null) {
                            this.j = true;
                            try {
                                AutofillManager g3 = ((AutofillManager) acVar3);
                                if (g3 != null) {
                                    long j10;
                                    Object[] objArr6;
                                    if (g3 instanceof ik0) {
                                        ik0 ik04 = (ik0) g3;
                                        objArr2 = ik04.b;
                                        long[] jArr6 = ik04.a;
                                        length3 = jArr6.length - 2;
                                        if (length3 >= 0) {
                                            boolean z6 = z2;
                                            i5 = 0;
                                            while (true) {
                                                j10 = jArr6[i5];
                                                jArr2 = jArr6;
                                                Object[] objArr7;
                                                if (((((~j10) << 7) & j10) & -9187201950435737472L) != -9187201950435737472L) {
                                                    length2 = 8 - ((~(i5 - length3)) >>> 31);
                                                    i8 = 0;
                                                    while (i8 < length2) {
                                                        long j11;
                                                        if ((j10 & 255) < 128) {
                                                            it2 = it;
                                                            spVar = (sp) objArr2[(i5 << 3) + i8];
                                                            spVar.getClass();
                                                            acVar2 = acVar3;
                                                            Object obj6 = hashMap2.get(spVar);
                                                            i6 = i8;
                                                            a71 a713 = spVar.g;
                                                            if (a713 == null) {
                                                                a713 = nq02;
                                                            }
                                                            objArr7 = objArr2;
                                                            if (a713.c(spVar.h().f, obj6) == null) {
                                                                g = ((AutofillManager) hk0);
                                                                if (g != null) {
                                                                    if (g instanceof ik0) {
                                                                        ik02 = (ik0) g;
                                                                        objArr6 = ik02.b;
                                                                        jArr = ik02.a;
                                                                        i8 = jArr.length - 2;
                                                                        if (i8 >= 0) {
                                                                            j11 = j10;
                                                                            i7 = 0;
                                                                            boolean z7 = z6;
                                                                            while (true) {
                                                                                long[] jArr7;
                                                                                j3 = jArr[i7];
                                                                                obj5 = next;
                                                                                Object[] objArr8 = objArr6;
                                                                                if (((((~j3) << 7) & j3) & -9187201950435737472L) != -9187201950435737472L) {
                                                                                    i4 = 8 - ((~(i7 - i8)) >>> 31);
                                                                                    i9 = 0;
                                                                                    while (i9 < i4) {
                                                                                        if ((j3 & 255) < 128) {
                                                                                            ik0.a(objArr8[(i7 << 3) + i9]);
                                                                                            z7 = true;
                                                                                        }
                                                                                        j3 >>= 8;
                                                                                        i9++;
                                                                                        jArr = jArr;
                                                                                    }
                                                                                    jArr7 = jArr;
                                                                                    if (i4 != 8) {
                                                                                        z4 = z7;
                                                                                        break;
                                                                                    }
                                                                                } else {
                                                                                    jArr7 = jArr;
                                                                                }
                                                                                if (i7 == i8) {
                                                                                    z6 = z7;
                                                                                    break;
                                                                                }
                                                                                i7++;
                                                                                next = obj5;
                                                                                objArr6 = objArr8;
                                                                                jArr = jArr7;
                                                                            }
                                                                            z4 = z6;
                                                                        }
                                                                    } else {
                                                                        obj5 = next;
                                                                        j11 = j10;
                                                                        ik0.a(g);
                                                                        z4 = true;
                                                                    }
                                                                    z6 = z4;
                                                                }
                                                                obj5 = next;
                                                                j11 = j10;
                                                                z4 = z6;
                                                                z6 = z4;
                                                            } else {
                                                                obj5 = next;
                                                                j11 = j10;
                                                                qk0.b(spVar);
                                                            }
                                                        } else {
                                                            it2 = it;
                                                            obj5 = next;
                                                            acVar2 = acVar3;
                                                            i6 = i8;
                                                            objArr7 = objArr2;
                                                            j11 = j10;
                                                        }
                                                        i8 = i6 + 1;
                                                        it = it2;
                                                        j10 = j11 >> 8;
                                                        objArr2 = objArr7;
                                                        next = obj5;
                                                        acVar3 = acVar2;
                                                    }
                                                    it2 = it;
                                                    obj5 = next;
                                                    acVar2 = acVar3;
                                                    objArr7 = objArr2;
                                                    if (length2 == 8) {
                                                        if (i5 != length3) {
                                                            break;
                                                        }
                                                        i5++;
                                                        it = it2;
                                                        jArr6 = jArr2;
                                                        objArr2 = objArr7;
                                                        next = obj5;
                                                        acVar3 = acVar2;
                                                    } else {
                                                        break;
                                                    }
                                                }
                                                it2 = it;
                                                obj5 = next;
                                                acVar2 = acVar3;
                                                objArr7 = objArr2;
                                                if (i5 != length3) {
                                                }
                                            }
                                            z2 = z6;
                                        }
                                    } else {
                                        it2 = it;
                                        obj5 = next;
                                        acVar2 = acVar3;
                                        sp spVar3 = (sp) g3;
                                        obj = hashMap2.get(spVar3);
                                        a71 = spVar3.g;
                                        if (a71 == null) {
                                            a71 = nq02;
                                        }
                                        if (a71.c(spVar3.h().f, obj) == null) {
                                            g = ((AutofillManager) hk0);
                                            if (g != null) {
                                                if (g instanceof ik0) {
                                                    ik02 = (ik0) g;
                                                    Object[] objArr9 = ik02.b;
                                                    jArr = ik02.a;
                                                    i9 = jArr.length - 2;
                                                    if (i9 >= 0) {
                                                        boolean z8 = z2;
                                                        i5 = 0;
                                                        while (true) {
                                                            j5 = jArr[i5];
                                                            if (((((~j5) << 7) & j5) & -9187201950435737472L) != -9187201950435737472L) {
                                                                i2 = 8 - ((~(i5 - i9)) >>> 31);
                                                                j4 = j5;
                                                                for (i8 = 0; i8 < i2; i8++) {
                                                                    if ((j4 & 255) < 128) {
                                                                        ik0.a(objArr9[(i5 << 3) + i8]);
                                                                        z8 = true;
                                                                    }
                                                                    j4 >>= 8;
                                                                }
                                                                if (i2 != 8) {
                                                                    z4 = z8;
                                                                    break;
                                                                }
                                                            }
                                                            if (i5 == i9) {
                                                                z2 = z8;
                                                                break;
                                                            }
                                                            i5++;
                                                        }
                                                    }
                                                } else {
                                                    ik0.a(g);
                                                    z4 = true;
                                                }
                                                z2 = z4;
                                            }
                                            z4 = z2;
                                            z2 = z4;
                                        } else {
                                            qk0.b(spVar3);
                                        }
                                    }
                                    z5 = false;
                                    this.j = false;
                                    z4 = z2;
                                    g2 = ((AutofillManager) hk0);
                                    if (g2 != null) {
                                        if (g2 instanceof ik0) {
                                            ik03 = (ik0) g2;
                                            objArr6 = ik03.b;
                                            jArr3 = ik03.a;
                                            length2 = jArr3.length - 2;
                                            if (length2 >= 0) {
                                                i8 = z5;
                                                while (true) {
                                                    j4 = jArr3[i8];
                                                    if (((((~j4) << 7) & j4) & -9187201950435737472L) != -9187201950435737472L) {
                                                        i2 = 8 - ((~(i8 - length2)) >>> 31);
                                                        j10 = j4;
                                                        for (i7 = z5; i7 < i2; i7++) {
                                                            if ((j10 & 255) < 128) {
                                                                ik0.a(objArr6[(i8 << 3) + i7]);
                                                                z4 = true;
                                                            }
                                                            j10 >>= 8;
                                                        }
                                                        if (i2 != 8) {
                                                            break;
                                                        }
                                                    }
                                                    if (i8 == length2) {
                                                        break;
                                                    }
                                                    i8++;
                                                }
                                            }
                                        } else {
                                            ik0.a(g2);
                                            z4 = true;
                                        }
                                    }
                                    z2 = z4;
                                }
                                it2 = it;
                                obj5 = next;
                                acVar2 = acVar3;
                                z5 = false;
                                this.j = false;
                                z4 = z2;
                                g2 = ((AutofillManager) hk0);
                                if (g2 != null) {
                                }
                                z2 = z4;
                            } catch (Throwable th2) {
                                this.j = false;
                                throw th2;
                            }
                        }
                        acVar2 = acVar3;
                    }
                    it2 = it;
                    obj5 = next;
                    z5 = false;
                    z4 = z2;
                    g2 = ((AutofillManager) hk0);
                    if (g2 != null) {
                    }
                    z2 = z4;
                } else {
                    it2 = it;
                }
                it = it2;
            }
            z = z2;
        }
        i4 = 0;
        if (!this.j) {
            i = qk0.g;
            if (i != 0) {
                objArr = qk0.e;
                i5 = 0;
                while (i5 < i) {
                    Object[] objArr10;
                    int i16;
                    int i17;
                    qk0 qk02;
                    sp spVar4 = (sp) objArr[i5];
                    long g4 = n61.j().g();
                    int i18 = (int) (g4 ^ (g4 >>> 32));
                    AutofillManager g5 = ((AutofillManager) hk0);
                    if (g5 != null) {
                        boolean z9 = g5 instanceof ik0;
                        hk0 hk02 = this.f;
                        sp spVar5;
                        if (z9) {
                            ik0 ik05 = (ik0) g5;
                            Object[] objArr11 = ik05.b;
                            long[] jArr8 = ik05.a;
                            i2 = jArr8.length - 2;
                            if (i2 >= 0) {
                                i3 = i4;
                                sp spVar6 = spVar4;
                                while (true) {
                                    long j12 = jArr8[i3];
                                    objArr10 = objArr;
                                    i16 = i5;
                                    if (((((~j12) << j) & j12) & j2) != j2) {
                                        length = 8 - ((~(i3 - i2)) >>> 31);
                                        i5 = 0;
                                        while (i5 < length) {
                                            if ((j12 & 255) < 128) {
                                                zj0 zj0;
                                                i17 = i;
                                                obj = objArr11[(i3 << 3) + i5];
                                                zj0 zj02 = (zj0) ((AutofillManager) hk02);
                                                i6 = i5;
                                                if (zj02 == null) {
                                                    zj0 = new zj0();
                                                    hk02.m(obj, zj0);
                                                } else {
                                                    zj0 = zj02;
                                                }
                                                qk02 = qk0;
                                                spVar5 = spVar6;
                                                b(spVar5, i18, obj, zj0);
                                            } else {
                                                i17 = i;
                                                i6 = i5;
                                                qk02 = qk0;
                                                spVar5 = spVar6;
                                            }
                                            j12 >>= 8;
                                            i5 = i6 + 1;
                                            spVar6 = spVar5;
                                            qk0 = qk02;
                                            i = i17;
                                        }
                                        i17 = i;
                                        qk02 = qk0;
                                        spVar5 = spVar6;
                                        if (length != 8) {
                                            break;
                                        }
                                    } else {
                                        i17 = i;
                                        qk02 = qk0;
                                        spVar5 = spVar6;
                                    }
                                    if (i3 == i2) {
                                        break;
                                    }
                                    i3++;
                                    spVar6 = spVar5;
                                    objArr = objArr10;
                                    i5 = i16;
                                    qk0 = qk02;
                                    i = i17;
                                }
                            } else {
                                i17 = i;
                                objArr10 = objArr;
                                i16 = i5;
                                qk02 = qk0;
                            }
                        } else {
                            i17 = i;
                            objArr10 = objArr;
                            i16 = i5;
                            qk02 = qk0;
                            spVar5 = spVar4;
                            zj0 zj03 = (zj0) ((AutofillManager) hk02);
                            if (zj03 == null) {
                                zj03 = new zj0();
                                hk02.m(g5, zj03);
                            }
                            b(spVar5, i18, g5, zj03);
                        }
                    } else {
                        i17 = i;
                        objArr10 = objArr;
                        i16 = i5;
                        qk02 = qk0;
                    }
                    i5 = i16 + 1;
                    objArr = objArr10;
                    qk0 = qk02;
                    i = i17;
                    i4 = 0;
                }
                qk0.g();
            }
        }
        return z;
    }

    /* JADX WARNING: Removed duplicated region for block: B:29:0x00b0  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void d() {
        hk0 hk0 = this.f;
        long[] jArr = hk0.a;
        int length = jArr.length - 2;
        if (length >= 0) {
            int i = 0;
            while (true) {
                long[] jArr2;
                long j = jArr[i];
                Object obj = 7;
                long j2 = -9187201950435737472L;
                if (((((~j) << 7) & j) & -9187201950435737472L) != -9187201950435737472L) {
                    int i2 = 8;
                    int i3 = 8 - ((~(i - length)) >>> 31);
                    int i4 = 0;
                    while (i4 < i3) {
                        Object obj2;
                        long j3;
                        long j4;
                        if ((j & 255) < 128) {
                            boolean z;
                            int i5 = (i << 3) + i4;
                            obj2 = obj;
                            obj = hk0.b[i5];
                            j3 = j2;
                            zj0 zj0 = (zj0) hk0.c[i5];
                            obj.getClass();
                            boolean r = ((mp0) obj).r();
                            if (!r) {
                                long j5 = 255;
                                Object[] objArr = zj0.b;
                                int[] iArr = zj0.c;
                                long[] jArr3 = zj0.a;
                                long j6 = i2;
                                i2 = jArr3.length - 2;
                                if (i2 >= 0) {
                                    jArr2 = jArr;
                                    j4 = j;
                                    int i6 = 0;
                                    while (true) {
                                        j = jArr3[i6];
                                        long[] jArr4 = jArr3;
                                        z = r;
                                        if (((((~j) << obj2) & j) & j3) != j3) {
                                            int i7 = 8 - ((~(i6 - i2)) >>> 31);
                                            for (int i8 = 0; i8 < i7; i8++) {
                                                long j7;
                                                if ((j & j5) < 128) {
                                                    int i9 = (i6 << 3) + i8;
                                                    j7 = j;
                                                    Object obj3 = objArr[i9];
                                                    int i10 = iArr[i9];
                                                    c(obj, obj3);
                                                } else {
                                                    j7 = j;
                                                }
                                                j = j7 >> j6;
                                            }
                                            if (i7 != j6) {
                                                break;
                                            }
                                        }
                                        if (i6 == i2) {
                                            break;
                                        }
                                        i6++;
                                        r = z;
                                        jArr3 = jArr4;
                                        j6 = 8;
                                    }
                                    if (!z) {
                                        hk0.l(i5);
                                    }
                                    j = 8;
                                }
                            }
                            jArr2 = jArr;
                            j4 = j;
                            z = r;
                            if (z) {
                            }
                            j = 8;
                        } else {
                            jArr2 = jArr;
                            j4 = j;
                            obj2 = obj;
                            j3 = j2;
                            j = i2;
                        }
                        i4++;
                        i2 = j;
                        j = j4 >> j;
                        obj = obj2;
                        j2 = j3;
                        jArr = jArr2;
                    }
                    jArr2 = jArr;
                    if (i3 != i2) {
                        return;
                    }
                } else {
                    jArr2 = jArr;
                }
                if (i != length) {
                    i++;
                    jArr = jArr2;
                } else {
                    return;
                }
            }
        }
    }

    public final void b(Object obj, int i, Object obj2, zj0 zj0) {
        Object obj3 = obj;
        int i2 = i;
        zj0 zj02 = zj0;
        if (this.k <= 0) {
            int i3;
            int c = zj02.c(obj3);
            if (c < 0) {
                c = ~c;
                i3 = -1;
            } else {
                i3 = zj02.c[c];
            }
            zj02.b[c] = obj3;
            zj02.c[c] = i2;
            if ((obj3 instanceof sp) && i3 != i2) {
                rp h = ((sp) obj3).h();
                this.m.put(obj3, h.f);
                zj0 zj03 = h.e;
                hk0 hk0 = this.l;
                mc0.z(hk0, obj3);
                Object[] objArr = zj03.b;
                long[] jArr = zj03.a;
                int length = jArr.length - 2;
                if (length >= 0) {
                    int i4 = 0;
                    while (true) {
                        long j = jArr[i4];
                        if (((((~j) << 7) & j) & -9187201950435737472L) != -9187201950435737472L) {
                            int i5 = 8 - ((~(i4 - length)) >>> 31);
                            for (int i6 = 0; i6 < i5; i6++) {
                                if ((j & 255) < 128) {
                                    h81 h81 = (h81) objArr[(i4 << 3) + i6];
                                    if (h81 instanceof i81) {
                                        ((i81) h81).f(2);
                                    }
                                    mc0.d(hk0, h81, obj3);
                                }
                                j >>= 8;
                            }
                            if (i5 != 8) {
                                break;
                            }
                        }
                        if (i4 == length) {
                            break;
                        }
                        i4++;
                    }
                }
            }
            if (i3 == -1) {
                if (obj3 instanceof i81) {
                    ((i81) obj3).f(2);
                }
                mc0.d(this.e, obj3, obj2);
            }
        }
    }

    public a71(i00 i00) {
        this.a = i00;
    }

    public final void c(Object obj, Object obj2) {
        hk0 hk0 = this.e;
        mc0.y(hk0, obj2, obj);
        if ((obj2 instanceof sp) && hk0.c(obj2) == null) {
            mc0.z(this.l, obj2);
            this.m.remove(obj2);
        }
    }
}