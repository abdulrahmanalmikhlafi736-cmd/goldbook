package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bj */
public final class bj extends nl {
    public Object h;
    public r60 i;
    public int j;
    public int k;
    public /* synthetic */ Object l;
    public final /* synthetic */ cj m;
    public int n;

    public final Object p(Object obj) {
        this.l = obj;
        this.n |= Integer.MIN_VALUE;
        return cj.a(this.m, null, null, this);
    }

    public bj(cj cjVar, nl nlVar) {
        this.m = cjVar;
        super(nlVar);
    }
}