package defpackage;

import android.view.autofill.AutofillManager;
import java.util.Collection;
import java.util.Map;
import java.util.Set;
import java.util.function.BiFunction;
import java.util.function.Function;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bh0 */
public final class bh0 implements Map, w80 {
    public final hk0 e;
    public lu f;
    public lu g;
    public h91 h;

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null) {
            if (bh0.class == obj.getClass()) {
                return k70.p(this.e, ((bh0) obj).e);
            }
        }
        return false;
    }

    public final Set entrySet() {
        lu luVar = this.f;
        if (luVar != null) {
            return luVar;
        }
        luVar = new lu(this.e, 0);
        this.f = luVar;
        return luVar;
    }

    public final Set keySet() {
        lu luVar = this.g;
        if (luVar != null) {
            return luVar;
        }
        luVar = new lu(this.e, 1);
        this.g = luVar;
        return luVar;
    }

    public final Collection values() {
        h91 h91 = this.h;
        if (h91 != null) {
            return h91;
        }
        h91 = new h91(this.e);
        this.h = h91;
        return h91;
    }

    public bh0(hk0 hk0) {
        hk0.getClass();
        this.e = hk0;
    }

    public final void clear() {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final Object compute(Object obj, BiFunction biFunction) {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final Object computeIfAbsent(Object obj, Function function) {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final Object computeIfPresent(Object obj, BiFunction biFunction) {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final Object merge(Object obj, Object obj2, BiFunction biFunction) {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final Object put(Object obj, Object obj2) {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final void putAll(Map map) {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final Object putIfAbsent(Object obj, Object obj2) {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final Object remove(Object obj) {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final Object replace(Object obj, Object obj2) {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final void replaceAll(BiFunction biFunction) {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final boolean containsKey(Object obj) {
        return this.e.c(obj);
    }

    public final boolean containsValue(Object obj) {
        return this.e.d(obj);
    }

    public final Object get(Object obj) {
        return ((AutofillManager) this.e);
    }

    public final int hashCode() {
        return this.e.hashCode();
    }

    public final boolean isEmpty() {
        return this.e.i();
    }

    public final String toString() {
        return this.e.toString();
    }

    public final int size() {
        return this.e.e;
    }

    public final boolean remove(Object obj, Object obj2) {
        throw new dl1("Operation is not supported for read-only collection");
    }

    public final boolean replace(Object obj, Object obj2, Object obj3) {
        throw new dl1("Operation is not supported for read-only collection");
    }
}