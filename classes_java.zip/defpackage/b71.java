package defpackage;

import android.view.autofill.AutofillManager;
import androidx.core.content.FileProvider;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: b71 */
public final class b71 {
    public final i00 a;
    public final AtomicReference b = new AtomicReference(null);
    public boolean c;
    public final hc d = new hc(16, this);
    public final l e = new l(25, (Object) this);
    public final qk0 f = new qk0(new a71[16]);
    public final Object g = new Object();
    public m2 h;
    public a71 i;
    public long j = -1;

    /* JADX WARNING: Removed duplicated region for block: B:105:0x01e9 A:{SYNTHETIC} */
    /* JADX WARNING: Removed duplicated region for block: B:136:0x021c A:{SYNTHETIC} */
    /* JADX WARNING: Removed duplicated region for block: B:136:0x021c A:{SYNTHETIC} */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void b(Object obj, i00 i00, xz xzVar) {
        int i;
        lk0 lk0;
        a71 a71;
        a71 a712;
        long j;
        Throwable th;
        Object obj2 = obj;
        i00 i002 = i00;
        b71 j2 = kb0.j();
        synchronized (this.g) {
            Object obj3;
            qk0 qk0 = this.f;
            Object[] objArr = qk0.e;
            int i2 = qk0.g;
            i = 0;
            while (true) {
                lk0 = null;
                if (i >= i2) {
                    obj3 = null;
                    break;
                }
                obj3 = objArr[i];
                if (((a71) obj3).a == i002) {
                    break;
                }
                i++;
            }
            a71 = (a71) obj3;
            if (a71 == null) {
                i002.getClass();
                vd1.e(1, i002);
                a71 = new a71(i002);
                qk0.b(a71);
            }
            a712 = this.i;
            j = this.j;
        }
        if (j != -1) {
            if (j != j2) {
                StringBuilder dl1 = new dl1("Detected multithreaded access to SnapshotStateObserver: previousThreadId=");
                dl1.append(j);
                dl1.append("), currentThread={id=");
                dl1.append(j2);
                dl1.append(", name=");
                dl1.append(Thread.currentThread().getName());
                dl1.append("}. Note that observation on multiple threads in layout/draw is not supported. Make sure your measure/layout/draw for each Owner (AndroidComposeView) is executed on the same thread.");
                FileProvider.a(dl1.toString());
            }
        }
        try {
            int i3;
            synchronized (this.g) {
                try {
                    this.i = a71;
                    this.j = j2;
                } catch (Throwable th2) {
                    th = th2;
                    synchronized (j2.g) {
                    }
                    throw th;
                }
            }
            l lVar = this.e;
            Object obj4 = a71.b;
            zj0 zj0 = a71.c;
            int i4 = a71.d;
            a71.b = obj2;
            a71.c = (zj0) ((AutofillManager) a71.f);
            if (a71.d == -1) {
                long g = n61.j().g();
                a71.d = (int) (g ^ (g >>> 32));
            }
            c10 c10 = a71.i;
            qk0 i5 = mc0.i();
            try {
                i5.b(c10);
                if (lVar == null) {
                    xzVar.a();
                } else {
                    g61 u;
                    g61 j3;
                    g61 g61 = (g61) n61.b.p();
                    if (g61 instanceof hd1) {
                        try {
                            if (((hd1) g61).t == kb0.j()) {
                                i00 i003 = ((hd1) g61).r;
                                i00 i004 = ((hd1) g61).s;
                                try {
                                    ((hd1) g61).r = n61.k(lVar, i003, true);
                                    ((hd1) g61).s = i004;
                                    xzVar.a();
                                } finally {
                                    ((hd1) g61).r = i003;
                                    ((hd1) g61).s = i004;
                                }
                            }
                        } catch (Throwable th3) {
                            th = th3;
                            j2 = this;
                            i3 = 1;
                            i5.k(i5.g - 1);
                            throw th;
                        }
                    }
                    if (g61 != null) {
                        if (!(g61 instanceof lk0)) {
                            u = g61.u(lVar);
                            j3 = u.j();
                            try {
                                xzVar.a();
                                g61.q(j3);
                                u.c();
                            } catch (Throwable th4) {
                                th = th4;
                                try {
                                    u.c();
                                    throw th;
                                } catch (Throwable th5) {
                                    th = th5;
                                    i5.k(i5.g - 1);
                                    throw th;
                                }
                            }
                        }
                    }
                    if (g61 instanceof lk0) {
                        lk0 = (lk0) g61;
                    }
                    u = new hd1(lk0, lVar, null, true, false);
                    try {
                        j3 = u.j();
                        xzVar.a();
                        g61.q(j3);
                        u.c();
                    } catch (Throwable th6) {
                        th = th6;
                        j2 = this;
                        i3 = 1;
                        u.c();
                        throw th;
                    }
                }
            } catch (Throwable th7) {
                th = th7;
                j2 = this;
                i3 = 1;
                i5.k(i5.g - 1);
                throw th;
            }
            try {
                a71 a713;
                i5.k(i5.g - 1);
                obj2 = a71.b;
                obj2.getClass();
                int i6 = a71.d;
                zj0 zj02 = a71.c;
                if (zj02 != null) {
                    long[] jArr = zj02.a;
                    int length = jArr.length - 2;
                    if (length >= 0) {
                        int i7 = 1;
                        long[] jArr2 = jArr;
                        i = 0;
                        while (true) {
                            int i8;
                            long j4 = jArr2[i];
                            i3 = i7;
                            a71 a714 = a71;
                            if (((((~j4) << 7) & j4) & -9187201950435737472L) != -9187201950435737472L) {
                                i7 = 8 - ((~(i - length)) >>> 31);
                                int i9 = 8;
                                int i10 = 0;
                                while (i10 < i7) {
                                    long j5;
                                    int i11;
                                    if ((j4 & 255) < 128) {
                                        j5 = j4;
                                        int i12 = (i << 3) + i10;
                                        Object obj5 = zj02.b[i12];
                                        i11 = i10;
                                        i10 = zj02.c[i12] != i6 ? i3 : 0;
                                        if (i10 != 0) {
                                            i8 = i6;
                                            a713 = a714;
                                            a713.c(obj2, obj5);
                                        } else {
                                            i8 = i6;
                                            a713 = a714;
                                        }
                                        if (i10 != 0) {
                                            zj02.f(i12);
                                        }
                                    } else {
                                        i8 = i6;
                                        j5 = j4;
                                        i11 = i10;
                                        a713 = a714;
                                    }
                                    j4 = j5 >> i9;
                                    i10 = i11 + 1;
                                    a714 = a713;
                                    i6 = i8;
                                }
                                i8 = i6;
                                a713 = a714;
                                if (i7 != i9) {
                                    break;
                                }
                            } else {
                                i8 = i6;
                                a713 = a714;
                            }
                            if (i == length) {
                                break;
                            }
                            i++;
                            i7 = i3;
                            a71 = a713;
                            i6 = i8;
                        }
                        a713.b = obj4;
                        a713.c = zj0;
                        a713.d = i4;
                        synchronized (this.g) {
                            this.i = a712;
                            this.j = j;
                        }
                    }
                }
                a713 = a71;
                a713.b = obj4;
                a713.c = zj0;
                a713.d = i4;
                synchronized (this.g) {
                }
            } catch (Throwable th8) {
                th = th8;
                j2 = this;
                synchronized (j2.g) {
                    j2.i = a712;
                    j2.j = j;
                }
                throw th;
            }
        } catch (Throwable th9) {
            th = th9;
            j2 = this;
            synchronized (j2.g) {
            }
            throw th;
        }
    }

    public final boolean a() {
        boolean z;
        synchronized (this.g) {
            z = this.c;
        }
        if (z) {
            return false;
        }
        z = false;
        while (true) {
            Set set;
            AtomicReference atomicReference = this.b;
            while (true) {
                Object obj = atomicReference.get();
                set = null;
                if (obj != null) {
                    Set set2;
                    Object obj2;
                    if (obj instanceof Set) {
                        set2 = (Set) obj;
                    } else if (obj instanceof List) {
                        List list = (List) obj;
                        Set set3 = (Set) list.get(0);
                        if (list.size() == 2) {
                            obj2 = list.get(1);
                        } else if (list.size() > 2) {
                            obj2 = list.subList(1, list.size());
                        }
                        set2 = set3;
                    } else {
                        a5.b("Unexpected notification");
                        throw new RuntimeException();
                    }
                    while (!atomicReference.compareAndSet(obj, obj2)) {
                        if (atomicReference.get() != obj) {
                        }
                    }
                    set = set2;
                    break;
                }
                break;
            }
            if (set == null) {
                return z;
            }
            synchronized (this.g) {
                qk0 qk0 = this.f;
                Object[] objArr = qk0.e;
                int i = qk0.g;
                for (int i2 = 0; i2 < i; i2++) {
                    if (!((a71) objArr[i2]).a(set)) {
                        if (!z) {
                            z = false;
                        }
                    }
                    z = true;
                }
            }
        }
    }

    public b71(i00 i00) {
        this.a = i00;
    }

    public final void c() {
        hc hcVar = this.d;
        n61.e(n61.a);
        synchronized (n61.c) {
            n61.h = tg.Y(n61.h, hcVar);
        }
        this.h = new m2(hcVar);
    }
}