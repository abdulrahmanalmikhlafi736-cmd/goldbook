package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: jr0 */
public abstract class jr0 {
    public final boolean a;
    public final boolean b;

    public jr0(int i) {
        boolean z = true;
        boolean z2 = (i & 1) == 0;
        if ((i & 2) != 0) {
            z = false;
        }
        this.a = z2;
        this.b = z;
    }
}