package defpackage;

import android.view.autofill.AutofillValue;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: db */
public abstract class db implements ml, dm, Serializable {
    public final ml e;

    public StackTraceElement o() {
        un unVar = (un) getClass().getAnnotation(un.class);
        String str = null;
        if (unVar != null) {
            if (unVar.v() >= 1) {
                int intValue;
                String c;
                int i = -1;
                try {
                    Field declaredField = getClass().getDeclaredField("label");
                    declaredField.setAccessible(true);
                    Object obj = declaredField.get(this);
                    Integer num = obj instanceof Integer ? (Integer) obj : null;
                    intValue = (num != null ? num.intValue() : 0) - 1;
                } catch (Exception unused) {
                    intValue = -1;
                }
                if (intValue >= 0) {
                    i = unVar.l()[intValue];
                }
                k9 k9Var = gh0.h;
                k9 k9Var2 = gh0.i;
                if (k9Var2 == null) {
                    try {
                        k9 k9Var3 = new k9(Class.class.getDeclaredMethod("getModule", null), getClass().getClassLoader().loadClass("java.lang.Module").getDeclaredMethod("getDescriptor", null), getClass().getClassLoader().loadClass("java.lang.module.ModuleDescriptor").getDeclaredMethod("name", null), 6);
                        gh0.i = k9Var3;
                        k9Var2 = k9Var3;
                    } catch (Exception unused2) {
                        gh0.i = k9Var;
                        k9Var2 = k9Var;
                    }
                }
                if (k9Var2 != k9Var) {
                    Method method = (Method) k9Var2.f;
                    if (method != null) {
                        Object invoke = method.invoke(getClass(), null);
                        if (invoke != null) {
                            method = (Method) k9Var2.g;
                            if (method != null) {
                                invoke = method.invoke(invoke, null);
                                if (invoke != null) {
                                    method = (Method) k9Var2.h;
                                    invoke = method != null ? method.invoke(invoke, null) : null;
                                    if (invoke instanceof String) {
                                        str = (String) invoke;
                                    }
                                }
                            }
                        }
                    }
                }
                if (str == null) {
                    c = unVar.c();
                } else {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(str);
                    stringBuilder.append('/');
                    stringBuilder.append(unVar.c());
                    c = stringBuilder.toString();
                }
                return new StackTraceElement(c, unVar.m(), unVar.f(), i);
            }
        }
        return null;
    }

    public final AutofillValue h(Object obj) {
        while (true) {
            this = this;
            ml mlVar = this.e;
            mlVar.getClass();
            try {
                obj = this.p(obj);
                if (obj == cm.e) {
                    return;
                }
            } catch (Throwable th) {
                obj = new px0(th);
            }
            this.q();
            if (mlVar instanceof db) {
                ml thisR = mlVar;
            } else {
                ((AutofillValue) mlVar);
                return;
            }
        }
    }

    public String toString() {
        StringBuilder dl1 = new dl1("Continuation at ");
        Object o = o();
        if (o == null) {
            o = getClass().getName();
        }
        dl1.append(o);
        return dl1.toString();
    }

    public dm d() {
        ml mlVar = this.e;
        return mlVar instanceof dm ? (dm) mlVar : null;
    }

    public ml n(ml mlVar, Object obj) {
        throw new dl1("create(Any?;Continuation) has not been overridden");
    }

    public db(ml mlVar) {
        this.e = mlVar;
    }

    public void q() {
    }

    public abstract Object p(Object obj);
}