package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: mi0 */
public interface mi0 {
    Object a(m00 m00, Object obj);

    mi0 b(mi0 mi0);

    boolean d(i00 i00);
}