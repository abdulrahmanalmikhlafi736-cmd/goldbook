package defpackage;

import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.os.Binder;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcelable;
import android.util.Size;
import android.util.SizeF;
import android.util.SparseArray;
import android.view.KeyEvent;
import android.view.View;
import android.view.autofill.AutofillManager;
import android.view.autofill.AutofillManager$AutofillCallback;
import android.view.autofill.AutofillValue;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.Serializable;
import java.lang.reflect.Method;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.CancellationException;
import java.util.zip.DataFormatException;
import java.util.zip.Deflater;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.Inflater;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: a5 */
public abstract class a5 {
    public static final ml[] a = new ml[0];
    public static final a51 b = a51.f;
    public static final pi c = new pi(856539202, false, new h90(1));
    public static final pi d = new pi(1201367364, false, new h90(2));
    public static final pi e = new pi(-454738871, false, new h90(6));
    public static final pi f = new pi(-282324790, false, new h90(7));
    public static final Class[] g = new Class[]{Serializable.class, Parcelable.class, String.class, SparseArray.class, Binder.class, Size.class, SizeF.class};
    public static final float[] h = new float[]{1.0f, 10.0f, 100.0f, 1000.0f, 10000.0f, 100000.0f, 1000000.0f, 1.0E7f, 1.0E8f, 1.0E9f, 1.0E10f};
    public static final long[] i = new long[]{-6499023860262858360L, -3512093806901185046L, -9112587656954322510L, -6779048552765515233L, -3862124672529506138L, -215969822234494768L, -7052510166537641086L, -4203951689744663454L, -643253593753441413L, -7319562523736982739L, -4537767136243840520L, -1060522901877412746L, -7580355841314464822L, -4863758783215693124L, -1468012460592228501L, -7835036815511224669L, -5182110000961642932L, -1865951482774665761L, -8083748704375247957L, -5492999862041672042L, -2254563809124702148L, -8326631408344020699L, -5796603242002637969L, -2634068034075909558L, -8563821548938525330L, -6093090917745768758L, -3004677628754823043L, -8795452545612846258L, -6382629663588669919L, -3366601061058449494L, -9021654690802612790L, -6665382345075878084L, -3720041912917459700L, -38366372719436721L, -6941508010590729807L, -4065198994811024355L, -469812725086392539L, -7211161980820077193L, -4402266457597708587L, -891147053569747830L, -7474495936122174250L, -4731433901725329908L, -1302606358729274481L, -7731658001846878407L, -5052886483881210105L, -1704422086424124727L, -7982792831656159810L, -5366805021142811859L, -2096820258001126919L, -8228041688891786181L, -5673366092687344822L, -2480021597431793123L, -8467542526035952558L, -5972742139117552794L, -2854241655469553088L, -8701430062309552536L, -6265101559459552766L, -3219690930897053053L, -8929835859451740015L, -6550608805887287114L, -3576574988931720989L, -9152888395723407474L, -6829424476226871438L, -3925094576856201394L, -294682202642863838L, -7101705404292871755L, -4265445736938701790L, -720121152745989333L, -7367604748107325189L, -4597819916706768583L, -1135588877456072824L, -7627272076051127371L, -4922404076636521310L, -1541319077368263733L, -7880853450996246689L, -5239380795317920458L, -1937539975720012668L, -8128491512466089774L, -5548928372155224313L, -2324474446766642487L, -8370325556870233411L, -5851220927660403859L, -2702340141148116920L, -8606491615858654931L, -6146428501395930760L, -3071349608317525546L, -8837122532839535322L, -6434717147622031249L, -3431710416100151157L, -9062348037703676329L, -6716249028702207507L, -3783625267450371480L, -117845565885576446L, -6991182506319567135L, -4127292114472071014L, -547429124662700864L, -7259672230555269896L, -4462904269766699466L, -966944318780986428L, -7521869226879198374L, -4790650515171610063L, -1376627125537124675L, -7777920981101784778L, -5110715207949843068L, -1776707991509915931L, -8027971522334779313L, -5423278384491086237L, -2167411962186469893L, -8272161504007625539L, -5728515861582144020L, -2548958808550292121L, -8510628282985014432L, -6026599335303880135L, -2921563150702462265L, -8743505996830120772L, -6317696477610263061L, -3285434578585440922L, -8970925639256982432L, -6601971030643840136L, -3640777769877412266L, -9193015133814464522L, -6879582898840692749L, -3987792605123478032L, -373054737976959636L, -7150688238876681629L, -4326674280168464132L, -796656831783192261L, -7415439547505577019L, -4657613415954583370L, -1210330751515841308L, -7673985747338482674L, -4980796165745715438L, -1614309188754756393L, -7926472270612804602L, -5296404319838617848L, -2008819381370884406L, -8173041140997884610L, -5604615407819967859L, -2394083241347571919L, -8413831053483314306L, -5905602798426754978L, -2770317479606055818L, -8648977452394866743L, -6199535797066195524L, -3137733727905356501L, -8878612607581929669L, -6486579741050024183L, -3496538657885142324L, -9102865688819295809L, -6766896092596731857L, -3846934097318526917L, -196981603220770742L, -7040642529654063570L, -4189117143640191558L, -624710411122851544L, -7307973034592864071L, -4523280274813692185L, -1042414325089727327L, -7569037980822161435L, -4849611457600313890L, -1450328303573004458L, -7823984217374209643L, -5168294253290374149L, -1848681798185579782L, -8072955151507069220L, -5479507920956448621L, -2237698882768172872L, -8316090829371189901L, -5783427518286599473L, -2617598379430861437L, -8553528014785370254L, -6080224000054324913L, -2988593981640518238L, -8785400266166405755L, -6370064314280619289L, -3350894374423386208L, -9011838011655698236L, -6653111496142234891L, -3704703351750405709L, -19193171260619233L, -6929524759678968877L, -4050219931171323192L, -451088895536766085L, -7199459587351560659L, -4387638465762062920L, -872862063775190746L, -7463067817500576073L, -4717148753448332187L, -1284749923383027329L, -7720497729755473937L, -5038936143766954517L, -1686984161281305242L, -7971894128441897632L, -5353181642124984136L, -2079791034228842266L, -8217398424034108273L, -5660062011615247437L, -2463391496091671392L, -8457148712698376476L, -5959749872445582691L, -2838001322129590460L, -8691279853972075893L, -6252413799037706963L, -3203831230369745799L, -8919923546622172981L, -6538218414850328322L, -3561087000135522498L, -9143208402725783417L, -6817324484979841368L, -3909969587797413806L, -275775966319379353L, -7089889006590693952L, -4250675239810979535L, -701658031336336515L, -7356065297226292178L, -4583395603105477319L, -1117558485454458744L, -7616003081050118571L, -4908317832885260310L, -1523711272679187483L, -7869848573065574033L, -5225624697904579637L, -1920344853953336643L, -8117744561361917258L, -5535494683275008668L, -2307682335666372931L, -8359830487432564938L, -5838102090863318269L, -2685941595151759932L, -8596242524610931813L, -6133617137336276863L, -3055335403242958174L, -8827113654667930715L, -6422206049907525490L, -3416071543957018958L, -9052573742614218705L, -6704031159840385477L, -3768352931373093942L, -98755145788979524L, -6979250993759194058L, -4112377723771604669L, -528786136287117932L, -7248020362820530564L, -4448339435098275301L, -948738275445456222L, -7510490449794491995L, -4776427043815727089L, -1358847786342270957L, -7766808894105001205L, -5096825099203863602L, -1759345355577441598L, -8017119874876982855L, -5409713825168840664L, -2150456263033662926L, -8261564192037121185L, -5715269221619013577L, -2532400508596379068L, -8500279345513818773L, -6013663163464885563L, -2905392935903719049L, -8733399612580906262L, -6305063497298744923L, -3269643353196043250L, -8961056123388608887L, -6589634135808373205L, -3625356651333078602L, -9183376934724255983L, -6867535149977932074L, -3972732919045027189L, -354230130378896082L, -7138922859127891907L, -4311967555482476980L, -778273425925708321L, -7403949918844649557L, -4643251380128424042L, -1192378206733142148L, -7662765406849295699L, -4966770740134231719L, -1596777406740401745L, -7915514906853832947L, -5282707615139903279L, -1991698500497491195L, -8162340590452013853L, -5591239719637629412L, -2377363631119648861L, -8403381297090862394L, -5892540602936190089L, -2753989735242849707L, -8638772612167862923L, -6186779746782440750L, -3121788665050663033L, -8868646943297746252L, -6474122660694794911L, -3480967307441105734L, -9093133594791772940L, -6754730975062328271L, -3831727700400522434L, -177973607073265139L, -7028762532061872568L, -4174267146649952806L, -606147914885053103L, -7296371474444240046L, -4508778324627912153L, -1024286887357502287L, -7557708332239520786L, -4835449396872013078L, -1432625727662628443L, -7812920107430224633L, -5154464115860392887L, -1831394126398103205L, -8062150356639896359L, -5466001927372482545L, -2220816390788215277L, -8305539271883716405L, -5770238071427257602L, -2601111570856684098L, -8543223759426509417L, -6067343680855748868L, -2972493582642298180L, -8775337516792518219L, -6357485877563259869L, -3335171328526686933L, -9002011107970261189L, -6640827866535438582L, -3689348814741910324L, Long.MIN_VALUE, -6917529027641081856L, -4035225266123964416L, -432345564227567616L, -7187745005283311616L, -4372995238176751616L, -854558029293551616L, -7451627795949551616L, -4702848726509551616L, -1266874889709551616L, -7709325833709551616L, -5024971273709551616L, -1669528073709551616L, -7960984073709551616L, -5339544073709551616L, -2062744073709551616L, -8206744073709551616L, -5646744073709551616L, -2446744073709551616L, -8446744073709551616L, -5946744073709551616L, -2821744073709551616L, -8681119073709551616L, -6239712823709551616L, -3187955011209551616L, -8910000909647051616L, -6525815118631426616L, -3545582879861895366L, -9133518327554766460L, -6805211891016070171L, -3894828845342699810L, -256850038250986858L, -7078060301547948643L, -4235889358507547899L, -683175679707046970L, -7344513827457986212L, -4568956265895094861L, -1099509313941480672L, -7604722348854507276L, -4894216917640746191L, -1506085128623544835L, -7858832233030797378L, -5211854272861108819L, -1903131822648998119L, -8106986416796705681L, -5522047002568494197L, -2290872734783229842L, -8349324486880600507L, -5824969590173362730L, -2669525969289315508L, -8585982758446904049L, -6120792429631242157L, -3039304518611664792L, -8817094351773372351L, -6409681921289327535L, -3400416383184271515L, -9042789267131251553L, -6691800565486676537L, -3753064688430957767L, -79644842111309304L, -6967307053960650171L, -4097447799023424810L, -510123730351893109L, -7236356359111015049L, -4433759430461380907L, -930513269649338230L, -7499099821171918250L, -4762188758037509908L, -1341049929119499481L, -7755685233340769032L, -5082920523248573386L, -1741964635633328828L, -8006256924911912374L, -5396135137712502563L, -2133482903713240300L, -8250955842461857044L, -5702008784649933400L, -2515824962385028846L, -8489919629131724885L, -6000713517987268202L, -2889205879056697349L, -8723282702051517699L, -6292417359137009220L, -3253835680493873621L, -8951176327949752869L, -6577284391509803182L, -3609919470959866074L, -9173728696990998152L, -6855474852811359786L, -3957657547586811828L, -335385916056126881L, -7127145225176161157L, -4297245513042813542L, -759870872876129024L, -7392448323188662496L, -4628874385558440216L, -1174406963520662366L, -7651533379841495835L, -4952730706374481889L, -1579227364540714458L, -7904546130479028392L, -5268996644671397586L, -1974559787411859078L, -8151628894773493780L, -5577850100039479321L, -2360626606621961247L, -8392920656779807636L, -5879464802547371641L, -2737644984756826647L, -8628557143114098510L, -6174010410465235234L, -3105826994654156138L, -8858670899299929442L, -6461652605697523899L, -3465379738694516970L, -9083391364325154962L, -6742553186979055799L, -3816505465296431844L, -158945813193151901L, -7016870160886801794L, -4159401682681114339L, -587566084924005019L, -7284757830718584993L, -4494261269970843337L, -1006140569036166268L, -7546366883288685774L, -4821272585683469313L, -1414904713676948737L, -7801844473689174817L, -5140619573684080617L, -1814088448677712867L, -8051334308064652398L, -5452481866653427593L, -2203916314889396588L, -8294976724446954723L, -5757034887131305500L, -2584607590486743971L, -8532908771695296838L, -6054449946191733143L, -2956376414312278525L, -8765264286586255934L, -6344894339805432014L, -3319431906329402113L, -8992173969096958177L, -6628531442943809817L, -3673978285252374367L, -9213765455923815836L, -6905520801477381891L, -4020214983419339459L, -413582710846786420L, -7176018221920323369L, -4358336758973016307L, -836234930288882479L, -7440175859071633406L, -4688533805412153853L, -1248981238337804412L, -7698142301602209614L, -5010991858575374113L, -1652053804791829737L, -7950062655635975442L, -5325892301117581398L, -2045679357969588844L, -8196078626372074883L, -5633412264537705700L, -2430079312244744221L, -8436328597794046994L, -5933724728815170839L, -2805469892591575644L, -8670947710510816634L, -6226998619711132888L, -3172062256211528206L, -8900067937773286985L, -6513398903789220827L, -3530062611309138130L, -9123818159709293187L, -6793086681209228580L, -3879672333084147821L, -237904397927796872L, -7066219276345954901L, -4221088077005055722L, -664674077828931749L, -7332950326284164199L, -4554501889427817345L, -1081441343357383777L, -7593429867239446717L, -4880101315621920492L, -1488440626100012711L, -7847804418953589800L, -5198069505264599346L, -1885900863153361279L, -8096217067111932656L, -5508585315462527915L, -2274045625900771990L, -8338807543829064350L, -5811823411358942533L, -2653093245771290262L, -8575712306248138270L, -6107954364382784934L, -3023256937051093263L, -8807064613298015146L, -6397144748195131028L, -3384744916816525881L, -9032994600651410532L, -6679557232386875260L, -3737760522056206171L, -60514634142869810L, -6955350673980375487L, -4082502324048081455L, -491441886632713915L, -7224680206786528053L, -4419164240055772162L, -912269281642327298L, -7487697328667536418L, -4747935642407032618L, -1323233534581402868L, -7744549986754458649L, -5069001465015685407L, -1724565812842218855L, -7995382660667468640L, -5382542307406947896L, -2116491865831296966L, -8240336443785642460L, -5688734536304665171L, -2499232151953443560L, -8479549122611984081L, -5987750384837592197L, -2873001962619602342L, -8713155254278333320L, -6279758049420528746L, -3238011543348273028L, -8941286242233752499L, -6564921784364802720L, -3594466212028615495L, -9164070410158966541L, -6843401994271320272L, -3942566474411762436L, -316522074587315140L, -7115355324258153819L, -4282508136895304370L, -741449152691742558L, -7380934748073420955L, -4614482416664388289L, -1156417002403097458L, -7640289654143017767L, -4938676049251384305L, -1561659043136842477L, -7893565929601608404L, -5255271393574622601L, -1957403223540890347L, -8140906042354138323L, -5564446534515285000L, -2343872149716718346L, -8382449121214030822L, -5866375383090150624L, -2721283210435300376L, -8618331034163144591L, -6161227774276542835L, -3089848699418290639L, -8848684464777513506L, -6449169562544503978L, -3449775934753242068L, -9073638986861858149L, -6730362715149934782L, -3801267375510030573L, -139898200960150313L, -7004965403241175802L, -4144520735624081848L, -568964901102714406L, -7273132090830278360L, -4479729095110460046L, -987975350460687153L, -7535013621679011327L, -4807081008671376254L, -1397165242411832414L, -7790757304148477115L, -5126760611758208489L, -1796764746270372707L, -8040506994060064798L, -5438947724147693094L, -2186998636757228463L, -8284403175614349646L, -5743817951090549153L, -2568086420435798537L, -8522583040413455942L, -6041542782089432023L, -2940242459184402125L, -8755180564631333184L, -6332289687361778576L, -3303676090774835316L, -8982326584375353929L, -6616222212041804507L, -3658591746624867729L, -9204148869281624187L, -6893500068174642330L, -4005189066790915008L, -394800315061255856L, -7164279224554366766L, -4343663012265570553L, -817892746904575288L, -7428711994456441411L, -4674203974643163860L, -1231068949876566920L, -7686947121313936181L, -4996997883215032323L, -1634561335591402499L, -7939129862385708418L, -5312226309554747619L, -2028596868516046619L, -8185402070463610993L};
    public static final byte[] j = new byte[]{(byte) 112, (byte) 114, (byte) 111, (byte) 0};
    public static final byte[] k = new byte[]{(byte) 112, (byte) 114, (byte) 109, (byte) 0};
    public static final f11 l = new h90(0);
    public static final g11 m = new Object();
    public static final eq n = new h90(1);
    public static final h11 o = new Object();
    public static final Object p = new Object();
    public static final av0 q = new h90(14);

    public static boolean O(ByteArrayOutputStream byteArrayOutputStream, byte[] bArr, up[] upVarArr) {
        Throwable th;
        ByteArrayOutputStream byteArrayOutputStream2 = byteArrayOutputStream;
        byte[] bArr2 = bArr;
        up[] upVarArr2 = upVarArr;
        byte[] bArr3 = ac.x;
        byte[] bArr4 = ac.w;
        byte[] bArr5 = ac.t;
        int i = 0;
        int i2;
        int length;
        if (Arrays.equals(bArr2, bArr5)) {
            ArrayList h90 = new h90(3);
            ArrayList h902 = new h90(3);
            ByteArrayOutputStream byteArrayOutputStream3 = new ByteArrayOutputStream();
            try {
                int i3;
                String s;
                int length2;
                a5.V(byteArrayOutputStream3, upVarArr2.length);
                int i4 = 2;
                int i5 = 2;
                for (up upVar : upVarArr2) {
                    a5.U(byteArrayOutputStream3, upVar.c, 4);
                    a5.U(byteArrayOutputStream3, upVar.d, 4);
                    a5.U(byteArrayOutputStream3, (long) upVar.g, 4);
                    s = a5.s(bArr5, upVar.a, upVar.b);
                    i5 += 14;
                    Charset charset = StandardCharsets.UTF_8;
                    length2 = s.getBytes(charset).length;
                    a5.V(byteArrayOutputStream3, length2);
                    i5 += length2;
                    byteArrayOutputStream3.write(s.getBytes(charset));
                }
                bArr5 = byteArrayOutputStream3.toByteArray();
                s = ", does not match actual size ";
                String str = "Expected size ";
                StringBuilder stringBuilder;
                if (i5 == bArr5.length) {
                    int i6;
                    sl1 sl1 = new sl1(1, bArr5, false);
                    byteArrayOutputStream3.close();
                    h90.add(sl1);
                    ByteArrayOutputStream byteArrayOutputStream4 = new ByteArrayOutputStream();
                    i2 = 0;
                    i3 = i2;
                    while (i2 < upVarArr2.length) {
                        try {
                            up upVar2 = upVarArr2[i2];
                            a5.V(byteArrayOutputStream4, i2);
                            i3 += 4;
                            a5.V(byteArrayOutputStream4, upVar2.e);
                            i3 += upVar2.e * i4;
                            int[] iArr = upVar2.h;
                            length2 = iArr.length;
                            int i7 = i;
                            while (i < length2) {
                                int i8 = iArr[i];
                                i6 = i4;
                                a5.V(byteArrayOutputStream4, i8 - i7);
                                i++;
                                i4 = i6;
                                i7 = i8;
                            }
                            i6 = i4;
                            i2++;
                            i = 0;
                        } catch (Throwable th2) {
                            th.addSuppressed(th2);
                        }
                    }
                    i6 = i4;
                    byte[] toByteArray = byteArrayOutputStream4.toByteArray();
                    if (i3 == toByteArray.length) {
                        sl1 sl12 = new sl1(3, toByteArray, true);
                        byteArrayOutputStream4.close();
                        h90.add(sl12);
                        byteArrayOutputStream4 = new ByteArrayOutputStream();
                        i2 = 0;
                        i = 0;
                        while (i2 < upVarArr2.length) {
                            try {
                                up upVar3 = upVarArr2[i2];
                                i5 = 0;
                                for (Entry value : upVar3.i.entrySet()) {
                                    i5 |= ((Integer) value.getValue()).intValue();
                                }
                                ByteArrayOutputStream byteArrayOutputStream5 = new ByteArrayOutputStream();
                                try {
                                    a5.S(byteArrayOutputStream5, i5, upVar3);
                                    byte[] toByteArray2 = byteArrayOutputStream5.toByteArray();
                                    byteArrayOutputStream5.close();
                                    byteArrayOutputStream5 = new ByteArrayOutputStream();
                                    try {
                                        a5.T(byteArrayOutputStream5, upVar3);
                                        byte[] toByteArray3 = byteArrayOutputStream5.toByteArray();
                                        byteArrayOutputStream5.close();
                                        a5.V(byteArrayOutputStream4, i2);
                                        i3 = (toByteArray2.length + 2) + toByteArray3.length;
                                        i += 6;
                                        bArr3 = toByteArray3;
                                        a5.U(byteArrayOutputStream4, (long) i3, 4);
                                        a5.V(byteArrayOutputStream4, i5);
                                        byteArrayOutputStream4.write(toByteArray2);
                                        byteArrayOutputStream4.write(bArr3);
                                        i += i3;
                                        i2++;
                                    } catch (Throwable th22) {
                                        th.addSuppressed(th22);
                                    }
                                } catch (Throwable th222) {
                                    th.addSuppressed(th222);
                                }
                            } catch (Throwable th2222) {
                                th.addSuppressed(th2222);
                            }
                        }
                        byte[] toByteArray4 = byteArrayOutputStream4.toByteArray();
                        if (i == toByteArray4.length) {
                            sl1 sl13 = new sl1(4, toByteArray4, true);
                            byteArrayOutputStream4.close();
                            h90.add(sl13);
                            long size = 12 + ((long) (h90.size() * 16));
                            a5.U(byteArrayOutputStream2, (long) h90.size(), 4);
                            int i9 = 0;
                            while (i9 < h90.size()) {
                                long j;
                                sl13 = (sl1) h90.get(i9);
                                i = sl13.a;
                                byte[] bArr6 = sl13.b;
                                if (i != 1) {
                                    i5 = i6;
                                    if (i == i5) {
                                        j = 1;
                                    } else if (i == 3) {
                                        j = 2;
                                    } else if (i == 4) {
                                        j = 3;
                                    } else if (i == 5) {
                                        j = 4;
                                    } else {
                                        throw null;
                                    }
                                }
                                i5 = i6;
                                j = 0;
                                a5.U(byteArrayOutputStream2, j, 4);
                                a5.U(byteArrayOutputStream2, size, 4);
                                if (sl13.c) {
                                    long length3 = (long) bArr6.length;
                                    bArr3 = a5.m(bArr6);
                                    h902.add(bArr3);
                                    a5.U(byteArrayOutputStream2, (long) bArr3.length, 4);
                                    a5.U(byteArrayOutputStream2, length3, 4);
                                    length = bArr3.length;
                                } else {
                                    h902.add(bArr6);
                                    a5.U(byteArrayOutputStream2, (long) bArr6.length, 4);
                                    a5.U(byteArrayOutputStream2, 0, 4);
                                    length = bArr6.length;
                                }
                                size += (long) length;
                                i9++;
                                i6 = i5;
                            }
                            for (i = 0; i < h902.size(); i++) {
                                byteArrayOutputStream2.write((byte[]) h902.get(i));
                            }
                        } else {
                            stringBuilder = new StringBuilder();
                            stringBuilder.append(str);
                            stringBuilder.append(i);
                            stringBuilder.append(s);
                            stringBuilder.append(toByteArray4.length);
                            throw new dl1(stringBuilder.toString());
                        }
                    }
                    stringBuilder = new StringBuilder();
                    stringBuilder.append(str);
                    stringBuilder.append(i3);
                    stringBuilder.append(s);
                    stringBuilder.append(toByteArray.length);
                    throw new dl1(stringBuilder.toString());
                }
                stringBuilder = new StringBuilder();
                stringBuilder.append(str);
                stringBuilder.append(i5);
                stringBuilder.append(s);
                stringBuilder.append(bArr5.length);
                throw new dl1(stringBuilder.toString());
            } catch (Throwable th22222) {
                th.addSuppressed(th22222);
            }
        } else {
            bArr5 = ac.u;
            Charset charset2;
            if (Arrays.equals(bArr2, bArr5)) {
                bArr2 = a5.o(upVarArr2, bArr5);
                a5.U(byteArrayOutputStream2, (long) upVarArr2.length, 1);
                a5.U(byteArrayOutputStream2, (long) bArr2.length, 4);
                bArr2 = a5.m(bArr2);
                a5.U(byteArrayOutputStream2, (long) bArr2.length, 4);
                byteArrayOutputStream2.write(bArr2);
                return true;
            } else if (Arrays.equals(bArr2, bArr4)) {
                a5.U(byteArrayOutputStream2, (long) upVarArr2.length, 1);
                for (up upVar4 : upVarArr2) {
                    i2 = upVar4.i.size() * 4;
                    String s2 = a5.s(bArr4, upVar4.a, upVar4.b);
                    charset2 = StandardCharsets.UTF_8;
                    a5.V(byteArrayOutputStream2, s2.getBytes(charset2).length);
                    a5.V(byteArrayOutputStream2, upVar4.h.length);
                    a5.U(byteArrayOutputStream2, (long) i2, 4);
                    a5.U(byteArrayOutputStream2, upVar4.c, 4);
                    byteArrayOutputStream2.write(s2.getBytes(charset2));
                    for (Integer intValue : upVar4.i.keySet()) {
                        a5.V(byteArrayOutputStream2, intValue.intValue());
                        a5.V(byteArrayOutputStream2, 0);
                    }
                    for (int V : upVar4.h) {
                        a5.V(byteArrayOutputStream2, V);
                    }
                }
            } else {
                bArr4 = ac.v;
                if (Arrays.equals(bArr2, bArr4)) {
                    bArr2 = a5.o(upVarArr2, bArr4);
                    a5.U(byteArrayOutputStream2, (long) upVarArr2.length, 1);
                    a5.U(byteArrayOutputStream2, (long) bArr2.length, 4);
                    bArr2 = a5.m(bArr2);
                    a5.U(byteArrayOutputStream2, (long) bArr2.length, 4);
                    byteArrayOutputStream2.write(bArr2);
                    return true;
                } else if (!Arrays.equals(bArr2, bArr3)) {
                    return false;
                } else {
                    a5.V(byteArrayOutputStream2, upVarArr2.length);
                    for (up upVar5 : upVarArr2) {
                        String str2 = upVar5.a;
                        TreeMap treeMap = upVar5.i;
                        str2 = a5.s(bArr3, str2, upVar5.b);
                        charset2 = StandardCharsets.UTF_8;
                        a5.V(byteArrayOutputStream2, str2.getBytes(charset2).length);
                        a5.V(byteArrayOutputStream2, treeMap.size());
                        a5.V(byteArrayOutputStream2, upVar5.h.length);
                        a5.U(byteArrayOutputStream2, upVar5.c, 4);
                        byteArrayOutputStream2.write(str2.getBytes(charset2));
                        for (Integer intValue2 : treeMap.keySet()) {
                            a5.V(byteArrayOutputStream2, intValue2.intValue());
                        }
                        for (int V2 : upVar5.h) {
                            a5.V(byteArrayOutputStream2, V2);
                        }
                    }
                }
            }
        }
        return true;
    }

    /* JADX WARNING: Removed duplicated region for block: B:155:0x0258  */
    /* JADX WARNING: Removed duplicated region for block: B:151:0x024a  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final long A(int i, int i2, String str) {
        long j;
        int floatToRawIntBits;
        long floatToRawIntBits2;
        int i3 = i;
        int i4 = i2;
        String str2 = str;
        long j2 = 4294967295L;
        if (i3 == i4) {
            j = ((long) i3) << 32;
            floatToRawIntBits = Float.floatToRawIntBits(Float.NaN);
        } else {
            int i5;
            int charAt;
            long j3;
            int i6;
            long j4;
            Object obj;
            int i7;
            int i8;
            int i9;
            int i10;
            long charAt2;
            char charAt3 = str2.charAt(i3);
            Object obj2 = charAt3 == '-' ? 1 : null;
            if (obj2 != null) {
                i5 = i3 + 1;
                if (i5 == i4) {
                    j = ((long) i5) << 32;
                    floatToRawIntBits = Float.floatToRawIntBits(Float.NaN);
                } else {
                    charAt = str2.charAt(i5);
                    if (((char) (charAt - 48)) >= 10) {
                        if (charAt != '.') {
                            j = ((long) i5) << 32;
                            floatToRawIntBits = Float.floatToRawIntBits(Float.NaN);
                        }
                    }
                }
            } else {
                charAt = charAt3;
                i5 = i3;
            }
            int length = str2.length();
            long j5 = 0;
            float f = Float.NaN;
            int i11 = i5;
            long j6 = 0;
            while (i11 != i4) {
                j3 = j2;
                i6 = charAt - 48;
                if (((char) i6) >= 10) {
                    break;
                }
                j6 = (j6 * 10) + ((long) i6);
                i11++;
                charAt = i11 < length ? str2.charAt(i11) : 0;
                j2 = j3;
            }
            j3 = j2;
            i6 = i11 - i5;
            int i12 = 48;
            if (i11 == i4 || charAt != 46) {
                j4 = 32;
                obj = 1;
                i7 = i11;
                i8 = i7;
                i9 = 0;
            } else {
                charAt = i11 + 1;
                j4 = 32;
                i7 = charAt;
                while (true) {
                    obj = 1;
                    if (i4 - i7 < 4) {
                        i10 = charAt;
                        break;
                    }
                    i10 = charAt;
                    charAt2 = ((((long) str2.charAt(i7)) | (((long) str2.charAt(i7 + 1)) << 16)) | (((long) str2.charAt(i7 + 2)) << j4)) | (((long) str2.charAt(i7 + 3)) << 48);
                    long j7 = charAt2 - 13511005043687472L;
                    i9 = (((charAt2 + 19703549022044230L) | j7) & -35747867511423104L) != 0 ? -1 : (int) ((j7 * 281475406208040961L) >>> 48);
                    if (i9 < 0) {
                        break;
                    }
                    j6 = (j6 * 10000) + ((long) i9);
                    i7 += 4;
                    charAt = i10;
                }
                char charAt4 = i7 < length ? str2.charAt(i7) : 0;
                loop2:
                while (true) {
                    charAt = charAt4;
                    while (i7 != i4) {
                        i9 = charAt - 48;
                        if (((char) i9) >= 10) {
                            break loop2;
                        }
                        j6 = (j6 * 10) + ((long) i9);
                        i7++;
                        if (i7 < length) {
                            charAt4 = str2.charAt(i7);
                        } else {
                            charAt = 0;
                        }
                    }
                    break loop2;
                }
                i9 = i10 - i7;
                i6 -= i9;
                i8 = i10;
            }
            if (i6 == 0) {
                j = ((long) i7) << j4;
                floatToRawIntBits2 = ((long) Float.floatToRawIntBits(f)) & j3;
                return j | floatToRawIntBits2;
            }
            int i13;
            int charAt5;
            int i14;
            long j8;
            Object obj3;
            long j9;
            if ((charAt | 32) == 101) {
                i13 = i7 + 1;
                char charAt6 = i13 < length ? str2.charAt(i13) : 0;
                Object obj4 = charAt6 == '-' ? obj : null;
                if (obj4 != null || charAt6 == '+') {
                    i13 = i7 + 2;
                }
                charAt5 = str2.charAt(i13);
                i14 = 0;
                while (i13 != i4) {
                    charAt5 -= i12;
                    i10 = i9;
                    if (((char) charAt5) >= 10) {
                        break;
                    }
                    if (i14 < 1024) {
                        i14 = (i14 * 10) + charAt5;
                    }
                    i13++;
                    charAt5 = i13 < length ? str2.charAt(i13) : 0;
                    i9 = i10;
                    i12 = 48;
                }
                i10 = i9;
                if (obj4 != null) {
                    i14 = -i14;
                }
                i9 = i10 + i14;
            } else {
                i10 = i9;
                i13 = i7;
                i14 = 0;
            }
            i12 = 19;
            if (i6 > 19) {
                char charAt7 = str2.charAt(i5);
                charAt = i5;
                while (i13 != i4) {
                    if (charAt7 != '0' && charAt7 != '.') {
                        i4 = 19;
                        break;
                    }
                    if (charAt7 == '0') {
                        i6--;
                    }
                    charAt++;
                    charAt7 = charAt < length ? str2.charAt(charAt) : 0;
                    i12 = 19;
                }
                i4 = i12;
                if (i6 > i4) {
                    i4 = str2.charAt(i5);
                    j6 = 0;
                    while (true) {
                        charAt5 = i5;
                        if (i5 != i11 && Long.compare(j6 ^ Long.MIN_VALUE, -8223372036854775808L) < 0) {
                            j6 = (j6 * 10) + ((long) (i4 - 48));
                            i5 = charAt5 + 1;
                            i4 = i5 < length ? str2.charAt(i5) : 0;
                        }
                    }
                    if (Long.compare(j6 ^ Long.MIN_VALUE, -8223372036854775808L) >= 0) {
                        i9 = (i11 - charAt5) + i14;
                    } else {
                        i4 = str2.charAt(i8);
                        i11 = i8;
                        while (i11 != i7 && Long.compare(j6 ^ Long.MIN_VALUE, -8223372036854775808L) < 0) {
                            j6 = (j6 * 10) + ((long) (i4 - 48));
                            i11++;
                            i4 = i11 < length ? str2.charAt(i11) : 0;
                        }
                        i9 = (i8 - i11) + i14;
                    }
                    j8 = j6;
                    obj3 = obj;
                    if (-10 > i9 && i9 < 11 && obj3 == null && Long.compare(j8 ^ Long.MIN_VALUE, -9223372036837998592L) <= 0) {
                        float f2 = (float) j8;
                        float[] fArr = h;
                        f2 = i9 < 0 ? f2 / fArr[-i9] : f2 * fArr[i9];
                        if (obj2 != null) {
                            f2 = -f2;
                        }
                        j9 = ((long) i13) << j4;
                        i3 = Float.floatToRawIntBits(f2);
                    } else if (j8 != 0) {
                        j9 = ((long) i13) << j4;
                        i3 = Float.floatToRawIntBits(obj2 != null ? -0.0f : 0.0f);
                    } else if (-126 > i9 || i9 >= 128) {
                        j9 = ((long) i13) << j4;
                        i3 = Float.floatToRawIntBits(Float.parseFloat(str2.substring(i3, i13)));
                    } else {
                        long j10 = i[i9 + 325];
                        i4 = Long.numberOfLeadingZeros(j8);
                        j8 <<= i4;
                        long j11 = j8 & j3;
                        j8 >>>= j4;
                        long j12 = j10 & j3;
                        long j13 = j10 >>> j4;
                        long j14 = j8 * j13;
                        j13 *= j11;
                        j14 = (j14 + ((((j8 * j12) + ((j11 * j12) >>> j4)) + (j13 & j3)) >>> j4)) + (j13 >>> j4);
                        i11 = (int) (j14 >>> 63);
                        j2 = j14 >>> (i11 + 9);
                        i4 += i11 ^ 1;
                        j11 = j14 & 511;
                        if (j11 != 511) {
                            if (j11 != 0 || (3 & j2) != 1) {
                                j8 = (j2 + 1) >>> obj;
                                if (j8 >= 9007199254740992L) {
                                    i4--;
                                    j8 = 4503599627370496L;
                                }
                                j8 &= -4503599627370497L;
                                charAt2 = (((((long) i9) * 217706) >> 16) + 1087) - ((long) i4);
                                if (charAt2 >= 1) {
                                    if (charAt2 <= 2046) {
                                        j = (charAt2 << 52) | j8;
                                        if (obj2 != null) {
                                            j5 = Long.MIN_VALUE;
                                        }
                                        j9 = ((long) i13) << j4;
                                        i3 = Float.floatToRawIntBits((float) Double.longBitsToDouble(j | j5));
                                    }
                                }
                                j9 = ((long) i13) << j4;
                                i3 = Float.floatToRawIntBits(Float.parseFloat(str2.substring(i3, i13)));
                            }
                        }
                        j9 = ((long) i13) << j4;
                        i3 = Float.floatToRawIntBits(Float.parseFloat(str2.substring(i3, i13)));
                    }
                    return j9 | (((long) i3) & j3);
                }
            }
            j8 = j6;
            obj3 = null;
            if (-10 > i9) {
            }
            if (j8 != 0) {
            }
            return j9 | (((long) i3) & j3);
        }
        floatToRawIntBits2 = ((long) floatToRawIntBits) & 4294967295L;
        return j | floatToRawIntBits2;
    }

    public static final Object N(ry ryVar, int i, i00 i00) {
        int i2;
        int i3;
        Object obj;
        li0 li0;
        if (!ryVar.e.r) {
            a5.b("visitAncestors called on an unattached node");
        }
        li0 li02 = ryVar.e.i;
        ba0 O = k70.O(ryVar);
        loop0:
        while (true) {
            i2 = 0;
            i3 = 1;
            obj = null;
            if (O == null) {
                li0 = null;
                break;
            }
            if ((O.J.f.h & 1024) != 0) {
                for (li02 = 
/*
Method generation error in method: a5.N(ry, int, i00):java.lang.Object, dex: 
jadx.core.utils.exceptions.CodegenException: Error generate insn: PHI: (r0_5 'li02' li0) = (r0_4 'li02' li0), (r0_11 'li02' li0) binds: {(r0_4 'li02' li0)=B:3:0x000b, (r0_11 'li02' li0)=B:117:0x0013} in method: a5.N(ry, int, i00):java.lang.Object, dex: 
	at jadx.core.codegen.InsnGen.makeInsn(Unknown Source:86)
	at jadx.core.codegen.RegionGen.makeLoop(Unknown Source:137)
	at jadx.core.codegen.RegionGen.makeRegion(Unknown Source:54)
	at jadx.core.codegen.RegionGen.makeSimpleRegion(Unknown Source:24)
	at jadx.core.codegen.RegionGen.makeRegion(Unknown Source:20)
	at jadx.core.codegen.RegionGen.makeRegionIndent(Unknown Source:3)
	at jadx.core.codegen.RegionGen.makeIf(Unknown Source:43)
	at jadx.core.codegen.RegionGen.makeRegion(Unknown Source:34)
	at jadx.core.codegen.RegionGen.makeSimpleRegion(Unknown Source:24)
	at jadx.core.codegen.RegionGen.makeRegion(Unknown Source:20)
	at jadx.core.codegen.RegionGen.makeSimpleRegion(Unknown Source:24)
	at jadx.core.codegen.RegionGen.makeRegion(Unknown Source:20)
	at jadx.core.codegen.RegionGen.makeSimpleRegion(Unknown Source:24)
	at jadx.core.codegen.RegionGen.makeRegion(Unknown Source:20)
	at jadx.core.codegen.RegionGen.makeRegionIndent(Unknown Source:3)
	at jadx.core.codegen.RegionGen.makeLoop(Unknown Source:100)
	at jadx.core.codegen.RegionGen.makeRegion(Unknown Source:54)
	at jadx.core.codegen.RegionGen.makeSimpleRegion(Unknown Source:24)
	at jadx.core.codegen.RegionGen.makeRegion(Unknown Source:20)
	at jadx.core.codegen.MethodGen.addInstructions(Unknown Source:40)
	at jadx.core.codegen.ClassGen.addMethod(Unknown Source:103)
	at jadx.core.codegen.ClassGen.addMethods(Unknown Source:51)
	at jadx.core.codegen.ClassGen.addClassBody(Unknown Source:22)
	at jadx.core.codegen.ClassGen.addClassCode(Unknown Source:24)
	at jadx.core.codegen.ClassGen.makeClass(Unknown Source:5)
	at jadx.core.codegen.CodeGen.visit(Unknown Source:13)
	at jadx.core.ProcessClass.process(Unknown Source:71)
	at jadx.api.JadxDecompiler.processClass(Unknown Source:4)
	at jadx.api.JavaClass.decompile(Unknown Source:19)
Caused by: jadx.core.utils.exceptions.CodegenException: PHI can be used only in fallback mode
	at jadx.core.codegen.InsnGen.fallbackOnlyInsn(Unknown Source:28)
	at jadx.core.codegen.InsnGen.makeInsnBody(Unknown Source:61)
	at jadx.core.codegen.InsnGen.makeInsn(Unknown Source:48)
	... 28 more

*/

    public static final Bundle j(zp0... zp0Arr) {
        Bundle h90 = new h90(zp0Arr.length);
        for (zp0 zp0 : zp0Arr) {
            String str = (String) zp0.e;
            Object obj = zp0.f;
            if (obj == null) {
                h90.putString(str, null);
            } else if (obj instanceof Boolean) {
                h90.putBoolean(str, ((Boolean) obj).booleanValue());
            } else if (obj instanceof Byte) {
                h90.putByte(str, ((Number) obj).byteValue());
            } else if (obj instanceof Character) {
                h90.putChar(str, ((Character) obj).charValue());
            } else if (obj instanceof Double) {
                h90.putDouble(str, ((Number) obj).doubleValue());
            } else if (obj instanceof Float) {
                h90.putFloat(str, ((Number) obj).floatValue());
            } else if (obj instanceof Integer) {
                h90.putInt(str, ((Number) obj).intValue());
            } else if (obj instanceof Long) {
                h90.putLong(str, ((Number) obj).longValue());
            } else if (obj instanceof Short) {
                h90.putShort(str, ((Number) obj).shortValue());
            } else if (obj instanceof Bundle) {
                h90.putBundle(str, (Bundle) obj);
            } else if (obj instanceof CharSequence) {
                h90.putCharSequence(str, (CharSequence) obj);
            } else if (obj instanceof Parcelable) {
                h90.putParcelable(str, (Parcelable) obj);
            } else if (obj instanceof boolean[]) {
                h90.putBooleanArray(str, (boolean[]) obj);
            } else if (obj instanceof byte[]) {
                h90.putByteArray(str, (byte[]) obj);
            } else if (obj instanceof char[]) {
                h90.putCharArray(str, (char[]) obj);
            } else if (obj instanceof double[]) {
                h90.putDoubleArray(str, (double[]) obj);
            } else if (obj instanceof float[]) {
                h90.putFloatArray(str, (float[]) obj);
            } else if (obj instanceof int[]) {
                h90.putIntArray(str, (int[]) obj);
            } else if (obj instanceof long[]) {
                h90.putLongArray(str, (long[]) obj);
            } else if (obj instanceof short[]) {
                h90.putShortArray(str, (short[]) obj);
            } else {
                String str2 = " for key \"";
                if (obj instanceof Object[]) {
                    Class componentType = obj.getClass().getComponentType();
                    componentType.getClass();
                    if (Parcelable.class.isAssignableFrom(componentType)) {
                        h90.putParcelableArray(str, (Parcelable[]) obj);
                    } else if (String.class.isAssignableFrom(componentType)) {
                        h90.putStringArray(str, (String[]) obj);
                    } else if (CharSequence.class.isAssignableFrom(componentType)) {
                        h90.putCharSequenceArray(str, (CharSequence[]) obj);
                    } else if (Serializable.class.isAssignableFrom(componentType)) {
                        h90.putSerializable(str, (Serializable) obj);
                    } else {
                        od.i("Illegal value array type ", componentType.getCanonicalName(), str2, str, 34);
                        return null;
                    }
                } else if (obj instanceof Serializable) {
                    h90.putSerializable(str, (Serializable) obj);
                } else if (obj instanceof IBinder) {
                    h90.putBinder(str, (IBinder) obj);
                } else if (obj instanceof Size) {
                    h90.putSize(str, (Size) obj);
                } else if (obj instanceof SizeF) {
                    h90.putSizeF(str, (SizeF) obj);
                } else {
                    od.i("Illegal value type ", obj.getClass().getCanonicalName(), str2, str, 34);
                    return null;
                }
            }
        }
        return h90;
    }

    public static up[] L(ByteArrayInputStream byteArrayInputStream, String str, int i) {
        InputStream inputStream = byteArrayInputStream;
        int i2 = i;
        int i3 = 0;
        if (inputStream.available() == 0) {
            return new up[0];
        }
        int i4;
        int K;
        int K2;
        up[] upVarArr = new up[i2];
        for (i4 = 0; i4 < i2; i4++) {
            K = (int) a5.K(inputStream, 2);
            K2 = (int) a5.K(inputStream, 2);
            long K3 = a5.K(inputStream, 4);
            String str2 = str;
            upVarArr[i4] = new up(str2, new String(a5.D(inputStream, K), StandardCharsets.UTF_8), a5.K(inputStream, 4), K2, (int) K3, (int) a5.K(inputStream, 4), new int[K2], new TreeMap());
        }
        i4 = 0;
        while (i4 < i2) {
            int i5;
            int i6;
            up upVar = upVarArr[i4];
            int available = inputStream.available();
            int i7 = upVar.f;
            int i8 = upVar.g;
            TreeMap treeMap = upVar.i;
            available -= i7;
            i7 = i3;
            while (inputStream.available() > available) {
                i7 += (int) a5.K(inputStream, 2);
                treeMap.put(Integer.valueOf(i7), Integer.valueOf(1));
                int K4 = (int) a5.K(inputStream, 2);
                while (K4 > 0) {
                    a5.K(inputStream, 2);
                    K2 = (int) a5.K(inputStream, 1);
                    if (K2 != 6) {
                        if (K2 != 7) {
                            while (K2 > 0) {
                                a5.K(inputStream, 1);
                                i5 = i3;
                                i6 = i4;
                                for (i3 = (int) a5.K(inputStream, 1); i3 > 0; i3--) {
                                    a5.K(inputStream, 2);
                                }
                                K2--;
                                i3 = i5;
                                i4 = i6;
                            }
                        }
                    }
                    K4--;
                    i3 = i3;
                    i4 = i4;
                }
            }
            i5 = i3;
            i6 = i4;
            if (inputStream.available() == available) {
                upVar.h = a5.E(inputStream, upVar.e);
                BitSet valueOf = BitSet.valueOf(a5.D(inputStream, (((i8 * 2) + 7) & -8) / 8));
                for (i4 = i5; i4 < i8; i4++) {
                    K = valueOf.get(i4) != null ? 2 : i5;
                    if (valueOf.get(i4 + i8) != null) {
                        K |= 4;
                    }
                    if (K != 0) {
                        Integer num = (Integer) treeMap.get(Integer.valueOf(i4));
                        if (num == null) {
                            num = Integer.valueOf(i5);
                        }
                        treeMap.put(Integer.valueOf(i4), Integer.valueOf(K | num.intValue()));
                    }
                }
                i4 = i6 + 1;
                i3 = i5;
            } else {
                od.p("Read too much data during profile line parse");
                return null;
            }
        }
        return upVarArr;
    }

    /* JADX WARNING: Removed duplicated region for block: B:34:0x0088  */
    /* JADX WARNING: Removed duplicated region for block: B:30:0x0071  */
    /* JADX WARNING: Removed duplicated region for block: B:34:0x0088  */
    /* JADX WARNING: Removed duplicated region for block: B:27:0x0065  */
    /* JADX WARNING: Removed duplicated region for block: B:20:0x0049  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0023  */
    /* JADX WARNING: Removed duplicated region for block: B:26:0x0064  */
    /* JADX WARNING: Removed duplicated region for block: B:27:0x0065  */
    /* JADX WARNING: Missing block: B:31:0x0083, code:
            if (r1.k(r10, r0) == r5) goto L_0x0085;
     */
    /* JADX WARNING: Missing block: B:40:0x0090, code:
            if (r9 != false) goto L_0x0092;
     */
    /* JADX WARNING: Missing block: B:42:0x0094, code:
            if ((r7 instanceof java.util.concurrent.CancellationException) != false) goto L_0x0096;
     */
    /* JADX WARNING: Missing block: B:43:0x0096, code:
            r2 = (java.util.concurrent.CancellationException) r7;
     */
    /* JADX WARNING: Missing block: B:44:0x0099, code:
            if (r2 == null) goto L_0x009b;
     */
    /* JADX WARNING: Missing block: B:45:0x009b, code:
            r2 = new defpackage.dl1("Channel was consumed, consumer had failed");
            r2.initCause(r7);
     */
    /* JADX WARNING: Missing block: B:46:0x00a5, code:
            r8.a(r2);
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final Object q(uw uwVar, ye yeVar, boolean z, nl nlVar) {
        vw vwVar;
        int i;
        Object obj;
        CancellationException cancellationException;
        cm cmVar;
        hd it;
        cm b;
        uw uwVar2;
        hd hdVar;
        if (nlVar instanceof vw) {
            vwVar = (vw) nlVar;
            i = vwVar.m;
            if ((i & Integer.MIN_VALUE) != 0) {
                vwVar.m = i - Integer.MIN_VALUE;
                obj = vwVar.l;
                i = vwVar.m;
                cancellationException = null;
                cmVar = cm.e;
                if (i != 0) {
                    nb0.t(obj);
                    if (uwVar instanceof dc1) {
                        throw ((dc1) uwVar).e;
                    }
                    it = yeVar.iterator();
                    vwVar.h = uwVar;
                    vwVar.i = yeVar;
                    vwVar.j = it;
                    vwVar.k = z;
                    vwVar.m = 1;
                    b = it.b(vwVar);
                    if (b != cmVar) {
                        cm cmVar2 = b;
                        uwVar2 = uwVar;
                        hdVar = it;
                        obj = cmVar2;
                        if (!((Boolean) obj).booleanValue()) {
                            if (z) {
                            }
                        }
                        if (z) {
                        }
                        return we1.a;
                    }
                    return cmVar;
                } else if (i == 1) {
                    z = vwVar.k;
                    hdVar = vwVar.j;
                    yeVar = vwVar.i;
                    uwVar2 = vwVar.h;
                    nb0.t(obj);
                    if (!((Boolean) obj).booleanValue()) {
                        obj = hdVar.c();
                        vwVar.h = uwVar2;
                        vwVar.i = yeVar;
                        vwVar.j = hdVar;
                        vwVar.k = z;
                        vwVar.m = 2;
                    }
                    if (z) {
                        yeVar.a(null);
                    }
                    return we1.a;
                } else if (i == 2) {
                    z = vwVar.k;
                    hdVar = vwVar.j;
                    yeVar = vwVar.i;
                    uwVar2 = vwVar.h;
                    nb0.t(obj);
                } else {
                    od.p("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                it = hdVar;
                uwVar = uwVar2;
                vwVar.h = uwVar;
                vwVar.i = yeVar;
                vwVar.j = it;
                vwVar.k = z;
                vwVar.m = 1;
                b = it.b(vwVar);
                if (b != cmVar) {
                }
                return cmVar;
            }
        }
        vwVar = new db(nlVar);
        obj = vwVar.l;
        i = vwVar.m;
        cancellationException = null;
        cmVar = cm.e;
        if (i != 0) {
        }
        it = hdVar;
        uwVar = uwVar2;
        vwVar.h = uwVar;
        vwVar.i = yeVar;
        vwVar.j = it;
        vwVar.k = z;
        vwVar.m = 1;
        b = it.b(vwVar);
        if (b != cmVar) {
        }
        return cmVar;
    }

    public static byte[] o(up[] upVarArr, byte[] bArr) {
        up upVar;
        int length = upVarArr.length;
        int i = 0;
        int i2 = 0;
        int i3 = i2;
        while (i2 < length) {
            upVar = upVarArr[i2];
            i3 += ((((upVar.g * 2) + 7) & -8) / 8) + (((upVar.e * 2) + (a5.s(bArr, upVar.a, upVar.b).getBytes(StandardCharsets.UTF_8).length + 16)) + upVar.f);
            i2++;
        }
        ByteArrayOutputStream h90 = new h90(i3);
        if (Arrays.equals(bArr, ac.v)) {
            i2 = upVarArr.length;
            while (i < i2) {
                upVar = upVarArr[i];
                a5.R(h90, upVar, a5.s(bArr, upVar.a, upVar.b));
                a5.Q(h90, upVar);
                i++;
            }
        } else {
            for (up upVar2 : upVarArr) {
                a5.R(h90, upVar2, a5.s(bArr, upVar2.a, upVar2.b));
            }
            int length2 = upVarArr.length;
            while (i < length2) {
                a5.Q(h90, upVarArr[i]);
                i++;
            }
        }
        if (h90.size() == i3) {
            return h90.toByteArray();
        }
        int size = h90.size();
        StringBuilder dl1 = new dl1("The bytes saved do not match expectation. actual=");
        dl1.append(size);
        dl1.append(" expected=");
        dl1.append(i3);
        throw new dl1(dl1.toString());
    }

    public static up[] G(FileInputStream fileInputStream, byte[] bArr, byte[] bArr2, up[] upVarArr) {
        byte[] bArr3 = ac.y;
        String str = "Unsupported meta version";
        String str2 = "Content found after the end of file";
        int K;
        ByteArrayInputStream byteArrayInputStream;
        up[] H;
        if (Arrays.equals(bArr, bArr3)) {
            if (Arrays.equals(ac.t, bArr2)) {
                od.p("Requires new Baseline Profile Metadata. Please rebuild the APK with Android Gradle Plugin 7.2 Canary 7 or higher");
                return null;
            } else if (Arrays.equals(bArr, bArr3)) {
                K = (int) a5.K(fileInputStream, 1);
                bArr2 = a5.F(fileInputStream, (int) a5.K(fileInputStream, 4), (int) a5.K(fileInputStream, 4));
                if (fileInputStream.read() <= 0) {
                    byteArrayInputStream = new ByteArrayInputStream(bArr2);
                    try {
                        H = a5.H(byteArrayInputStream, K, upVarArr);
                        byteArrayInputStream.close();
                        return H;
                    } catch (Throwable th) {
                        th.addSuppressed(th);
                    }
                } else {
                    od.p(str2);
                    return null;
                }
            } else {
                od.p(str);
                return null;
            }
        } else if (Arrays.equals(bArr, ac.z)) {
            K = (int) a5.K(fileInputStream, 2);
            bArr3 = a5.F(fileInputStream, (int) a5.K(fileInputStream, 4), (int) a5.K(fileInputStream, 4));
            if (fileInputStream.read() <= 0) {
                byteArrayInputStream = new ByteArrayInputStream(bArr3);
                try {
                    H = a5.I(byteArrayInputStream, bArr2, K, upVarArr);
                    byteArrayInputStream.close();
                    return H;
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
            } else {
                od.p(str2);
                return null;
            }
        } else {
            od.p(str);
            return null;
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:24:0x0069  */
    /* JADX WARNING: Removed duplicated region for block: B:37:0x0092  */
    /* JADX WARNING: Removed duplicated region for block: B:35:0x008f  */
    /* JADX WARNING: Removed duplicated region for block: B:17:0x0041  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0023  */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x0069  */
    /* JADX WARNING: Removed duplicated region for block: B:35:0x008f  */
    /* JADX WARNING: Removed duplicated region for block: B:37:0x0092  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final Object f(List list, zm zmVar, nl nlVar) {
        rm rmVar;
        int i;
        Object obj;
        Object obj2;
        a91 a91;
        Iterator it;
        Serializable serializable;
        Throwable th;
        if (nlVar instanceof rm) {
            rmVar = (rm) nlVar;
            i = rmVar.k;
            if ((i & Integer.MIN_VALUE) != 0) {
                rmVar.k = i - Integer.MIN_VALUE;
                obj = rmVar.j;
                i = rmVar.k;
                obj2 = cm.e;
                if (i != 0) {
                    nb0.t(obj);
                    ArrayList arrayList = new ArrayList();
                    tm tmVar = new tm(list, arrayList, null);
                    rmVar.h = arrayList;
                    rmVar.k = 1;
                    if (zmVar.a(tmVar, rmVar) == obj2) {
                        return obj2;
                    }
                    a91 = arrayList;
                } else if (i == 1) {
                    a91 = (List) rmVar.h;
                    nb0.t(obj);
                } else if (i == 2) {
                    it = rmVar.i;
                    serializable = (nw0) rmVar.h;
                    try {
                        nb0.t(obj);
                    } catch (Throwable th2) {
                        Object obj3 = serializable.e;
                        if (obj3 == null) {
                            serializable.e = th2;
                        } else {
                            ac.i((Throwable) obj3, th2);
                        }
                    }
                    while (it.hasNext()) {
                        i00 i00 = (i00) it.next();
                        rmVar.h = serializable;
                        rmVar.i = it;
                        rmVar.k = 2;
                        if (i00.i(rmVar) == obj2) {
                            break;
                        }
                    }
                    th = (Throwable) serializable.e;
                    if (th == null) {
                        obj2 = we1.a;
                        return obj2;
                    }
                    throw th;
                } else {
                    od.p("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                serializable = new Object();
                it = a91.iterator();
                while (it.hasNext()) {
                }
                th = (Throwable) serializable.e;
                if (th == null) {
                }
            }
        }
        rmVar = new db(nlVar);
        obj = rmVar.j;
        i = rmVar.k;
        obj2 = cm.e;
        if (i != 0) {
        }
        serializable = new Object();
        it = a91.iterator();
        while (it.hasNext()) {
        }
        th = (Throwable) serializable.e;
        if (th == null) {
        }
    }

    public static byte[] F(FileInputStream fileInputStream, int i, int i2) {
        Inflater inflater = new Inflater();
        try {
            StringBuilder stringBuilder;
            byte[] bArr = new byte[i2];
            byte[] bArr2 = new byte[2048];
            int i3 = 0;
            int i4 = i3;
            while (!inflater.finished() && !inflater.needsDictionary() && i3 < i) {
                int read = fileInputStream.read(bArr2);
                if (read >= 0) {
                    inflater.setInput(bArr2, 0, read);
                    try {
                        i4 += inflater.inflate(bArr, i4, i2 - i4);
                        i3 += read;
                    } catch (DataFormatException e) {
                        throw new dl1(e.getMessage());
                    }
                }
                stringBuilder = new StringBuilder();
                stringBuilder.append("Invalid zip data. Stream ended after $totalBytesRead bytes. Expected ");
                stringBuilder.append(i);
                stringBuilder.append(" bytes");
                throw new dl1(stringBuilder.toString());
            }
            if (i3 != i) {
                stringBuilder = new StringBuilder();
                stringBuilder.append("Didn't read enough bytes during decompression. expected=");
                stringBuilder.append(i);
                stringBuilder.append(" actual=");
                stringBuilder.append(i3);
                throw new dl1(stringBuilder.toString());
            } else if (inflater.finished()) {
                return bArr;
            } else {
                throw new dl1("Inflater did not finish");
            }
        } finally {
            inflater.end();
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:17:0x0034  */
    /* JADX WARNING: Removed duplicated region for block: B:9:0x001e  */
    /* JADX WARNING: Missing block: B:32:0x0066, code:
            if (java.util.Arrays.equals(r6, r0) != false) goto L_0x0068;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static String s(byte[] bArr, String str, String str2) {
        Object obj;
        byte[] bArr2 = ac.w;
        byte[] bArr3 = ac.x;
        String str3 = "!";
        String str4 = ":";
        if (!Arrays.equals(bArr, bArr3)) {
            if (!Arrays.equals(bArr, bArr2)) {
                obj = str3;
                if (str.length() > 0) {
                    if (str3.equals(obj)) {
                        return str2.replace(str4, str3);
                    }
                    if (str4.equals(obj)) {
                        return str2.replace(str3, str4);
                    }
                } else if (str2.equals("classes.dex")) {
                    return str;
                } else {
                    if (!str2.contains(str3)) {
                        if (!str2.contains(str4)) {
                            if (!str2.endsWith(".apk")) {
                                StringBuilder stringBuilder = new StringBuilder();
                                stringBuilder.append(str);
                                if (Arrays.equals(bArr, bArr3)) {
                                }
                                str3 = str4;
                                stringBuilder.append(str3);
                                stringBuilder.append(str2);
                                return stringBuilder.toString();
                            }
                        }
                    }
                    if (str3.equals(obj)) {
                        return str2.replace(str4, str3);
                    }
                    if (str4.equals(obj)) {
                        return str2.replace(str3, str4);
                    }
                }
                return str2;
            }
        }
        obj = str4;
        if (str.length() > 0) {
        }
        return str2;
    }

    public static up[] I(ByteArrayInputStream byteArrayInputStream, byte[] bArr, int i, up[] upVarArr) {
        if (byteArrayInputStream.available() == 0) {
            return new up[0];
        }
        if (i == upVarArr.length) {
            int i2 = 0;
            while (i2 < i) {
                up upVar;
                a5.K(byteArrayInputStream, 2);
                String str = new String(a5.D(byteArrayInputStream, (int) a5.K(byteArrayInputStream, 2)), StandardCharsets.UTF_8);
                long K = a5.K(byteArrayInputStream, 4);
                int K2 = (int) a5.K(byteArrayInputStream, 2);
                if (upVarArr.length > 0) {
                    int indexOf = str.indexOf("!");
                    if (indexOf < 0) {
                        indexOf = str.indexOf(":");
                    }
                    Object substring = indexOf > 0 ? str.substring(indexOf + 1) : str;
                    for (int i3 = 0; i3 < upVarArr.length; i3++) {
                        if (upVarArr[i3].b.equals(substring)) {
                            upVar = upVarArr[i3];
                            break;
                        }
                    }
                }
                upVar = null;
                if (upVar != null) {
                    upVar.d = K;
                    int[] E = a5.E(byteArrayInputStream, K2);
                    if (Arrays.equals(bArr, ac.x)) {
                        upVar.e = K2;
                        upVar.h = E;
                    }
                    i2++;
                } else {
                    od.p("Missing profile key: ".concat(str));
                    return null;
                }
            }
            return upVarArr;
        }
        od.p("Mismatched number of dex files found in metadata");
        return null;
    }

    /* JADX WARNING: Removed duplicated region for block: B:14:0x003e  */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x0054 A:{Catch:{ all -> 0x006d }} */
    /* JADX WARNING: Removed duplicated region for block: B:33:0x0078  */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x0084  */
    /* JADX WARNING: Removed duplicated region for block: B:14:0x003e  */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x0054 A:{Catch:{ all -> 0x006d }} */
    /* JADX WARNING: Removed duplicated region for block: B:33:0x0078  */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x0084  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final boolean P(Throwable th, xz xzVar) {
        Collection asList;
        int size;
        boolean z;
        int i;
        ej ejVar;
        th.getClass();
        Integer num = x70.a;
        Throwable th2 = null;
        if (num != null) {
            if (num.intValue() < 19) {
                Method method = os0.b;
                if (method != null) {
                    Object invoke = method.invoke(th, null);
                    if (invoke != null) {
                        asList = Arrays.asList((Throwable[]) invoke);
                        asList.getClass();
                        size = asList.size();
                        z = false;
                        for (i = 0; i < size; i++) {
                            if (((Throwable) asList.get(i)) instanceof vp) {
                                return false;
                            }
                        }
                        ejVar = (ej) xzVar.a();
                        if (ejVar != null) {
                            boolean z2 = ejVar.b;
                            List list = ejVar.a;
                            if (z2) {
                                int size2 = list.size();
                                for (i = 0; i < size2; i++) {
                                    ((gj) list.get(i)).getClass();
                                }
                            } else if (!list.isEmpty()) {
                                z = true;
                            }
                        }
                        if (z) {
                            ejVar.getClass();
                            th2 = new vp(ejVar);
                        }
                        if (th2 != null) {
                            ac.i(th, th2);
                        }
                        return z;
                    }
                }
                asList = ut.e;
                size = asList.size();
                z = false;
                while (i < size) {
                }
                ejVar = (ej) xzVar.a();
                if (ejVar != null) {
                }
                if (z) {
                }
                if (th2 != null) {
                }
                return z;
            }
        }
        Throwable[] suppressed = th.getSuppressed();
        suppressed.getClass();
        asList = Arrays.asList(suppressed);
        asList.getClass();
        size = asList.size();
        z = false;
        while (i < size) {
        }
        try {
            ejVar = (ej) xzVar.a();
            if (ejVar != null) {
            }
            if (z) {
            }
        } catch (Throwable th3) {
            th2 = th3;
        }
        if (th2 != null) {
        }
        return z;
    }

    public static final void C(float[] fArr, float[] fArr2) {
        float[] fArr3 = fArr;
        float[] fArr4 = fArr2;
        float p = a5.p(fArr4, 0, fArr3, 0);
        float p2 = a5.p(fArr4, 0, fArr3, 1);
        float p3 = a5.p(fArr4, 0, fArr3, 2);
        float p4 = a5.p(fArr4, 0, fArr3, 3);
        float p5 = a5.p(fArr4, 1, fArr3, 0);
        float p6 = a5.p(fArr4, 1, fArr3, 1);
        float p7 = a5.p(fArr4, 1, fArr3, 2);
        float p8 = a5.p(fArr4, 1, fArr3, 3);
        float p9 = a5.p(fArr4, 2, fArr3, 0);
        float p10 = a5.p(fArr4, 2, fArr3, 1);
        float p11 = a5.p(fArr4, 2, fArr3, 2);
        float p12 = a5.p(fArr4, 2, fArr3, 3);
        float p13 = a5.p(fArr4, 3, fArr3, 0);
        float p14 = a5.p(fArr4, 3, fArr3, 1);
        float p15 = a5.p(fArr4, 3, fArr3, 2);
        float p16 = a5.p(fArr4, 3, fArr3, 3);
        fArr3[0] = p;
        fArr3[1] = p2;
        fArr3[2] = p3;
        fArr3[3] = p4;
        fArr3[4] = p5;
        fArr3[5] = p6;
        fArr3[6] = p7;
        fArr3[7] = p8;
        fArr3[8] = p9;
        fArr3[9] = p10;
        fArr3[10] = p11;
        fArr3[11] = p12;
        fArr3[12] = p13;
        fArr3[13] = p14;
        fArr3[14] = p15;
        fArr3[15] = p16;
    }

    /* JADX WARNING: Removed duplicated region for block: B:21:0x0068  */
    /* JADX WARNING: Removed duplicated region for block: B:12:0x0034  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0020  */
    /* JADX WARNING: Removed duplicated region for block: B:18:0x005c A:{RETURN} */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x0068  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final Object h(x91 x91, at0 at0, db dbVar) {
        sz szVar;
        int i;
        Object obj;
        List list;
        int i2;
        cm cmVar;
        if (dbVar instanceof sz) {
            szVar = (sz) dbVar;
            i = szVar.k;
            if ((i & Integer.MIN_VALUE) != 0) {
                szVar.k = i - Integer.MIN_VALUE;
                obj = szVar.j;
                i = szVar.k;
                if (i != 0) {
                    nb0.t(obj);
                    list = x91.j.w.a;
                    i = list.size();
                    i2 = 0;
                    while (i2 < i) {
                        if (!((dt0) list.get(i2)).d) {
                            i2++;
                        }
                    }
                    return we1.a;
                } else if (i == 1) {
                    at0 at02 = szVar.i;
                    x91 x912 = szVar.h;
                    nb0.t(obj);
                    x91 x913 = x912;
                    at0 = at02;
                    x91 = x913;
                    list = ((zs0) obj).a;
                    i = list.size();
                    for (i2 = 0; i2 < i; i2++) {
                        if (((dt0) list.get(i2)).d) {
                        }
                    }
                    return we1.a;
                } else {
                    od.p("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                szVar.h = x91;
                szVar.i = at0;
                szVar.k = 1;
                obj = x91.c(at0, szVar);
                cmVar = cm.e;
                if (obj == cmVar) {
                    return cmVar;
                }
                list = ((zs0) obj).a;
                i = list.size();
                while (i2 < i) {
                }
                return we1.a;
            }
        }
        szVar = new db(dbVar);
        obj = szVar.j;
        i = szVar.k;
        if (i != 0) {
        }
        szVar.h = x91;
        szVar.i = at0;
        szVar.k = 1;
        obj = x91.c(at0, szVar);
        cmVar = cm.e;
        if (obj == cmVar) {
        }
        list = ((zs0) obj).a;
        i = list.size();
        while (i2 < i) {
        }
        return we1.a;
    }

    public static void Q(ByteArrayOutputStream byteArrayOutputStream, up upVar) {
        a5.T(byteArrayOutputStream, upVar);
        int i = upVar.g;
        int[] iArr = upVar.h;
        int length = iArr.length;
        int i2 = 0;
        int i3 = 0;
        while (i2 < length) {
            int i4 = iArr[i2];
            a5.V(byteArrayOutputStream, i4 - i3);
            i2++;
            i3 = i4;
        }
        byte[] bArr = new byte[((((i * 2) + 7) & -8) / 8)];
        for (Entry entry : upVar.i.entrySet()) {
            i2 = ((Integer) entry.getKey()).intValue();
            length = ((Integer) entry.getValue()).intValue();
            if ((length & 2) != 0) {
                i3 = i2 / 8;
                bArr[i3] = (byte) (bArr[i3] | (1 << (i2 % 8)));
            }
            if ((length & 4) != 0) {
                i2 += i;
                length = i2 / 8;
                bArr[length] = (byte) ((1 << (i2 % 8)) | bArr[length]);
            }
        }
        byteArrayOutputStream.write(bArr);
    }

    public static void S(ByteArrayOutputStream byteArrayOutputStream, int i, up upVar) {
        int i2 = upVar.g;
        byte[] bArr = new byte[((((Integer.bitCount(i & -2) * i2) + 7) & -8) / 8)];
        for (Entry entry : upVar.i.entrySet()) {
            int intValue = ((Integer) entry.getKey()).intValue();
            int intValue2 = ((Integer) entry.getValue()).intValue();
            int i3 = 0;
            for (int i4 = 1; i4 <= 4; i4 <<= 1) {
                if (i4 != 1) {
                    if ((i4 & i) != 0) {
                        if ((i4 & intValue2) == i4) {
                            int i5 = (i3 * i2) + intValue;
                            int i6 = i5 / 8;
                            bArr[i6] = (byte) ((1 << (i5 % 8)) | bArr[i6]);
                        }
                        i3++;
                    }
                }
            }
        }
        byteArrayOutputStream.write(bArr);
    }

    /* JADX WARNING: Removed duplicated region for block: B:12:0x0032  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x001f  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final Object g(y11 y11, long j, nl nlVar) {
        i11 i11;
        int i;
        Object obj;
        kw0 obj2;
        if (nlVar instanceof i11) {
            i11 = (i11) nlVar;
            i = i11.k;
            if ((i & Integer.MIN_VALUE) != 0) {
                i11.k = i - Integer.MIN_VALUE;
                obj = i11.j;
                i = i11.k;
                if (i != 0) {
                    nb0.t(obj);
                    obj2 = new Object();
                    y11 y112 = y11;
                    g gVar = new g(y112, j, obj2, null, 1);
                    i11.h = y112;
                    i11.i = obj2;
                    i11.k = 1;
                    cm f = y112.f(tk0.e, gVar, i11);
                    cm cmVar = cm.e;
                    if (f == cmVar) {
                        return cmVar;
                    }
                    y11 = y112;
                } else if (i == 1) {
                    kw0 kw0 = i11.i;
                    y11 y113 = i11.h;
                    nb0.t(obj);
                    obj2 = kw0;
                    y11 = y113;
                } else {
                    od.p("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                return new ad(y11.h(obj2.e));
            }
        }
        i11 = new db(nlVar);
        obj = i11.j;
        i = i11.k;
        if (i != 0) {
        }
        return new ad(y11.h(obj2.e));
    }

    public static up[] H(ByteArrayInputStream byteArrayInputStream, int i, up[] upVarArr) {
        int i2 = 0;
        if (byteArrayInputStream.available() == 0) {
            return new up[0];
        }
        if (i == upVarArr.length) {
            String[] strArr = new String[i];
            int[] iArr = new int[i];
            for (int i3 = 0; i3 < i; i3++) {
                int K = (int) a5.K(byteArrayInputStream, 2);
                iArr[i3] = (int) a5.K(byteArrayInputStream, 2);
                strArr[i3] = new String(a5.D(byteArrayInputStream, K), StandardCharsets.UTF_8);
            }
            while (i2 < i) {
                up upVar = upVarArr[i2];
                if (upVar.b.equals(strArr[i2])) {
                    int i4 = iArr[i2];
                    upVar.e = i4;
                    upVar.h = a5.E(byteArrayInputStream, i4);
                    i2++;
                } else {
                    od.p("Order of dexfiles in metadata did not match baseline");
                    return null;
                }
            }
            return upVarArr;
        }
        od.p("Mismatched number of dex files found in metadata");
        return null;
    }

    public static final void M(ne neVar, ml mlVar, boolean z) {
        Object obj = ne.k.get(neVar);
        AutofillManager$AutofillCallback f = ((AutofillManager$AutofillCallback) neVar);
        Object px0 = f != null ? new px0(f) : ((AutofillManager) neVar);
        if (z) {
            mlVar.getClass();
            gq gqVar = (gq) mlVar;
            nl nlVar = gqVar.i;
            Object obj2 = gqVar.k;
            sl e = nlVar.e();
            mt X = gh0.X(e, obj2);
            te1 P = X != gh0.m ? j70.P(nlVar, e, X) : null;
            try {
                ((AutofillValue) nlVar);
                if (P != null) {
                    if (!P.i0()) {
                        return;
                    }
                }
                gh0.O(e, X);
            } catch (Throwable th) {
                if (P == null || P.i0()) {
                    gh0.O(e, X);
                }
            }
        } else {
            ((AutofillValue) mlVar);
        }
    }

    public static final Object i(ht0 ht0, m00 m00, ml mlVar) {
        cm cmVar;
        we1 we1;
        tz tzVar = new tz(mlVar.e(), m00, null);
        y91 y91 = (y91) ht0;
        y91.getClass();
        ne neVar = new ne(1, ac.x(mlVar));
        neVar.t();
        x91 x91 = new x91(y91, neVar);
        synchronized (y91.y) {
            y91.x.b(x91);
            ml x = ac.x(ac.m(x91, x91, tzVar));
            cmVar = cm.e;
            bz0 dbVar = new db(x);
            we1 = we1.a;
            ((AutofillValue) dbVar);
        }
        neVar.v(new j3(24, x91));
        cm s = neVar.s();
        return s == cmVar ? s : we1;
    }

    public static final boolean k(Object obj) {
        if (obj instanceof r61) {
            r61 r61 = (r61) obj;
            if (r61.d() == e3.X || r61.d() == nq0.j || r61.d() == nq0.h) {
                obj = r61.getValue();
                if (obj != null) {
                    return a5.k(obj);
                }
            }
            return false;
        } else if ((obj instanceof u00) && (obj instanceof Serializable)) {
            return false;
        } else {
            int i = 0;
            while (i < 7) {
                if (!g[i].isInstance(obj)) {
                    i++;
                }
            }
            return false;
        }
        return true;
    }

    public static up[] J(FileInputStream fileInputStream, byte[] bArr, String str) {
        if (Arrays.equals(bArr, ac.u)) {
            int K = (int) a5.K(fileInputStream, 1);
            byte[] F = a5.F(fileInputStream, (int) a5.K(fileInputStream, 4), (int) a5.K(fileInputStream, 4));
            if (fileInputStream.read() <= 0) {
                ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(F);
                try {
                    up[] L = a5.L(byteArrayInputStream, str, K);
                    byteArrayInputStream.close();
                    return L;
                } catch (Throwable th) {
                    th.addSuppressed(th);
                }
            } else {
                od.p("Content found after the end of file");
                return null;
            }
        }
        od.p("Unsupported version");
        return null;
    }

    public static void T(ByteArrayOutputStream byteArrayOutputStream, up upVar) {
        int i = 0;
        for (Entry entry : upVar.i.entrySet()) {
            int intValue = ((Integer) entry.getKey()).intValue();
            if ((((Integer) entry.getValue()).intValue() & 1) != 0) {
                a5.V(byteArrayOutputStream, intValue - i);
                a5.V(byteArrayOutputStream, 0);
                i = intValue;
            }
        }
    }

    public static byte[] m(byte[] bArr) {
        Deflater h90 = new h90(1);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        try {
            DeflaterOutputStream deflaterOutputStream = new DeflaterOutputStream(byteArrayOutputStream, h90);
            try {
                deflaterOutputStream.write(bArr);
                deflaterOutputStream.close();
                return byteArrayOutputStream.toByteArray();
            } catch (Throwable th) {
                th.addSuppressed(th);
            }
        } finally {
            h90.end();
        }
    }

    public static void R(ByteArrayOutputStream byteArrayOutputStream, up upVar, String str) {
        Charset charset = StandardCharsets.UTF_8;
        a5.V(byteArrayOutputStream, str.getBytes(charset).length);
        a5.V(byteArrayOutputStream, upVar.e);
        a5.U(byteArrayOutputStream, (long) upVar.f, 4);
        a5.U(byteArrayOutputStream, upVar.c, 4);
        a5.U(byteArrayOutputStream, (long) upVar.g, 4);
        byteArrayOutputStream.write(str.getBytes(charset));
    }

    public static h6 c(int i, int i2, int i3) {
        Bitmap c;
        ay0 ay0 = jh.e;
        Config I = ac.I(i3);
        if (VERSION.SDK_INT >= 26) {
            c = Bitmap.createBitmap(null, i, i2, ac.I(i3), true, b9.a(ay0));
        } else {
            c = Bitmap.createBitmap(null, i, i2, I);
            c.setHasAlpha(true);
        }
        return new h6(c);
    }

    public static final int d(int i, qk0 qk0) {
        int i2 = qk0.g - 1;
        int i3 = 0;
        while (i3 < i2) {
            int i4 = ((i2 - i3) / 2) + i3;
            Object[] objArr = qk0.e;
            int i5 = ((f70) objArr[i4]).a;
            if (i5 != i) {
                if (i5 < i) {
                    i3 = i4 + 1;
                    if (i < ((f70) objArr[i3]).a) {
                    }
                } else {
                    i2 = i4 - 1;
                }
            }
            return i4;
        }
        return i3;
    }

    public static final float p(float[] fArr, int i, float[] fArr2, int i2) {
        i *= 4;
        return (fArr[i + 3] * fArr2[12 + i2]) + ((fArr[i + 2] * fArr2[8 + i2]) + ((fArr[i + 1] * fArr2[4 + i2]) + (fArr[i] * fArr2[i2])));
    }

    public static void l(int i) {
        if (2 > i || i >= 37) {
            StringBuilder H = fu0.H(i, "radix ", " was not in valid range ");
            H.append(new o60(2, 36, 1));
            throw new dl1(H.toString());
        }
    }

    public static final int t(pz pzVar, int i) {
        int i2 = k70.y(pzVar.e, pz.f.e) >= 0 ? 1 : 0;
        i = i == 1 ? 1 : 0;
        if (i != 0 && i2 != 0) {
            return 3;
        }
        if (i2 != 0) {
            return 1;
        }
        return i != 0 ? 2 : 0;
    }

    public static byte[] D(InputStream inputStream, int i) {
        byte[] bArr = new byte[i];
        int i2 = 0;
        while (i2 < i) {
            int read = inputStream.read(bArr, i2, i - i2);
            if (read >= 0) {
                i2 += read;
            } else {
                od.p(fu0.E("Not enough bytes to read: ", i));
                return null;
            }
        }
        return bArr;
    }

    public static final boolean e(View view, View view2) {
        if (!view2.equals(view)) {
            for (Object parent = view2.getParent(); parent != null; parent = parent.getParent()) {
                if (parent == view) {
                    return true;
                }
            }
        }
        return false;
    }

    public static void U(ByteArrayOutputStream byteArrayOutputStream, long j, int i) {
        byte[] bArr = new byte[i];
        for (int i2 = 0; i2 < i; i2++) {
            bArr[i2] = (byte) ((int) ((j >> (i2 * 8)) & 255));
        }
        byteArrayOutputStream.write(bArr);
    }

    public static long K(InputStream inputStream, int i) {
        byte[] D = a5.D(inputStream, i);
        long j = 0;
        for (int i2 = 0; i2 < i; i2++) {
            j += ((long) (D[i2] & 255)) << (i2 * 8);
        }
        return j;
    }

    public static final u8 n(u8 u8Var) {
        u8 c = u8Var.c();
        int b = c.b();
        for (int i = 0; i < b; i++) {
            c.e(u8Var.a(i), i);
        }
        return c;
    }

    public static int[] E(ByteArrayInputStream byteArrayInputStream, int i) {
        int[] iArr = new int[i];
        int i2 = 0;
        int i3 = 0;
        while (i2 < i) {
            i3 += (int) a5.K(byteArrayInputStream, 2);
            iArr[i2] = i3;
            i2++;
        }
        return iArr;
    }

    public static final String[] u(jl jlVar) {
        jlVar.getClass();
        return (String[]) ((j5) jlVar).b.toArray(new String[0]);
    }

    public static final void a(xz xzVar, pi piVar, mi0 mi0, m00 m00, m00 m002, m00 m003, y41 y41, long j, long j2, long j3, long j4, yp ypVar, d10 d10, int i) {
        mi0 mi02;
        long j5;
        yp ypVar2;
        long j6;
        long j7;
        y41 y412;
        long j8;
        d10 d102 = d10;
        d102.X(94478519);
        xz xzVar2 = xzVar;
        int i2 = (i | (((AutofillValue) d102) != null ? 4 : 2)) | 306209152;
        if (d102.O(i2 & 1, (306783379 & i2) != 306783378)) {
            mi0 mi03;
            y41 y413;
            long j9;
            long j10;
            long j11;
            long j12;
            yp ypVar3;
            d102.T();
            if ((i & 1) != 0) {
                if (!d102.y()) {
                    d102.R();
                    i2 &= -2143289345;
                    mi03 = mi0;
                    y413 = y41;
                    j9 = j;
                    j10 = j2;
                    j11 = j3;
                    j12 = j4;
                    ypVar3 = ypVar;
                    d102.q();
                    d3.c(xzVar2, piVar, mi03, m00, m002, m003, y413, j9, j10, j11, j12, ypVar3, d102, i2 & 2147483646, 3456);
                    mi02 = mi03;
                    j5 = j12;
                    ypVar2 = ypVar3;
                    j6 = j11;
                    j7 = j10;
                    y412 = y413;
                    j8 = j9;
                }
            }
            y41 a = d51.a(zi1.i, d102);
            long d = fh.d(zi1.h, d102);
            j9 = fh.d(zi1.n, d102);
            i2 &= -2143289345;
            j10 = fh.d(zi1.j, d102);
            j11 = fh.d(zi1.l, d102);
            yp h90 = new h90(7);
            y413 = a;
            mi03 = ji0.a;
            j12 = j11;
            j11 = j10;
            j10 = j9;
            j9 = d;
            ypVar3 = h90;
            d102.q();
            d3.c(xzVar2, piVar, mi03, m00, m002, m003, y413, j9, j10, j11, j12, ypVar3, d102, i2 & 2147483646, 3456);
            mi02 = mi03;
            j5 = j12;
            ypVar2 = ypVar3;
            j6 = j11;
            j7 = j10;
            y412 = y413;
            j8 = j9;
        } else {
            d10.R();
            mi02 = mi0;
            y412 = y41;
            j8 = j;
            j7 = j2;
            j6 = j3;
            j5 = j4;
            ypVar2 = ypVar;
        }
        xv0 r = d10.r();
        if (r != null) {
            r.d = new o3(xzVar, piVar, mi02, m00, m002, m003, y412, j8, j7, j6, j5, ypVar2, i);
        }
    }

    public static final void x(ds dsVar) {
        if (((li0) dsVar).e.r) {
            k70.M(dsVar, 1).F0();
        }
    }

    public static boolean y(char c) {
        if (!Character.isWhitespace(c)) {
            if (!Character.isSpaceChar(c)) {
                return false;
            }
        }
        return true;
    }

    public static final int v(KeyEvent keyEvent) {
        int action = keyEvent.getAction();
        if (action != 0) {
            return action != 1 ? 0 : 1;
        } else {
            return 2;
        }
    }

    public static final j5 b(String str) {
        Set singleton = Collections.singleton(str);
        singleton.getClass();
        return new j5(singleton);
    }

    public static final mi0 B(mi0 mi0, k7 k7Var) {
        return mi0.b(new ln0(k7Var));
    }

    public static final boolean r(long j, long j2) {
        return j == j2;
    }

    public static void V(ByteArrayOutputStream byteArrayOutputStream, int i) {
        a5.U(byteArrayOutputStream, (long) i, 2);
    }

    public static final mi0 z(n00 n00) {
        return new p90(n00);
    }

    /*  JADX ERROR: NullPointerException in pass: BlockSplitter
        java.lang.NullPointerException: Attempt to invoke virtual method 'boolean jadx.core.dex.attributes.AttrNode.contains(jadx.core.dex.attributes.AType)' on a null object reference
        	at jadx.core.dex.visitors.blocksmaker.BlockSplitter.connectExceptionHandlers(Unknown Source:64)
        	at jadx.core.dex.visitors.blocksmaker.BlockSplitter.setupConnections(Unknown Source:58)
        	at jadx.core.dex.visitors.blocksmaker.BlockSplitter.splitBasicBlocks(Unknown Source:22)
        	at jadx.core.dex.visitors.blocksmaker.BlockSplitter.visit(Unknown Source:13)
        	at jadx.core.dex.visitors.DepthTraversal.visit(Unknown Source:9)
        	at jadx.core.dex.visitors.DepthTraversal.visit(Unknown Source:41)
        	at jadx.core.ProcessClass.process(Unknown Source:54)
        	at jadx.core.ProcessClass.processDependencies(Unknown Source:22)
        	at jadx.core.ProcessClass.process(Unknown Source:68)
        	at jadx.api.JadxDecompiler.processClass(Unknown Source:4)
        	at jadx.api.JavaClass.decompile(Unknown Source:19)
        */
    public static final defpackage.ig w(defpackage.fh1 r4) {
        /*
        r4.getClass();
        r0 = q;
        monitor-enter(r0);
        r1 = "androidx.lifecycle.viewmodel.internal.ViewModelCoroutineScope.JOB_KEY";	 Catch:{ all -> 0x002c }
        r1 = r4.c(r1);	 Catch:{ all -> 0x002c }
        r1 = (defpackage.ig) r1;	 Catch:{ all -> 0x002c }
        if (r1 != 0) goto L_0x002e;	 Catch:{ all -> 0x002c }
    L_0x0010:
        r1 = defpackage.st.e;	 Catch:{ all -> 0x002c }
        r2 = defpackage.kq.a;	 Catch:{ qm0 -> 0x0018, qm0 -> 0x0018 }
        r2 = defpackage.kg0.a;	 Catch:{ qm0 -> 0x0018, qm0 -> 0x0018 }
        r1 = r2.j;	 Catch:{ qm0 -> 0x0018, qm0 -> 0x0018 }
    L_0x0018:
        r2 = new ig;
        r3 = defpackage.ua0.e();
        r1 = r1.i(r3);
        r2.<init>(r1);
        r1 = "androidx.lifecycle.viewmodel.internal.ViewModelCoroutineScope.JOB_KEY";
        r4.a(r1, r2);
        r1 = r2;
        goto L_0x002e;
        r4 = move-exception;
        goto L_0x0030;
    L_0x002e:
        monitor-exit(r0);
        return r1;
    L_0x0030:
        monitor-exit(r0);
        throw r4;
        */
        throw new UnsupportedOperationException("Method not decompiled: a5.w(fh1):ig");
    }
}