package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ap */
public class ap implements jh1 {
    public static final ap b = new h90(0);
    public static ap c;
    public final /* synthetic */ int a;

    public final fh1 c(wf wfVar, pj0 pj0) {
        switch (this.a) {
            case 0:
                Class cls = wfVar.a;
                cls.getClass();
                return zi1.r(cls);
            case 1:
                return new tz0();
            default:
                Class cls2 = wfVar.a;
                cls2.getClass();
                return b(cls2, pj0);
        }
    }

    public fh1 a(Class cls) {
        String str = "`Factory.create(String, CreationExtras)` is not implemented. You may need to override the method and provide a custom implementation. Note that using `Factory.create(String)` is not supported and considered an error.";
        switch (this.a) {
            case 0:
                throw new dl1(str);
            case 1:
                throw new dl1(str);
            default:
                return zi1.r(cls);
        }
    }

    public fh1 b(Class cls, pj0 pj0) {
        switch (this.a) {
            case 0:
                a(cls);
                throw null;
            case 1:
                a(cls);
                throw null;
            default:
                return a(cls);
        }
    }

    public /* synthetic */ ap(int i) {
        this.a = i;
    }
}