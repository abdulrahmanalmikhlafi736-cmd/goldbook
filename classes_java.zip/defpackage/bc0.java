package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bc0 */
public final /* synthetic */ class bc0 implements xz {
    public final /* synthetic */ int e;
    public final /* synthetic */ dc0 f;

    public final Object a() {
        int i = this.e;
        dc0 dc0 = this.f;
        sc0 sc0;
        switch (i) {
            case 0:
                sc0 = dc0.t.b;
                return Float.valueOf((float) ((((iq0) sc0.e.b).g() * 500) + ((iq0) sc0.e.c).g()));
            case 1:
                sc0 = dc0.t.b;
                i = ((iq0) sc0.e.b).g();
                int g = ((iq0) sc0.e.c).g();
                return Float.valueOf(sc0.c() ? ((float) ((i * 500) + g)) + 100.0f : (float) ((i * 500) + g));
            default:
                sc0 sc02 = dc0.t.b;
                i = (int) (sc02.g().o == bp0.e ? sc02.g().g() & 4294967295L : sc02.g().g() >> 32);
                sc0 = dc0.t.b;
                return Float.valueOf((float) (i - ((-sc0.g().l) + sc0.g().p)));
        }
    }

    public /* synthetic */ bc0(dc0 dc0, int i) {
        this.e = i;
        this.f = dc0;
    }
}