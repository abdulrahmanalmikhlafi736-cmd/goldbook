package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: c81 */
public final class c81 extends nl {
    public d81 h;
    public uw i;
    public e81 j;
    public a80 k;
    public Object l;
    public /* synthetic */ Object m;
    public final /* synthetic */ d81 n;
    public int o;

    public final Object p(Object obj) {
        this.m = obj;
        this.o |= Integer.MIN_VALUE;
        this.n.b(null, this);
        return cm.e;
    }

    public c81(d81 d81, ml mlVar) {
        this.n = d81;
        super(mlVar);
    }
}