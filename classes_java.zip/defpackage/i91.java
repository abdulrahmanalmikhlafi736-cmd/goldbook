package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: i91 */
public interface i91 {
    void f(h91 h91);

    boolean i(Object obj, Object obj2);
}