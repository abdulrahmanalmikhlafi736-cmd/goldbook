package defpackage;

import android.os.Trace;
import androidx.core.content.FileProvider;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bw0 */
public final /* synthetic */ class bw0 implements i00 {
    public final /* synthetic */ dw0 e;
    public final /* synthetic */ ik0 f;
    public final /* synthetic */ ik0 g;
    public final /* synthetic */ List h;
    public final /* synthetic */ List i;
    public final /* synthetic */ ik0 j;
    public final /* synthetic */ List k;
    public final /* synthetic */ ik0 l;
    public final /* synthetic */ Set m;

    /* JADX WARNING: Missing block: B:82:0x0141, code:
            if (r2 == 8) goto L_0x0143;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final Object i(Object obj) {
        Throwable th;
        dw0 dw0 = this.e;
        ik0 ik0 = this.f;
        ik0 ik02 = this.g;
        List list = this.h;
        List list2 = this.i;
        ik0 ik03 = this.j;
        List list3 = this.k;
        ik0 ik04 = this.l;
        Set set = this.m;
        long longValue = ((Long) obj).longValue();
        if (dw0.y(dw0)) {
            Trace.beginSection("Recomposer:animation");
            try {
                ((pa) dw0.a.g).f(new ad(longValue));
                kb0.A();
                Trace.endSection();
            } catch (Throwable th2) {
                Trace.endSection();
                throw th2;
            }
        }
        Trace.beginSection("Recomposer:recompose");
        try {
            qk0 qk0;
            int i;
            boolean z;
            int i2;
            int size;
            int i3;
            dw0.Q();
            synchronized (dw0.c) {
                try {
                    qk0 = dw0.i;
                    Object[] objArr = qk0.e;
                    i = qk0.g;
                    z = false;
                    for (i2 = 0; i2 < i; i2++) {
                        list.add((yj) objArr[i2]);
                    }
                    dw0.i.g();
                } catch (Throwable th22) {
                    throw th22;
                }
            }
            ik0.b();
            ik02.b();
            while (true) {
                if (list.isEmpty()) {
                    if (list2.isEmpty()) {
                        break;
                    }
                }
                try {
                    int size2 = list.size();
                    for (i = 0; i < size2; i++) {
                        yj yjVar = (yj) list.get(i);
                        yj O = dw0.O(yjVar, ik0);
                        if (O != null) {
                            list3.add(O);
                        }
                        ik02.a(yjVar);
                    }
                    list.clear();
                    if (ik0.h() || dw0.i.g != 0) {
                        synchronized (dw0.c) {
                            try {
                                Object[] objArr2;
                                List I = dw0.I();
                                size = I.size();
                                for (i3 = 0; i3 < size; i3++) {
                                    yj yjVar2 = (yj) I.get(i3);
                                    if (ik02.c(yjVar2) == null && yjVar2.v(set)) {
                                        list.add(yjVar2);
                                    }
                                }
                                qk0 = dw0.i;
                                size = qk0.g;
                                i3 = 0;
                                i2 = 0;
                                while (true) {
                                    objArr2 = qk0.e;
                                    if (i3 >= size) {
                                        break;
                                    }
                                    yj yjVar3 = (yj) objArr2[i3];
                                    if (ik02.c(yjVar3) == null && !list.contains(yjVar3)) {
                                        list.add(yjVar3);
                                        i2++;
                                    } else if (i2 > 0) {
                                        objArr2 = qk0.e;
                                        objArr2[i3 - i2] = objArr2[i3];
                                    }
                                    i3++;
                                }
                                i3 = size - i2;
                                Arrays.fill(objArr2, i3, size, null);
                                qk0.g = i3;
                            } catch (Throwable th222) {
                                throw th222;
                            }
                        }
                    }
                    if (list.isEmpty()) {
                        try {
                            cw0.s(list2, dw0);
                            while (!list2.isEmpty()) {
                                List<Object> N = dw0.N(list2, ik0);
                                ik03.getClass();
                                for (Object k : N) {
                                    ik03.k(k);
                                }
                                cw0.s(list2, dw0);
                            }
                        } catch (Throwable th2222) {
                            dw0.P(th2222, null);
                            cw0.r(dw0, list, list2, list3, ik03, ik04, ik0, ik02);
                        }
                    }
                    z = false;
                } catch (Throwable th22222) {
                    list.clear();
                    throw th22222;
                }
            }
            g61 j = n61.j();
            g61 hd1 = j instanceof lk0 ? new hd1((lk0) j, null, null, true, false) : new id1(j, null, true, z);
            try {
                g61 j2 = hd1.j();
                try {
                    Object[] objArr3;
                    long j3;
                    List list4;
                    List list5;
                    int i4;
                    int i5;
                    if (!list3.isEmpty()) {
                        try {
                            int size3 = list3.size();
                            for (size = z; size < size3; size++) {
                                ik04.a((yj) list3.get(size));
                            }
                            size3 = list3.size();
                            for (size = z; size < size3; size++) {
                                ((yj) list3.get(size)).d();
                            }
                            list3.clear();
                        } catch (Throwable th222222) {
                            list3.clear();
                            throw th222222;
                        }
                    }
                    if (ik03.h()) {
                        try {
                            ik04.j(ik03);
                            objArr3 = ik03.b;
                            long[] jArr = ik03.a;
                            j3 = 128;
                            int length = jArr.length - 2;
                            if (length >= 0) {
                                int i6 = 0;
                                while (true) {
                                    long j4 = jArr[i6];
                                    list4 = list;
                                    list5 = list2;
                                    if (((((~j4) << 7) & j4) & -9187201950435737472L) != -9187201950435737472L) {
                                        i4 = 8 - ((~(i6 - length)) >>> 31);
                                        for (i5 = 0; i5 < i4; i5++) {
                                            if ((j4 & 255) < 128) {
                                                try {
                                                    ((yj) objArr3[(i6 << 3) + i5]).f();
                                                } catch (Throwable th3) {
                                                    th222222 = th3;
                                                }
                                            }
                                            j4 >>= 8;
                                        }
                                    }
                                    if (i6 != length) {
                                        i6++;
                                        list = list4;
                                        list2 = list5;
                                    }
                                }
                            } else {
                                list4 = list;
                                list5 = list2;
                            }
                            ik03.b();
                            list = list4;
                            list2 = list5;
                            break;
                        } catch (Throwable th4) {
                            th222222 = th4;
                            list4 = list;
                            list5 = list2;
                            try {
                                dw0.P(th222222, null);
                                cw0.r(dw0, list4, list5, list3, ik03, ik04, ik0, ik02);
                                ik03.b();
                                g61.q(j2);
                                hd1.c();
                                Trace.endSection();
                                return we1.a;
                            } catch (Throwable th2222222) {
                                ik03.b();
                                throw th2222222;
                            }
                        }
                    }
                    j3 = 128;
                    if (ik04.h()) {
                        try {
                            objArr3 = ik04.b;
                            long[] jArr2 = ik04.a;
                            size = jArr2.length - 2;
                            if (size >= 0) {
                                i3 = 0;
                                while (true) {
                                    Object[] objArr4;
                                    long j5 = jArr2[i3];
                                    list4 = list;
                                    list5 = list2;
                                    if (((((~j5) << 7) & j5) & -9187201950435737472L) != -9187201950435737472L) {
                                        i4 = 8 - ((~(i3 - size)) >>> 31);
                                        i5 = 0;
                                        while (i5 < i4) {
                                            if ((j5 & 255) < j3) {
                                                try {
                                                    ((yj) objArr3[(i3 << 3) + i5]).g();
                                                } catch (Throwable th5) {
                                                    th2222222 = th5;
                                                    try {
                                                        dw0.P(th2222222, null);
                                                        cw0.r(dw0, list4, list5, list3, ik03, ik04, ik0, ik02);
                                                        ik04.b();
                                                        g61.q(j2);
                                                        hd1.c();
                                                        Trace.endSection();
                                                        return we1.a;
                                                    } catch (Throwable th22222222) {
                                                        ik04.b();
                                                        throw th22222222;
                                                    }
                                                }
                                            }
                                            j5 >>= 8;
                                            i5++;
                                            objArr3 = objArr3;
                                        }
                                        objArr4 = objArr3;
                                        if (i4 == 8) {
                                        }
                                    } else {
                                        objArr4 = objArr3;
                                    }
                                    if (i3 != size) {
                                        i3++;
                                        list = list4;
                                        list2 = list5;
                                        objArr3 = objArr4;
                                    }
                                }
                            }
                            ik04.b();
                            break;
                        } catch (Throwable th6) {
                            th22222222 = th6;
                            list4 = list;
                            list5 = list2;
                            dw0.P(th22222222, null);
                            cw0.r(dw0, list4, list5, list3, ik03, ik04, ik0, ik02);
                            ik04.b();
                            g61.q(j2);
                            hd1.c();
                            Trace.endSection();
                            return we1.a;
                        }
                    }
                    g61.q(j2);
                    hd1.c();
                    synchronized (dw0.c) {
                        try {
                            if (dw0.D() != null) {
                                FileProvider.a("unexpected to get continuation here");
                            }
                        } catch (Throwable th222222222) {
                            throw th222222222;
                        }
                    }
                    n61.j().m();
                    ik02.b();
                    ik0.b();
                    dw0.q = null;
                    Trace.endSection();
                    return we1.a;
                } catch (Throwable th2222222222) {
                    g61.q(j2);
                    throw th2222222222;
                }
            } catch (Throwable th22222222222) {
                hd1.c();
                throw th22222222222;
            }
        } catch (Throwable th222222222222) {
            Trace.endSection();
            throw th222222222222;
        }
    }

    public /* synthetic */ bw0(dw0 dw0, ik0 ik0, ik0 ik02, List list, List list2, ik0 ik03, List list3, ik0 ik04, Set set) {
        this.e = dw0;
        this.f = ik0;
        this.g = ik02;
        this.h = list;
        this.i = list2;
        this.j = ik03;
        this.k = list3;
        this.l = ik04;
        this.m = set;
    }
}