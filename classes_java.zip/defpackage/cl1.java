package defpackage;

import android.content.ContentResolver;
import android.content.Context;
import android.net.Uri;
import android.os.Looper;
import android.provider.Settings.Global;
import android.view.View;
import android.view.autofill.AutofillId;
import android.view.autofill.AutofillManager;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cl1 */
public abstract class cl1 {
    public static final hk0 a = new hk0();

    public static final b81 a(Context context) {
        b81 b81;
        hk0 hk0 = a;
        synchronized (hk0) {
            try {
                AutofillManager g = ((AutofillManager) hk0);
                if (g == null) {
                    ContentResolver contentResolver = context.getContentResolver();
                    Uri uriFor = Global.getUriFor("animator_duration_scale");
                    id b = wl1.b(-1, 6, null);
                    Context context2 = context;
                    cz0 cz0 = new cz0(0, new al1(contentResolver, uriFor, new bl1(b, vd1.j(Looper.getMainLooper())), b, context2, null));
                    l91 e = ua0.e();
                    uo uoVar = kq.a;
                    g = wl1.K(cz0, new ax0(vn.O(e, kg0.a)), new ad(Long.MAX_VALUE), Float.valueOf(Global.getFloat(context2.getContentResolver(), "animator_duration_scale", 1.0f)));
                    hk0.m(context2, g);
                }
                b81 = (b81) g;
            } catch (Throwable th) {
                Throwable th2 = th;
            }
        }
        return b81;
    }

    public static final AutofillId b(View view) {
        Object tag = view.getTag(2131034155);
        return tag instanceof sj ? (sj) tag : null;
    }

    static {
        long[] jArr = n01.a;
    }
}