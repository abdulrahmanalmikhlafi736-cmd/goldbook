package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ck0 */
public final class ck0 extends ox0 implements m00 {
    public m10 g;
    public dk0 h;
    public long[] i;
    public int j;
    public int k;
    public /* synthetic */ Object l;
    public final /* synthetic */ dk0 m;
    public final /* synthetic */ m10 n;

    public final Object p(Object obj) {
        Object obj2;
        dk0 dk0;
        long[] jArr;
        m10 m10;
        int i = this.k;
        if (i == 0) {
            nb0.t(obj);
            obj2 = (c31) this.l;
            dk0 = this.m;
            bk0 bk0 = dk0.f;
            jArr = bk0.c;
            i = bk0.e;
            m10 = this.n;
        } else if (i == 1) {
            i = this.j;
            jArr = this.i;
            dk0 = this.h;
            m10 = this.g;
            obj2 = (c31) this.l;
            nb0.t(obj);
        } else {
            od.p("call to 'resume' before 'invoke' with coroutine");
            return null;
        }
        if (i == Integer.MAX_VALUE) {
            return we1.a;
        }
        int i2 = (int) ((jArr[i] >> 31) & 2147483647L);
        m10.f = i;
        Object obj3 = dk0.f.b[i];
        this.l = obj2;
        this.g = m10;
        this.h = dk0;
        this.i = jArr;
        this.j = i2;
        this.k = 1;
        obj2.b(obj3, this);
        return cm.e;
    }

    public final Object f(Object obj, Object obj2) {
        return ((ck0) n((ml) obj2, (c31) obj)).p(we1.a);
    }

    public final ml n(ml mlVar, Object obj) {
        ck0 ck0 = new ck0(this.m, this.n, mlVar);
        ck0.l = obj;
        return ck0;
    }

    public ck0(dk0 dk0, m10 m10, ml mlVar) {
        this.m = dk0;
        this.n = m10;
        super(2, mlVar);
    }
}