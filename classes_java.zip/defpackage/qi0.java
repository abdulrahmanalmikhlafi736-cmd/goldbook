package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: qi0 */
public abstract class qi0 implements ki0 {
    public final boolean d(i00 i00) {
        return ((Boolean) i00.i(this)).booleanValue();
    }

    public final Object a(m00 m00, Object obj) {
        return m00.f(obj, this);
    }

    public final /* synthetic */ mi0 b(mi0 mi0) {
        return fu0.l(this, mi0);
    }

    public abstract li0 e();

    public abstract void f(li0 li0);
}