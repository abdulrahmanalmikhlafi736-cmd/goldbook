package defpackage;

import android.os.Looper;
import android.view.Choreographer;
import androidx.core.content.FileProvider;
import java.util.UUID;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: b5 */
public final class b5 extends h90 implements xz {
    public static final b5 A = new xo0(0, 20);
    public static final b5 B = new xo0(0, 21);
    public static final b5 C = new xo0(0, 22);
    public static final b5 D = new xo0(0, 23);
    public static final b5 E = new xo0(0, 24);
    public static final b5 F = new xo0(0, 25);
    public static final b5 G = new xo0(0, 26);
    public static final b5 H = new xo0(0, 27);
    public static final b5 I = new xo0(0, 28);
    public static final b5 J = new xo0(0, 29);
    public static final b5 g = new xo0(0, 0);
    public static final b5 h = new xo0(0, 1);
    public static final b5 i = new xo0(0, 2);
    public static final b5 j = new xo0(0, 3);
    public static final b5 k = new xo0(0, 4);
    public static final b5 l = new xo0(0, 5);
    public static final b5 m = new xo0(0, 6);
    public static final b5 n = new xo0(0, 7);
    public static final b5 o = new xo0(0, 8);
    public static final b5 p = new xo0(0, 9);
    public static final b5 q = new xo0(0, 10);
    public static final b5 r = new xo0(0, 11);
    public static final b5 s = new xo0(0, 12);
    public static final b5 t = new xo0(0, 13);
    public static final b5 u = new xo0(0, 14);
    public static final b5 v = new xo0(0, 15);
    public static final b5 w = new xo0(0, 16);
    public static final b5 x = new xo0(0, 17);
    public static final b5 y = new xo0(0, 18);
    public static final b5 z = new xo0(0, 19);
    public final /* synthetic */ int f;

    public final Object a() {
        int i = this.f;
        we1 we1 = we1.a;
        switch (i) {
            case 0:
                FileProvider.a("LocalConfiguration");
                throw null;
            case 1:
                FileProvider.a("LocalContext");
                throw null;
            case 2:
                FileProvider.a("LocalImageVectorCache");
                throw null;
            case 3:
                FileProvider.a("LocalResourceIdCache");
                throw null;
            case gu0.LONG_FIELD_NUMBER /*4*/:
                FileProvider.a("LocalView");
                throw null;
            case gu0.STRING_FIELD_NUMBER /*5*/:
                return UUID.randomUUID();
            case gu0.STRING_SET_FIELD_NUMBER /*6*/:
                return Boolean.FALSE;
            case gu0.DOUBLE_FIELD_NUMBER /*7*/:
                return "DEFAULT_TEST_TAG";
            case 8:
                Choreographer instance;
                if (Looper.myLooper() == Looper.getMainLooper()) {
                    instance = Choreographer.getInstance();
                } else {
                    uo uoVar = kq.a;
                    instance = (Choreographer) wl1.G(kg0.a, new a7(2, null, 0));
                }
                d7 d7Var = new d7(instance, vd1.j(Looper.getMainLooper()));
                return vn.O(d7Var, d7Var.p);
            case 9:
            case 10:
            case 11:
                return we1;
            case 12:
                return new h90(2);
            case 13:
            case 14:
                return null;
            case 15:
                a5.b("LocalAutofillManager");
                throw null;
            case 16:
                a5.b("LocalAutofillTree");
                throw null;
            case 17:
                a5.b("LocalClipboard");
                throw null;
            case 18:
                a5.b("LocalClipboardManager");
                throw null;
            case 19:
                return Boolean.TRUE;
            case 20:
                a5.b("LocalDensity");
                throw null;
            case 21:
                a5.b("LocalFocusManager");
                throw null;
            case 22:
                a5.b("LocalFontFamilyResolver");
                throw null;
            case 23:
                a5.b("LocalFontLoader");
                throw null;
            case 24:
                a5.b("LocalGraphicsContext");
                throw null;
            case 25:
                a5.b("LocalHapticFeedback");
                throw null;
            case 26:
                a5.b("LocalInputManager");
                throw null;
            case 27:
                a5.b("LocalLayoutDirection");
                throw null;
            case 28:
                return null;
            default:
                a5.b("LocalProvidableLocaleList");
                throw null;
        }
    }

    public /* synthetic */ b5(int i, int i2) {
        this.f = i2;
        super(i);
    }
}