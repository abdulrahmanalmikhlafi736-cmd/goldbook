package defpackage;

import android.os.Build.VERSION;
import android.os.Handler;
import android.os.Looper;
import com.almekhlafi.goldbook.MainActivity;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ai */
public final /* synthetic */ class ai implements xz {
    public final /* synthetic */ int e;
    public final /* synthetic */ MainActivity f;

    public final Object a() {
        int i = this.e;
        MainActivity mainActivity = this.f;
        switch (i) {
            case 0:
                mainActivity.reportFullyDrawn();
                return we1.a;
            case 1:
                return new wz(mainActivity.j, new ai(mainActivity, 0));
            case 2:
                cq obj = new Object();
                mainActivity.a().c(obj);
                return obj;
            case 3:
                return new yz0(mainActivity.getApplication(), mainActivity, mainActivity.getIntent() != null ? mainActivity.getIntent().getExtras() : null);
            case gu0.LONG_FIELD_NUMBER /*4*/:
                jn0 jn0 = new jn0(new o4(2, mainActivity));
                if (VERSION.SDK_INT >= 33) {
                    if (k70.p(Looper.myLooper(), Looper.getMainLooper())) {
                        mainActivity.e.a(new bi(jn0, mainActivity));
                    } else {
                        new Handler(Looper.getMainLooper()).post(new al(1, mainActivity, jn0));
                    }
                }
                return jn0;
            default:
                return k70.E(mainActivity);
        }
    }

    public /* synthetic */ ai(MainActivity mainActivity, int i) {
        this.e = i;
        this.f = mainActivity;
    }
}