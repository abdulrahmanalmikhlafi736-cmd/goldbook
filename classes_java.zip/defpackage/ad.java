package defpackage;

import android.view.autofill.AutofillValue;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ad */
public final /* synthetic */ class ad implements i00 {
    public final /* synthetic */ long e;

    public final Object i(Object obj) {
        long j = this.e;
        bd bdVar = (bd) obj;
        i00 i00 = bdVar.b;
        if (i00 != null) {
            ne neVar = bdVar.a;
            if (neVar != null) {
                Object i;
                try {
                    i = i00.i(Long.valueOf(j));
                } catch (Throwable th) {
                    i = new px0(th);
                }
                ((AutofillValue) neVar);
            }
        }
        return we1.a;
    }

    public /* synthetic */ ad(long j) {
        this.e = j;
    }
}