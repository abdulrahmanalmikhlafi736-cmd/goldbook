package com.almekhlafi.goldbook.stealth;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import defpackage.dl1;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
public final class SecretCodeReceiver extends BroadcastReceiver {
    public final void onReceive(Context context, Intent intent) {
        context.getClass();
        intent.getClass();
        try {
            Intent dl1 = new dl1("android.intent.action.MAIN");
            String packageName = context.getPackageName();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(packageName);
            stringBuilder.append(".MainActivity");
            dl1.setClassName(context, stringBuilder.toString());
            dl1.addFlags(268435456);
            context.startActivity(dl1);
        } catch (Throwable unused) {
        }
    }
}