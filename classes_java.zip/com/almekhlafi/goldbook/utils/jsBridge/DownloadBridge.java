package com.almekhlafi.goldbook.utils.jsBridge;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Environment;
import android.provider.MediaStore.Downloads;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.widget.Toast;
import defpackage.ak0;
import defpackage.mv;
import defpackage.px0;
import defpackage.q81;
import defpackage.sd1;
import defpackage.we1;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
public final class DownloadBridge {
    public static final int $stable = 8;
    private final Context context;

    /* JADX WARNING: Removed duplicated region for block: B:52:0x012f  */
    /* JADX WARNING: Removed duplicated region for block: B:34:0x00d0 A:{SYNTHETIC, Splitter: B:34:0x00d0} */
    /* JADX WARNING: Removed duplicated region for block: B:67:0x0165  */
    /* JADX WARNING: Removed duplicated region for block: B:34:0x00d0 A:{SYNTHETIC, Splitter: B:34:0x00d0} */
    /* JADX WARNING: Removed duplicated region for block: B:52:0x012f  */
    /* JADX WARNING: Removed duplicated region for block: B:67:0x0165  */
    /* JADX WARNING: Missing block: B:48:?, code:
            defpackage.gh0.t(r5, r9);
     */
    /* JADX WARNING: Missing block: B:62:?, code:
            defpackage.gh0.t(r10, r9);
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    @JavascriptInterface
    public final void downloadBase64File(String str, String str2) {
        String str3 = "is_pending";
        String str4 = ",";
        str.getClass();
        str2.getClass();
        Object obj;
        try {
            Context context;
            if (q81.z(str, str4)) {
                sd1 sd1;
                String str5;
                long currentTimeMillis;
                StringBuilder stringBuilder;
                int i;
                sd1 sd12;
                byte[] decode = Base64.decode((String) q81.H(str, new String[]{str4}).get(1), 0);
                boolean startsWith = str2.startsWith("image/");
                boolean startsWith2 = str2.startsWith("video/");
                String str6 = "bin";
                if (startsWith) {
                    Bitmap decodeByteArray = BitmapFactory.decodeByteArray(decode, 0, decode.length);
                    if (decodeByteArray != null) {
                        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                        decodeByteArray.compress(CompressFormat.PNG, 100, byteArrayOutputStream);
                        sd1 = new sd1(byteArrayOutputStream.toByteArray(), "image/png", "png");
                        decode = (byte[]) sd1.e;
                        str5 = (String) sd1.f;
                        str2 = sd1.g;
                        currentTimeMillis = System.currentTimeMillis();
                        stringBuilder = new StringBuilder();
                        stringBuilder.append(currentTimeMillis);
                        stringBuilder.append(".");
                        stringBuilder.append(str2);
                        str2 = stringBuilder.toString();
                        i = VERSION.SDK_INT;
                        obj = we1.a;
                        if (i >= 29) {
                            ContentValues contentValues = new ContentValues();
                            contentValues.put("_display_name", str2);
                            contentValues.put("mime_type", str5);
                            contentValues.put("relative_path", Environment.DIRECTORY_DOWNLOADS);
                            contentValues.put(str3, Integer.valueOf(1));
                            ContentResolver contentResolver = this.context.getContentResolver();
                            Uri insert = contentResolver.insert(Downloads.EXTERNAL_CONTENT_URI, contentValues);
                            if (insert != null) {
                                OutputStream openOutputStream = contentResolver.openOutputStream(insert);
                                if (openOutputStream != null) {
                                    openOutputStream.write(decode);
                                    openOutputStream.close();
                                }
                                contentValues.clear();
                                contentValues.put(str3, Integer.valueOf(0));
                                contentResolver.update(insert, contentValues, null, null);
                                context = this.context;
                                Toast.makeText(context, context.getString(2131361948), 0).show();
                            } else {
                                obj = null;
                            }
                        } else {
                            FileOutputStream mvVar = new mv(new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), str2));
                            mvVar.write(decode);
                            mvVar.close();
                            context = this.context;
                            Toast.makeText(context, context.getString(2131361948), 0).show();
                        }
                        if (ak0.a(obj) != null) {
                            Context context2 = this.context;
                            Toast.makeText(context2, context2.getString(2131361841), 0).show();
                        }
                        return;
                    }
                    str5 = MimeTypeMap.getSingleton().getExtensionFromMimeType(str2);
                    if (str5 != null) {
                        str6 = str5;
                    }
                    sd12 = new sd1(decode, str2, str6);
                } else if (startsWith2) {
                    str5 = MimeTypeMap.getSingleton().getExtensionFromMimeType(str2);
                    if (str5 == null) {
                        str5 = "mp4";
                    }
                    sd1 = new sd1(decode, str2, str5);
                    decode = (byte[]) sd1.e;
                    str5 = (String) sd1.f;
                    str2 = sd1.g;
                    currentTimeMillis = System.currentTimeMillis();
                    stringBuilder = new StringBuilder();
                    stringBuilder.append(currentTimeMillis);
                    stringBuilder.append(".");
                    stringBuilder.append(str2);
                    str2 = stringBuilder.toString();
                    i = VERSION.SDK_INT;
                    obj = we1.a;
                    if (i >= 29) {
                    }
                    if (ak0.a(obj) != null) {
                    }
                    return;
                } else {
                    str5 = MimeTypeMap.getSingleton().getExtensionFromMimeType(str2);
                    if (str5 != null) {
                        str6 = str5;
                    }
                    sd12 = new sd1(decode, str2, str6);
                }
                sd1 = sd12;
                decode = (byte[]) sd1.e;
                str5 = (String) sd1.f;
                str2 = sd1.g;
                currentTimeMillis = System.currentTimeMillis();
                stringBuilder = new StringBuilder();
                stringBuilder.append(currentTimeMillis);
                stringBuilder.append(".");
                stringBuilder.append(str2);
                str2 = stringBuilder.toString();
                i = VERSION.SDK_INT;
                obj = we1.a;
                if (i >= 29) {
                }
                if (ak0.a(obj) != null) {
                }
                return;
            }
            context = this.context;
            Toast.makeText(context, context.getString(2131361833), 0).show();
        } catch (Throwable th) {
            obj = new px0(th);
        }
    }

    public DownloadBridge(Context context) {
        context.getClass();
        this.context = context;
    }
}