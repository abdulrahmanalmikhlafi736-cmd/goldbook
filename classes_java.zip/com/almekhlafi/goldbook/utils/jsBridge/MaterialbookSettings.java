package com.almekhlafi.goldbook.utils.jsBridge;

import android.webkit.JavascriptInterface;
import defpackage.xz;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
public final class MaterialbookSettings {
    public static final int $stable = 0;
    private final xz toggleSettings;

    public MaterialbookSettings(xz xzVar) {
        xzVar.getClass();
        this.toggleSettings = xzVar;
    }

    @JavascriptInterface
    public final void onSettingsToggle() {
        this.toggleSettings.a();
    }
}