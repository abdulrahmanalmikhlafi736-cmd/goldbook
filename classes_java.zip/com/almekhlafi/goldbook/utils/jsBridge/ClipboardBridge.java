package com.almekhlafi.goldbook.utils.jsBridge;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build.VERSION;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import defpackage.a5;
import defpackage.ak0;
import defpackage.mv;
import defpackage.px0;
import defpackage.q81;
import defpackage.we1;
import java.io.File;
import java.io.FileOutputStream;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
public final class ClipboardBridge {
    public static final int $stable = 8;
    private final Context context;

    /* JADX WARNING: Missing block: B:38:?, code:
            defpackage.gh0.t(r1, r11);
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    @JavascriptInterface
    public final void copyImageToClipboard(String str, String str2) {
        String str3 = ",";
        str.getClass();
        str2.getClass();
        Object obj;
        try {
            Context context;
            if (q81.z(str, str3)) {
                byte[] decode = Base64.decode((String) q81.H(str, new String[]{str3}).get(1), 0);
                Bitmap decodeByteArray = BitmapFactory.decodeByteArray(decode, 0, decode.length);
                Context context2 = this.context;
                if (decodeByteArray == null) {
                    Toast.makeText(context2, context2.getString(2131361825), 0).show();
                    return;
                }
                Object systemService = context2.getSystemService("clipboard");
                systemService.getClass();
                ClipboardManager clipboardManager = (ClipboardManager) systemService;
                if (VERSION.SDK_INT >= 24) {
                    File file = new File(this.context.getCacheDir(), "clipboard_images");
                    if (!file.exists()) {
                        file.mkdirs();
                    }
                    File[] listFiles = file.listFiles();
                    if (listFiles != null) {
                        for (File file2 : listFiles) {
                            if (System.currentTimeMillis() - file2.lastModified() > 3600000) {
                                file2.delete();
                            }
                        }
                    }
                    long currentTimeMillis = System.currentTimeMillis();
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("clipboard_");
                    stringBuilder.append(currentTimeMillis);
                    stringBuilder.append(".png");
                    File file3 = new File(file, stringBuilder.toString());
                    FileOutputStream mvVar = new mv(file3);
                    decodeByteArray.compress(CompressFormat.PNG, 100, mvVar);
                    mvVar.close();
                    context = this.context;
                    String packageName = context.getPackageName();
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append(packageName);
                    stringBuilder2.append(".fileprovider");
                    Uri d = FileProvider.d(context, stringBuilder2.toString(), file3);
                    d.getClass();
                    clipboardManager.setPrimaryClip(ClipData.newUri(this.context.getContentResolver(), "Image", d));
                    context = this.context;
                    Toast.makeText(context, context.getString(2131361853), 0).show();
                } else {
                    context = this.context;
                    Toast.makeText(context, context.getString(2131361821), 0).show();
                }
                obj = we1.a;
                if (ak0.a(obj) != null) {
                    Context context3 = this.context;
                    Toast.makeText(context3, context3.getString(2131361840), 0).show();
                }
                return;
            }
            context = this.context;
            Toast.makeText(context, context.getString(2131361824), 0).show();
        } catch (Throwable th) {
            obj = new px0(th);
        }
    }

    @JavascriptInterface
    public final void copyText(String str) {
        Context context;
        if (str != null) {
            if (!q81.E(str)) {
                Object obj;
                try {
                    Object systemService = this.context.getSystemService("clipboard");
                    systemService.getClass();
                    ClipboardManager clipboardManager = (ClipboardManager) systemService;
                    String str2 = "GoldBook";
                    int length = str.length() - 1;
                    int i = 0;
                    int i2 = i;
                    while (i <= length) {
                        boolean y = a5.y(str.charAt(i2 == 0 ? i : length));
                        if (i2 == 0) {
                            if (y) {
                                i++;
                            } else {
                                i2 = 1;
                            }
                        } else if (!y) {
                            break;
                        } else {
                            length--;
                        }
                    }
                    clipboardManager.setPrimaryClip(ClipData.newPlainText(str2, str.subSequence(i, length + 1).toString()));
                    Context context2 = this.context;
                    Toast.makeText(context2, context2.getString(2131361964), 0).show();
                    obj = we1.a;
                } catch (Throwable th) {
                    obj = new px0(th);
                }
                if (ak0.a(obj) != null) {
                    context = this.context;
                    Toast.makeText(context, context.getString(2131361839), 0).show();
                }
                return;
            }
        }
        context = this.context;
        Toast.makeText(context, context.getString(2131361935), 0).show();
    }

    public ClipboardBridge(Context context) {
        context.getClass();
        this.context = context;
    }
}