package com.almekhlafi.goldbook.utils.jsBridge;

import android.webkit.JavascriptInterface;
import defpackage.dl1;
import defpackage.sb1;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
public final class MaterialYouBridge {
    public static final int $stable = 8;
    private final sb1 colors;

    private final String colorToRgb(int i) {
        int i2 = (i >> 16) & 255;
        int i3 = (i >> 8) & 255;
        i &= 255;
        StringBuilder dl1 = new dl1("{\"r\":");
        dl1.append(i2);
        dl1.append(",\"g\":");
        dl1.append(i3);
        dl1.append(",\"b\":");
        dl1.append(i);
        dl1.append("}");
        return dl1.toString();
    }

    private final String colorToRgbString(int i) {
        int i2 = (i >> 16) & 255;
        int i3 = (i >> 8) & 255;
        i &= 255;
        StringBuilder dl1 = new dl1("rgb(");
        dl1.append(i2);
        String str = ", ";
        dl1.append(str);
        dl1.append(i3);
        dl1.append(str);
        dl1.append(i);
        dl1.append(")");
        return dl1.toString();
    }

    public MaterialYouBridge(sb1 sb1) {
        sb1.getClass();
        this.colors = sb1;
    }

    @JavascriptInterface
    public final String getMaterialYouOnPrimaryRgb() {
        return colorToRgb(this.colors.b);
    }

    @JavascriptInterface
    public final String getMaterialYouOnPrimaryRgbString() {
        return colorToRgbString(this.colors.b);
    }

    @JavascriptInterface
    public final String getMaterialYouPrimaryRgb() {
        return colorToRgb(this.colors.a);
    }

    @JavascriptInterface
    public final String getMaterialYouPrimaryRgbString() {
        return colorToRgbString(this.colors.a);
    }
}