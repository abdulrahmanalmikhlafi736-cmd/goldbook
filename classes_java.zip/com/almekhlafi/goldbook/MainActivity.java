package com.almekhlafi.goldbook;

import android.content.Intent;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import android.widget.Toast;
import defpackage.dd0;
import defpackage.ea1;
import defpackage.h90;
import defpackage.hc;
import defpackage.ib;
import defpackage.jb0;
import defpackage.jj;
import defpackage.k70;
import defpackage.ki;
import defpackage.li;
import defpackage.mc0;
import defpackage.n41;
import defpackage.o;
import defpackage.os;
import defpackage.pi;
import defpackage.ps;
import defpackage.ua0;
import defpackage.ws;
import mod.Mod;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
public final class MainActivity extends ki {
    public static final /* synthetic */ int z = 0;
    public n41 y;

    /* JADX WARNING: Removed duplicated region for block: B:47:0x00f9  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void onCreate(Bundle bundle) {
        int i;
        View childAt;
        dd0.u(getWindow(), false);
        ea1 ea1 = new ea1(0, 0, new h90(4));
        ea1 ea12 = new ea1(ps.a, ps.b, new h90(4));
        View decorView = getWindow().getDecorView();
        decorView.getClass();
        ws wsVar = ps.c;
        if (wsVar == null) {
            i = VERSION.SDK_INT;
            wsVar = i >= 35 ? new Object() : i >= 30 ? new Object() : i >= 29 ? new Object() : i >= 28 ? new Object() : i >= 26 ? new Object() : new Object();
            ps.c = wsVar;
        }
        ws wsVar2 = wsVar;
        ib ibVar = new ib(wsVar2, ea1, ea12, this, decorView, 1);
        ViewGroup viewGroup = (ViewGroup) decorView;
        int i2 = 0;
        while (i2 < viewGroup.getChildCount()) {
            i = i2 + 1;
            childAt = viewGroup.getChildAt(i2);
            if (childAt == null) {
                throw new IndexOutOfBoundsException();
            } else if (childAt.getTag() instanceof ws) {
                break;
            } else {
                i2 = i;
            }
        }
        os osVar = new os(ibVar, viewGroup.getContext());
        osVar.setTag(wsVar2);
        osVar.setVisibility(8);
        osVar.setWillNotDraw(true);
        viewGroup.addView(osVar);
        ibVar.run();
        Window window = getWindow();
        window.getClass();
        wsVar2.a(window);
        super.onCreate(bundle);
        Mod.warm(this);
        this.y = new n41(this);
        if (mc0.q(this)) {
            boolean z;
            Intent intent = getIntent();
            if (intent != null) {
                int action = intent.getAction();
                if (action != 0) {
                    if (action.equals("android.provider.Telephony.SECRET_CODE")) {
                        z = true;
                    } else {
                        Uri data = intent.getData();
                        if (data != null) {
                            z = k70.p(data.getScheme(), "goldbook");
                        }
                    }
                    if (z) {
                        try {
                            Toast.makeText(this, getString(2131361956), 1).show();
                        } catch (Throwable unused) {
                        }
                    }
                }
            }
            z = false;
            if (z) {
            }
        }
        pi piVar = new pi(-1690879578, true, new hc(5, this));
        LayoutParams layoutParams = li.a;
        childAt = ((ViewGroup) getWindow().getDecorView().findViewById(16908290)).getChildAt(0);
        o oVar = childAt instanceof jj ? (jj) childAt : null;
        if (oVar != null) {
            oVar.setParentCompositionContext(null);
            oVar.setContent(piVar);
            return;
        }
        jj jjVar = new jj(this);
        jjVar.setParentCompositionContext(null);
        jjVar.setContent(piVar);
        View decorView2 = getWindow().getDecorView();
        if (ua0.o(decorView2) == null) {
            decorView2.setTag(2131034229, this);
        }
        if (jb0.j(decorView2) == null) {
            decorView2.setTag(2131034233, this);
        }
        if (jb0.j(decorView2) == null) {
            decorView2.setTag(2131034232, this);
        }
        setContentView(jjVar, li.a);
    }

    public final void onPictureInPictureModeChanged(boolean z, Configuration configuration) {
        configuration.getClass();
        super.onPictureInPictureModeChanged(z, configuration);
        Mod.setInPip(z);
    }

    public final void onUserLeaveHint() {
        super.onUserLeaveHint();
        Mod.onUserLeaveHint(this);
    }
}