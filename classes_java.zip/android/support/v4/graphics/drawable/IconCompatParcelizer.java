package android.support.v4.graphics.drawable;

import androidx.core.graphics.drawable.IconCompat;
import defpackage.kg1;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
public final class IconCompatParcelizer extends androidx.core.graphics.drawable.IconCompatParcelizer {
    public static IconCompat read(kg1 kg1) {
        return androidx.core.graphics.drawable.IconCompatParcelizer.read(kg1);
    }

    public static void write(IconCompat iconCompat, kg1 kg1) {
        androidx.core.graphics.drawable.IconCompatParcelizer.write(iconCompat, kg1);
    }
}