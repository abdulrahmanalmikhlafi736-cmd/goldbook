package defpackage;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cm  reason: default package */
public final class cm {
    public static final cm e;
    public static final cm f;
    public static final cm g;
    public static final /* synthetic */ cm[] h;

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0, types: [java.lang.Enum, cm] */
    /* JADX WARN: Type inference failed for: r1v1, types: [java.lang.Enum, cm] */
    /* JADX WARN: Type inference failed for: r3v1, types: [java.lang.Enum, cm] */
    static {
        ?? r0 = new Enum("COROUTINE_SUSPENDED", 0);
        e = r0;
        ?? r1 = new Enum("UNDECIDED", 1);
        f = r1;
        ?? r3 = new Enum("RESUMED", 2);
        g = r3;
        h = new cm[]{r0, r1, r3};
    }

    public static cm valueOf(String str) {
        return (cm) Enum.valueOf(cm.class, str);
    }

    public static cm[] values() {
        return (cm[]) h.clone();
    }
}