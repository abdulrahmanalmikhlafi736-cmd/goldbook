package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cc1  reason: default package */
public final class cc1 {
    public final sj0 a;
    public bc1 b;
    public long c;
    public long d;
    public long e;
    public long f;
    public float[] g;

    public cc1() {
        sj0 sj0Var = m60.a;
        this.a = new sj0();
        this.c = -1L;
        this.d = 0L;
        this.e = 0L;
    }

    public final void a(bc1 bc1Var, long j, long j2, float[] fArr, long j3) {
        boolean z;
        long j4 = bc1Var.g;
        if (j3 - j4 <= 0 && j4 != Long.MIN_VALUE) {
            z = false;
        } else {
            z = true;
        }
        if (z) {
            bc1Var.g = j3;
            bc1Var.a(bc1Var.e, bc1Var.f, j, j2, fArr);
        }
    }
}