package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bl0  reason: default package */
public final class bl0 implements le, oh1 {
    public final ne e;
    public final /* synthetic */ cl0 f;

    public bl0(cl0 cl0Var, ne neVar) {
        this.f = cl0Var;
        this.e = neVar;
    }

    @Override // defpackage.oh1
    public final void a(a21 a21Var, int i) {
        this.e.a(a21Var, i);
    }

    @Override // defpackage.ml
    public final sl e() {
        return this.e.i;
    }

    @Override // defpackage.ml
    public final void h(Object obj) {
        this.e.h(obj);
    }

    @Override // defpackage.le
    public final mt j(Object obj, n00 n00Var) {
        cl0 cl0Var = this.f;
        me meVar = new me(cl0Var, this);
        mt j = this.e.j((we1) obj, meVar);
        if (j != null) {
            cl0.g.set(cl0Var, null);
        }
        return j;
    }

    @Override // defpackage.le
    public final boolean l(Throwable th) {
        return this.e.l(th);
    }

    @Override // defpackage.le
    public final void x(Object obj) {
        this.e.x(obj);
    }
}