package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ed  reason: default package */
public final class ed implements ua1 {
    public final dd a;
    public final float b;

    public ed(dd ddVar, float f) {
        this.a = ddVar;
        this.b = f;
    }

    @Override // defpackage.ua1
    public final float a() {
        return this.b;
    }

    @Override // defpackage.ua1
    public final long b() {
        int i = zg.j;
        return zg.i;
    }

    @Override // defpackage.ua1
    public final /* synthetic */ ua1 c(ua1 ua1Var) {
        return fu0.f(this, ua1Var);
    }

    @Override // defpackage.ua1
    public final ua1 d(xz xzVar) {
        if (!equals(ta1.a)) {
            return this;
        }
        return (ua1) xzVar.a();
    }

    @Override // defpackage.ua1
    public final zi1 e() {
        return this.a;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof ed)) {
            return false;
        }
        ed edVar = (ed) obj;
        if (k70.p(this.a, edVar.a) && Float.compare(this.b, edVar.b) == 0) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        return Float.floatToIntBits(this.b) + (this.a.hashCode() * 31);
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("BrushStyle(value=");
        sb.append(this.a);
        sb.append(", alpha=");
        return fu0.F(sb, this.b, ')');
    }
}