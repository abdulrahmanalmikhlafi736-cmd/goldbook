package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: a31  reason: default package */
public final class a31 implements uw {
    public final z21 e;

    public a31(yu0 yu0Var) {
        this.e = yu0Var;
    }

    @Override // defpackage.uw
    public final Object k(Object obj, ml mlVar) {
        Object c = this.e.c(mlVar, obj);
        if (c == cm.e) {
            return c;
        }
        return we1.a;
    }
}