package defpackage;

import java.util.Collection;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: a91  reason: default package */
public final class a91 implements List, w80 {
    public final z61 e;
    public final int f;
    public int g;
    public int h;

    public a91(z61 z61Var, int i, int i2) {
        this.e = z61Var;
        this.f = i;
        this.g = zi1.v(z61Var);
        this.h = i2 - i;
    }

    public final void a() {
        if (zi1.v(this.e) == this.g) {
            return;
        }
        throw new ConcurrentModificationException();
    }

    @Override // java.util.List, java.util.Collection
    public final boolean add(Object obj) {
        a();
        int i = this.f + this.h;
        z61 z61Var = this.e;
        z61Var.add(i, obj);
        this.h++;
        this.g = zi1.v(z61Var);
        return true;
    }

    @Override // java.util.List
    public final boolean addAll(int i, Collection collection) {
        a();
        int i2 = i + this.f;
        z61 z61Var = this.e;
        boolean addAll = z61Var.addAll(i2, collection);
        if (addAll) {
            this.h = collection.size() + this.h;
            this.g = zi1.v(z61Var);
        }
        return addAll;
    }

    @Override // java.util.List, java.util.Collection
    public final void clear() {
        if (this.h > 0) {
            a();
            int i = this.h;
            int i2 = this.f;
            z61 z61Var = this.e;
            z61Var.e(i2, i + i2);
            this.h = 0;
            this.g = zi1.v(z61Var);
        }
    }

    @Override // java.util.List, java.util.Collection
    public final boolean contains(Object obj) {
        if (indexOf(obj) >= 0) {
            return true;
        }
        return false;
    }

    @Override // java.util.List, java.util.Collection
    public final boolean containsAll(Collection collection) {
        Collection<Object> collection2 = collection;
        if ((collection2 instanceof Collection) && collection2.isEmpty()) {
            return true;
        }
        for (Object obj : collection2) {
            if (!contains(obj)) {
                return false;
            }
        }
        return true;
    }

    @Override // java.util.List
    public final Object get(int i) {
        a();
        zi1.j(i, this.h);
        return this.e.get(this.f + i);
    }

    @Override // java.util.List
    public final int indexOf(Object obj) {
        int nextInt;
        a();
        int i = this.h;
        int i2 = this.f;
        Iterator it = sb0.w(i2, i + i2).iterator();
        do {
            p60 p60Var = (p60) it;
            if (p60Var.g) {
                nextInt = p60Var.nextInt();
            } else {
                return -1;
            }
        } while (!k70.p(obj, this.e.get(nextInt)));
        return nextInt - i2;
    }

    @Override // java.util.List, java.util.Collection
    public final boolean isEmpty() {
        if (this.h == 0) {
            return true;
        }
        return false;
    }

    @Override // java.util.List, java.util.Collection, java.lang.Iterable
    public final Iterator iterator() {
        return listIterator(0);
    }

    @Override // java.util.List
    public final int lastIndexOf(Object obj) {
        a();
        int i = this.h;
        int i2 = this.f;
        for (int i3 = (i + i2) - 1; i3 >= i2; i3--) {
            if (k70.p(obj, this.e.get(i3))) {
                return i3 - i2;
            }
        }
        return -1;
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [lw0, java.lang.Object] */
    @Override // java.util.List
    public final ListIterator listIterator(int i) {
        a();
        ?? obj = new Object();
        obj.e = i - 1;
        return new ux0((lw0) obj, this);
    }

    @Override // java.util.List
    public final Object remove(int i) {
        a();
        int i2 = this.f + i;
        z61 z61Var = this.e;
        Object remove = z61Var.remove(i2);
        this.h--;
        this.g = zi1.v(z61Var);
        return remove;
    }

    @Override // java.util.List, java.util.Collection
    public final boolean removeAll(Collection collection) {
        while (true) {
            boolean z = false;
            for (Object obj : collection) {
                if (remove(obj) || z) {
                    z = true;
                }
            }
            return z;
        }
    }

    @Override // java.util.List, java.util.Collection
    public final boolean retainAll(Collection collection) {
        int i;
        c0 c0Var;
        g61 j;
        boolean n;
        a();
        z61 z61Var = this.e;
        int i2 = this.f;
        int i3 = this.h + i2;
        int size = z61Var.size();
        do {
            synchronized (zi1.x) {
                g81 g81Var = z61Var.e;
                g81Var.getClass();
                g81 g81Var2 = (g81) n61.h(g81Var);
                i = g81Var2.d;
                c0Var = g81Var2.c;
            }
            c0Var.getClass();
            es0 f = c0Var.f();
            f.subList(i2, i3).retainAll(collection);
            c0 c = f.c();
            if (k70.p(c, c0Var)) {
                break;
            }
            g81 g81Var3 = z61Var.e;
            g81Var3.getClass();
            synchronized (n61.c) {
                j = n61.j();
                n = zi1.n((g81) n61.x(g81Var3, z61Var, j), i, c, true);
            }
            n61.o(j, z61Var);
        } while (!n);
        int size2 = size - z61Var.size();
        if (size2 > 0) {
            this.g = zi1.v(this.e);
            this.h -= size2;
        }
        if (size2 > 0) {
            return true;
        }
        return false;
    }

    @Override // java.util.List
    public final Object set(int i, Object obj) {
        zi1.j(i, this.h);
        a();
        int i2 = i + this.f;
        z61 z61Var = this.e;
        Object obj2 = z61Var.set(i2, obj);
        this.g = zi1.v(z61Var);
        return obj2;
    }

    @Override // java.util.List, java.util.Collection
    public final int size() {
        return this.h;
    }

    @Override // java.util.List
    public final List subList(int i, int i2) {
        if (i < 0 || i > i2 || i2 > this.h) {
            rt0.a("fromIndex or toIndex are out of bounds");
        }
        a();
        int i3 = this.f;
        return new a91(this.e, i + i3, i2 + i3);
    }

    @Override // java.util.List, java.util.Collection
    public final Object[] toArray() {
        return vd1.G(this);
    }

    @Override // java.util.List, java.util.Collection
    public final Object[] toArray(Object[] objArr) {
        return vd1.H(this, objArr);
    }

    @Override // java.util.List
    public final ListIterator listIterator() {
        return listIterator(0);
    }

    @Override // java.util.List, java.util.Collection
    public final boolean remove(Object obj) {
        int indexOf = indexOf(obj);
        if (indexOf >= 0) {
            remove(indexOf);
            return true;
        }
        return false;
    }

    @Override // java.util.List
    public final void add(int i, Object obj) {
        a();
        int i2 = this.f + i;
        z61 z61Var = this.e;
        z61Var.add(i2, obj);
        this.h++;
        this.g = zi1.v(z61Var);
    }

    @Override // java.util.List, java.util.Collection
    public final boolean addAll(Collection collection) {
        return addAll(this.h, collection);
    }
}