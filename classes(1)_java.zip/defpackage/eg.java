package defpackage;

import android.view.ViewConfiguration;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: eg  reason: default package */
public abstract class eg {
    public static final long a = ViewConfiguration.getTapTimeout();
    public static final /* synthetic */ int b = 0;
}