package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: au0  reason: default package */
public abstract class au0 {
    public static final xg0 a = new xg0(il1.g, il1.i, gu0.v());
}