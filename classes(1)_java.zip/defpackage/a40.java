package defpackage;

import android.content.res.Resources;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: a40  reason: default package */
public final class a40 {
    public final Resources.Theme a;

    public a40(Resources.Theme theme) {
        this.a = theme;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if ((obj instanceof a40) && k70.p(this.a, ((a40) obj).a)) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        return (this.a.hashCode() * 31) + 2130968576;
    }

    public final String toString() {
        return "Key(theme=" + this.a + ", id=2130968576)";
    }
}