package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: en  reason: default package */
public final class en extends u91 implements n00 {
    public final /* synthetic */ int i = 1;
    public int j;
    public /* synthetic */ Object k;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public en(tn tnVar, ml mlVar) {
        super(3, mlVar);
        this.k = tnVar;
    }

    @Override // defpackage.n00
    public final Object c(Object obj, Object obj2, Object obj3) {
        int i = this.i;
        we1 we1Var = we1.a;
        switch (i) {
            case 0:
                uw uwVar = (uw) obj;
                Throwable th = (Throwable) obj2;
                return new en((tn) this.k, (ml) obj3).p(we1Var);
            default:
                ((Boolean) obj2).getClass();
                en enVar = new en(3, (ml) obj3);
                enVar.k = (mv) obj;
                return enVar.p(we1Var);
        }
    }

    @Override // defpackage.db
    public final Object p(Object obj) {
        int i = this.i;
        cm cmVar = cm.e;
        switch (i) {
            case 0:
                int i2 = this.j;
                if (i2 != 0) {
                    if (i2 == 1) {
                        nb0.t(obj);
                    } else {
                        od.p("call to 'resume' before 'invoke' with coroutine");
                        return null;
                    }
                } else {
                    nb0.t(obj);
                    this.j = 1;
                    if (tn.a((tn) this.k, this) == cmVar) {
                        return cmVar;
                    }
                }
                return we1.a;
            default:
                int i3 = this.j;
                if (i3 != 0) {
                    if (i3 == 1) {
                        nb0.t(obj);
                        return obj;
                    }
                    od.p("call to 'resume' before 'invoke' with coroutine");
                } else {
                    nb0.t(obj);
                    mv mvVar = (mv) this.k;
                    this.j = 1;
                    if (!mvVar.b.get()) {
                        Object c = vd1.c(mvVar.a, new nn(mvVar, null, 1), this);
                        if (c == cmVar) {
                            return cmVar;
                        }
                        return c;
                    }
                    od.p("This scope has already been closed.");
                }
                return null;
        }
    }

    public /* synthetic */ en(int i, ml mlVar) {
        super(i, mlVar);
    }
}