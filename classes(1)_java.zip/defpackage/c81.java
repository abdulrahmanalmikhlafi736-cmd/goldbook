package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: c81  reason: default package */
public final class c81 extends nl {
    public d81 h;
    public uw i;
    public e81 j;
    public a80 k;
    public Object l;
    public /* synthetic */ Object m;
    public final /* synthetic */ d81 n;
    public int o;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public c81(d81 d81Var, ml mlVar) {
        super(mlVar);
        this.n = d81Var;
    }

    @Override // defpackage.db
    public final Object p(Object obj) {
        this.m = obj;
        this.o |= Integer.MIN_VALUE;
        this.n.b(null, this);
        return cm.e;
    }
}