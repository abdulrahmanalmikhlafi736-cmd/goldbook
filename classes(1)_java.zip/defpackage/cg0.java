package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cg0  reason: default package */
public final class cg0 extends js0 {
    public final /* synthetic */ int f;
    public final Object g;

    public /* synthetic */ cg0(int i, Object obj) {
        this.f = i;
        this.g = obj;
    }

    @Override // defpackage.jp
    public final float a() {
        int i = this.f;
        Object obj = this.g;
        switch (i) {
            case 0:
                return ((bg0) obj).a();
            default:
                return ((n4) obj).getDensity().a();
        }
    }

    @Override // defpackage.js0
    public float d(j30 j30Var) {
        float f;
        float intBitsToFloat;
        int f0;
        switch (this.f) {
            case 0:
                m00 m00Var = j30Var.a;
                if (m00Var != null) {
                    return ((Number) m00Var.f(this, Float.valueOf(Float.NaN))).floatValue();
                }
                bg0 bg0Var = (bg0) this.g;
                if (bg0Var.o) {
                    return Float.NaN;
                }
                bg0 bg0Var2 = bg0Var;
                while (true) {
                    wy0 wy0Var = bg0Var2.q;
                    if (wy0Var != null && (f0 = ba.f0((j30[]) wy0Var.b, j30Var)) >= 0) {
                        f = ((float[]) wy0Var.c)[f0];
                    } else {
                        f = Float.NaN;
                    }
                    if (!Float.isNaN(f)) {
                        bg0Var2.U(bg0Var.f0(), j30Var);
                        n90 d0 = bg0Var2.d0();
                        n90 d02 = bg0Var.d0();
                        switch (j30Var.b) {
                            case 0:
                                intBitsToFloat = Float.intBitsToFloat((int) (d02.v(d0, (Float.floatToRawIntBits(f) & 4294967295L) | (Float.floatToRawIntBits(((int) (d0.A() >> 32)) / 2.0f) << 32)) & 4294967295L));
                                break;
                            default:
                                intBitsToFloat = Float.intBitsToFloat((int) (d02.v(d0, (Float.floatToRawIntBits(f) << 32) | (4294967295L & Float.floatToRawIntBits(((int) (d0.A() & 4294967295L)) / 2.0f))) >> 32));
                                break;
                        }
                        return intBitsToFloat;
                    }
                    bg0 h0 = bg0Var2.h0();
                    if (h0 == null) {
                        bg0Var2.U(bg0Var.f0(), j30Var);
                        return Float.NaN;
                    }
                    bg0Var2 = h0;
                }
                break;
            default:
                return super.d(j30Var);
        }
    }

    @Override // defpackage.js0
    public final o90 e() {
        int i = this.f;
        Object obj = this.g;
        switch (i) {
            case 0:
                return ((bg0) obj).getLayoutDirection();
            default:
                return ((n4) obj).getLayoutDirection();
        }
    }

    @Override // defpackage.js0
    public final int f() {
        int i = this.f;
        Object obj = this.g;
        switch (i) {
            case 0:
                return ((bg0) obj).P();
            default:
                return ((n4) obj).getRoot().K.p.e;
        }
    }

    @Override // defpackage.jp
    public final float g() {
        int i = this.f;
        Object obj = this.g;
        switch (i) {
            case 0:
                return ((bg0) obj).g();
            default:
                return ((n4) obj).getDensity().g();
        }
    }
}