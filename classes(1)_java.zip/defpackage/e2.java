package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: e2  reason: default package */
public final class e2 implements pm0 {
    public static final e2 a = new Object();

    public final String toString() {
        return "Active";
    }
}