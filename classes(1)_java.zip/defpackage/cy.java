package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cy  reason: default package */
public final class cy {
    public final hy a;
    public final n4 b;
    public final ik0 c;
    public final ik0 d;
    public boolean e;

    public cy(hy hyVar, n4 n4Var) {
        this.a = hyVar;
        this.b = n4Var;
        ik0 ik0Var = o01.a;
        this.c = new ik0();
        this.d = new ik0();
    }

    public final void a() {
        if (!this.e) {
            e4 e4Var = new e4(0, this, cy.class, "invalidateNodes", "invalidateNodes()V", 0, 0, 1);
            ak0 ak0Var = this.b.D0;
            if (ak0Var.g(e4Var) < 0) {
                ak0Var.a(e4Var);
            }
            this.e = true;
        }
    }
}