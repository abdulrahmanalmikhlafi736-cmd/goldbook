package defpackage;

import android.graphics.Insets;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: c60  reason: default package */
public final class c60 {
    public static final c60 e = new c60(0, 0, 0, 0);
    public final int a;
    public final int b;
    public final int c;
    public final int d;

    public c60(int i, int i2, int i3, int i4) {
        this.a = i;
        this.b = i2;
        this.c = i3;
        this.d = i4;
    }

    public static c60 a(c60 c60Var, c60 c60Var2) {
        return b(Math.max(c60Var.a, c60Var2.a), Math.max(c60Var.b, c60Var2.b), Math.max(c60Var.c, c60Var2.c), Math.max(c60Var.d, c60Var2.d));
    }

    public static c60 b(int i, int i2, int i3, int i4) {
        if (i == 0 && i2 == 0 && i3 == 0 && i4 == 0) {
            return e;
        }
        return new c60(i, i2, i3, i4);
    }

    public static c60 c(Insets insets) {
        return b(o20.a(insets), o20.n(insets), b60.c(insets), b60.u(insets));
    }

    public final Insets d() {
        return zk.h(this.a, this.b, this.c, this.d);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || c60.class != obj.getClass()) {
            return false;
        }
        c60 c60Var = (c60) obj;
        if (this.d == c60Var.d && this.a == c60Var.a && this.c == c60Var.c && this.b == c60Var.b) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        return (((((this.a * 31) + this.b) * 31) + this.c) * 31) + this.d;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("Insets{left=");
        sb.append(this.a);
        sb.append(", top=");
        sb.append(this.b);
        sb.append(", right=");
        sb.append(this.c);
        sb.append(", bottom=");
        return fu0.G(sb, this.d, '}');
    }
}