package defpackage;

import java.util.ArrayList;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: co0  reason: default package */
public final class co0 extends xo0 {
    public static final co0 c = new xo0(0, 1, 1);

    @Override // defpackage.xo0
    public final void a(pg pgVar, m9 m9Var, a61 a61Var, uw0 uw0Var, yo0 yo0Var) {
        qk0 qk0Var;
        xv0 xv0Var = (xv0) pgVar.c(0);
        hk0 hk0Var = uw0Var.i;
        if (hk0Var != null && ((mr0) hk0Var.g(xv0Var)) != null) {
            ArrayList arrayList = uw0Var.j;
            if (arrayList != null && (qk0Var = (qk0) arrayList.remove(arrayList.size() - 1)) != null) {
                uw0Var.e = qk0Var;
            }
            hk0Var.k(xv0Var);
        }
    }
}