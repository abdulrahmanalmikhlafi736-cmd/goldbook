package defpackage;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: b10  reason: default package */
public final class b10 extends sj {
    public final long a;
    public final boolean b;
    public final boolean c;
    public HashSet d;
    public final ik0 e;
    public final lq0 f;
    public final /* synthetic */ d10 g;

    public b10(d10 d10Var, long j, boolean z, boolean z2, pg0 pg0Var) {
        this.g = d10Var;
        this.a = j;
        this.b = z;
        this.c = z2;
        ik0 ik0Var = o01.a;
        this.e = new ik0();
        this.f = new lq0(qr0.h, nq0.h);
    }

    @Override // defpackage.sj
    public final void a(yj yjVar, m00 m00Var) {
        this.g.b.a(yjVar, m00Var);
    }

    @Override // defpackage.sj
    public final ik0 b(yj yjVar, l51 l51Var, m00 m00Var) {
        return this.g.b.b(yjVar, l51Var, m00Var);
    }

    @Override // defpackage.sj
    public final void c() {
        d10 d10Var = this.g;
        d10Var.A--;
    }

    @Override // defpackage.sj
    public final boolean d() {
        return this.g.b.d();
    }

    @Override // defpackage.sj
    public final boolean e() {
        return this.b;
    }

    @Override // defpackage.sj
    public final boolean f() {
        return this.c;
    }

    @Override // defpackage.sj
    public final long g() {
        return this.a;
    }

    @Override // defpackage.sj
    public final rj h() {
        return this.g.h;
    }

    @Override // defpackage.sj
    public final qr0 i() {
        return (qr0) this.f.getValue();
    }

    @Override // defpackage.sj
    public final sl j() {
        return this.g.b.j();
    }

    @Override // defpackage.sj
    public final boolean k() {
        return this.g.b.k();
    }

    @Override // defpackage.sj
    public final void l(yj yjVar) {
        d10 d10Var = this.g;
        d10Var.b.l(d10Var.h);
        d10Var.b.l(yjVar);
    }

    @Override // defpackage.sj
    public final fj0 m(gj0 gj0Var) {
        return this.g.b.m(gj0Var);
    }

    @Override // defpackage.sj
    public final ik0 n(yj yjVar, l51 l51Var, ik0 ik0Var) {
        return this.g.b.n(yjVar, l51Var, ik0Var);
    }

    @Override // defpackage.sj
    public final void o(Set set) {
        HashSet hashSet = this.d;
        if (hashSet == null) {
            hashSet = new HashSet();
            this.d = hashSet;
        }
        hashSet.add(set);
    }

    @Override // defpackage.sj
    public final void p(d10 d10Var) {
        this.e.a(d10Var);
    }

    @Override // defpackage.sj
    public final void q(xv0 xv0Var) {
        this.g.b.q(xv0Var);
    }

    @Override // defpackage.sj
    public final void r(yj yjVar) {
        this.g.b.r(yjVar);
    }

    @Override // defpackage.sj
    public final oe s(f8 f8Var) {
        return this.g.b.s(f8Var);
    }

    @Override // defpackage.sj
    public final void t() {
        this.g.A++;
    }

    @Override // defpackage.sj
    public final void u(d10 d10Var) {
        HashSet hashSet = this.d;
        if (hashSet != null) {
            Iterator it = hashSet.iterator();
            while (it.hasNext()) {
                d10Var.getClass();
                ((Set) it.next()).remove(d10Var.w());
            }
        }
        if (fu0.M(d10Var)) {
            this.e.l(d10Var);
        }
    }

    @Override // defpackage.sj
    public final void v(yj yjVar) {
        this.g.b.v(yjVar);
    }

    public final void w() {
        ik0 ik0Var = this.e;
        if (ik0Var.h()) {
            HashSet hashSet = this.d;
            if (hashSet != null) {
                Object[] objArr = ik0Var.b;
                long[] jArr = ik0Var.a;
                int length = jArr.length - 2;
                if (length >= 0) {
                    int i = 0;
                    while (true) {
                        long j = jArr[i];
                        if ((((~j) << 7) & j & (-9187201950435737472L)) != -9187201950435737472L) {
                            int i2 = 8 - ((~(i - length)) >>> 31);
                            for (int i3 = 0; i3 < i2; i3++) {
                                if ((255 & j) < 128) {
                                    d10 d10Var = (d10) objArr[(i << 3) + i3];
                                    Iterator it = hashSet.iterator();
                                    while (it.hasNext()) {
                                        ((Set) it.next()).remove(d10Var.w());
                                    }
                                }
                                j >>= 8;
                            }
                            if (i2 != 8) {
                                break;
                            }
                        }
                        if (i == length) {
                            break;
                        }
                        i++;
                    }
                }
            }
            ik0Var.b();
        }
    }
}