package defpackage;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: aw0  reason: default package */
public final class aw0 {
    public static final aw0 e;
    public static final aw0 f;
    public static final aw0 g;
    public static final aw0 h;
    public static final aw0 i;
    public static final aw0 j;
    public static final /* synthetic */ aw0[] k;

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0, types: [java.lang.Enum, aw0] */
    /* JADX WARN: Type inference failed for: r1v1, types: [java.lang.Enum, aw0] */
    /* JADX WARN: Type inference failed for: r3v1, types: [java.lang.Enum, aw0] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Enum, aw0] */
    /* JADX WARN: Type inference failed for: r7v1, types: [java.lang.Enum, aw0] */
    /* JADX WARN: Type inference failed for: r9v1, types: [java.lang.Enum, aw0] */
    static {
        ?? r0 = new Enum("ShutDown", 0);
        e = r0;
        ?? r1 = new Enum("ShuttingDown", 1);
        f = r1;
        ?? r3 = new Enum("Inactive", 2);
        g = r3;
        ?? r5 = new Enum("InactivePendingWork", 3);
        h = r5;
        ?? r7 = new Enum("Idle", 4);
        i = r7;
        ?? r9 = new Enum("PendingWork", 5);
        j = r9;
        k = new aw0[]{r0, r1, r3, r5, r7, r9};
    }

    public static aw0 valueOf(String str) {
        return (aw0) Enum.valueOf(aw0.class, str);
    }

    public static aw0[] values() {
        return (aw0[]) k.clone();
    }
}