package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ax0  reason: default package */
public final class ax0 implements bm, ww0 {
    public static final qe h = new qe(0);
    public final sl e;
    public final ax0 f = this;
    public volatile sl g;

    public ax0(sl slVar) {
        this.e = slVar;
    }

    public final void a() {
        synchronized (this.f) {
            try {
                sl slVar = this.g;
                if (slVar == null) {
                    this.g = h;
                } else {
                    uz uzVar = new uz(0);
                    a80 a80Var = (a80) slVar.k(e3.S);
                    if (a80Var != null) {
                        a80Var.a(uzVar);
                    }
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    @Override // defpackage.ww0
    public final void c() {
    }

    @Override // defpackage.ww0
    public final void d() {
        a();
    }

    @Override // defpackage.ww0
    public final void e() {
        a();
    }

    @Override // defpackage.bm
    public final sl f() {
        sl slVar;
        sl slVar2;
        sl slVar3 = this.g;
        if (slVar3 == null || slVar3 == h) {
            wj wjVar = (wj) this.e.k(wj.f);
            if (wjVar != null) {
                slVar = new zw0(wjVar, this);
            } else {
                slVar = st.e;
            }
            synchronized (this.f) {
                try {
                    sl slVar4 = this.g;
                    if (slVar4 == null) {
                        sl slVar5 = this.e;
                        slVar2 = slVar5.i(new c80((a80) slVar5.k(e3.S))).i(st.e).i(slVar);
                    } else if (slVar4 == h) {
                        sl slVar6 = this.e;
                        c80 c80Var = new c80((a80) slVar6.k(e3.S));
                        c80Var.A(new uz(0));
                        slVar2 = slVar6.i(c80Var).i(st.e).i(slVar);
                    } else {
                        slVar2 = slVar4;
                    }
                    this.g = slVar2;
                } catch (Throwable th) {
                    throw th;
                }
            }
            slVar3 = slVar2;
        }
        slVar3.getClass();
        return slVar3;
    }
}