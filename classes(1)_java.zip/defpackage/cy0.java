package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cy0  reason: default package */
public final class cy0 {
    public final long a = zg.i;

    public final boolean equals(Object obj) {
        if (this != obj) {
            if (obj instanceof cy0) {
                if (!zg.c(this.a, ((cy0) obj).a)) {
                    return false;
                }
                return true;
            }
            return false;
        }
        return true;
    }

    public final int hashCode() {
        int i = zg.j;
        return pe1.a(this.a) * 31;
    }

    public final String toString() {
        return "RippleConfiguration(color=" + ((Object) zg.i(this.a)) + ", rippleAlpha=null)";
    }
}