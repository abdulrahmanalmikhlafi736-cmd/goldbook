package defpackage;

import android.util.Log;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CancellationException;
import java.util.concurrent.atomic.AtomicReference;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dw0  reason: default package */
public final class dw0 extends sj {
    public final g7 a;
    public final k9 b;
    public final Object c;
    public a80 d;
    public Throwable e;
    public final ArrayList f;
    public List g;
    public ik0 h;
    public final qk0 i;
    public final ArrayList j;
    public final ArrayList k;
    public final hk0 l;
    public final al m;
    public final hk0 n;
    public final hk0 o;
    public ArrayList p;
    public ik0 q;
    public ne r;
    public final d81 s;
    public boolean t;
    public final d81 u;
    public final k9 v;
    public final c80 w;
    public final sl x;
    public final av0 y;
    public static final d81 z = ac.c(cs0.h);
    public static final AtomicReference A = new AtomicReference(Boolean.FALSE);

    public dw0(sl slVar) {
        g7 g7Var = new g7(new yv0(this, 0));
        this.a = g7Var;
        this.b = new k9(new yv0(this, 1));
        this.c = new Object();
        this.f = new ArrayList();
        this.h = new ik0();
        this.i = new qk0(new yj[16]);
        this.j = new ArrayList();
        this.k = new ArrayList();
        this.l = new hk0();
        this.m = new al(13);
        this.n = new hk0();
        this.o = new hk0();
        this.s = ac.c(null);
        this.u = ac.c(aw0.g);
        this.v = new k9(11);
        c80 c80Var = new c80((a80) slVar.k(e3.S));
        c80Var.r(new l(17, this));
        this.w = c80Var;
        this.x = slVar.i(g7Var).i(c80Var);
        this.y = new av0(5);
    }

    public static final void A(dw0 dw0Var, a80 a80Var) {
        synchronized (dw0Var.c) {
            Throwable th = dw0Var.e;
            if (th == null) {
                if (((aw0) dw0Var.u.getValue()).compareTo(aw0.f) > 0) {
                    if (dw0Var.d == null) {
                        dw0Var.d = a80Var;
                        if (dw0Var.D() != null) {
                            qj.a("called outside of runRecomposeAndApplyChanges");
                        }
                    } else {
                        throw new IllegalStateException("Recomposer already running");
                    }
                } else {
                    throw new IllegalStateException("Recomposer shut down");
                }
            } else {
                throw th;
            }
        }
    }

    public static void B(lk0 lk0Var) {
        try {
            if (!(lk0Var.w() instanceof i61)) {
                return;
            }
            throw new IllegalStateException("Unsupported concurrent change during composition. A state object was modified by composition as well as being modified outside composition.");
        } finally {
            lk0Var.c();
        }
    }

    public static final void M(ArrayList arrayList, dw0 dw0Var, yj yjVar) {
        arrayList.clear();
        synchronized (dw0Var.c) {
            Iterator it = dw0Var.k.iterator();
            if (it.hasNext()) {
                ((gj0) it.next()).getClass();
                throw null;
            }
        }
    }

    public static final Object w(dw0 dw0Var, cw0 cw0Var) {
        ne neVar;
        if (!dw0Var.H()) {
            ne neVar2 = new ne(1, ac.x(cw0Var));
            neVar2.t();
            synchronized (dw0Var.c) {
                if (dw0Var.H()) {
                    neVar = neVar2;
                } else {
                    dw0Var.r = neVar2;
                    neVar = null;
                }
            }
            if (neVar != null) {
                neVar.h(we1.a);
            }
            Object s = neVar2.s();
            if (s == cm.e) {
                return s;
            }
            return we1.a;
        }
        return we1.a;
    }

    public static final void x(dw0 dw0Var) {
        int i;
        ak0 ak0Var;
        synchronized (dw0Var.c) {
            try {
                if (dw0Var.l.j()) {
                    ak0 b = oj0.b(dw0Var.l);
                    dw0Var.l.a();
                    al alVar = dw0Var.m;
                    ((hk0) alVar.f).a();
                    ((hk0) alVar.g).a();
                    dw0Var.o.a();
                    ak0Var = new ak0(b.b);
                    Object[] objArr = b.a;
                    int i2 = b.b;
                    for (int i3 = 0; i3 < i2; i3++) {
                        gj0 gj0Var = (gj0) objArr[i3];
                        ak0Var.a(new zp0(gj0Var, dw0Var.n.g(gj0Var)));
                    }
                    dw0Var.n.a();
                } else {
                    ak0Var = tm0.b;
                    ak0Var.getClass();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        Object[] objArr2 = ak0Var.a;
        int i4 = ak0Var.b;
        for (i = 0; i < i4; i++) {
            zp0 zp0Var = (zp0) objArr2[i];
            gj0 gj0Var2 = (gj0) zp0Var.e;
            fj0 fj0Var = (fj0) zp0Var.f;
        }
    }

    public static final boolean y(dw0 dw0Var) {
        boolean E;
        synchronized (dw0Var.c) {
            E = dw0Var.E();
        }
        return E;
    }

    public static final List z(dw0 dw0Var) {
        List I;
        synchronized (dw0Var.c) {
            I = dw0Var.I();
        }
        return I;
    }

    public final void C() {
        synchronized (this.c) {
            if (((aw0) this.u.getValue()).compareTo(aw0.i) >= 0) {
                d81 d81Var = this.u;
                aw0 aw0Var = aw0.f;
                d81Var.getClass();
                d81Var.i(null, aw0Var);
            }
        }
        this.w.a(null);
    }

    public final le D() {
        d81 d81Var = this.u;
        int compareTo = ((aw0) d81Var.getValue()).compareTo(aw0.f);
        d81 d81Var2 = this.s;
        ArrayList arrayList = this.k;
        ArrayList arrayList2 = this.j;
        qk0 qk0Var = this.i;
        if (compareTo <= 0) {
            List I = I();
            int size = I.size();
            for (int i = 0; i < size; i++) {
                yj yjVar = (yj) I.get(i);
            }
            this.f.clear();
            this.g = ut.e;
            this.h = new ik0();
            qk0Var.g();
            arrayList2.clear();
            arrayList.clear();
            this.p = null;
            ne neVar = this.r;
            if (neVar != null) {
                neVar.l(null);
            }
            this.r = null;
            d81Var2.h(null);
            return null;
        }
        Object value = d81Var2.getValue();
        aw0 aw0Var = aw0.j;
        aw0 aw0Var2 = aw0.g;
        if (value == null) {
            if (this.d == null) {
                this.h = new ik0();
                qk0Var.g();
                if (E() || G()) {
                    aw0Var2 = aw0.h;
                }
            } else {
                aw0Var2 = (qk0Var.g != 0 || this.h.h() || !arrayList2.isEmpty() || !arrayList.isEmpty() || E() || G() || this.l.j()) ? aw0Var : aw0.i;
            }
        }
        d81Var.i(null, aw0Var2);
        if (aw0Var2 != aw0Var) {
            return null;
        }
        ne neVar2 = this.r;
        this.r = null;
        return neVar2;
    }

    public final boolean E() {
        if (!this.t && (((ca) ((pa) this.a.g).c).get() & 134217727) > 0) {
            return true;
        }
        return false;
    }

    public final boolean F() {
        if (this.i.g == 0 && !E() && !G() && !this.l.j()) {
            return false;
        }
        return true;
    }

    public final boolean G() {
        if (!this.t && (((ca) ((pa) this.b.g).c).get() & 134217727) > 0) {
            return true;
        }
        return false;
    }

    public final boolean H() {
        boolean z2;
        synchronized (this.c) {
            if (!this.h.h() && this.i.g == 0 && !E()) {
                if (!G()) {
                    z2 = false;
                }
            }
            z2 = true;
        }
        return z2;
    }

    public final List I() {
        List arrayList;
        List list = this.g;
        if (list != null) {
            return list;
        }
        ArrayList arrayList2 = this.f;
        if (arrayList2.isEmpty()) {
            arrayList = ut.e;
        } else {
            arrayList = new ArrayList(arrayList2);
        }
        this.g = arrayList;
        return arrayList;
    }

    public final void J() {
        le D;
        synchronized (this.c) {
            D = D();
            if (((aw0) this.u.getValue()).compareTo(aw0.f) <= 0) {
                Throwable th = this.e;
                CancellationException cancellationException = new CancellationException("Recomposer shutdown; frame clock awaiter will never resume");
                cancellationException.initCause(th);
                throw cancellationException;
            }
        }
        if (D != null) {
            ((ne) D).h(we1.a);
        }
    }

    public final void K() {
        synchronized (this.c) {
            this.t = true;
        }
    }

    public final void L(yj yjVar) {
        synchronized (this.c) {
            ArrayList arrayList = this.k;
            if (arrayList.size() > 0) {
                ((gj0) arrayList.get(0)).getClass();
                throw null;
            }
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:53:0x013a, code lost:
        r3 = r11.size();
        r4 = 0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:54:0x013f, code lost:
        if (r4 >= r3) goto L95;
     */
    /* JADX WARN: Code restructure failed: missing block: B:56:0x0149, code lost:
        if (((defpackage.zp0) r11.get(r4)).f == null) goto L62;
     */
    /* JADX WARN: Code restructure failed: missing block: B:57:0x014b, code lost:
        r4 = r4 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:58:0x014e, code lost:
        r3 = new java.util.ArrayList(r11.size());
        r4 = r11.size();
        r9 = 0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:59:0x015c, code lost:
        if (r9 >= r4) goto L71;
     */
    /* JADX WARN: Code restructure failed: missing block: B:60:0x015e, code lost:
        r12 = (defpackage.zp0) r11.get(r9);
     */
    /* JADX WARN: Code restructure failed: missing block: B:61:0x0166, code lost:
        if (r12.f != null) goto L70;
     */
    /* JADX WARN: Code restructure failed: missing block: B:62:0x0168, code lost:
        r12 = (defpackage.gj0) r12.e;
     */
    /* JADX WARN: Code restructure failed: missing block: B:65:0x016f, code lost:
        r9 = r9 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:66:0x0172, code lost:
        r4 = r18.c;
     */
    /* JADX WARN: Code restructure failed: missing block: B:67:0x0174, code lost:
        monitor-enter(r4);
     */
    /* JADX WARN: Code restructure failed: missing block: B:68:0x0175, code lost:
        defpackage.yg.O(r3, r18.k);
     */
    /* JADX WARN: Code restructure failed: missing block: B:69:0x017a, code lost:
        monitor-exit(r4);
     */
    /* JADX WARN: Code restructure failed: missing block: B:70:0x017b, code lost:
        r3 = new java.util.ArrayList(r11.size());
        r4 = r11.size();
        r9 = 0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:71:0x0189, code lost:
        if (r9 >= r4) goto L85;
     */
    /* JADX WARN: Code restructure failed: missing block: B:72:0x018b, code lost:
        r12 = r11.get(r9);
     */
    /* JADX WARN: Code restructure failed: missing block: B:73:0x0194, code lost:
        if (((defpackage.zp0) r12).f == null) goto L84;
     */
    /* JADX WARN: Code restructure failed: missing block: B:74:0x0196, code lost:
        r3.add(r12);
     */
    /* JADX WARN: Code restructure failed: missing block: B:75:0x0199, code lost:
        r9 = r9 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:76:0x019c, code lost:
        r11 = r3;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final List N(List list, ik0 ik0Var) {
        lk0 lk0Var;
        lk0 D;
        ArrayList arrayList;
        HashMap hashMap = new HashMap(list.size());
        int size = list.size();
        for (int i = 0; i < size; i++) {
            Object obj = list.get(i);
            ((gj0) obj).getClass();
            Object obj2 = hashMap.get(null);
            if (obj2 == null) {
                obj2 = new ArrayList();
                hashMap.put(null, obj2);
            }
            ((ArrayList) obj2).add(obj);
        }
        for (Map.Entry entry : hashMap.entrySet()) {
            yj yjVar = (yj) entry.getKey();
            List list2 = (List) entry.getValue();
            if (yjVar.z.F) {
                qj.a("Check failed");
            }
            l lVar = new l(16, yjVar);
            c cVar = new c(19, yjVar, ik0Var);
            g61 j = n61.j();
            if (j instanceof lk0) {
                lk0Var = (lk0) j;
            } else {
                lk0Var = null;
            }
            if (lk0Var != null && (D = lk0Var.D(lVar, cVar)) != null) {
                try {
                    g61 j2 = D.j();
                    synchronized (this.c) {
                        try {
                            arrayList = new ArrayList(list2.size());
                            int size2 = list2.size();
                            for (int i2 = 0; i2 < size2; i2++) {
                                gj0 gj0Var = (gj0) list2.get(i2);
                                hk0 hk0Var = this.l;
                                gj0Var.getClass();
                                Object a = oj0.a(hk0Var);
                                gj0 gj0Var2 = (gj0) a;
                                arrayList.add(new zp0(gj0Var, a));
                            }
                            int size3 = arrayList.size();
                            int i3 = 0;
                            while (true) {
                                if (i3 >= size3) {
                                    break;
                                }
                                zp0 zp0Var = (zp0) arrayList.get(i3);
                                if (zp0Var.f == null) {
                                    al alVar = this.m;
                                    ((gj0) zp0Var.e).getClass();
                                    if (((hk0) alVar.f).b(null)) {
                                        ArrayList arrayList2 = new ArrayList(arrayList.size());
                                        int size4 = arrayList.size();
                                        for (int i4 = 0; i4 < size4; i4++) {
                                            zp0 zp0Var2 = (zp0) arrayList.get(i4);
                                            if (zp0Var2.f == null) {
                                                al alVar2 = this.m;
                                                ((gj0) zp0Var2.e).getClass();
                                                hk0 hk0Var2 = (hk0) alVar2.f;
                                                ll0 ll0Var = (ll0) oj0.a(hk0Var2);
                                                if (hk0Var2.i()) {
                                                    ((hk0) alVar2.g).a();
                                                }
                                            }
                                            arrayList2.add(zp0Var2);
                                        }
                                        arrayList = arrayList2;
                                    }
                                }
                                i3++;
                            }
                        } finally {
                        }
                    }
                    int size5 = arrayList.size();
                    int i5 = 0;
                    while (true) {
                        if (i5 >= size5) {
                            break;
                        }
                        if (((zp0) arrayList.get(i5)).f != null) {
                            break;
                        }
                        i5++;
                    }
                    yjVar.r(arrayList);
                    g61.q(j2);
                } finally {
                    B(D);
                }
            } else {
                od.p("Cannot create a mutable snapshot of an read-only snapshot");
                return null;
            }
        }
        return tg.c0(hashMap.keySet());
    }

    public final yj O(yj yjVar, ik0 ik0Var) {
        lk0 lk0Var;
        lk0 D;
        if (yjVar.z.F || yjVar.A == 3) {
            return null;
        }
        ik0 ik0Var2 = this.q;
        if (ik0Var2 == null || !ik0Var2.c(yjVar)) {
            l lVar = new l(16, yjVar);
            c cVar = new c(19, yjVar, ik0Var);
            g61 j = n61.j();
            if (j instanceof lk0) {
                lk0Var = (lk0) j;
            } else {
                lk0Var = null;
            }
            if (lk0Var != null && (D = lk0Var.D(lVar, cVar)) != null) {
                try {
                    g61 j2 = D.j();
                    if (ik0Var != null && ik0Var.h()) {
                        va vaVar = new va(8, ik0Var, yjVar);
                        d10 d10Var = yjVar.z;
                        if (d10Var.F) {
                            qj.a("Preparing a composition while composing is not supported");
                        }
                        d10Var.F = true;
                        try {
                            vaVar.a();
                            d10Var.F = false;
                        } catch (Throwable th) {
                            d10Var.F = false;
                            throw th;
                        }
                    }
                    boolean w = yjVar.w();
                    g61.q(j2);
                    if (w) {
                        return yjVar;
                    }
                } finally {
                    B(D);
                }
            } else {
                od.p("Cannot create a mutable snapshot of an read-only snapshot");
            }
        }
        return null;
    }

    public final void P(Throwable th, yj yjVar) {
        if (((Boolean) A.get()).booleanValue() && !(th instanceof zi)) {
            synchronized (this.c) {
                try {
                    Log.e("ComposeInternal", "Error was captured in composition while live edit was enabled.", th);
                    this.j.clear();
                    this.i.g();
                    this.h = new ik0();
                    this.k.clear();
                    this.l.a();
                    this.n.a();
                    d81 d81Var = this.s;
                    zv0 zv0Var = new zv0(th);
                    d81Var.getClass();
                    d81Var.i(null, zv0Var);
                    if (yjVar != null) {
                        R(yjVar);
                    }
                    if (D() != null) {
                        qj.a("expected to go to inactive state due to composition error");
                    }
                } catch (Throwable th2) {
                    throw th2;
                }
            }
            return;
        }
        synchronized (this.c) {
            Log.e("ComposeInternal", "Error was captured in composition.", th);
            zv0 zv0Var2 = (zv0) this.s.getValue();
            if (zv0Var2 == null) {
                d81 d81Var2 = this.s;
                zv0 zv0Var3 = new zv0(th);
                d81Var2.getClass();
                d81Var2.i(null, zv0Var3);
            } else {
                throw zv0Var2.a;
            }
        }
        throw th;
    }

    public final boolean Q() {
        boolean F;
        synchronized (this.c) {
            if (this.h.g()) {
                return F();
            }
            List I = I();
            p01<Object> p01Var = new p01(this.h);
            this.h = new ik0();
            try {
                int size = I.size();
                for (int i = 0; i < size; i++) {
                    ((yj) I.get(i)).x(p01Var);
                    if (((aw0) this.u.getValue()).compareTo(aw0.f) <= 0) {
                        break;
                    }
                }
                synchronized (this.c) {
                    if (D() == null) {
                        F = F();
                    } else {
                        throw new IllegalStateException("called outside of runRecomposeAndApplyChanges");
                    }
                }
                return F;
            } catch (Throwable th) {
                synchronized (this.c) {
                    ik0 ik0Var = this.h;
                    ik0Var.getClass();
                    for (Object obj : p01Var) {
                        ik0Var.k(obj);
                    }
                    throw th;
                }
            }
        }
    }

    public final void R(yj yjVar) {
        ArrayList arrayList = this.p;
        if (arrayList == null) {
            arrayList = new ArrayList();
            this.p = arrayList;
        }
        if (!arrayList.contains(yjVar)) {
            arrayList.add(yjVar);
        }
        if (this.f.remove(yjVar)) {
            this.g = null;
        }
    }

    public final void S() {
        le leVar;
        synchronized (this.c) {
            if (this.t) {
                this.t = false;
                leVar = D();
            } else {
                leVar = null;
            }
        }
        if (leVar != null) {
            ((ne) leVar).h(we1.a);
        }
    }

    @Override // defpackage.sj
    public final void a(yj yjVar, m00 m00Var) {
        aw0 aw0Var;
        boolean z2;
        lk0 lk0Var;
        lk0 D;
        boolean z3 = yjVar.z.F;
        synchronized (this.c) {
            aw0Var = aw0.f;
            z2 = true;
            if (((aw0) this.u.getValue()).compareTo(aw0Var) > 0) {
                z2 = true ^ I().contains(yjVar);
            }
        }
        try {
            l lVar = new l(16, yjVar);
            c cVar = new c(19, yjVar, null);
            g61 j = n61.j();
            if (j instanceof lk0) {
                lk0Var = (lk0) j;
            } else {
                lk0Var = null;
            }
            if (lk0Var != null && (D = lk0Var.D(lVar, cVar)) != null) {
                g61 j2 = D.j();
                try {
                    yjVar.j(m00Var);
                    B(D);
                    synchronized (this.c) {
                        if (((aw0) this.u.getValue()).compareTo(aw0Var) > 0 && !I().contains(yjVar)) {
                            this.f.add(yjVar);
                            this.g = null;
                        }
                    }
                    if (!z3) {
                        n61.j().m();
                    }
                    try {
                        L(yjVar);
                        try {
                            yjVar.d();
                            yjVar.f();
                            if (!z3) {
                                n61.j().m();
                                return;
                            }
                            return;
                        } catch (Throwable th) {
                            P(th, null);
                            return;
                        }
                    } catch (Throwable th2) {
                        P(th2, yjVar);
                        return;
                    }
                } finally {
                    g61.q(j2);
                }
            }
            throw new IllegalStateException("Cannot create a mutable snapshot of an read-only snapshot");
        } catch (Throwable th3) {
            if (z2) {
                synchronized (this.c) {
                }
            }
            P(th3, yjVar);
        }
    }

    @Override // defpackage.sj
    public final ik0 b(yj yjVar, l51 l51Var, m00 m00Var) {
        k9 k9Var = this.v;
        try {
            l51 l51Var2 = yjVar.t;
            yjVar.t = l51Var;
            a(yjVar, m00Var);
            ik0 ik0Var = (ik0) k9Var.p();
            if (ik0Var == null) {
                ik0Var = o01.a;
                ik0Var.getClass();
            }
            yjVar.t = l51Var2;
            return ik0Var;
        } finally {
            k9Var.A(null);
        }
    }

    @Override // defpackage.sj
    public final boolean d() {
        return ((Boolean) A.get()).booleanValue();
    }

    @Override // defpackage.sj
    public final boolean e() {
        return false;
    }

    @Override // defpackage.sj
    public final boolean f() {
        return false;
    }

    @Override // defpackage.sj
    public final long g() {
        return 1000L;
    }

    @Override // defpackage.sj
    public final rj h() {
        return null;
    }

    @Override // defpackage.sj
    public final sl j() {
        return this.x;
    }

    @Override // defpackage.sj
    public final boolean k() {
        return false;
    }

    @Override // defpackage.sj
    public final void l(yj yjVar) {
        le leVar;
        synchronized (this.c) {
            if (!this.i.h(yjVar)) {
                this.i.b(yjVar);
                leVar = D();
            } else {
                leVar = null;
            }
        }
        if (leVar != null) {
            ((ne) leVar).h(we1.a);
        }
    }

    @Override // defpackage.sj
    public final fj0 m(gj0 gj0Var) {
        fj0 fj0Var;
        synchronized (this.c) {
            fj0Var = (fj0) this.n.k(gj0Var);
        }
        return fj0Var;
    }

    @Override // defpackage.sj
    public final ik0 n(yj yjVar, l51 l51Var, ik0 ik0Var) {
        k9 k9Var = this.v;
        try {
            Q();
            yjVar.x(new p01(ik0Var));
            l51 l51Var2 = yjVar.t;
            yjVar.t = l51Var;
            yj O = O(yjVar, null);
            if (O != null) {
                L(yjVar);
                O.d();
                O.f();
            }
            ik0 ik0Var2 = (ik0) k9Var.p();
            if (ik0Var2 == null) {
                ik0Var2 = o01.a;
                ik0Var2.getClass();
            }
            yjVar.t = l51Var2;
            return ik0Var2;
        } finally {
            k9Var.A(null);
        }
    }

    @Override // defpackage.sj
    public final void o(Set set) {
    }

    @Override // defpackage.sj
    public final void q(xv0 xv0Var) {
        k9 k9Var = this.v;
        ik0 ik0Var = (ik0) k9Var.p();
        if (ik0Var == null) {
            ik0 ik0Var2 = o01.a;
            ik0Var = new ik0();
            k9Var.A(ik0Var);
        }
        ik0Var.a(xv0Var);
    }

    @Override // defpackage.sj
    public final void r(yj yjVar) {
        synchronized (this.c) {
            try {
                ik0 ik0Var = this.q;
                if (ik0Var == null) {
                    ik0 ik0Var2 = o01.a;
                    ik0Var = new ik0();
                    this.q = ik0Var;
                }
                ik0Var.a(yjVar);
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v0, types: [oa, java.lang.Object, zl0] */
    @Override // defpackage.sj
    public final oe s(f8 f8Var) {
        k9 k9Var = this.b;
        ?? obj = new Object();
        obj.a = f8Var;
        return ((pa) k9Var.g).d(obj, (va) k9Var.h);
    }

    @Override // defpackage.sj
    public final void v(yj yjVar) {
        synchronized (this.c) {
            if (this.f.remove(yjVar)) {
                this.g = null;
            }
            this.i.j(yjVar);
            this.j.remove(yjVar);
        }
    }
}