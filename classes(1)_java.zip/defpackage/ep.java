package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ep  reason: default package */
public final /* synthetic */ class ep implements xz {
    public final /* synthetic */ int e;
    public final /* synthetic */ fp f;

    public /* synthetic */ ep(fp fpVar, int i) {
        this.e = i;
        this.f = fpVar;
    }

    @Override // defpackage.xz
    public final Object a() {
        int i = this.e;
        fp fpVar = this.f;
        switch (i) {
            case 0:
                cy0 cy0Var = (cy0) j70.z(fpVar, fy0.a);
                return j70.e;
            default:
                cy0 cy0Var2 = (cy0) j70.z(fpVar, fy0.a);
                y6 y6Var = fpVar.y;
                if (cy0Var2 == null) {
                    if (y6Var != null) {
                        fpVar.s0(y6Var);
                    }
                    fpVar.y = null;
                } else if (y6Var == null) {
                    pg0 pg0Var = new pg0(13, fpVar);
                    ep epVar = new ep(fpVar, 0);
                    uj0 uj0Var = fpVar.u;
                    boolean z = fpVar.v;
                    float f = fpVar.w;
                    td1 td1Var = gy0.a;
                    y6 y6Var2 = new y6(uj0Var, z, f, pg0Var, epVar);
                    fpVar.r0(y6Var2);
                    fpVar.y = y6Var2;
                }
                return we1.a;
        }
    }
}