package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cv  reason: default package */
public final class cv {
    public final yv a;

    public cv(yv yvVar) {
        this.a = yvVar;
    }

    public final boolean equals(Object obj) {
        if (this != obj) {
            if (obj instanceof cv) {
                cv cvVar = (cv) obj;
                if (Float.compare(0.0f, 0.0f) != 0 || !k70.p(this.a, cvVar.a)) {
                    return false;
                }
                return true;
            }
            return false;
        }
        return true;
    }

    public final int hashCode() {
        return this.a.hashCode() + (Float.floatToIntBits(0.0f) * 31);
    }

    public final String toString() {
        return "Fade(alpha=0.0, animationSpec=" + this.a + ')';
    }
}