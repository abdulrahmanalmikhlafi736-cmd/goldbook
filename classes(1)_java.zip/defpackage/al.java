package defpackage;

import android.graphics.Insets;
import android.os.Build;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableString;
import android.view.View;
import android.view.WindowInsetsAnimation;
import android.view.autofill.AutofillId;
import android.view.contentcapture.ContentCaptureSession;
import java.lang.ref.Reference;
import java.lang.ref.ReferenceQueue;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: al  reason: default package */
public final class al implements lt, tw, i91, oe, yo0, a01 {
    public final /* synthetic */ int e;
    public Object f;
    public Object g;

    public al(int i) {
        this.e = i;
        switch (i) {
            case 10:
                this.f = new ig1(0);
                this.g = new ig1(0);
                return;
            case 11:
                this.f = mc0.t(Boolean.FALSE);
                return;
            case 13:
                this.f = new hk0();
                this.g = new hk0();
                return;
            case 14:
                this.f = new qk0(new ba0[16]);
                return;
            case 18:
                this.f = new LinkedHashMap();
                this.g = new LinkedHashMap();
                return;
            case 23:
                this.f = new av0(16);
                this.g = new ig0(16);
                return;
            case 24:
                this.f = new qk0(new Reference[16]);
                this.g = new ReferenceQueue();
                return;
            default:
                return;
        }
    }

    public static void m(ba0 ba0Var) {
        if (ba0Var.T > 0) {
            if (ba0Var.K.d == x90.i && !ba0Var.p() && !ba0Var.q() && !ba0Var.U && ba0Var.I()) {
                li0 li0Var = ba0Var.J.f;
                if ((li0Var.h & 256) != 0) {
                    while (li0Var != null) {
                        if ((li0Var.g & 256) != 0) {
                            li0 li0Var2 = li0Var;
                            qk0 qk0Var = null;
                            while (li0Var2 != null) {
                                if (li0Var2 instanceof q10) {
                                    q10 q10Var = (q10) li0Var2;
                                    q10Var.o(k70.M(q10Var, 256));
                                } else if ((li0Var2.g & 256) != 0 && (li0Var2 instanceof dp)) {
                                    int i = 0;
                                    for (li0 li0Var3 = ((dp) li0Var2).t; li0Var3 != null; li0Var3 = li0Var3.j) {
                                        if ((li0Var3.g & 256) != 0) {
                                            i++;
                                            if (i == 1) {
                                                li0Var2 = li0Var3;
                                            } else {
                                                if (qk0Var == null) {
                                                    qk0Var = new qk0(new li0[16]);
                                                }
                                                if (li0Var2 != null) {
                                                    qk0Var.b(li0Var2);
                                                    li0Var2 = null;
                                                }
                                                qk0Var.b(li0Var3);
                                            }
                                        }
                                    }
                                    if (i == 1) {
                                    }
                                }
                                li0Var2 = k70.m(qk0Var);
                            }
                        }
                        if ((li0Var.h & 256) == 0) {
                            break;
                        }
                        li0Var = li0Var.j;
                    }
                }
            }
            ba0Var.S = false;
            qk0 z = ba0Var.z();
            Object[] objArr = z.e;
            int i2 = z.g;
            for (int i3 = 0; i3 < i2; i3++) {
                m((ba0) objArr[i3]);
            }
        }
    }

    @Override // defpackage.lt
    public Object a() {
        return (bf1) this.f;
    }

    /* JADX WARN: Removed duplicated region for block: B:12:0x002c  */
    /* JADX WARN: Removed duplicated region for block: B:19:0x003b  */
    /* JADX WARN: Removed duplicated region for block: B:27:0x005d  */
    /* JADX WARN: Removed duplicated region for block: B:29:0x0066  */
    /* JADX WARN: Removed duplicated region for block: B:42:0x009d  */
    /* JADX WARN: Removed duplicated region for block: B:51:0x00b6  */
    /* JADX WARN: Removed duplicated region for block: B:84:? A[RETURN, SYNTHETIC] */
    @Override // defpackage.tw
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public Object b(uw uwVar, ml mlVar) {
        zw zwVar;
        int i;
        Throwable th;
        yy0 yy0Var;
        bn bnVar;
        al alVar;
        bx bxVar;
        int i2;
        xq xqVar;
        int i3 = this.e;
        we1 we1Var = we1.a;
        cm cmVar = cm.e;
        switch (i3) {
            case 3:
                if (mlVar instanceof zw) {
                    zwVar = (zw) mlVar;
                    int i4 = zwVar.i;
                    if ((i4 & Integer.MIN_VALUE) != 0) {
                        zwVar.i = i4 - Integer.MIN_VALUE;
                        Object obj = zwVar.h;
                        i = zwVar.i;
                        if (i == 0) {
                            if (i != 1) {
                                if (i == 2) {
                                    nb0.t(obj);
                                    return we1Var;
                                }
                                od.p("call to 'resume' before 'invoke' with coroutine");
                                return null;
                            }
                            yy0Var = zwVar.m;
                            uwVar = zwVar.l;
                            alVar = zwVar.k;
                            try {
                                nb0.t(obj);
                            } catch (Throwable th2) {
                                th = th2;
                                yy0Var.q();
                                throw th;
                            }
                        } else {
                            nb0.t(obj);
                            sl slVar = zwVar.f;
                            slVar.getClass();
                            yy0 yy0Var2 = new yy0(uwVar, slVar);
                            try {
                                bnVar = (bn) this.f;
                            } catch (Throwable th3) {
                                th = th3;
                            }
                            try {
                                zwVar.k = this;
                                zwVar.l = uwVar;
                                zwVar.m = yy0Var2;
                                zwVar.i = 1;
                                if (bnVar.f(yy0Var2, zwVar) != cmVar) {
                                    alVar = this;
                                    yy0Var = yy0Var2;
                                }
                                return cmVar;
                            } catch (Throwable th4) {
                                th = th4;
                                yy0Var = yy0Var2;
                                yy0Var.q();
                                throw th;
                            }
                        }
                        yy0Var.q();
                        zwVar.k = null;
                        zwVar.l = null;
                        zwVar.m = null;
                        zwVar.i = 2;
                        if (((tw) alVar.g).b(uwVar, zwVar) != cmVar) {
                            return we1Var;
                        }
                        return cmVar;
                    }
                }
                zwVar = new zw(this, mlVar);
                Object obj2 = zwVar.h;
                i = zwVar.i;
                if (i == 0) {
                }
                yy0Var.q();
                zwVar.k = null;
                zwVar.l = null;
                zwVar.m = null;
                zwVar.i = 2;
                if (((tw) alVar.g).b(uwVar, zwVar) != cmVar) {
                }
                return cmVar;
            case gu0.LONG_FIELD_NUMBER /* 4 */:
                Object b = ((tw) this.f).b(new g8(new Object(), uwVar, (m00) this.g, 2), mlVar);
                if (b == cmVar) {
                    return b;
                }
                return we1Var;
            default:
                if (mlVar instanceof bx) {
                    bxVar = (bx) mlVar;
                    int i5 = bxVar.i;
                    if ((i5 & Integer.MIN_VALUE) != 0) {
                        bxVar.i = i5 - Integer.MIN_VALUE;
                        Object obj3 = bxVar.h;
                        i2 = bxVar.i;
                        if (i2 == 0) {
                            if (i2 == 1) {
                                xqVar = bxVar.k;
                                try {
                                    nb0.t(obj3);
                                    return we1Var;
                                } catch (a e) {
                                    e = e;
                                }
                            } else {
                                od.p("call to 'resume' before 'invoke' with coroutine");
                                return null;
                            }
                        } else {
                            nb0.t(obj3);
                            al alVar2 = (al) this.f;
                            xq xqVar2 = new xq(1, (cn) this.g, uwVar);
                            try {
                                bxVar.k = xqVar2;
                                bxVar.i = 1;
                                if (alVar2.b(xqVar2, bxVar) == cmVar) {
                                    return cmVar;
                                }
                                return we1Var;
                            } catch (a e2) {
                                e = e2;
                                xqVar = xqVar2;
                            }
                        }
                        if (e.e != xqVar) {
                            sl slVar2 = bxVar.f;
                            slVar2.getClass();
                            j70.B(slVar2);
                            return we1Var;
                        }
                        throw e;
                    }
                }
                bxVar = new bx(this, mlVar);
                Object obj32 = bxVar.h;
                i2 = bxVar.i;
                if (i2 == 0) {
                }
                if (e.e != xqVar) {
                }
        }
    }

    @Override // defpackage.oe
    public void cancel() {
        if (!((ca) this.g).compareAndSet(1, 1)) {
            ((na) this.f).a();
        }
    }

    @Override // defpackage.yo0
    public List d(Integer num) {
        List d = ((yo0) this.f).d(null);
        a61 a61Var = (a61) this.g;
        int i = a61Var.v;
        if (i < 0) {
            return d;
        }
        return tg.Z(wl1.p(a61Var, num, i, Integer.valueOf(a61Var.E(a61Var.b, i))), d);
    }

    @Override // defpackage.a01
    public Object e(Object obj) {
        return ((i00) this.g).i(obj);
    }

    @Override // defpackage.i91
    public void f(h91 h91Var) {
        int i;
        zj0 zj0Var = (zj0) this.g;
        zj0Var.a();
        bk0 bk0Var = (bk0) h91Var.f;
        Object[] objArr = bk0Var.b;
        long[] jArr = bk0Var.c;
        int i2 = bk0Var.e;
        while (i2 != Integer.MAX_VALUE) {
            int i3 = (int) ((jArr[i2] >> 31) & 2147483647L);
            Object obj = objArr[i2];
            Object b = ((hb0) this.f).b(obj);
            int d = zj0Var.d(b);
            if (d >= 0) {
                i = zj0Var.c[d];
            } else {
                i = 0;
            }
            if (i == 7) {
                h91Var.remove(obj);
            } else {
                zj0Var.g(i + 1, b);
            }
            i2 = i3;
        }
    }

    @Override // defpackage.lt
    public boolean g(CharSequence charSequence, int i, int i2, fe1 fe1Var) {
        Spannable spannableString;
        if ((fe1Var.c & 4) > 0) {
            return true;
        }
        if (((bf1) this.f) == null) {
            if (charSequence instanceof Spannable) {
                spannableString = (Spannable) charSequence;
            } else {
                spannableString = new SpannableString(charSequence);
            }
            this.f = new bf1(spannableString);
        }
        ((vj) this.g).getClass();
        ((bf1) this.f).setSpan(new ge1(fe1Var), i, i2, 33);
        return true;
    }

    @Override // defpackage.yo0
    public boolean h() {
        return ((yo0) this.f).h();
    }

    @Override // defpackage.i91
    public boolean i(Object obj, Object obj2) {
        hb0 hb0Var = (hb0) this.f;
        return k70.p(hb0Var.b(obj), hb0Var.b(obj2));
    }

    @Override // defpackage.a01
    public Object j(iz0 iz0Var, Object obj) {
        return ((m00) this.f).f(iz0Var, obj);
    }

    public Bundle k(String str) {
        Bundle bundle;
        wz0 wz0Var = (wz0) this.f;
        if (wz0Var.g) {
            Bundle bundle2 = wz0Var.f;
            if (bundle2 == null) {
                return null;
            }
            if (bundle2.containsKey(str)) {
                bundle = kb0.n(bundle2, str);
            } else {
                bundle = null;
            }
            bundle2.remove(str);
            if (bundle2.isEmpty()) {
                wz0Var.f = null;
            }
            return bundle;
        }
        od.p("You can 'consumeRestoredStateForKey' only after the corresponding component has moved to the 'CREATED' state");
        return null;
    }

    /* JADX WARN: Code restructure failed: missing block: B:5:0x0017, code lost:
        if (r3 < r1) goto L22;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public void l() {
        ba0[] ba0VarArr;
        qk0 qk0Var = (qk0) this.f;
        Arrays.sort(qk0Var.e, 0, qk0Var.g, uy.d);
        int i = qk0Var.g;
        ba0[] ba0VarArr2 = (ba0[]) this.g;
        if (ba0VarArr2 != null) {
            int length = ba0VarArr2.length;
            ba0VarArr = ba0VarArr2;
        }
        ba0VarArr = new ba0[Math.max(16, i)];
        this.g = null;
        for (int i2 = 0; i2 < i; i2++) {
            ba0VarArr[i2] = qk0Var.e[i2];
        }
        qk0Var.g();
        while (true) {
            i--;
            if (-1 < i) {
                ba0 ba0Var = ba0VarArr[i];
                ba0Var.getClass();
                if (ba0Var.S) {
                    m(ba0Var);
                }
                ba0VarArr[i] = null;
            } else {
                this.g = ba0VarArr;
                return;
            }
        }
    }

    public mh0 n() {
        return (mh0) ((lq0) this.g).getValue();
    }

    public vz0 o(String str) {
        vz0 vz0Var;
        wz0 wz0Var = (wz0) this.f;
        synchronized (wz0Var.c) {
            Iterator it = wz0Var.d.entrySet().iterator();
            do {
                vz0Var = null;
                if (!it.hasNext()) {
                    break;
                }
                Map.Entry entry = (Map.Entry) it.next();
                vz0 vz0Var2 = (vz0) entry.getValue();
                if (k70.p((String) entry.getKey(), str)) {
                    vz0Var = vz0Var2;
                    continue;
                }
            } while (vz0Var == null);
        }
        return vz0Var;
    }

    public AutofillId p(long j) {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentCaptureSession e = s3.e(this.f);
            k1 m = sb0.m((View) this.g);
            Objects.requireNonNull(m);
            return zk.b(e, ga.d(m.a), j);
        }
        return null;
    }

    public void q(Bundle bundle) {
        wz0 wz0Var = (wz0) this.f;
        xz0 xz0Var = wz0Var.a;
        if (!wz0Var.e) {
            wz0Var.a();
        }
        if (xz0Var.g().d.compareTo(jd0.h) < 0) {
            if (!wz0Var.g) {
                Bundle bundle2 = null;
                if (bundle != null && bundle.containsKey("androidx.lifecycle.BundlableSavedStateRegistry.key")) {
                    bundle2 = kb0.n(bundle, "androidx.lifecycle.BundlableSavedStateRegistry.key");
                }
                wz0Var.f = bundle2;
                wz0Var.g = true;
                return;
            }
            od.p("SavedStateRegistry was already restored.");
            return;
        }
        jd0 jd0Var = xz0Var.g().d;
        throw new IllegalStateException(("performRestore cannot be called when owner is " + jd0Var).toString());
    }

    public void r(Bundle bundle) {
        wz0 wz0Var = (wz0) this.f;
        Bundle j = a5.j((zp0[]) Arrays.copyOf(new zp0[0], 0));
        Bundle bundle2 = wz0Var.f;
        if (bundle2 != null) {
            j.putAll(bundle2);
        }
        synchronized (wz0Var.c) {
            for (Map.Entry entry : wz0Var.d.entrySet()) {
                String str = (String) entry.getKey();
                Bundle a = ((vz0) entry.getValue()).a();
                str.getClass();
                j.putBundle(str, a);
            }
        }
        if (!j.isEmpty()) {
            bundle.putBundle("androidx.lifecycle.BundlableSavedStateRegistry.key", j);
        }
    }

    public void s(String str, vz0 vz0Var) {
        vz0Var.getClass();
        wz0 wz0Var = (wz0) this.f;
        synchronized (wz0Var.c) {
            if (!wz0Var.d.containsKey(str)) {
                wz0Var.d.put(str, vz0Var);
            } else {
                throw new IllegalArgumentException("SavedStateProvider with the given key is already registered");
            }
        }
    }

    public void t() {
        if (((wz0) this.f).h) {
            ew0 ew0Var = (ew0) this.g;
            if (ew0Var == null) {
                ew0Var = new ew0(this);
            }
            this.g = ew0Var;
            try {
                cd0.class.getDeclaredConstructor(null);
                ew0 ew0Var2 = (ew0) this.g;
                if (ew0Var2 != null) {
                    ew0Var2.a.add(cd0.class.getName());
                    return;
                }
                return;
            } catch (NoSuchMethodException e) {
                String simpleName = cd0.class.getSimpleName();
                throw new IllegalArgumentException("Class " + simpleName + " must have default constructor in order to be automatically recreated", e);
            }
        }
        od.p("Can not perform this action after onSaveInstanceState");
    }

    public String toString() {
        switch (this.e) {
            case 25:
                return "Bounds{lower=" + ((c60) this.f) + " upper=" + ((c60) this.g) + "}";
            default:
                return super.toString();
        }
    }

    public al(xz xzVar, i00 i00Var) {
        this.e = 2;
        i00Var.getClass();
        this.f = i00Var;
        this.g = xzVar;
    }

    public al(wz0 wz0Var, int i) {
        this.e = i;
        switch (i) {
            case 20:
                this.f = wz0Var;
                this.g = new al(wz0Var, 19);
                return;
            default:
                this.f = wz0Var;
                return;
        }
    }

    public /* synthetic */ al(int i, Object obj, Object obj2) {
        this.e = i;
        this.f = obj;
        this.g = obj2;
    }

    public al(ba0 ba0Var, mh0 mh0Var) {
        this.e = 6;
        this.f = ba0Var;
        this.g = mc0.t(mh0Var);
    }

    public al(na naVar) {
        this.e = 15;
        this.f = naVar;
        this.g = new AtomicInteger(0);
    }

    public al(hb0 hb0Var) {
        this.e = 7;
        this.f = hb0Var;
        zj0 zj0Var = sm0.a;
        this.g = new zj0();
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public al(Object obj) {
        this(11);
        this.e = 11;
        this.g = mc0.t(obj);
        mc0.t(obj);
    }

    public al(WindowInsetsAnimation.Bounds bounds) {
        Insets lowerBound;
        Insets upperBound;
        this.e = 25;
        lowerBound = bounds.getLowerBound();
        this.f = c60.c(lowerBound);
        upperBound = bounds.getUpperBound();
        this.g = c60.c(upperBound);
    }
}