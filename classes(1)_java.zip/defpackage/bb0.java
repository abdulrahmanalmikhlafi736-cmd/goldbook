package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bb0  reason: default package */
public final class bb0 extends li0 implements t90 {
    public static final za0 v = new Object();
    public ec0 s;
    public sc t;
    public bp0 u;

    @Override // defpackage.t90
    public final /* synthetic */ int G(bg0 bg0Var, hh0 hh0Var, int i) {
        return fu0.i(this, bg0Var, hh0Var, i);
    }

    @Override // defpackage.t90
    public final nh0 U(oh0 oh0Var, hh0 hh0Var, long j) {
        ks0 e = hh0Var.e(j);
        return oh0Var.O(e.e, e.f, vt.e, new vv(e, 1));
    }

    @Override // defpackage.t90
    public final /* synthetic */ int d(bg0 bg0Var, hh0 hh0Var, int i) {
        return fu0.d(this, bg0Var, hh0Var, i);
    }

    @Override // defpackage.t90
    public final /* synthetic */ int h(bg0 bg0Var, hh0 hh0Var, int i) {
        return fu0.b(this, bg0Var, hh0Var, i);
    }

    /* JADX WARN: Code restructure failed: missing block: B:16:0x001b, code lost:
        if (r4.u == defpackage.bp0.e) goto L19;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x000d, code lost:
        if (r4.u == defpackage.bp0.f) goto L19;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean r0(xa0 xa0Var, int i) {
        if (i != 5 && i != 6) {
            if (i != 3 && i != 4) {
                if (i != 1 && i != 2) {
                    od.p("Lazy list does not support beyond bounds layout for the specified direction");
                    return false;
                }
            }
            if (!s0(i) ? xa0Var.a <= 0 : xa0Var.b >= this.s.a.g().n - 1) {
                return false;
            }
            return true;
        }
    }

    public final boolean s0(int i) {
        if (i == 1) {
            return false;
        }
        if (i == 2) {
            return true;
        }
        if (i == 5) {
            return false;
        }
        if (i == 6) {
            return true;
        }
        if (i == 3) {
            int ordinal = k70.O(this).D.ordinal();
            if (ordinal == 0) {
                return false;
            }
            if (ordinal == 1) {
                return true;
            }
            od.k();
            return false;
        } else if (i == 4) {
            int ordinal2 = k70.O(this).D.ordinal();
            if (ordinal2 == 0) {
                return true;
            }
            if (ordinal2 == 1) {
                return false;
            }
            od.k();
            return false;
        } else {
            od.p("Lazy list does not support beyond bounds layout for the specified direction");
            return false;
        }
    }

    @Override // defpackage.t90
    public final /* synthetic */ int t(bg0 bg0Var, hh0 hh0Var, int i) {
        return fu0.g(this, bg0Var, hh0Var, i);
    }
}