package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: b90  reason: default package */
public interface b90 {
    Object a(wy0 wy0Var);

    h31 b();
}