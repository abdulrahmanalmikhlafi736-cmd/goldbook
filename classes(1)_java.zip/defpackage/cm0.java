package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cm0  reason: default package */
public final class cm0 {
    public li0 a;
    public int b;
    public qk0 c;
    public qk0 d;
    public boolean e;
    public final /* synthetic */ em0 f;

    public cm0(em0 em0Var, li0 li0Var, int i, qk0 qk0Var, qk0 qk0Var2, boolean z) {
        this.f = em0Var;
        this.a = li0Var;
        this.b = i;
        this.c = qk0Var;
        this.d = qk0Var2;
        this.e = z;
    }

    public final boolean a(int i, int i2) {
        qk0 qk0Var = this.c;
        int i3 = this.b;
        ki0 ki0Var = (ki0) qk0Var.e[i + i3];
        ki0 ki0Var2 = (ki0) this.d.e[i3 + i2];
        if (k70.p(ki0Var, ki0Var2) || ki0Var.getClass() == ki0Var2.getClass()) {
            return true;
        }
        return false;
    }
}