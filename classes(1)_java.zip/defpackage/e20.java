package defpackage;

import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;
import android.widget.Toast;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: e20  reason: default package */
public final /* synthetic */ class e20 implements xz {
    public final /* synthetic */ int e;
    public final /* synthetic */ Context f;
    public final /* synthetic */ mk0 g;

    public /* synthetic */ e20(Context context, mk0 mk0Var, int i) {
        this.e = i;
        this.f = context;
        this.g = mk0Var;
    }

    @Override // defpackage.xz
    public final Object a() {
        Object px0Var;
        Object px0Var2;
        int i = this.e;
        we1 we1Var = we1.a;
        mk0 mk0Var = this.g;
        Context context = this.f;
        switch (i) {
            case 0:
                Toast.makeText(context, context.getResources().getString(2131361939), 0).show();
                mk0Var.setValue("messages");
                return we1Var;
            case 1:
                mk0Var.setValue(Boolean.FALSE);
                try {
                    PackageManager packageManager = context.getPackageManager();
                    String packageName = context.getPackageName();
                    packageManager.setComponentEnabledSetting(new ComponentName(context, packageName + ".LauncherAlias"), 2, 1);
                    px0Var = Boolean.TRUE;
                } catch (Throwable th) {
                    px0Var = new px0(th);
                }
                Object obj = Boolean.FALSE;
                if (px0Var instanceof px0) {
                    px0Var = obj;
                }
                Boolean bool = (Boolean) px0Var;
                return we1Var;
            default:
                if (mc0.q(context)) {
                    try {
                        PackageManager packageManager2 = context.getPackageManager();
                        String packageName2 = context.getPackageName();
                        packageManager2.setComponentEnabledSetting(new ComponentName(context, packageName2 + ".LauncherAlias"), 1, 1);
                        px0Var2 = Boolean.TRUE;
                    } catch (Throwable th2) {
                        px0Var2 = new px0(th2);
                    }
                    Object obj2 = Boolean.FALSE;
                    if (px0Var2 instanceof px0) {
                        px0Var2 = obj2;
                    }
                    Boolean bool2 = (Boolean) px0Var2;
                } else {
                    mk0Var.setValue(Boolean.TRUE);
                }
                return we1Var;
        }
    }
}