package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cr  reason: default package */
public final class cr implements pl {
    public final float a;

    public cr(float f) {
        this.a = f;
    }

    @Override // defpackage.pl
    public final float a(long j, jp jpVar) {
        return jpVar.q(this.a);
    }

    public final boolean equals(Object obj) {
        if (this != obj) {
            if (!(obj instanceof cr) || !br.b(this.a, ((cr) obj).a)) {
                return false;
            }
            return true;
        }
        return true;
    }

    public final int hashCode() {
        return Float.floatToIntBits(this.a);
    }

    public final String toString() {
        return "CornerSize(size = " + this.a + ".dp)";
    }
}