package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: c51  reason: default package */
public final class c51 {
    public final oy0 a;
    public final oy0 b;
    public final oy0 c;
    public final oy0 d;
    public final oy0 e;
    public final oy0 f;
    public final oy0 g;
    public final oy0 h;

    public c51() {
        oy0 oy0Var = z41.a;
        oy0 oy0Var2 = z41.b;
        oy0 oy0Var3 = z41.c;
        oy0 oy0Var4 = z41.d;
        oy0 oy0Var5 = z41.f;
        oy0 oy0Var6 = z41.e;
        oy0 oy0Var7 = z41.g;
        oy0 oy0Var8 = z41.h;
        this.a = oy0Var;
        this.b = oy0Var2;
        this.c = oy0Var3;
        this.d = oy0Var4;
        this.e = oy0Var5;
        this.f = oy0Var6;
        this.g = oy0Var7;
        this.h = oy0Var8;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof c51)) {
            return false;
        }
        c51 c51Var = (c51) obj;
        if (k70.p(this.a, c51Var.a) && k70.p(this.b, c51Var.b) && k70.p(this.c, c51Var.c) && k70.p(this.d, c51Var.d) && k70.p(this.e, c51Var.e) && k70.p(this.f, c51Var.f) && k70.p(this.g, c51Var.g) && k70.p(this.h, c51Var.h)) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        int hashCode = this.b.hashCode();
        int hashCode2 = this.c.hashCode();
        int hashCode3 = this.d.hashCode();
        int hashCode4 = this.e.hashCode();
        int hashCode5 = this.f.hashCode();
        int hashCode6 = this.g.hashCode();
        return this.h.hashCode() + ((hashCode6 + ((hashCode5 + ((hashCode4 + ((hashCode3 + ((hashCode2 + ((hashCode + (this.a.hashCode() * 31)) * 31)) * 31)) * 31)) * 31)) * 31)) * 31);
    }

    public final String toString() {
        return "Shapes(extraSmall=" + this.a + ", small=" + this.b + ", medium=" + this.c + ", large=" + this.d + ", largeIncreased=" + this.f + ", extraLarge=" + this.e + ", extralargeIncreased=" + this.g + ", extraExtraLarge=" + this.h + ')';
    }
}