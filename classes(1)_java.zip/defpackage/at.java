package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: at  reason: default package */
public final class at {
    public final dt a;
    public volatile k9 b;
    public volatile p3 c;

    public at(dt dtVar) {
        this.a = dtVar;
    }
}