package defpackage;

import android.content.Context;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: di1  reason: default package */
public final class di1 {
    public final Context a;

    public di1(Context context) {
        context.getClass();
        this.a = context;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if ((obj instanceof di1) && k70.p(this.a, ((di1) obj).a)) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        return this.a.hashCode();
    }

    public final String toString() {
        return "WebViewFactoryParam(context=" + this.a + ")";
    }
}