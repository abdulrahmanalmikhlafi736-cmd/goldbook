package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ag  reason: default package */
public final class ag extends qi0 implements e21 {
    public final i00 a;

    public ag(i00 i00Var) {
        this.a = i00Var;
    }

    @Override // defpackage.e21
    public final d21 c() {
        d21 d21Var = new d21();
        d21Var.g = false;
        d21Var.h = true;
        this.a.i(d21Var);
        return d21Var;
    }

    @Override // defpackage.qi0
    public final li0 e() {
        return new ol(false, true, this.a);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof ag)) {
            return false;
        }
        if (this.a == ((ag) obj).a) {
            return true;
        }
        return false;
    }

    @Override // defpackage.qi0
    public final void f(li0 li0Var) {
        ((ol) li0Var).u = this.a;
    }

    public final int hashCode() {
        return this.a.hashCode();
    }
}