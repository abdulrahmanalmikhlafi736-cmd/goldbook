package defpackage;

import android.widget.FrameLayout;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: d2  reason: default package */
public final class d2 implements n00 {
    public final /* synthetic */ wi1 e;
    public final /* synthetic */ boolean f;
    public final /* synthetic */ ui1 g;
    public final /* synthetic */ i00 h;
    public final /* synthetic */ i00 i;
    public final /* synthetic */ w1 j;
    public final /* synthetic */ v1 k;
    public final /* synthetic */ i00 l;

    public d2(wi1 wi1Var, boolean z, ui1 ui1Var, i00 i00Var, i00 i00Var2, w1 w1Var, v1 v1Var, i00 i00Var3) {
        this.e = wi1Var;
        this.f = z;
        this.g = ui1Var;
        this.h = i00Var;
        this.i = i00Var2;
        this.j = w1Var;
        this.k = v1Var;
        this.l = i00Var3;
    }

    @Override // defpackage.n00
    public final Object c(Object obj, Object obj2, Object obj3) {
        int i;
        int i2;
        oc ocVar = (oc) obj;
        d10 d10Var = (d10) obj2;
        int intValue = ((Number) obj3).intValue();
        ocVar.getClass();
        long j = ocVar.b;
        if ((intValue & 6) == 0) {
            if (d10Var.f(ocVar)) {
                i2 = 4;
            } else {
                i2 = 2;
            }
            intValue |= i2;
        }
        if ((intValue & 19) == 18 && d10Var.A()) {
            d10Var.R();
        } else {
            int i3 = -2;
            if (sk.f(j)) {
                i = -1;
            } else {
                i = -2;
            }
            if (sk.e(j)) {
                i3 = -1;
            }
            zi1.b(this.e, new FrameLayout.LayoutParams(i, i3), this.f, this.g, this.h, this.i, this.j, this.k, this.l, d10Var, 384);
        }
        return we1.a;
    }
}