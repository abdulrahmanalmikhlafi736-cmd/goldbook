package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ck0  reason: default package */
public final class ck0 extends ox0 implements m00 {
    public m10 g;
    public dk0 h;
    public long[] i;
    public int j;
    public int k;
    public /* synthetic */ Object l;
    public final /* synthetic */ dk0 m;
    public final /* synthetic */ m10 n;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public ck0(dk0 dk0Var, m10 m10Var, ml mlVar) {
        super(2, mlVar);
        this.m = dk0Var;
        this.n = m10Var;
    }

    @Override // defpackage.m00
    public final Object f(Object obj, Object obj2) {
        return ((ck0) n((ml) obj2, (c31) obj)).p(we1.a);
    }

    @Override // defpackage.db
    public final ml n(ml mlVar, Object obj) {
        ck0 ck0Var = new ck0(this.m, this.n, mlVar);
        ck0Var.l = obj;
        return ck0Var;
    }

    @Override // defpackage.db
    public final Object p(Object obj) {
        c31 c31Var;
        dk0 dk0Var;
        long[] jArr;
        int i;
        m10 m10Var;
        int i2 = this.k;
        if (i2 != 0) {
            if (i2 == 1) {
                i = this.j;
                jArr = this.i;
                dk0Var = this.h;
                m10Var = this.g;
                c31Var = (c31) this.l;
                nb0.t(obj);
            } else {
                od.p("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
        } else {
            nb0.t(obj);
            c31Var = (c31) this.l;
            dk0Var = this.m;
            bk0 bk0Var = dk0Var.f;
            jArr = bk0Var.c;
            i = bk0Var.e;
            m10Var = this.n;
        }
        if (i != Integer.MAX_VALUE) {
            int i3 = (int) ((jArr[i] >> 31) & 2147483647L);
            m10Var.f = i;
            Object obj2 = dk0Var.f.b[i];
            this.l = c31Var;
            this.g = m10Var;
            this.h = dk0Var;
            this.i = jArr;
            this.j = i3;
            this.k = 1;
            c31Var.b(obj2, this);
            return cm.e;
        }
        return we1.a;
    }
}