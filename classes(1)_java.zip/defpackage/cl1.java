package defpackage;

import android.content.ContentResolver;
import android.content.Context;
import android.net.Uri;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cl1  reason: default package */
public abstract class cl1 {
    public static final hk0 a;

    static {
        long[] jArr = n01.a;
        a = new hk0();
    }

    public static final b81 a(Context context) {
        b81 b81Var;
        hk0 hk0Var = a;
        synchronized (hk0Var) {
            try {
                Object g = hk0Var.g(context);
                if (g == null) {
                    ContentResolver contentResolver = context.getContentResolver();
                    Uri uriFor = Settings.Global.getUriFor("animator_duration_scale");
                    id b = wl1.b(-1, 6, null);
                    cz0 cz0Var = new cz0(0, new al1(contentResolver, uriFor, new bl1(b, vd1.j(Looper.getMainLooper())), b, context, null));
                    l91 e = ua0.e();
                    uo uoVar = kq.a;
                    g = wl1.K(cz0Var, new ll(vn.O(e, kg0.a)), new x71(Long.MAX_VALUE), Float.valueOf(Settings.Global.getFloat(context.getContentResolver(), "animator_duration_scale", 1.0f)));
                    hk0Var.m(context, g);
                }
                b81Var = (b81) g;
            } catch (Throwable th) {
                throw th;
            }
        }
        return b81Var;
    }

    public static final sj b(View view) {
        Object tag = view.getTag(2131034155);
        if (tag instanceof sj) {
            return (sj) tag;
        }
        return null;
    }
}