package defpackage;

import java.util.AbstractList;
import java.util.ConcurrentModificationException;
import java.util.ListIterator;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: c30  reason: default package */
public final class c30 implements ListIterator, w80 {
    public final /* synthetic */ int e;
    public int f;
    public int g;
    public int h;
    public final Object i;

    public c30(z61 z61Var, int i) {
        this.e = 3;
        this.i = z61Var;
        this.f = i - 1;
        this.g = -1;
        this.h = zi1.v(z61Var);
    }

    public void a() {
        int i;
        i = ((AbstractList) ((pe0) this.i).i).modCount;
        if (i == this.h) {
            return;
        }
        throw new ConcurrentModificationException();
    }

    @Override // java.util.ListIterator
    public final void add(Object obj) {
        int i;
        int i2;
        int i3 = this.e;
        Object obj2 = this.i;
        switch (i3) {
            case 0:
                throw new UnsupportedOperationException("Operation is not supported for read-only collection");
            case 1:
                a();
                pe0 pe0Var = (pe0) obj2;
                int i4 = this.f;
                this.f = i4 + 1;
                pe0Var.add(i4, obj);
                this.g = -1;
                i = ((AbstractList) pe0Var).modCount;
                this.h = i;
                return;
            case 2:
                b();
                qe0 qe0Var = (qe0) obj2;
                int i5 = this.f;
                this.f = i5 + 1;
                qe0Var.add(i5, obj);
                this.g = -1;
                i2 = ((AbstractList) qe0Var).modCount;
                this.h = i2;
                return;
            default:
                c();
                z61 z61Var = (z61) obj2;
                z61Var.add(this.f + 1, obj);
                this.g = -1;
                this.f++;
                this.h = zi1.v(z61Var);
                return;
        }
    }

    public void b() {
        int i;
        i = ((AbstractList) ((qe0) this.i)).modCount;
        if (i == this.h) {
            return;
        }
        throw new ConcurrentModificationException();
    }

    public void c() {
        if (zi1.v((z61) this.i) == this.h) {
            return;
        }
        throw new ConcurrentModificationException();
    }

    @Override // java.util.ListIterator, java.util.Iterator
    public final boolean hasNext() {
        int i = this.e;
        Object obj = this.i;
        switch (i) {
            case 0:
                if (this.f >= this.h) {
                    return false;
                }
                return true;
            case 1:
                if (this.f >= ((pe0) obj).g) {
                    return false;
                }
                return true;
            case 2:
                if (this.f >= ((qe0) obj).f) {
                    return false;
                }
                return true;
            default:
                if (this.f >= ((z61) obj).size() - 1) {
                    return false;
                }
                return true;
        }
    }

    @Override // java.util.ListIterator
    public final boolean hasPrevious() {
        switch (this.e) {
            case 0:
                if (this.f > this.g) {
                    return true;
                }
                return false;
            case 1:
                if (this.f > 0) {
                    return true;
                }
                return false;
            case 2:
                if (this.f > 0) {
                    return true;
                }
                return false;
            default:
                if (this.f >= 0) {
                    return true;
                }
                return false;
        }
    }

    @Override // java.util.ListIterator, java.util.Iterator
    public final Object next() {
        int i = this.e;
        Object obj = this.i;
        switch (i) {
            case 0:
                ak0 ak0Var = ((e30) obj).e;
                int i2 = this.f;
                this.f = i2 + 1;
                Object f = ak0Var.f(i2);
                f.getClass();
                return (li0) f;
            case 1:
                a();
                int i3 = this.f;
                pe0 pe0Var = (pe0) obj;
                if (i3 < pe0Var.g) {
                    this.f = i3 + 1;
                    this.g = i3;
                    return pe0Var.e[pe0Var.f + i3];
                }
                od.n();
                return null;
            case 2:
                b();
                int i4 = this.f;
                qe0 qe0Var = (qe0) obj;
                if (i4 < qe0Var.f) {
                    this.f = i4 + 1;
                    this.g = i4;
                    return qe0Var.e[i4];
                }
                od.n();
                return null;
            default:
                c();
                int i5 = this.f + 1;
                this.g = i5;
                z61 z61Var = (z61) obj;
                zi1.j(i5, z61Var.size());
                Object obj2 = z61Var.get(i5);
                this.f = i5;
                return obj2;
        }
    }

    @Override // java.util.ListIterator
    public final int nextIndex() {
        switch (this.e) {
            case 0:
                return this.f - this.g;
            case 1:
                return this.f;
            case 2:
                return this.f;
            default:
                return this.f + 1;
        }
    }

    @Override // java.util.ListIterator
    public final Object previous() {
        int i = this.e;
        Object obj = this.i;
        switch (i) {
            case 0:
                ak0 ak0Var = ((e30) obj).e;
                int i2 = this.f - 1;
                this.f = i2;
                Object f = ak0Var.f(i2);
                f.getClass();
                return (li0) f;
            case 1:
                a();
                int i3 = this.f;
                if (i3 > 0) {
                    int i4 = i3 - 1;
                    this.f = i4;
                    this.g = i4;
                    pe0 pe0Var = (pe0) obj;
                    return pe0Var.e[pe0Var.f + i4];
                }
                od.n();
                return null;
            case 2:
                b();
                int i5 = this.f;
                if (i5 > 0) {
                    int i6 = i5 - 1;
                    this.f = i6;
                    this.g = i6;
                    return ((qe0) obj).e[i6];
                }
                od.n();
                return null;
            default:
                c();
                z61 z61Var = (z61) obj;
                zi1.j(this.f, z61Var.size());
                int i7 = this.f;
                this.g = i7;
                this.f--;
                return z61Var.get(i7);
        }
    }

    @Override // java.util.ListIterator
    public final int previousIndex() {
        int i;
        switch (this.e) {
            case 0:
                return (this.f - this.g) - 1;
            case 1:
                i = this.f;
                break;
            case 2:
                i = this.f;
                break;
            default:
                return this.f;
        }
        return i - 1;
    }

    @Override // java.util.ListIterator, java.util.Iterator
    public final void remove() {
        int i;
        int i2;
        int i3 = this.e;
        Object obj = this.i;
        switch (i3) {
            case 0:
                throw new UnsupportedOperationException("Operation is not supported for read-only collection");
            case 1:
                pe0 pe0Var = (pe0) obj;
                a();
                int i4 = this.g;
                if (i4 != -1) {
                    pe0Var.b(i4);
                    this.f = this.g;
                    this.g = -1;
                    i = ((AbstractList) pe0Var).modCount;
                    this.h = i;
                    return;
                }
                od.p("Call next() or previous() before removing element from the iterator.");
                return;
            case 2:
                qe0 qe0Var = (qe0) obj;
                b();
                int i5 = this.g;
                if (i5 != -1) {
                    qe0Var.b(i5);
                    this.f = this.g;
                    this.g = -1;
                    i2 = ((AbstractList) qe0Var).modCount;
                    this.h = i2;
                    return;
                }
                od.p("Call next() or previous() before removing element from the iterator.");
                return;
            default:
                c();
                z61 z61Var = (z61) obj;
                z61Var.remove(this.g);
                this.f--;
                this.g = -1;
                this.h = zi1.v(z61Var);
                return;
        }
    }

    @Override // java.util.ListIterator
    public final void set(Object obj) {
        int i = this.e;
        Object obj2 = this.i;
        switch (i) {
            case 0:
                throw new UnsupportedOperationException("Operation is not supported for read-only collection");
            case 1:
                a();
                int i2 = this.g;
                if (i2 != -1) {
                    ((pe0) obj2).set(i2, obj);
                    return;
                } else {
                    od.p("Call next() or previous() before replacing element from the iterator.");
                    return;
                }
            case 2:
                b();
                int i3 = this.g;
                if (i3 != -1) {
                    ((qe0) obj2).set(i3, obj);
                    return;
                } else {
                    od.p("Call next() or previous() before replacing element from the iterator.");
                    return;
                }
            default:
                z61 z61Var = (z61) obj2;
                c();
                int i4 = this.g;
                if (i4 >= 0) {
                    z61Var.set(i4, obj);
                    this.h = zi1.v(z61Var);
                    return;
                }
                od.p("Cannot call set before the first call to next() or previous() or immediately after a call to add() or remove()");
                return;
        }
    }

    public c30(qe0 qe0Var, int i) {
        int i2;
        this.e = 2;
        this.i = qe0Var;
        this.f = i;
        this.g = -1;
        i2 = ((AbstractList) qe0Var).modCount;
        this.h = i2;
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public c30(e30 e30Var, int i, int i2) {
        this(e30Var, (i2 & 1) != 0 ? 0 : i, 0, e30Var.e.b);
        this.e = 0;
    }

    public c30(e30 e30Var, int i, int i2, int i3) {
        this.e = 0;
        this.i = e30Var;
        this.f = i;
        this.g = i2;
        this.h = i3;
    }

    public c30(pe0 pe0Var, int i) {
        int i2;
        this.e = 1;
        this.i = pe0Var;
        this.f = i;
        this.g = -1;
        i2 = ((AbstractList) pe0Var).modCount;
        this.h = i2;
    }
}