package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: d3  reason: default package */
public abstract class d3 {
    public static final up0 a = new up0(24.0f, 24.0f, 24.0f, 24.0f);
    public static final up0 b;
    public static final up0 c;
    public static final gk d;

    static {
        ac.f(16.0f);
        b = ac.f(16.0f);
        c = ac.f(24.0f);
        d = new gk(new i2(2));
    }

    public static final void a(final pi piVar, mi0 mi0Var, final m00 m00Var, final m00 m00Var2, final y41 y41Var, final long j, final long j2, final long j3, final long j4, final long j5, d10 d10Var, final int i) {
        final ji0 ji0Var;
        d10Var.X(1378716401);
        int i2 = i | 48 | (d10Var.h(null) ? 256 : 128) | (d10Var.h(m00Var) ? 2048 : 1024) | (d10Var.h(m00Var2) ? 16384 : 8192) | (d10Var.f(y41Var) ? 131072 : 65536) | (d10Var.e(j) ? 1048576 : 524288) | (d10Var.c(0.0f) ? 8388608 : 4194304) | (d10Var.e(j2) ? 67108864 : 33554432) | (d10Var.e(j3) ? 536870912 : 268435456);
        if (d10Var.O(i2 & 1, ((i2 & 306783379) == 306783378 && (((d10Var.e(j4) ? (char) 4 : (char) 2) | (d10Var.e(j5) ? ' ' : (char) 16)) & 19) == 18) ? false : true)) {
            pi A = vd1.A(-652798794, new m00(m00Var2, j3, j4, j5, j2, piVar) { // from class: a3
                public final /* synthetic */ m00 f;
                public final /* synthetic */ long g;
                public final /* synthetic */ long h;
                public final /* synthetic */ long i;
                public final /* synthetic */ pi j;

                {
                    this.g = j4;
                    this.h = j5;
                    this.i = j2;
                    this.j = piVar;
                }

                @Override // defpackage.m00
                public final Object f(Object obj, Object obj2) {
                    boolean z;
                    d10 d10Var2 = (d10) obj;
                    int intValue = ((Integer) obj2).intValue();
                    if ((intValue & 3) != 2) {
                        z = true;
                    } else {
                        z = false;
                    }
                    if (d10Var2.O(intValue & 1, z)) {
                        mi0 C = ac.C(ji0.a, d3.a);
                        ph a2 = nh.a(zi1.b, e3.q, d10Var2, 0);
                        long j6 = d10Var2.T;
                        int i3 = (int) (j6 ^ (j6 >>> 32));
                        qr0 l = d10Var2.l();
                        mi0 I = vn.I(d10Var2, C);
                        ij.c.getClass();
                        dk dkVar = hj.b;
                        d10Var2.Z();
                        if (d10Var2.S) {
                            d10Var2.k(dkVar);
                        } else {
                            d10Var2.j0();
                        }
                        s7 s7Var = hj.f;
                        mc0.B(s7Var, d10Var2, a2);
                        s7 s7Var2 = hj.e;
                        mc0.B(s7Var2, d10Var2, l);
                        Integer valueOf = Integer.valueOf(i3);
                        s7 s7Var3 = hj.g;
                        mc0.p(d10Var2, valueOf, s7Var3);
                        i4 i4Var = hj.h;
                        mc0.w(d10Var2, i4Var);
                        s7 s7Var4 = hj.d;
                        mc0.B(s7Var4, d10Var2, I);
                        d10Var2.W(346092326);
                        d10Var2.p(false);
                        m00 m00Var3 = m00.this;
                        if (m00Var3 == null) {
                            d10Var2.W(346396529);
                            d10Var2.p(false);
                        } else {
                            d10Var2.W(346396530);
                            nb0.b(this.g, me1.a(zi1.k, d10Var2), vd1.A(71284337, new c3(0, m00Var3), d10Var2), d10Var2, 384);
                            d10Var2.p(false);
                        }
                        m00 m00Var4 = this.f;
                        if (m00Var4 == null) {
                            d10Var2.W(347174009);
                            d10Var2.p(false);
                        } else {
                            d10Var2.W(347174010);
                            nb0.b(this.h, me1.a(zi1.m, d10Var2), vd1.A(705583346, new c3(1, m00Var4), d10Var2), d10Var2, 384);
                            d10Var2.p(false);
                        }
                        f30 f30Var = new f30(e3.s);
                        mh0 d2 = ic.d(e3.f, false);
                        long j7 = d10Var2.T;
                        int i4 = (int) (j7 ^ (j7 >>> 32));
                        qr0 l2 = d10Var2.l();
                        mi0 I2 = vn.I(d10Var2, f30Var);
                        d10Var2.Z();
                        if (d10Var2.S) {
                            d10Var2.k(dkVar);
                        } else {
                            d10Var2.j0();
                        }
                        mc0.B(s7Var, d10Var2, d2);
                        mc0.B(s7Var2, d10Var2, l2);
                        mc0.p(d10Var2, Integer.valueOf(i4), s7Var3);
                        mc0.w(d10Var2, i4Var);
                        mc0.B(s7Var4, d10Var2, I2);
                        nb0.b(this.i, me1.a(zi1.g, d10Var2), this.j, d10Var2, 0);
                        d10Var2.p(true);
                        d10Var2.p(true);
                    } else {
                        d10Var2.R();
                    }
                    return we1.a;
                }
            }, d10Var);
            int i3 = i2 >> 12;
            int i4 = (i3 & 896) | (i3 & 112) | 12582918 | ((i2 >> 9) & 57344);
            ji0 ji0Var2 = ji0.a;
            p91.a(ji0Var2, y41Var, j, 0L, A, d10Var, i4, 104);
            ji0Var = ji0Var2;
        } else {
            d10Var.R();
            ji0Var = mi0Var;
        }
        xv0 r = d10Var.r();
        if (r != null) {
            r.d = new m00(ji0Var, m00Var, m00Var2, y41Var, j, j2, j3, j4, j5, i) { // from class: b3
                public final /* synthetic */ mi0 f;
                public final /* synthetic */ m00 g;
                public final /* synthetic */ m00 h;
                public final /* synthetic */ y41 i;
                public final /* synthetic */ long j;
                public final /* synthetic */ long k;
                public final /* synthetic */ long l;
                public final /* synthetic */ long m;
                public final /* synthetic */ long n;

                @Override // defpackage.m00
                public final Object f(Object obj, Object obj2) {
                    ((Integer) obj2).getClass();
                    int s = wc0.s(7);
                    d3.a(pi.this, this.f, this.g, this.h, this.i, this.j, this.k, this.l, this.m, this.n, (d10) obj, s);
                    return we1.a;
                }
            };
        }
    }

    public static final void b(final float f, final pi piVar, d10 d10Var, int i) {
        int i2;
        boolean z;
        o90 o90Var;
        d10Var.X(-917637668);
        if (d10Var.c(f)) {
            i2 = 32;
        } else {
            i2 = 16;
        }
        int i3 = i2 | i;
        if ((i3 & 147) != 146) {
            z = true;
        } else {
            z = false;
        }
        if (d10Var.O(i3 & 1, z)) {
            k81 k81Var = fk.n;
            final o90 o90Var2 = (o90) d10Var.j(k81Var);
            int ordinal = o90Var2.ordinal();
            if (ordinal != 0) {
                if (ordinal == 1) {
                    o90Var = o90.e;
                } else {
                    od.k();
                    return;
                }
            } else {
                o90Var = o90.f;
            }
            k70.c(k81Var.a(o90Var), vd1.A(-1986402020, new m00() { // from class: u2
                @Override // defpackage.m00
                public final Object f(Object obj, Object obj2) {
                    boolean z2;
                    d10 d10Var2 = (d10) obj;
                    int intValue = ((Integer) obj2).intValue();
                    if ((intValue & 3) != 2) {
                        z2 = true;
                    } else {
                        z2 = false;
                    }
                    if (d10Var2.O(intValue & 1, z2)) {
                        j70.h(null, new q9(8.0f, new o9(0)), new q9(f, new o9(0)), null, 0, 0, vd1.A(879927511, new w2(o90Var2, piVar, 0), d10Var2), d10Var2, 1572864);
                    } else {
                        d10Var2.R();
                    }
                    return we1.a;
                }
            }, d10Var), d10Var, 56);
        } else {
            d10Var.R();
        }
        xv0 r = d10Var.r();
        if (r != null) {
            r.d = new v2(f, piVar, i);
        }
    }

    public static final void c(final xz xzVar, final pi piVar, final mi0 mi0Var, final m00 m00Var, final m00 m00Var2, final m00 m00Var3, final y41 y41Var, final long j, final long j2, final long j3, final long j4, final yp ypVar, d10 d10Var, final int i, final int i2) {
        int i3;
        Object obj;
        Object obj2;
        int i4;
        d10Var.X(-867616355);
        if ((i & 6) == 0) {
            i3 = (d10Var.h(xzVar) ? 4 : 2) | i;
        } else {
            i3 = i;
        }
        if ((i & 48) == 0) {
            obj = piVar;
            i3 |= d10Var.h(obj) ? 32 : 16;
        } else {
            obj = piVar;
        }
        if ((i & 384) == 0) {
            i3 |= d10Var.f(mi0Var) ? 256 : 128;
        }
        if ((i & 3072) == 0) {
            obj2 = m00Var;
            i3 |= d10Var.h(obj2) ? 2048 : 1024;
        } else {
            obj2 = m00Var;
        }
        if ((i & 24576) == 0) {
            i3 |= d10Var.h(null) ? 16384 : 8192;
        }
        if ((196608 & i) == 0) {
            i3 |= d10Var.h(m00Var2) ? 131072 : 65536;
        }
        if ((i & 1572864) == 0) {
            i3 |= d10Var.h(m00Var3) ? 1048576 : 524288;
        }
        if ((i & 12582912) == 0) {
            i3 |= d10Var.f(y41Var) ? 8388608 : 4194304;
        }
        if ((i & 100663296) == 0) {
            i3 |= d10Var.e(j) ? 67108864 : 33554432;
        }
        if ((i & 805306368) == 0) {
            i3 |= d10Var.e(j2) ? 536870912 : 268435456;
        }
        if ((i2 & 6) == 0) {
            i4 = i2 | (d10Var.e(j3) ? 4 : 2);
        } else {
            i4 = i2;
        }
        if ((i2 & 48) == 0) {
            i4 |= d10Var.e(j4) ? 32 : 16;
        }
        if ((i2 & 384) == 0) {
            i4 |= d10Var.c(0.0f) ? 256 : 128;
        }
        if ((i2 & 3072) == 0) {
            i4 |= d10Var.f(ypVar) ? 2048 : 1024;
        }
        int i5 = i4;
        if (d10Var.O(i3 & 1, ((i3 & 306783379) == 306783378 && (i5 & 1171) == 1170) ? false : true)) {
            final pi piVar2 = obj;
            final m00 m00Var4 = obj2;
            d(xzVar, mi0Var, ypVar, vd1.A(527420759, new m00() { // from class: t2
                @Override // defpackage.m00
                public final Object f(Object obj3, Object obj4) {
                    boolean z;
                    d10 d10Var2 = (d10) obj3;
                    int intValue = ((Integer) obj4).intValue();
                    if ((intValue & 3) != 2) {
                        z = true;
                    } else {
                        z = false;
                    }
                    if (d10Var2.O(intValue & 1, z)) {
                        d3.a(vd1.A(1367541877, new y2(piVar2, m00Var4, 0), d10Var2), null, m00.this, m00Var3, y41Var, j, fh.d(zi1.f, d10Var2), j2, j3, j4, d10Var2, 6);
                    } else {
                        d10Var2.R();
                    }
                    return we1.a;
                }
            }, d10Var), d10Var, (i3 & 14) | 3072 | ((i3 >> 3) & 112) | ((i5 >> 3) & 896));
        } else {
            d10Var.R();
        }
        xv0 r = d10Var.r();
        if (r != null) {
            r.d = new m00() { // from class: x2
                @Override // defpackage.m00
                public final Object f(Object obj3, Object obj4) {
                    ((Integer) obj4).getClass();
                    int s = wc0.s(i | 1);
                    int s2 = wc0.s(i2);
                    d3.c(xz.this, piVar, mi0Var, m00Var, m00Var2, m00Var3, y41Var, j, j2, j3, j4, ypVar, (d10) obj3, s, s2);
                    return we1.a;
                }
            };
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v7, types: [p3, java.lang.Object] */
    public static final void d(xz xzVar, mi0 mi0Var, yp ypVar, pi piVar, d10 d10Var, int i) {
        int i2;
        boolean z;
        int i3;
        int i4;
        int i5;
        int i6;
        d10Var.X(24925658);
        if ((i & 6) == 0) {
            if (d10Var.h(xzVar)) {
                i6 = 4;
            } else {
                i6 = 2;
            }
            i2 = i6 | i;
        } else {
            i2 = i;
        }
        if ((i & 48) == 0) {
            if (d10Var.f(mi0Var)) {
                i5 = 32;
            } else {
                i5 = 16;
            }
            i2 |= i5;
        }
        if ((i & 384) == 0) {
            if (d10Var.f(ypVar)) {
                i4 = 256;
            } else {
                i4 = 128;
            }
            i2 |= i4;
        }
        if ((i & 3072) == 0) {
            if (d10Var.h(piVar)) {
                i3 = 2048;
            } else {
                i3 = 1024;
            }
            i2 |= i3;
        }
        if ((i2 & 1171) != 1170) {
            z = true;
        } else {
            z = false;
        }
        if (d10Var.O(i2 & 1, z)) {
            ?? obj = new Object();
            obj.e = xzVar;
            obj.f = mi0Var;
            obj.g = ypVar;
            obj.h = piVar;
            ((zn) d10Var.j(d)).a(obj, d10Var, 0);
        } else {
            d10Var.R();
        }
        xv0 r = d10Var.r();
        if (r != null) {
            r.d = new z2(xzVar, mi0Var, ypVar, piVar, i, 0);
        }
    }
}