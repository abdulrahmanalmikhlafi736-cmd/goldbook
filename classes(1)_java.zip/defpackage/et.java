package defpackage;

import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import androidx.emoji2.text.EmojiCompatInitializer;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: et  reason: default package */
public final class et implements ro {
    public final /* synthetic */ ud0 e;

    public et(EmojiCompatInitializer emojiCompatInitializer, ud0 ud0Var) {
        this.e = ud0Var;
    }

    @Override // defpackage.ro
    public final void a(sd0 sd0Var) {
    }

    @Override // defpackage.ro
    public final void b(sd0 sd0Var) {
    }

    @Override // defpackage.ro
    public final void c(sd0 sd0Var) {
    }

    @Override // defpackage.ro
    public final void d(sd0 sd0Var) {
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.Object, java.lang.Runnable] */
    @Override // defpackage.ro
    public final void e(sd0 sd0Var) {
        Handler handler;
        if (Build.VERSION.SDK_INT >= 28) {
            handler = jk.a(Looper.getMainLooper());
        } else {
            handler = new Handler(Looper.getMainLooper());
        }
        handler.postDelayed(new Object(), 500L);
        this.e.f(this);
    }

    @Override // defpackage.ro
    public final void g(sd0 sd0Var) {
    }
}