package defpackage;

import java.io.Serializable;
import java.util.Iterator;
import java.util.List;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: an  reason: default package */
public final class an extends u91 implements i00 {
    public Object i;
    public Serializable j;
    public Object k;
    public Object l;
    public Iterator m;
    public int n;
    public int o;
    public final /* synthetic */ tn p;
    public final /* synthetic */ p3 q;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public an(tn tnVar, p3 p3Var, ml mlVar) {
        super(1, mlVar);
        this.p = tnVar;
        this.q = p3Var;
    }

    @Override // defpackage.i00
    public final Object i(Object obj) {
        return new an(this.p, this.q, (ml) obj).p(we1.a);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:23:0x00a5  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x00d8  */
    /* JADX WARN: Removed duplicated region for block: B:35:0x00e3  */
    /* JADX WARN: Removed duplicated region for block: B:36:0x00e8  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x00fe  */
    /* JADX WARN: Type inference failed for: r0v2, types: [nw0] */
    /* JADX WARN: Type inference failed for: r0v21 */
    /* JADX WARN: Type inference failed for: r10v0, types: [java.lang.Object, java.io.Serializable] */
    /* JADX WARN: Type inference failed for: r9v0 */
    /* JADX WARN: Type inference failed for: r9v1, types: [nw0] */
    /* JADX WARN: Type inference failed for: r9v3, types: [java.io.Serializable] */
    /* JADX WARN: Type inference failed for: r9v7, types: [nw0] */
    @Override // defpackage.db
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object p(Object obj) {
        cl0 cl0Var;
        nw0 nw0Var;
        jw0 jw0Var;
        nw0 nw0Var2;
        cl0 cl0Var2;
        Iterator it;
        cl0 cl0Var3;
        jw0 jw0Var2;
        nw0 nw0Var3;
        zm zmVar;
        jw0 jw0Var3;
        nw0 nw0Var4;
        jw0 jw0Var4;
        Object obj2;
        int i;
        Integer a;
        Object obj3;
        int i2 = this.o;
        p3 p3Var = this.q;
        tn tnVar = this.p;
        cm cmVar = cm.e;
        if (i2 != 0) {
            if (i2 != 1) {
                if (i2 != 2) {
                    if (i2 != 3) {
                        if (i2 == 4) {
                            i = this.n;
                            obj3 = this.i;
                            nb0.t(obj);
                            return new qm(i, ((Number) obj).intValue(), obj3);
                        }
                        od.p("call to 'resume' before 'invoke' with coroutine");
                        return null;
                    }
                    cl0Var2 = (cl0) this.k;
                    nw0Var4 = (nw0) this.j;
                    jw0Var4 = (jw0) this.i;
                    nb0.t(obj);
                    try {
                        jw0Var4.e = true;
                        cl0Var2.e(null);
                        obj2 = nw0Var4.e;
                        if (obj2 == null) {
                            i = obj2.hashCode();
                        } else {
                            i = 0;
                        }
                        q51 h = tnVar.h();
                        this.i = obj2;
                        this.j = null;
                        this.k = null;
                        this.n = i;
                        this.o = 4;
                        a = h.a();
                        if (a != cmVar) {
                            obj = a;
                            obj3 = obj2;
                            return new qm(i, ((Number) obj).intValue(), obj3);
                        }
                        return cmVar;
                    } catch (Throwable th) {
                        cl0Var2.e(null);
                        throw th;
                    }
                }
                it = this.m;
                zmVar = (zm) this.l;
                nw0Var3 = (nw0) this.k;
                jw0Var2 = (jw0) this.j;
                cl0Var3 = (cl0) this.i;
                nb0.t(obj);
                while (it.hasNext()) {
                    this.i = cl0Var3;
                    this.j = jw0Var2;
                    this.k = nw0Var3;
                    this.l = zmVar;
                    this.m = it;
                    this.o = 2;
                    if (((m00) it.next()).f(zmVar, this) == cmVar) {
                        break;
                    }
                }
                nw0Var = nw0Var3;
                jw0Var3 = jw0Var2;
                cl0Var2 = cl0Var3;
                p3Var.g = null;
                this.i = jw0Var3;
                this.j = nw0Var;
                this.k = cl0Var2;
                this.l = null;
                this.m = null;
                this.o = 3;
                if (cl0Var2.c(this) != cmVar) {
                    nw0Var4 = nw0Var;
                    jw0Var4 = jw0Var3;
                    jw0Var4.e = true;
                    cl0Var2.e(null);
                    obj2 = nw0Var4.e;
                    if (obj2 == null) {
                    }
                    q51 h2 = tnVar.h();
                    this.i = obj2;
                    this.j = null;
                    this.k = null;
                    this.n = i;
                    this.o = 4;
                    a = h2.a();
                    if (a != cmVar) {
                    }
                }
                return cmVar;
            }
            nw0Var = (nw0) this.k;
            cl0Var = (cl0) this.i;
            nb0.t(obj);
            nw0Var2 = (nw0) this.l;
            jw0Var = (jw0) this.j;
        } else {
            nb0.t(obj);
            cl0Var = new cl0();
            ?? obj4 = new Object();
            Object obj5 = new Object();
            this.i = cl0Var;
            this.j = obj4;
            this.k = obj5;
            this.l = obj5;
            this.o = 1;
            obj = tn.g(tnVar, true, this);
            if (obj != cmVar) {
                nw0Var = obj5;
                nw0Var2 = obj5;
                jw0Var = obj4;
            }
            return cmVar;
        }
        nw0Var2.e = ((qm) obj).b;
        zm zmVar2 = new zm(cl0Var, jw0Var, nw0Var, tnVar);
        List list = (List) p3Var.g;
        if (list != null) {
            it = list.iterator();
            cl0Var3 = cl0Var;
            jw0Var2 = jw0Var;
            nw0Var3 = nw0Var;
            zmVar = zmVar2;
            while (it.hasNext()) {
            }
            nw0Var = nw0Var3;
            jw0Var3 = jw0Var2;
            cl0Var2 = cl0Var3;
            p3Var.g = null;
            this.i = jw0Var3;
            this.j = nw0Var;
            this.k = cl0Var2;
            this.l = null;
            this.m = null;
            this.o = 3;
            if (cl0Var2.c(this) != cmVar) {
            }
            return cmVar;
        }
        cl0Var2 = cl0Var;
        jw0Var3 = jw0Var;
        p3Var.g = null;
        this.i = jw0Var3;
        this.j = nw0Var;
        this.k = cl0Var2;
        this.l = null;
        this.m = null;
        this.o = 3;
        if (cl0Var2.c(this) != cmVar) {
        }
        return cmVar;
    }
}