package defpackage;

import android.content.res.Resources;
import android.graphics.Rect;
import android.view.ScrollCaptureSession;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: aj  reason: default package */
public final class aj extends u91 implements m00 {
    public final /* synthetic */ int i;
    public int j;
    public Object k;
    public /* synthetic */ Object l;
    public final /* synthetic */ Object m;
    public final /* synthetic */ Object n;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ aj(Object obj, Object obj2, Object obj3, Object obj4, ml mlVar, int i) {
        super(2, mlVar);
        this.i = i;
        this.k = obj;
        this.l = obj2;
        this.m = obj3;
        this.n = obj4;
    }

    @Override // defpackage.m00
    public final Object f(Object obj, Object obj2) {
        int i = this.i;
        we1 we1Var = we1.a;
        switch (i) {
            case 0:
                return ((aj) n((ml) obj2, (bm) obj)).p(we1Var);
            case 1:
                return ((aj) n((ml) obj2, (i51) obj)).p(we1Var);
            case 2:
                return ((aj) n((ml) obj2, (bm) obj)).p(we1Var);
            case 3:
                ((aj) n((ml) obj2, (bm) obj)).p(we1Var);
                return cm.e;
            default:
                return ((aj) n((ml) obj2, (bm) obj)).p(we1Var);
        }
    }

    @Override // defpackage.db
    public final ml n(ml mlVar, Object obj) {
        int i = this.i;
        Object obj2 = this.n;
        Object obj3 = this.m;
        switch (i) {
            case 0:
                return new aj((cj) this.k, (ScrollCaptureSession) this.l, (Rect) obj3, (Consumer) obj2, mlVar, 0);
            case 1:
                aj ajVar = new aj((tw) this.l, (d81) obj3, this.n, mlVar, 1);
                ajVar.k = obj;
                return ajVar;
            case 2:
                return new aj((k51) this.k, (tw) this.l, (d81) obj3, this.n, mlVar, 2);
            case 3:
                aj ajVar2 = new aj((mk0) obj3, (j50) obj2, mlVar);
                ajVar2.l = obj;
                return ajVar2;
            default:
                return new aj((lg0) this.l, (List) obj3, (Resources) obj2, mlVar, 4);
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:78:0x01a7, code lost:
        if (defpackage.wl1.y(r1, r2, r23) == r8) goto L76;
     */
    /* JADX WARN: Removed duplicated region for block: B:51:0x0123  */
    /* JADX WARN: Removed duplicated region for block: B:56:0x0139  */
    /* JADX WARN: Removed duplicated region for block: B:59:0x0155  */
    /* JADX WARN: Type inference failed for: r2v4, types: [u91, m00] */
    /* JADX WARN: Type inference failed for: r2v5, types: [kw0, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r7v6, types: [u91, m00] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:55:0x0137 -> B:49:0x0106). Please submit an issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:57:0x0152 -> B:49:0x0106). Please submit an issue!!! */
    @Override // defpackage.db
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object p(Object obj) {
        Object a;
        bm bmVar;
        kw0 kw0Var;
        int i;
        kw0 kw0Var2;
        lq0 lq0Var;
        Object px0Var;
        String str;
        int i2 = this.i;
        int i3 = 0;
        we1 we1Var = we1.a;
        Object obj2 = this.n;
        Object obj3 = this.m;
        cm cmVar = cm.e;
        switch (i2) {
            case 0:
                int i4 = this.j;
                if (i4 != 0) {
                    if (i4 == 1) {
                        nb0.t(obj);
                        a = obj;
                    } else {
                        od.p("call to 'resume' before 'invoke' with coroutine");
                        return null;
                    }
                } else {
                    nb0.t(obj);
                    Rect rect = (Rect) obj3;
                    r60 r60Var = new r60(rect.left, rect.top, rect.right, rect.bottom);
                    this.j = 1;
                    a = cj.a((cj) this.k, (ScrollCaptureSession) this.l, r60Var, this);
                    if (a == cmVar) {
                        return cmVar;
                    }
                }
                ((Consumer) obj2).accept(dd0.x((r60) a));
                return we1Var;
            case 1:
                d81 d81Var = (d81) obj3;
                int i5 = this.j;
                if (i5 != 0) {
                    if (i5 == 1) {
                        nb0.t(obj);
                        return we1Var;
                    }
                    od.p("call to 'resume' before 'invoke' with coroutine");
                } else {
                    nb0.t(obj);
                    int ordinal = ((i51) this.k).ordinal();
                    if (ordinal != 0) {
                        if (ordinal != 1) {
                            if (ordinal == 2) {
                                if (obj2 != k70.t) {
                                    d81Var.i(null, obj2);
                                    return we1Var;
                                }
                                throw new UnsupportedOperationException("MutableStateFlow.resetReplayCache is not supported");
                            }
                            od.k();
                        } else {
                            return we1Var;
                        }
                    } else {
                        this.j = 1;
                        if (((tw) this.l).b(d81Var, this) == cmVar) {
                            return cmVar;
                        }
                        return we1Var;
                    }
                }
                return null;
            case 2:
                tw twVar = (tw) this.l;
                d81 d81Var2 = (d81) obj3;
                int i6 = this.j;
                if (i6 != 0) {
                    if (i6 != 1) {
                        if (i6 != 2) {
                            if (i6 != 3 && i6 != 4) {
                                od.p("call to 'resume' before 'invoke' with coroutine");
                                return null;
                            }
                        } else {
                            nb0.t(obj);
                        }
                    }
                    nb0.t(obj);
                    return we1Var;
                }
                nb0.t(obj);
                k51 k51Var = (k51) this.k;
                if (k51Var == j51.a) {
                    this.j = 1;
                    if (twVar.b(d81Var2, this) != cmVar) {
                        return we1Var;
                    }
                } else if (k51Var == j51.b) {
                    j91 g = d81Var2.g();
                    ?? u91Var = new u91(2, null);
                    this.j = 2;
                    break;
                } else {
                    tw u = wl1.u(k51Var.b(d81Var2.g()));
                    aj ajVar = new aj(twVar, d81Var2, this.n, null, 1);
                    this.j = 4;
                    int i7 = ex.a;
                    we1 b = wl1.o(new ff(new dx(ajVar, null), u, st.e, -2, gd.e), 0).b(om0.e, this);
                    if (b != cmVar) {
                        b = we1Var;
                    }
                    if (b != cmVar) {
                        b = we1Var;
                    }
                    if (b != cmVar) {
                        return we1Var;
                    }
                }
                return cmVar;
                this.j = 3;
                if (twVar.b(d81Var2, this) != cmVar) {
                    return we1Var;
                }
                return cmVar;
            case 3:
                int i8 = this.j;
                if (i8 != 0) {
                    if (i8 != 1) {
                        if (i8 == 2) {
                            bm bmVar2 = (bm) this.l;
                            nb0.t(obj);
                            kw0Var2 = (kw0) this.k;
                            bmVar = bmVar2;
                        } else {
                            od.p("call to 'resume' before 'invoke' with coroutine");
                            return null;
                        }
                    } else {
                        bm bmVar3 = (bm) this.l;
                        nb0.t(obj);
                        kw0Var = (kw0) this.k;
                        bmVar = bmVar3;
                        i = (kw0Var.e > 0.0f ? 1 : (kw0Var.e == 0.0f ? 0 : -1));
                        kw0Var2 = kw0Var;
                        if (i == 0) {
                            cz0 C = mc0.C(new x1(6, bmVar));
                            ?? u91Var2 = new u91(2, null);
                            this.l = bmVar;
                            this.k = kw0Var;
                            this.j = 2;
                            kw0Var2 = kw0Var;
                            if (wl1.y(C, u91Var2, this) == cmVar) {
                                return cmVar;
                            }
                        }
                    }
                } else {
                    nb0.t(obj);
                    bmVar = (bm) this.l;
                    ?? obj4 = new Object();
                    obj4.e = 1.0f;
                    kw0Var2 = obj4;
                }
                ho hoVar = new ho((mk0) obj3, (j50) obj2, kw0Var2, bmVar);
                this.l = bmVar;
                this.k = kw0Var2;
                this.j = 1;
                if (e().k(e3.R) != null) {
                    kw0Var = kw0Var2;
                    if (sb0.o(e()).c(hoVar, this) == cmVar) {
                        return cmVar;
                    }
                    i = (kw0Var.e > 0.0f ? 1 : (kw0Var.e == 0.0f ? 0 : -1));
                    kw0Var2 = kw0Var;
                    if (i == 0) {
                    }
                    ho hoVar2 = new ho((mk0) obj3, (j50) obj2, kw0Var2, bmVar);
                    this.l = bmVar;
                    this.k = kw0Var2;
                    this.j = 1;
                    if (e().k(e3.R) != null) {
                        od.d();
                        return null;
                    }
                }
            default:
                int i9 = this.j;
                if (i9 != 0) {
                    if (i9 == 1) {
                        nb0.t(obj);
                        lq0Var = (lq0) this.k;
                        str = obj;
                    } else {
                        od.p("call to 'resume' before 'invoke' with coroutine");
                        return null;
                    }
                } else {
                    nb0.t(obj);
                    lq0Var = ((lg0) this.l).d;
                    Resources resources = (Resources) obj2;
                    this.k = lq0Var;
                    this.j = 1;
                    StringBuilder sb = new StringBuilder();
                    ArrayList arrayList = new ArrayList();
                    for (Object obj5 : (List) obj3) {
                        if (((t01) obj5).a) {
                            arrayList.add(obj5);
                        }
                    }
                    int size = arrayList.size();
                    while (i3 < size) {
                        Object obj6 = arrayList.get(i3);
                        i3++;
                        try {
                            InputStream openRawResource = resources.openRawResource(new Integer(((t01) obj6).b).intValue());
                            openRawResource.getClass();
                            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(openRawResource, mf.a), 8192);
                            px0Var = ua0.v(bufferedReader);
                            bufferedReader.close();
                        } catch (Throwable th) {
                            px0Var = new px0(th);
                        }
                        if (qx0.a(px0Var) != null) {
                            px0Var = "";
                        }
                        sb.append((String) px0Var);
                        sb.append("\n");
                    }
                    String sb2 = sb.toString();
                    str = sb2;
                    if (sb2 == cmVar) {
                        return cmVar;
                    }
                }
                lq0Var.setValue(str);
                return we1Var;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ aj(Object obj, Object obj2, Object obj3, ml mlVar, int i) {
        super(2, mlVar);
        this.i = i;
        this.l = obj;
        this.m = obj2;
        this.n = obj3;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public aj(mk0 mk0Var, j50 j50Var, ml mlVar) {
        super(2, mlVar);
        this.i = 3;
        this.m = mk0Var;
        this.n = j50Var;
    }
}