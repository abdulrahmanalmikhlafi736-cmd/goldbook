package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: aj0  reason: default package */
public final class aj0 {
    public final long a;
    public final long b;
    public final boolean c;

    public aj0(long j, long j2, boolean z) {
        this.a = j;
        this.b = j2;
        this.c = z;
    }

    public final aj0 a(aj0 aj0Var) {
        return new aj0(xm0.f(this.a, aj0Var.a), Math.max(this.b, aj0Var.b), this.c);
    }

    public final boolean equals(Object obj) {
        if (this != obj) {
            if (obj instanceof aj0) {
                aj0 aj0Var = (aj0) obj;
                if (!xm0.b(this.a, aj0Var.a) || this.b != aj0Var.b || this.c != aj0Var.c) {
                    return false;
                }
                return true;
            }
            return false;
        }
        return true;
    }

    public final int hashCode() {
        int i;
        long j = this.b;
        int d = ((xm0.d(this.a) * 31) + ((int) (j ^ (j >>> 32)))) * 31;
        if (this.c) {
            i = 1231;
        } else {
            i = 1237;
        }
        return d + i;
    }

    public final String toString() {
        return "MouseWheelScrollDelta(value=" + ((Object) xm0.h(this.a)) + ", timeMillis=" + this.b + ", shouldApplyImmediately=" + this.c + ')';
    }
}