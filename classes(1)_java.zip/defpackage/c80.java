package defpackage;

import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: c80  reason: default package */
public class c80 extends h80 {
    public final boolean g;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public c80(a80 a80Var) {
        super(true);
        qf qfVar;
        qf qfVar2;
        boolean z = true;
        O(a80Var);
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = h80.f;
        pf pfVar = (pf) atomicReferenceFieldUpdater.get(this);
        if (pfVar instanceof qf) {
            qfVar = (qf) pfVar;
        } else {
            qfVar = null;
        }
        if (qfVar != null) {
            h80 j = qfVar.j();
            while (!j.J()) {
                pf pfVar2 = (pf) atomicReferenceFieldUpdater.get(j);
                if (pfVar2 instanceof qf) {
                    qfVar2 = (qf) pfVar2;
                } else {
                    qfVar2 = null;
                }
                if (qfVar2 != null) {
                    j = qfVar2.j();
                }
            }
            this.g = z;
        }
        z = false;
        this.g = z;
    }

    @Override // defpackage.h80
    public final boolean J() {
        return this.g;
    }

    @Override // defpackage.h80
    public final boolean K() {
        return true;
    }
}