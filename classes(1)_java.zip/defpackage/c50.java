package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: c50  reason: default package */
public final class c50 {
    public final q11 a;
    public x40 b;
    public a50 c;
    public z40 d;
    public y40 e;
    public j70 f;
    public cz0 g;
    public long h = 9205357640488583168L;
    public rc1 i;
    public final zh j;
    public final zh k;
    public long l;

    /* JADX WARN: Type inference failed for: r3v1, types: [java.lang.Object, zh] */
    /* JADX WARN: Type inference failed for: r3v2, types: [java.lang.Object, zh] */
    public c50(q11 q11Var) {
        this.a = q11Var;
        ?? obj = new Object();
        obj.f = new ak0();
        this.j = obj;
        ?? obj2 = new Object();
        obj2.f = new vj0();
        this.k = obj2;
        this.l = 0L;
    }

    /* JADX WARN: Type inference failed for: r0v2, types: [z40, java.lang.Object] */
    public static void c(c50 c50Var, v40 v40Var, long j, long j2, int i) {
        if ((i & 4) != 0) {
            j2 = 0;
        }
        q11 q11Var = c50Var.a;
        z40 z40Var = c50Var.d;
        z40 z40Var2 = z40Var;
        if (z40Var == null) {
            ?? obj = new Object();
            obj.L = null;
            obj.M = Long.MAX_VALUE;
            obj.N = false;
            c50Var.d = obj;
            z40Var2 = obj;
        }
        z40Var2.L = v40Var;
        z40Var2.M = j;
        rc1 rc1Var = c50Var.i;
        bp0 bp0Var = q11Var.u;
        if (rc1Var == null) {
            c50Var.i = new rc1(bp0Var, 0);
        } else {
            rc1Var.a = bp0Var;
            rc1Var.b = j2;
        }
        z40Var2.N = false;
        c50Var.f = z40Var2;
    }

    /* JADX WARN: Type inference failed for: r0v2, types: [x40, java.lang.Object] */
    public final void a() {
        x40 x40Var = this.b;
        w40 w40Var = w40.g;
        x40 x40Var2 = x40Var;
        if (x40Var == null) {
            ?? obj = new Object();
            obj.L = w40Var;
            obj.M = false;
            this.b = obj;
            x40Var2 = obj;
        }
        x40Var2.L = w40Var;
        x40Var2.M = false;
        this.f = x40Var2;
    }

    /* JADX WARN: Type inference failed for: r0v2, types: [y40, java.lang.Object] */
    public final void b(v40 v40Var, long j, rc1 rc1Var) {
        y40 y40Var = this.e;
        y40 y40Var2 = y40Var;
        if (y40Var == null) {
            ?? obj = new Object();
            obj.L = null;
            obj.M = Long.MAX_VALUE;
            this.e = obj;
            y40Var2 = obj;
        }
        y40Var2.L = v40Var;
        y40Var2.M = j;
        rc1Var.b = 0L;
        this.f = y40Var2;
    }

    public final cz0 d() {
        cz0 cz0Var = this.g;
        if (cz0Var != null) {
            return cz0Var;
        }
        od.m("Velocity Tracker not initialized.");
        return null;
    }

    public final void e(v40 v40Var, u40 u40Var, long j) {
        long j2;
        q11 q11Var = this.a;
        long d = k70.N(q11Var).d(0L);
        if (!xm0.b(this.h, 9205357640488583168L) && !xm0.b(d, this.h)) {
            this.l = xm0.f(this.l, xm0.e(d, this.h));
        }
        this.h = d;
        bp0 bp0Var = q11Var.u;
        bp0Var.getClass();
        if (bp0Var == bp0.e) {
            j2 = j & 4294967295L;
        } else {
            j2 = j >> 32;
        }
        if (Math.abs(Float.intBitsToFloat((int) j2)) > 2.0f) {
            k70.h(d(), v40Var, q11Var.u, u40Var, this.j, this.l);
            zh zhVar = this.k;
            vj0 vj0Var = (vj0) zhVar.f;
            int i = vj0Var.b;
            if (i == 3) {
                int i2 = zhVar.e;
                zhVar.e = i2 + 1;
                if (i2 >= 0 && i2 < i) {
                    long[] jArr = vj0Var.a;
                    long j3 = jArr[i2];
                    jArr[i2] = j;
                } else {
                    od.f("Index must be between 0 and size");
                    return;
                }
            } else {
                vj0Var.a(j);
            }
            if (zhVar.e == 3) {
                zhVar.e = 0;
            }
            long[] jArr2 = vj0Var.a;
            int i3 = vj0Var.b;
            float f = 0.0f;
            float f2 = 0.0f;
            for (int i4 = 0; i4 < i3; i4++) {
                f2 += Float.intBitsToFloat((int) (jArr2[i4] >> 32));
            }
            int i5 = vj0Var.b;
            float f3 = f2 / i5;
            long[] jArr3 = vj0Var.a;
            for (int i6 = 0; i6 < i5; i6++) {
                f += Float.intBitsToFloat((int) (jArr3[i6] & 4294967295L));
            }
            q11Var.B0(new mr((Float.floatToRawIntBits(f3) << 32) | (Float.floatToRawIntBits(f / vj0Var.b) & 4294967295L), true));
        }
    }

    public final void f(v40 v40Var, v40 v40Var2, u40 u40Var, long j) {
        if (this.g == null) {
            this.g = new cz0(11);
        }
        this.l = 0L;
        cz0 d = d();
        q11 q11Var = this.a;
        k70.h(d, v40Var, q11Var.u, u40Var, this.j, this.l);
        long e = xm0.e(k70.L(v40Var2, q11Var.u, u40Var), j);
        q11Var.v.getClass();
        this.h = k70.N(q11Var).d(0L);
        q11Var.B0(new nr(e));
        zh zhVar = this.k;
        zhVar.e = 0;
        ((vj0) zhVar.f).b = 0;
    }
}