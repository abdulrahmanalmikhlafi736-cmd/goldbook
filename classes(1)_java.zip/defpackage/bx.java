package defpackage;

/* renamed from: bx  reason: default package */
public final class bx extends nl {
    public /* synthetic */ Object h;
    public int i;
    public final /* synthetic */ al j;
    public xq k;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public bx(al alVar, ml mlVar) {
        super(mlVar);
        this.j = alVar;
    }

    @Override // defpackage.db
    public final Object p(Object obj) {
        this.h = obj;
        this.i |= Integer.MIN_VALUE;
        return this.j.b(null, this);
    }
}