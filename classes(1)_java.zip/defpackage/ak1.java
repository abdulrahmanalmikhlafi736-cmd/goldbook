package defpackage;

import android.view.WindowInsets;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ak1  reason: default package */
public class ak1 extends zj1 {
    public ak1(hk1 hk1Var, WindowInsets windowInsets) {
        super(hk1Var, windowInsets);
    }

    public ak1(hk1 hk1Var, ak1 ak1Var) {
        super(hk1Var, ak1Var);
    }
}