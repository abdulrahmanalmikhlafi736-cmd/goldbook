package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ep0  reason: default package */
public final class ep0 extends jb0 {
    public final gw0 b;

    public ep0(gw0 gw0Var) {
        this.b = gw0Var;
    }

    public final boolean equals(Object obj) {
        if (this != obj) {
            if (obj instanceof ep0) {
                if (!this.b.equals(((ep0) obj).b)) {
                    return false;
                }
                return true;
            }
            return false;
        }
        return true;
    }

    public final int hashCode() {
        return this.b.hashCode();
    }

    @Override // defpackage.jb0
    public final gw0 k() {
        return this.b;
    }
}