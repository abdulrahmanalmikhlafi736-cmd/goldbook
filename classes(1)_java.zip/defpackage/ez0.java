package defpackage;

import java.util.Map;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ez0  reason: default package */
public final class ez0 implements Map.Entry {
    public final Object e;
    public final td0 f;
    public ez0 g;
    public ez0 h;

    public ez0(rd0 rd0Var, td0 td0Var) {
        this.e = rd0Var;
        this.f = td0Var;
    }

    @Override // java.util.Map.Entry
    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof ez0) {
            ez0 ez0Var = (ez0) obj;
            if (this.e.equals(ez0Var.e) && this.f == ez0Var.f) {
                return true;
            }
            return false;
        }
        return false;
    }

    @Override // java.util.Map.Entry
    public final Object getKey() {
        return this.e;
    }

    @Override // java.util.Map.Entry
    public final Object getValue() {
        return this.f;
    }

    @Override // java.util.Map.Entry
    public final int hashCode() {
        return this.f.hashCode() ^ this.e.hashCode();
    }

    @Override // java.util.Map.Entry
    public final Object setValue(Object obj) {
        throw new UnsupportedOperationException("An entry modification is not supported");
    }

    public final String toString() {
        return this.e + "=" + this.f;
    }
}