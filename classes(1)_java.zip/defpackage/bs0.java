package defpackage;

import java.util.Iterator;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bs0  reason: default package */
public final class bs0 extends m {
    public final rr0 e;

    public bs0(rr0 rr0Var) {
        this.e = rr0Var;
    }

    @Override // defpackage.m
    public final int a() {
        rr0 rr0Var = this.e;
        rr0Var.getClass();
        return rr0Var.f;
    }

    @Override // defpackage.m, java.util.Collection
    public final boolean contains(Object obj) {
        return this.e.containsValue(obj);
    }

    @Override // java.util.Collection, java.lang.Iterable
    public final Iterator iterator() {
        od1 od1Var = this.e.e;
        pd1[] pd1VarArr = new pd1[8];
        for (int i = 0; i < 8; i++) {
            pd1VarArr[i] = new qd1(2);
        }
        return new sr0(od1Var, pd1VarArr);
    }
}