package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ek  reason: default package */
public final class ek extends h90 implements m00 {
    public final /* synthetic */ int f = 0;
    public final /* synthetic */ m00 g;
    public final /* synthetic */ Object h;
    public final /* synthetic */ Object i;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public ek(lp0 lp0Var, nq0 nq0Var, m00 m00Var, int i) {
        super(2);
        this.h = lp0Var;
        this.i = nq0Var;
        this.g = m00Var;
    }

    @Override // defpackage.m00
    public final Object f(Object obj, Object obj2) {
        boolean z;
        int i = this.f;
        we1 we1Var = we1.a;
        m00 m00Var = this.g;
        Object obj3 = this.i;
        Object obj4 = this.h;
        switch (i) {
            case 0:
                ((Number) obj2).intValue();
                fk.a((lp0) obj4, (nq0) obj3, m00Var, (d10) obj, wc0.s(1));
                return we1Var;
            default:
                d10 d10Var = (d10) obj;
                int intValue = ((Number) obj2).intValue();
                pl1 pl1Var = (pl1) obj4;
                if ((intValue & 3) != 2) {
                    z = true;
                } else {
                    z = false;
                }
                if (d10Var.O(intValue & 1, z)) {
                    n4 n4Var = pl1Var.e;
                    boolean h = d10Var.h(pl1Var);
                    Object L = d10Var.L();
                    nq0 nq0Var = oj.a;
                    if (h || L == nq0Var) {
                        L = new ol1(pl1Var, null, 0);
                        d10Var.g0(L);
                    }
                    j70.j((m00) L, d10Var, n4Var);
                    boolean h2 = d10Var.h(pl1Var);
                    Object L2 = d10Var.L();
                    if (h2 || L2 == nq0Var) {
                        L2 = new ol1(pl1Var, null, 1);
                        d10Var.g0(L2);
                    }
                    j70.j((m00) L2, d10Var, n4Var);
                    ((mj) obj3).a(n4Var, m00Var, d10Var, 0);
                } else {
                    d10Var.R();
                }
                return we1Var;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public ek(pl1 pl1Var, mj mjVar, m00 m00Var) {
        super(2);
        this.h = pl1Var;
        this.i = mjVar;
        this.g = m00Var;
    }
}