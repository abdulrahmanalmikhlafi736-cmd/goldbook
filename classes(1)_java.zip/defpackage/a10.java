package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: a10  reason: default package */
public final class a10 implements ww0 {
    public final b10 e;

    public a10(b10 b10Var) {
        this.e = b10Var;
    }

    @Override // defpackage.ww0
    public final void c() {
    }

    @Override // defpackage.ww0
    public final void d() {
        this.e.w();
    }

    @Override // defpackage.ww0
    public final void e() {
        this.e.w();
    }
}