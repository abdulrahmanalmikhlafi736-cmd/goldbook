package defpackage;

import java.util.concurrent.CancellationException;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: a  reason: default package */
public final class a extends CancellationException {
    public final transient Object e;

    public a(uw uwVar) {
        super("Flow was aborted, no more elements needed");
        this.e = uwVar;
    }

    @Override // java.lang.Throwable
    public final Throwable fillInStackTrace() {
        setStackTrace(new StackTraceElement[0]);
        return this;
    }
}