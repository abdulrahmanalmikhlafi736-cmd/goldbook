package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dw  reason: default package */
public final class dw {
    public final float a;
    public final float b;

    public dw(float f, jp jpVar) {
        this.a = f;
        float a = jpVar.a();
        float f2 = ew.a;
        this.b = a * 386.0878f * 160.0f * 0.84f;
    }

    public final cw a(float f) {
        double b = b(f);
        double d = ew.a;
        double d2 = d - 1.0d;
        return new cw(f, (float) (Math.exp((d / d2) * b) * this.a * this.b), (long) (Math.exp(b / d2) * 1000.0d));
    }

    public final double b(float f) {
        float[] fArr = c6.a;
        return Math.log((Math.abs(f) * 0.35f) / (this.a * this.b));
    }
}