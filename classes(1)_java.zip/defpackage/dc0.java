package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dc0  reason: default package */
public final class dc0 extends li0 implements g21 {
    public xz s;
    public yb0 t;
    public bp0 u;
    public boolean v;
    public u01 w;
    public final ac0 x = new ac0(this, 0);
    public ac0 y;

    public dc0(xz xzVar, yb0 yb0Var, bp0 bp0Var, boolean z) {
        this.s = xzVar;
        this.t = yb0Var;
        this.u = bp0Var;
        this.v = z;
        r0();
    }

    @Override // defpackage.g21
    public final void Q(r21 r21Var) {
        a90[] a90VarArr = p21.a;
        q21 q21Var = n21.n;
        a90[] a90VarArr2 = p21.a;
        a90 a90Var = a90VarArr2[6];
        r21Var.a(q21Var, Boolean.TRUE);
        r21Var.a(n21.L, this.x);
        bp0 bp0Var = this.u;
        u01 u01Var = this.w;
        if (bp0Var == bp0.e) {
            if (u01Var != null) {
                q21 q21Var2 = n21.w;
                a90 a90Var2 = a90VarArr2[13];
                r21Var.a(q21Var2, u01Var);
            } else {
                k70.T("scrollAxisRange");
                throw null;
            }
        } else if (u01Var != null) {
            q21 q21Var3 = n21.v;
            a90 a90Var3 = a90VarArr2[12];
            r21Var.a(q21Var3, u01Var);
        } else {
            k70.T("scrollAxisRange");
            throw null;
        }
        ac0 ac0Var = this.y;
        if (ac0Var != null) {
            r21Var.a(c21.f, new o0(null, ac0Var));
        }
        r21Var.a(c21.B, new o0(null, new j3(22, new bc0(this, 2))));
        yb0 yb0Var = this.t;
        yb0Var.getClass();
        sg sgVar = new sg(1, ((Number) yb0Var.a.getValue()).intValue());
        q21 q21Var4 = n21.f;
        a90 a90Var4 = a90VarArr2[23];
        r21Var.a(q21Var4, sgVar);
    }

    @Override // defpackage.g21
    public final /* synthetic */ boolean S() {
        return false;
    }

    @Override // defpackage.g21
    public final /* synthetic */ boolean T() {
        return false;
    }

    @Override // defpackage.g21
    public final /* synthetic */ boolean e() {
        return true;
    }

    @Override // defpackage.li0
    public final boolean e0() {
        return false;
    }

    public final void r0() {
        ac0 ac0Var;
        this.w = new u01(new bc0(this, 0), new bc0(this, 1));
        if (this.v) {
            ac0Var = new ac0(this, 1);
        } else {
            ac0Var = null;
        }
        this.y = ac0Var;
    }
}