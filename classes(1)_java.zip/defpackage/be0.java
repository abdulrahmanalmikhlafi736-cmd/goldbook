package defpackage;

import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: be0  reason: default package */
public final class be0 extends ul implements bp {
    public static final /* synthetic */ AtomicIntegerFieldUpdater l = AtomicIntegerFieldUpdater.newUpdater(be0.class, "runningWorkers$volatile");
    public final /* synthetic */ bp g;
    public final ul h;
    public final int i;
    public final pf0 j;
    public final Object k;
    private volatile /* synthetic */ int runningWorkers$volatile;

    public be0(ul ulVar, int i) {
        bp bpVar;
        if (ulVar instanceof bp) {
            bpVar = (bp) ulVar;
        } else {
            bpVar = null;
        }
        this.g = bpVar == null ? go.a : bpVar;
        this.h = ulVar;
        this.i = i;
        this.j = new pf0();
        this.k = new Object();
    }

    @Override // defpackage.bp
    public final sq c(long j, jc1 jc1Var, sl slVar) {
        return this.g.c(j, jc1Var, slVar);
    }

    @Override // defpackage.bp
    public final void d(long j, ne neVar) {
        this.g.d(j, neVar);
    }

    @Override // defpackage.ul
    public final void e(sl slVar, Runnable runnable) {
        boolean z;
        Runnable j;
        this.j.a(runnable);
        AtomicIntegerFieldUpdater atomicIntegerFieldUpdater = l;
        if (atomicIntegerFieldUpdater.get(this) < this.i) {
            synchronized (this.k) {
                AtomicIntegerFieldUpdater atomicIntegerFieldUpdater2 = l;
                if (atomicIntegerFieldUpdater2.get(this) >= this.i) {
                    z = false;
                } else {
                    atomicIntegerFieldUpdater2.incrementAndGet(this);
                    z = true;
                }
            }
            if (z && (j = j()) != null) {
                try {
                    wl1.H(this.h, this, new ae0(this, j));
                } catch (Throwable th) {
                    atomicIntegerFieldUpdater.decrementAndGet(this);
                    throw th;
                }
            }
        }
    }

    public final Runnable j() {
        while (true) {
            Runnable runnable = (Runnable) this.j.d();
            if (runnable == null) {
                synchronized (this.k) {
                    AtomicIntegerFieldUpdater atomicIntegerFieldUpdater = l;
                    atomicIntegerFieldUpdater.decrementAndGet(this);
                    if (this.j.c() == 0) {
                        return null;
                    }
                    atomicIntegerFieldUpdater.incrementAndGet(this);
                }
            } else {
                return runnable;
            }
        }
    }

    @Override // defpackage.ul
    public final String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(this.h);
        sb.append(".limitedParallelism(");
        return fu0.G(sb, this.i, ')');
    }
}