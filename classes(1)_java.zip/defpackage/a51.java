package defpackage;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: a51  reason: default package */
public final class a51 {
    public static final a51 e;
    public static final a51 f;
    public static final a51 g;
    public static final /* synthetic */ a51[] h;
    /* JADX INFO: Fake field, exist only in values array */
    a51 EF0;

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r11v1, types: [java.lang.Enum, a51] */
    /* JADX WARN: Type inference failed for: r13v1, types: [java.lang.Enum, a51] */
    /* JADX WARN: Type inference failed for: r1v1, types: [java.lang.Enum, a51] */
    static {
        Enum r0 = new Enum("CornerExtraExtraLarge", 0);
        ?? r1 = new Enum("CornerExtraLarge", 1);
        e = r1;
        Enum r3 = new Enum("CornerExtraLargeIncreased", 2);
        Enum r5 = new Enum("CornerExtraLargeTop", 3);
        Enum r7 = new Enum("CornerExtraSmall", 4);
        Enum r9 = new Enum("CornerExtraSmallTop", 5);
        ?? r11 = new Enum("CornerFull", 6);
        f = r11;
        ?? r13 = new Enum("CornerLarge", 7);
        g = r13;
        h = new a51[]{r0, r1, r3, r5, r7, r9, r11, r13, new Enum("CornerLargeEnd", 8), new Enum("CornerLargeIncreased", 9), new Enum("CornerLargeStart", 10), new Enum("CornerLargeTop", 11), new Enum("CornerMedium", 12), new Enum("CornerNone", 13), new Enum("CornerSmall", 14)};
    }

    public static a51 valueOf(String str) {
        return (a51) Enum.valueOf(a51.class, str);
    }

    public static a51[] values() {
        return (a51[]) h.clone();
    }
}