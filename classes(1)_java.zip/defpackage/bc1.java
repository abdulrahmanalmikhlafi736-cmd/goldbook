package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bc1  reason: default package */
public final class bc1 {
    public final int a;
    public final la b;
    public final c c;
    public bc1 d;
    public long e;
    public long f;
    public long g = Long.MIN_VALUE;
    public final /* synthetic */ cc1 h;

    public bc1(cc1 cc1Var, int i, la laVar, c cVar) {
        this.h = cc1Var;
        this.a = i;
        this.b = laVar;
        this.c = cVar;
    }

    public final void a(long j, long j2, long j3, long j4, float[] fArr) {
        rw0 rw0Var;
        rw0 rw0Var2;
        long C;
        long j5 = this.h.f;
        la laVar = this.b;
        gm0 M = k70.M(laVar, 2);
        ba0 O = k70.O(laVar);
        boolean I = O.I();
        em0 em0Var = O.J;
        if (!I) {
            rw0Var2 = null;
        } else {
            if (em0Var.d != M) {
                long floatToRawIntBits = Float.floatToRawIntBits((int) (j >> 32));
                long j6 = M.g;
                gm0 gm0Var = em0Var.d;
                gm0Var.getClass();
                rw0Var = new rw0(vd1.C(gm0Var.x(M, (Float.floatToRawIntBits((int) (j & 4294967295L)) & 4294967295L) | (floatToRawIntBits << 32))), (4294967295L & (((int) (C & 4294967295L)) + ((int) (j6 & 4294967295L)))) | ((((int) (C >> 32)) + ((int) (j6 >> 32))) << 32), j3, j4, j5, fArr, laVar);
            } else {
                rw0Var = new rw0(j, j2, j3, j4, j5, fArr, laVar);
            }
            rw0Var2 = rw0Var;
        }
        if (rw0Var2 == null) {
            return;
        }
        this.c.i(rw0Var2);
    }

    public final void b() {
        bc1 bc1Var;
        cc1 cc1Var = this.h;
        sj0 sj0Var = cc1Var.a;
        int i = this.a;
        bc1 bc1Var2 = (bc1) sj0Var.g(i);
        if (bc1Var2 != null) {
            if (bc1Var2 != this) {
                int d = sj0Var.d(i);
                Object[] objArr = sj0Var.c;
                Object obj = objArr[d];
                sj0Var.b[d] = i;
                objArr[d] = bc1Var2;
                while (true) {
                    bc1 bc1Var3 = bc1Var2.d;
                    if (bc1Var3 == null) {
                        break;
                    } else if (bc1Var3 == this) {
                        bc1Var2.d = this.d;
                        this.d = null;
                        return;
                    } else {
                        bc1Var2 = bc1Var3;
                    }
                }
            } else {
                bc1 bc1Var4 = this.d;
                this.d = null;
                if (bc1Var4 != null) {
                    int d2 = sj0Var.d(i);
                    Object[] objArr2 = sj0Var.c;
                    Object obj2 = objArr2[d2];
                    sj0Var.b[d2] = i;
                    objArr2[d2] = bc1Var4;
                    return;
                }
                ba0 O = k70.O(this.b.e);
                if (O.k) {
                    ((n4) ea0.a(O)).getRectManager().a.f(O.f, false);
                    return;
                }
                return;
            }
        }
        bc1 bc1Var5 = cc1Var.b;
        if (bc1Var5 == this) {
            cc1Var.b = bc1Var5.d;
            this.d = null;
            return;
        }
        if (bc1Var5 != null) {
            bc1Var = bc1Var5.d;
        } else {
            bc1Var = null;
        }
        while (true) {
            bc1 bc1Var6 = bc1Var5;
            bc1Var5 = bc1Var;
            if (bc1Var5 != null) {
                if (bc1Var5 == this) {
                    if (bc1Var6 != null) {
                        bc1Var6.d = bc1Var5.d;
                    }
                    this.d = null;
                    return;
                }
                bc1Var = bc1Var5.d;
            } else {
                return;
            }
        }
    }
}