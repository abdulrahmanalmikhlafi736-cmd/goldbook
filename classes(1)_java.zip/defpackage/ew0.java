package defpackage;

import android.os.Bundle;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ew0  reason: default package */
public final class ew0 implements vz0 {
    public final LinkedHashSet a = new LinkedHashSet();

    public ew0(al alVar) {
        alVar.s("androidx.savedstate.Restarter", this);
    }

    @Override // defpackage.vz0
    public final Bundle a() {
        ArrayList<String> arrayList;
        Bundle j = a5.j((zp0[]) Arrays.copyOf(new zp0[0], 0));
        List c0 = tg.c0(this.a);
        if (c0 instanceof ArrayList) {
            arrayList = (ArrayList) c0;
        } else {
            arrayList = new ArrayList<>(c0);
        }
        j.putStringArrayList("classes_to_restore", arrayList);
        return j;
    }
}