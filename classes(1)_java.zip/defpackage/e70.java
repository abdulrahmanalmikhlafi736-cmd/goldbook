package defpackage;

import java.util.List;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: e70  reason: default package */
public final class e70 {
    public final xf0 a;
    public final al b;
    public boolean c;

    public e70(xf0 xf0Var, al alVar) {
        this.a = xf0Var;
        this.b = alVar;
    }

    public final boolean a(long j) {
        Object obj;
        List list = (List) this.b.f;
        int size = list.size();
        int i = 0;
        while (true) {
            if (i < size) {
                obj = list.get(i);
                if (sb0.k(((ft0) obj).a, j)) {
                    break;
                }
                i++;
            } else {
                obj = null;
                break;
            }
        }
        ft0 ft0Var = (ft0) obj;
        if (ft0Var == null) {
            return false;
        }
        return ft0Var.h;
    }
}