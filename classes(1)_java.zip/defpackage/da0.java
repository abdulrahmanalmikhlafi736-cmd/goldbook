package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: da0  reason: default package */
public final class da0 implements es {
    public final te e = new te();
    public ds f;

    @Override // defpackage.es
    public final void D(h6 h6Var, long j, long j2, long j3, float f, pb pbVar, int i) {
        this.e.D(h6Var, j, j2, j3, f, pbVar, i);
    }

    @Override // defpackage.jp
    public final int F(float f) {
        te teVar = this.e;
        teVar.getClass();
        return fu0.k(f, teVar);
    }

    @Override // defpackage.jp
    public final long K(long j) {
        te teVar = this.e;
        teVar.getClass();
        return fu0.p(j, teVar);
    }

    @Override // defpackage.jp
    public final float N(long j) {
        te teVar = this.e;
        teVar.getClass();
        return fu0.o(j, teVar);
    }

    @Override // defpackage.jp
    public final long V(float f) {
        return this.e.V(f);
    }

    @Override // defpackage.jp
    public final float a() {
        return this.e.a();
    }

    @Override // defpackage.es
    public final long b() {
        return this.e.f.t();
    }

    @Override // defpackage.jp
    public final float b0(int i) {
        return this.e.b0(i);
    }

    public final void c() {
        te teVar = this.e;
        re q = teVar.f.q();
        ds dsVar = this.f;
        if (dsVar != null) {
            li0 li0Var = (li0) dsVar;
            dp dpVar = li0Var.e.j;
            if (dpVar != null && (dpVar.h & 4) != 0) {
                while (dpVar != null) {
                    int i = dpVar.g;
                    if ((i & 2) != 0) {
                        break;
                    } else if ((i & 4) != 0) {
                        break;
                    } else {
                        dpVar = dpVar.j;
                    }
                }
            }
            dpVar = null;
            if (dpVar != null) {
                qk0 qk0Var = null;
                while (dpVar != null) {
                    if (dpVar instanceof ds) {
                        ds dsVar2 = (ds) dpVar;
                        i20 i20Var = (i20) teVar.f.g;
                        gm0 M = k70.M(dsVar2, 4);
                        long M2 = wl1.M(M.g);
                        ba0 ba0Var = M.s;
                        ba0Var.getClass();
                        ((n4) ea0.a(ba0Var)).getSharedDrawScope().d(q, M2, M, dsVar2, i20Var);
                    } else if ((dpVar.g & 4) != 0 && (dpVar instanceof dp)) {
                        int i2 = 0;
                        for (li0 li0Var2 = dpVar.t; li0Var2 != null; li0Var2 = li0Var2.j) {
                            if ((li0Var2.g & 4) != 0) {
                                i2++;
                                if (i2 == 1) {
                                    dpVar = li0Var2;
                                } else {
                                    if (qk0Var == null) {
                                        qk0Var = new qk0(new li0[16]);
                                    }
                                    if (dpVar != null) {
                                        qk0Var.b(dpVar);
                                        dpVar = null;
                                    }
                                    qk0Var.b(li0Var2);
                                }
                            }
                        }
                        if (i2 == 1) {
                        }
                    }
                    dpVar = k70.m(qk0Var);
                }
                return;
            }
            gm0 M3 = k70.M(dsVar, 4);
            if (M3.y0() == li0Var.e) {
                M3 = M3.t;
                M3.getClass();
            }
            M3.N0(q, (i20) teVar.f.g);
            return;
        }
        throw fu0.C("Attempting to drawContent for a `null` node. This usually means that a call to ContentDrawScope#drawContent() has been captured inside a lambda, and is being invoked outside of the draw pass. Capturing the scope this way is unsupported - if you are trying to record drawContent with graphicsLayer.record(), make sure you are using the GraphicsLayer#record function within DrawScope, instead of the member function on GraphicsLayer.");
    }

    @Override // defpackage.jp
    public final float c0(float f) {
        return f / this.e.a();
    }

    public final void d(re reVar, long j, gm0 gm0Var, ds dsVar, i20 i20Var) {
        ds dsVar2 = this.f;
        this.f = dsVar;
        o90 o90Var = gm0Var.s.D;
        te teVar = this.e;
        k9 k9Var = teVar.f;
        se seVar = ((te) k9Var.h).e;
        jp jpVar = seVar.a;
        o90 o90Var2 = seVar.b;
        re q = k9Var.q();
        k9 k9Var2 = teVar.f;
        long t = k9Var2.t();
        i20 i20Var2 = (i20) k9Var2.g;
        k9Var2.C(gm0Var);
        k9Var2.D(o90Var);
        k9Var2.B(reVar);
        k9Var2.E(j);
        k9Var2.g = i20Var;
        reVar.i();
        try {
            dsVar.C(this);
            reVar.g();
            k9Var2.C(jpVar);
            k9Var2.D(o90Var2);
            k9Var2.B(q);
            k9Var2.E(t);
            k9Var2.g = i20Var2;
            this.f = dsVar2;
        } catch (Throwable th) {
            reVar.g();
            k9Var2.C(jpVar);
            k9Var2.D(o90Var2);
            k9Var2.B(q);
            k9Var2.E(t);
            k9Var2.g = i20Var2;
            throw th;
        }
    }

    public final void e(r6 r6Var, long j, ac acVar) {
        te teVar = this.e;
        teVar.e.c.f(r6Var, te.c(teVar, j, acVar, 3));
    }

    @Override // defpackage.jp
    public final float g() {
        return this.e.g();
    }

    @Override // defpackage.es
    public final o90 getLayoutDirection() {
        return this.e.e.b;
    }

    @Override // defpackage.es
    public final void k(long j, long j2, long j3, ac acVar, int i) {
        this.e.k(j, j2, j3, acVar, i);
    }

    @Override // defpackage.es
    public final void p(r6 r6Var, zi1 zi1Var, float f, ac acVar, int i) {
        this.e.p(r6Var, zi1Var, f, acVar, i);
    }

    @Override // defpackage.jp
    public final float q(float f) {
        return this.e.a() * f;
    }

    @Override // defpackage.es
    public final k9 u() {
        return this.e.f;
    }

    @Override // defpackage.jp
    public final float y(long j) {
        te teVar = this.e;
        teVar.getClass();
        return fu0.m(j, teVar);
    }
}