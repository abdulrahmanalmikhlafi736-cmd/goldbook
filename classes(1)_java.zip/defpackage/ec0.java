package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ec0  reason: default package */
public final class ec0 {
    public final sc0 a;

    public ec0(sc0 sc0Var) {
        this.a = sc0Var;
    }
}