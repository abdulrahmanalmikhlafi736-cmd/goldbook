package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ag1  reason: default package */
public final class ag1 extends wp0 {
    public final lq0 e = mc0.t(new s51(0));
    public final lq0 f = mc0.t(Boolean.FALSE);
    public final wf1 g;
    public final lq0 h;
    public float i;
    public pb j;

    public ag1(s20 s20Var) {
        wf1 wf1Var = new wf1(s20Var);
        wf1Var.f = new f8(13, this);
        this.g = wf1Var;
        this.h = new lq0(we1.a, e3.X);
        this.i = 1.0f;
    }

    @Override // defpackage.wp0
    public final void a(float f) {
        this.i = f;
    }

    @Override // defpackage.wp0
    public final void b(pb pbVar) {
        this.j = pbVar;
    }

    @Override // defpackage.wp0
    public final long d() {
        return ((s51) this.e.getValue()).a;
    }

    @Override // defpackage.wp0
    public final void e(da0 da0Var) {
        te teVar = da0Var.e;
        pb pbVar = this.j;
        wf1 wf1Var = this.g;
        if (pbVar == null) {
            pbVar = (pb) wf1Var.g.getValue();
        }
        if (((Boolean) this.f.getValue()).booleanValue() && da0Var.getLayoutDirection() == o90.f) {
            long e = teVar.e();
            k9 k9Var = teVar.f;
            long t = k9Var.t();
            k9Var.q().i();
            try {
                ((pg0) k9Var.f).C(-1.0f, 1.0f, e);
                wf1Var.e(da0Var, this.i, pbVar);
            } finally {
                k9Var.q().g();
                k9Var.E(t);
            }
        } else {
            wf1Var.e(da0Var, this.i, pbVar);
        }
        this.h.getValue();
    }
}