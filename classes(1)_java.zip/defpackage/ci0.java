package defpackage;

import android.util.SparseArray;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ci0  reason: default package */
public final class ci0 {
    public final SparseArray a;
    public fe1 b;

    public ci0(int i) {
        this.a = new SparseArray(i);
    }

    public final void a(fe1 fe1Var, int i, int i2) {
        ci0 ci0Var;
        int a = fe1Var.a(i);
        SparseArray sparseArray = this.a;
        if (sparseArray == null) {
            ci0Var = null;
        } else {
            ci0Var = (ci0) sparseArray.get(a);
        }
        if (ci0Var == null) {
            ci0Var = new ci0(1);
            sparseArray.put(fe1Var.a(i), ci0Var);
        }
        if (i2 > i) {
            ci0Var.a(fe1Var, i + 1, i2);
        } else {
            ci0Var.b = fe1Var;
        }
    }
}