package defpackage;

import java.util.Iterator;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dz0  reason: default package */
public final class dz0 extends gz0 implements Iterator {
    public ez0 e;
    public ez0 f;
    public final /* synthetic */ int g;

    public dz0(ez0 ez0Var, ez0 ez0Var2, int i) {
        this.g = i;
        this.e = ez0Var2;
        this.f = ez0Var;
    }

    @Override // defpackage.gz0
    public final void a(ez0 ez0Var) {
        ez0 ez0Var2;
        ez0 ez0Var3 = null;
        if (this.e == ez0Var && ez0Var == this.f) {
            this.f = null;
            this.e = null;
        }
        ez0 ez0Var4 = this.e;
        if (ez0Var4 == ez0Var) {
            switch (this.g) {
                case 0:
                    ez0Var2 = ez0Var4.h;
                    break;
                default:
                    ez0Var2 = ez0Var4.g;
                    break;
            }
            this.e = ez0Var2;
        }
        ez0 ez0Var5 = this.f;
        if (ez0Var5 == ez0Var) {
            ez0 ez0Var6 = this.e;
            if (ez0Var5 != ez0Var6 && ez0Var6 != null) {
                ez0Var3 = b(ez0Var5);
            }
            this.f = ez0Var3;
        }
    }

    public final ez0 b(ez0 ez0Var) {
        switch (this.g) {
            case 0:
                return ez0Var.g;
            default:
                return ez0Var.h;
        }
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        if (this.f != null) {
            return true;
        }
        return false;
    }

    @Override // java.util.Iterator
    public final Object next() {
        ez0 ez0Var;
        ez0 ez0Var2 = this.f;
        ez0 ez0Var3 = this.e;
        if (ez0Var2 != ez0Var3 && ez0Var3 != null) {
            ez0Var = b(ez0Var2);
        } else {
            ez0Var = null;
        }
        this.f = ez0Var;
        return ez0Var2;
    }
}