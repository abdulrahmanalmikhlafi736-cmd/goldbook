package defpackage;

import java.util.concurrent.atomic.AtomicReference;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: al0  reason: default package */
public final class al0 {
    public final AtomicReference a = new AtomicReference(null);
    public final cl0 b = new cl0();

    public static Object a(al0 al0Var, i00 i00Var, nl nlVar) {
        al0Var.getClass();
        return vd1.i(new xk0(al0Var, i00Var, null), nlVar);
    }
}