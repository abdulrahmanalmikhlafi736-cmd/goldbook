package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: a70  reason: default package */
public final /* synthetic */ class a70 extends w00 implements m00 {
    public static final a70 l = new w00(2, gh0.class, "min", "min(II)I", 1);

    @Override // defpackage.m00
    public final Object f(Object obj, Object obj2) {
        return Integer.valueOf(Math.min(((Number) obj).intValue(), ((Number) obj2).intValue()));
    }
}