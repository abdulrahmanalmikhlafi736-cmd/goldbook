package defpackage;

import java.util.List;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bg1  reason: default package */
public final class bg1 extends zf1 {
    public final String e;
    public final List f;
    public final int g;
    public final zi1 h;
    public final float i;
    public final zi1 j;
    public final float k;
    public final float l;
    public final int m;
    public final int n;
    public final float o;
    public final float p;
    public final float q;
    public final float r;

    public bg1(String str, List list, int i, zi1 zi1Var, float f, zi1 zi1Var2, float f2, float f3, int i2, int i3, float f4, float f5, float f6, float f7) {
        this.e = str;
        this.f = list;
        this.g = i;
        this.h = zi1Var;
        this.i = f;
        this.j = zi1Var2;
        this.k = f2;
        this.l = f3;
        this.m = i2;
        this.n = i3;
        this.o = f4;
        this.p = f5;
        this.q = f6;
        this.r = f7;
    }

    public final boolean equals(Object obj) {
        if (this != obj) {
            if (obj != null && bg1.class == obj.getClass()) {
                bg1 bg1Var = (bg1) obj;
                if (this.e.equals(bg1Var.e) && k70.p(this.h, bg1Var.h) && this.i == bg1Var.i && k70.p(this.j, bg1Var.j) && this.k == bg1Var.k && this.l == bg1Var.l && this.m == bg1Var.m && this.n == bg1Var.n && this.o == bg1Var.o && this.p == bg1Var.p && this.q == bg1Var.q && this.r == bg1Var.r && this.g == bg1Var.g && k70.p(this.f, bg1Var.f)) {
                    return true;
                }
                return false;
            }
            return false;
        }
        return true;
    }

    public final int hashCode() {
        int i;
        int hashCode = (this.f.hashCode() + (this.e.hashCode() * 31)) * 31;
        int i2 = 0;
        zi1 zi1Var = this.h;
        if (zi1Var != null) {
            i = zi1Var.hashCode();
        } else {
            i = 0;
        }
        int z = fu0.z(this.i, (hashCode + i) * 31, 31);
        zi1 zi1Var2 = this.j;
        if (zi1Var2 != null) {
            i2 = zi1Var2.hashCode();
        }
        return fu0.z(this.r, fu0.z(this.q, fu0.z(this.p, fu0.z(this.o, (((fu0.z(this.l, fu0.z(this.k, (z + i2) * 31, 31), 31) + this.m) * 31) + this.n) * 31, 31), 31), 31), 31) + this.g;
    }
}