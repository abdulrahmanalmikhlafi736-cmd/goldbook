package defpackage;

import android.view.View;
import android.view.inputmethod.InputMethodManager;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: e40  reason: default package */
public abstract class e40 {
    public abstract boolean a(InputMethodManager inputMethodManager);

    public abstract Object b(InputMethodManager inputMethodManager);

    public abstract View c(InputMethodManager inputMethodManager);
}