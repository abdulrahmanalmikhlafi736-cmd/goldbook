package defpackage;

import java.util.Arrays;
import java.util.List;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ba0  reason: default package */
public final class ba0 implements wi, mp0, ij {
    public static final ly0 V = new ly0("Undefined intrinsics block and it is required", 1);
    public static final w90 W = new Object();
    public static final v6 X = new v6(4);
    public mh0 A;
    public al B;
    public jp C;
    public o90 D;
    public yg1 E;
    public ck F;
    public z90 G;
    public z90 H;
    public boolean I;
    public final em0 J;
    public final fa0 K;
    public pa0 L;
    public gm0 M;
    public boolean N;
    public mi0 O;
    public mi0 P;
    public k7 Q;
    public l7 R;
    public boolean S;
    public int T;
    public boolean U;
    public final boolean e;
    public int f;
    public boolean g;
    public long h;
    public boolean i;
    public boolean j;
    public boolean k;
    public ba0 l;
    public int m;
    public final al n;
    public qk0 o;
    public boolean p;
    public ba0 q;
    public lp0 r;
    public ah1 s;
    public int t;
    public boolean u;
    public boolean v;
    public d21 w;
    public boolean x;
    public final qk0 y;
    public boolean z;

    public ba0(int i, boolean z) {
        this.e = z;
        this.f = i;
        this.h = 9223372034707292159L;
        this.i = true;
        this.j = true;
        this.n = new al(12, new qk0(new ba0[16]), new f8(5, this));
        this.y = new qk0(new ba0[16]);
        this.z = true;
        this.A = V;
        this.C = ea0.a;
        this.D = o90.e;
        this.E = W;
        ck.d.getClass();
        this.F = bk.b;
        z90 z90Var = z90.g;
        this.G = z90Var;
        this.H = z90Var;
        this.J = new em0(this);
        this.K = new fa0(this);
        this.N = true;
        this.O = ji0.a;
    }

    public static void T(ba0 ba0Var, boolean z, int i) {
        boolean z2;
        ba0 v;
        boolean z3 = false;
        if ((i & 1) != 0) {
            z = false;
        }
        if ((i & 2) != 0) {
            z2 = true;
        } else {
            z2 = false;
        }
        if ((i & 4) != 0) {
            z3 = true;
        }
        if (ba0Var.l == null) {
            p50.b("Lookahead measure cannot be requested on a node that is not a part of the LookaheadScope");
        }
        lp0 lp0Var = ba0Var.r;
        if (lp0Var != null && !ba0Var.u && !ba0Var.e) {
            ((n4) lp0Var).C(ba0Var, true, z, z2);
            if (z3) {
                hg0 hg0Var = ba0Var.K.q;
                hg0Var.getClass();
                fa0 fa0Var = hg0Var.j;
                ba0 v2 = fa0Var.a.v();
                z90 z90Var = fa0Var.a.G;
                if (v2 != null && z90Var != z90.g) {
                    while (v2.G == z90Var && (v = v2.v()) != null) {
                        v2 = v;
                    }
                    int ordinal = z90Var.ordinal();
                    if (ordinal != 0) {
                        if (ordinal == 1) {
                            if (v2.l != null) {
                                v2.S(z);
                                return;
                            } else {
                                v2.U(z);
                                return;
                            }
                        }
                        od.p("Intrinsics isn't used by the parent");
                    } else if (v2.l != null) {
                        T(v2, z, 6);
                    } else {
                        V(v2, z, 6);
                    }
                }
            }
        }
    }

    public static void V(ba0 ba0Var, boolean z, int i) {
        boolean z2;
        boolean z3;
        lp0 lp0Var;
        ba0 v;
        if ((i & 1) != 0) {
            z = false;
        }
        if ((i & 2) != 0) {
            z2 = true;
        } else {
            z2 = false;
        }
        if ((i & 4) != 0) {
            z3 = true;
        } else {
            z3 = false;
        }
        if (!ba0Var.u && !ba0Var.e && (lp0Var = ba0Var.r) != null) {
            ((n4) lp0Var).C(ba0Var, false, z, z2);
            if (z3) {
                fa0 fa0Var = ba0Var.K.p.j;
                ba0 v2 = fa0Var.a.v();
                z90 z90Var = fa0Var.a.G;
                if (v2 != null && z90Var != z90.g) {
                    while (v2.G == z90Var && (v = v2.v()) != null) {
                        v2 = v;
                    }
                    int ordinal = z90Var.ordinal();
                    if (ordinal != 0) {
                        if (ordinal == 1) {
                            v2.U(z);
                            return;
                        } else {
                            od.p("Intrinsics isn't used by the parent");
                            return;
                        }
                    }
                    V(v2, z, 6);
                }
            }
        }
    }

    public static void W(ba0 ba0Var) {
        int i = aa0.a[ba0Var.K.d.ordinal()];
        fa0 fa0Var = ba0Var.K;
        if (i == 1) {
            if (fa0Var.e) {
                T(ba0Var, true, 6);
                return;
            }
            if (fa0Var.f) {
                ba0Var.S(true);
            }
            if (ba0Var.q()) {
                V(ba0Var, true, 6);
                return;
            } else if (ba0Var.p()) {
                ba0Var.U(true);
                return;
            } else {
                return;
            }
        }
        od.o(fa0Var.d, "Unexpected state ");
    }

    private final String j(ba0 ba0Var) {
        String str;
        StringBuilder sb = new StringBuilder("Cannot insert ");
        sb.append(ba0Var);
        sb.append(" because it already has a parent or an owner. This tree: ");
        sb.append(g(0));
        sb.append(" Other tree: ");
        ba0 ba0Var2 = ba0Var.q;
        if (ba0Var2 != null) {
            str = ba0Var2.g(0);
        } else {
            str = null;
        }
        sb.append(str);
        return sb.toString();
    }

    public final void A(long j, e30 e30Var, int i, boolean z) {
        em0 em0Var = this.J;
        gm0 gm0Var = em0Var.d;
        sx0 sx0Var = gm0.Q;
        em0Var.d.D0(gm0.S, gm0Var.v0(j), e30Var, i, z);
    }

    public final void B(int i, ba0 ba0Var) {
        if (ba0Var.q != null && ba0Var.r != null) {
            p50.b(j(ba0Var));
        }
        ba0Var.q = this;
        al alVar = this.n;
        ((qk0) alVar.f).a(i, ba0Var);
        ((f8) alVar.g).a();
        O();
        if (ba0Var.e) {
            this.m++;
        }
        G();
        lp0 lp0Var = this.r;
        if (lp0Var != null) {
            ba0Var.d(lp0Var);
        }
        if (ba0Var.K.l > 0) {
            fa0 fa0Var = this.K;
            fa0Var.d(fa0Var.l + 1);
        }
        if (ba0Var.T > 0) {
            a0(this.T + 1);
        }
    }

    public final void C() {
        kp0 kp0Var;
        if (this.N) {
            em0 em0Var = this.J;
            gm0 gm0Var = em0Var.c;
            gm0 gm0Var2 = em0Var.d.u;
            this.M = null;
            while (true) {
                if (k70.p(gm0Var, gm0Var2)) {
                    break;
                }
                if (gm0Var != null) {
                    kp0Var = gm0Var.P;
                } else {
                    kp0Var = null;
                }
                if (kp0Var != null) {
                    this.M = gm0Var;
                    break;
                } else if (gm0Var != null) {
                    gm0Var = gm0Var.u;
                } else {
                    gm0Var = null;
                }
            }
            this.N = false;
        }
        gm0 gm0Var3 = this.M;
        if (gm0Var3 != null && gm0Var3.P == null) {
            throw fu0.C("layer was not set");
        }
        if (gm0Var3 != null) {
            gm0Var3.F0();
            return;
        }
        ba0 v = v();
        if (v != null) {
            v.C();
            return;
        }
        lp0 lp0Var = this.r;
        if (lp0Var != null) {
            ((n4) lp0Var).invalidate();
        }
    }

    public final void D() {
        em0 em0Var = this.J;
        gm0 gm0Var = em0Var.d;
        v50 v50Var = em0Var.c;
        while (gm0Var != v50Var) {
            gm0Var.getClass();
            v90 v90Var = (v90) gm0Var;
            kp0 kp0Var = v90Var.P;
            if (kp0Var != null) {
                ((l20) kp0Var).c();
            }
            gm0Var = v90Var.t;
        }
        kp0 kp0Var2 = em0Var.c.P;
        if (kp0Var2 != null) {
            ((l20) kp0Var2).c();
        }
    }

    public final void E() {
        if (this.e) {
            ba0 v = v();
            if (v != null) {
                v.E();
            }
        } else if (this.l != null) {
            T(this, false, 7);
        } else {
            V(this, false, 7);
        }
    }

    /* JADX WARN: Type inference failed for: r1v1, types: [nw0, java.lang.Object] */
    public final void F() {
        if (this.x) {
            return;
        }
        if (this.J.b.j != null || this.P != null) {
            this.v = true;
            return;
        }
        d21 d21Var = this.w;
        this.x = true;
        ?? obj = new Object();
        obj.e = new d21();
        op0 snapshotObserver = ((n4) ea0.a(this)).getSnapshotObserver();
        g4 g4Var = new g4(7, this, obj);
        snapshotObserver.a.b(this, snapshotObserver.d, g4Var);
        this.x = false;
        this.w = (d21) obj.e;
        this.v = false;
        n4 n4Var = (n4) ea0.a(this);
        n4Var.getSemanticsOwner().b(this, d21Var);
        n4Var.E();
    }

    public final void G() {
        ba0 ba0Var;
        if (this.m > 0) {
            this.p = true;
        }
        if (this.e && (ba0Var = this.q) != null) {
            ba0Var.G();
        }
    }

    public final boolean H() {
        if (this.r != null) {
            return true;
        }
        return false;
    }

    public final boolean I() {
        return this.K.p.v;
    }

    public final Boolean J() {
        boolean z;
        hg0 hg0Var = this.K.q;
        if (hg0Var != null) {
            if (hg0Var.t != fg0.g) {
                z = true;
            } else {
                z = false;
            }
            return Boolean.valueOf(z);
        }
        return null;
    }

    public final void K() {
        ba0 v;
        if (this.G == z90.g) {
            f();
        }
        hg0 hg0Var = this.K.q;
        hg0Var.getClass();
        boolean z = true;
        try {
            hg0Var.k = true;
            if (!hg0Var.o) {
                p50.b("replace() called on item that was not placed");
            }
            hg0Var.E = false;
            if (hg0Var.t == fg0.g) {
                z = false;
            }
            hg0Var.d0(hg0Var.r, hg0Var.s);
            if (z && !hg0Var.E && (v = hg0Var.j.a.v()) != null) {
                v.S(false);
            }
            hg0Var.k = false;
        } catch (Throwable th) {
            hg0Var.k = false;
            throw th;
        }
    }

    public final void L(int i, int i2, int i3) {
        int i4;
        if (i == i2) {
            return;
        }
        for (int i5 = 0; i5 < i3; i5++) {
            if (i > i2) {
                i4 = i + i5;
            } else {
                i4 = i;
            }
            int i6 = i > i2 ? i2 + i5 : (i2 + i3) - 2;
            al alVar = this.n;
            f8 f8Var = (f8) alVar.g;
            Object k = ((qk0) alVar.f).k(i4);
            f8Var.a();
            ((qk0) alVar.f).a(i6, (ba0) k);
            f8Var.a();
        }
        O();
        G();
        E();
    }

    public final void M(ba0 ba0Var) {
        fa0 fa0Var;
        if (ba0Var.K.l > 0) {
            this.K.d(fa0Var.l - 1);
        }
        if (this.r != null) {
            ba0Var.h();
        }
        ba0Var.q = null;
        if (ba0Var.T > 0) {
            a0(this.T - 1);
        }
        ba0Var.J.d.u = null;
        if (ba0Var.e) {
            this.m--;
            qk0 qk0Var = (qk0) ba0Var.n.f;
            Object[] objArr = qk0Var.e;
            int i = qk0Var.g;
            for (int i2 = 0; i2 < i; i2++) {
                ((ba0) objArr[i2]).J.d.u = null;
            }
        }
        G();
        O();
    }

    public final void N(gm0 gm0Var) {
        iw0 iw0Var;
        boolean z;
        lp0 lp0Var = this.r;
        if (lp0Var != null) {
            iw0Var = ((n4) lp0Var).getRectManager();
        } else {
            iw0Var = null;
        }
        fa0 fa0Var = this.K;
        int i = 0;
        if (fa0Var.d == x90.i && !q() && !p()) {
            z = false;
        } else {
            z = true;
        }
        if (this.k && iw0Var != null) {
            if (gm0Var == this.J.d) {
                this.j = true;
                if (!z) {
                    iw0Var.f(this);
                }
            } else {
                this.i = true;
                qk0 z2 = z();
                Object[] objArr = z2.e;
                int i2 = z2.g;
                for (int i3 = 0; i3 < i2; i3++) {
                    ba0 ba0Var = (ba0) objArr[i3];
                    ba0Var.j = true;
                    if (!z) {
                        iw0Var.f(ba0Var);
                    }
                }
                if (this.k) {
                    iw0Var.d = true;
                    i6 i6Var = iw0Var.a;
                    int i4 = this.f & 33554431;
                    long[] jArr = (long[]) i6Var.c;
                    int i5 = i6Var.b;
                    while (true) {
                        if (i >= jArr.length - 2 || i >= i5) {
                            break;
                        }
                        int i6 = i + 2;
                        long j = jArr[i6];
                        if ((((int) j) & 33554431) == i4) {
                            jArr[i6] = (((j >> 63) & 1) << 60) | j;
                            break;
                        }
                        i += 3;
                    }
                }
                iw0Var.i();
            }
        }
        fa0Var.p.e0();
    }

    public final void O() {
        if (this.e) {
            ba0 v = v();
            if (v != null) {
                v.O();
                return;
            }
            return;
        }
        this.z = true;
    }

    public final void P() {
        al alVar = this.n;
        int i = ((qk0) alVar.f).g;
        while (true) {
            i--;
            qk0 qk0Var = (qk0) alVar.f;
            if (-1 < i) {
                M((ba0) qk0Var.e[i]);
            } else {
                qk0Var.g();
                ((f8) alVar.g).a();
                return;
            }
        }
    }

    public final void Q(int i, int i2) {
        if (i2 < 0) {
            p50.a("count (" + i2 + ") must be greater than 0");
        }
        int i3 = (i2 + i) - 1;
        if (i > i3) {
            return;
        }
        while (true) {
            al alVar = this.n;
            M((ba0) ((qk0) alVar.f).e[i3]);
            Object k = ((qk0) alVar.f).k(i3);
            ((f8) alVar.g).a();
            ba0 ba0Var = (ba0) k;
            if (i3 != i) {
                i3--;
            } else {
                return;
            }
        }
    }

    public final void R() {
        ba0 v;
        if (this.G == z90.g) {
            f();
        }
        lh0 lh0Var = this.K.p;
        fa0 fa0Var = lh0Var.j;
        try {
            lh0Var.k = true;
            if (!lh0Var.o) {
                p50.b("replace called on unplaced item");
            }
            boolean z = lh0Var.v;
            lh0Var.a0(lh0Var.q, lh0Var.s, lh0Var.r);
            if (z && !lh0Var.I && (v = fa0Var.a.v()) != null) {
                v.U(false);
            }
        } finally {
        }
    }

    public final void S(boolean z) {
        lp0 lp0Var;
        if (!this.e && (lp0Var = this.r) != null) {
            ((n4) lp0Var).D(this, true, z);
        }
    }

    public final void U(boolean z) {
        lp0 lp0Var;
        if (!this.e && (lp0Var = this.r) != null) {
            ((n4) lp0Var).D(this, false, z);
        }
    }

    public final void X() {
        qk0 z = z();
        Object[] objArr = z.e;
        int i = z.g;
        for (int i2 = 0; i2 < i; i2++) {
            ba0 ba0Var = (ba0) objArr[i2];
            z90 z90Var = ba0Var.H;
            ba0Var.G = z90Var;
            if (z90Var != z90.g) {
                ba0Var.X();
            }
        }
    }

    public final void Y(Throwable th) {
        ck ckVar = this.F;
        k81 k81Var = xj.a;
        qr0 qr0Var = (qr0) ckVar;
        qr0Var.getClass();
        wj wjVar = (wj) gh0.L(qr0Var, k81Var);
        if (wjVar != null) {
            a5.P(th, new va(2, wjVar, this));
        }
        throw th;
    }

    public final void Z(jp jpVar) {
        if (!k70.p(this.C, jpVar)) {
            this.C = jpVar;
            E();
            ba0 v = v();
            if (v != null) {
                v.C();
            } else {
                lp0 lp0Var = this.r;
                if (lp0Var != null) {
                    ((n4) lp0Var).invalidate();
                }
            }
            D();
            for (li0 li0Var = this.J.f; li0Var != null; li0Var = li0Var.j) {
                li0Var.i0();
            }
        }
    }

    @Override // defpackage.wi
    public final void a() {
        ah1 ah1Var = this.s;
        if (ah1Var != null) {
            ah1Var.a();
        }
        pa0 pa0Var = this.L;
        if (pa0Var != null) {
            pa0Var.a();
        }
        em0 em0Var = this.J;
        gm0 gm0Var = em0Var.c.t;
        for (gm0 gm0Var2 = em0Var.d; !k70.p(gm0Var2, gm0Var) && gm0Var2 != null; gm0Var2 = gm0Var2.t) {
            gm0Var2.K0();
        }
    }

    public final void a0(int i) {
        ba0 v;
        ba0 v2;
        int i2 = this.T;
        if (i2 != i) {
            if (i > 0 && i2 == 0 && (v2 = v()) != null) {
                v2.a0(v2.T + 1);
            }
            if (i == 0 && this.T > 0 && (v = v()) != null) {
                v.a0(v.T - 1);
            }
            this.T = i;
        }
    }

    /* JADX WARN: Type inference failed for: r7v1 */
    /* JADX WARN: Type inference failed for: r7v16 */
    /* JADX WARN: Type inference failed for: r7v17 */
    /* JADX WARN: Type inference failed for: r7v3, types: [li0, gm0] */
    public final void b(mi0 mi0Var) {
        int i;
        ?? r7;
        boolean z;
        em0 em0Var;
        dm0 dm0Var;
        qk0 qk0Var;
        boolean z2;
        v50 v50Var;
        boolean z3;
        boolean z4;
        qk0 qk0Var2;
        boolean z5;
        boolean z6;
        j3 j3Var;
        em0 em0Var2 = this.J;
        boolean d = em0Var2.d(16);
        li0 li0Var = em0Var2.e;
        boolean d2 = em0Var2.d(1024);
        this.O = mi0Var;
        v50 v50Var2 = em0Var2.c;
        ba0 ba0Var = em0Var2.a;
        li0 li0Var2 = em0Var2.f;
        dm0 dm0Var2 = em0Var2.b;
        if (li0Var2 == dm0Var2) {
            p50.b("padChain called on already padded chain");
        }
        li0 li0Var3 = em0Var2.f;
        li0Var3.i = dm0Var2;
        dm0Var2.j = li0Var3;
        qk0 qk0Var3 = em0Var2.g;
        if (qk0Var3 != null) {
            i = qk0Var3.g;
        } else {
            i = 0;
        }
        qk0 qk0Var4 = em0Var2.h;
        if (qk0Var4 == null) {
            qk0Var4 = new qk0(new ki0[16]);
        }
        qk0 qk0Var5 = em0Var2.i;
        qk0Var5.b(mi0Var);
        j3 j3Var2 = null;
        while (true) {
            int i2 = qk0Var5.g;
            if (i2 == 0) {
                break;
            }
            mi0 mi0Var2 = (mi0) qk0Var5.k(i2 - 1);
            if (mi0Var2 instanceof rh) {
                rh rhVar = (rh) mi0Var2;
                qk0Var5.b(rhVar.b);
                qk0Var5.b(rhVar.a);
            } else if (mi0Var2 instanceof ki0) {
                qk0Var4.b(mi0Var2);
            } else {
                if (j3Var2 == null) {
                    j3Var = new j3(18, qk0Var4);
                    j3Var2 = j3Var;
                } else {
                    j3Var = j3Var2;
                }
                mi0Var2.d(j3Var);
            }
        }
        int i3 = qk0Var4.g;
        if (i3 == i) {
            li0 li0Var4 = dm0Var2.j;
            int i4 = 0;
            while (li0Var4 != null && i4 < i) {
                if (qk0Var3 != null) {
                    ki0 ki0Var = (ki0) qk0Var3.e[i4];
                    ki0 ki0Var2 = (ki0) qk0Var4.e[i4];
                    if (k70.p(ki0Var, ki0Var2)) {
                        qk0Var2 = qk0Var3;
                        z6 = true;
                    } else {
                        qk0Var2 = qk0Var3;
                        if (ki0Var.getClass() == ki0Var2.getClass()) {
                            z6 = true;
                        } else {
                            z6 = false;
                        }
                    }
                    if (z6) {
                        if (z6) {
                            em0.h(ki0Var, ki0Var2, li0Var4);
                        }
                        li0Var4 = li0Var4.j;
                        i4++;
                        qk0Var3 = qk0Var2;
                    } else {
                        li0Var4 = li0Var4.i;
                        break;
                    }
                } else {
                    throw fu0.C("expected prior modifier list to be non-empty");
                }
            }
            qk0Var2 = qk0Var3;
            if (i4 < i) {
                if (qk0Var2 != null) {
                    if (li0Var4 != null) {
                        if (ba0Var.P != null) {
                            z5 = true;
                        } else {
                            z5 = false;
                        }
                        li0 li0Var5 = li0Var4;
                        em0Var = em0Var2;
                        qk0Var = qk0Var4;
                        qk0Var3 = qk0Var2;
                        z4 = false;
                        em0Var.f(i4, qk0Var3, qk0Var, li0Var5, !z5);
                        dm0Var = dm0Var2;
                        z2 = true;
                        r7 = z4;
                    } else {
                        throw fu0.C("structuralUpdate requires a non-null tail");
                    }
                } else {
                    throw fu0.C("expected prior modifier list to be non-empty");
                }
            } else {
                em0Var2 = em0Var2;
                qk0Var3 = qk0Var2;
                z3 = false;
                em0Var = em0Var2;
                dm0Var = dm0Var2;
                qk0Var = qk0Var4;
                z2 = false;
                r7 = z3;
            }
        } else {
            r7 = 0;
            z4 = false;
            z3 = false;
            mi0 mi0Var3 = ba0Var.P;
            if (mi0Var3 != null && i == 0) {
                li0 li0Var6 = dm0Var2;
                for (int i5 = 0; i5 < qk0Var4.g; i5++) {
                    li0Var6 = em0.b((ki0) qk0Var4.e[i5], li0Var6);
                }
                int i6 = 0;
                for (li0 li0Var7 = li0Var.i; li0Var7 != null && li0Var7 != dm0Var2; li0Var7 = li0Var7.i) {
                    i6 |= li0Var7.g;
                    li0Var7.h = i6;
                }
                em0Var = em0Var2;
                dm0Var = dm0Var2;
                qk0Var = qk0Var4;
                z2 = true;
                r7 = z4;
            } else if (i3 == 0) {
                if (qk0Var3 != null) {
                    li0 li0Var8 = dm0Var2.j;
                    for (int i7 = 0; li0Var8 != null && i7 < qk0Var3.g; i7++) {
                        li0Var8 = em0.c(li0Var8).j;
                    }
                    ba0 v = ba0Var.v();
                    if (v != null) {
                        v50Var = v.J.c;
                    } else {
                        v50Var = null;
                    }
                    v50Var2.u = v50Var;
                    em0Var2.d = v50Var2;
                    em0Var = em0Var2;
                    dm0Var = dm0Var2;
                    qk0Var = qk0Var4;
                    z2 = false;
                    r7 = z3;
                } else {
                    throw fu0.C("expected prior modifier list to be non-empty");
                }
            } else {
                if (qk0Var3 == null) {
                    qk0Var3 = new qk0(new ki0[16]);
                }
                if (mi0Var3 != null) {
                    z = true;
                } else {
                    z = false;
                }
                em0Var = em0Var2;
                dm0Var = dm0Var2;
                qk0Var = qk0Var4;
                em0Var.f(0, qk0Var3, qk0Var, dm0Var, !z);
                z2 = true;
            }
        }
        em0Var.g = qk0Var;
        if (qk0Var3 != null) {
            qk0Var3.g();
        } else {
            qk0Var3 = r7;
        }
        em0Var.h = qk0Var3;
        li0 li0Var9 = dm0Var.j;
        if (li0Var9 != null) {
            li0Var = li0Var9;
        }
        li0Var.i = r7;
        dm0Var.j = r7;
        dm0Var.h = -1;
        dm0Var.l = r7;
        if (li0Var == dm0Var) {
            p50.b("trimChain did not update the head");
        }
        em0Var.f = li0Var;
        if (z2) {
            em0Var.g();
        }
        boolean d3 = em0Var.d(16);
        boolean d4 = em0Var.d(1024);
        this.K.j();
        if (this.l == null && em0Var.d(512)) {
            b0(this);
        }
        if (d != d3 || d2 != d4) {
            iw0 rectManager = ((n4) ea0.a(this)).getRectManager();
            rectManager.getClass();
            if (H()) {
                i6 i6Var = rectManager.a;
                int i8 = this.f & 33554431;
                long[] jArr = (long[]) i6Var.c;
                int i9 = i6Var.b;
                for (int i10 = 0; i10 < jArr.length - 2 && i10 < i9; i10 += 3) {
                    int i11 = i10 + 2;
                    long j = jArr[i11];
                    if ((((int) j) & 33554431) == i8) {
                        jArr[i11] = ((-6917529027641081857L) & j) | ((d4 ? 1L : 0L) * 2305843009213693952L) | ((d3 ? 1L : 0L) * 4611686018427387904L);
                        return;
                    }
                }
            }
        }
    }

    public final void b0(ba0 ba0Var) {
        if (!k70.p(ba0Var, this.l)) {
            this.l = ba0Var;
            fa0 fa0Var = this.K;
            if (ba0Var != null) {
                if (fa0Var.q == null) {
                    fa0Var.q = new hg0(fa0Var);
                }
                em0 em0Var = this.J;
                gm0 gm0Var = em0Var.c.t;
                for (gm0 gm0Var2 = em0Var.d; !k70.p(gm0Var2, gm0Var) && gm0Var2 != null; gm0Var2 = gm0Var2.t) {
                    gm0Var2.t0();
                }
            } else {
                fa0Var.q = null;
                fa0Var.f = false;
                fa0Var.e = false;
            }
            E();
        }
    }

    @Override // defpackage.wi
    public final void c() {
        r3 r3Var;
        ah1 ah1Var = this.s;
        if (ah1Var != null) {
            ah1Var.c();
        }
        pa0 pa0Var = this.L;
        if (pa0Var != null) {
            pa0Var.i(true);
        }
        this.U = true;
        li0 li0Var = this.J.e;
        for (li0 li0Var2 = li0Var; li0Var2 != null; li0Var2 = li0Var2.i) {
            if (li0Var2.r) {
                li0Var2.m0();
            }
        }
        for (li0 li0Var3 = li0Var; li0Var3 != null; li0Var3 = li0Var3.i) {
            if (li0Var3.r) {
                li0Var3.o0();
            }
        }
        while (li0Var != null) {
            if (li0Var.r) {
                li0Var.g0();
            }
            li0Var = li0Var.i;
        }
        if (H()) {
            this.w = null;
            this.v = false;
        }
        lp0 lp0Var = this.r;
        if (lp0Var != null) {
            n4 n4Var = (n4) lp0Var;
            if (n4.l() && (r3Var = n4Var.S) != null && r3Var.k.e(this.f)) {
                r3Var.e.x(r3Var.g, this.f, false);
            }
        }
    }

    public final void c0(mh0 mh0Var) {
        if (!k70.p(this.A, mh0Var)) {
            this.A = mh0Var;
            al alVar = this.B;
            if (alVar != null) {
                ((lq0) alVar.g).setValue(mh0Var);
            }
            E();
        }
    }

    public final void d(lp0 lp0Var) {
        v50 v50Var;
        int i;
        ba0 ba0Var;
        r3 r3Var;
        d21 x;
        lp0 lp0Var2;
        String str;
        if (this.r != null) {
            p50.b("Cannot attach " + this + " as it already is attached.  Tree: " + g(0));
        }
        ba0 ba0Var2 = this.q;
        if (ba0Var2 != null && !k70.p(ba0Var2.r, lp0Var)) {
            StringBuilder sb = new StringBuilder("Attaching to a different owner(");
            sb.append(lp0Var);
            sb.append(") than the parent's owner(");
            ba0 v = v();
            if (v != null) {
                lp0Var2 = v.r;
            } else {
                lp0Var2 = null;
            }
            sb.append(lp0Var2);
            sb.append("). This tree: ");
            sb.append(g(0));
            sb.append(" Parent tree: ");
            ba0 ba0Var3 = this.q;
            if (ba0Var3 != null) {
                str = ba0Var3.g(0);
            } else {
                str = null;
            }
            sb.append(str);
            p50.b(sb.toString());
        }
        ba0 v2 = v();
        fa0 fa0Var = this.K;
        if (v2 == null) {
            fa0Var.p.v = true;
            ((n4) lp0Var).getRectManager().f(this);
            hg0 hg0Var = fa0Var.q;
            if (hg0Var != null) {
                hg0Var.t = fg0.e;
            }
        }
        em0 em0Var = this.J;
        gm0 gm0Var = em0Var.d;
        if (v2 != null) {
            v50Var = v2.J.c;
        } else {
            v50Var = null;
        }
        gm0Var.u = v50Var;
        this.r = lp0Var;
        if (v2 != null) {
            i = v2.t;
        } else {
            i = -1;
        }
        this.t = i + 1;
        mi0 mi0Var = this.P;
        if (mi0Var != null) {
            b(mi0Var);
        }
        this.P = null;
        ((n4) lp0Var).getLayoutNodes().h(this.f, this);
        ba0 ba0Var4 = this.q;
        if (ba0Var4 == null || (ba0Var = ba0Var4.l) == null) {
            ba0Var = this.l;
        }
        b0(ba0Var);
        if (this.l == null && em0Var.d(512)) {
            b0(this);
        }
        if (!this.U) {
            for (li0 li0Var = em0Var.f; li0Var != null; li0Var = li0Var.j) {
                li0Var.f0();
            }
        }
        qk0 qk0Var = (qk0) this.n.f;
        Object[] objArr = qk0Var.e;
        int i2 = qk0Var.g;
        for (int i3 = 0; i3 < i2; i3++) {
            ((ba0) objArr[i3]).d(lp0Var);
        }
        if (!this.U) {
            em0Var.e();
        }
        E();
        if (v2 != null) {
            v2.E();
        }
        k7 k7Var = this.Q;
        if (k7Var != null) {
            k7Var.i(lp0Var);
        }
        fa0Var.j();
        if (!this.U && em0Var.d(8)) {
            F();
        }
        n4 n4Var = (n4) lp0Var;
        if (n4.l() && (r3Var = n4Var.S) != null && (x = x()) != null && x.e.b(n21.r)) {
            r3Var.k.a(this.f);
            r3Var.e.x(r3Var.g, this.f, true);
        }
    }

    public final void d0(mi0 mi0Var) {
        if (this.e && this.O != ji0.a) {
            p50.a("Modifiers are not supported on virtual LayoutNodes");
        }
        if (this.U) {
            p50.a("modifier is updated when deactivated");
        }
        if (H()) {
            b(mi0Var);
            if (this.v) {
                F();
                return;
            }
            return;
        }
        this.P = mi0Var;
    }

    public final void e() {
        this.H = this.G;
        z90 z90Var = z90.g;
        this.G = z90Var;
        qk0 z = z();
        Object[] objArr = z.e;
        int i = z.g;
        for (int i2 = 0; i2 < i; i2++) {
            ba0 ba0Var = (ba0) objArr[i2];
            if (ba0Var.G != z90Var) {
                ba0Var.e();
            }
        }
    }

    public final void e0(yg1 yg1Var) {
        if (!k70.p(this.E, yg1Var)) {
            this.E = yg1Var;
            li0 li0Var = this.J.f;
            if ((li0Var.h & 16) != 0) {
                while (li0Var != null) {
                    if ((li0Var.g & 16) != 0) {
                        li0 li0Var2 = li0Var;
                        qk0 qk0Var = null;
                        while (li0Var2 != null) {
                            if (li0Var2 instanceof gt0) {
                                ((gt0) li0Var2).L();
                            } else if ((li0Var2.g & 16) != 0 && (li0Var2 instanceof dp)) {
                                int i = 0;
                                for (li0 li0Var3 = ((dp) li0Var2).t; li0Var3 != null; li0Var3 = li0Var3.j) {
                                    if ((li0Var3.g & 16) != 0) {
                                        i++;
                                        if (i == 1) {
                                            li0Var2 = li0Var3;
                                        } else {
                                            if (qk0Var == null) {
                                                qk0Var = new qk0(new li0[16]);
                                            }
                                            if (li0Var2 != null) {
                                                qk0Var.b(li0Var2);
                                                li0Var2 = null;
                                            }
                                            qk0Var.b(li0Var3);
                                        }
                                    }
                                }
                                if (i == 1) {
                                }
                            }
                            li0Var2 = k70.m(qk0Var);
                        }
                    }
                    if ((li0Var.h & 16) != 0) {
                        li0Var = li0Var.j;
                    } else {
                        return;
                    }
                }
            }
        }
    }

    public final void f() {
        this.H = this.G;
        this.G = z90.g;
        qk0 z = z();
        Object[] objArr = z.e;
        int i = z.g;
        for (int i2 = 0; i2 < i; i2++) {
            ba0 ba0Var = (ba0) objArr[i2];
            if (ba0Var.G == z90.f) {
                ba0Var.f();
            }
        }
    }

    public final void f0() {
        if (this.m > 0 && this.p) {
            this.p = false;
            qk0 qk0Var = this.o;
            if (qk0Var == null) {
                qk0Var = new qk0(new ba0[16]);
                this.o = qk0Var;
            }
            qk0Var.g();
            qk0 qk0Var2 = (qk0) this.n.f;
            Object[] objArr = qk0Var2.e;
            int i = qk0Var2.g;
            for (int i2 = 0; i2 < i; i2++) {
                ba0 ba0Var = (ba0) objArr[i2];
                if (ba0Var.e) {
                    qk0Var.c(qk0Var.g, ba0Var.z());
                } else {
                    qk0Var.b(ba0Var);
                }
            }
            fa0 fa0Var = this.K;
            fa0Var.p.C = true;
            hg0 hg0Var = fa0Var.q;
            if (hg0Var != null) {
                hg0Var.w = true;
            }
        }
    }

    public final String g(int i) {
        StringBuilder sb = new StringBuilder();
        for (int i2 = 0; i2 < i; i2++) {
            sb.append("  ");
        }
        sb.append("|-");
        sb.append(toString());
        sb.append('\n');
        qk0 z = z();
        Object[] objArr = z.e;
        int i3 = z.g;
        for (int i4 = 0; i4 < i3; i4++) {
            sb.append(((ba0) objArr[i4]).g(i + 1));
        }
        String sb2 = sb.toString();
        if (i == 0) {
            return sb2.substring(0, sb2.length() - 1);
        }
        return sb2;
    }

    public final void h() {
        r3 r3Var;
        ca0 ca0Var;
        lp0 lp0Var = this.r;
        String str = null;
        if (lp0Var == null) {
            StringBuilder sb = new StringBuilder("Cannot detach node that is already detached!  Tree: ");
            ba0 v = v();
            if (v != null) {
                str = v.g(0);
            }
            sb.append(str);
            p50.c(sb.toString());
            throw new RuntimeException();
        }
        ba0 v2 = v();
        fa0 fa0Var = this.K;
        if (v2 != null) {
            v2.C();
            v2.E();
            lh0 lh0Var = fa0Var.p;
            z90 z90Var = z90.g;
            lh0Var.p = z90Var;
            hg0 hg0Var = fa0Var.q;
            if (hg0Var != null) {
                hg0Var.n = z90Var;
            }
        }
        ca0 ca0Var2 = fa0Var.p.A;
        ca0Var2.b = true;
        ca0Var2.c = false;
        ca0Var2.d = false;
        ca0Var2.e = false;
        ca0Var2.f = null;
        hg0 hg0Var2 = fa0Var.q;
        if (hg0Var2 != null && (ca0Var = hg0Var2.u) != null) {
            ca0Var.b = true;
            ca0Var.c = false;
            ca0Var.d = false;
            ca0Var.e = false;
            ca0Var.f = null;
        }
        em0 em0Var = this.J;
        li0 li0Var = em0Var.e;
        gm0 gm0Var = em0Var.c.t;
        for (gm0 gm0Var2 = em0Var.d; !k70.p(gm0Var2, gm0Var) && gm0Var2 != null; gm0Var2 = gm0Var2.t) {
            gm0Var2.Q0();
            if (gm0Var2.s.I()) {
                gm0Var2.L0();
            }
        }
        l7 l7Var = this.R;
        if (l7Var != null) {
            l7Var.i(lp0Var);
        }
        for (li0 li0Var2 = li0Var; li0Var2 != null; li0Var2 = li0Var2.i) {
            if (li0Var2.r) {
                li0Var2.o0();
            }
        }
        this.u = true;
        qk0 qk0Var = (qk0) this.n.f;
        Object[] objArr = qk0Var.e;
        int i = qk0Var.g;
        for (int i2 = 0; i2 < i; i2++) {
            ((ba0) objArr[i2]).h();
        }
        this.u = false;
        while (li0Var != null) {
            if (li0Var.r) {
                li0Var.g0();
            }
            li0Var = li0Var.i;
        }
        n4 n4Var = (n4) lp0Var;
        n4Var.getLayoutNodes().g(this.f);
        jh0 jh0Var = n4Var.e0;
        k9 k9Var = jh0Var.b;
        ((pg0) k9Var.f).B(this);
        ((pg0) k9Var.g).B(this);
        ((pg0) k9Var.h).B(this);
        ((qk0) jh0Var.e.f).j(this);
        n4Var.T = true;
        if (n4.l() && (r3Var = n4Var.S) != null && r3Var.k.e(this.f)) {
            r3Var.e.x(r3Var.g, this.f, false);
        }
        n4Var.getRectManager().g(this);
        this.r = null;
        b0(null);
        this.t = 0;
        lh0 lh0Var2 = fa0Var.p;
        lh0Var2.m = Integer.MAX_VALUE;
        lh0Var2.l = Integer.MAX_VALUE;
        lh0Var2.v = false;
        hg0 hg0Var3 = fa0Var.q;
        if (hg0Var3 != null) {
            hg0Var3.m = Integer.MAX_VALUE;
            hg0Var3.l = Integer.MAX_VALUE;
            hg0Var3.t = fg0.g;
        }
        if (em0Var.d(8)) {
            d21 d21Var = this.w;
            this.w = null;
            this.v = false;
            n4Var.getSemanticsOwner().b(this, d21Var);
            n4Var.E();
        }
    }

    public final void i(re reVar, i20 i20Var) {
        try {
            this.J.d.r0(reVar, i20Var);
        } catch (Throwable th) {
            Y(th);
            throw null;
        }
    }

    public final void k() {
        sk skVar;
        if (this.l != null) {
            T(this, false, 5);
        } else {
            V(this, false, 5);
        }
        lh0 lh0Var = this.K.p;
        if (lh0Var.n) {
            skVar = new sk(lh0Var.h);
        } else {
            skVar = null;
        }
        lp0 lp0Var = this.r;
        if (skVar != null) {
            if (lp0Var != null) {
                ((n4) lp0Var).y(this, skVar.a);
            }
        } else if (lp0Var != null) {
            ((n4) lp0Var).x(true);
        }
    }

    public final List l() {
        hg0 hg0Var = this.K.q;
        hg0Var.getClass();
        qk0 qk0Var = hg0Var.v;
        fa0 fa0Var = hg0Var.j;
        fa0Var.a.n();
        if (!hg0Var.w) {
            return qk0Var.f();
        }
        ba0 ba0Var = fa0Var.a;
        qk0 z = ba0Var.z();
        Object[] objArr = z.e;
        int i = z.g;
        for (int i2 = 0; i2 < i; i2++) {
            ba0 ba0Var2 = (ba0) objArr[i2];
            if (qk0Var.g <= i2) {
                hg0 hg0Var2 = ba0Var2.K.q;
                hg0Var2.getClass();
                qk0Var.b(hg0Var2);
            } else {
                hg0 hg0Var3 = ba0Var2.K.q;
                hg0Var3.getClass();
                Object[] objArr2 = qk0Var.e;
                Object obj = objArr2[i2];
                objArr2[i2] = hg0Var3;
            }
        }
        qk0Var.l(((nk0) ba0Var.n()).e.g, qk0Var.g);
        hg0Var.w = false;
        return qk0Var.f();
    }

    public final List m() {
        return this.K.p.U();
    }

    public final List n() {
        return z().f();
    }

    public final List o() {
        return ((qk0) this.n.f).f();
    }

    public final boolean p() {
        return this.K.p.y;
    }

    public final boolean q() {
        return this.K.p.x;
    }

    @Override // defpackage.mp0
    public final boolean r() {
        return H();
    }

    public final z90 s() {
        return this.K.p.p;
    }

    public final z90 t() {
        z90 z90Var;
        hg0 hg0Var = this.K.q;
        if (hg0Var != null && (z90Var = hg0Var.n) != null) {
            return z90Var;
        }
        return z90.g;
    }

    public final String toString() {
        return gh0.S(this) + " children: " + ((nk0) n()).e.g + " measurePolicy: " + this.A + " deactivated: " + this.U;
    }

    public final al u() {
        al alVar = this.B;
        if (alVar == null) {
            al alVar2 = new al(this, this.A);
            this.B = alVar2;
            return alVar2;
        }
        return alVar;
    }

    public final ba0 v() {
        ba0 ba0Var = this.q;
        while (ba0Var != null && ba0Var.e) {
            ba0Var = ba0Var.q;
        }
        return ba0Var;
    }

    public final int w() {
        return this.K.p.m;
    }

    public final d21 x() {
        if (H() && !this.U && this.J.d(8)) {
            return this.w;
        }
        return null;
    }

    public final qk0 y() {
        boolean z = this.z;
        qk0 qk0Var = this.y;
        if (z) {
            qk0Var.g();
            qk0Var.c(qk0Var.g, z());
            Arrays.sort(qk0Var.e, 0, qk0Var.g, X);
            this.z = false;
        }
        return qk0Var;
    }

    public final qk0 z() {
        f0();
        if (this.m == 0) {
            return (qk0) this.n.f;
        }
        qk0 qk0Var = this.o;
        qk0Var.getClass();
        return qk0Var;
    }

    public ba0(int i) {
        this(f21.a.addAndGet(1), (i & 1) == 0);
    }
}