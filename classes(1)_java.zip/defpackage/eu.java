package defpackage;

import java.util.LinkedHashMap;
import java.util.Map;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: eu  reason: default package */
public abstract class eu {
    public static final ud1 a = new ud1(i4.x, i4.y);
    public static final p71 b = zi1.G(0.0f, 400.0f, null, 5);
    public static final p71 c;
    public static final p71 d;

    static {
        zi1.G(0.0f, 400.0f, null, 5);
        Map map = nh1.a;
        c = zi1.G(0.0f, 400.0f, new n60(4294967297L), 1);
        d = zi1.G(0.0f, 400.0f, new v60(4294967297L), 1);
    }

    public static ju a(p71 p71Var, int i) {
        if ((i & 1) != 0) {
            p71Var = zi1.G(0.0f, 400.0f, null, 5);
        }
        return new ju(new fd1(new cv(p71Var), (we) null, (l01) null, (LinkedHashMap) null, 126));
    }

    public static wu b(p71 p71Var, int i) {
        if ((i & 1) != 0) {
            p71Var = zi1.G(0.0f, 400.0f, null, 5);
        }
        return new wu(new fd1(new cv(p71Var), (we) null, (l01) null, (LinkedHashMap) null, 126));
    }
}