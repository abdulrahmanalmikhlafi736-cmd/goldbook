package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bd1  reason: default package */
public final class bd1 implements a81 {
    public final ud1 e;
    public final lq0 f;
    public final lq0 g;
    public final lq0 h;
    public final lq0 i;
    public final hq0 j;
    public boolean k;
    public final lq0 l;
    public u8 m;
    public final jq0 n;
    public boolean o;
    public final p71 p;
    public final /* synthetic */ ed1 q;

    public bd1(ed1 ed1Var, Object obj, u8 u8Var, ud1 ud1Var) {
        this.q = ed1Var;
        this.e = ud1Var;
        lq0 t = mc0.t(obj);
        this.f = t;
        Object obj2 = null;
        this.g = mc0.t(zi1.G(0.0f, 0.0f, null, 7));
        this.h = mc0.t(new ja1(b(), ud1Var, obj, t.getValue(), u8Var));
        this.i = mc0.t(Boolean.TRUE);
        this.j = new hq0(-1.0f);
        this.l = mc0.t(obj);
        this.m = u8Var;
        this.n = new jq0(a().c());
        Float f = (Float) nh1.a.get(ud1Var);
        if (f != null) {
            float floatValue = f.floatValue();
            u8 u8Var2 = (u8) ud1Var.a.i(obj);
            int b = u8Var2.b();
            for (int i = 0; i < b; i++) {
                u8Var2.e(floatValue, i);
            }
            obj2 = this.e.b.i(u8Var2);
        }
        this.p = zi1.G(0.0f, 0.0f, obj2, 3);
    }

    public final ja1 a() {
        return (ja1) this.h.getValue();
    }

    public final yv b() {
        return (yv) this.g.getValue();
    }

    public final void c() {
        if (this.j.g() == -1.0f) {
            this.o = true;
            boolean p = k70.p(a().c, a().d);
            lq0 lq0Var = this.l;
            if (p) {
                lq0Var.setValue(a().c);
                return;
            }
            lq0Var.setValue(a().b(0L));
            this.m = a().f(0L);
        }
    }

    public final void e(Object obj, boolean z) {
        yv b;
        o8 t71Var;
        ed1 ed1Var = this.q;
        lq0 lq0Var = ed1Var.h;
        lq0 lq0Var2 = this.f;
        boolean p = k70.p(null, lq0Var2.getValue());
        jq0 jq0Var = this.n;
        lq0 lq0Var3 = this.h;
        ud1 ud1Var = this.e;
        if (p) {
            lq0Var3.setValue(new ja1(this.p, ud1Var, obj, obj, this.m.c()));
            this.k = true;
            jq0Var.h(a().c());
            return;
        }
        if (z && !this.o) {
            if (b() instanceof p71) {
                b = b();
            } else {
                b = this.p;
            }
        } else {
            b = b();
        }
        long j = 0;
        if (ed1Var.e() <= 0) {
            t71Var = b;
        } else {
            t71Var = new t71(b, ed1Var.e());
        }
        lq0Var3.setValue(new ja1(t71Var, ud1Var, obj, lq0Var2.getValue(), this.m));
        jq0Var.h(a().c());
        this.k = false;
        lq0Var.setValue(Boolean.TRUE);
        if (ed1Var.g()) {
            z61 z61Var = ed1Var.i;
            int size = z61Var.size();
            for (int i = 0; i < size; i++) {
                bd1 bd1Var = (bd1) z61Var.get(i);
                j = Math.max(j, bd1Var.n.g());
                bd1Var.c();
            }
            lq0Var.setValue(Boolean.FALSE);
        }
    }

    public final void f(Object obj, Object obj2, yv yvVar) {
        this.f.setValue(obj2);
        this.g.setValue(yvVar);
        if (k70.p(a().d, obj) && k70.p(a().c, obj2)) {
            return;
        }
        e(obj, false);
    }

    public final void g(Object obj, yv yvVar) {
        Object value;
        if (!this.k || !k70.p(obj, null)) {
            lq0 lq0Var = this.f;
            boolean p = k70.p(lq0Var.getValue(), obj);
            hq0 hq0Var = this.j;
            if (p && hq0Var.g() == -1.0f) {
                return;
            }
            lq0Var.setValue(obj);
            this.g.setValue(yvVar);
            int i = (hq0Var.g() > (-3.0f) ? 1 : (hq0Var.g() == (-3.0f) ? 0 : -1));
            lq0 lq0Var2 = this.l;
            if (i == 0) {
                value = obj;
            } else {
                value = lq0Var2.getValue();
            }
            lq0 lq0Var3 = this.i;
            boolean z = true;
            e(value, !((Boolean) lq0Var3.getValue()).booleanValue());
            if (hq0Var.g() != -3.0f) {
                z = false;
            }
            lq0Var3.setValue(Boolean.valueOf(z));
            if (hq0Var.g() >= 0.0f) {
                long c = a().c();
                lq0Var2.setValue(a().b(hq0Var.g() * ((float) c)));
            } else if (hq0Var.g() == -3.0f) {
                lq0Var2.setValue(obj);
            }
            this.k = false;
            hq0Var.h(-1.0f);
        }
    }

    @Override // defpackage.a81
    public final Object getValue() {
        return this.l.getValue();
    }

    public final String toString() {
        return "current value: " + this.l.getValue() + ", target: " + this.f.getValue() + ", spec: " + b();
    }
}