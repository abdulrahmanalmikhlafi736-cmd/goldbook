package defpackage;

import android.os.Trace;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cw0  reason: default package */
public final class cw0 extends u91 implements n00 {
    public List i;
    public List j;
    public List k;
    public ik0 l;
    public ik0 m;
    public ik0 n;
    public Set o;
    public ik0 p;
    public int q;
    public /* synthetic */ g7 r;
    public final /* synthetic */ dw0 s;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public cw0(dw0 dw0Var, ml mlVar) {
        super(3, mlVar);
        this.s = dw0Var;
    }

    public static final void r(dw0 dw0Var, List list, List list2, List list3, ik0 ik0Var, ik0 ik0Var2, ik0 ik0Var3, ik0 ik0Var4) {
        char c;
        long j;
        long j2;
        synchronized (dw0Var.c) {
            try {
                list.clear();
                list2.clear();
                int size = list3.size();
                for (int i = 0; i < size; i++) {
                    yj yjVar = (yj) list3.get(i);
                    yjVar.a();
                    dw0Var.R(yjVar);
                }
                list3.clear();
                Object[] objArr = ik0Var.b;
                long[] jArr = ik0Var.a;
                int length = jArr.length - 2;
                if (length >= 0) {
                    int i2 = 0;
                    j = 255;
                    while (true) {
                        long j3 = jArr[i2];
                        c = 7;
                        j2 = -9187201950435737472L;
                        if ((((~j3) << 7) & j3 & (-9187201950435737472L)) != -9187201950435737472L) {
                            int i3 = 8 - ((~(i2 - length)) >>> 31);
                            for (int i4 = 0; i4 < i3; i4++) {
                                if ((j3 & 255) < 128) {
                                    yj yjVar2 = (yj) objArr[(i2 << 3) + i4];
                                    yjVar2.a();
                                    dw0Var.R(yjVar2);
                                }
                                j3 >>= 8;
                            }
                            if (i3 != 8) {
                                break;
                            }
                        }
                        if (i2 == length) {
                            break;
                        }
                        i2++;
                    }
                } else {
                    c = 7;
                    j = 255;
                    j2 = -9187201950435737472L;
                }
                ik0Var.b();
                Object[] objArr2 = ik0Var2.b;
                long[] jArr2 = ik0Var2.a;
                int length2 = jArr2.length - 2;
                if (length2 >= 0) {
                    int i5 = 0;
                    while (true) {
                        long j4 = jArr2[i5];
                        if ((((~j4) << c) & j4 & j2) != j2) {
                            int i6 = 8 - ((~(i5 - length2)) >>> 31);
                            for (int i7 = 0; i7 < i6; i7++) {
                                if ((j4 & j) < 128) {
                                    ((yj) objArr2[(i5 << 3) + i7]).g();
                                }
                                j4 >>= 8;
                            }
                            if (i6 != 8) {
                                break;
                            }
                        }
                        if (i5 == length2) {
                            break;
                        }
                        i5++;
                    }
                }
                ik0Var2.b();
                ik0Var3.b();
                Object[] objArr3 = ik0Var4.b;
                long[] jArr3 = ik0Var4.a;
                int length3 = jArr3.length - 2;
                if (length3 >= 0) {
                    int i8 = 0;
                    while (true) {
                        long j5 = jArr3[i8];
                        if ((((~j5) << c) & j5 & j2) != j2) {
                            int i9 = 8 - ((~(i8 - length3)) >>> 31);
                            for (int i10 = 0; i10 < i9; i10++) {
                                if ((j5 & j) < 128) {
                                    yj yjVar3 = (yj) objArr3[(i8 << 3) + i10];
                                    yjVar3.a();
                                    dw0Var.R(yjVar3);
                                }
                                j5 >>= 8;
                            }
                            if (i9 != 8) {
                                break;
                            }
                        }
                        if (i8 == length3) {
                            break;
                        }
                        i8++;
                    }
                }
                ik0Var4.b();
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public static final void s(List list, dw0 dw0Var) {
        list.clear();
        synchronized (dw0Var.c) {
            try {
                ArrayList arrayList = dw0Var.k;
                int size = arrayList.size();
                for (int i = 0; i < size; i++) {
                    list.add((gj0) arrayList.get(i));
                }
                dw0Var.k.clear();
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    @Override // defpackage.n00
    public final Object c(Object obj, Object obj2, Object obj3) {
        bm bmVar = (bm) obj;
        cw0 cw0Var = new cw0(this.s, (ml) obj3);
        cw0Var.r = (g7) obj2;
        cw0Var.p(we1.a);
        return cm.e;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:14:0x0098 A[DONT_GENERATE] */
    /* JADX WARN: Removed duplicated region for block: B:21:0x00c9  */
    /* JADX WARN: Removed duplicated region for block: B:26:0x0117  */
    /* JADX WARN: Type inference failed for: r10v5, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r10v6, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r11v10, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r11v8, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r5v10 */
    /* JADX WARN: Type inference failed for: r5v12 */
    /* JADX WARN: Type inference failed for: r5v14, types: [java.util.Set] */
    /* JADX WARN: Type inference failed for: r5v16, types: [java.util.Set] */
    /* JADX WARN: Type inference failed for: r9v10, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r9v8, types: [java.util.List] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:24:0x00ee -> B:25:0x00f6). Please submit an issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:26:0x0117 -> B:12:0x0093). Please submit an issue!!! */
    @Override // defpackage.db
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object p(Object obj) {
        g7 g7Var;
        ik0 ik0Var;
        ik0 ik0Var2;
        ArrayList arrayList;
        p01 p01Var;
        ArrayList arrayList2;
        ik0 ik0Var3;
        ArrayList arrayList3;
        ik0 ik0Var4;
        final ArrayList arrayList4;
        final ik0 ik0Var5;
        final ArrayList arrayList5;
        final ArrayList arrayList6;
        final ik0 ik0Var6;
        p01 p01Var2;
        dw0 dw0Var;
        cm cmVar = cm.e;
        int i = this.q;
        if (i != 0) {
            if (i != 1) {
                if (i == 2) {
                    ik0 ik0Var7 = this.p;
                    Set set = this.o;
                    ik0Var3 = this.n;
                    ik0Var4 = this.m;
                    ik0Var = this.l;
                    ?? r9 = this.k;
                    ?? r10 = this.j;
                    ?? r11 = this.i;
                    g7 g7Var2 = this.r;
                    nb0.t(obj);
                    ik0Var2 = ik0Var7;
                    g7Var = g7Var2;
                    ArrayList arrayList7 = r9;
                    ArrayList arrayList8 = r10;
                    ArrayList arrayList9 = r11;
                    dw0.x(this.s);
                    k9 k9Var = this.s.b;
                    ((ca) k9Var.f).set(0);
                    ((pa) k9Var.g).f(new z1(18));
                    p01Var = set;
                    arrayList3 = arrayList7;
                    arrayList2 = arrayList8;
                    arrayList = arrayList9;
                    synchronized (this.s.c) {
                    }
                    dw0 dw0Var2 = this.s;
                    this.r = g7Var;
                    this.i = arrayList;
                    this.j = arrayList2;
                    this.k = arrayList3;
                    this.l = ik0Var;
                    this.m = ik0Var4;
                    this.n = ik0Var3;
                    this.o = p01Var;
                    this.p = ik0Var2;
                    this.q = 1;
                    if (dw0.w(dw0Var2, this) != cmVar) {
                        ArrayList arrayList10 = arrayList;
                        ik0Var5 = ik0Var;
                        ik0Var6 = ik0Var2;
                        arrayList4 = arrayList3;
                        arrayList6 = arrayList10;
                        p01Var2 = p01Var;
                        arrayList5 = arrayList2;
                        final p01 p01Var3 = p01Var2;
                        final ik0 ik0Var8 = ik0Var4;
                        final ik0 ik0Var9 = ik0Var3;
                        dw0Var = this.s;
                        d81 d81Var = dw0.z;
                        if (!dw0Var.Q()) {
                            final dw0 dw0Var3 = this.s;
                            i00 i00Var = new i00() { // from class: bw0
                                /* JADX WARN: Multi-variable type inference failed */
                                @Override // defpackage.i00
                                public final Object i(Object obj2) {
                                    boolean z;
                                    Object[] objArr;
                                    g61 id1Var;
                                    List list;
                                    List list2;
                                    long j;
                                    List list3;
                                    List list4;
                                    Object[] objArr2;
                                    dw0 dw0Var4 = dw0.this;
                                    ik0 ik0Var10 = ik0Var9;
                                    ik0 ik0Var11 = ik0Var6;
                                    List list5 = arrayList6;
                                    List list6 = arrayList5;
                                    ik0 ik0Var12 = ik0Var5;
                                    List list7 = arrayList4;
                                    ik0 ik0Var13 = ik0Var8;
                                    Set set2 = p01Var3;
                                    final long longValue = ((Long) obj2).longValue();
                                    if (dw0.y(dw0Var4)) {
                                        Trace.beginSection("Recomposer:animation");
                                        try {
                                            ((pa) dw0Var4.a.g).f(new i00() { // from class: ad
                                                @Override // defpackage.i00
                                                public final Object i(Object obj3) {
                                                    ne neVar;
                                                    Object px0Var;
                                                    long j2 = longValue;
                                                    bd bdVar = (bd) obj3;
                                                    i00 i00Var2 = bdVar.b;
                                                    if (i00Var2 != null && (neVar = bdVar.a) != null) {
                                                        try {
                                                            px0Var = i00Var2.i(Long.valueOf(j2));
                                                        } catch (Throwable th) {
                                                            px0Var = new px0(th);
                                                        }
                                                        neVar.h(px0Var);
                                                    }
                                                    return we1.a;
                                                }
                                            });
                                            kb0.A();
                                        } finally {
                                        }
                                    }
                                    Trace.beginSection("Recomposer:recompose");
                                    try {
                                        dw0Var4.Q();
                                        synchronized (dw0Var4.c) {
                                            qk0 qk0Var = dw0Var4.i;
                                            Object[] objArr3 = qk0Var.e;
                                            int i2 = qk0Var.g;
                                            z = 0;
                                            for (int i3 = 0; i3 < i2; i3++) {
                                                list5.add((yj) objArr3[i3]);
                                            }
                                            dw0Var4.i.g();
                                        }
                                        ik0Var10.b();
                                        ik0Var11.b();
                                        while (true) {
                                            if (list5.isEmpty() && list6.isEmpty()) {
                                                break;
                                            }
                                            int size = list5.size();
                                            for (int i4 = 0; i4 < size; i4++) {
                                                yj yjVar = (yj) list5.get(i4);
                                                yj O = dw0Var4.O(yjVar, ik0Var10);
                                                if (O != null) {
                                                    list7.add(O);
                                                }
                                                ik0Var11.a(yjVar);
                                            }
                                            list5.clear();
                                            if (ik0Var10.h() || dw0Var4.i.g != 0) {
                                                synchronized (dw0Var4.c) {
                                                    List I = dw0Var4.I();
                                                    int size2 = I.size();
                                                    for (int i5 = 0; i5 < size2; i5++) {
                                                        yj yjVar2 = (yj) I.get(i5);
                                                        if (!ik0Var11.c(yjVar2) && yjVar2.v(set2)) {
                                                            list5.add(yjVar2);
                                                        }
                                                    }
                                                    qk0 qk0Var2 = dw0Var4.i;
                                                    int i6 = qk0Var2.g;
                                                    int i7 = 0;
                                                    int i8 = 0;
                                                    while (true) {
                                                        objArr = qk0Var2.e;
                                                        if (i7 >= i6) {
                                                            break;
                                                        }
                                                        yj yjVar3 = (yj) objArr[i7];
                                                        if (!ik0Var11.c(yjVar3) && !list5.contains(yjVar3)) {
                                                            list5.add(yjVar3);
                                                            i8++;
                                                        } else if (i8 > 0) {
                                                            Object[] objArr4 = qk0Var2.e;
                                                            objArr4[i7 - i8] = objArr4[i7];
                                                        }
                                                        i7++;
                                                    }
                                                    int i9 = i6 - i8;
                                                    Arrays.fill(objArr, i9, i6, (Object) null);
                                                    qk0Var2.g = i9;
                                                }
                                            }
                                            if (list5.isEmpty()) {
                                                cw0.s(list6, dw0Var4);
                                                while (!list6.isEmpty()) {
                                                    List<Object> N = dw0Var4.N(list6, ik0Var10);
                                                    ik0Var12.getClass();
                                                    for (Object obj3 : N) {
                                                        ik0Var12.k(obj3);
                                                    }
                                                    cw0.s(list6, dw0Var4);
                                                }
                                            }
                                            z = 0;
                                        }
                                        g61 j2 = n61.j();
                                        if (j2 instanceof lk0) {
                                            id1Var = new hd1((lk0) j2, null, null, true, false);
                                        } else {
                                            id1Var = new id1(j2, null, true, z);
                                        }
                                        g61 j3 = id1Var.j();
                                        if (!list7.isEmpty()) {
                                            int size3 = list7.size();
                                            for (int i10 = z; i10 < size3; i10++) {
                                                ik0Var13.a((yj) list7.get(i10));
                                            }
                                            int size4 = list7.size();
                                            for (int i11 = z; i11 < size4; i11++) {
                                                ((yj) list7.get(i11)).d();
                                            }
                                            list7.clear();
                                        }
                                        if (ik0Var12.h()) {
                                            try {
                                                ik0Var13.j(ik0Var12);
                                                Object[] objArr5 = ik0Var12.b;
                                                long[] jArr = ik0Var12.a;
                                                j = 128;
                                                int length = jArr.length - 2;
                                                if (length >= 0) {
                                                    int i12 = 0;
                                                    while (true) {
                                                        long j4 = jArr[i12];
                                                        list = list5;
                                                        list2 = list6;
                                                        if ((((~j4) << 7) & j4 & (-9187201950435737472L)) != -9187201950435737472L) {
                                                            int i13 = 8 - ((~(i12 - length)) >>> 31);
                                                            for (int i14 = 0; i14 < i13; i14++) {
                                                                if ((j4 & 255) < 128) {
                                                                    try {
                                                                        ((yj) objArr5[(i12 << 3) + i14]).f();
                                                                    } catch (Throwable th) {
                                                                        th = th;
                                                                        try {
                                                                            dw0Var4.P(th, null);
                                                                            cw0.r(dw0Var4, list, list2, list7, ik0Var12, ik0Var13, ik0Var10, ik0Var11);
                                                                            g61.q(j3);
                                                                            id1Var.c();
                                                                            return we1.a;
                                                                        } finally {
                                                                            ik0Var12.b();
                                                                        }
                                                                    }
                                                                }
                                                                j4 >>= 8;
                                                            }
                                                            if (i13 != 8) {
                                                                break;
                                                            }
                                                        }
                                                        if (i12 == length) {
                                                            break;
                                                        }
                                                        i12++;
                                                        list5 = list;
                                                        list6 = list2;
                                                    }
                                                } else {
                                                    list = list5;
                                                    list2 = list6;
                                                }
                                                list5 = list;
                                                list6 = list2;
                                            } catch (Throwable th2) {
                                                th = th2;
                                                list = list5;
                                                list2 = list6;
                                            }
                                        } else {
                                            j = 128;
                                        }
                                        if (ik0Var13.h()) {
                                            try {
                                                Object[] objArr6 = ik0Var13.b;
                                                long[] jArr2 = ik0Var13.a;
                                                int length2 = jArr2.length - 2;
                                                if (length2 >= 0) {
                                                    int i15 = 0;
                                                    while (true) {
                                                        long j5 = jArr2[i15];
                                                        list3 = list5;
                                                        list4 = list6;
                                                        if ((((~j5) << 7) & j5 & (-9187201950435737472L)) != -9187201950435737472L) {
                                                            int i16 = 8 - ((~(i15 - length2)) >>> 31);
                                                            int i17 = 0;
                                                            while (i17 < i16) {
                                                                if ((j5 & 255) < j) {
                                                                    try {
                                                                        ((yj) objArr6[(i15 << 3) + i17]).g();
                                                                    } catch (Throwable th3) {
                                                                        th = th3;
                                                                        try {
                                                                            dw0Var4.P(th, null);
                                                                            cw0.r(dw0Var4, list3, list4, list7, ik0Var12, ik0Var13, ik0Var10, ik0Var11);
                                                                            g61.q(j3);
                                                                            id1Var.c();
                                                                            return we1.a;
                                                                        } finally {
                                                                            ik0Var13.b();
                                                                        }
                                                                    }
                                                                }
                                                                j5 >>= 8;
                                                                i17++;
                                                                objArr6 = objArr6;
                                                            }
                                                            objArr2 = objArr6;
                                                            if (i16 != 8) {
                                                                break;
                                                            }
                                                        } else {
                                                            objArr2 = objArr6;
                                                        }
                                                        if (i15 == length2) {
                                                            break;
                                                        }
                                                        i15++;
                                                        list5 = list3;
                                                        list6 = list4;
                                                        objArr6 = objArr2;
                                                    }
                                                }
                                                ik0Var13.b();
                                            } catch (Throwable th4) {
                                                th = th4;
                                                list3 = list5;
                                                list4 = list6;
                                            }
                                        }
                                        g61.q(j3);
                                        id1Var.c();
                                        synchronized (dw0Var4.c) {
                                            if (dw0Var4.D() != null) {
                                                qj.a("unexpected to get continuation here");
                                            }
                                        }
                                        n61.j().m();
                                        ik0Var11.b();
                                        ik0Var10.b();
                                        dw0Var4.q = null;
                                        return we1.a;
                                    } finally {
                                    }
                                }
                            };
                            this.r = g7Var;
                            this.i = arrayList6;
                            this.j = arrayList5;
                            this.k = arrayList4;
                            this.l = ik0Var5;
                            this.m = ik0Var8;
                            this.n = ik0Var9;
                            this.o = p01Var3;
                            this.p = ik0Var6;
                            this.q = 2;
                            if (g7Var.c(i00Var, this) != cmVar) {
                                ArrayList arrayList11 = arrayList4;
                                ik0Var2 = ik0Var6;
                                ik0Var = ik0Var5;
                                arrayList9 = arrayList6;
                                arrayList7 = arrayList11;
                                ik0Var3 = ik0Var9;
                                ik0Var4 = ik0Var8;
                                set = p01Var3;
                                arrayList8 = arrayList5;
                                dw0.x(this.s);
                                k9 k9Var2 = this.s.b;
                                ((ca) k9Var2.f).set(0);
                                ((pa) k9Var2.g).f(new z1(18));
                                p01Var = set;
                                arrayList3 = arrayList7;
                                arrayList2 = arrayList8;
                                arrayList = arrayList9;
                                synchronized (this.s.c) {
                                }
                            }
                        } else {
                            ArrayList arrayList12 = arrayList4;
                            ik0Var2 = ik0Var6;
                            ik0Var = ik0Var5;
                            arrayList = arrayList6;
                            arrayList3 = arrayList12;
                            ik0Var3 = ik0Var9;
                            ik0Var4 = ik0Var8;
                            p01Var = p01Var3;
                            arrayList2 = arrayList5;
                            synchronized (this.s.c) {
                            }
                        }
                    }
                    return cmVar;
                }
                od.p("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            ik0 ik0Var10 = this.p;
            ik0Var3 = this.n;
            ik0Var4 = this.m;
            ik0 ik0Var11 = this.l;
            ?? r92 = this.k;
            ?? r102 = this.j;
            ?? r112 = this.i;
            g7 g7Var3 = this.r;
            nb0.t(obj);
            ik0Var6 = ik0Var10;
            g7Var = g7Var3;
            arrayList4 = r92;
            arrayList6 = r112;
            ik0Var5 = ik0Var11;
            p01Var2 = this.o;
            arrayList5 = r102;
            final Set p01Var32 = p01Var2;
            final ik0 ik0Var82 = ik0Var4;
            final ik0 ik0Var92 = ik0Var3;
            dw0Var = this.s;
            d81 d81Var2 = dw0.z;
            if (!dw0Var.Q()) {
            }
        } else {
            nb0.t(obj);
            g7Var = this.r;
            ArrayList arrayList13 = new ArrayList();
            ArrayList arrayList14 = new ArrayList();
            ArrayList arrayList15 = new ArrayList();
            ik0 ik0Var12 = o01.a;
            ik0Var = new ik0();
            ik0 ik0Var13 = new ik0();
            ik0 ik0Var14 = new ik0();
            p01 p01Var4 = new p01(ik0Var14);
            ik0Var2 = new ik0();
            arrayList = arrayList13;
            p01Var = p01Var4;
            arrayList2 = arrayList14;
            ik0Var3 = ik0Var14;
            arrayList3 = arrayList15;
            ik0Var4 = ik0Var13;
            synchronized (this.s.c) {
            }
        }
    }
}