package defpackage;

import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: d80  reason: default package */
public abstract class d80 extends of0 implements sq, l40 {
    public h80 h;

    @Override // defpackage.sq
    public final void a() {
        h80 j = j();
        while (true) {
            AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = h80.e;
            Object obj = atomicReferenceFieldUpdater.get(j);
            if (obj instanceof d80) {
                if (obj == this) {
                    pt ptVar = zi1.v;
                    while (!atomicReferenceFieldUpdater.compareAndSet(j, obj, ptVar)) {
                        if (atomicReferenceFieldUpdater.get(j) != obj) {
                            break;
                        }
                    }
                    return;
                }
                return;
            } else if (!(obj instanceof l40) || ((l40) obj).d() == null) {
                return;
            } else {
                while (true) {
                    AtomicReferenceFieldUpdater atomicReferenceFieldUpdater2 = of0.e;
                    Object obj2 = atomicReferenceFieldUpdater2.get(this);
                    if (!(obj2 instanceof bx0)) {
                        if (obj2 == this) {
                            of0 of0Var = (of0) obj2;
                            return;
                        }
                        obj2.getClass();
                        of0 of0Var2 = (of0) obj2;
                        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater3 = of0.g;
                        bx0 bx0Var = (bx0) atomicReferenceFieldUpdater3.get(of0Var2);
                        if (bx0Var == null) {
                            bx0Var = new bx0(of0Var2);
                            atomicReferenceFieldUpdater3.set(of0Var2, bx0Var);
                        }
                        while (!atomicReferenceFieldUpdater2.compareAndSet(this, obj2, bx0Var)) {
                            if (atomicReferenceFieldUpdater2.get(this) != obj2) {
                                break;
                            }
                        }
                        of0Var2.f();
                        return;
                    }
                    return;
                }
            }
        }
    }

    @Override // defpackage.l40
    public final boolean b() {
        return true;
    }

    @Override // defpackage.l40
    public final im0 d() {
        return null;
    }

    public a80 getParent() {
        return j();
    }

    public final h80 j() {
        h80 h80Var = this.h;
        if (h80Var != null) {
            return h80Var;
        }
        k70.T("job");
        throw null;
    }

    public abstract boolean k();

    public abstract void l(Throwable th);

    @Override // defpackage.of0
    public final String toString() {
        return getClass().getSimpleName() + '@' + vn.y(this) + "[job@" + vn.y(j()) + ']';
    }
}