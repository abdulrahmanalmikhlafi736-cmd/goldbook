package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ab0  reason: default package */
public final class ab0 implements kb {
    public final /* synthetic */ bb0 a;
    public final /* synthetic */ nw0 b;
    public final /* synthetic */ int c;

    public ab0(bb0 bb0Var, nw0 nw0Var, int i) {
        this.a = bb0Var;
        this.b = nw0Var;
        this.c = i;
    }

    @Override // defpackage.kb
    public final boolean a() {
        int i = this.c;
        return this.a.r0((xa0) this.b.e, i);
    }
}