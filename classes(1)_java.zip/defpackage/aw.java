package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: aw  reason: default package */
public final class aw extends ks0 {
    public final /* synthetic */ int j;

    public aw(int i, int i2, int i3) {
        this.j = i3;
        switch (i3) {
            case 1:
                S((i2 & 4294967295L) | (i << 32));
                return;
            default:
                S((i2 & 4294967295L) | (i << 32));
                return;
        }
    }

    private final void U(long j, float f, i00 i00Var) {
    }

    private final void W(long j, float f, i00 i00Var) {
    }

    @Override // defpackage.ks0
    public final void R(long j, float f, i00 i00Var) {
        int i = this.j;
    }
}