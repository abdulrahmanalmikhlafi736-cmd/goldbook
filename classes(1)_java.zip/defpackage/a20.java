package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: a20  reason: default package */
public final /* synthetic */ class a20 implements xz {
    public final /* synthetic */ int e;
    public final /* synthetic */ mk0 f;

    public /* synthetic */ a20(mk0 mk0Var, int i) {
        this.e = i;
        this.f = mk0Var;
    }

    @Override // defpackage.xz
    public final Object a() {
        int i = this.e;
        we1 we1Var = we1.a;
        mk0 mk0Var = this.f;
        switch (i) {
            case 0:
                mk0Var.setValue(Boolean.TRUE);
                return we1Var;
            case 1:
                mk0Var.setValue("facebook");
                return we1Var;
            case 2:
                return (hc0) ((xz) mk0Var.getValue()).a();
            case 3:
                return new fc0((i00) mk0Var.getValue());
            case gu0.LONG_FIELD_NUMBER /* 4 */:
                mk0Var.setValue(Boolean.FALSE);
                return we1Var;
            case gu0.STRING_FIELD_NUMBER /* 5 */:
                mk0Var.setValue(Boolean.TRUE);
                return we1Var;
            case gu0.STRING_SET_FIELD_NUMBER /* 6 */:
                mk0Var.setValue(Boolean.FALSE);
                return we1Var;
            case gu0.DOUBLE_FIELD_NUMBER /* 7 */:
                mk0Var.setValue(Boolean.FALSE);
                return we1Var;
            case 8:
                mk0Var.setValue(Boolean.TRUE);
                return we1Var;
            default:
                mk0Var.setValue(Boolean.FALSE);
                return we1Var;
        }
    }
}