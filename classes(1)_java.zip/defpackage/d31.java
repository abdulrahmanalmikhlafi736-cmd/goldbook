package defpackage;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* renamed from: d31  reason: default package */
public abstract class d31 extends e31 {
    public static List x(b31 b31Var) {
        Iterator it = b31Var.iterator();
        if (!it.hasNext()) {
            return ut.e;
        }
        Object next = it.next();
        if (!it.hasNext()) {
            return zi1.y(next);
        }
        ArrayList arrayList = new ArrayList();
        arrayList.add(next);
        while (it.hasNext()) {
            arrayList.add(it.next());
        }
        return arrayList;
    }
}