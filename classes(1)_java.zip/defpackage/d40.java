package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: d40  reason: default package */
public final class d40 {
    public static final /* synthetic */ int e = 0;
    public final boolean a;
    public final int b;
    public final int c;
    public final if0 d;

    static {
        new d40();
    }

    public d40() {
        if0 if0Var = if0.g;
        this.a = true;
        this.b = 1;
        this.c = 1;
        this.d = if0Var;
    }

    public final boolean equals(Object obj) {
        if (this != obj) {
            if (obj instanceof d40) {
                d40 d40Var = (d40) obj;
                if (this.a == d40Var.a && this.b == d40Var.b && this.c == d40Var.c && k70.p(this.d, d40Var.d)) {
                    return true;
                }
                return false;
            }
            return false;
        }
        return true;
    }

    public final int hashCode() {
        int i;
        if (this.a) {
            i = 1231;
        } else {
            i = 1237;
        }
        return this.d.e.hashCode() + ((((((1188757 + i) * 31) + this.b) * 31) + this.c) * 961);
    }

    public final String toString() {
        String str;
        StringBuilder sb = new StringBuilder("ImeOptions(singleLine=false, capitalization=");
        String str2 = "None";
        sb.append((Object) "None");
        sb.append(", autoCorrect=");
        sb.append(this.a);
        sb.append(", keyboardType=");
        int i = this.b;
        if (i == 0) {
            str = "Unspecified";
        } else if (i == 1) {
            str = "Text";
        } else if (i == 2) {
            str = "Ascii";
        } else if (i == 3) {
            str = "Number";
        } else if (i == 4) {
            str = "Phone";
        } else if (i == 5) {
            str = "Uri";
        } else if (i == 6) {
            str = "Email";
        } else if (i == 7) {
            str = "Password";
        } else if (i == 8) {
            str = "NumberPassword";
        } else if (i != 9) {
            str = "Invalid";
        } else {
            str = "Decimal";
        }
        sb.append((Object) str);
        sb.append(", imeAction=");
        int i2 = this.c;
        if (i2 == -1) {
            str2 = "Unspecified";
        } else if (i2 != 0) {
            if (i2 == 1) {
                str2 = "Default";
            } else if (i2 == 2) {
                str2 = "Go";
            } else if (i2 == 3) {
                str2 = "Search";
            } else if (i2 == 4) {
                str2 = "Send";
            } else if (i2 == 5) {
                str2 = "Previous";
            } else if (i2 == 6) {
                str2 = "Next";
            } else if (i2 != 7) {
                str2 = "Invalid";
            } else {
                str2 = "Done";
            }
        }
        sb.append((Object) str2);
        sb.append(", platformImeOptions=null, hintLocales=");
        sb.append(this.d);
        sb.append(')');
        return sb.toString();
    }
}