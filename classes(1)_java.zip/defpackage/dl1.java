package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dl1  reason: default package */
public final class dl1 {
    public final w50 f;
    public final w50 g;
    public final lq0 a = mc0.t(Boolean.TRUE);
    public final lq0 b = mc0.t(Boolean.FALSE);
    public final hq0 c = new hq0(0.0f);
    public final jq0 d = new jq0(0);
    public final hq0 e = new hq0(1.0f);
    public long h = -1;
    public long i = -1;
    public long j = -1;
    public long k = -1;

    public dl1(String str) {
        this.f = new w50(str.concat(" source"));
        this.g = new w50(str.concat(" target"));
    }
}