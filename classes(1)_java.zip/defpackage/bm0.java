package defpackage;

import java.util.ArrayList;
import java.util.List;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bm0  reason: default package */
public final class bm0 extends lm0 {
    public final li0 c;
    public final zh d;
    public final xf0 e;
    public gm0 f;
    public zs0 g;
    public boolean h;
    public boolean i;
    public boolean j;

    /* JADX WARN: Type inference failed for: r3v1, types: [java.lang.Object, zh] */
    public bm0(li0 li0Var) {
        this.c = li0Var;
        ?? obj = new Object();
        obj.f = new long[2];
        this.d = obj;
        this.e = new xf0(2);
        this.i = true;
        this.j = true;
    }

    @Override // defpackage.lm0
    public final boolean a(xf0 xf0Var, n90 n90Var, e70 e70Var, boolean z) {
        zh zhVar;
        xf0 xf0Var2;
        Object obj;
        int i;
        boolean z2;
        zs0 zs0Var;
        boolean z3;
        boolean z4;
        boolean z5;
        boolean z6;
        int i2;
        int i3;
        boolean z7;
        int i4;
        boolean z8;
        int i5;
        List list;
        List list2;
        int i6;
        dt0 dt0Var;
        n90 n90Var2 = n90Var;
        boolean a = super.a(xf0Var, n90Var, e70Var, z);
        li0 li0Var = this.c;
        boolean z9 = true;
        if (li0Var.r) {
            qk0 qk0Var = null;
            while (li0Var != null) {
                if (li0Var instanceof gt0) {
                    this.f = k70.M((gt0) li0Var, 16);
                } else if ((li0Var.g & 16) != 0 && (li0Var instanceof dp)) {
                    int i7 = 0;
                    for (li0 li0Var2 = ((dp) li0Var).t; li0Var2 != null; li0Var2 = li0Var2.j) {
                        if ((li0Var2.g & 16) != 0) {
                            i7++;
                            if (i7 == 1) {
                                li0Var = li0Var2;
                            } else {
                                if (qk0Var == null) {
                                    qk0Var = new qk0(new li0[16]);
                                }
                                if (li0Var != null) {
                                    qk0Var.b(li0Var);
                                    li0Var = null;
                                }
                                qk0Var.b(li0Var2);
                            }
                        }
                    }
                    if (i7 == 1) {
                    }
                }
                li0Var = k70.m(qk0Var);
            }
            if (this.f != null) {
                int d = xf0Var.d();
                int i8 = 0;
                while (true) {
                    zhVar = this.d;
                    xf0Var2 = this.e;
                    if (i8 >= d) {
                        break;
                    }
                    long a2 = xf0Var.a(i8);
                    dt0 dt0Var2 = (dt0) xf0Var.e(i8);
                    if (zhVar.c(a2)) {
                        boolean z10 = z9;
                        long j = dt0Var2.g;
                        List list3 = dt0Var2.m;
                        long j2 = dt0Var2.c;
                        if ((((j & 9223372034707292159L) + 36028792732385279L) & (-9223372034707292160L)) == 0 && (((j2 & 9223372034707292159L) + 36028792732385279L) & (-9223372034707292160L)) == 0) {
                            z8 = z10;
                            List list4 = ut.e;
                            if (list3 == null) {
                                list = list4;
                            } else {
                                list = list3;
                            }
                            z7 = a;
                            ArrayList arrayList = new ArrayList(list.size());
                            if (list3 == null) {
                                list2 = list4;
                            } else {
                                list2 = list3;
                            }
                            i4 = d;
                            int size = list2.size();
                            i5 = i8;
                            int i9 = 0;
                            while (i9 < size) {
                                List list5 = list2;
                                a30 a30Var = (a30) list2.get(i9);
                                xf0 xf0Var3 = xf0Var2;
                                long j3 = a2;
                                long j4 = a30Var.b;
                                if ((((j4 & 9223372034707292159L) + 36028792732385279L) & (-9223372034707292160L)) == 0) {
                                    dt0Var = dt0Var2;
                                    long j5 = a30Var.a;
                                    i6 = size;
                                    gm0 gm0Var = this.f;
                                    gm0Var.getClass();
                                    arrayList.add(new a30(j5, gm0Var.x(n90Var2, j4), a30Var.c, a30Var.d, a30Var.e));
                                } else {
                                    i6 = size;
                                    dt0Var = dt0Var2;
                                }
                                i9++;
                                size = i6;
                                list2 = list5;
                                xf0Var2 = xf0Var3;
                                a2 = j3;
                                dt0Var2 = dt0Var;
                            }
                            xf0 xf0Var4 = xf0Var2;
                            long j6 = a2;
                            gm0 gm0Var2 = this.f;
                            gm0Var2.getClass();
                            long x = gm0Var2.x(n90Var2, j);
                            gm0 gm0Var3 = this.f;
                            gm0Var3.getClass();
                            dt0 dt0Var3 = new dt0(dt0Var2.a, dt0Var2.b, gm0Var3.x(n90Var2, j2), dt0Var2.d, dt0Var2.e, dt0Var2.f, x, dt0Var2.h, dt0Var2.i, arrayList, dt0Var2.j, dt0Var2.k, dt0Var2.l, dt0Var2.n);
                            dt0 dt0Var4 = dt0Var2.q;
                            if (dt0Var4 == null) {
                                dt0Var4 = dt0Var2;
                            }
                            dt0Var3.q = dt0Var4;
                            dt0 dt0Var5 = dt0Var2.q;
                            if (dt0Var5 != null) {
                                dt0Var2 = dt0Var5;
                            }
                            dt0Var3.q = dt0Var2;
                            xf0Var4.b(j6, dt0Var3);
                        } else {
                            z7 = a;
                            i4 = d;
                            i5 = i8;
                            z8 = z10;
                        }
                    } else {
                        z7 = a;
                        i4 = d;
                        z8 = z9;
                        i5 = i8;
                    }
                    i8 = i5 + 1;
                    n90Var2 = n90Var;
                    d = i4;
                    z9 = z8;
                    a = z7;
                }
                boolean z11 = a;
                boolean z12 = z9;
                if (xf0Var2.d() == 0) {
                    zhVar.e = 0;
                    this.a.g();
                    return z12;
                }
                int i10 = zhVar.e;
                while (true) {
                    i10--;
                    if (-1 >= i10) {
                        break;
                    }
                    long j7 = ((long[]) zhVar.f)[i10];
                    if (xf0Var.e) {
                        int i11 = xf0Var.h;
                        long[] jArr = xf0Var.f;
                        Object[] objArr = xf0Var.g;
                        int i12 = 0;
                        for (int i13 = 0; i13 < i11; i13++) {
                            Object obj2 = objArr[i13];
                            if (obj2 != k70.o) {
                                if (i13 != i12) {
                                    jArr[i12] = jArr[i13];
                                    objArr[i12] = obj2;
                                    objArr[i13] = null;
                                }
                                i12++;
                            }
                        }
                        xf0Var.e = false;
                        xf0Var.h = i12;
                    }
                    if (k70.s(xf0Var.f, xf0Var.h, j7) < 0 && i10 < (i3 = zhVar.e)) {
                        int i14 = i3 - 1;
                        int i15 = i10;
                        while (i15 < i14) {
                            long[] jArr2 = (long[]) zhVar.f;
                            int i16 = i15 + 1;
                            jArr2[i15] = jArr2[i16];
                            i15 = i16;
                        }
                        zhVar.e--;
                    }
                }
                ArrayList arrayList2 = new ArrayList(xf0Var2.d());
                int d2 = xf0Var2.d();
                for (int i17 = 0; i17 < d2; i17++) {
                    arrayList2.add(xf0Var2.e(i17));
                }
                zs0 zs0Var2 = new zs0(arrayList2, e70Var);
                int size2 = arrayList2.size();
                int i18 = 0;
                while (true) {
                    if (i18 < size2) {
                        obj = arrayList2.get(i18);
                        if (e70Var.a(((dt0) obj).a)) {
                            break;
                        }
                        i18++;
                    } else {
                        obj = null;
                        break;
                    }
                }
                dt0 dt0Var6 = (dt0) obj;
                if (dt0Var6 != null) {
                    boolean z13 = dt0Var6.d;
                    if (!z) {
                        i = false;
                        this.i = false;
                    } else {
                        i = false;
                        if (!this.i && (z13 || dt0Var6.h)) {
                            gm0 gm0Var4 = this.f;
                            gm0Var4.getClass();
                            long j8 = gm0Var4.g;
                            long j9 = dt0Var6.c;
                            float intBitsToFloat = Float.intBitsToFloat((int) (j9 >> 32));
                            float intBitsToFloat2 = Float.intBitsToFloat((int) (j9 & 4294967295L));
                            int i19 = (int) (j8 >> 32);
                            int i20 = (int) (j8 & 4294967295L);
                            if (intBitsToFloat < 0.0f) {
                                z3 = z12;
                            } else {
                                z3 = false;
                            }
                            if (intBitsToFloat > i19) {
                                z4 = z12;
                            } else {
                                z4 = false;
                            }
                            boolean z14 = z4 | z3;
                            if (intBitsToFloat2 < 0.0f) {
                                z5 = z12;
                            } else {
                                z5 = false;
                            }
                            boolean z15 = z5 | z14;
                            if (intBitsToFloat2 > i20) {
                                z6 = z12;
                            } else {
                                z6 = false;
                            }
                            this.i = !(z6 | z15);
                        }
                    }
                    boolean z16 = this.i;
                    boolean z17 = this.h;
                    int i21 = 5;
                    if (z16 != z17 && ((i2 = zs0Var2.c) == 3 || i2 == 4 || i2 == 5)) {
                        if (z16) {
                            i21 = 4;
                        }
                        zs0Var2.c = i21;
                    } else {
                        int i22 = zs0Var2.c;
                        if (i22 == 4 && z17 && !this.j) {
                            zs0Var2.c = 3;
                        } else if (i22 == 5 && z16 && z13) {
                            zs0Var2.c = 3;
                        }
                    }
                } else {
                    i = false;
                }
                if (!z11 && zs0Var2.c == 3 && (zs0Var = this.g) != null) {
                    List list6 = zs0Var.a;
                    int size3 = list6.size();
                    List list7 = zs0Var2.a;
                    if (size3 == list7.size()) {
                        int size4 = list7.size();
                        for (int i23 = i; i23 < size4; i23++) {
                            if (xm0.b(((dt0) list6.get(i23)).c, ((dt0) list7.get(i23)).c)) {
                            }
                        }
                        z2 = i;
                        this.g = zs0Var2;
                        return z2;
                    }
                }
                z2 = z12;
                this.g = zs0Var2;
                return z2;
            }
        }
        return true;
    }

    @Override // defpackage.lm0
    public final void b(e70 e70Var) {
        super.b(e70Var);
        zs0 zs0Var = this.g;
        if (zs0Var == null) {
            return;
        }
        this.h = this.i;
        List list = zs0Var.a;
        int size = list.size();
        boolean z = false;
        for (int i = 0; i < size; i++) {
            dt0 dt0Var = (dt0) list.get(i);
            boolean z2 = dt0Var.d;
            long j = dt0Var.a;
            boolean a = e70Var.a(j);
            boolean z3 = this.i;
            if ((!z2 && !a) || (!z2 && !z3)) {
                this.d.g(j);
            }
        }
        this.i = false;
        if (zs0Var.c == 5) {
            z = true;
        }
        this.j = z;
    }

    public final void c() {
        qk0 qk0Var = this.a;
        Object[] objArr = qk0Var.e;
        int i = qk0Var.g;
        for (int i2 = 0; i2 < i; i2++) {
            ((bm0) objArr[i2]).c();
        }
        li0 li0Var = this.c;
        qk0 qk0Var2 = null;
        while (li0Var != null) {
            if (li0Var instanceof gt0) {
                ((gt0) li0Var).R();
            } else if ((li0Var.g & 16) != 0 && (li0Var instanceof dp)) {
                int i3 = 0;
                for (li0 li0Var2 = ((dp) li0Var).t; li0Var2 != null; li0Var2 = li0Var2.j) {
                    if ((li0Var2.g & 16) != 0) {
                        i3++;
                        if (i3 == 1) {
                            li0Var = li0Var2;
                        } else {
                            if (qk0Var2 == null) {
                                qk0Var2 = new qk0(new li0[16]);
                            }
                            if (li0Var != null) {
                                qk0Var2.b(li0Var);
                                li0Var = null;
                            }
                            qk0Var2.b(li0Var2);
                        }
                    }
                }
                if (i3 == 1) {
                }
            }
            li0Var = k70.m(qk0Var2);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:57:0x00ad A[LOOP:0: B:56:0x00ab->B:57:0x00ad, LOOP_END] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean d(e70 e70Var) {
        boolean z;
        boolean z2;
        boolean z3;
        boolean z4;
        boolean z5;
        ba0 ba0Var;
        int i;
        int i2;
        xf0 xf0Var = this.e;
        if (xf0Var.d() != 0) {
            li0 li0Var = this.c;
            if (li0Var.r) {
                gm0 gm0Var = li0Var.l;
                if (gm0Var != null && (ba0Var = gm0Var.s) != null) {
                    z = ba0Var.I();
                } else {
                    z = false;
                }
                if (z) {
                    zs0 zs0Var = this.g;
                    zs0Var.getClass();
                    gm0 gm0Var2 = this.f;
                    gm0Var2.getClass();
                    long j = gm0Var2.g;
                    li0 li0Var2 = li0Var;
                    qk0 qk0Var = null;
                    while (true) {
                        z2 = true;
                        if (li0Var2 == null) {
                            break;
                        }
                        if (li0Var2 instanceof gt0) {
                            ((gt0) li0Var2).x(zs0Var, at0.g, j);
                            z3 = false;
                        } else {
                            z3 = true;
                        }
                        if (z3) {
                            if ((li0Var2.g & 16) != 0) {
                                z4 = true;
                            } else {
                                z4 = false;
                            }
                            if (z4 && (li0Var2 instanceof dp)) {
                                int i3 = 0;
                                for (li0 li0Var3 = ((dp) li0Var2).t; li0Var3 != null; li0Var3 = li0Var3.j) {
                                    if ((li0Var3.g & 16) != 0) {
                                        z5 = true;
                                    } else {
                                        z5 = false;
                                    }
                                    if (z5) {
                                        i3++;
                                        if (i3 == 1) {
                                            li0Var2 = li0Var3;
                                        } else {
                                            if (qk0Var == null) {
                                                qk0Var = new qk0(new li0[16]);
                                            }
                                            if (li0Var2 != null) {
                                                qk0Var.b(li0Var2);
                                                li0Var2 = null;
                                            }
                                            qk0Var.b(li0Var3);
                                        }
                                    }
                                }
                                if (i3 == 1) {
                                }
                            }
                        }
                        li0Var2 = k70.m(qk0Var);
                    }
                    if (li0Var.r) {
                        qk0 qk0Var2 = this.a;
                        Object[] objArr = qk0Var2.e;
                        int i4 = qk0Var2.g;
                        for (int i5 = 0; i5 < i4; i5++) {
                            ((bm0) objArr[i5]).d(e70Var);
                        }
                    }
                    b(e70Var);
                    i = xf0Var.h;
                    Object[] objArr2 = xf0Var.g;
                    for (i2 = 0; i2 < i; i2++) {
                        objArr2[i2] = null;
                    }
                    xf0Var.h = 0;
                    xf0Var.e = false;
                    this.f = null;
                    return z2;
                }
            }
        }
        z2 = false;
        b(e70Var);
        i = xf0Var.h;
        Object[] objArr22 = xf0Var.g;
        while (i2 < i) {
        }
        xf0Var.h = 0;
        xf0Var.e = false;
        this.f = null;
        return z2;
    }

    public final boolean e(e70 e70Var, boolean z) {
        boolean z2;
        boolean z3;
        boolean z4;
        boolean z5;
        boolean z6;
        boolean z7;
        boolean z8;
        ba0 ba0Var;
        if (this.e.d() == 0) {
            return false;
        }
        li0 li0Var = this.c;
        if (li0Var.r) {
            gm0 gm0Var = li0Var.l;
            if (gm0Var != null && (ba0Var = gm0Var.s) != null) {
                z2 = ba0Var.I();
            } else {
                z2 = false;
            }
            if (z2) {
                zs0 zs0Var = this.g;
                zs0Var.getClass();
                gm0 gm0Var2 = this.f;
                gm0Var2.getClass();
                long j = gm0Var2.g;
                li0 li0Var2 = li0Var;
                qk0 qk0Var = null;
                while (li0Var2 != null) {
                    if (li0Var2 instanceof gt0) {
                        ((gt0) li0Var2).x(zs0Var, at0.e, j);
                        z6 = false;
                    } else {
                        z6 = true;
                    }
                    if (z6) {
                        if ((li0Var2.g & 16) != 0) {
                            z7 = true;
                        } else {
                            z7 = false;
                        }
                        if (z7 && (li0Var2 instanceof dp)) {
                            int i = 0;
                            for (li0 li0Var3 = ((dp) li0Var2).t; li0Var3 != null; li0Var3 = li0Var3.j) {
                                if ((li0Var3.g & 16) != 0) {
                                    z8 = true;
                                } else {
                                    z8 = false;
                                }
                                if (z8) {
                                    i++;
                                    if (i == 1) {
                                        li0Var2 = li0Var3;
                                    } else {
                                        if (qk0Var == null) {
                                            qk0Var = new qk0(new li0[16]);
                                        }
                                        if (li0Var2 != null) {
                                            qk0Var.b(li0Var2);
                                            li0Var2 = null;
                                        }
                                        qk0Var.b(li0Var3);
                                    }
                                }
                            }
                            if (i == 1) {
                            }
                        }
                    }
                    li0Var2 = k70.m(qk0Var);
                }
                if (li0Var.r) {
                    qk0 qk0Var2 = this.a;
                    Object[] objArr = qk0Var2.e;
                    int i2 = qk0Var2.g;
                    for (int i3 = 0; i3 < i2; i3++) {
                        this.f.getClass();
                        ((bm0) objArr[i3]).e(e70Var, z);
                    }
                }
                if (li0Var.r) {
                    qk0 qk0Var3 = null;
                    while (li0Var != null) {
                        if (li0Var instanceof gt0) {
                            ((gt0) li0Var).x(zs0Var, at0.f, j);
                            z3 = false;
                        } else {
                            z3 = true;
                        }
                        if (z3) {
                            if ((li0Var.g & 16) != 0) {
                                z4 = true;
                            } else {
                                z4 = false;
                            }
                            if (z4 && (li0Var instanceof dp)) {
                                int i4 = 0;
                                for (li0 li0Var4 = ((dp) li0Var).t; li0Var4 != null; li0Var4 = li0Var4.j) {
                                    if ((li0Var4.g & 16) != 0) {
                                        z5 = true;
                                    } else {
                                        z5 = false;
                                    }
                                    if (z5) {
                                        i4++;
                                        if (i4 == 1) {
                                            li0Var = li0Var4;
                                        } else {
                                            if (qk0Var3 == null) {
                                                qk0Var3 = new qk0(new li0[16]);
                                            }
                                            if (li0Var != null) {
                                                qk0Var3.b(li0Var);
                                                li0Var = null;
                                            }
                                            qk0Var3.b(li0Var4);
                                        }
                                    }
                                }
                                if (i4 == 1) {
                                }
                            }
                        }
                        li0Var = k70.m(qk0Var3);
                    }
                }
                return true;
            }
        }
        return false;
    }

    public final void f(long j, ak0 ak0Var) {
        zh zhVar = this.d;
        if (zhVar.c(j) && ak0Var.g(this) < 0) {
            zhVar.g(j);
            this.e.c(j);
        }
        qk0 qk0Var = this.a;
        Object[] objArr = qk0Var.e;
        int i = qk0Var.g;
        for (int i2 = 0; i2 < i; i2++) {
            ((bm0) objArr[i2]).f(j, ak0Var);
        }
    }

    public final String toString() {
        return "Node(modifierNode=" + this.c + ", children=" + this.a + ", pointerIds=" + this.d + ')';
    }
}