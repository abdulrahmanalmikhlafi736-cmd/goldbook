package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: da  reason: default package */
public final class da {
    public final int a;

    public /* synthetic */ da(int i) {
        this.a = i;
    }

    public final boolean equals(Object obj) {
        if (obj instanceof da) {
            if (this.a != ((da) obj).a) {
                return false;
            }
            return true;
        }
        return false;
    }

    public final int hashCode() {
        return this.a;
    }

    public final String toString() {
        return "AutoClearFocusBehavior(value=" + this.a + ')';
    }
}