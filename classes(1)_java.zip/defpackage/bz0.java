package defpackage;

import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bz0  reason: default package */
public final class bz0 implements ml, dm {
    public static final AtomicReferenceFieldUpdater f = AtomicReferenceFieldUpdater.newUpdater(bz0.class, Object.class, "result");
    public final ml e;
    private volatile Object result;

    public bz0(ml mlVar) {
        cm cmVar = cm.e;
        this.e = mlVar;
        this.result = cmVar;
    }

    @Override // defpackage.dm
    public final dm d() {
        ml mlVar = this.e;
        if (mlVar instanceof dm) {
            return (dm) mlVar;
        }
        return null;
    }

    @Override // defpackage.ml
    public final sl e() {
        return this.e.e();
    }

    @Override // defpackage.ml
    public final void h(Object obj) {
        while (true) {
            Object obj2 = this.result;
            cm cmVar = cm.f;
            if (obj2 == cmVar) {
                AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = f;
                while (!atomicReferenceFieldUpdater.compareAndSet(this, cmVar, obj)) {
                    if (atomicReferenceFieldUpdater.get(this) != cmVar) {
                        break;
                    }
                }
                return;
            }
            cm cmVar2 = cm.e;
            if (obj2 == cmVar2) {
                AtomicReferenceFieldUpdater atomicReferenceFieldUpdater2 = f;
                cm cmVar3 = cm.g;
                while (!atomicReferenceFieldUpdater2.compareAndSet(this, cmVar2, cmVar3)) {
                    if (atomicReferenceFieldUpdater2.get(this) != cmVar2) {
                        break;
                    }
                }
                this.e.h(obj);
                return;
            }
            od.p("Already resumed");
            return;
        }
    }

    public final String toString() {
        return "SafeContinuation for " + this.e;
    }
}