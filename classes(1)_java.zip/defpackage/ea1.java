package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ea1  reason: default package */
public final class ea1 {
    public final int a;
    public final int b;
    public final i00 c;

    public ea1(int i, int i2, i00 i00Var) {
        this.a = i;
        this.b = i2;
        this.c = i00Var;
    }
}