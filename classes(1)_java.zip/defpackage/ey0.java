package defpackage;

import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.View;
import android.view.animation.AnimationUtils;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ey0 */
public final class ey0 extends View {
    public static final int[] j = {16842919, 16842910};
    public static final int[] k = new int[0];
    public cf1 e;
    public Boolean f;
    public Long g;
    public o4 h;
    public x1 i;

    public static /* synthetic */ void a(ey0 ey0Var) {
        setRippleState$lambda$1(ey0Var);
    }

    private final void setRippleState(boolean z) {
        long j2;
        int[] iArr;
        long currentAnimationTimeMillis = AnimationUtils.currentAnimationTimeMillis();
        Runnable runnable = this.h;
        if (runnable != null) {
            removeCallbacks(runnable);
            runnable.run();
        }
        Long l = this.g;
        if (l != null) {
            j2 = l.longValue();
        } else {
            j2 = 0;
        }
        long j3 = currentAnimationTimeMillis - j2;
        if (!z && j3 < 5) {
            o4 o4Var = new o4(8, this);
            this.h = o4Var;
            postDelayed(o4Var, 50L);
        } else {
            if (z) {
                iArr = j;
            } else {
                iArr = k;
            }
            cf1 cf1Var = this.e;
            if (cf1Var != null) {
                cf1Var.setState(iArr);
            }
        }
        this.g = Long.valueOf(currentAnimationTimeMillis);
    }

    public static final void setRippleState$lambda$1(ey0 ey0Var) {
        cf1 cf1Var = ey0Var.e;
        if (cf1Var != null) {
            cf1Var.setState(k);
        }
        ey0Var.h = null;
    }

    public final void b(ou0 ou0Var, boolean z, long j2, int i, long j3, x1 x1Var) {
        if (this.e == null || !Boolean.valueOf(z).equals(this.f)) {
            cf1 cf1Var = new cf1(z);
            setBackground(cf1Var);
            this.e = cf1Var;
            this.f = Boolean.valueOf(z);
        }
        cf1 cf1Var2 = this.e;
        cf1Var2.getClass();
        this.i = x1Var;
        e(i, j2, j3);
        if (z) {
            cf1Var2.setHotspot(Float.intBitsToFloat((int) (ou0Var.a >> 32)), Float.intBitsToFloat((int) (ou0Var.a & 4294967295L)));
        } else {
            cf1Var2.setHotspot(cf1Var2.getBounds().centerX(), cf1Var2.getBounds().centerY());
        }
        setRippleState(true);
    }

    public final void c() {
        this.i = null;
        o4 o4Var = this.h;
        if (o4Var != null) {
            removeCallbacks(o4Var);
            o4 o4Var2 = this.h;
            o4Var2.getClass();
            o4Var2.run();
        } else {
            cf1 cf1Var = this.e;
            if (cf1Var != null) {
                cf1Var.setState(k);
            }
        }
        cf1 cf1Var2 = this.e;
        if (cf1Var2 == null) {
            return;
        }
        cf1Var2.setVisible(false, false);
        unscheduleDrawable(cf1Var2);
    }

    public final void d() {
        setRippleState(false);
    }

    @Override // android.view.View
    public final void draw(Canvas canvas) {
        if (!isAttachedToWindow()) {
            c();
        } else {
            super.draw(canvas);
        }
    }

    public final void e(int i, long j2, long j3) {
        float f;
        boolean c;
        cf1 cf1Var = this.e;
        if (cf1Var == null) {
            return;
        }
        Integer num = cf1Var.g;
        if (num == null || num.intValue() != i) {
            cf1Var.g = Integer.valueOf(i);
            cf1Var.setRadius(i);
        }
        if (Build.VERSION.SDK_INT < 28) {
            f = 0.2f;
        } else {
            f = 0.1f;
        }
        if (f > 1.0f) {
            f = 1.0f;
        }
        long b = zg.b(j3, f);
        zg zgVar = cf1Var.f;
        if (zgVar == null) {
            c = false;
        } else {
            c = zg.c(zgVar.a, b);
        }
        if (!c) {
            cf1Var.f = new zg(b);
            cf1Var.setColor(ColorStateList.valueOf(wl1.L(b)));
        }
        Rect rect = new Rect(0, 0, gh0.P(Float.intBitsToFloat((int) (j2 >> 32))), gh0.P(Float.intBitsToFloat((int) (j2 & 4294967295L))));
        setLeft(rect.left);
        setTop(rect.top);
        setRight(rect.right);
        setBottom(rect.bottom);
        cf1Var.setBounds(rect);
    }

    @Override // android.view.View, android.graphics.drawable.Drawable.Callback
    public final void invalidateDrawable(Drawable drawable) {
        x1 x1Var = this.i;
        if (x1Var != null) {
            x1Var.a();
        }
    }

    @Override // android.view.View
    public final void onLayout(boolean z, int i, int i2, int i3, int i4) {
    }

    @Override // android.view.View
    public final void onMeasure(int i, int i2) {
        setMeasuredDimension(0, 0);
    }

    @Override // android.view.View
    public final void refreshDrawableState() {
    }
}