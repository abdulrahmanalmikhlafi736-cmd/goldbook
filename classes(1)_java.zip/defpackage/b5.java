package defpackage;

import android.os.Looper;
import android.view.Choreographer;
import java.util.UUID;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: b5  reason: default package */
public final class b5 extends h90 implements xz {
    public final /* synthetic */ int f;
    public static final b5 g = new b5(0, 0);
    public static final b5 h = new b5(0, 1);
    public static final b5 i = new b5(0, 2);
    public static final b5 j = new b5(0, 3);
    public static final b5 k = new b5(0, 4);
    public static final b5 l = new b5(0, 5);
    public static final b5 m = new b5(0, 6);
    public static final b5 n = new b5(0, 7);
    public static final b5 o = new b5(0, 8);
    public static final b5 p = new b5(0, 9);
    public static final b5 q = new b5(0, 10);
    public static final b5 r = new b5(0, 11);
    public static final b5 s = new b5(0, 12);
    public static final b5 t = new b5(0, 13);
    public static final b5 u = new b5(0, 14);
    public static final b5 v = new b5(0, 15);
    public static final b5 w = new b5(0, 16);
    public static final b5 x = new b5(0, 17);
    public static final b5 y = new b5(0, 18);
    public static final b5 z = new b5(0, 19);
    public static final b5 A = new b5(0, 20);
    public static final b5 B = new b5(0, 21);
    public static final b5 C = new b5(0, 22);
    public static final b5 D = new b5(0, 23);
    public static final b5 E = new b5(0, 24);
    public static final b5 F = new b5(0, 25);
    public static final b5 G = new b5(0, 26);
    public static final b5 H = new b5(0, 27);
    public static final b5 I = new b5(0, 28);
    public static final b5 J = new b5(0, 29);

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ b5(int i2, int i3) {
        super(i2);
        this.f = i3;
    }

    @Override // defpackage.xz
    public final Object a() {
        Choreographer choreographer;
        int i2 = this.f;
        we1 we1Var = we1.a;
        switch (i2) {
            case 0:
                c5.a("LocalConfiguration");
                throw null;
            case 1:
                c5.a("LocalContext");
                throw null;
            case 2:
                c5.a("LocalImageVectorCache");
                throw null;
            case 3:
                c5.a("LocalResourceIdCache");
                throw null;
            case gu0.LONG_FIELD_NUMBER /* 4 */:
                c5.a("LocalView");
                throw null;
            case gu0.STRING_FIELD_NUMBER /* 5 */:
                return UUID.randomUUID();
            case gu0.STRING_SET_FIELD_NUMBER /* 6 */:
                return Boolean.FALSE;
            case gu0.DOUBLE_FIELD_NUMBER /* 7 */:
                return "DEFAULT_TEST_TAG";
            case 8:
                if (Looper.myLooper() == Looper.getMainLooper()) {
                    choreographer = Choreographer.getInstance();
                } else {
                    uo uoVar = kq.a;
                    choreographer = (Choreographer) wl1.G(kg0.a, new a7(2, null, 0));
                }
                d7 d7Var = new d7(choreographer, vd1.j(Looper.getMainLooper()));
                return vn.O(d7Var, d7Var.p);
            case 9:
            case 10:
            case 11:
                return we1Var;
            case 12:
                return new ba0(2);
            case 13:
            case 14:
                return null;
            case 15:
                fk.b("LocalAutofillManager");
                throw null;
            case 16:
                fk.b("LocalAutofillTree");
                throw null;
            case 17:
                fk.b("LocalClipboard");
                throw null;
            case 18:
                fk.b("LocalClipboardManager");
                throw null;
            case 19:
                return Boolean.TRUE;
            case 20:
                fk.b("LocalDensity");
                throw null;
            case 21:
                fk.b("LocalFocusManager");
                throw null;
            case 22:
                fk.b("LocalFontFamilyResolver");
                throw null;
            case 23:
                fk.b("LocalFontLoader");
                throw null;
            case 24:
                fk.b("LocalGraphicsContext");
                throw null;
            case 25:
                fk.b("LocalHapticFeedback");
                throw null;
            case 26:
                fk.b("LocalInputManager");
                throw null;
            case 27:
                fk.b("LocalLayoutDirection");
                throw null;
            case 28:
                return null;
            default:
                fk.b("LocalProvidableLocaleList");
                throw null;
        }
    }
}