package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: b  reason: default package */
public final /* synthetic */ class b implements xz {
    public final /* synthetic */ int e;
    public final /* synthetic */ dg f;

    public /* synthetic */ b(dg dgVar, int i) {
        this.e = i;
        this.f = dgVar;
    }

    @Override // defpackage.xz
    public final Object a() {
        cp cpVar;
        int i = this.e;
        dg dgVar = this.f;
        switch (i) {
            case 0:
                t40 t40Var = (t40) j70.z(dgVar, p40.a);
                if (t40Var == null) {
                    s50.a("clickable only supports IndicationNodeFactory instances provided to LocalIndication, but Indication was provided instead. Either migrate the Indication implementation to implement IndicationNodeFactory, or use the other clickable overload that takes an Indication parameter, and explicitly pass LocalIndication.current there. The Indication instance provided here was: " + t40Var);
                }
                t40 t40Var2 = dgVar.B;
                dgVar.B = t40Var;
                if (t40Var2 != null && !k70.p(t40Var, t40Var2) && ((cpVar = dgVar.D) != null || !dgVar.K)) {
                    if (cpVar != null) {
                        dgVar.s0(cpVar);
                    }
                    dgVar.D = null;
                    dgVar.y0();
                }
                return we1.a;
            default:
                dgVar.z.a();
                return Boolean.TRUE;
        }
    }
}