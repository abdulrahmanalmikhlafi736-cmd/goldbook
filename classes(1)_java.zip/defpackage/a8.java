package defpackage;

import java.util.concurrent.CancellationException;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: a8  reason: default package */
public final class a8 extends u91 implements i00 {
    public p8 i;
    public jw0 j;
    public int k;
    public final /* synthetic */ c8 l;
    public final /* synthetic */ Object m;
    public final /* synthetic */ ja1 n;
    public final /* synthetic */ long o;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public a8(c8 c8Var, Object obj, ja1 ja1Var, long j, ml mlVar) {
        super(1, mlVar);
        this.l = c8Var;
        this.m = obj;
        this.n = ja1Var;
        this.o = j;
    }

    @Override // defpackage.i00
    public final Object i(Object obj) {
        ja1 ja1Var = this.n;
        long j = this.o;
        return new a8(this.l, this.m, ja1Var, j, (ml) obj).p(we1.a);
    }

    /* JADX WARN: Type inference failed for: r7v1, types: [jw0, java.lang.Object] */
    @Override // defpackage.db
    public final Object p(Object obj) {
        p8 p8Var;
        jw0 jw0Var;
        l8 l8Var;
        ja1 ja1Var = this.n;
        int i = this.k;
        c8 c8Var = this.l;
        try {
            if (i != 0) {
                if (i == 1) {
                    jw0Var = this.j;
                    p8Var = this.i;
                    nb0.t(obj);
                } else {
                    od.p("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
            } else {
                nb0.t(obj);
                c8Var.c.g = (u8) c8Var.a.a.i(this.m);
                c8Var.e.setValue(ja1Var.c);
                c8Var.d.setValue(Boolean.TRUE);
                p8 p8Var2 = c8Var.c;
                p8 p8Var3 = new p8(p8Var2.e, p8Var2.f.getValue(), a5.n(p8Var2.g), p8Var2.h, Long.MIN_VALUE, p8Var2.j);
                ?? obj2 = new Object();
                long j = this.o;
                z7 z7Var = new z7(c8Var, p8Var3, (Object) obj2, 0);
                this.i = p8Var3;
                this.j = obj2;
                this.k = 1;
                Object b = wa0.b(p8Var3, ja1Var, j, z7Var, this);
                cm cmVar = cm.e;
                if (b == cmVar) {
                    return cmVar;
                }
                p8Var = p8Var3;
                jw0Var = obj2;
            }
            if (jw0Var.e) {
                l8Var = l8.e;
            } else {
                l8Var = l8.f;
            }
            c8.b(c8Var);
            return new m8(p8Var, l8Var);
        } catch (CancellationException e) {
            c8.b(c8Var);
            throw e;
        }
    }
}