package defpackage;

import android.content.ContentProviderClient;
import android.content.Context;
import android.net.Uri;
import java.util.concurrent.ExecutorService;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ez  reason: default package */
public final class ez {
    public final /* synthetic */ int a;
    public final ContentProviderClient b;

    public ez(Context context, Uri uri, int i) {
        this.a = i;
        switch (i) {
            case 1:
                this.b = context.getContentResolver().acquireUnstableContentProviderClient(uri);
                return;
            default:
                this.b = context.getContentResolver().acquireUnstableContentProviderClient(uri);
                return;
        }
    }

    public final void a() {
        int i = this.a;
        ContentProviderClient contentProviderClient = this.b;
        switch (i) {
            case 0:
                if (contentProviderClient != null) {
                    contentProviderClient.release();
                    return;
                }
                return;
            default:
                if (contentProviderClient != null) {
                    if (contentProviderClient instanceof AutoCloseable) {
                        contentProviderClient.close();
                        return;
                    } else if (contentProviderClient instanceof ExecutorService) {
                        y0.o((ExecutorService) contentProviderClient);
                        return;
                    } else {
                        contentProviderClient.release();
                        return;
                    }
                }
                return;
        }
    }
}