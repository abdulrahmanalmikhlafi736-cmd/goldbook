package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ec1  reason: default package */
final class ec1 extends qi0 {
    public final uj0 a;
    public final boolean b;
    public final p71 c;

    public ec1(uj0 uj0Var, boolean z, p71 p71Var) {
        this.a = uj0Var;
        this.b = z;
        this.c = p71Var;
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [li0, hc1] */
    @Override // defpackage.qi0
    public final li0 e() {
        ?? li0Var = new li0();
        li0Var.s = this.a;
        li0Var.t = this.b;
        li0Var.u = this.c;
        li0Var.y = Float.NaN;
        li0Var.z = Float.NaN;
        return li0Var;
    }

    public final boolean equals(Object obj) {
        if (this != obj) {
            if (obj instanceof ec1) {
                ec1 ec1Var = (ec1) obj;
                if (!k70.p(this.a, ec1Var.a) || this.b != ec1Var.b || !this.c.equals(ec1Var.c)) {
                    return false;
                }
                return true;
            }
            return false;
        }
        return true;
    }

    @Override // defpackage.qi0
    public final void f(li0 li0Var) {
        hc1 hc1Var = (hc1) li0Var;
        hc1Var.s = this.a;
        boolean z = hc1Var.t;
        boolean z2 = this.b;
        if (z != z2) {
            vd1.t(hc1Var);
        }
        hc1Var.t = z2;
        hc1Var.u = this.c;
        if (hc1Var.x == null && !Float.isNaN(hc1Var.z)) {
            hc1Var.x = k70.a(hc1Var.z);
        }
        if (hc1Var.w == null && !Float.isNaN(hc1Var.y)) {
            hc1Var.w = k70.a(hc1Var.y);
        }
    }

    public final int hashCode() {
        int i;
        int hashCode = this.a.hashCode() * 31;
        if (this.b) {
            i = 1231;
        } else {
            i = 1237;
        }
        return this.c.hashCode() + ((hashCode + i) * 31);
    }

    public final String toString() {
        return "ThumbElement(interactionSource=" + this.a + ", checked=" + this.b + ", animationSpec=" + this.c + ')';
    }
}