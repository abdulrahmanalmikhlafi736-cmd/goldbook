package defpackage;

import mod.Mod;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dn  reason: default package */
public final class dn extends u91 implements m00 {
    public final /* synthetic */ int i;
    public /* synthetic */ Object j;
    public final /* synthetic */ Object k;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ dn(Object obj, Object obj2, ml mlVar, int i) {
        super(2, mlVar);
        this.i = i;
        this.j = obj;
        this.k = obj2;
    }

    @Override // defpackage.m00
    public final Object f(Object obj, Object obj2) {
        int i = this.i;
        we1 we1Var = we1.a;
        switch (i) {
            case 0:
                return ((dn) n((ml) obj2, (z71) obj)).p(we1Var);
            case 1:
                ((dn) n((ml) obj2, (bm) obj)).p(we1Var);
                return we1Var;
            case 2:
                ((dn) n((ml) obj2, (bm) obj)).p(we1Var);
                return we1Var;
            case 3:
                ((dn) n((ml) obj2, (bm) obj)).p(we1Var);
                return we1Var;
            case gu0.LONG_FIELD_NUMBER /* 4 */:
                ((dn) n((ml) obj2, (bm) obj)).p(we1Var);
                return we1Var;
            default:
                ((dn) n((ml) obj2, (ek0) obj)).p(we1Var);
                return we1Var;
        }
    }

    @Override // defpackage.db
    public final ml n(ml mlVar, Object obj) {
        int i = this.i;
        Object obj2 = this.k;
        switch (i) {
            case 0:
                dn dnVar = new dn((z71) obj2, mlVar, 0);
                dnVar.j = obj;
                return dnVar;
            case 1:
                return new dn((wi1) this.j, (mk0) obj2, mlVar, 1);
            case 2:
                return new dn((sb1) this.j, (dh) obj2, mlVar, 2);
            case 3:
                dn dnVar2 = new dn((kd0) obj2, mlVar, 3);
                dnVar2.j = obj;
                return dnVar2;
            case gu0.LONG_FIELD_NUMBER /* 4 */:
                return new dn((wi1) this.j, (ui1) obj2, mlVar, 4);
            default:
                dn dnVar3 = new dn((String) obj2, mlVar, 5);
                dnVar3.j = obj;
                return dnVar3;
        }
    }

    @Override // defpackage.db
    public final Object p(Object obj) {
        String str;
        boolean z = false;
        switch (this.i) {
            case 0:
                nb0.t(obj);
                z71 z71Var = (z71) this.j;
                if ((z71Var instanceof qm) && ((qm) z71Var).a <= ((qm) ((z71) this.k)).a) {
                    z = true;
                }
                return Boolean.valueOf(z);
            case 1:
                nb0.t(obj);
                if (((Boolean) ((mk0) this.k).getValue()).booleanValue()) {
                    str = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0";
                } else {
                    str = null;
                }
                x7 b = ((wi1) this.j).b();
                if (b != null) {
                    b.a.getSettings().setUserAgentString(str);
                    return we1.a;
                }
                od.p("WebView is not initialized");
                return null;
            case 2:
                nb0.t(obj);
                ((sb1) this.j).a = wl1.L(((dh) this.k).a);
                ((sb1) this.j).b = wl1.L(((dh) this.k).b);
                return we1.a;
            case 3:
                nb0.t(obj);
                bm bmVar = (bm) this.j;
                kd0 kd0Var = (kd0) this.k;
                ud0 ud0Var = kd0Var.e;
                if (ud0Var.d.compareTo(jd0.f) >= 0) {
                    ud0Var.a(kd0Var);
                } else {
                    a80 a80Var = (a80) bmVar.f().k(e3.S);
                    if (a80Var != null) {
                        a80Var.a(null);
                    }
                }
                return we1.a;
            case gu0.LONG_FIELD_NUMBER /* 4 */:
                nb0.t(obj);
                if (((wi1) this.j).h == null) {
                    ui1 ui1Var = (ui1) this.k;
                    wl1.B(ui1Var.a, null, new d(ui1Var, "https://www.facebook.com/messages", null, 24), 3);
                }
                Mod.setVideoState(false, 0, 0);
                return we1.a;
            default:
                nb0.t(obj);
                ((ek0) this.j).d(n41.L, (String) this.k);
                return we1.a;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ dn(Object obj, ml mlVar, int i) {
        super(2, mlVar);
        this.i = i;
        this.k = obj;
    }
}