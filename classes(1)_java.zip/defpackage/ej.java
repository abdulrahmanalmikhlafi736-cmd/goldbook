package defpackage;

import java.util.List;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ej  reason: default package */
public final class ej {
    public final List a;
    public final boolean b;

    public ej(List list, boolean z) {
        this.a = list;
        this.b = z;
    }
}