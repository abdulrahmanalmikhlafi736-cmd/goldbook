package defpackage;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.NoSuchElementException;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ch0  reason: default package */
public abstract class ch0 extends sb0 {
    public static Object x(Object obj, Map map) {
        map.getClass();
        Object obj2 = map.get(obj);
        if (obj2 == null && !map.containsKey(obj)) {
            throw new NoSuchElementException("Key " + obj + " is missing in the map.");
        }
        return obj2;
    }

    public static int y(int i) {
        if (i < 0) {
            return i;
        }
        if (i < 3) {
            return i + 1;
        }
        if (i < 1073741824) {
            return (int) ((i / 0.75f) + 1.0f);
        }
        return Integer.MAX_VALUE;
    }

    public static Map z(zp0... zp0VarArr) {
        if (zp0VarArr.length > 0) {
            LinkedHashMap linkedHashMap = new LinkedHashMap(y(zp0VarArr.length));
            for (zp0 zp0Var : zp0VarArr) {
                linkedHashMap.put(zp0Var.e, zp0Var.f);
            }
            return linkedHashMap;
        }
        return vt.e;
    }
}