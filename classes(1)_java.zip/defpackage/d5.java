package defpackage;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: d5  reason: default package */
public final class d5 {
    public static final d5 e;
    public static final d5 f;
    public static final /* synthetic */ d5[] g;

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0, types: [d5, java.lang.Enum] */
    /* JADX WARN: Type inference failed for: r1v1, types: [d5, java.lang.Enum] */
    static {
        ?? r0 = new Enum("SHOW_ORIGINAL", 0);
        e = r0;
        ?? r1 = new Enum("SHOW_TRANSLATED", 1);
        f = r1;
        g = new d5[]{r0, r1};
    }

    public static d5 valueOf(String str) {
        return (d5) Enum.valueOf(d5.class, str);
    }

    public static d5[] values() {
        return (d5[]) g.clone();
    }
}