package defpackage;

import android.os.Looper;
import android.view.Choreographer;
import android.view.MotionEvent;
import android.view.View;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: e7  reason: default package */
public final class e7 extends h90 implements i00 {
    public final /* synthetic */ int f;
    public final /* synthetic */ Object g;
    public final /* synthetic */ Object h;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ e7(int i, Object obj, Object obj2) {
        super(1);
        this.f = i;
        this.h = obj;
        this.g = obj2;
    }

    @Override // defpackage.i00
    public final Object i(Object obj) {
        it0 it0Var;
        switch (this.f) {
            case 0:
                Throwable th = (Throwable) obj;
                d7 d7Var = (d7) this.h;
                f7 f7Var = (f7) this.g;
                synchronized (d7Var.i) {
                    d7Var.k.remove(f7Var);
                }
                return we1.a;
            case 1:
                Throwable th2 = (Throwable) obj;
                ((Choreographer) ((g7) this.h).f).removeFrameCallback((f7) this.g);
                return we1.a;
            case 2:
                ((ba0) this.h).d0(((mi0) obj).b((mi0) this.g));
                return we1.a;
            case 3:
                js0.m((js0) obj, (ks0) this.h, ((rb) this.g).s);
                return we1.a;
            case gu0.LONG_FIELD_NUMBER /* 4 */:
                MotionEvent motionEvent = (MotionEvent) obj;
                jt0 jt0Var = (jt0) this.g;
                if (motionEvent.getActionMasked() == 0) {
                    p3 p3Var = (p3) this.h;
                    if (((Boolean) ((l7) jt0Var.e()).i(motionEvent)).booleanValue()) {
                        it0Var = it0.f;
                    } else {
                        it0Var = it0.g;
                    }
                    p3Var.f = it0Var;
                } else {
                    ((l7) jt0Var.e()).i(motionEvent);
                }
                return we1.a;
            case gu0.STRING_FIELD_NUMBER /* 5 */:
                js0.m((js0) obj, (ks0) this.h, ((n51) this.g).D);
                return we1.a;
            case gu0.STRING_SET_FIELD_NUMBER /* 6 */:
                mj mjVar = (mj) obj;
                m00 m00Var = (m00) this.g;
                pl1 pl1Var = (pl1) this.h;
                if (!pl1Var.g) {
                    sd0 sd0Var = mjVar.c;
                    View view = mjVar.a;
                    ud0 g = sd0Var.g();
                    pl1Var.i = m00Var;
                    if (pl1Var.h == null) {
                        if (!k70.p(Looper.myLooper(), view.getHandler().getLooper())) {
                            view.post(new e5(3, pl1Var, g));
                        } else {
                            pl1Var.h = g;
                            g.a(pl1Var);
                        }
                    } else if (g.d.compareTo(jd0.g) >= 0) {
                        pl1Var.f.A(new pi(-1723985096, true, new ek(pl1Var, mjVar, m00Var)));
                    }
                }
                return we1.a;
            default:
                js0 js0Var = (js0) obj;
                ks0 ks0Var = (ks0) this.h;
                float f = ((vl1) this.g).s;
                js0Var.getClass();
                js0.c(js0Var, ks0Var);
                ks0Var.R(n60.c(0L, ks0Var.i), f, null);
                return we1.a;
        }
    }
}