package defpackage;

import java.util.HashSet;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: em0  reason: default package */
public final class em0 {
    public final ba0 a;
    public final dm0 b;
    public final v50 c;
    public gm0 d;
    public final ha1 e;
    public li0 f;
    public qk0 g;
    public qk0 h;
    public final qk0 i;
    public cm0 j;

    /* JADX WARN: Type inference failed for: r0v0, types: [li0, dm0] */
    public em0(ba0 ba0Var) {
        this.a = ba0Var;
        ?? li0Var = new li0();
        li0Var.h = -1;
        this.b = li0Var;
        v50 v50Var = new v50(ba0Var);
        this.c = v50Var;
        this.d = v50Var;
        ha1 ha1Var = v50Var.U;
        this.e = ha1Var;
        this.f = ha1Var;
        this.i = new qk0(new mi0[16]);
    }

    public static final void a(em0 em0Var, li0 li0Var, gm0 gm0Var) {
        v50 v50Var;
        for (li0 li0Var2 = li0Var.i; li0Var2 != null; li0Var2 = li0Var2.i) {
            if (li0Var2 == em0Var.b) {
                ba0 v = em0Var.a.v();
                if (v != null) {
                    v50Var = v.J.c;
                } else {
                    v50Var = null;
                }
                gm0Var.u = v50Var;
                em0Var.d = gm0Var;
                return;
            } else if ((li0Var2.g & 2) == 0) {
                li0Var2.q0(gm0Var);
            } else {
                return;
            }
        }
    }

    /* JADX WARN: Type inference failed for: r0v1, types: [li0, cb] */
    public static li0 b(ki0 ki0Var, li0 li0Var) {
        li0 li0Var2;
        if (ki0Var instanceof qi0) {
            li0Var2 = ((qi0) ki0Var).e();
            li0Var2.g = hm0.f(li0Var2);
        } else {
            ?? li0Var3 = new li0();
            li0Var3.g = hm0.d(ki0Var);
            li0Var3.s = ki0Var;
            new HashSet();
            li0Var2 = li0Var3;
        }
        if (li0Var2.r) {
            p50.b("A ModifierNodeElement cannot return an already attached node from create() ");
        }
        li0Var2.m = true;
        li0 li0Var4 = li0Var.j;
        if (li0Var4 != null) {
            li0Var4.i = li0Var2;
            li0Var2.j = li0Var4;
        }
        li0Var.j = li0Var2;
        li0Var2.i = li0Var;
        return li0Var2;
    }

    public static li0 c(li0 li0Var) {
        boolean z = li0Var.r;
        if (z) {
            zj0 zj0Var = hm0.a;
            if (!z) {
                p50.b("autoInvalidateRemovedNode called on unattached node");
            }
            hm0.a(li0Var, -1, 2);
            li0Var.o0();
            li0Var.g0();
        }
        li0 li0Var2 = li0Var.j;
        li0 li0Var3 = li0Var.i;
        if (li0Var2 != null) {
            li0Var2.i = li0Var3;
            li0Var.j = null;
        }
        if (li0Var3 != null) {
            li0Var3.j = li0Var2;
            li0Var.i = null;
        }
        li0Var3.getClass();
        return li0Var3;
    }

    public static void h(ki0 ki0Var, ki0 ki0Var2, li0 li0Var) {
        if ((ki0Var instanceof qi0) && (ki0Var2 instanceof qi0)) {
            li0Var.getClass();
            ((qi0) ki0Var2).f(li0Var);
            if (li0Var.r) {
                hm0.c(li0Var);
            } else {
                li0Var.n = true;
            }
        } else if (li0Var instanceof cb) {
            cb cbVar = (cb) li0Var;
            boolean z = cbVar.r;
            if (z) {
                if (!z) {
                    p50.b("unInitializeModifier called on unattached node");
                }
                if ((cbVar.g & 8) != 0) {
                    ((n4) k70.P(cbVar)).E();
                }
            }
            cbVar.s = ki0Var2;
            cbVar.g = hm0.d(ki0Var2);
            if (cbVar.r) {
                cbVar.r0(false);
            }
            if (li0Var.r) {
                hm0.c(li0Var);
            } else {
                li0Var.n = true;
            }
        } else {
            p50.b("Unknown Modifier.Node type");
        }
    }

    public final boolean d(int i) {
        if ((this.f.h & i) != 0) {
            return true;
        }
        return false;
    }

    public final void e() {
        for (li0 li0Var = this.f; li0Var != null; li0Var = li0Var.j) {
            li0Var.n0();
            if (li0Var.m) {
                zj0 zj0Var = hm0.a;
                if (!li0Var.r) {
                    p50.b("autoInvalidateInsertedNode called on unattached node");
                }
                hm0.a(li0Var, -1, 1);
            }
            if (li0Var.n) {
                hm0.c(li0Var);
            }
            li0Var.m = false;
            li0Var.n = false;
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:118:0x0262, code lost:
        r13 = r28 + 2;
        r11 = r24;
     */
    /* JADX WARN: Code restructure failed: missing block: B:119:0x0268, code lost:
        r3 = r3 + 1;
        r12 = r20;
        r11 = r21;
        r13 = r26;
        r14 = r29;
        r35 = 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x00ce, code lost:
        if (r16[(r11 + 1) + r17] > r16[(r25 - 1) + r17]) goto L82;
     */
    /* JADX WARN: Code restructure failed: missing block: B:55:0x0148, code lost:
        r26 = r13;
        r29 = r14;
     */
    /* JADX WARN: Code restructure failed: missing block: B:56:0x014e, code lost:
        if ((r19 & 1) != 0) goto L132;
     */
    /* JADX WARN: Code restructure failed: missing block: B:57:0x0150, code lost:
        r11 = 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:58:0x0152, code lost:
        r11 = r33;
     */
    /* JADX WARN: Code restructure failed: missing block: B:59:0x0154, code lost:
        r13 = r12;
     */
    /* JADX WARN: Code restructure failed: missing block: B:60:0x0155, code lost:
        if (r13 > r3) goto L130;
     */
    /* JADX WARN: Code restructure failed: missing block: B:61:0x0157, code lost:
        if (r13 == r12) goto L129;
     */
    /* JADX WARN: Code restructure failed: missing block: B:62:0x0159, code lost:
        if (r13 == r3) goto L128;
     */
    /* JADX WARN: Code restructure failed: missing block: B:63:0x015b, code lost:
        r24 = r11;
     */
    /* JADX WARN: Code restructure failed: missing block: B:64:0x0169, code lost:
        if (r20[(r13 + 1) + r17] >= r20[(r13 - 1) + r17]) goto L95;
     */
    /* JADX WARN: Code restructure failed: missing block: B:66:0x016c, code lost:
        r24 = r11;
     */
    /* JADX WARN: Code restructure failed: missing block: B:67:0x016e, code lost:
        r11 = r20[(r13 - 1) + r17];
        r14 = r11 - 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:68:0x0177, code lost:
        r24 = r11;
     */
    /* JADX WARN: Code restructure failed: missing block: B:69:0x0179, code lost:
        r11 = r20[(r13 + 1) + r17];
        r14 = r11;
     */
    /* JADX WARN: Code restructure failed: missing block: B:70:0x0180, code lost:
        r22 = r10 - ((r6 - r14) - r13);
     */
    /* JADX WARN: Code restructure failed: missing block: B:71:0x0186, code lost:
        if (r3 == 0) goto L126;
     */
    /* JADX WARN: Code restructure failed: missing block: B:72:0x0188, code lost:
        r25 = 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:73:0x018b, code lost:
        r25 = r33;
     */
    /* JADX WARN: Code restructure failed: missing block: B:74:0x018d, code lost:
        if (r14 != r11) goto L125;
     */
    /* JADX WARN: Code restructure failed: missing block: B:75:0x018f, code lost:
        r27 = 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:76:0x0192, code lost:
        r27 = r33;
     */
    /* JADX WARN: Code restructure failed: missing block: B:77:0x0194, code lost:
        r25 = r22 + (r25 & r27);
        r22 = r11;
        r11 = r22;
     */
    /* JADX WARN: Code restructure failed: missing block: B:78:0x019e, code lost:
        if (r14 <= r7) goto L124;
     */
    /* JADX WARN: Code restructure failed: missing block: B:79:0x01a0, code lost:
        if (r11 <= r15) goto L122;
     */
    /* JADX WARN: Code restructure failed: missing block: B:80:0x01a2, code lost:
        r27 = r11;
        r28 = r13;
     */
    /* JADX WARN: Code restructure failed: missing block: B:81:0x01ae, code lost:
        if (r0.a(r14 - 1, r27 - 1) == false) goto L107;
     */
    /* JADX WARN: Code restructure failed: missing block: B:82:0x01b0, code lost:
        r14 = r14 - 1;
        r11 = r27 - 1;
        r13 = r28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:83:0x01b7, code lost:
        r27 = r11;
        r28 = r13;
     */
    /* JADX WARN: Code restructure failed: missing block: B:84:0x01bb, code lost:
        r20[r17 + r28] = r14;
     */
    /* JADX WARN: Code restructure failed: missing block: B:85:0x01bf, code lost:
        if (r24 == 0) goto L121;
     */
    /* JADX WARN: Code restructure failed: missing block: B:86:0x01c1, code lost:
        r11 = r19 - r28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:87:0x01c3, code lost:
        if (r11 < r12) goto L120;
     */
    /* JADX WARN: Code restructure failed: missing block: B:88:0x01c5, code lost:
        if (r11 > r3) goto L119;
     */
    /* JADX WARN: Code restructure failed: missing block: B:90:0x01cb, code lost:
        if (r16[r17 + r11] < r14) goto L117;
     */
    /* JADX WARN: Code restructure failed: missing block: B:91:0x01cd, code lost:
        r26[r33] = r14;
        r11 = 1;
        r26[1] = r27;
        r26[r32] = r22;
        r26[3] = r25;
        r26[4] = 1;
     */
    /* JADX WARN: Removed duplicated region for block: B:33:0x00f1  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x00f4  */
    /* JADX WARN: Removed duplicated region for block: B:36:0x00f8  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x00fb  */
    /* JADX WARN: Removed duplicated region for block: B:46:0x011c  */
    /* JADX WARN: Removed duplicated region for block: B:53:0x013e  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void f(int i, qk0 qk0Var, qk0 qk0Var2, li0 li0Var, boolean z) {
        int i2;
        qk0 qk0Var3;
        qk0 qk0Var4;
        int i3;
        int[] iArr;
        int[] iArr2;
        int i4;
        char c;
        char c2;
        int i5;
        int i6;
        int i7;
        int i8;
        int i9;
        int i10;
        int i11;
        int i12;
        int i13;
        int i14;
        int i15;
        cm0 cm0Var = this.j;
        if (cm0Var == null) {
            i2 = i;
            qk0Var3 = qk0Var;
            qk0Var4 = qk0Var2;
            cm0Var = new cm0(this, li0Var, i2, qk0Var3, qk0Var4, z);
            this.j = cm0Var;
        } else {
            i2 = i;
            qk0Var3 = qk0Var;
            qk0Var4 = qk0Var2;
            cm0Var.a = li0Var;
            cm0Var.b = i2;
            cm0Var.c = qk0Var3;
            cm0Var.d = qk0Var4;
            cm0Var.e = z;
        }
        em0 em0Var = cm0Var.f;
        int i16 = qk0Var3.g - i2;
        int i17 = qk0Var4.g - i2;
        char c3 = 2;
        int i18 = ((i16 + i17) + 1) / 2;
        w60 w60Var = new w60(i18 * 3);
        w60 w60Var2 = new w60(i18 * 4);
        int i19 = 0;
        w60Var2.e(0, i16, 0, i17);
        int i20 = (i18 * 2) + 1;
        int[] iArr3 = new int[i20];
        int[] iArr4 = new int[i20];
        int[] iArr5 = new int[5];
        while (true) {
            int i21 = w60Var2.b;
            if (i21 == 0) {
                break;
            }
            char c4 = c3;
            int[] iArr6 = w60Var2.a;
            int i22 = i19;
            int i23 = i21 - 1;
            w60Var2.b = i23;
            int i24 = iArr6[i23];
            int i25 = i21 - 2;
            w60Var2.b = i25;
            int i26 = iArr6[i25];
            int i27 = i21 - 3;
            w60Var2.b = i27;
            int i28 = iArr6[i27];
            int i29 = i21 - 4;
            w60Var2.b = i29;
            int i30 = iArr6[i29];
            int i31 = i28 - i30;
            int i32 = i20;
            int i33 = i24 - i26;
            int[] iArr7 = iArr3;
            if (i31 >= 1 && i33 >= 1) {
                int i34 = 1;
                int i35 = ((i31 + i33) + 1) / 2;
                int i36 = i32 / 2;
                int i37 = i36 + 1;
                iArr7[i37] = i30;
                iArr4[i37] = i28;
                int i38 = i22;
                while (i38 < i35) {
                    int i39 = i31 - i33;
                    int i40 = i35;
                    iArr = iArr4;
                    if ((Math.abs(i39) & 1) == i34) {
                        i4 = 1;
                    } else {
                        i4 = i22;
                    }
                    int i41 = -i38;
                    int i42 = i4;
                    int i43 = i41;
                    while (true) {
                        if (i43 > i38) {
                            break;
                        }
                        if (i43 != i41) {
                            if (i43 != i38) {
                                i9 = i43;
                                iArr2 = iArr5;
                            } else {
                                i9 = i43;
                                iArr2 = iArr5;
                            }
                            i10 = iArr7[(i9 - 1) + i36];
                            i11 = i10 + 1;
                            int i44 = ((i11 - i30) + i26) - i9;
                            if (i38 == 0) {
                                i12 = 1;
                            } else {
                                i12 = i22;
                            }
                            if (i11 != i10) {
                                i13 = 1;
                            } else {
                                i13 = i22;
                            }
                            int i45 = i44 - (i12 & i13);
                            int i46 = i10;
                            i14 = i44;
                            while (i11 < i28 && i14 < i24 && cm0Var.a(i11, i14)) {
                                i11++;
                                i14++;
                            }
                            iArr7[i36 + i9] = i11;
                            if (i42 == 0) {
                                int i47 = i14;
                                int i48 = i39 - i9;
                                i15 = i31;
                                if (i48 >= i41 + 1 && i48 <= i38 - 1 && iArr[i36 + i48] <= i11) {
                                    iArr2[i22] = i46;
                                    iArr2[1] = i45;
                                    iArr2[c4] = i11;
                                    iArr2[3] = i47;
                                    iArr2[4] = i22;
                                    c = 1;
                                    break;
                                }
                            } else {
                                i15 = i31;
                            }
                            i43 = i9 + 2;
                            iArr5 = iArr2;
                            i31 = i15;
                        } else {
                            i9 = i43;
                            iArr2 = iArr5;
                        }
                        i10 = iArr7[i9 + 1 + i36];
                        i11 = i10;
                        int i442 = ((i11 - i30) + i26) - i9;
                        if (i38 == 0) {
                        }
                        if (i11 != i10) {
                        }
                        int i452 = i442 - (i12 & i13);
                        int i462 = i10;
                        i14 = i442;
                        while (i11 < i28) {
                            i11++;
                            i14++;
                        }
                        iArr7[i36 + i9] = i11;
                        if (i42 == 0) {
                        }
                        i43 = i9 + 2;
                        iArr5 = iArr2;
                        i31 = i15;
                    }
                    if (Math.min(iArr2[c4] - iArr2[i22], iArr2[3] - iArr2[c]) > 0) {
                        int i49 = iArr2[i22];
                        int i50 = iArr2[c];
                        int i51 = iArr2[3] - i50;
                        int i52 = iArr2[c4] - i49;
                        if (i51 != i52) {
                            i52 = Math.min(i52, i51);
                            int i53 = iArr2[4];
                            if (i53 != 0) {
                                i5 = 1;
                            } else {
                                i5 = i22;
                            }
                            int i54 = iArr2[3];
                            c2 = 1;
                            int i55 = iArr2[1];
                            int i56 = i54 - i55;
                            int i57 = iArr2[c4];
                            int i58 = iArr2[i22];
                            if (i56 > i57 - i58) {
                                i6 = 1;
                            } else {
                                i6 = i22;
                            }
                            int i59 = i49 + ((i6 | i5) ^ 1);
                            if (i53 != 0) {
                                i7 = 1;
                            } else {
                                i7 = i22;
                            }
                            if (i54 - i55 > i57 - i58) {
                                i8 = 1;
                            } else {
                                i8 = i22;
                            }
                            i50 += ((i8 ^ 1) | i7) ^ 1;
                            i49 = i59;
                        } else {
                            c2 = 1;
                        }
                        w60Var.d(i49, i50, i52);
                    } else {
                        c2 = c;
                    }
                    w60Var2.e(i30, iArr2[i22], i26, iArr2[c2]);
                    w60Var2.e(iArr2[c4], i28, iArr2[3], i24);
                    c3 = c4;
                    i19 = i22;
                    i20 = i32;
                    iArr3 = iArr7;
                    iArr4 = iArr;
                    iArr5 = iArr2;
                }
            }
            iArr = iArr4;
            iArr2 = iArr5;
            c3 = c4;
            i19 = i22;
            i20 = i32;
            iArr3 = iArr7;
            iArr4 = iArr;
            iArr5 = iArr2;
        }
        int i60 = i19;
        int i61 = w60Var.b;
        if (i61 % 3 != 0) {
            p50.b("Array size not a multiple of 3");
        }
        if (i61 > 3) {
            i3 = i60;
            w60Var.f(i3, i61 - 3);
        } else {
            i3 = i60;
        }
        w60Var.d(i16, i17, i3);
        int i62 = i3;
        int i63 = i62;
        int i64 = i63;
        while (i62 < w60Var.b) {
            int[] iArr8 = w60Var.a;
            int i65 = iArr8[i62];
            int i66 = iArr8[i62 + 2];
            int i67 = i65 - i66;
            int i68 = iArr8[i62 + 1] - i66;
            i62 += 3;
            while (i63 < i67) {
                li0 li0Var2 = cm0Var.a.j;
                li0Var2.getClass();
                if ((li0Var2.g & 2) != 0) {
                    gm0 gm0Var = li0Var2.l;
                    gm0Var.getClass();
                    gm0 gm0Var2 = gm0Var.u;
                    gm0 gm0Var3 = gm0Var.t;
                    gm0Var3.getClass();
                    if (gm0Var2 != null) {
                        gm0Var2.t = gm0Var3;
                    }
                    gm0Var3.u = gm0Var2;
                    a(em0Var, cm0Var.a, gm0Var3);
                }
                cm0Var.a = c(li0Var2);
                i63++;
            }
            while (i64 < i68) {
                li0 b = b((ki0) cm0Var.d.e[cm0Var.b + i64], cm0Var.a);
                cm0Var.a = b;
                if (cm0Var.e) {
                    li0 li0Var3 = b.j;
                    li0Var3.getClass();
                    gm0 gm0Var4 = li0Var3.l;
                    gm0Var4.getClass();
                    t90 q = k70.q(cm0Var.a);
                    if (q != null) {
                        v90 v90Var = new v90(em0Var.a, q);
                        cm0Var.a.q0(v90Var);
                        a(em0Var, cm0Var.a, v90Var);
                        v90Var.u = gm0Var4.u;
                        v90Var.t = gm0Var4;
                        gm0Var4.u = v90Var;
                    } else {
                        cm0Var.a.q0(gm0Var4);
                    }
                    cm0Var.a.f0();
                    cm0Var.a.n0();
                    li0 li0Var4 = cm0Var.a;
                    zj0 zj0Var = hm0.a;
                    if (!li0Var4.r) {
                        p50.b("autoInvalidateInsertedNode called on unattached node");
                    }
                    hm0.a(li0Var4, -1, 1);
                } else {
                    b.m = true;
                }
                i64++;
            }
            while (true) {
                int i69 = i66 - 1;
                if (i66 > 0) {
                    li0 li0Var5 = cm0Var.a.j;
                    li0Var5.getClass();
                    cm0Var.a = li0Var5;
                    qk0 qk0Var5 = cm0Var.c;
                    int i70 = cm0Var.b;
                    ki0 ki0Var = (ki0) qk0Var5.e[i70 + i63];
                    ki0 ki0Var2 = (ki0) cm0Var.d.e[i70 + i64];
                    if (!k70.p(ki0Var, ki0Var2)) {
                        h(ki0Var, ki0Var2, cm0Var.a);
                    }
                    i63++;
                    i64++;
                    i66 = i69;
                }
            }
        }
        int i71 = i3;
        for (li0 li0Var6 = this.e.i; li0Var6 != null && li0Var6 != this.b; li0Var6 = li0Var6.i) {
            i71 |= li0Var6.g;
            li0Var6.h = i71;
        }
    }

    public final void g() {
        ba0 ba0Var;
        v50 v50Var;
        v90 v90Var;
        li0 li0Var = this.e.i;
        gm0 gm0Var = this.c;
        li0 li0Var2 = li0Var;
        while (true) {
            ba0Var = this.a;
            if (li0Var2 == null) {
                break;
            }
            t90 q = k70.q(li0Var2);
            if (q != null) {
                gm0 gm0Var2 = li0Var2.l;
                if (gm0Var2 != null) {
                    v90 v90Var2 = (v90) gm0Var2;
                    t90 t90Var = v90Var2.U;
                    v90Var2.W0(q);
                    v90Var = v90Var2;
                    if (t90Var != li0Var2) {
                        kp0 kp0Var = v90Var2.P;
                        v90Var = v90Var2;
                        if (kp0Var != null) {
                            ((l20) kp0Var).c();
                            v90Var = v90Var2;
                        }
                    }
                } else {
                    v90 v90Var3 = new v90(ba0Var, q);
                    li0Var2.q0(v90Var3);
                    v90Var = v90Var3;
                }
                gm0Var.u = v90Var;
                v90Var.t = gm0Var;
                gm0Var = v90Var;
            } else {
                li0Var2.q0(gm0Var);
            }
            li0Var2 = li0Var2.i;
        }
        ba0 v = ba0Var.v();
        if (v != null) {
            v50Var = v.J.c;
        } else {
            v50Var = null;
        }
        gm0Var.u = v50Var;
        this.d = gm0Var;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("[");
        li0 li0Var = this.f;
        ha1 ha1Var = this.e;
        if (li0Var != ha1Var) {
            while (true) {
                if (li0Var == null || li0Var == ha1Var) {
                    break;
                }
                sb.append(String.valueOf(li0Var));
                if (li0Var.j == ha1Var) {
                    sb.append("]");
                    break;
                }
                sb.append(",");
                li0Var = li0Var.j;
            }
        } else {
            sb.append("]");
        }
        return sb.toString();
    }
}