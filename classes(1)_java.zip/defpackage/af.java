package defpackage;

import java.util.ArrayList;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: af  reason: default package */
public abstract class af implements x00 {
    public final sl e;
    public final int f;
    public final gd g;
    public final tw h;

    public af(tw twVar, sl slVar, int i, gd gdVar) {
        this.e = slVar;
        this.f = i;
        this.g = gdVar;
        this.h = twVar;
    }

    public abstract af a(sl slVar, int i, gd gdVar);

    @Override // defpackage.tw
    public final Object b(uw uwVar, ml mlVar) {
        sl D;
        int i = this.f;
        cm cmVar = cm.e;
        we1 we1Var = we1.a;
        if (i == -3) {
            sl e = mlVar.e();
            Boolean bool = Boolean.FALSE;
            o9 o9Var = new o9(14);
            sl slVar = this.e;
            if (!((Boolean) slVar.p(o9Var, bool)).booleanValue()) {
                D = e.i(slVar);
            } else {
                D = j70.D(e, slVar, false);
            }
            if (k70.p(D, e)) {
                Object e2 = e(uwVar, mlVar);
                if (e2 == cmVar) {
                    return e2;
                }
            } else {
                e3 e3Var = e3.B;
                if (k70.p(D.k(e3Var), e.k(e3Var))) {
                    sl e3 = mlVar.e();
                    if (!(uwVar instanceof a31) && !(uwVar instanceof om0)) {
                        uwVar = new g8(uwVar, e3);
                    }
                    Object L = zi1.L(D, uwVar, gh0.U(D), new ze(this, null, 1), mlVar);
                    if (L == cmVar) {
                        return L;
                    }
                }
            }
            return we1Var;
        }
        Object i2 = vd1.i(new f(uwVar, this, null, 3), mlVar);
        if (i2 != cmVar) {
            i2 = we1Var;
        }
        if (i2 == cmVar) {
            return i2;
        }
        return we1Var;
    }

    @Override // defpackage.x00
    public final tw c(sl slVar, int i, gd gdVar) {
        sl slVar2 = this.e;
        sl i2 = slVar.i(slVar2);
        gd gdVar2 = gd.e;
        gd gdVar3 = this.g;
        int i3 = this.f;
        if (gdVar == gdVar2) {
            if (i3 != -3) {
                if (i != -3) {
                    if (i3 != -2) {
                        if (i != -2) {
                            i += i3;
                            if (i < 0) {
                                i = Integer.MAX_VALUE;
                            }
                        }
                    }
                }
                i = i3;
            }
            gdVar = gdVar3;
        }
        if (k70.p(i2, slVar2) && i == i3 && gdVar == gdVar3) {
            return this;
        }
        return a(i2, i, gdVar);
    }

    public tw d() {
        return null;
    }

    public abstract Object e(uw uwVar, ml mlVar);

    public final String f() {
        ArrayList arrayList = new ArrayList(4);
        st stVar = st.e;
        sl slVar = this.e;
        if (slVar != stVar) {
            arrayList.add("context=" + slVar);
        }
        int i = this.f;
        if (i != -3) {
            arrayList.add("capacity=" + i);
        }
        gd gdVar = gd.e;
        gd gdVar2 = this.g;
        if (gdVar2 != gdVar) {
            arrayList.add("onBufferOverflow=" + gdVar2);
        }
        return getClass().getSimpleName() + '[' + tg.V(arrayList, ", ", null, null, null, 62) + ']';
    }

    public final String toString() {
        return this.h + " -> " + f();
    }
}