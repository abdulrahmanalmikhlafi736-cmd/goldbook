package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: eq0  reason: default package */
public final class eq0 {
    public String a;
    public ob1 b;
    public yy c;
    public int d;
    public boolean e;
    public int f;
    public int g;
    public jp i;
    public m6 j;
    public boolean k;
    public di0 m;
    public dq0 n;
    public o90 o;
    public long s;
    public long h = t50.a;
    public long l = 0;
    public long p = tk.g(0, 0, 0, 0);
    public int q = -1;
    public int r = -1;

    public eq0(String str, ob1 ob1Var, yy yyVar, int i, boolean z, int i2, int i3) {
        this.a = str;
        this.b = ob1Var;
        this.c = yyVar;
        this.d = i;
        this.e = z;
        this.f = i2;
        this.g = i3;
    }

    public static long g(eq0 eq0Var, long j, o90 o90Var) {
        ob1 ob1Var = eq0Var.b;
        di0 di0Var = eq0Var.m;
        jp jpVar = eq0Var.i;
        jpVar.getClass();
        yy yyVar = eq0Var.c;
        if ((di0Var == null || o90Var != di0Var.a || !wa0.v(ob1Var, o90Var).equals(di0Var.b) || jpVar.a() != di0Var.c.e || yyVar != di0Var.d) && ((di0Var = di0.h) == null || o90Var != di0Var.a || !wa0.v(ob1Var, o90Var).equals(di0Var.b) || jpVar.a() != di0Var.c.e || yyVar != di0Var.d)) {
            di0Var = new di0(o90Var, wa0.v(ob1Var, o90Var), new mp(jpVar.a(), jpVar.g()), yyVar);
            di0.h = di0Var;
        }
        eq0Var.m = di0Var;
        int i = eq0Var.g;
        mp mpVar = di0Var.c;
        float f = di0Var.g;
        float f2 = di0Var.f;
        int i2 = 0;
        if (Float.isNaN(f) || Float.isNaN(f2)) {
            float b = dd0.a(ei0.a, di0Var.e, tk.b(0, 0, 15), mpVar, di0Var.d, 1).b();
            float b2 = dd0.a(ei0.b, di0Var.e, tk.b(0, 0, 15), mpVar, di0Var.d, 2).b() - b;
            di0Var.g = b;
            di0Var.f = b2;
            f2 = b2;
            f = b;
        }
        if (i != 1) {
            int round = Math.round((f2 * (i - 1)) + f);
            if (round >= 0) {
                i2 = round;
            }
            int g = sk.g(j);
            if (i2 > g) {
                i2 = g;
            }
        } else {
            i2 = sk.i(j);
        }
        return tk.a(sk.j(j), sk.h(j), i2, sk.g(j));
    }

    public final int a(int i, o90 o90Var) {
        int i2;
        int i3 = this.q;
        int i4 = this.r;
        if (i == i3 && i3 != -1) {
            return i4;
        }
        long a = tk.a(0, i, 0, Integer.MAX_VALUE);
        if (this.g > 1) {
            a = g(this, a, o90Var);
        }
        dq0 e = e(o90Var);
        long v = wl1.v(a, this.e, this.d, e.c());
        boolean z = this.e;
        int i5 = this.d;
        int i6 = this.f;
        if ((!z && (i5 == 2 || i5 == 4 || i5 == 5)) || i6 < 1) {
            i2 = 1;
        } else {
            i2 = i6;
        }
        int e2 = sb0.e(new m6((q6) e, i2, i5, v).b());
        int i7 = sk.i(a);
        if (e2 < i7) {
            e2 = i7;
        }
        this.q = i;
        this.r = e2;
        return e2;
    }

    public final boolean b(long j, o90 o90Var) {
        long j2;
        int i;
        long d;
        dq0 dq0Var;
        long d2;
        this.s = (this.s << 2) | 3;
        boolean z = true;
        if (this.g > 1) {
            j2 = g(this, j, o90Var);
        } else {
            j2 = j;
        }
        m6 m6Var = this.j;
        boolean z2 = false;
        if (m6Var != null && (dq0Var = this.n) != null && !dq0Var.b() && o90Var == this.o && (sk.b(j2, this.p) || (sk.h(j2) == sk.h(this.p) && sk.j(j2) == sk.j(this.p) && sk.g(j2) >= m6Var.b() && !m6Var.d.d))) {
            if (!sk.b(j2, this.p)) {
                m6 m6Var2 = this.j;
                m6Var2.getClass();
                this.l = tk.d(j2, (sb0.e(Math.min(m6Var2.a.i.c(), m6Var2.c())) << 32) | (sb0.e(m6Var2.b()) & 4294967295L));
                if (this.d == 3 || (((int) (d2 >> 32)) >= m6Var2.c() && ((int) (4294967295L & d2)) >= m6Var2.b())) {
                    z = false;
                }
                this.k = z;
                this.p = j2;
            }
            return false;
        }
        dq0 e = e(o90Var);
        long v = wl1.v(j2, this.e, this.d, e.c());
        boolean z3 = this.e;
        int i2 = this.d;
        int i3 = this.f;
        if ((!z3 && (i2 == 2 || i2 == 4 || i2 == 5)) || i3 < 1) {
            i = 1;
        } else {
            i = i3;
        }
        m6 m6Var3 = new m6((q6) e, i, i2, v);
        this.p = j2;
        this.l = tk.d(j2, (sb0.e(m6Var3.b()) & 4294967295L) | (sb0.e(m6Var3.c()) << 32));
        if (this.d != 3 && (((int) (d >> 32)) < m6Var3.c() || ((int) (d & 4294967295L)) < m6Var3.b())) {
            z2 = true;
        }
        this.k = z2;
        this.j = m6Var3;
        return true;
    }

    public final void c() {
        this.j = null;
        this.n = null;
        this.o = null;
        this.q = -1;
        this.r = -1;
        if (!(true & true)) {
            r50.a("width and height must be >= 0");
        }
        this.p = tk.g(0, 0, 0, 0);
        this.l = 0L;
        this.k = false;
    }

    public final void d(jp jpVar) {
        long j;
        jp jpVar2 = this.i;
        if (jpVar != null) {
            int i = t50.b;
            j = t50.a(jpVar.a(), jpVar.g());
        } else {
            j = t50.a;
        }
        if (jpVar2 == null) {
            this.i = jpVar;
            this.h = j;
        } else if (jpVar != null && this.h == j) {
        } else {
            this.i = jpVar;
            this.h = j;
            this.s = (this.s << 2) | 1;
            c();
        }
    }

    public final dq0 e(o90 o90Var) {
        dq0 dq0Var = this.n;
        if (dq0Var == null || o90Var != this.o || dq0Var.b()) {
            this.o = o90Var;
            String str = this.a;
            ob1 v = wa0.v(this.b, o90Var);
            jp jpVar = this.i;
            jpVar.getClass();
            yy yyVar = this.c;
            ut utVar = ut.e;
            dq0Var = new q6(str, v, utVar, utVar, yyVar, jpVar);
        }
        this.n = dq0Var;
        return dq0Var;
    }

    public final void f(String str, ob1 ob1Var, yy yyVar, int i, boolean z, int i2, int i3) {
        this.a = str;
        this.b = ob1Var;
        this.c = yyVar;
        this.d = i;
        this.e = z;
        this.f = i2;
        this.g = i3;
        this.s = (this.s << 2) | 2;
        c();
    }

    public final String toString() {
        String str;
        StringBuilder sb = new StringBuilder("ParagraphLayoutCache(paragraph=");
        if (this.j != null) {
            str = "<paragraph>";
        } else {
            str = "null";
        }
        sb.append(str);
        sb.append(", lastDensity=");
        sb.append((Object) t50.b(this.h));
        sb.append(", history=");
        sb.append(this.s);
        sb.append(", constraints=$)");
        return sb.toString();
    }
}