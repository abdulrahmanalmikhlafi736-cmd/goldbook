package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ar  reason: default package */
public final class ar implements sl {
    public final /* synthetic */ sl e;
    public final Throwable f;

    public ar(sl slVar, Throwable th) {
        this.e = slVar;
        this.f = th;
    }

    @Override // defpackage.sl
    public final sl i(sl slVar) {
        return this.e.i(slVar);
    }

    @Override // defpackage.sl
    public final ql k(rl rlVar) {
        return this.e.k(rlVar);
    }

    @Override // defpackage.sl
    public final Object p(m00 m00Var, Object obj) {
        return this.e.p(m00Var, obj);
    }

    @Override // defpackage.sl
    public final sl t(rl rlVar) {
        return this.e.t(rlVar);
    }
}