package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ah0  reason: default package */
public abstract class ah0 {
    public static final zg0 a;
    public static final zg0 b;

    /* JADX WARN: Type inference failed for: r0v3, types: [zg0, java.lang.Object] */
    static {
        jv0 jv0Var = jv0.c;
        zg0 zg0Var = null;
        try {
            zg0Var = (zg0) Class.forName("androidx.datastore.preferences.protobuf.MapFieldSchemaFull").getDeclaredConstructor(null).newInstance(null);
        } catch (Exception unused) {
        }
        a = zg0Var;
        b = new Object();
    }
}