package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: aa0  reason: default package */
public abstract /* synthetic */ class aa0 {
    public static final /* synthetic */ int[] a;

    static {
        int[] iArr = new int[x90.values().length];
        try {
            iArr[4] = 1;
        } catch (NoSuchFieldError unused) {
        }
        a = iArr;
    }
}