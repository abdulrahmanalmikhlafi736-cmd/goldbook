package defpackage;

import android.graphics.Insets;
import android.view.View;
import android.view.WindowInsets;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bk1  reason: default package */
public class bk1 extends ak1 {
    public static final hk1 x;

    static {
        WindowInsets windowInsets;
        windowInsets = WindowInsets.CONSUMED;
        x = hk1.c(null, windowInsets);
    }

    public bk1(hk1 hk1Var, WindowInsets windowInsets) {
        super(hk1Var, windowInsets);
    }

    @Override // defpackage.zj1, defpackage.vj1, defpackage.dk1
    public c60 i(int i) {
        Insets insets;
        insets = this.c.getInsets(gk1.a(i));
        return c60.c(insets);
    }

    @Override // defpackage.zj1, defpackage.vj1, defpackage.dk1
    public c60 j(int i) {
        Insets insetsIgnoringVisibility;
        insetsIgnoringVisibility = this.c.getInsetsIgnoringVisibility(gk1.a(i));
        return c60.c(insetsIgnoringVisibility);
    }

    @Override // defpackage.vj1, defpackage.dk1
    public void p(View view) {
    }

    @Override // defpackage.zj1, defpackage.vj1, defpackage.dk1
    public boolean u(int i) {
        boolean isVisible;
        isVisible = this.c.isVisible(gk1.a(i));
        return isVisible;
    }

    public bk1(hk1 hk1Var, bk1 bk1Var) {
        super(hk1Var, bk1Var);
    }
}