package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bo  reason: default package */
public final class bo extends li0 implements ds {
    public final uj0 s;
    public boolean t;
    public boolean u;
    public boolean v;

    public bo(uj0 uj0Var) {
        this.s = uj0Var;
    }

    @Override // defpackage.ds
    public final void C(da0 da0Var) {
        da0Var.c();
        te teVar = da0Var.e;
        if (this.t) {
            fu0.x(da0Var, zg.b(zg.b, 0.3f), teVar.f.t(), 122);
        } else if (!this.u && !this.v) {
        } else {
            fu0.x(da0Var, zg.b(zg.b, 0.1f), teVar.f.t(), 122);
        }
    }

    @Override // defpackage.ds
    public final /* synthetic */ void Z() {
    }

    @Override // defpackage.li0
    public final void h0() {
        wl1.B(d0(), null, new ao(this, (ml) null, 0), 3);
    }
}