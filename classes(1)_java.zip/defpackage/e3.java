package defpackage;

import android.app.Activity;
import android.content.ContextWrapper;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Point;
import android.graphics.Rect;
import android.util.Log;
import android.view.Display;
import android.view.DisplayCutout;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import org.chromium.support_lib_boundary.StaticsBoundaryInterface;
import org.chromium.support_lib_boundary.WebkitToCompatConverterBoundaryInterface;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: e3  reason: default package */
public final class e3 implements dc, rl, kp, vb0, nd, rx0, vi1, t61, i91 {
    public final /* synthetic */ int e;
    public static final nb f = new nb(-1.0f, -1.0f);
    public static final nb g = new nb(0.0f, -1.0f);
    public static final nb h = new nb(1.0f, -1.0f);
    public static final nb i = new nb(-1.0f, 0.0f);
    public static final nb j = new nb(0.0f, 0.0f);
    public static final nb k = new nb(1.0f, 0.0f);
    public static final nb l = new nb(-1.0f, 1.0f);
    public static final nb m = new nb(0.0f, 1.0f);
    public static final nb n = new nb(1.0f, 1.0f);
    public static final mb o = new mb(-1.0f);
    public static final mb p = new mb(0.0f);
    public static final lb q = new lb(-1.0f);
    public static final lb r = new lb(0.0f);
    public static final lb s = new lb(1.0f);
    public static final e3 t = new e3(1);
    public static final e3 u = new e3(2);
    public static final e3 v = new e3(3);
    public static final e3 w = new e3(4);
    public static final e3 x = new e3(5);
    public static final od y = new od(1);
    public static final i5 z = new i5(1);
    public static final i5 A = new i5(2);
    public static final /* synthetic */ e3 B = new e3(8);
    public static final /* synthetic */ e3 C = new e3(9);
    public static final e3 D = new e3(10);
    public static final e3 E = new e3(11);
    public static final e3 F = new e3(12);
    public static final e3 G = new e3(13);
    public static final e3 H = new e3(14);
    public static final o90 I = o90.e;
    public static final mp J = new mp(1.0f, 1.0f);
    public static final e3 K = new e3(15);
    public static final e3 L = new e3(16);
    public static final e3 M = new e3(17);
    public static final gw0 N = new gw0(Float.NaN, Float.NaN, Float.NaN, Float.NaN);
    public static final e3 O = new e3(19);
    public static final /* synthetic */ e3 P = new e3(20);
    public static final String[] Q = new String[0];
    public static final /* synthetic */ e3 R = new e3(22);
    public static final /* synthetic */ e3 S = new e3(23);
    public static final e3 T = new e3(24);
    public static final /* synthetic */ e3 U = new e3(25);
    public static final /* synthetic */ e3 V = new e3(26);
    public static final e3 W = new e3(27);
    public static final e3 X = new e3(28);
    public static final e3 Y = new e3(29);

    public /* synthetic */ e3(int i2) {
        this.e = i2;
    }

    @Override // defpackage.nd
    public jp a() {
        return J;
    }

    @Override // defpackage.nd
    public long b() {
        return 9205357640488583168L;
    }

    @Override // defpackage.t61
    public boolean c(Object obj, Object obj2) {
        return false;
    }

    @Override // defpackage.vb0
    public void cancel() {
    }

    @Override // defpackage.vb0
    public void d() {
    }

    @Override // defpackage.vi1
    public String[] e() {
        return Q;
    }

    @Override // defpackage.i91
    public void f(h91 h91Var) {
        h91Var.clear();
    }

    @Override // defpackage.dc
    public Rect g(Activity activity) {
        int i2;
        int i3;
        int i4 = this.e;
        cc ccVar = dc.a;
        DisplayCutout displayCutout = null;
        int i5 = 0;
        switch (i4) {
            case 1:
                Display defaultDisplay = activity.getWindowManager().getDefaultDisplay();
                defaultDisplay.getClass();
                Point point = new Point();
                defaultDisplay.getRealSize(point);
                Rect rect = new Rect();
                int i6 = point.x;
                if (i6 != 0 && (i2 = point.y) != 0) {
                    rect.right = i6;
                    rect.bottom = i2;
                } else {
                    defaultDisplay.getRectSize(rect);
                }
                return rect;
            case 2:
                Rect rect2 = new Rect();
                Display defaultDisplay2 = activity.getWindowManager().getDefaultDisplay();
                defaultDisplay2.getRectSize(rect2);
                if (!y0.r(activity)) {
                    Point point2 = new Point();
                    defaultDisplay2.getRealSize(point2);
                    Resources resources = activity.getResources();
                    int identifier = resources.getIdentifier("navigation_bar_height", "dimen", "android");
                    if (identifier > 0) {
                        i5 = resources.getDimensionPixelSize(identifier);
                    }
                    int i7 = rect2.bottom + i5;
                    if (i7 == point2.y) {
                        rect2.bottom = i7;
                    } else {
                        int i8 = rect2.right + i5;
                        if (i8 == point2.x) {
                            rect2.right = i8;
                        }
                    }
                }
                return rect2;
            case 3:
                Rect rect3 = new Rect();
                Configuration configuration = activity.getResources().getConfiguration();
                try {
                    Field declaredField = Configuration.class.getDeclaredField("windowConfiguration");
                    declaredField.setAccessible(true);
                    Object obj = declaredField.get(configuration);
                    if (y0.r(activity)) {
                        Object invoke = obj.getClass().getDeclaredMethod("getBounds", null).invoke(obj, null);
                        invoke.getClass();
                        rect3.set((Rect) invoke);
                    } else {
                        Object invoke2 = obj.getClass().getDeclaredMethod("getAppBounds", null).invoke(obj, null);
                        invoke2.getClass();
                        rect3.set((Rect) invoke2);
                    }
                } catch (Exception e) {
                    if (!(e instanceof NoSuchFieldException) && !(e instanceof NoSuchMethodException) && !(e instanceof IllegalAccessException) && !(e instanceof InvocationTargetException)) {
                        throw e;
                    }
                    ccVar.getClass();
                    Log.w(cc.b, e);
                    activity.getWindowManager().getDefaultDisplay().getRectSize(rect3);
                }
                Display defaultDisplay3 = activity.getWindowManager().getDefaultDisplay();
                Point point3 = new Point();
                defaultDisplay3.getRealSize(point3);
                if (!y0.r(activity)) {
                    Resources resources2 = activity.getResources();
                    int identifier2 = resources2.getIdentifier("navigation_bar_height", "dimen", "android");
                    if (identifier2 > 0) {
                        i3 = resources2.getDimensionPixelSize(identifier2);
                    } else {
                        i3 = 0;
                    }
                    int i9 = rect3.bottom + i3;
                    if (i9 == point3.y) {
                        rect3.bottom = i9;
                    } else {
                        int i10 = rect3.right + i3;
                        if (i10 == point3.x) {
                            rect3.right = i10;
                        } else if (rect3.left == i3) {
                            rect3.left = 0;
                        }
                    }
                }
                if ((rect3.width() < point3.x || rect3.height() < point3.y) && !y0.r(activity)) {
                    try {
                        Constructor<?> constructor = Class.forName("android.view.DisplayInfo").getConstructor(null);
                        constructor.setAccessible(true);
                        Object newInstance = constructor.newInstance(null);
                        Method declaredMethod = defaultDisplay3.getClass().getDeclaredMethod("getDisplayInfo", newInstance.getClass());
                        declaredMethod.setAccessible(true);
                        declaredMethod.invoke(defaultDisplay3, newInstance);
                        Field declaredField2 = newInstance.getClass().getDeclaredField("displayCutout");
                        declaredField2.setAccessible(true);
                        Object obj2 = declaredField2.get(newInstance);
                        if (z0.r(obj2)) {
                            displayCutout = z0.e(obj2);
                        }
                    } catch (Exception e2) {
                        if (!(e2 instanceof ClassNotFoundException) && !(e2 instanceof NoSuchMethodException) && !(e2 instanceof NoSuchFieldException) && !(e2 instanceof IllegalAccessException) && !(e2 instanceof InvocationTargetException) && !(e2 instanceof InstantiationException)) {
                            throw e2;
                        }
                        ccVar.getClass();
                        Log.w(cc.b, e2);
                    }
                    if (displayCutout != null) {
                        if (rect3.left == z0.s(displayCutout)) {
                            rect3.left = 0;
                        }
                        if (point3.x - rect3.right == z0.y(displayCutout)) {
                            rect3.right = z0.y(displayCutout) + rect3.right;
                        }
                        if (rect3.top == z0.a(displayCutout)) {
                            rect3.top = 0;
                        }
                        if (point3.y - rect3.bottom == z0.x(displayCutout)) {
                            rect3.bottom = z0.x(displayCutout) + rect3.bottom;
                        }
                    }
                }
                return rect3;
            default:
                Configuration configuration2 = activity.getResources().getConfiguration();
                try {
                    Field declaredField3 = Configuration.class.getDeclaredField("windowConfiguration");
                    declaredField3.setAccessible(true);
                    Object obj3 = declaredField3.get(configuration2);
                    Object invoke3 = obj3.getClass().getDeclaredMethod("getBounds", null).invoke(obj3, null);
                    invoke3.getClass();
                    return new Rect((Rect) invoke3);
                } catch (Exception e3) {
                    if (!(e3 instanceof NoSuchFieldException) && !(e3 instanceof NoSuchMethodException) && !(e3 instanceof IllegalAccessException) && !(e3 instanceof InvocationTargetException)) {
                        throw e3;
                    }
                    ccVar.getClass();
                    Log.w(cc.b, e3);
                    return v.g(activity);
                }
        }
    }

    @Override // defpackage.nd
    public o90 getLayoutDirection() {
        return I;
    }

    @Override // defpackage.vi1
    public StaticsBoundaryInterface getStatics() {
        throw new UnsupportedOperationException("This should never happen, if this method was called it means we're trying to reach into WebView APK code on an incompatible device. This most likely means the current method is being called too early, or is being called on start-up rather than lazily");
    }

    @Override // defpackage.vi1
    public WebkitToCompatConverterBoundaryInterface getWebkitToCompatConverter() {
        throw new UnsupportedOperationException("This should never happen, if this method was called it means we're trying to reach into WebView APK code on an incompatible device. This most likely means the current method is being called too early, or is being called on start-up rather than lazily");
    }

    @Override // defpackage.kp
    public float h(ContextWrapper contextWrapper) {
        return contextWrapper.getResources().getDisplayMetrics().density;
    }

    @Override // defpackage.i91
    public boolean i(Object obj, Object obj2) {
        return false;
    }

    public mi0 j(nb nbVar) {
        return new fc(nbVar);
    }

    public String toString() {
        switch (this.e) {
            case 28:
                return "NeverEqualPolicy";
            default:
                return super.toString();
        }
    }
}