package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ar0  reason: default package */
public final class ar0 extends jr0 {
    public final float c;
    public final float d;
    public final float e;
    public final float f;
    public final float g;
    public final float h;

    public ar0(float f, float f2, float f3, float f4, float f5, float f6) {
        super(2);
        this.c = f;
        this.d = f2;
        this.e = f3;
        this.f = f4;
        this.g = f5;
        this.h = f6;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof ar0)) {
            return false;
        }
        ar0 ar0Var = (ar0) obj;
        if (Float.compare(this.c, ar0Var.c) == 0 && Float.compare(this.d, ar0Var.d) == 0 && Float.compare(this.e, ar0Var.e) == 0 && Float.compare(this.f, ar0Var.f) == 0 && Float.compare(this.g, ar0Var.g) == 0 && Float.compare(this.h, ar0Var.h) == 0) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        return Float.floatToIntBits(this.h) + fu0.z(this.g, fu0.z(this.f, fu0.z(this.e, fu0.z(this.d, Float.floatToIntBits(this.c) * 31, 31), 31), 31), 31);
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("RelativeCurveTo(dx1=");
        sb.append(this.c);
        sb.append(", dy1=");
        sb.append(this.d);
        sb.append(", dx2=");
        sb.append(this.e);
        sb.append(", dy2=");
        sb.append(this.f);
        sb.append(", dx3=");
        sb.append(this.g);
        sb.append(", dy3=");
        return fu0.F(sb, this.h, ')');
    }
}