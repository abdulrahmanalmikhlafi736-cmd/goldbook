package defpackage;

import android.database.ContentObserver;
import android.net.Uri;
import android.os.Handler;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bl1  reason: default package */
public final class bl1 extends ContentObserver {
    public final /* synthetic */ id a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public bl1(id idVar, Handler handler) {
        super(handler);
        this.a = idVar;
    }

    @Override // android.database.ContentObserver
    public final void onChange(boolean z, Uri uri) {
        this.a.s(we1.a);
    }
}