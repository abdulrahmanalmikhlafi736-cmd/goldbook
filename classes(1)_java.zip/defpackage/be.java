package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: be  reason: default package */
public final class be implements jp {
    public nd e;
    public pg0 f;

    @Override // defpackage.jp
    public final /* synthetic */ int F(float f) {
        return fu0.k(f, this);
    }

    @Override // defpackage.jp
    public final /* synthetic */ long K(long j) {
        return fu0.p(j, this);
    }

    @Override // defpackage.jp
    public final /* synthetic */ float N(long j) {
        return fu0.o(j, this);
    }

    @Override // defpackage.jp
    public final long V(float f) {
        return fu0.q(c0(f), this);
    }

    @Override // defpackage.jp
    public final float a() {
        return this.e.a().a();
    }

    @Override // defpackage.jp
    public final float b0(int i) {
        return i / a();
    }

    public final pg0 c(i00 i00Var) {
        pg0 pg0Var = new pg0(17, false);
        pg0Var.f = i00Var;
        this.f = pg0Var;
        return pg0Var;
    }

    @Override // defpackage.jp
    public final float c0(float f) {
        return f / a();
    }

    @Override // defpackage.jp
    public final float g() {
        return this.e.a().g();
    }

    @Override // defpackage.jp
    public final float q(float f) {
        return a() * f;
    }

    @Override // defpackage.jp
    public final /* synthetic */ float y(long j) {
        return fu0.m(j, this);
    }
}