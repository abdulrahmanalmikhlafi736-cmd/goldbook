package defpackage;

import android.content.Context;
import android.os.Parcelable;
import android.util.SparseArray;
import android.view.View;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ah1  reason: default package */
public final class ah1 extends q7 {
    public final View E;
    public final rl0 F;
    public lz0 G;
    public i00 H;
    public i00 I;
    public i00 J;

    /* JADX WARN: Illegal instructions before constructor call */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public ah1(Context context, i00 i00Var, b10 b10Var, mz0 mz0Var, int i, lp0 lp0Var) {
        super(context, b10Var, i, r4, r5, lp0Var);
        Object obj;
        View view = (View) i00Var.i(context);
        rl0 rl0Var = new rl0();
        this.E = view;
        this.F = rl0Var;
        setClipChildren(false);
        String valueOf = String.valueOf(i);
        if (mz0Var != null) {
            obj = mz0Var.f(valueOf);
        } else {
            obj = null;
        }
        SparseArray<Parcelable> sparseArray = obj instanceof SparseArray ? (SparseArray) obj : null;
        if (sparseArray != null) {
            view.restoreHierarchyState(sparseArray);
        }
        if (mz0Var != null) {
            setSavableRegistryEntry(mz0Var.a(valueOf, new p7(this, 2)));
        }
        i4 i4Var = i4.o;
        this.H = i4Var;
        this.I = i4Var;
        this.J = i4Var;
    }

    public static final void h(ah1 ah1Var) {
        ah1Var.setSavableRegistryEntry(null);
    }

    private final void setSavableRegistryEntry(lz0 lz0Var) {
        lz0 lz0Var2 = this.G;
        if (lz0Var2 != null) {
            ((k9) lz0Var2).F();
        }
        this.G = lz0Var;
    }

    public final rl0 getDispatcher() {
        return this.F;
    }

    public final i00 getReleaseBlock() {
        return this.J;
    }

    public final i00 getResetBlock() {
        return this.I;
    }

    public /* bridge */ /* synthetic */ o getSubCompositionView() {
        return null;
    }

    public final i00 getUpdateBlock() {
        return this.H;
    }

    public View getViewRoot() {
        return this;
    }

    public final void setReleaseBlock(i00 i00Var) {
        this.J = i00Var;
        setRelease(new p7(this, 3));
    }

    public final void setResetBlock(i00 i00Var) {
        this.I = i00Var;
        setReset(new p7(this, 4));
    }

    public final void setUpdateBlock(i00 i00Var) {
        this.H = i00Var;
        setUpdate(new p7(this, 5));
    }
}