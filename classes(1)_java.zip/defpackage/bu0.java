package defpackage;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Collections;
import java.util.Map;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bu0  reason: default package */
public final class bu0 extends l10 {
    private static final bu0 DEFAULT_INSTANCE;
    private static volatile oq0 PARSER = null;
    public static final int PREFERENCES_FIELD_NUMBER = 1;
    private yg0 preferences_ = yg0.f;

    static {
        bu0 bu0Var = new bu0();
        DEFAULT_INSTANCE = bu0Var;
        l10.j(bu0.class, bu0Var);
    }

    public static yg0 l(bu0 bu0Var) {
        yg0 yg0Var = bu0Var.preferences_;
        if (!yg0Var.e) {
            bu0Var.preferences_ = yg0Var.b();
        }
        return bu0Var.preferences_;
    }

    public static zt0 n() {
        return (zt0) ((j10) DEFAULT_INSTANCE.c(5));
    }

    public static bu0 o(FileInputStream fileInputStream) {
        bu0 bu0Var = DEFAULT_INSTANCE;
        ng ngVar = new ng(fileInputStream);
        yu a = yu.a();
        l10 i = bu0Var.i();
        try {
            jv0 jv0Var = jv0.c;
            jv0Var.getClass();
            q01 a2 = jv0Var.a(i.getClass());
            pg pgVar = (pg) ngVar.f;
            if (pgVar == null) {
                pgVar = new pg(ngVar);
            }
            a2.h(i, pgVar, a);
            a2.c(i);
            if (l10.f(i, true)) {
                return (bu0) i;
            }
            throw new IOException(new ue1().getMessage());
        } catch (s70 e) {
            if (e.e) {
                throw new IOException(e.getMessage(), e);
            }
            throw e;
        } catch (IOException e2) {
            if (e2.getCause() instanceof s70) {
                throw ((s70) e2.getCause());
            }
            throw new IOException(e2.getMessage(), e2);
        } catch (ue1 e3) {
            throw new IOException(e3.getMessage());
        } catch (RuntimeException e4) {
            if (e4.getCause() instanceof s70) {
                throw ((s70) e4.getCause());
            }
            throw e4;
        }
    }

    /* JADX WARN: Type inference failed for: r2v13, types: [java.lang.Object, oq0] */
    @Override // defpackage.l10
    public final Object c(int i) {
        oq0 oq0Var;
        switch (fu0.N(i)) {
            case 0:
                return (byte) 1;
            case 1:
                return null;
            case 2:
                return new rv0(DEFAULT_INSTANCE, "\u0001\u0001\u0000\u0000\u0001\u0001\u0001\u0001\u0000\u0000\u00012", new Object[]{"preferences_", au0.a});
            case 3:
                return new bu0();
            case gu0.LONG_FIELD_NUMBER /* 4 */:
                return new j10(DEFAULT_INSTANCE);
            case gu0.STRING_FIELD_NUMBER /* 5 */:
                return DEFAULT_INSTANCE;
            case gu0.STRING_SET_FIELD_NUMBER /* 6 */:
                oq0 oq0Var2 = PARSER;
                if (oq0Var2 == null) {
                    synchronized (bu0.class) {
                        try {
                            oq0 oq0Var3 = PARSER;
                            oq0Var = oq0Var3;
                            if (oq0Var3 == null) {
                                ?? obj = new Object();
                                PARSER = obj;
                                oq0Var = obj;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                    }
                    return oq0Var;
                }
                return oq0Var2;
            default:
                throw new UnsupportedOperationException();
        }
    }

    public final Map m() {
        return Collections.unmodifiableMap(this.preferences_);
    }
}