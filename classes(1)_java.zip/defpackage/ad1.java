package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ad1  reason: default package */
public final class ad1 {
    public final Object a;
    public final Object b;

    public ad1(Object obj, Object obj2) {
        this.a = obj;
        this.b = obj2;
    }

    public final boolean a(zt ztVar, zt ztVar2) {
        if (ztVar.equals(this.a) && ztVar2.equals(this.b)) {
            return true;
        }
        return false;
    }

    public final boolean equals(Object obj) {
        if (obj instanceof ad1) {
            ad1 ad1Var = (ad1) obj;
            if (k70.p(this.a, ad1Var.a) && k70.p(this.b, ad1Var.b)) {
                return true;
            }
            return false;
        }
        return false;
    }

    public final int hashCode() {
        int i;
        int i2 = 0;
        Object obj = this.a;
        if (obj != null) {
            i = obj.hashCode();
        } else {
            i = 0;
        }
        int i3 = i * 31;
        Object obj2 = this.b;
        if (obj2 != null) {
            i2 = obj2.hashCode();
        }
        return i3 + i2;
    }
}