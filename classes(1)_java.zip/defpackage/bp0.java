package defpackage;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bp0  reason: default package */
public final class bp0 {
    public static final bp0 e;
    public static final bp0 f;
    public static final /* synthetic */ bp0[] g;

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0, types: [bp0, java.lang.Enum] */
    /* JADX WARN: Type inference failed for: r1v1, types: [bp0, java.lang.Enum] */
    static {
        ?? r0 = new Enum("Vertical", 0);
        e = r0;
        ?? r1 = new Enum("Horizontal", 1);
        f = r1;
        g = new bp0[]{r0, r1};
    }

    public static bp0 valueOf(String str) {
        return (bp0) Enum.valueOf(bp0.class, str);
    }

    public static bp0[] values() {
        return (bp0[]) g.clone();
    }
}