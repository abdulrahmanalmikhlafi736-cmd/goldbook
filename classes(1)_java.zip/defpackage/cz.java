package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cz  reason: default package */
public final class cz extends q implements vl {
    @Override // defpackage.vl
    public final void n(sl slVar, Throwable th) {
    }
}