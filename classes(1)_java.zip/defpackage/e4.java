package defpackage;

import android.os.Build;
import android.view.View;
import android.view.contentcapture.ContentCaptureSession;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: e4  reason: default package */
public final /* synthetic */ class e4 extends w00 implements xz {
    public final /* synthetic */ int l;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ e4(int i, Object obj, Class cls, String str, String str2, int i2, int i3, int i4) {
        super(i, obj, cls, str, str2, i2, i3);
        this.l = i4;
    }

    @Override // defpackage.xz
    public final Object a() {
        ContentCaptureSession a;
        em0 em0Var;
        int i = this.l;
        Object obj = this.f;
        switch (i) {
            case 0:
                View view = (View) obj;
                int i2 = Build.VERSION.SDK_INT;
                if (i2 >= 30) {
                    g1.f(view);
                }
                if (i2 < 29 || (a = zk.a(view)) == null) {
                    return null;
                }
                return new al(0, a, view);
            case 1:
                cy cyVar = (cy) obj;
                ik0 ik0Var = cyVar.c;
                ik0 ik0Var2 = cyVar.d;
                hy hyVar = cyVar.a;
                ry f = hyVar.f();
                long j = -9187201950435737472L;
                if (f == null) {
                    Object[] objArr = ik0Var2.b;
                    long[] jArr = ik0Var2.a;
                    int length = jArr.length - 2;
                    if (length >= 0) {
                        int i3 = 0;
                        while (true) {
                            long j2 = jArr[i3];
                            if ((((~j2) << 7) & j2 & (-9187201950435737472L)) != -9187201950435737472L) {
                                int i4 = 8 - ((~(i3 - length)) >>> 31);
                                for (int i5 = 0; i5 < i4; i5++) {
                                    if ((j2 & 255) >= 128) {
                                        j2 >>= 8;
                                    } else {
                                        ((cb) objArr[(i3 << 3) + i5]).s0();
                                        throw null;
                                    }
                                }
                                if (i4 != 8) {
                                }
                            }
                            if (i3 != length) {
                                i3++;
                            }
                        }
                    }
                } else if (f.r) {
                    if (ik0Var.c(f)) {
                        f.x0();
                    }
                    f.w0();
                    if (!f.e.r) {
                        p50.b("visitAncestors called on an unattached node");
                    }
                    li0 li0Var = f.e;
                    ba0 O = k70.O(f);
                    int i6 = 0;
                    while (O != null) {
                        if ((O.J.f.h & 5120) != 0) {
                            while (li0Var != null) {
                                int i7 = li0Var.g;
                                if ((i7 & 5120) != 0) {
                                    if ((i7 & 1024) != 0) {
                                        i6++;
                                    }
                                    if ((li0Var instanceof cb) && ik0Var2.c(li0Var)) {
                                        if (i6 <= 1) {
                                            ((cb) li0Var).s0();
                                            throw null;
                                        }
                                        ((cb) li0Var).s0();
                                        throw null;
                                    }
                                }
                                li0Var = li0Var.i;
                            }
                        }
                        O = O.v();
                        if (O != null && (em0Var = O.J) != null) {
                            li0Var = em0Var.e;
                        } else {
                            li0Var = null;
                        }
                    }
                    Object[] objArr2 = ik0Var2.b;
                    long[] jArr2 = ik0Var2.a;
                    int length2 = jArr2.length - 2;
                    if (length2 >= 0) {
                        int i8 = 0;
                        while (true) {
                            long j3 = jArr2[i8];
                            long j4 = j;
                            if ((((~j3) << 7) & j3 & j4) != j4) {
                                int i9 = 8 - ((~(i8 - length2)) >>> 31);
                                for (int i10 = 0; i10 < i9; i10++) {
                                    if ((j3 & 255) >= 128) {
                                        j3 >>= 8;
                                    } else {
                                        ((cb) objArr2[(i8 << 3) + i10]).s0();
                                        throw null;
                                    }
                                }
                                if (i9 != 8) {
                                }
                            }
                            if (i8 != length2) {
                                i8++;
                                j = j4;
                            }
                        }
                    }
                }
                if (hyVar.f() == null || hyVar.c.w0() == my.g) {
                    hyVar.c();
                }
                ik0Var.b();
                ik0Var2.b();
                cyVar.e = false;
                return we1.a;
            default:
                return Boolean.valueOf(((vy) obj).z.y0(7));
        }
    }
}