package defpackage;

import android.app.Dialog;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.window.OnBackInvokedDispatcher;
import java.util.UUID;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: aq  reason: default package */
public final class aq extends Dialog implements sd0, kn0, el0, xz0 {
    public ud0 e;
    public final al f;
    public final da1 g;
    public final da1 h;
    public xz i;
    public yp j;
    public final View k;
    public final xp l;
    public boolean m;

    /* JADX WARN: Illegal instructions before constructor call */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public aq(xz xzVar, yp ypVar, View view, o90 o90Var, jp jpVar, UUID uuid) {
        super(new ContextThemeWrapper(r1, r2), 0);
        int i;
        Context context = view.getContext();
        if (ypVar.e) {
            i = 2131427328;
        } else {
            i = 2131427331;
        }
        this.f = new al(new wz0(this, new x1(13, this)), 20);
        this.g = new da1(new xz(this) { // from class: mi
            public final /* synthetic */ aq f;

            {
                this.f = this;
            }

            /* JADX WARN: Type inference failed for: r0v1, types: [java.lang.Object, hl0] */
            @Override // defpackage.xz
            public final Object a() {
                int i2 = r2;
                aq aqVar = this.f;
                switch (i2) {
                    case 0:
                        ?? obj = new Object();
                        aqVar.a().c(obj);
                        return obj;
                    default:
                        return new jn0(new o4(4, aqVar));
                }
            }
        });
        this.h = new da1(new xz(this) { // from class: mi
            public final /* synthetic */ aq f;

            {
                this.f = this;
            }

            /* JADX WARN: Type inference failed for: r0v1, types: [java.lang.Object, hl0] */
            @Override // defpackage.xz
            public final Object a() {
                int i2 = r2;
                aq aqVar = this.f;
                switch (i2) {
                    case 0:
                        ?? obj = new Object();
                        aqVar.a().c(obj);
                        return obj;
                    default:
                        return new jn0(new o4(4, aqVar));
                }
            }
        });
        this.i = xzVar;
        this.j = ypVar;
        this.k = view;
        Window window = getWindow();
        if (window != null) {
            window.requestFeature(1);
            window.setBackgroundDrawableResource(17170445);
            dd0.u(window, this.j.e);
            window.setGravity(17);
            if (!this.j.e) {
                window.addFlags(65792);
                WindowManager.LayoutParams attributes = window.getAttributes();
                int i2 = Build.VERSION.SDK_INT;
                if (i2 >= 28) {
                    c9.a.a(attributes);
                }
                if (i2 >= 30) {
                    d9 d9Var = d9.a;
                    d9Var.b(attributes, 0);
                    d9Var.c(attributes, 0);
                }
                window.setAttributes(attributes);
            }
            xp xpVar = new xp(getContext(), window);
            setTitle(this.j.f);
            xpVar.setTag(2131034163, "Dialog:" + uuid);
            xpVar.setClipChildren(false);
            xpVar.setElevation(jpVar.q(8.0f));
            xpVar.setOutlineProvider(new zp(0));
            this.l = xpVar;
            View decorView = window.getDecorView();
            ViewGroup viewGroup = decorView instanceof ViewGroup ? (ViewGroup) decorView : null;
            if (viewGroup != null) {
                e(viewGroup);
            }
            setContentView(xpVar);
            xpVar.setTag(2131034229, ua0.o(view));
            xpVar.setTag(2131034233, jb0.j(view));
            xpVar.setTag(2131034232, wa0.j(view));
            i(this.i, this.j, o90Var);
            jn0 b = b();
            l5 l5Var = new l5(this, 1);
            b.getClass();
            sa saVar = new sa(l5Var);
            final ud0 f = f();
            if (f.d == jd0.e) {
                return;
            }
            en0 en0Var = new en0(saVar, new fn0(saVar, this));
            saVar.a.add(en0Var);
            en0Var.g(false);
            p3.b(b.a(), en0Var);
            final to toVar = new to(en0Var, b, f);
            f.a(toVar);
            saVar.c.add(new AutoCloseable() { // from class: gn0
                @Override // java.lang.AutoCloseable
                public final void close() {
                    ud0.this.f(toVar);
                }
            });
            return;
        }
        od.p("Dialog has no window");
        throw null;
    }

    public static void d(aq aqVar) {
        super.onBackPressed();
    }

    public static final void e(ViewGroup viewGroup) {
        ViewGroup viewGroup2;
        viewGroup.setClipChildren(false);
        if (!(viewGroup instanceof xp)) {
            int childCount = viewGroup.getChildCount();
            for (int i = 0; i < childCount; i++) {
                View childAt = viewGroup.getChildAt(i);
                if (childAt instanceof ViewGroup) {
                    viewGroup2 = (ViewGroup) childAt;
                } else {
                    viewGroup2 = null;
                }
                if (viewGroup2 != null) {
                    e(viewGroup2);
                }
            }
        }
    }

    @Override // defpackage.el0
    public final p3 a() {
        return b().a();
    }

    @Override // android.app.Dialog
    public final void addContentView(View view, ViewGroup.LayoutParams layoutParams) {
        view.getClass();
        h();
        super.addContentView(view, layoutParams);
    }

    @Override // defpackage.kn0
    public final jn0 b() {
        return (jn0) this.h.getValue();
    }

    @Override // defpackage.xz0
    public final al c() {
        return (al) this.f.g;
    }

    @Override // android.app.Dialog, android.content.DialogInterface
    public final void cancel() {
    }

    public final ud0 f() {
        ud0 ud0Var = this.e;
        if (ud0Var == null) {
            ud0 ud0Var2 = new ud0(this, true);
            this.e = ud0Var2;
            return ud0Var2;
        }
        return ud0Var;
    }

    @Override // defpackage.sd0
    public final ud0 g() {
        return f();
    }

    public final void h() {
        Window window = getWindow();
        window.getClass();
        View decorView = window.getDecorView();
        decorView.getClass();
        decorView.setTag(2131034229, this);
        Window window2 = getWindow();
        window2.getClass();
        View decorView2 = window2.getDecorView();
        decorView2.getClass();
        decorView2.setTag(2131034231, this);
        Window window3 = getWindow();
        window3.getClass();
        View decorView3 = window3.getDecorView();
        decorView3.getClass();
        decorView3.setTag(2131034232, this);
        Window window4 = getWindow();
        window4.getClass();
        View decorView4 = window4.getDecorView();
        decorView4.getClass();
        decorView4.setTag(2131034230, this);
    }

    public final void i(xz xzVar, yp ypVar, o90 o90Var) {
        WindowManager.LayoutParams layoutParams;
        boolean z;
        int i;
        int i2;
        boolean z2;
        int i3;
        this.i = xzVar;
        this.j = ypVar;
        z11 z11Var = ypVar.c;
        int i4 = u6.a;
        ViewGroup.LayoutParams layoutParams2 = this.k.getRootView().getLayoutParams();
        if (layoutParams2 instanceof WindowManager.LayoutParams) {
            layoutParams = (WindowManager.LayoutParams) layoutParams2;
        } else {
            layoutParams = null;
        }
        int i5 = 0;
        if (layoutParams != null && (layoutParams.flags & 8192) != 0) {
            z = true;
        } else {
            z = false;
        }
        int ordinal = z11Var.ordinal();
        if (ordinal != 0) {
            if (ordinal != 1) {
                if (ordinal == 2) {
                    z = false;
                } else {
                    od.k();
                    return;
                }
            } else {
                z = true;
            }
        }
        Window window = getWindow();
        window.getClass();
        if (z) {
            i = 8192;
        } else {
            i = -8193;
        }
        window.setFlags(i, 8192);
        int ordinal2 = o90Var.ordinal();
        if (ordinal2 != 0) {
            if (ordinal2 == 1) {
                i2 = 1;
            } else {
                od.k();
                return;
            }
        } else {
            i2 = 0;
        }
        xp xpVar = this.l;
        xpVar.setLayoutDirection(i2);
        boolean z3 = ypVar.e;
        boolean z4 = ypVar.d;
        Window window2 = xpVar.n;
        if (xpVar.r && z4 == xpVar.p && z3 == xpVar.q) {
            z2 = false;
        } else {
            z2 = true;
        }
        xpVar.p = z4;
        xpVar.q = z3;
        if (z2) {
            WindowManager.LayoutParams attributes = window2.getAttributes();
            if (z4) {
                i3 = -2;
            } else {
                i3 = -1;
            }
            if (i3 != attributes.width || !xpVar.r) {
                window2.setLayout(i3, -2);
                xpVar.r = true;
            }
        }
        setCanceledOnTouchOutside(ypVar.b);
        Window window3 = getWindow();
        if (window3 != null) {
            if (!z3) {
                if (Build.VERSION.SDK_INT < 31) {
                    i5 = 16;
                } else {
                    i5 = 48;
                }
            }
            window3.setSoftInputMode(i5);
        }
    }

    @Override // android.app.Dialog
    public final void onBackPressed() {
        ((cq) this.g.getValue()).a();
    }

    @Override // android.app.Dialog
    public final void onCreate(Bundle bundle) {
        OnBackInvokedDispatcher onBackInvokedDispatcher;
        super.onCreate(bundle);
        if (Build.VERSION.SDK_INT >= 33) {
            jn0 b = b();
            onBackInvokedDispatcher = getOnBackInvokedDispatcher();
            onBackInvokedDispatcher.getClass();
            b.b(onBackInvokedDispatcher);
        }
        this.f.q(bundle);
        f().d(id0.ON_CREATE);
    }

    @Override // android.app.Dialog, android.view.KeyEvent.Callback
    public final boolean onKeyUp(int i, KeyEvent keyEvent) {
        if (this.j.a && keyEvent.isTracking() && !keyEvent.isCanceled() && i == 111) {
            this.i.a();
            return true;
        }
        return super.onKeyUp(i, keyEvent);
    }

    @Override // android.app.Dialog
    public final Bundle onSaveInstanceState() {
        Bundle onSaveInstanceState = super.onSaveInstanceState();
        onSaveInstanceState.getClass();
        this.f.r(onSaveInstanceState);
        return onSaveInstanceState;
    }

    @Override // android.app.Dialog
    public final void onStart() {
        super.onStart();
        f().d(id0.ON_RESUME);
    }

    @Override // android.app.Dialog
    public final void onStop() {
        f().d(id0.ON_DESTROY);
        this.e = null;
        super.onStop();
    }

    /* JADX WARN: Code restructure failed: missing block: B:16:0x0066, code lost:
        if (r5 <= r1) goto L29;
     */
    @Override // android.app.Dialog
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        View childAt;
        boolean onTouchEvent = super.onTouchEvent(motionEvent);
        if (this.j.b) {
            xp xpVar = this.l;
            xpVar.getClass();
            if (Math.abs(motionEvent.getX()) <= Float.MAX_VALUE && Math.abs(motionEvent.getY()) <= Float.MAX_VALUE && (childAt = xpVar.getChildAt(0)) != null) {
                int left = childAt.getLeft() + xpVar.getLeft();
                int width = childAt.getWidth() + left;
                int top = childAt.getTop() + xpVar.getTop();
                int height = childAt.getHeight() + top;
                int P = gh0.P(motionEvent.getX());
                if (left <= P) {
                    if (P <= width) {
                        int P2 = gh0.P(motionEvent.getY());
                        if (top <= P2) {
                        }
                    }
                }
            }
            int actionMasked = motionEvent.getActionMasked();
            if (actionMasked != 0) {
                if (actionMasked != 1) {
                    if (actionMasked == 3) {
                        this.m = false;
                        return onTouchEvent;
                    }
                } else if (this.m) {
                    this.i.a();
                    this.m = false;
                    return true;
                }
                return onTouchEvent;
            }
            this.m = true;
            return true;
        }
        int actionMasked2 = motionEvent.getActionMasked();
        if (actionMasked2 == 0 || actionMasked2 == 1 || actionMasked2 == 3) {
            this.m = false;
            return onTouchEvent;
        }
        return onTouchEvent;
    }

    @Override // android.app.Dialog
    public final void setContentView(View view) {
        view.getClass();
        h();
        super.setContentView(view);
    }

    @Override // android.app.Dialog
    public final void setContentView(int i) {
        h();
        super.setContentView(i);
    }

    @Override // android.app.Dialog
    public final void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        view.getClass();
        h();
        super.setContentView(view, layoutParams);
    }
}