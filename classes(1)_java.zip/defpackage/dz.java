package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dz  reason: default package */
public final class dz {
    public static final cz a = new q(e3.C);
}