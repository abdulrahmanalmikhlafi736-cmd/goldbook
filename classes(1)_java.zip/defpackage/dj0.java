package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dj0  reason: default package */
public final class dj0 extends nl {
    public tp h;
    public nw0 i;
    public kw0 j;
    public y11 k;
    public nw0 l;
    public /* synthetic */ Object m;
    public int n;

    @Override // defpackage.db
    public final Object p(Object obj) {
        this.m = obj;
        this.n |= Integer.MIN_VALUE;
        return tp.b(null, null, null, null, null, 0L, this);
    }
}