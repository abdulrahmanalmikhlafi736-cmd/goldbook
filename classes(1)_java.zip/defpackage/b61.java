package defpackage;

import java.util.Arrays;
import java.util.Collection;
import java.util.ListIterator;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: b61  reason: default package */
public final class b61 extends c0 {
    public static final b61 f = new b61(new Object[0]);
    public final Object[] e;

    public b61(Object[] objArr) {
        this.e = objArr;
    }

    @Override // defpackage.m
    public final int a() {
        return this.e.length;
    }

    @Override // defpackage.c0
    public final c0 b(int i, Object obj) {
        Object[] objArr = this.e;
        kb0.g(i, objArr.length);
        if (i == objArr.length) {
            return c(obj);
        }
        if (objArr.length < 32) {
            Object[] objArr2 = new Object[objArr.length + 1];
            ba.a0(objArr, objArr2, 0, i, 6);
            ba.Y(objArr, objArr2, i + 1, i, objArr.length);
            objArr2[i] = obj;
            return new b61(objArr2);
        }
        Object[] copyOf = Arrays.copyOf(objArr, objArr.length);
        ba.Y(objArr, copyOf, i + 1, i, objArr.length - 1);
        copyOf[i] = obj;
        Object[] objArr3 = new Object[32];
        objArr3[0] = objArr[31];
        return new ds0(copyOf, objArr3, objArr.length + 1, 0);
    }

    @Override // defpackage.c0
    public final c0 c(Object obj) {
        Object[] objArr = this.e;
        if (objArr.length < 32) {
            Object[] copyOf = Arrays.copyOf(objArr, objArr.length + 1);
            copyOf[objArr.length] = obj;
            return new b61(copyOf);
        }
        Object[] objArr2 = new Object[32];
        objArr2[0] = obj;
        return new ds0(objArr, objArr2, objArr.length + 1, 0);
    }

    @Override // defpackage.c0
    public final c0 e(Collection collection) {
        Object[] objArr = this.e;
        if (collection.size() + objArr.length <= 32) {
            Object[] copyOf = Arrays.copyOf(objArr, collection.size() + objArr.length);
            int length = objArr.length;
            for (Object obj : collection) {
                copyOf[length] = obj;
                length++;
            }
            return new b61(copyOf);
        }
        es0 f2 = f();
        f2.addAll(collection);
        return f2.c();
    }

    @Override // defpackage.c0
    public final es0 f() {
        return new es0(this, null, this.e, 0);
    }

    @Override // defpackage.c0
    public final c0 g(b0 b0Var) {
        Object[] objArr = this.e;
        int length = objArr.length;
        int length2 = objArr.length;
        Object[] objArr2 = objArr;
        boolean z = false;
        for (int i = 0; i < length2; i++) {
            Object obj = objArr[i];
            if (((Boolean) b0Var.i(obj)).booleanValue()) {
                if (!z) {
                    objArr2 = Arrays.copyOf(objArr, objArr.length);
                    z = true;
                    length = i;
                }
            } else if (z) {
                objArr2[length] = obj;
                length++;
            }
        }
        if (length == objArr.length) {
            return this;
        }
        if (length == 0) {
            return f;
        }
        return new b61(ba.b0(objArr2, 0, length));
    }

    @Override // java.util.List
    public final Object get(int i) {
        Object[] objArr = this.e;
        kb0.f(i, objArr.length);
        return objArr[i];
    }

    @Override // defpackage.c0
    public final c0 h(int i) {
        Object[] objArr = this.e;
        kb0.f(i, objArr.length);
        if (objArr.length == 1) {
            return f;
        }
        Object[] copyOf = Arrays.copyOf(objArr, objArr.length - 1);
        ba.Y(objArr, copyOf, i, i + 1, objArr.length);
        return new b61(copyOf);
    }

    @Override // defpackage.c0
    public final c0 i(int i, Object obj) {
        Object[] objArr = this.e;
        kb0.f(i, objArr.length);
        Object[] copyOf = Arrays.copyOf(objArr, objArr.length);
        copyOf[i] = obj;
        return new b61(copyOf);
    }

    @Override // defpackage.v, java.util.List
    public final int indexOf(Object obj) {
        return ba.f0(this.e, obj);
    }

    @Override // defpackage.v, java.util.List
    public final int lastIndexOf(Object obj) {
        Object[] objArr = this.e;
        if (obj == null) {
            int length = objArr.length - 1;
            if (length >= 0) {
                while (true) {
                    int i = length - 1;
                    if (objArr[length] == null) {
                        return length;
                    }
                    if (i < 0) {
                        break;
                    }
                    length = i;
                }
            }
        } else {
            int length2 = objArr.length - 1;
            if (length2 >= 0) {
                while (true) {
                    int i2 = length2 - 1;
                    if (obj.equals(objArr[length2])) {
                        return length2;
                    }
                    if (i2 < 0) {
                        break;
                    }
                    length2 = i2;
                }
            }
        }
        return -1;
    }

    @Override // defpackage.v, java.util.List
    public final ListIterator listIterator(int i) {
        Object[] objArr = this.e;
        kb0.g(i, objArr.length);
        return new fd(objArr, i, objArr.length);
    }
}