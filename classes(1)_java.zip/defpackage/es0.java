package defpackage;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.ListIterator;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: es0  reason: default package */
public final class es0 extends z implements Collection, w80 {
    public c0 e;
    public Object[] f;
    public Object[] g;
    public int h;
    public vj i = new vj(20);
    public Object[] j;
    public Object[] k;
    public int l;

    public es0(c0 c0Var, Object[] objArr, Object[] objArr2, int i) {
        this.e = c0Var;
        this.f = objArr;
        this.g = objArr2;
        this.h = i;
        this.j = objArr;
        this.k = objArr2;
        this.l = c0Var.a();
    }

    public static void e(Object[] objArr, int i, Iterator it) {
        while (i < 32 && it.hasNext()) {
            objArr[i] = it.next();
            i++;
        }
    }

    public final Object[] A(Object[] objArr, int i, int i2, k1 k1Var) {
        int q = ua0.q(i2, i);
        int i3 = 31;
        if (i == 0) {
            Object obj = objArr[q];
            Object[] l = l(objArr);
            ba.Y(objArr, l, q, q + 1, 32);
            l[31] = k1Var.a;
            k1Var.a = obj;
            return l;
        }
        if (objArr[31] == null) {
            i3 = ua0.q(C() - 1, i);
        }
        Object[] l2 = l(objArr);
        int i4 = i - 5;
        int i5 = q + 1;
        if (i5 <= i3) {
            while (true) {
                Object obj2 = l2[i3];
                obj2.getClass();
                l2[i3] = A((Object[]) obj2, i4, 0, k1Var);
                if (i3 == i5) {
                    break;
                }
                i3--;
            }
        }
        Object obj3 = l2[q];
        obj3.getClass();
        l2[q] = A((Object[]) obj3, i4, i2, k1Var);
        return l2;
    }

    public final Object B(Object[] objArr, int i, int i2, int i3) {
        int i4 = this.l - i;
        Object[] objArr2 = this.k;
        if (i4 == 1) {
            Object obj = objArr2[0];
            r(objArr, i, i2);
            return obj;
        }
        Object obj2 = objArr2[i3];
        Object[] l = l(objArr2);
        ba.Y(objArr2, l, i3, i3 + 1, i4);
        l[i4 - 1] = null;
        this.j = objArr;
        this.k = l;
        this.l = (i + i4) - 1;
        this.h = i2;
        return obj2;
    }

    public final int C() {
        int i = this.l;
        if (i <= 32) {
            return 0;
        }
        return (i - 1) & (-32);
    }

    public final Object[] D(Object[] objArr, int i, int i2, Object obj, k1 k1Var) {
        int q = ua0.q(i2, i);
        Object[] l = l(objArr);
        if (i == 0) {
            if (l != objArr) {
                ((AbstractList) this).modCount++;
            }
            k1Var.a = l[q];
            l[q] = obj;
            return l;
        }
        Object obj2 = l[q];
        obj2.getClass();
        l[q] = D((Object[]) obj2, i - 5, i2, obj, k1Var);
        return l;
    }

    public final void E(Collection collection, int i, Object[] objArr, int i2, Object[][] objArr2, int i3, Object[] objArr3) {
        Object[] n;
        if (i3 < 1) {
            rt0.a("requires at least one nullBuffer");
        }
        Object[] l = l(objArr);
        objArr2[0] = l;
        int i4 = i & 31;
        int size = ((collection.size() + i) - 1) & 31;
        int i5 = (i2 - i4) + size;
        if (i5 < 32) {
            ba.Y(l, objArr3, size + 1, i4, i2);
        } else {
            int i6 = i5 - 31;
            if (i3 == 1) {
                n = l;
            } else {
                n = n();
                i3--;
                objArr2[i3] = n;
            }
            int i7 = i2 - i6;
            ba.Y(l, objArr3, 0, i7, i2);
            ba.Y(l, n, size + 1, i4, i7);
            objArr3 = n;
        }
        Iterator it = collection.iterator();
        e(l, i4, it);
        for (int i8 = 1; i8 < i3; i8++) {
            Object[] n2 = n();
            e(n2, 0, it);
            objArr2[i8] = n2;
        }
        e(objArr3, 0, it);
    }

    public final int F() {
        int i = this.l;
        if (i <= 32) {
            return i;
        }
        return i - ((i - 1) & (-32));
    }

    @Override // defpackage.z
    public final int a() {
        return this.l;
    }

    @Override // java.util.AbstractList, java.util.List
    public final void add(int i, Object obj) {
        kb0.g(i, a());
        if (i == a()) {
            add(obj);
            return;
        }
        ((AbstractList) this).modCount++;
        int C = C();
        if (i >= C) {
            i(this.j, i - C, obj);
            return;
        }
        k1 k1Var = new k1(null);
        Object[] objArr = this.j;
        objArr.getClass();
        i(h(objArr, this.h, i, obj, k1Var), 0, k1Var.a);
    }

    @Override // java.util.AbstractList, java.util.List
    public final boolean addAll(int i, Collection collection) {
        Collection collection2;
        Object[] n;
        kb0.g(i, this.l);
        if (i == this.l) {
            return addAll(collection);
        }
        if (collection.isEmpty()) {
            return false;
        }
        ((AbstractList) this).modCount++;
        int i2 = (i >> 5) << 5;
        int size = ((collection.size() + (this.l - i2)) - 1) / 32;
        if (size == 0) {
            int i3 = i & 31;
            int size2 = ((collection.size() + i) - 1) & 31;
            Object[] objArr = this.k;
            Object[] l = l(objArr);
            ba.Y(objArr, l, size2 + 1, i3, F());
            e(l, i3, collection.iterator());
            this.k = l;
            this.l = collection.size() + this.l;
            return true;
        }
        Object[][] objArr2 = new Object[size];
        int F = F();
        int size3 = collection.size() + this.l;
        if (size3 > 32) {
            size3 -= (size3 - 1) & (-32);
        }
        if (i >= C()) {
            n = n();
            collection2 = collection;
            E(collection2, i, this.k, F, objArr2, size, n);
            objArr2 = objArr2;
        } else {
            collection2 = collection;
            Object[] objArr3 = this.k;
            if (size3 > F) {
                int i4 = size3 - F;
                Object[] m = m(i4, objArr3);
                g(collection2, i, i4, objArr2, size, m);
                objArr2 = objArr2;
                n = m;
            } else {
                n = n();
                int i5 = F - size3;
                ba.Y(objArr3, n, 0, i5, F);
                int i6 = 32 - i5;
                Object[] m2 = m(i6, this.k);
                int i7 = size - 1;
                objArr2[i7] = m2;
                g(collection2, i, i6, objArr2, i7, m2);
                collection2 = collection2;
            }
        }
        this.j = t(this.j, i2, objArr2);
        this.k = n;
        this.l = collection2.size() + this.l;
        return true;
    }

    @Override // defpackage.z
    public final Object b(int i) {
        kb0.f(i, a());
        ((AbstractList) this).modCount++;
        int C = C();
        if (i >= C) {
            return B(this.j, C, this.h, i - C);
        }
        k1 k1Var = new k1(this.k[0]);
        Object[] objArr = this.j;
        objArr.getClass();
        B(A(objArr, this.h, i, k1Var), C, this.h, 0);
        return k1Var.a;
    }

    public final c0 c() {
        c0 ds0Var;
        Object[] objArr = this.j;
        if (objArr == this.f && this.k == this.g) {
            ds0Var = this.e;
        } else {
            this.i = new vj(20);
            this.f = objArr;
            Object[] objArr2 = this.k;
            this.g = objArr2;
            if (objArr == null) {
                if (objArr2.length == 0) {
                    ds0Var = b61.f;
                } else {
                    ds0Var = new b61(Arrays.copyOf(objArr2, this.l));
                }
            } else {
                ds0Var = new ds0(objArr, objArr2, this.l, this.h);
            }
        }
        this.e = ds0Var;
        return ds0Var;
    }

    public final int f() {
        return ((AbstractList) this).modCount;
    }

    public final void g(Collection collection, int i, int i2, Object[][] objArr, int i3, Object[] objArr2) {
        if (this.j != null) {
            int i4 = i >> 5;
            w k = k(C() >> 5);
            int i5 = i3;
            Object[] objArr3 = objArr2;
            while (k.e - 1 != i4) {
                Object[] objArr4 = (Object[]) k.previous();
                ba.Y(objArr4, objArr3, 0, 32 - i2, 32);
                objArr3 = m(i2, objArr4);
                i5--;
                objArr[i5] = objArr3;
            }
            Object[] objArr5 = (Object[]) k.previous();
            int C = i3 - (((C() >> 5) - 1) - i4);
            if (C < i3) {
                objArr2 = objArr[C];
                objArr2.getClass();
            }
            E(collection, i, objArr5, 32, objArr, C, objArr2);
            return;
        }
        od.p("root is null");
    }

    @Override // java.util.AbstractList, java.util.List
    public final Object get(int i) {
        Object[] objArr;
        kb0.f(i, a());
        if (C() <= i) {
            objArr = this.k;
        } else {
            Object[] objArr2 = this.j;
            objArr2.getClass();
            for (int i2 = this.h; i2 > 0; i2 -= 5) {
                Object[] objArr3 = objArr2[ua0.q(i, i2)];
                objArr3.getClass();
                objArr2 = objArr3;
            }
            objArr = objArr2;
        }
        return objArr[i & 31];
    }

    public final Object[] h(Object[] objArr, int i, int i2, Object obj, k1 k1Var) {
        Object obj2;
        int q = ua0.q(i2, i);
        if (i == 0) {
            k1Var.a = objArr[31];
            Object[] l = l(objArr);
            ba.Y(objArr, l, q + 1, q, 31);
            l[q] = obj;
            return l;
        }
        Object[] l2 = l(objArr);
        int i3 = i - 5;
        Object obj3 = l2[q];
        obj3.getClass();
        l2[q] = h((Object[]) obj3, i3, i2, obj, k1Var);
        while (true) {
            q++;
            if (q >= 32 || (obj2 = l2[q]) == null) {
                break;
            }
            l2[q] = h((Object[]) obj2, i3, 0, k1Var.a, k1Var);
        }
        return l2;
    }

    public final void i(Object[] objArr, int i, Object obj) {
        int F = F();
        Object[] l = l(this.k);
        Object[] objArr2 = this.k;
        if (F < 32) {
            ba.Y(objArr2, l, i + 1, i, F);
            l[i] = obj;
            this.j = objArr;
            this.k = l;
            this.l++;
            return;
        }
        Object obj2 = objArr2[31];
        ba.Y(objArr2, l, i + 1, i, 31);
        l[i] = obj;
        u(objArr, l, o(obj2));
    }

    @Override // java.util.AbstractList, java.util.AbstractCollection, java.util.Collection, java.lang.Iterable, java.util.List
    public final Iterator iterator() {
        return listIterator(0);
    }

    public final boolean j(Object[] objArr) {
        if (objArr.length == 33 && objArr[32] == this.i) {
            return true;
        }
        return false;
    }

    public final w k(int i) {
        Object[] objArr = this.j;
        if (objArr != null) {
            int C = C() >> 5;
            kb0.g(i, C);
            int i2 = this.h;
            if (i2 == 0) {
                return new fd(i, objArr);
            }
            return new nd1(objArr, i, C, i2 / 5);
        }
        od.p("Invalid root");
        return null;
    }

    public final Object[] l(Object[] objArr) {
        if (objArr == null) {
            return n();
        }
        if (j(objArr)) {
            return objArr;
        }
        Object[] n = n();
        int length = objArr.length;
        if (length > 32) {
            length = 32;
        }
        ba.a0(objArr, n, 0, length, 6);
        return n;
    }

    @Override // java.util.AbstractList, java.util.List
    public final ListIterator listIterator(int i) {
        kb0.g(i, this.l);
        return new gs0(this, i);
    }

    public final Object[] m(int i, Object[] objArr) {
        if (j(objArr)) {
            ba.Y(objArr, objArr, i, 0, 32 - i);
            return objArr;
        }
        Object[] n = n();
        ba.Y(objArr, n, i, 0, 32 - i);
        return n;
    }

    public final Object[] n() {
        Object[] objArr = new Object[33];
        objArr[32] = this.i;
        return objArr;
    }

    public final Object[] o(Object obj) {
        Object[] objArr = new Object[33];
        objArr[0] = obj;
        objArr[32] = this.i;
        return objArr;
    }

    public final Object[] p(Object[] objArr, int i, int i2) {
        if (i2 < 0) {
            rt0.a("shift should be positive");
        }
        if (i2 == 0) {
            return objArr;
        }
        int q = ua0.q(i, i2);
        Object obj = objArr[q];
        obj.getClass();
        Object p = p((Object[]) obj, i, i2 - 5);
        if (q < 31) {
            int i3 = q + 1;
            if (objArr[i3] != null) {
                if (j(objArr)) {
                    Arrays.fill(objArr, i3, 32, (Object) null);
                }
                Object[] n = n();
                ba.Y(objArr, n, 0, 0, i3);
                objArr = n;
            }
        }
        if (p != objArr[q]) {
            Object[] l = l(objArr);
            l[q] = p;
            return l;
        }
        return objArr;
    }

    public final Object[] q(Object[] objArr, int i, int i2, k1 k1Var) {
        Object[] q;
        int q2 = ua0.q(i2 - 1, i);
        if (i == 5) {
            k1Var.a = objArr[q2];
            q = null;
        } else {
            Object obj = objArr[q2];
            obj.getClass();
            q = q((Object[]) obj, i - 5, i2, k1Var);
        }
        if (q == null && q2 == 0) {
            return null;
        }
        Object[] l = l(objArr);
        l[q2] = q;
        return l;
    }

    public final void r(Object[] objArr, int i, int i2) {
        if (i2 == 0) {
            this.j = null;
            if (objArr == null) {
                objArr = new Object[0];
            }
            this.k = objArr;
            this.l = i;
            this.h = i2;
            return;
        }
        k1 k1Var = new k1(null);
        objArr.getClass();
        Object[] q = q(objArr, i2, i, k1Var);
        q.getClass();
        Object obj = k1Var.a;
        obj.getClass();
        this.k = (Object[]) obj;
        this.l = i;
        if (q[1] == null) {
            this.j = (Object[]) q[0];
            this.h = i2 - 5;
            return;
        }
        this.j = q;
        this.h = i2;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final boolean removeAll(Collection collection) {
        return z(new b0(1, collection));
    }

    public final Object[] s(Object[] objArr, int i, int i2, Iterator it) {
        boolean z;
        if (!it.hasNext()) {
            rt0.a("invalid buffersIterator");
        }
        if (i2 >= 0) {
            z = true;
        } else {
            z = false;
        }
        if (!z) {
            rt0.a("negative shift");
        }
        if (i2 == 0) {
            return (Object[]) it.next();
        }
        Object[] l = l(objArr);
        int q = ua0.q(i, i2);
        int i3 = i2 - 5;
        l[q] = s((Object[]) l[q], i, i3, it);
        while (true) {
            q++;
            if (q >= 32 || !it.hasNext()) {
                break;
            }
            l[q] = s((Object[]) l[q], 0, i3, it);
        }
        return l;
    }

    @Override // java.util.AbstractList, java.util.List
    public final Object set(int i, Object obj) {
        kb0.f(i, a());
        if (C() <= i) {
            Object[] l = l(this.k);
            if (l != this.k) {
                ((AbstractList) this).modCount++;
            }
            int i2 = i & 31;
            Object obj2 = l[i2];
            l[i2] = obj;
            this.k = l;
            return obj2;
        }
        k1 k1Var = new k1(null);
        Object[] objArr = this.j;
        objArr.getClass();
        this.j = D(objArr, this.h, i, obj, k1Var);
        return k1Var.a;
    }

    public final Object[] t(Object[] objArr, int i, Object[][] objArr2) {
        Object[] l;
        Iterator sVar = new s(objArr2);
        int i2 = i >> 5;
        int i3 = this.h;
        if (i2 < (1 << i3)) {
            l = s(objArr, i, i3, sVar);
        } else {
            l = l(objArr);
        }
        while (sVar.hasNext()) {
            this.h += 5;
            l = o(l);
            int i4 = this.h;
            s(l, 1 << i4, i4, sVar);
        }
        return l;
    }

    public final void u(Object[] objArr, Object[] objArr2, Object[] objArr3) {
        int i = this.l;
        int i2 = i >> 5;
        int i3 = this.h;
        if (i2 > (1 << i3)) {
            this.j = v(this.h + 5, o(objArr), objArr2);
            this.k = objArr3;
            this.h += 5;
            this.l++;
        } else if (objArr == null) {
            this.j = objArr2;
            this.k = objArr3;
            this.l = i + 1;
        } else {
            this.j = v(i3, objArr, objArr2);
            this.k = objArr3;
            this.l++;
        }
    }

    public final Object[] v(int i, Object[] objArr, Object[] objArr2) {
        int q = ua0.q(a() - 1, i);
        Object[] l = l(objArr);
        if (i == 5) {
            l[q] = objArr2;
            return l;
        }
        l[q] = v(i - 5, (Object[]) l[q], objArr2);
        return l;
    }

    public final int w(i00 i00Var, Object[] objArr, int i, int i2, k1 k1Var, ArrayList arrayList, ArrayList arrayList2) {
        Object[] n;
        if (j(objArr)) {
            arrayList.add(objArr);
        }
        Object obj = k1Var.a;
        obj.getClass();
        Object[] objArr2 = (Object[]) obj;
        Object[] objArr3 = objArr2;
        for (int i3 = 0; i3 < i; i3++) {
            Object obj2 = objArr[i3];
            if (!((Boolean) i00Var.i(obj2)).booleanValue()) {
                if (i2 == 32) {
                    if (!arrayList.isEmpty()) {
                        n = (Object[]) arrayList.remove(arrayList.size() - 1);
                    } else {
                        n = n();
                    }
                    objArr3 = n;
                    i2 = 0;
                }
                objArr3[i2] = obj2;
                i2++;
            }
        }
        k1Var.a = objArr3;
        if (objArr2 != objArr3) {
            arrayList2.add(objArr2);
        }
        return i2;
    }

    public final int x(i00 i00Var, Object[] objArr, int i, k1 k1Var) {
        Object[] objArr2 = objArr;
        int i2 = i;
        boolean z = false;
        for (int i3 = 0; i3 < i; i3++) {
            Object obj = objArr[i3];
            if (((Boolean) i00Var.i(obj)).booleanValue()) {
                if (!z) {
                    objArr2 = l(objArr);
                    z = true;
                    i2 = i3;
                }
            } else if (z) {
                objArr2[i2] = obj;
                i2++;
            }
        }
        k1Var.a = objArr2;
        return i2;
    }

    public final int y(i00 i00Var, int i, k1 k1Var) {
        int x = x(i00Var, this.k, i, k1Var);
        Object obj = k1Var.a;
        if (x == i) {
            return i;
        }
        obj.getClass();
        Object[] objArr = (Object[]) obj;
        Arrays.fill(objArr, x, i, (Object) null);
        this.k = objArr;
        this.l -= i - x;
        return x;
    }

    /* JADX WARN: Code restructure failed: missing block: B:16:0x0046, code lost:
        if (r0 != r8) goto L5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x0016, code lost:
        if (y(r1, r8, r5) != r8) goto L5;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean z(i00 i00Var) {
        int i;
        i00 i00Var2 = i00Var;
        int F = F();
        Object[] objArr = null;
        k1 k1Var = new k1(null);
        boolean z = false;
        if (this.j != null) {
            w k = k(0);
            int i2 = 32;
            while (i2 == 32 && k.hasNext()) {
                i2 = x(i00Var2, (Object[]) k.next(), 32, k1Var);
            }
            if (i2 == 32) {
                int y = y(i00Var2, F, k1Var);
                if (y == 0) {
                    r(this.j, this.l, this.h);
                }
            } else {
                int i3 = (k.e - 1) << 5;
                ArrayList arrayList = new ArrayList();
                ArrayList arrayList2 = new ArrayList();
                int i4 = i2;
                while (k.hasNext()) {
                    i4 = w(i00Var2, (Object[]) k.next(), 32, i4, k1Var, arrayList2, arrayList);
                    i00Var2 = i00Var;
                }
                int w = w(i00Var, this.k, F, i4, k1Var, arrayList2, arrayList);
                Object obj = k1Var.a;
                obj.getClass();
                Object[] objArr2 = (Object[]) obj;
                Arrays.fill(objArr2, w, 32, (Object) null);
                boolean isEmpty = arrayList.isEmpty();
                Object[] objArr3 = this.j;
                if (isEmpty) {
                    objArr3.getClass();
                } else {
                    objArr3 = s(objArr3, i3, this.h, arrayList.iterator());
                }
                int size = i3 + (arrayList.size() << 5);
                if ((size & 31) != 0) {
                    rt0.a("invalid size");
                }
                if (size == 0) {
                    this.h = 0;
                } else {
                    int i5 = size - 1;
                    while (true) {
                        i = this.h;
                        if ((i5 >> i) != 0) {
                            break;
                        }
                        this.h = i - 5;
                        Object[] objArr4 = objArr3[0];
                        objArr4.getClass();
                        objArr3 = objArr4;
                    }
                    objArr = p(objArr3, i5, i);
                }
                this.j = objArr;
                this.k = objArr2;
                this.l = size + w;
            }
            z = true;
        }
        if (z) {
            ((AbstractList) this).modCount++;
        }
        return z;
    }

    @Override // java.util.AbstractList, java.util.List
    public final ListIterator listIterator() {
        return listIterator(0);
    }

    @Override // java.util.AbstractList, java.util.AbstractCollection, java.util.Collection, java.util.List
    public final boolean add(Object obj) {
        ((AbstractList) this).modCount++;
        int F = F();
        if (F < 32) {
            Object[] l = l(this.k);
            l[F] = obj;
            this.k = l;
            this.l = a() + 1;
        } else {
            u(this.j, this.k, o(obj));
        }
        return true;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final boolean addAll(Collection collection) {
        if (collection.isEmpty()) {
            return false;
        }
        ((AbstractList) this).modCount++;
        int F = F();
        Iterator it = collection.iterator();
        if (32 - F >= collection.size()) {
            Object[] l = l(this.k);
            e(l, F, it);
            this.k = l;
            this.l = collection.size() + this.l;
            return true;
        }
        int size = ((collection.size() + F) - 1) / 32;
        Object[][] objArr = new Object[size];
        Object[] l2 = l(this.k);
        e(l2, F, it);
        objArr[0] = l2;
        for (int i = 1; i < size; i++) {
            Object[] n = n();
            e(n, 0, it);
            objArr[i] = n;
        }
        this.j = t(this.j, C(), objArr);
        Object[] n2 = n();
        e(n2, 0, it);
        this.k = n2;
        this.l = collection.size() + this.l;
        return true;
    }
}