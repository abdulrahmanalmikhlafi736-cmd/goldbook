package defpackage;

/* renamed from: d41  reason: default package */
public final class d41 extends nl {
    public /* synthetic */ Object h;
    public int i;
    public final /* synthetic */ gn j;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public d41(gn gnVar, ml mlVar) {
        super(mlVar);
        this.j = gnVar;
    }

    @Override // defpackage.db
    public final Object p(Object obj) {
        this.h = obj;
        this.i |= Integer.MIN_VALUE;
        return this.j.k(null, this);
    }
}