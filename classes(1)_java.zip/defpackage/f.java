package defpackage;

import java.util.ArrayList;
import java.util.concurrent.CancellationException;
import java.util.concurrent.atomic.AtomicInteger;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: f  reason: default package */
public final class f extends u91 implements m00 {
    public final /* synthetic */ int i;
    public int j;
    public Object k;
    public Object l;
    public final /* synthetic */ Object m;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public f(uj0 uj0Var, nw nwVar, ml mlVar) {
        super(2, mlVar);
        this.i = 8;
        this.k = uj0Var;
        this.m = nwVar;
    }

    @Override // defpackage.m00
    public final Object f(Object obj, Object obj2) {
        int i = this.i;
        we1 we1Var = we1.a;
        switch (i) {
            case 0:
                return ((f) n((ml) obj2, (bm) obj)).p(we1Var);
            case 1:
                return ((f) n((ml) obj2, (xu0) obj)).p(we1Var);
            case 2:
                return ((f) n((ml) obj2, (bm) obj)).p(we1Var);
            case 3:
                return ((f) n((ml) obj2, (bm) obj)).p(we1Var);
            case gu0.LONG_FIELD_NUMBER /* 4 */:
                return ((f) n((ml) obj2, (uw) obj)).p(we1Var);
            case gu0.STRING_FIELD_NUMBER /* 5 */:
                return ((f) n((ml) obj2, (bm) obj)).p(we1Var);
            case gu0.STRING_SET_FIELD_NUMBER /* 6 */:
                return ((f) n((ml) obj2, (a11) obj)).p(we1Var);
            case gu0.DOUBLE_FIELD_NUMBER /* 7 */:
                return ((f) n((ml) obj2, (bm) obj)).p(we1Var);
            case 8:
                return ((f) n((ml) obj2, (bm) obj)).p(we1Var);
            case 9:
                return ((f) n((ml) obj2, (bm) obj)).p(we1Var);
            case 10:
                return ((f) n((ml) obj2, (bm) obj)).p(we1Var);
            case 11:
                return ((f) n((ml) obj2, (bm) obj)).p(we1Var);
            case 12:
                return ((f) n((ml) obj2, (w11) obj)).p(we1Var);
            case 13:
                return ((f) n((ml) obj2, (a11) obj)).p(we1Var);
            case 14:
                return ((f) n((ml) obj2, (xu0) obj)).p(we1Var);
            default:
                return ((f) n((ml) obj2, (bm) obj)).p(we1Var);
        }
    }

    @Override // defpackage.db
    public final ml n(ml mlVar, Object obj) {
        int i = this.i;
        Object obj2 = this.m;
        switch (i) {
            case 0:
                return new f((uj0) this.k, (nu0) this.l, (sq) obj2, mlVar, 0);
            case 1:
                f fVar = new f((ed1) this.l, (mk0) obj2, mlVar, 1);
                fVar.k = obj;
                return fVar;
            case 2:
                return new f((vc) this.k, (gm0) this.l, (g4) obj2, mlVar, 2);
            case 3:
                f fVar2 = new f((uw) this.l, (af) obj2, mlVar, 3);
                fVar2.k = obj;
                return fVar2;
            case gu0.LONG_FIELD_NUMBER /* 4 */:
                f fVar3 = new f((tn) obj2, mlVar, 4);
                fVar3.l = obj;
                return fVar3;
            case gu0.STRING_FIELD_NUMBER /* 5 */:
                f fVar4 = new f((tn) this.l, (m00) obj2, mlVar, 5);
                fVar4.k = obj;
                return fVar4;
            case gu0.STRING_SET_FIELD_NUMBER /* 6 */:
                f fVar5 = new f((wo) this.l, (m00) obj2, mlVar, 6);
                fVar5.k = obj;
                return fVar5;
            case gu0.DOUBLE_FIELD_NUMBER /* 7 */:
                return new f((wo) this.k, (tk0) this.l, (m00) obj2, mlVar, 7);
            case 8:
                f fVar6 = new f((uj0) this.k, (nw) obj2, mlVar);
                fVar6.l = obj;
                return fVar6;
            case 9:
                return new f((uj0) this.k, (y60) this.l, (sq) obj2, mlVar, 9);
            case 10:
                return new f((id) obj2, mlVar, 10);
            case 11:
                f fVar7 = new f((cw0) this.l, (g7) obj2, mlVar, 11);
                fVar7.k = obj;
                return fVar7;
            case 12:
                f fVar8 = new f((vr) this.l, (y11) obj2, mlVar, 12);
                fVar8.k = obj;
                return fVar8;
            case 13:
                f fVar9 = new f((y11) this.l, (m00) obj2, mlVar, 13);
                fVar9.k = obj;
                return fVar9;
            case 14:
                f fVar10 = new f((sl) this.l, (tw) obj2, mlVar, 14);
                fVar10.k = obj;
                return fVar10;
            default:
                return new f((ui1) this.k, (String) this.l, (i00) obj2, mlVar, 15);
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:181:0x0380, code lost:
        if (r7 == r11) goto L211;
     */
    /* JADX WARN: Code restructure failed: missing block: B:195:0x03e4, code lost:
        if (r0 == r11) goto L211;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x007a, code lost:
        if (r1.b(r2, r16) == r3) goto L29;
     */
    /* JADX WARN: Code restructure failed: missing block: B:270:0x0549, code lost:
        if (r0 == r4) goto L278;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x008a, code lost:
        if (defpackage.wl1.P(r2, r6, r16) == r3) goto L29;
     */
    /* JADX WARN: Code restructure failed: missing block: B:311:?, code lost:
        return r3;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:191:0x03dc  */
    /* JADX WARN: Removed duplicated region for block: B:197:0x03e8  */
    /* JADX WARN: Removed duplicated region for block: B:71:0x015a  */
    /* JADX WARN: Removed duplicated region for block: B:74:0x0164 A[Catch: all -> 0x0138, TryCatch #2 {all -> 0x0138, blocks: (B:62:0x0132, B:72:0x015c, B:74:0x0164, B:75:0x0171, B:82:0x0181, B:69:0x014e, B:84:0x0184, B:68:0x0149, B:76:0x0172, B:78:0x0178), top: B:301:0x0126 }] */
    /* JADX WARN: Removed duplicated region for block: B:88:0x018b  */
    /* JADX WARN: Type inference failed for: r3v0 */
    /* JADX WARN: Type inference failed for: r3v41, types: [ye] */
    /* JADX WARN: Type inference failed for: r3v43, types: [id] */
    /* JADX WARN: Type inference failed for: r3v44, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r3v45, types: [ye] */
    /* JADX WARN: Type inference failed for: r3v57 */
    /* JADX WARN: Type inference failed for: r3v58 */
    /* JADX WARN: Type inference failed for: r6v2, types: [p, yu0, ye] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:70:0x0158 -> B:72:0x015c). Please submit an issue!!! */
    @Override // defpackage.db
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object p(Object obj) {
        Object obj2;
        uw uwVar;
        Object P;
        z71 z71Var;
        uw uwVar2;
        hd hdVar;
        Object b;
        boolean z;
        ?? r3 = 5;
        CancellationException cancellationException = null;
        switch (this.i) {
            case 0:
                cm cmVar = cm.e;
                int i = this.j;
                if (i != 0) {
                    if (i == 1) {
                        nb0.t(obj);
                    } else {
                        od.p("call to 'resume' before 'invoke' with coroutine");
                        return null;
                    }
                } else {
                    nb0.t(obj);
                    this.j = 1;
                    if (((uj0) this.k).a((nu0) this.l, this) == cmVar) {
                        return cmVar;
                    }
                }
                sq sqVar = (sq) this.m;
                if (sqVar != null) {
                    sqVar.a();
                }
                return we1.a;
            case 1:
                ed1 ed1Var = (ed1) this.l;
                cm cmVar2 = cm.e;
                int i2 = this.j;
                if (i2 != 0) {
                    if (i2 == 1) {
                        nb0.t(obj);
                    } else {
                        od.p("call to 'resume' before 'invoke' with coroutine");
                        return null;
                    }
                } else {
                    nb0.t(obj);
                    cz0 C = mc0.C(new f8(0, ed1Var));
                    g8 g8Var = new g8((xu0) this.k, ed1Var, (mk0) this.m, 0);
                    this.j = 1;
                    if (C.b(g8Var, this) == cmVar2) {
                        return cmVar2;
                    }
                }
                return we1.a;
            case 2:
                we1 we1Var = we1.a;
                vc vcVar = (vc) this.k;
                cm cmVar3 = cm.e;
                int i3 = this.j;
                if (i3 != 0) {
                    if (i3 == 1) {
                        nb0.t(obj);
                    } else {
                        od.p("call to 'resume' before 'invoke' with coroutine");
                        return null;
                    }
                } else {
                    nb0.t(obj);
                    gl glVar = vcVar.s;
                    tc tcVar = new tc(vcVar, (gm0) this.l, (g4) this.m);
                    this.j = 1;
                    glVar.getClass();
                    gw0 gw0Var = (gw0) tcVar.a();
                    if (gw0Var != null && !gl.t0(glVar, gw0Var, 0L, 0L, 3)) {
                        ne neVar = new ne(1, ac.x(this));
                        neVar.t();
                        dl dlVar = new dl(tcVar, neVar);
                        sc scVar = glVar.w;
                        qk0 qk0Var = scVar.a;
                        gw0 gw0Var2 = (gw0) tcVar.a();
                        if (gw0Var2 == null) {
                            neVar.h(we1Var);
                        } else {
                            neVar.v(new c(5, scVar, dlVar));
                            q60 w = sb0.w(0, qk0Var.g);
                            int i4 = w.e;
                            int i5 = w.f;
                            if (i4 <= i5) {
                                while (true) {
                                    gw0 gw0Var3 = (gw0) ((dl) qk0Var.e[i5]).a.a();
                                    if (gw0Var3 != null) {
                                        gw0 c = gw0Var2.c(gw0Var3);
                                        if (c.equals(gw0Var2)) {
                                            qk0Var.a(i5 + 1, dlVar);
                                        } else if (!c.equals(gw0Var3)) {
                                            CancellationException cancellationException2 = new CancellationException("bringIntoView call interrupted by a newer, non-overlapping call");
                                            int i6 = qk0Var.g - 1;
                                            if (i6 <= i5) {
                                                while (true) {
                                                    ((dl) qk0Var.e[i5]).b.l(cancellationException2);
                                                    if (i6 != i5) {
                                                        i6++;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    if (i5 != i4) {
                                        i5--;
                                    }
                                }
                            }
                            qk0Var.a(0, dlVar);
                            if (!glVar.z) {
                                glVar.u0(0L);
                            }
                        }
                        obj2 = neVar.s();
                        break;
                    }
                    obj2 = we1Var;
                    if (obj2 == cmVar3) {
                        return cmVar3;
                    }
                }
                return we1Var;
            case 3:
                we1 we1Var2 = we1.a;
                cm cmVar4 = cm.e;
                int i7 = this.j;
                if (i7 != 0) {
                    if (i7 == 1) {
                        nb0.t(obj);
                    } else {
                        od.p("call to 'resume' before 'invoke' with coroutine");
                        return null;
                    }
                } else {
                    nb0.t(obj);
                    bm bmVar = (bm) this.k;
                    uw uwVar3 = (uw) this.l;
                    af afVar = (af) this.m;
                    sl slVar = afVar.e;
                    int i8 = afVar.f;
                    if (i8 == -3) {
                        i8 = -2;
                    }
                    gd gdVar = afVar.g;
                    em emVar = em.g;
                    ze zeVar = new ze(afVar, null, 0);
                    id b2 = wl1.b(i8, 4, gdVar);
                    sl D = j70.D(bmVar.f(), slVar, true);
                    uo uoVar = kq.a;
                    if (D != uoVar && D.k(e3.B) == null) {
                        D = D.i(uoVar);
                    }
                    ?? yu0Var = new yu0(D, b2);
                    yu0Var.g0(emVar, yu0Var, zeVar);
                    this.j = 1;
                    Object q = a5.q(uwVar3, yu0Var, true, this);
                    if (q != cmVar4) {
                        q = we1Var2;
                    }
                    if (q == cmVar4) {
                        return cmVar4;
                    }
                }
                return we1Var2;
            case gu0.LONG_FIELD_NUMBER /* 4 */:
                we1 we1Var3 = we1.a;
                tn tnVar = (tn) this.m;
                cm cmVar5 = cm.e;
                int i9 = this.j;
                if (i9 != 0) {
                    if (i9 != 1) {
                        if (i9 != 2) {
                            if (i9 == 3) {
                                nb0.t(obj);
                                return we1Var3;
                            }
                            od.p("call to 'resume' before 'invoke' with coroutine");
                            return null;
                        }
                        z71Var = (qm) this.k;
                        uwVar2 = (uw) this.l;
                        nb0.t(obj);
                        yw ywVar = new yw(new pg0(10, new al(4, new al(5, new al(3, new bn(tnVar, null, 0), (d81) tnVar.k.f), new cn(2, null, 0)), new dn(z71Var, null, 0))), new en(tnVar, (ml) null));
                        this.l = null;
                        this.k = null;
                        this.j = 3;
                        if (uwVar2 instanceof dc1) {
                            Object b3 = ywVar.b(uwVar2, this);
                            if (b3 != cmVar5) {
                                b3 = we1Var3;
                                break;
                            }
                        } else {
                            throw ((dc1) uwVar2).e;
                        }
                    } else {
                        nb0.t(obj);
                        uwVar = (uw) this.l;
                        P = obj;
                    }
                } else {
                    nb0.t(obj);
                    uwVar = (uw) this.l;
                    this.l = uwVar;
                    this.j = 1;
                    P = wl1.P(tnVar.f.f(), new bn(tnVar, null, 2), this);
                    break;
                }
                z71 z71Var2 = (z71) P;
                if (z71Var2 instanceof qm) {
                    qm qmVar = (qm) z71Var2;
                    Object obj3 = qmVar.b;
                    this.l = uwVar;
                    this.k = qmVar;
                    this.j = 2;
                    if (uwVar.k(obj3, this) != cmVar5) {
                        z71Var = z71Var2;
                        uwVar2 = uwVar;
                        yw ywVar2 = new yw(new pg0(10, new al(4, new al(5, new al(3, new bn(tnVar, null, 0), (d81) tnVar.k.f), new cn(2, null, 0)), new dn(z71Var, null, 0))), new en(tnVar, (ml) null));
                        this.l = null;
                        this.k = null;
                        this.j = 3;
                        if (uwVar2 instanceof dc1) {
                        }
                    }
                    return cmVar5;
                } else if (!(z71Var2 instanceof qe1)) {
                    if (!(z71Var2 instanceof sv0)) {
                        if (!(z71Var2 instanceof xv)) {
                            if (z71Var2 instanceof am0) {
                                od.p("This is a bug in DataStore. Please file a bug at: https://issuetracker.google.com/issues/new?component=907884&template=1466542");
                                return null;
                            }
                            od.k();
                            return null;
                        }
                        return we1Var3;
                    }
                    throw ((sv0) z71Var2).b;
                } else {
                    od.p("This is a bug in DataStore. Please file a bug at: https://issuetracker.google.com/issues/new?component=907884&template=1466542");
                    return null;
                }
            case gu0.STRING_FIELD_NUMBER /* 5 */:
                tn tnVar2 = (tn) this.l;
                cm cmVar6 = cm.e;
                int i10 = this.j;
                if (i10 != 0) {
                    if (i10 == 1) {
                        nb0.t(obj);
                        return obj;
                    }
                    od.p("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                nb0.t(obj);
                bm bmVar2 = (bm) this.k;
                uh b4 = k70.b();
                z71 o = tnVar2.k.o();
                if (o instanceof qm) {
                    o = new z71(((qm) o).a);
                }
                qh0 qh0Var = new qh0((m00) this.m, b4, o, bmVar2.f());
                p3 p3Var = tnVar2.o;
                Object s = ((id) p3Var.g).s(qh0Var);
                if (s instanceof gf) {
                    Throwable th = ((gf) s).a;
                    if (th == null) {
                        throw new IllegalStateException("Channel was closed normally");
                    }
                    throw th;
                } else if (!(s instanceof hf)) {
                    if (((AtomicInteger) ((pg0) p3Var.h).f).getAndIncrement() == 0) {
                        wl1.B((bm) p3Var.e, null, new d(p3Var, null, 18), 3);
                    }
                    this.j = 1;
                    Object e0 = b4.e0(this);
                    if (e0 == cmVar6) {
                        return cmVar6;
                    }
                    return e0;
                } else {
                    od.p("Check failed.");
                    return null;
                }
            case gu0.STRING_SET_FIELD_NUMBER /* 6 */:
                lq0 lq0Var = ((wo) this.l).d;
                cm cmVar7 = cm.e;
                int i11 = this.j;
                try {
                    if (i11 != 0) {
                        if (i11 == 1) {
                            nb0.t(obj);
                        } else {
                            od.p("call to 'resume' before 'invoke' with coroutine");
                            return null;
                        }
                    } else {
                        nb0.t(obj);
                        a11 a11Var = (a11) this.k;
                        lq0Var.setValue(Boolean.TRUE);
                        this.j = 1;
                        if (((m00) this.m).f(a11Var, this) == cmVar7) {
                            return cmVar7;
                        }
                    }
                    lq0Var.setValue(Boolean.FALSE);
                    return we1.a;
                } catch (Throwable th2) {
                    lq0Var.setValue(Boolean.FALSE);
                    throw th2;
                }
            case gu0.DOUBLE_FIELD_NUMBER /* 7 */:
                cm cmVar8 = cm.e;
                int i12 = this.j;
                if (i12 != 0) {
                    if (i12 == 1) {
                        nb0.t(obj);
                    } else {
                        od.p("call to 'resume' before 'invoke' with coroutine");
                        return null;
                    }
                } else {
                    nb0.t(obj);
                    wo woVar = (wo) this.k;
                    zk0 zk0Var = woVar.c;
                    vo voVar = woVar.b;
                    tk0 tk0Var = (tk0) this.l;
                    f fVar = new f(woVar, (m00) this.m, null, 6);
                    this.j = 1;
                    zk0Var.getClass();
                    if (vd1.i(new yk0(tk0Var, zk0Var, fVar, voVar, null), this) == cmVar8) {
                        return cmVar8;
                    }
                }
                return we1.a;
            case 8:
                cm cmVar9 = cm.e;
                int i13 = this.j;
                if (i13 != 0) {
                    if (i13 == 1) {
                        nb0.t(obj);
                        return we1.a;
                    }
                    od.p("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                nb0.t(obj);
                ArrayList arrayList = new ArrayList();
                g51 g51Var = ((uj0) this.k).a;
                g8 g8Var2 = new g8(arrayList, (bm) this.l, (nw) this.m, 1);
                this.j = 1;
                g51Var.getClass();
                g51.j(g51Var, g8Var2, this);
                return cmVar9;
            case 9:
                cm cmVar10 = cm.e;
                int i14 = this.j;
                if (i14 != 0) {
                    if (i14 == 1) {
                        nb0.t(obj);
                    } else {
                        od.p("call to 'resume' before 'invoke' with coroutine");
                        return null;
                    }
                } else {
                    nb0.t(obj);
                    this.j = 1;
                    if (((uj0) this.k).a((y60) this.l, this) == cmVar10) {
                        return cmVar10;
                    }
                }
                sq sqVar2 = (sq) this.m;
                if (sqVar2 != null) {
                    sqVar2.a();
                }
                return we1.a;
            case 10:
                cm cmVar11 = cm.e;
                int i15 = this.j;
                try {
                    if (i15 != 0) {
                        if (i15 == 1) {
                            hdVar = (hd) this.l;
                            ye yeVar = (ye) this.k;
                            nb0.t(obj);
                            b = obj;
                            r3 = yeVar;
                            if (((Boolean) b).booleanValue()) {
                                we1 we1Var4 = (we1) hdVar.c();
                                u10.b.set(false);
                                synchronized (n61.c) {
                                    ik0 ik0Var = n61.j.h;
                                    if (ik0Var != null && ik0Var.h()) {
                                        z = true;
                                    } else {
                                        z = false;
                                    }
                                }
                                if (z) {
                                    n61.a();
                                }
                                this.k = r3;
                                this.l = hdVar;
                                this.j = 1;
                                b = hdVar.b(this);
                                r3 = r3;
                                if (b == cmVar11) {
                                    return cmVar11;
                                }
                                if (((Boolean) b).booleanValue()) {
                                    r3.a(null);
                                    return we1.a;
                                }
                            }
                        } else {
                            od.p("call to 'resume' before 'invoke' with coroutine");
                            return null;
                        }
                    } else {
                        nb0.t(obj);
                        r3 = (id) this.m;
                        hdVar = new hd(r3);
                        this.k = r3;
                        this.l = hdVar;
                        this.j = 1;
                        b = hdVar.b(this);
                        r3 = r3;
                        if (b == cmVar11) {
                        }
                        if (((Boolean) b).booleanValue()) {
                        }
                    }
                } catch (Throwable th3) {
                    try {
                        throw th3;
                    } catch (Throwable th4) {
                        if (th3 instanceof CancellationException) {
                            cancellationException = th3;
                        }
                        if (cancellationException == null) {
                            cancellationException = new CancellationException("Channel was consumed, consumer had failed");
                            cancellationException.initCause(th3);
                        }
                        r3.a(cancellationException);
                        throw th4;
                    }
                }
                break;
            case 11:
                cm cmVar12 = cm.e;
                int i16 = this.j;
                if (i16 != 0) {
                    if (i16 == 1) {
                        nb0.t(obj);
                        return we1.a;
                    }
                    od.p("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                nb0.t(obj);
                cw0 cw0Var = (cw0) this.l;
                this.j = 1;
                cw0Var.c((bm) this.k, (g7) this.m, this);
                return cmVar12;
            case 12:
                cm cmVar13 = cm.e;
                int i17 = this.j;
                if (i17 != 0) {
                    if (i17 == 1) {
                        nb0.t(obj);
                    } else {
                        od.p("call to 'resume' before 'invoke' with coroutine");
                        return null;
                    }
                } else {
                    nb0.t(obj);
                    c cVar = new c(22, (w11) this.k, (y11) this.m);
                    this.j = 1;
                    if (((vr) this.l).f(cVar, this) == cmVar13) {
                        return cmVar13;
                    }
                }
                return we1.a;
            case 13:
                cm cmVar14 = cm.e;
                int i18 = this.j;
                if (i18 != 0) {
                    if (i18 == 1) {
                        nb0.t(obj);
                    } else {
                        od.p("call to 'resume' before 'invoke' with coroutine");
                        return null;
                    }
                } else {
                    nb0.t(obj);
                    y11 y11Var = (y11) this.l;
                    y11Var.k = (a11) this.k;
                    w11 w11Var = y11Var.l;
                    this.j = 1;
                    if (((m00) this.m).f(w11Var, this) == cmVar14) {
                        return cmVar14;
                    }
                }
                return we1.a;
            case 14:
                tw twVar = (tw) this.m;
                sl slVar2 = (sl) this.l;
                cm cmVar15 = cm.e;
                int i19 = this.j;
                if (i19 != 0) {
                    if (i19 != 1 && i19 != 2) {
                        od.p("call to 'resume' before 'invoke' with coroutine");
                        return null;
                    }
                    nb0.t(obj);
                } else {
                    nb0.t(obj);
                    xu0 xu0Var = (xu0) this.k;
                    if (k70.p(slVar2, st.e)) {
                        w61 w61Var = new w61(xu0Var, 0);
                        this.j = 1;
                        break;
                    } else {
                        d dVar = new d(twVar, xu0Var, null, 19);
                        this.j = 2;
                        break;
                    }
                }
                return we1.a;
            default:
                cm cmVar16 = cm.e;
                int i20 = this.j;
                if (i20 != 0) {
                    if (i20 == 1) {
                        nb0.t(obj);
                    } else {
                        od.p("call to 'resume' before 'invoke' with coroutine");
                        return null;
                    }
                } else {
                    nb0.t(obj);
                    g51 g51Var2 = ((ui1) this.k).c;
                    ni1 ni1Var = new ni1((i00) this.m, (String) this.l);
                    this.j = 1;
                    if (g51Var2.k(ni1Var, this) == cmVar16) {
                        return cmVar16;
                    }
                }
                return we1.a;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ f(Object obj, ml mlVar, int i) {
        super(2, mlVar);
        this.i = i;
        this.m = obj;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ f(Object obj, Object obj2, ml mlVar, int i) {
        super(2, mlVar);
        this.i = i;
        this.l = obj;
        this.m = obj2;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ f(Object obj, Object obj2, Object obj3, ml mlVar, int i) {
        super(2, mlVar);
        this.i = i;
        this.k = obj;
        this.l = obj2;
        this.m = obj3;
    }
}