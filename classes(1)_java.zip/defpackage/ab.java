package defpackage;

/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ab  reason: default package */
public final class ab extends qi0 {
    public final long a;
    public final float b = 1.0f;
    public final y41 c;

    public ab(long j, y41 y41Var) {
        this.a = j;
        this.c = y41Var;
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [bb, li0] */
    @Override // defpackage.qi0
    public final li0 e() {
        ?? li0Var = new li0();
        li0Var.s = this.a;
        li0Var.t = this.c;
        li0Var.u = 9205357640488583168L;
        return li0Var;
    }

    public final boolean equals(Object obj) {
        ab abVar;
        if (obj instanceof ab) {
            abVar = (ab) obj;
        } else {
            abVar = null;
        }
        if (abVar != null && zg.c(this.a, abVar.a) && this.b == abVar.b && k70.p(this.c, abVar.c)) {
            return true;
        }
        return false;
    }

    @Override // defpackage.qi0
    public final void f(li0 li0Var) {
        bb bbVar = (bb) li0Var;
        bbVar.s = this.a;
        y41 y41Var = bbVar.t;
        y41 y41Var2 = this.c;
        if (!k70.p(y41Var, y41Var2)) {
            bbVar.t = y41Var2;
            jb0.n(bbVar);
        }
        a5.x(bbVar);
    }

    public final int hashCode() {
        int i = zg.j;
        return this.c.hashCode() + fu0.z(this.b, pe1.a(this.a) * 961, 31);
    }
}