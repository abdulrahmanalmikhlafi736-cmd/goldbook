package defpackage;

import android.view.autofill.AutofillValue;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: a6  reason: default package */
public final class a6 {
    public final AutofillValue a;

    public a6(AutofillValue autofillValue) {
        this.a = autofillValue;
    }
}