package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: b91  reason: default package */
public final class b91 extends h90 implements m00 {
    public final /* synthetic */ mi0 f;
    public final /* synthetic */ m00 g;
    public final /* synthetic */ int h;
    public final /* synthetic */ int i;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public b91(mi0 mi0Var, m00 m00Var, int i, int i2) {
        super(2);
        this.f = mi0Var;
        this.g = m00Var;
        this.h = i;
        this.i = i2;
    }

    @Override // defpackage.m00
    public final Object f(Object obj, Object obj2) {
        ((Number) obj2).intValue();
        int s = wc0.s(this.h | 1);
        int i = this.i;
        vn.b(this.f, this.g, (d10) obj, s, i);
        return we1.a;
    }
}