package defpackage;

import java.util.HashMap;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: b40  reason: default package */
public final class b40 {
    public final HashMap a = new HashMap();
}