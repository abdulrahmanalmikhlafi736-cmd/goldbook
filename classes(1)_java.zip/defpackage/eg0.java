package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: eg0  reason: default package */
public final class eg0 implements n90 {
    public final dg0 e;

    public eg0(dg0 dg0Var) {
        this.e = dg0Var;
    }

    @Override // defpackage.n90
    public final long A() {
        dg0 dg0Var = this.e;
        return (dg0Var.e << 32) | (dg0Var.f & 4294967295L);
    }

    @Override // defpackage.n90
    public final long B(long j) {
        return this.e.s.B(xm0.f(0L, a()));
    }

    @Override // defpackage.n90
    public final boolean I() {
        return this.e.s.y0().r;
    }

    public final long a() {
        dg0 dg0Var = this.e;
        dg0 m = nb0.m(dg0Var);
        return xm0.e(x(m.v, 0L), dg0Var.s.x(m.s, 0L));
    }

    @Override // defpackage.n90
    public final long d(long j) {
        return this.e.s.d(xm0.f(0L, a()));
    }

    @Override // defpackage.n90
    public final long h(long j) {
        return this.e.s.h(xm0.f(j, a()));
    }

    @Override // defpackage.n90
    public final n90 j() {
        dg0 w0;
        if (!I()) {
            p50.b("LayoutCoordinate operations are only valid when isAttached is true");
        }
        gm0 gm0Var = this.e.s.s.J.d.u;
        if (gm0Var != null && (w0 = gm0Var.w0()) != null) {
            return w0.v;
        }
        return null;
    }

    @Override // defpackage.n90
    public final long v(n90 n90Var, long j) {
        return x(n90Var, j);
    }

    @Override // defpackage.n90
    public final long x(n90 n90Var, long j) {
        boolean z = n90Var instanceof eg0;
        dg0 dg0Var = this.e;
        if (z) {
            dg0 dg0Var2 = ((eg0) n90Var).e;
            gm0 gm0Var = dg0Var2.s;
            gm0Var.H0();
            dg0 w0 = dg0Var.s.u0(gm0Var).w0();
            if (w0 != null) {
                long b = n60.b(n60.c(dg0Var2.q0(w0, false), vd1.C(j)), dg0Var.q0(w0, false));
                return (Float.floatToRawIntBits((int) (b >> 32)) << 32) | (Float.floatToRawIntBits((int) (b & 4294967295L)) & 4294967295L);
            }
            dg0 m = nb0.m(dg0Var2);
            long c = n60.c(n60.c(dg0Var2.q0(m, false), m.t), vd1.C(j));
            dg0 m2 = nb0.m(dg0Var);
            long b2 = n60.b(c, n60.c(dg0Var.q0(m2, false), m2.t));
            long floatToRawIntBits = Float.floatToRawIntBits((int) (b2 & 4294967295L)) & 4294967295L;
            gm0 gm0Var2 = m2.s.u;
            gm0Var2.getClass();
            gm0 gm0Var3 = m.s.u;
            gm0Var3.getClass();
            return gm0Var2.x(gm0Var3, floatToRawIntBits | (Float.floatToRawIntBits((int) (b2 >> 32)) << 32));
        }
        dg0 m3 = nb0.m(dg0Var);
        gm0 gm0Var4 = m3.s;
        long x = x(m3.v, j);
        long j2 = m3.t;
        long e = xm0.e(x, (4294967295L & Float.floatToRawIntBits((int) (j2 & 4294967295L))) | (Float.floatToRawIntBits((int) (j2 >> 32)) << 32));
        if (!gm0Var4.y0().r) {
            p50.b("LayoutCoordinate operations are only valid when isAttached is true");
        }
        gm0Var4.H0();
        gm0 gm0Var5 = gm0Var4.u;
        if (gm0Var5 != null) {
            gm0Var4 = gm0Var5;
        }
        return xm0.f(e, gm0Var4.x(n90Var, 0L));
    }

    @Override // defpackage.n90
    public final gw0 z(n90 n90Var, boolean z) {
        return this.e.s.z(n90Var, z);
    }
}