package defpackage;

import android.app.Application;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import com.almekhlafi.goldbook.MainActivity;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ai  reason: default package */
public final /* synthetic */ class ai implements xz {
    public final /* synthetic */ int e;
    public final /* synthetic */ MainActivity f;

    public /* synthetic */ ai(MainActivity mainActivity, int i) {
        this.e = i;
        this.f = mainActivity;
    }

    /* JADX WARN: Type inference failed for: r0v2, types: [java.lang.Object, hl0] */
    @Override // defpackage.xz
    public final Object a() {
        Bundle bundle;
        int i = this.e;
        MainActivity mainActivity = this.f;
        switch (i) {
            case 0:
                mainActivity.reportFullyDrawn();
                return we1.a;
            case 1:
                return new wz(mainActivity.j, new ai(mainActivity, 0));
            case 2:
                ?? obj = new Object();
                mainActivity.a().c(obj);
                return obj;
            case 3:
                Application application = mainActivity.getApplication();
                if (mainActivity.getIntent() != null) {
                    bundle = mainActivity.getIntent().getExtras();
                } else {
                    bundle = null;
                }
                return new yz0(application, mainActivity, bundle);
            case gu0.LONG_FIELD_NUMBER /* 4 */:
                jn0 jn0Var = new jn0(new o4(2, mainActivity));
                if (Build.VERSION.SDK_INT >= 33) {
                    if (!k70.p(Looper.myLooper(), Looper.getMainLooper())) {
                        new Handler(Looper.getMainLooper()).post(new e5(1, mainActivity, jn0Var));
                    } else {
                        mainActivity.e.a(new bi(jn0Var, mainActivity));
                    }
                }
                return jn0Var;
            default:
                return k70.E(mainActivity);
        }
    }
}