package defpackage;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ek0  reason: default package */
public final class ek0 {
    public final LinkedHashMap a;
    public final pg0 b;

    public ek0(LinkedHashMap linkedHashMap, boolean z) {
        this.a = linkedHashMap;
        this.b = new pg0(z);
    }

    public final Map a() {
        zp0 zp0Var;
        Set<Map.Entry> entrySet = this.a.entrySet();
        int y = ch0.y(ug.M(entrySet, 10));
        if (y < 16) {
            y = 16;
        }
        LinkedHashMap linkedHashMap = new LinkedHashMap(y);
        for (Map.Entry entry : entrySet) {
            Object value = entry.getValue();
            if (value instanceof byte[]) {
                byte[] bArr = (byte[]) value;
                zp0Var = new zp0(entry.getKey(), Arrays.copyOf(bArr, bArr.length));
            } else {
                zp0Var = new zp0(entry.getKey(), entry.getValue());
            }
            linkedHashMap.put(zp0Var.e, zp0Var.f);
        }
        Map unmodifiableMap = Collections.unmodifiableMap(linkedHashMap);
        unmodifiableMap.getClass();
        return unmodifiableMap;
    }

    public final void b() {
        if (!((AtomicBoolean) this.b.f).get()) {
            return;
        }
        od.p("Do mutate preferences once returned to DataStore.");
    }

    public final Object c(wt0 wt0Var) {
        wt0Var.getClass();
        Object obj = this.a.get(wt0Var);
        if (obj instanceof byte[]) {
            byte[] bArr = (byte[]) obj;
            return Arrays.copyOf(bArr, bArr.length);
        }
        return obj;
    }

    public final void d(wt0 wt0Var, Object obj) {
        wt0Var.getClass();
        e(wt0Var, obj);
    }

    public final void e(wt0 wt0Var, Object obj) {
        wt0Var.getClass();
        b();
        LinkedHashMap linkedHashMap = this.a;
        if (obj == null) {
            b();
            linkedHashMap.remove(wt0Var);
        } else if (obj instanceof Set) {
            Set unmodifiableSet = Collections.unmodifiableSet(tg.d0((Set) obj));
            unmodifiableSet.getClass();
            linkedHashMap.put(wt0Var, unmodifiableSet);
        } else if (obj instanceof byte[]) {
            byte[] bArr = (byte[]) obj;
            linkedHashMap.put(wt0Var, Arrays.copyOf(bArr, bArr.length));
        } else {
            linkedHashMap.put(wt0Var, obj);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:32:0x0060 A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean equals(Object obj) {
        boolean z;
        if (obj instanceof ek0) {
            LinkedHashMap linkedHashMap = ((ek0) obj).a;
            LinkedHashMap linkedHashMap2 = this.a;
            if (linkedHashMap != linkedHashMap2) {
                if (linkedHashMap.size() == linkedHashMap2.size()) {
                    if (!linkedHashMap.isEmpty()) {
                        for (Map.Entry entry : linkedHashMap.entrySet()) {
                            Object obj2 = linkedHashMap2.get(entry.getKey());
                            if (obj2 != null) {
                                Object value = entry.getValue();
                                if (value instanceof byte[]) {
                                    if ((obj2 instanceof byte[]) && Arrays.equals((byte[]) value, (byte[]) obj2)) {
                                        z = true;
                                        continue;
                                    }
                                } else {
                                    z = k70.p(value, obj2);
                                    continue;
                                }
                                if (!z) {
                                }
                            }
                            z = false;
                            continue;
                            if (!z) {
                            }
                        }
                    }
                }
            }
            return true;
        }
        return false;
    }

    public final int hashCode() {
        int hashCode;
        int i = 0;
        for (Map.Entry entry : this.a.entrySet()) {
            Object value = entry.getValue();
            if (value instanceof byte[]) {
                hashCode = Arrays.hashCode((byte[]) value);
            } else {
                hashCode = value.hashCode();
            }
            i += hashCode;
        }
        return i;
    }

    public final String toString() {
        return tg.V(this.a.entrySet(), ",\n", "{\n", "\n}", new z1(17), 24);
    }

    public /* synthetic */ ek0(boolean z) {
        this(new LinkedHashMap(), z);
    }
}