package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ew  reason: default package */
public abstract class ew {
    public static final float a = (float) (Math.log(0.78d) / Math.log(0.9d));
}