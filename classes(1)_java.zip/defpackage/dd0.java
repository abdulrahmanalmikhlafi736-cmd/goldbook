package defpackage;

import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Build;
import android.view.View;
import android.view.ViewParent;
import android.view.ViewStructure;
import android.view.Window;
import android.view.autofill.AutofillId;
import android.view.autofill.AutofillValue;
import java.util.List;
import java.util.NoSuchElementException;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dd0  reason: default package */
public abstract class dd0 {
    public static y30 a;

    public static m6 a(String str, ob1 ob1Var, long j, mp mpVar, yy yyVar, int i) {
        ut utVar = ut.e;
        return new m6(new q6(str, ob1Var, utVar, utVar, yyVar, mpVar), i, 1, j);
    }

    public static final long b(int i, int i2) {
        if (i < 0 || i2 < 0) {
            q50.a("start and end cannot be negative. [start: " + i + ", end: " + i2 + ']');
        }
        long j = (i2 & 4294967295L) | (i << 32);
        int i3 = hb1.c;
        return j;
    }

    public static void c(StringBuilder sb, Object obj, i00 i00Var) {
        boolean z;
        if (i00Var != null) {
            sb.append((CharSequence) i00Var.i(obj));
            return;
        }
        if (obj == null) {
            z = true;
        } else {
            z = obj instanceof CharSequence;
        }
        if (z) {
            sb.append((CharSequence) obj);
        } else if (obj instanceof Character) {
            sb.append(((Character) obj).charValue());
        } else {
            sb.append((CharSequence) obj.toString());
        }
    }

    public static final void d(fh1 fh1Var, al alVar, ud0 ud0Var) {
        alVar.getClass();
        ud0Var.getClass();
        rz0 rz0Var = (rz0) fh1Var.c("androidx.lifecycle.savedstate.vm.tag");
        if (rz0Var != null && !rz0Var.g) {
            rz0Var.f(alVar, ud0Var);
            jd0 jd0Var = ud0Var.d;
            if (jd0Var != jd0.f && jd0Var.compareTo(jd0.h) < 0) {
                ud0Var.a(new to(alVar, ud0Var));
            } else {
                alVar.t();
            }
        }
    }

    public static float[] e() {
        return new float[]{1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f};
    }

    public static final int h(int i, List list) {
        int i2;
        char c;
        int i3 = ((bq0) tg.W(list)).c;
        if (i > ((bq0) tg.W(list)).c) {
            q50.a("Index " + i + " should be less or equal than last line's end " + i3);
        }
        int size = list.size() - 1;
        int i4 = 0;
        while (true) {
            if (i4 <= size) {
                i2 = (i4 + size) >>> 1;
                bq0 bq0Var = (bq0) list.get(i2);
                if (bq0Var.b > i) {
                    c = 1;
                } else if (bq0Var.c <= i) {
                    c = 65535;
                } else {
                    c = 0;
                }
                if (c < 0) {
                    i4 = i2 + 1;
                } else if (c <= 0) {
                    break;
                } else {
                    size = i2 - 1;
                }
            } else {
                i2 = -(i4 + 1);
                break;
            }
        }
        if (i2 >= 0 && i2 < list.size()) {
            return i2;
        }
        StringBuilder H = fu0.H(i2, "Found paragraph index ", " should be in range [0, ");
        H.append(list.size());
        H.append(").\nDebug info: index=");
        H.append(i);
        H.append(", paragraphs=[");
        H.append(ue0.a(list, null, new z1(16), 31));
        H.append(']');
        q50.a(H.toString());
        return i2;
    }

    public static final int i(int i, List list) {
        char c;
        int size = list.size() - 1;
        int i2 = 0;
        while (i2 <= size) {
            int i3 = (i2 + size) >>> 1;
            bq0 bq0Var = (bq0) list.get(i3);
            if (bq0Var.d > i) {
                c = 1;
            } else if (bq0Var.e <= i) {
                c = 65535;
            } else {
                c = 0;
            }
            if (c < 0) {
                i2 = i3 + 1;
            } else if (c > 0) {
                size = i3 - 1;
            } else {
                return i3;
            }
        }
        return -(i2 + 1);
    }

    public static final ViewParent j(View view) {
        view.getClass();
        ViewParent parent = view.getParent();
        if (parent != null) {
            return parent;
        }
        Object tag = view.getTag(2131034228);
        if (tag instanceof ViewParent) {
            return (ViewParent) tag;
        }
        return null;
    }

    public static final a21 k(Object obj) {
        if (obj != j70.b) {
            return (a21) obj;
        }
        od.p("Does not contain segment");
        return null;
    }

    public static final boolean l(Object obj) {
        if (obj == j70.b) {
            return true;
        }
        return false;
    }

    public static final boolean m(float f, float f2, r6 r6Var) {
        float f3 = f - 0.005f;
        float f4 = f2 - 0.005f;
        float f5 = f + 0.005f;
        float f6 = f2 + 0.005f;
        r6 a2 = t6.a();
        if (Float.isNaN(f3) || Float.isNaN(f4) || Float.isNaN(f5) || Float.isNaN(f6)) {
            t6.b("Invalid rectangle, make sure no value is NaN");
        }
        if (a2.b == null) {
            a2.b = new RectF();
        }
        RectF rectF = a2.b;
        rectF.getClass();
        rectF.set(f3, f4, f5, f6);
        Path path = a2.a;
        RectF rectF2 = a2.b;
        rectF2.getClass();
        path.addRect(rectF2, Path.Direction.CCW);
        r6 a3 = t6.a();
        a3.b(r6Var, a2, 1);
        boolean isEmpty = a3.a.isEmpty();
        a3.c();
        a2.c();
        return !isEmpty;
    }

    public static final boolean n(float f, float f2, float f3, float f4, long j) {
        float f5 = f - f3;
        float f6 = f2 - f4;
        float intBitsToFloat = Float.intBitsToFloat((int) (j >> 32));
        float intBitsToFloat2 = Float.intBitsToFloat((int) (j & 4294967295L));
        if (((f6 * f6) / (intBitsToFloat2 * intBitsToFloat2)) + ((f5 * f5) / (intBitsToFloat * intBitsToFloat)) <= 1.0f) {
            return true;
        }
        return false;
    }

    public static final long o(float[] fArr, long j) {
        if (fArr.length < 16) {
            return j;
        }
        float f = fArr[0];
        float f2 = fArr[1];
        float f3 = fArr[3];
        float f4 = fArr[4];
        float f5 = fArr[5];
        float f6 = fArr[7];
        float f7 = fArr[12];
        float f8 = fArr[13];
        float f9 = fArr[15];
        float intBitsToFloat = Float.intBitsToFloat((int) (j >> 32));
        float intBitsToFloat2 = Float.intBitsToFloat((int) (j & 4294967295L));
        float f10 = 1.0f / (((f6 * intBitsToFloat2) + (f3 * intBitsToFloat)) + f9);
        if ((Float.floatToRawIntBits(f10) & Integer.MAX_VALUE) >= 2139095040) {
            f10 = 0.0f;
        }
        return (Float.floatToRawIntBits((((f4 * intBitsToFloat2) + (f * intBitsToFloat)) + f7) * f10) << 32) | (Float.floatToRawIntBits(((f5 * intBitsToFloat2) + (f2 * intBitsToFloat) + f8) * f10) & 4294967295L);
    }

    public static final void p(float[] fArr, gk0 gk0Var) {
        if (fArr.length < 16) {
            return;
        }
        float f = fArr[0];
        float f2 = fArr[1];
        float f3 = fArr[3];
        float f4 = fArr[4];
        float f5 = fArr[5];
        float f6 = fArr[7];
        float f7 = fArr[12];
        float f8 = fArr[13];
        float f9 = fArr[15];
        float f10 = gk0Var.a;
        float f11 = gk0Var.b;
        float f12 = gk0Var.c;
        float f13 = gk0Var.d;
        float f14 = f3 * f10;
        float f15 = f6 * f11;
        float f16 = 1.0f / ((f14 + f15) + f9);
        float f17 = 0.0f;
        if ((Float.floatToRawIntBits(f16) & Integer.MAX_VALUE) >= 2139095040) {
            f16 = 0.0f;
        }
        float f18 = f * f10;
        float f19 = f4 * f11;
        float f20 = (f18 + f19 + f7) * f16;
        float f21 = f10 * f2;
        float f22 = f11 * f5;
        float f23 = (f21 + f22 + f8) * f16;
        float f24 = f6 * f13;
        float f25 = 1.0f / ((f14 + f24) + f9);
        if ((Float.floatToRawIntBits(f25) & Integer.MAX_VALUE) >= 2139095040) {
            f25 = 0.0f;
        }
        float f26 = f4 * f13;
        float f27 = (f18 + f26 + f7) * f25;
        float f28 = f5 * f13;
        float f29 = (f21 + f28 + f8) * f25;
        float f30 = f3 * f12;
        float f31 = 1.0f / ((f15 + f30) + f9);
        if ((Float.floatToRawIntBits(f31) & Integer.MAX_VALUE) >= 2139095040) {
            f31 = 0.0f;
        }
        float f32 = f * f12;
        float f33 = (f32 + f19 + f7) * f31;
        float f34 = f12 * f2;
        float f35 = (f22 + f34 + f8) * f31;
        float f36 = 1.0f / ((f30 + f24) + f9);
        if ((Float.floatToRawIntBits(f36) & Integer.MAX_VALUE) < 2139095040) {
            f17 = f36;
        }
        float f37 = (f32 + f26 + f7) * f17;
        float f38 = (f34 + f28 + f8) * f17;
        gk0Var.a = Math.min(f20, Math.min(f27, Math.min(f33, f37)));
        gk0Var.b = Math.min(f23, Math.min(f29, Math.min(f35, f38)));
        gk0Var.c = Math.max(f20, Math.max(f27, Math.max(f33, f37)));
        gk0Var.d = Math.max(f23, Math.max(f29, Math.max(f35, f38)));
    }

    public static final nh0 q(qy0 qy0Var, int i, int i2, int i3, int i4, int i5, oh0 oh0Var, List list, ks0[] ks0VarArr, int i6, int i7, int[] iArr, int i8) {
        int i9;
        int i10;
        float f;
        long j;
        int i11;
        int i12;
        int i13;
        List list2 = list;
        long j2 = i5;
        int i14 = i7 - i6;
        int[] iArr2 = new int[i14];
        int i15 = i6;
        int i16 = 0;
        int i17 = 0;
        int i18 = 0;
        int i19 = 0;
        float f2 = 0.0f;
        while (i15 < i7) {
            hh0 hh0Var = (hh0) list2.get(i15);
            float l = wc0.l(wc0.k(hh0Var));
            if (l > 0.0f) {
                f2 += l;
                i17++;
                j = j2;
                i11 = i15;
            } else {
                int i20 = i3 - i18;
                ks0 ks0Var = ks0VarArr[i15];
                j = j2;
                if (ks0Var == null) {
                    if (i3 == Integer.MAX_VALUE) {
                        i11 = i15;
                        i12 = i17;
                        i13 = Integer.MAX_VALUE;
                    } else {
                        i11 = i15;
                        i12 = i17;
                        i13 = i20 < 0 ? 0 : i20;
                    }
                    ks0Var = hh0Var.e(qy0Var.d(0, i13, i4, false));
                } else {
                    i11 = i15;
                    i12 = i17;
                }
                ks0 ks0Var2 = ks0Var;
                int h = qy0Var.h(ks0Var2);
                int e = qy0Var.e(ks0Var2);
                iArr2[i11 - i6] = h;
                int i21 = i20 - h;
                if (i21 < 0) {
                    i21 = 0;
                }
                i19 = Math.min(i5, i21);
                i18 += h + i19;
                i16 = Math.max(i16, e);
                ks0VarArr[i11] = ks0Var2;
                i17 = i12;
            }
            i15 = i11 + 1;
            j2 = j;
        }
        long j3 = j2;
        if (i17 == 0) {
            i18 -= i19;
            i10 = 0;
        } else {
            long j4 = (i9 - 1) * j3;
            long j5 = ((i3 != Integer.MAX_VALUE ? i3 : i) - i18) - j4;
            if (j5 < 0) {
                j5 = 0;
            }
            float f3 = ((float) j5) / f2;
            for (int i22 = i6; i22 < i7; i22++) {
                j5 -= Math.round(wc0.l(wc0.k((hh0) list2.get(i22))) * f3);
            }
            int i23 = i6;
            int i24 = i16;
            int i25 = 0;
            while (i23 < i7) {
                if (ks0VarArr[i23] == null) {
                    hh0 hh0Var2 = (hh0) list2.get(i23);
                    f = f3;
                    ry0 k = wc0.k(hh0Var2);
                    float l2 = wc0.l(k);
                    if (l2 <= 0.0f) {
                        n50.b("All weights <= 0 should have placeables");
                    }
                    int signum = Long.signum(j5);
                    long j6 = j5 - signum;
                    int max = Math.max(0, Math.round(l2 * f) + signum);
                    ks0 e2 = hh0Var2.e(qy0Var.d((!(k != null ? k.b : true) || max == Integer.MAX_VALUE) ? 0 : max, max, i4, true));
                    int h2 = qy0Var.h(e2);
                    int e3 = qy0Var.e(e2);
                    iArr2[i23 - i6] = h2;
                    i25 += h2;
                    int max2 = Math.max(i24, e3);
                    ks0VarArr[i23] = e2;
                    i24 = max2;
                    j5 = j6;
                } else {
                    f = f3;
                }
                i23++;
                list2 = list;
                f3 = f;
            }
            i10 = (int) (i25 + j4);
            int i26 = i3 - i18;
            if (i10 < 0) {
                i10 = 0;
            }
            if (i10 > i26) {
                i10 = i26;
            }
            i16 = i24;
        }
        int i27 = i10 + i18;
        if (i27 < 0) {
            i27 = 0;
        }
        int max3 = Math.max(i27, i);
        int max4 = Math.max(i16, Math.max(i2, 0));
        int[] iArr3 = new int[i14];
        qy0Var.b(max3, oh0Var, iArr2, iArr3);
        return qy0Var.j(ks0VarArr, oh0Var, iArr3, max3, max4, iArr, i8, i6, i7);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:120:0x02aa  */
    /* JADX WARN: Removed duplicated region for block: B:122:0x02ad  */
    /* JADX WARN: Removed duplicated region for block: B:124:0x02b4  */
    /* JADX WARN: Removed duplicated region for block: B:127:0x02c1  */
    /* JADX WARN: Removed duplicated region for block: B:128:0x02c8  */
    /* JADX WARN: Removed duplicated region for block: B:134:0x02d9  */
    /* JADX WARN: Removed duplicated region for block: B:136:0x02e2  */
    /* JADX WARN: Removed duplicated region for block: B:147:0x0315  */
    /* JADX WARN: Removed duplicated region for block: B:154:0x0335  */
    /* JADX WARN: Removed duplicated region for block: B:157:0x033f  */
    /* JADX WARN: Removed duplicated region for block: B:163:0x0350  */
    /* JADX WARN: Removed duplicated region for block: B:172:0x0376  */
    /* JADX WARN: Removed duplicated region for block: B:214:0x0419  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void s(ViewStructure viewStructure, ba0 ba0Var, AutofillId autofillId, String str, iw0 iw0Var) {
        int i;
        long j;
        long j2;
        char c;
        long j3;
        boolean z;
        oc1 oc1Var;
        x8 x8Var;
        a6 a6Var;
        iy0 iy0Var;
        i5 i5Var;
        boolean z2;
        jl jlVar;
        Boolean bool;
        boolean z3;
        Integer num;
        int i2;
        List list;
        Integer valueOf;
        int i3;
        Integer num2;
        boolean z4;
        String[] u;
        boolean z5;
        boolean z6;
        boolean z7;
        String u2;
        String[] u3;
        boolean z8;
        String[] u4;
        AutofillValue forText;
        hk0 hk0Var;
        long[] jArr;
        Object[] objArr;
        int i4;
        long[] jArr2;
        Object[] objArr2;
        hk0 hk0Var2;
        oc1 oc1Var2;
        x8 x8Var2;
        a6 a6Var2;
        iy0 iy0Var2;
        q21 q21Var = n21.a;
        q21 q21Var2 = c21.a;
        d21 x = ba0Var.x();
        int i5 = 8;
        if (x != null && (hk0Var2 = x.e) != null) {
            Object[] objArr3 = hk0Var2.b;
            j = 128;
            Object[] objArr4 = hk0Var2.c;
            long[] jArr3 = hk0Var2.a;
            int length = jArr3.length - 2;
            i = 2;
            if (length >= 0) {
                z = true;
                int i6 = 0;
                i5Var = null;
                j2 = 255;
                z2 = false;
                oc1Var2 = null;
                x8Var2 = null;
                a6Var2 = null;
                jlVar = null;
                bool = null;
                iy0Var2 = null;
                z3 = false;
                num = null;
                c = 7;
                while (true) {
                    long j4 = jArr3[i6];
                    j3 = -9187201950435737472L;
                    if ((((~j4) << 7) & j4 & (-9187201950435737472L)) != -9187201950435737472L) {
                        int i7 = 8 - ((~(i6 - length)) >>> 31);
                        for (int i8 = 0; i8 < i7; i8++) {
                            if ((j4 & 255) < 128) {
                                int i9 = (i6 << 3) + i8;
                                Object obj = objArr3[i9];
                                Object obj2 = objArr4[i9];
                                q21 q21Var3 = (q21) obj;
                                if (k70.p(q21Var3, n21.s)) {
                                    obj2.getClass();
                                    i5Var = (i5) obj2;
                                } else if (k70.p(q21Var3, n21.a)) {
                                    obj2.getClass();
                                    CharSequence charSequence = (String) tg.R((List) obj2);
                                    if (charSequence != null) {
                                        viewStructure.setContentDescription(charSequence);
                                    }
                                } else if (k70.p(q21Var3, n21.r)) {
                                    obj2.getClass();
                                    jlVar = (jl) obj2;
                                } else if (k70.p(q21Var3, n21.t)) {
                                    obj2.getClass();
                                    a6Var2 = (a6) obj2;
                                } else if (k70.p(q21Var3, n21.F)) {
                                    obj2.getClass();
                                    x8Var2 = (x8) obj2;
                                } else if (k70.p(q21Var3, n21.l)) {
                                    obj2.getClass();
                                    viewStructure.setFocused(((Boolean) obj2).booleanValue());
                                } else if (k70.p(q21Var3, n21.N)) {
                                    obj2.getClass();
                                    num = (Integer) obj2;
                                } else if (k70.p(q21Var3, n21.J)) {
                                    z3 = true;
                                } else if (k70.p(q21Var3, n21.o)) {
                                    obj2.getClass();
                                    z = ((Boolean) obj2).booleanValue();
                                } else if (k70.p(q21Var3, n21.y)) {
                                    obj2.getClass();
                                    iy0Var2 = (iy0) obj2;
                                } else if (k70.p(q21Var3, n21.H)) {
                                    obj2.getClass();
                                    bool = (Boolean) obj2;
                                } else if (k70.p(q21Var3, n21.I)) {
                                    obj2.getClass();
                                    oc1Var2 = (oc1) obj2;
                                } else if (k70.p(q21Var3, c21.b)) {
                                    viewStructure.setClickable(true);
                                } else if (k70.p(q21Var3, c21.c)) {
                                    viewStructure.setLongClickable(true);
                                } else if (k70.p(q21Var3, c21.v)) {
                                    viewStructure.setFocusable(true);
                                } else if (k70.p(q21Var3, c21.k)) {
                                    z2 = true;
                                }
                            }
                            j4 >>= 8;
                        }
                        if (i7 != 8) {
                            break;
                        }
                    }
                    if (i6 == length) {
                        break;
                    }
                    i6++;
                }
            } else {
                j2 = 255;
                c = 7;
                j3 = -9187201950435737472L;
                z = true;
                i5Var = null;
                z2 = false;
                oc1Var2 = null;
                x8Var2 = null;
                a6Var2 = null;
                jlVar = null;
                bool = null;
                iy0Var2 = null;
                z3 = false;
                num = null;
            }
            oc1Var = oc1Var2;
            x8Var = x8Var2;
            a6Var = a6Var2;
            iy0Var = iy0Var2;
        } else {
            i = 2;
            j = 128;
            j2 = 255;
            c = 7;
            j3 = -9187201950435737472L;
            z = true;
            oc1Var = null;
            x8Var = null;
            a6Var = null;
            iy0Var = null;
            i5Var = null;
            z2 = false;
            jlVar = null;
            bool = null;
            z3 = false;
            num = null;
        }
        d21 x2 = ba0Var.x();
        if (x2 != null && x2.g && !x2.h) {
            x2 = x2.b();
            ak0 ak0Var = new ak0(((nk0) ba0Var.n()).e.g);
            ak0Var.c(ba0Var.n());
            while (ak0Var.i()) {
                ba0 ba0Var2 = (ba0) ak0Var.k(ak0Var.b - 1);
                d21 x3 = ba0Var2.x();
                if (x3 != null && !x3.g) {
                    x2.e(x3);
                    if (!x3.h) {
                        ak0Var.c(ba0Var2.n());
                    }
                }
            }
        }
        if (x2 != null && (hk0Var = x2.e) != null) {
            Object[] objArr5 = hk0Var.b;
            Object[] objArr6 = hk0Var.c;
            long[] jArr4 = hk0Var.a;
            int length2 = jArr4.length - 2;
            i2 = 1;
            if (length2 >= 0) {
                int i10 = 0;
                list = null;
                while (true) {
                    long j5 = jArr4[i10];
                    int i11 = i5;
                    int i12 = i10;
                    if ((((~j5) << c) & j5 & j3) != j3) {
                        int i13 = 8 - ((~(i12 - length2)) >>> 31);
                        int i14 = 0;
                        while (i14 < i13) {
                            if ((j5 & j2) < j) {
                                int i15 = (i12 << 3) + i14;
                                Object obj3 = objArr5[i15];
                                Object obj4 = objArr6[i15];
                                jArr2 = jArr4;
                                q21 q21Var4 = (q21) obj3;
                                objArr2 = objArr5;
                                if (k70.p(q21Var4, n21.j)) {
                                    viewStructure.setEnabled(false);
                                } else if (k70.p(q21Var4, n21.B)) {
                                    obj4.getClass();
                                    list = (List) obj4;
                                }
                            } else {
                                jArr2 = jArr4;
                                objArr2 = objArr5;
                            }
                            j5 >>= i11;
                            i14++;
                            objArr5 = objArr2;
                            jArr4 = jArr2;
                        }
                        jArr = jArr4;
                        objArr = objArr5;
                        i4 = i11;
                        if (i13 != i4) {
                            break;
                        }
                    } else {
                        jArr = jArr4;
                        objArr = objArr5;
                        i4 = i11;
                    }
                    if (i12 == length2) {
                        break;
                    }
                    i10 = i12 + 1;
                    i5 = i4;
                    objArr5 = objArr;
                    jArr4 = jArr;
                }
                valueOf = Integer.valueOf(ba0Var.f);
                if (ba0Var.v() == null) {
                    valueOf = null;
                }
                if (valueOf == null) {
                    i3 = valueOf.intValue();
                } else {
                    i3 = -1;
                }
                viewStructure.setAutofillId(autofillId, i3);
                viewStructure.setId(i3, str, null, null);
                if (i5Var == null) {
                    num2 = Integer.valueOf(i5Var.a);
                } else if (z2) {
                    num2 = Integer.valueOf(i2);
                } else if (oc1Var != null) {
                    num2 = Integer.valueOf(i);
                } else {
                    num2 = null;
                }
                if (num2 != null) {
                    viewStructure.setAutofillType(num2.intValue());
                }
                if (x8Var != null) {
                    String str2 = x8Var.f;
                    if (str2.length() >= 5000) {
                        if (Character.isHighSurrogate(str2.charAt(4999)) && Character.isLowSurrogate(str2.charAt(5000))) {
                            str2 = q81.J(str2, 4999);
                        } else {
                            str2 = q81.J(str2, 5000);
                        }
                    }
                    forText = AutofillValue.forText(str2);
                    viewStructure.setAutofillValue(forText);
                }
                if (a6Var != null) {
                    viewStructure.setAutofillValue(a6Var.a);
                }
                if (jlVar != null && (u4 = a5.u(jlVar)) != null) {
                    viewStructure.setAutofillHints(u4);
                }
                iw0Var.a.h(ba0Var.f, new ot0(viewStructure));
                if (bool != null) {
                    viewStructure.setSelected(bool.booleanValue());
                }
                int i16 = 4;
                if (oc1Var == null) {
                    viewStructure.setCheckable(i2);
                    if (oc1Var == oc1.e) {
                        z8 = true;
                    } else {
                        z8 = false;
                    }
                    viewStructure.setChecked(z8);
                } else if (bool != null && (iy0Var == null || iy0Var.a != 4)) {
                    z4 = true;
                    viewStructure.setCheckable(true);
                    viewStructure.setChecked(bool.booleanValue());
                    jl.a.getClass();
                    u = a5.u(il.b);
                    u.getClass();
                    if (u.length != 0) {
                        String str3 = u[0];
                        if (jlVar != null && (u3 = a5.u(jlVar)) != null && ba.f0(u3, str3) >= 0) {
                            z5 = z4;
                        } else {
                            z5 = false;
                        }
                        if (!z3 && !z5) {
                            z6 = false;
                        } else {
                            z6 = z4;
                        }
                        if (!z6 && !z) {
                            z7 = false;
                        } else {
                            z7 = z4;
                        }
                        viewStructure.setDataIsSensitive(z7);
                        if (!ba0Var.J.d.G0()) {
                            i16 = 0;
                        }
                        viewStructure.setVisibility(i16);
                        if (list != null) {
                            String str4 = "";
                            for (int i17 = 0; i17 < list.size(); i17++) {
                                str4 = str4 + ((x8) list.get(i17)).f + '\n';
                            }
                            viewStructure.setText(str4);
                            viewStructure.setClassName("android.widget.TextView");
                        }
                        if (((nk0) ba0Var.n()).isEmpty() && iy0Var != null && (u2 = nb0.u(iy0Var.a)) != null) {
                            viewStructure.setClassName(u2);
                        }
                        if (z2) {
                            viewStructure.setClassName("android.widget.EditText");
                            if (Build.VERSION.SDK_INT >= 28 && num != null) {
                                z0.m(viewStructure, num.intValue());
                            }
                            if (z6) {
                                viewStructure.setInputType(129);
                                return;
                            }
                            return;
                        }
                        return;
                    }
                    throw new NoSuchElementException("Array is empty.");
                }
                z4 = true;
                jl.a.getClass();
                u = a5.u(il.b);
                u.getClass();
                if (u.length != 0) {
                }
            }
        } else {
            i2 = 1;
        }
        list = null;
        valueOf = Integer.valueOf(ba0Var.f);
        if (ba0Var.v() == null) {
        }
        if (valueOf == null) {
        }
        viewStructure.setAutofillId(autofillId, i3);
        viewStructure.setId(i3, str, null, null);
        if (i5Var == null) {
        }
        if (num2 != null) {
        }
        if (x8Var != null) {
        }
        if (a6Var != null) {
        }
        if (jlVar != null) {
            viewStructure.setAutofillHints(u4);
        }
        iw0Var.a.h(ba0Var.f, new ot0(viewStructure));
        if (bool != null) {
        }
        int i162 = 4;
        if (oc1Var == null) {
        }
        z4 = true;
        jl.a.getClass();
        u = a5.u(il.b);
        u.getClass();
        if (u.length != 0) {
        }
    }

    public static final void t(float[] fArr) {
        if (fArr.length < 16) {
            return;
        }
        fArr[0] = 1.0f;
        fArr[1] = 0.0f;
        fArr[2] = 0.0f;
        fArr[3] = 0.0f;
        fArr[4] = 0.0f;
        fArr[5] = 1.0f;
        fArr[6] = 0.0f;
        fArr[7] = 0.0f;
        fArr[8] = 0.0f;
        fArr[9] = 0.0f;
        fArr[10] = 1.0f;
        fArr[11] = 0.0f;
        fArr[12] = 0.0f;
        fArr[13] = 0.0f;
        fArr[14] = 0.0f;
        fArr[15] = 1.0f;
    }

    public static void u(Window window, boolean z) {
        int i;
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 35) {
            g1.e(window, z);
        } else if (i2 >= 30) {
            g1.d(window, z);
        } else {
            View decorView = window.getDecorView();
            int systemUiVisibility = decorView.getSystemUiVisibility();
            if (z) {
                i = systemUiVisibility & (-1793);
            } else {
                i = systemUiVisibility | 1792;
            }
            decorView.setSystemUiVisibility(i);
        }
    }

    public static final void v(zo0 zo0Var, int i, Object obj) {
        zo0Var.f[(zo0Var.g - zo0Var.b[zo0Var.c - 1].b) + i] = obj;
    }

    public static final void w(zo0 zo0Var, int i, Object obj, int i2, Object obj2) {
        int i3 = zo0Var.g - zo0Var.b[zo0Var.c - 1].b;
        Object[] objArr = zo0Var.f;
        objArr[i + i3] = obj;
        objArr[i3 + i2] = obj2;
    }

    public static final Rect x(r60 r60Var) {
        return new Rect(r60Var.a, r60Var.b, r60Var.c, r60Var.d);
    }

    public static void y(float[] fArr, float f, float f2) {
        if (fArr.length < 16) {
            return;
        }
        float f3 = (fArr[8] * 0.0f) + (fArr[4] * f2) + (fArr[0] * f) + fArr[12];
        float f4 = (fArr[9] * 0.0f) + (fArr[5] * f2) + (fArr[1] * f) + fArr[13];
        float f5 = (fArr[10] * 0.0f) + (fArr[6] * f2) + (fArr[2] * f) + fArr[14];
        float f6 = fArr[3] * f;
        float f7 = fArr[11] * 0.0f;
        fArr[12] = f3;
        fArr[13] = f4;
        fArr[14] = f5;
        fArr[15] = f7 + (fArr[7] * f2) + f6 + fArr[15];
    }

    public abstract String f(byte[] bArr, int i, int i2);

    public abstract int g(String str, byte[] bArr, int i, int i2);
}