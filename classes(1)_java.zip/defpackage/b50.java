package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: b50  reason: default package */
public abstract /* synthetic */ class b50 {
    public static final /* synthetic */ int[] a;

    static {
        int[] iArr = new int[w40.values().length];
        try {
            iArr[2] = 1;
        } catch (NoSuchFieldError unused) {
        }
        a = iArr;
    }
}