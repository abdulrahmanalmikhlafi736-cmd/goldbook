package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: a30  reason: default package */
public final class a30 {
    public final long a;
    public final long b;
    public final float c;
    public final long d;
    public final long e;

    public a30(long j, long j2, float f, long j3, long j4) {
        this.a = j;
        this.b = j2;
        this.c = f;
        this.d = j3;
        this.e = j4;
    }

    public final String toString() {
        return "HistoricalChange(uptimeMillis=" + this.a + ", position=" + ((Object) xm0.h(this.b)) + ", scaleGestureFactor=" + this.c + ", panGestureOffset=" + ((Object) xm0.h(this.d)) + ')';
    }
}