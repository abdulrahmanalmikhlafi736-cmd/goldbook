package defpackage;

import android.graphics.BlendMode;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: b1 */
public abstract /* synthetic */ class b1 {
    public static /* bridge */ /* synthetic */ BlendMode A() {
        return BlendMode.EXCLUSION;
    }

    public static /* bridge */ /* synthetic */ BlendMode B() {
        return BlendMode.MULTIPLY;
    }

    public static /* bridge */ /* synthetic */ BlendMode C() {
        return BlendMode.HUE;
    }

    public static /* bridge */ /* synthetic */ BlendMode D() {
        return BlendMode.SATURATION;
    }

    public static /* bridge */ /* synthetic */ BlendMode a() {
        return BlendMode.CLEAR;
    }

    public static /* bridge */ /* synthetic */ BlendMode d() {
        return BlendMode.COLOR_BURN;
    }

    public static /* bridge */ /* synthetic */ BlendMode f() {
        return BlendMode.COLOR;
    }

    public static /* bridge */ /* synthetic */ BlendMode g() {
        return BlendMode.DST_ATOP;
    }

    public static /* bridge */ /* synthetic */ BlendMode h() {
        return BlendMode.LUMINOSITY;
    }

    public static /* bridge */ /* synthetic */ BlendMode i() {
        return BlendMode.SRC_OVER;
    }

    public static /* bridge */ /* synthetic */ BlendMode j() {
        return BlendMode.DST;
    }

    public static /* bridge */ /* synthetic */ BlendMode k() {
        return BlendMode.DST_OVER;
    }

    public static /* bridge */ /* synthetic */ BlendMode l() {
        return BlendMode.SRC_IN;
    }

    public static /* bridge */ /* synthetic */ BlendMode m() {
        return BlendMode.DST_IN;
    }

    public static /* bridge */ /* synthetic */ BlendMode n() {
        return BlendMode.SRC_OUT;
    }

    public static /* bridge */ /* synthetic */ BlendMode o() {
        return BlendMode.DST_OUT;
    }

    public static /* bridge */ /* synthetic */ BlendMode p() {
        return BlendMode.SRC;
    }

    public static /* bridge */ /* synthetic */ BlendMode r() {
        return BlendMode.SRC_ATOP;
    }

    public static /* bridge */ /* synthetic */ BlendMode s() {
        return BlendMode.XOR;
    }

    public static /* bridge */ /* synthetic */ BlendMode t() {
        return BlendMode.PLUS;
    }

    public static /* bridge */ /* synthetic */ BlendMode u() {
        return BlendMode.MODULATE;
    }

    public static /* bridge */ /* synthetic */ BlendMode v() {
        return BlendMode.SCREEN;
    }

    public static /* bridge */ /* synthetic */ BlendMode w() {
        return BlendMode.HARD_LIGHT;
    }

    public static /* bridge */ /* synthetic */ BlendMode y() {
        return BlendMode.SOFT_LIGHT;
    }

    public static /* bridge */ /* synthetic */ BlendMode z() {
        return BlendMode.DIFFERENCE;
    }
}