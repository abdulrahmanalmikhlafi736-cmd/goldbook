package defpackage;

import android.graphics.Rect;
import android.os.Build;
import android.view.View;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dk1  reason: default package */
public class dk1 {
    public static final hk1 b;
    public final hk1 a;

    static {
        uj1 nj1Var;
        int i = Build.VERSION.SDK_INT;
        if (i >= 36) {
            nj1Var = new tj1();
        } else if (i >= 35) {
            nj1Var = new sj1();
        } else if (i >= 34) {
            nj1Var = new rj1();
        } else if (i >= 31) {
            nj1Var = new qj1();
        } else if (i >= 30) {
            nj1Var = new pj1();
        } else if (i >= 29) {
            nj1Var = new oj1();
        } else {
            nj1Var = new nj1();
        }
        b = nj1Var.b().a.a().a.b().a.c();
    }

    public dk1(hk1 hk1Var) {
        this.a = hk1Var;
    }

    public void A(int i) {
    }

    public void B(Rect[][] rectArr) {
    }

    public void C(Rect[][] rectArr) {
    }

    public hk1 a() {
        return this.a;
    }

    public hk1 b() {
        return this.a;
    }

    public hk1 c() {
        return this.a;
    }

    public void d(View view) {
    }

    public void e(hk1 hk1Var) {
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof dk1)) {
            return false;
        }
        dk1 dk1Var = (dk1) obj;
        if (t() == dk1Var.t() && s() == dk1Var.s() && Objects.equals(n(), dk1Var.n()) && Objects.equals(l(), dk1Var.l()) && Objects.equals(h(), dk1Var.h())) {
            return true;
        }
        return false;
    }

    public List<Rect> f(int i) {
        return Collections.EMPTY_LIST;
    }

    public List<Rect> g(int i) {
        return Collections.EMPTY_LIST;
    }

    public mq h() {
        return null;
    }

    public int hashCode() {
        return Objects.hash(Boolean.valueOf(t()), Boolean.valueOf(s()), n(), l(), h());
    }

    public c60 i(int i) {
        return c60.e;
    }

    public c60 j(int i) {
        if ((i & 8) == 0) {
            return c60.e;
        }
        od.m("Unable to query the maximum insets for IME");
        return null;
    }

    public c60 k() {
        return n();
    }

    public c60 l() {
        return c60.e;
    }

    public c60 m() {
        return n();
    }

    public c60 n() {
        return c60.e;
    }

    public c60 o() {
        return n();
    }

    public void p(View view) {
    }

    public void q() {
    }

    public hk1 r(int i, int i2, int i3, int i4) {
        return b;
    }

    public boolean s() {
        return false;
    }

    public boolean t() {
        return false;
    }

    public boolean u(int i) {
        return true;
    }

    public void v(oq oqVar) {
    }

    public void w(c60[] c60VarArr) {
    }

    public void x(c60 c60Var) {
    }

    public void y(hk1 hk1Var) {
    }

    public void z(c60 c60Var) {
    }
}