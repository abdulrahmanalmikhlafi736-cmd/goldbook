package defpackage;

import java.util.Iterator;
import java.util.NoSuchElementException;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: c31  reason: default package */
public final class c31 implements Iterator, ml, w80 {
    public int e;
    public Object f;
    public ml g;

    public final RuntimeException a() {
        int i = this.e;
        if (i != 4) {
            if (i != 5) {
                return new IllegalStateException("Unexpected state of the iterator: " + this.e);
            }
            return new IllegalStateException("Iterator has failed.");
        }
        return new NoSuchElementException();
    }

    public final void b(Object obj, ox0 ox0Var) {
        this.f = obj;
        this.e = 3;
        this.g = ox0Var;
    }

    @Override // defpackage.ml
    public final sl e() {
        return st.e;
    }

    @Override // defpackage.ml
    public final void h(Object obj) {
        nb0.t(obj);
        this.e = 4;
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        int i;
        while (true) {
            i = this.e;
            if (i != 0) {
                break;
            }
            this.e = 5;
            ml mlVar = this.g;
            mlVar.getClass();
            this.g = null;
            mlVar.h(we1.a);
        }
        if (i != 1) {
            if (i == 2 || i == 3) {
                return true;
            }
            if (i == 4) {
                return false;
            }
            throw a();
        }
        throw null;
    }

    @Override // java.util.Iterator
    public final Object next() {
        int i = this.e;
        if (i != 0 && i != 1) {
            if (i != 2) {
                if (i == 3) {
                    this.e = 0;
                    Object obj = this.f;
                    this.f = null;
                    return obj;
                }
                throw a();
            }
            this.e = 1;
            throw null;
        } else if (hasNext()) {
            return next();
        } else {
            od.n();
            return null;
        }
    }

    @Override // java.util.Iterator
    public final void remove() {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }
}