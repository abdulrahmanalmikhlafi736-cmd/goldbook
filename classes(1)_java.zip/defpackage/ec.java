package defpackage;

import android.app.Activity;
import android.content.ContextWrapper;
import android.graphics.Rect;
import android.view.WindowManager;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ec  reason: default package */
public final class ec implements dc, uk1 {
    public static final ec e = new Object();
    public static final ec f = new Object();

    @Override // defpackage.uk1
    public qk1 b(ContextWrapper contextWrapper, kp kpVar) {
        kpVar.getClass();
        float f2 = contextWrapper.getResources().getDisplayMetrics().density;
        Rect bounds = ((WindowManager) contextWrapper.getSystemService(WindowManager.class)).getCurrentWindowMetrics().getBounds();
        bounds.getClass();
        return new qk1(bounds, f2);
    }

    @Override // defpackage.dc
    public Rect g(Activity activity) {
        Rect bounds = ((WindowManager) activity.getSystemService(WindowManager.class)).getCurrentWindowMetrics().getBounds();
        bounds.getClass();
        return bounds;
    }
}