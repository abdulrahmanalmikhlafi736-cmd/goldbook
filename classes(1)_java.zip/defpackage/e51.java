package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: e51  reason: default package */
public final class e51 implements sq {
    public final g51 e;
    public final long f;
    public final Object g;
    public final ne h;

    public e51(g51 g51Var, long j, Object obj, ne neVar) {
        this.e = g51Var;
        this.f = j;
        this.g = obj;
        this.h = neVar;
    }

    @Override // defpackage.sq
    public final void a() {
        g51 g51Var = this.e;
        synchronized (g51Var) {
            if (this.f < g51Var.o()) {
                return;
            }
            Object[] objArr = g51Var.l;
            objArr.getClass();
            long j = this.f;
            if (objArr[((int) j) & (objArr.length - 1)] != this) {
                return;
            }
            k70.n(objArr, j, k70.t);
            g51Var.i();
        }
    }
}