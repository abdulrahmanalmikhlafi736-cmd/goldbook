package defpackage;

import android.content.Context;
import android.webkit.WebView;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: a2  reason: default package */
public final /* synthetic */ class a2 implements i00 {
    public final /* synthetic */ int e;
    public final /* synthetic */ i00 f;

    public /* synthetic */ a2(i00 i00Var, int i) {
        this.e = i;
        this.f = i00Var;
    }

    @Override // defpackage.i00
    public final Object i(Object obj) {
        int i = this.e;
        i00 i00Var = this.f;
        switch (i) {
            case 0:
                WebView webView = (WebView) obj;
                webView.getClass();
                i00Var.i(webView);
                return we1.a;
            case 1:
                kd1 kd1Var = (kd1) obj;
                if (kd1Var instanceof p10) {
                    Boolean bool = (Boolean) i00Var.i(((p10) kd1Var).s);
                    bool.getClass();
                    return bool;
                }
                od.p("Node is not a GestureNode instance");
                return null;
            case 2:
                g61 g61Var = (g61) i00Var.i((l61) obj);
                synchronized (n61.c) {
                    n61.d = n61.d.f(g61Var.g());
                }
                return g61Var;
            case 3:
                Long l = (Long) obj;
                l.getClass();
                return i00Var.i(l);
            default:
                Context context = (Context) obj;
                context.getClass();
                return (WebView) i00Var.i(new di1(context));
        }
    }
}