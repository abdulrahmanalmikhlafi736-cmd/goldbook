package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bc0  reason: default package */
public final /* synthetic */ class bc0 implements xz {
    public final /* synthetic */ int e;
    public final /* synthetic */ dc0 f;

    public /* synthetic */ bc0(dc0 dc0Var, int i) {
        this.e = i;
        this.f = dc0Var;
    }

    @Override // defpackage.xz
    public final Object a() {
        float f;
        long g;
        int i = this.e;
        dc0 dc0Var = this.f;
        switch (i) {
            case 0:
                sc0 sc0Var = dc0Var.t.b;
                return Float.valueOf((((iq0) sc0Var.e.b).g() * 500) + ((iq0) sc0Var.e.c).g());
            case 1:
                sc0 sc0Var2 = dc0Var.t.b;
                int g2 = ((iq0) sc0Var2.e.b).g();
                int g3 = ((iq0) sc0Var2.e.c).g();
                if (sc0Var2.c()) {
                    f = (g2 * 500) + g3 + 100.0f;
                } else {
                    f = (g2 * 500) + g3;
                }
                return Float.valueOf(f);
            default:
                sc0 sc0Var3 = dc0Var.t.b;
                if (sc0Var3.g().o == bp0.e) {
                    g = sc0Var3.g().g() & 4294967295L;
                } else {
                    g = sc0Var3.g().g() >> 32;
                }
                int i2 = (int) g;
                sc0 sc0Var4 = dc0Var.t.b;
                return Float.valueOf(i2 - ((-sc0Var4.g().l) + sc0Var4.g().p));
        }
    }
}