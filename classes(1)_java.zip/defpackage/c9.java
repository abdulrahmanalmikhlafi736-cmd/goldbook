package defpackage;

import android.view.WindowManager;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: c9  reason: default package */
public final class c9 {
    public static final c9 a = new Object();

    public final void a(WindowManager.LayoutParams layoutParams) {
        layoutParams.layoutInDisplayCutoutMode = 3;
    }
}