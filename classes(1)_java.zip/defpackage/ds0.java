package defpackage;

import java.util.Arrays;
import java.util.ListIterator;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ds0  reason: default package */
public final class ds0 extends c0 {
    public final Object[] e;
    public final Object[] f;
    public final int g;
    public final int h;

    public ds0(Object[] objArr, Object[] objArr2, int i, int i2) {
        boolean z;
        this.e = objArr;
        this.f = objArr2;
        this.g = i;
        this.h = i2;
        if (a() > 32) {
            z = true;
        } else {
            z = false;
        }
        if (!z) {
            rt0.a("Trie-based persistent vector should have at least 33 elements, got " + a());
        }
        int length = objArr2.length;
    }

    public static Object[] j(Object[] objArr, int i, int i2, Object obj, k1 k1Var) {
        Object[] copyOf;
        int q = ua0.q(i2, i);
        if (i == 0) {
            if (q == 0) {
                copyOf = new Object[32];
            } else {
                copyOf = Arrays.copyOf(objArr, 32);
            }
            ba.Y(objArr, copyOf, q + 1, q, 31);
            k1Var.a = objArr[31];
            copyOf[q] = obj;
            return copyOf;
        }
        Object[] copyOf2 = Arrays.copyOf(objArr, 32);
        int i3 = i - 5;
        Object obj2 = objArr[q];
        obj2.getClass();
        copyOf2[q] = j((Object[]) obj2, i3, i2, obj, k1Var);
        while (true) {
            q++;
            if (q >= 32 || copyOf2[q] == null) {
                break;
            }
            Object obj3 = objArr[q];
            obj3.getClass();
            copyOf2[q] = j((Object[]) obj3, i3, 0, k1Var.a, k1Var);
        }
        return copyOf2;
    }

    public static Object[] l(Object[] objArr, int i, int i2, k1 k1Var) {
        Object[] l;
        int q = ua0.q(i2, i);
        if (i == 5) {
            k1Var.a = objArr[q];
            l = null;
        } else {
            Object obj = objArr[q];
            obj.getClass();
            l = l((Object[]) obj, i - 5, i2, k1Var);
        }
        if (l == null && q == 0) {
            return null;
        }
        Object[] copyOf = Arrays.copyOf(objArr, 32);
        copyOf[q] = l;
        return copyOf;
    }

    public static Object[] r(Object[] objArr, int i, int i2, Object obj) {
        int q = ua0.q(i2, i);
        Object[] copyOf = Arrays.copyOf(objArr, 32);
        if (i == 0) {
            copyOf[q] = obj;
            return copyOf;
        }
        Object obj2 = copyOf[q];
        obj2.getClass();
        copyOf[q] = r((Object[]) obj2, i - 5, i2, obj);
        return copyOf;
    }

    @Override // defpackage.m
    public final int a() {
        return this.g;
    }

    @Override // defpackage.c0
    public final c0 b(int i, Object obj) {
        int i2 = this.g;
        kb0.g(i, i2);
        if (i == i2) {
            return c(obj);
        }
        int q = q();
        Object[] objArr = this.e;
        if (i >= q) {
            return k(objArr, i - q, obj);
        }
        k1 k1Var = new k1(null);
        return k(j(objArr, this.h, i, obj, k1Var), 0, k1Var.a);
    }

    @Override // defpackage.c0
    public final c0 c(Object obj) {
        int q = q();
        int i = this.g;
        int i2 = i - q;
        Object[] objArr = this.e;
        Object[] objArr2 = this.f;
        if (i2 < 32) {
            Object[] copyOf = Arrays.copyOf(objArr2, 32);
            copyOf[i2] = obj;
            return new ds0(objArr, copyOf, i + 1, this.h);
        }
        Object[] objArr3 = new Object[32];
        objArr3[0] = obj;
        return m(objArr, objArr2, objArr3);
    }

    @Override // defpackage.c0
    public final es0 f() {
        return new es0(this, this.e, this.f, this.h);
    }

    @Override // defpackage.c0
    public final c0 g(b0 b0Var) {
        es0 es0Var = new es0(this, this.e, this.f, this.h);
        es0Var.z(b0Var);
        return es0Var.c();
    }

    @Override // java.util.List
    public final Object get(int i) {
        Object[] objArr;
        kb0.f(i, a());
        if (q() <= i) {
            objArr = this.f;
        } else {
            Object[] objArr2 = this.e;
            for (int i2 = this.h; i2 > 0; i2 -= 5) {
                Object[] objArr3 = objArr2[ua0.q(i, i2)];
                objArr3.getClass();
                objArr2 = objArr3;
            }
            objArr = objArr2;
        }
        return objArr[i & 31];
    }

    @Override // defpackage.c0
    public final c0 h(int i) {
        kb0.f(i, a());
        int q = q();
        int i2 = this.h;
        Object[] objArr = this.e;
        if (i >= q) {
            return p(objArr, q, i2, i - q);
        }
        return p(o(objArr, i2, i, new k1(this.f[0])), q, i2, 0);
    }

    @Override // defpackage.c0
    public final c0 i(int i, Object obj) {
        int i2 = this.g;
        kb0.f(i, i2);
        int q = q();
        Object[] objArr = this.e;
        Object[] objArr2 = this.f;
        int i3 = this.h;
        if (q <= i) {
            Object[] copyOf = Arrays.copyOf(objArr2, 32);
            copyOf[i & 31] = obj;
            return new ds0(objArr, copyOf, i2, i3);
        }
        return new ds0(r(objArr, i3, i, obj), objArr2, i2, i3);
    }

    public final ds0 k(Object[] objArr, int i, Object obj) {
        int q = q();
        int i2 = this.g;
        int i3 = i2 - q;
        Object[] objArr2 = this.f;
        Object[] copyOf = Arrays.copyOf(objArr2, 32);
        if (i3 < 32) {
            ba.Y(objArr2, copyOf, i + 1, i, i3);
            copyOf[i] = obj;
            return new ds0(objArr, copyOf, i2 + 1, this.h);
        }
        Object obj2 = objArr2[31];
        ba.Y(objArr2, copyOf, i + 1, i, i3 - 1);
        copyOf[i] = obj;
        Object[] objArr3 = new Object[32];
        objArr3[0] = obj2;
        return m(objArr, copyOf, objArr3);
    }

    @Override // defpackage.v, java.util.List
    public final ListIterator listIterator(int i) {
        kb0.g(i, this.g);
        return new fs0(this.e, this.f, i, this.g, (this.h / 5) + 1);
    }

    public final ds0 m(Object[] objArr, Object[] objArr2, Object[] objArr3) {
        int i = this.g;
        int i2 = i >> 5;
        int i3 = this.h;
        if (i2 > (1 << i3)) {
            Object[] objArr4 = new Object[32];
            objArr4[0] = objArr;
            int i4 = i3 + 5;
            return new ds0(n(i4, objArr4, objArr2), objArr3, i + 1, i4);
        }
        return new ds0(n(i3, objArr, objArr2), objArr3, i + 1, i3);
    }

    public final Object[] n(int i, Object[] objArr, Object[] objArr2) {
        Object[] objArr3;
        int q = ua0.q(a() - 1, i);
        if (objArr != null) {
            objArr3 = Arrays.copyOf(objArr, 32);
        } else {
            objArr3 = new Object[32];
        }
        if (i == 5) {
            objArr3[q] = objArr2;
            return objArr3;
        }
        objArr3[q] = n(i - 5, (Object[]) objArr3[q], objArr2);
        return objArr3;
    }

    public final Object[] o(Object[] objArr, int i, int i2, k1 k1Var) {
        Object[] copyOf;
        int q = ua0.q(i2, i);
        int i3 = 31;
        if (i == 0) {
            if (q == 0) {
                copyOf = new Object[32];
            } else {
                copyOf = Arrays.copyOf(objArr, 32);
            }
            ba.Y(objArr, copyOf, q, q + 1, 32);
            copyOf[31] = k1Var.a;
            k1Var.a = objArr[q];
            return copyOf;
        }
        if (objArr[31] == null) {
            i3 = ua0.q(q() - 1, i);
        }
        Object[] copyOf2 = Arrays.copyOf(objArr, 32);
        int i4 = i - 5;
        int i5 = q + 1;
        if (i5 <= i3) {
            while (true) {
                Object obj = copyOf2[i3];
                obj.getClass();
                copyOf2[i3] = o((Object[]) obj, i4, 0, k1Var);
                if (i3 == i5) {
                    break;
                }
                i3--;
            }
        }
        Object obj2 = copyOf2[q];
        obj2.getClass();
        copyOf2[q] = o((Object[]) obj2, i4, i2, k1Var);
        return copyOf2;
    }

    public final c0 p(Object[] objArr, int i, int i2, int i3) {
        int i4 = this.g - i;
        if (i4 == 1) {
            if (i2 == 0) {
                if (objArr.length == 33) {
                    objArr = Arrays.copyOf(objArr, 32);
                }
                return new b61(objArr);
            }
            k1 k1Var = new k1(null);
            Object[] l = l(objArr, i2, i - 1, k1Var);
            l.getClass();
            Object obj = k1Var.a;
            obj.getClass();
            Object[] objArr2 = (Object[]) obj;
            if (l[1] == null) {
                Object obj2 = l[0];
                obj2.getClass();
                return new ds0((Object[]) obj2, objArr2, i, i2 - 5);
            }
            return new ds0(l, objArr2, i, i2);
        }
        Object[] objArr3 = this.f;
        Object[] copyOf = Arrays.copyOf(objArr3, 32);
        int i5 = i4 - 1;
        if (i3 < i5) {
            ba.Y(objArr3, copyOf, i3, i3 + 1, i4);
        }
        copyOf[i5] = null;
        return new ds0(objArr, copyOf, (i + i4) - 1, i2);
    }

    public final int q() {
        return (this.g - 1) & (-32);
    }
}