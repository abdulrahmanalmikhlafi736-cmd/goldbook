package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dl  reason: default package */
public final class dl {
    public final tc a;
    public final ne b;

    public dl(tc tcVar, ne neVar) {
        this.a = tcVar;
        this.b = neVar;
    }

    public final String toString() {
        ne neVar = this.b;
        if (neVar.i.k(xl.f) == null) {
            StringBuilder sb = new StringBuilder("Request@");
            int hashCode = hashCode();
            a5.l(16);
            String num = Integer.toString(hashCode, 16);
            num.getClass();
            sb.append(num);
            sb.append("(currentBounds()=");
            sb.append(this.a.a());
            sb.append(", continuation=");
            sb.append(neVar);
            sb.append(')');
            return sb.toString();
        }
        od.d();
        return null;
    }
}