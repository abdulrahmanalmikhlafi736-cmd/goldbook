package defpackage;

import android.graphics.Paint;
import android.graphics.Shader;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dd  reason: default package */
public final class dd extends zi1 {
    public cz0 G;
    public long H = 9205357640488583168L;
    public final /* synthetic */ Shader I;

    public dd(Shader shader) {
        this.I = shader;
    }

    @Override // defpackage.zi1
    public final void l(float f, long j, k6 k6Var) {
        Shader shader;
        Paint paint = k6Var.a;
        cz0 cz0Var = this.G;
        Shader shader2 = null;
        if (cz0Var == null || !s51.a(this.H, j)) {
            if (s51.c(j)) {
                this.G = null;
                this.H = 9205357640488583168L;
                cz0Var = null;
            } else {
                cz0Var = this.G;
                if (cz0Var == null) {
                    cz0Var = new cz0(6, false);
                    this.G = cz0Var;
                }
                cz0Var.f = this.I;
                this.G = cz0Var;
                this.H = j;
            }
        }
        long d = wl1.d(paint.getColor());
        long j2 = zg.b;
        if (!zg.c(d, j2)) {
            k6Var.c(j2);
        }
        Shader shader3 = k6Var.c;
        if (cz0Var != null) {
            shader = (Shader) cz0Var.f;
        } else {
            shader = null;
        }
        if (!k70.p(shader3, shader)) {
            if (cz0Var != null) {
                shader2 = (Shader) cz0Var.f;
            }
            k6Var.c = shader2;
            paint.setShader(shader2);
        }
        if (paint.getAlpha() / 255.0f == f) {
            return;
        }
        k6Var.a(f);
    }
}