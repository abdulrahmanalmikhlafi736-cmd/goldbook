package defpackage;

import java.io.Serializable;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ef  reason: default package */
public final class ef implements uw {
    public final /* synthetic */ int e;
    public final /* synthetic */ Serializable f;
    public final /* synthetic */ Object g;
    public final /* synthetic */ Object h;
    public final /* synthetic */ Object i;

    public /* synthetic */ ef(Serializable serializable, Object obj, Object obj2, Object obj3, int i) {
        this.e = i;
        this.f = serializable;
        this.g = obj;
        this.h = obj2;
        this.i = obj3;
    }

    /* JADX WARN: Removed duplicated region for block: B:58:0x00b4  */
    /* JADX WARN: Removed duplicated region for block: B:61:0x00c5  */
    @Override // defpackage.uw
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object k(Object obj, ml mlVar) {
        df dfVar;
        int i;
        boolean z;
        boolean z2;
        boolean z3;
        int i2 = this.e;
        we1 we1Var = we1.a;
        boolean z4 = true;
        Serializable serializable = this.f;
        boolean z5 = false;
        switch (i2) {
            case 0:
                if (mlVar instanceof df) {
                    dfVar = (df) mlVar;
                    int i3 = dfVar.l;
                    if ((i3 & Integer.MIN_VALUE) != 0) {
                        dfVar.l = i3 - Integer.MIN_VALUE;
                        Object obj2 = dfVar.j;
                        i = dfVar.l;
                        if (i == 0) {
                            if (i == 1) {
                                obj = dfVar.i;
                                this = dfVar.h;
                                nb0.t(obj2);
                            } else {
                                od.p("call to 'resume' before 'invoke' with coroutine");
                                return null;
                            }
                        } else {
                            nb0.t(obj2);
                            a80 a80Var = (a80) ((nw0) serializable).e;
                            if (a80Var != null) {
                                a80Var.a(new nf("Child of the scoped flow was cancelled", 0));
                                dfVar.h = this;
                                dfVar.i = obj;
                                dfVar.l = 1;
                                Object v = a80Var.v(dfVar);
                                cm cmVar = cm.e;
                                if (v == cmVar) {
                                    return cmVar;
                                }
                            }
                        }
                        ((nw0) this.f).e = wl1.B((bm) this.g, null, new cf((ff) this.h, (uw) this.i, obj, null), 1);
                        return we1Var;
                    }
                }
                dfVar = new df(this, mlVar);
                Object obj22 = dfVar.j;
                i = dfVar.l;
                if (i == 0) {
                }
                ((nw0) this.f).e = wl1.B((bm) this.g, null, new cf((ff) this.h, (uw) this.i, obj, null), 1);
                return we1Var;
            default:
                y60 y60Var = (y60) obj;
                lw0 lw0Var = (lw0) this.h;
                lw0 lw0Var2 = (lw0) this.g;
                lw0 lw0Var3 = (lw0) serializable;
                if (y60Var instanceof ou0) {
                    lw0Var3.e++;
                } else if (y60Var instanceof pu0) {
                    lw0Var3.e--;
                } else if (y60Var instanceof nu0) {
                    lw0Var3.e--;
                } else if (y60Var instanceof m30) {
                    lw0Var2.e++;
                } else if (y60Var instanceof n30) {
                    lw0Var2.e--;
                } else if (y60Var instanceof yx) {
                    lw0Var.e++;
                } else if (y60Var instanceof zx) {
                    lw0Var.e--;
                }
                if (lw0Var3.e > 0) {
                    z = true;
                } else {
                    z = false;
                }
                if (lw0Var2.e > 0) {
                    z2 = true;
                } else {
                    z2 = false;
                }
                if (lw0Var.e > 0) {
                    z3 = true;
                } else {
                    z3 = false;
                }
                bo boVar = (bo) this.i;
                if (boVar.t != z) {
                    boVar.t = z;
                    z5 = true;
                }
                if (boVar.u != z2) {
                    boVar.u = z2;
                    z5 = true;
                }
                if (boVar.v != z3) {
                    boVar.v = z3;
                } else {
                    z4 = z5;
                }
                if (z4) {
                    a5.x(boVar);
                }
                return we1Var;
        }
    }
}