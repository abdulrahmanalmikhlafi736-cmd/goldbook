package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: d90  reason: default package */
public abstract class d90 {
    public static final long a;
    public static final long b;
    public static final long c;
    public static final long d;
    public static final long e;
    public static final long f;
    public static final long g;
    public static final long h;
    public static final long i;
    public static final long j;
    public static final long k;
    public static final long l;
    public static final long m;
    public static final long n;
    public static final long o;
    public static final /* synthetic */ int p = 0;

    static {
        fu0.I(0, 1, 2, 3, 3);
        a = ac.b(4);
        ac.b(259);
        b = ac.b(260);
        c = ac.b(261);
        fu0.I(262, 263, 280, 281, 282);
        ac.b(283);
        ac.b(5);
        ac.b(6);
        d = ac.b(19);
        e = ac.b(20);
        f = ac.b(21);
        g = ac.b(22);
        h = ac.b(23);
        fu0.I(268, 269, 270, 271, 24);
        fu0.I(25, 26, 27, 28, 7);
        fu0.I(8, 9, 10, 11, 12);
        fu0.I(13, 14, 15, 16, 81);
        fu0.I(69, 17, 70, 18, 29);
        fu0.I(30, 31, 32, 33, 34);
        fu0.I(35, 36, 37, 38, 39);
        fu0.I(40, 41, 42, 43, 44);
        fu0.I(45, 46, 47, 48, 49);
        fu0.I(50, 51, 52, 53, 54);
        fu0.I(55, 56, 57, 58, 59);
        ac.b(60);
        i = ac.b(61);
        j = ac.b(62);
        ac.b(63);
        ac.b(64);
        ac.b(65);
        k = ac.b(66);
        ac.b(67);
        ac.b(112);
        l = ac.b(111);
        fu0.I(113, 114, 115, 116, 117);
        fu0.I(118, 119, 120, 121, 122);
        fu0.I(123, 124, 277, 278, 279);
        fu0.I(68, 71, 72, 76, 73);
        fu0.I(74, 75, 77, 78, 79);
        ac.b(80);
        ac.b(82);
        ac.b(83);
        ac.b(84);
        m = ac.b(92);
        n = ac.b(93);
        fu0.I(94, 95, 96, 97, 98);
        fu0.I(99, 100, 101, 102, 103);
        fu0.I(104, 105, 106, 107, 108);
        fu0.I(109, 110, 188, 189, 190);
        fu0.I(191, 192, 193, 194, 195);
        fu0.I(196, 197, 198, 199, 200);
        fu0.I(201, 202, 203, 125, 131);
        fu0.I(132, 133, 134, 135, 136);
        fu0.I(137, 138, 139, 140, 141);
        fu0.I(142, 143, 144, 145, 146);
        fu0.I(147, 148, 149, 150, 151);
        fu0.I(152, 153, 154, 155, 156);
        ac.b(157);
        ac.b(158);
        ac.b(159);
        o = ac.b(160);
        fu0.I(161, 162, 163, 126, 127);
        fu0.I(85, 86, 130, 87, 88);
        fu0.I(89, 90, 128, 222, 129);
        fu0.I(226, 272, 273, 274, 275);
        fu0.I(91, 164, 165, 166, 167);
        fu0.I(168, 169, 170, 171, 172);
        fu0.I(173, 174, 175, 176, 177);
        fu0.I(178, 179, 180, 181, 182);
        fu0.I(183, 184, 185, 186, 187);
        fu0.I(204, 205, 206, 207, 208);
        fu0.I(209, 210, 211, 212, 213);
        fu0.I(214, 215, 216, 217, 218);
        fu0.I(219, 220, 221, 223, 224);
        fu0.I(276, 225, 229, 230, 231);
        fu0.I(232, 233, 234, 235, 236);
        fu0.I(237, 238, 239, 240, 241);
        fu0.I(242, 243, 244, 245, 246);
        fu0.I(247, 248, 249, 250, 251);
        fu0.I(252, 253, 254, 255, 256);
        fu0.I(257, 258, 264, 265, 266);
        fu0.I(267, 284, 285, 286, 287);
        fu0.I(288, -1000000001, -1000000002, -1000000003, -1000000004);
        fu0.I(-1000000005, -1000000006, -1000000007, -1000000008, -1000000009);
        ac.b(-1000000010);
    }

    public static final boolean a(long j2, long j3) {
        if (j2 == j3) {
            return true;
        }
        return false;
    }
}