package defpackage;

import java.util.List;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: b30  reason: default package */
public final class b30 {
    public final n90 a;
    public boolean b;
    public boolean c;
    public boolean d;
    public boolean e;
    public final ak0 f = new ak0();
    public final lm0 g = new lm0();
    public final wj0 h = new wj0(10);

    public b30(n90 n90Var) {
        this.a = n90Var;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r14v2, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r16v8 */
    public final void a(long j, List list, boolean z) {
        wj0 wj0Var;
        long[] jArr;
        long[] jArr2;
        int i;
        bm0 bm0Var;
        bm0 bm0Var2;
        int size = list.size();
        lm0 lm0Var = this.g;
        bm0 bm0Var3 = lm0Var;
        boolean z2 = true;
        int i2 = 0;
        while (true) {
            wj0Var = this.h;
            if (i2 >= size) {
                break;
            }
            li0 li0Var = (li0) list.get(i2);
            if (li0Var.r) {
                li0Var.q = new g4(6, this, li0Var);
                if (z2) {
                    qk0 qk0Var = bm0Var3.a;
                    ?? r14 = qk0Var.e;
                    int i3 = qk0Var.g;
                    int i4 = 0;
                    while (true) {
                        if (i4 < i3) {
                            bm0Var2 = r14[i4];
                            if (k70.p(((bm0) bm0Var2).c, li0Var)) {
                                break;
                            }
                            i4++;
                        } else {
                            bm0Var2 = null;
                            break;
                        }
                    }
                    bm0Var = bm0Var2;
                    if (bm0Var != null) {
                        bm0Var.i = true;
                        bm0Var.d.b(j);
                        if (z) {
                            Object d = wj0Var.d(j);
                            if (d == null) {
                                d = new ak0();
                                wj0Var.f(j, d);
                            }
                            ((ak0) d).a(bm0Var);
                        }
                        bm0Var3 = bm0Var;
                    } else {
                        z2 = false;
                    }
                }
                bm0Var = new bm0(li0Var);
                bm0Var.d.b(j);
                if (z) {
                    Object d2 = wj0Var.d(j);
                    if (d2 == null) {
                        d2 = new ak0();
                        wj0Var.f(j, d2);
                    }
                    ((ak0) d2).a(bm0Var);
                }
                bm0Var3.a.b(bm0Var);
                bm0Var3 = bm0Var;
            }
            i2++;
        }
        if (z) {
            long[] jArr3 = wj0Var.b;
            Object[] objArr = wj0Var.c;
            long[] jArr4 = wj0Var.a;
            int length = jArr4.length - 2;
            if (length >= 0) {
                int i5 = 0;
                while (true) {
                    long j2 = jArr4[i5];
                    if ((((~j2) << 7) & j2 & (-9187201950435737472L)) != -9187201950435737472L) {
                        int i6 = 8;
                        int i7 = 8 - ((~(i5 - length)) >>> 31);
                        int i8 = 0;
                        while (i8 < i7) {
                            if ((255 & j2) < 128) {
                                int i9 = (i5 << 3) + i8;
                                long j3 = jArr3[i9];
                                ak0 ak0Var = (ak0) objArr[i9];
                                qk0 qk0Var2 = lm0Var.a;
                                i = i6;
                                Object[] objArr2 = qk0Var2.e;
                                int i10 = qk0Var2.g;
                                jArr2 = jArr3;
                                for (int i11 = 0; i11 < i10; i11++) {
                                    ((bm0) objArr2[i11]).f(j3, ak0Var);
                                }
                            } else {
                                jArr2 = jArr3;
                                i = i6;
                            }
                            j2 >>= i;
                            i8++;
                            i6 = i;
                            jArr3 = jArr2;
                        }
                        jArr = jArr3;
                        if (i7 != i6) {
                            break;
                        }
                    } else {
                        jArr = jArr3;
                    }
                    if (i5 == length) {
                        break;
                    }
                    i5++;
                    jArr3 = jArr;
                }
            }
        }
        wj0Var.a();
    }

    public final boolean b(e70 e70Var, boolean z) {
        xf0 xf0Var = e70Var.a;
        n90 n90Var = this.a;
        lm0 lm0Var = this.g;
        boolean a = lm0Var.a(xf0Var, n90Var, e70Var, z);
        qk0 qk0Var = lm0Var.a;
        if (!a) {
            return false;
        }
        boolean z2 = true;
        this.b = true;
        Object[] objArr = qk0Var.e;
        int i = qk0Var.g;
        boolean z3 = false;
        for (int i2 = 0; i2 < i; i2++) {
            if (!((bm0) objArr[i2]).e(e70Var, z) && !z3) {
                z3 = false;
            } else {
                z3 = true;
            }
        }
        Object[] objArr2 = qk0Var.e;
        int i3 = qk0Var.g;
        boolean z4 = false;
        for (int i4 = 0; i4 < i3; i4++) {
            if (!((bm0) objArr2[i4]).d(e70Var) && !z4) {
                z4 = false;
            } else {
                z4 = true;
            }
        }
        lm0Var.b(e70Var);
        if (!z4 && !z3) {
            z2 = false;
        }
        this.b = false;
        if (this.e) {
            this.e = false;
            ak0 ak0Var = this.f;
            int i5 = ak0Var.b;
            for (int i6 = 0; i6 < i5; i6++) {
                d((li0) ak0Var.f(i6));
            }
            ak0Var.d();
        }
        if (this.c) {
            this.c = false;
            c();
        }
        if (this.d) {
            this.d = false;
            lm0Var.a.g();
        }
        return z2;
    }

    public final void c() {
        if (this.b) {
            this.c = true;
            return;
        }
        lm0 lm0Var = this.g;
        qk0 qk0Var = lm0Var.a;
        Object[] objArr = qk0Var.e;
        int i = qk0Var.g;
        for (int i2 = 0; i2 < i; i2++) {
            ((bm0) objArr[i2]).c();
        }
        if (this.d) {
            this.d = true;
        } else {
            lm0Var.a.g();
        }
    }

    public final void d(li0 li0Var) {
        if (this.b) {
            this.e = true;
            this.f.a(li0Var);
            return;
        }
        lm0 lm0Var = this.g;
        ak0 ak0Var = lm0Var.b;
        ak0Var.d();
        ak0Var.a(lm0Var);
        while (ak0Var.i()) {
            lm0 lm0Var2 = (lm0) ak0Var.k(ak0Var.b - 1);
            int i = 0;
            while (true) {
                qk0 qk0Var = lm0Var2.a;
                if (i < qk0Var.g) {
                    bm0 bm0Var = (bm0) qk0Var.e[i];
                    if (k70.p(bm0Var.c, li0Var)) {
                        lm0Var2.a.j(bm0Var);
                        bm0Var.c();
                    } else {
                        ak0Var.a(bm0Var);
                        i++;
                    }
                }
            }
        }
    }
}