package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: b70  reason: default package */
public abstract class b70 {
    public static final h30 a = new f3(a70.l);
    public static final ng1 b = new f3(z60.l);
    public static final k81 c;

    /* JADX WARN: Type inference failed for: r0v0, types: [h30, f3] */
    /* JADX WARN: Type inference failed for: r0v1, types: [ng1, f3] */
    /* JADX WARN: Type inference failed for: r1v4, types: [k81, lv0] */
    static {
        wa0.s(new i2(15));
        c = new lv0(new i2(16));
    }
}