package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ae0  reason: default package */
public final class ae0 implements Runnable {
    public Runnable e;
    public final /* synthetic */ be0 f;

    public ae0(be0 be0Var, Runnable runnable) {
        this.f = be0Var;
        this.e = runnable;
    }

    @Override // java.lang.Runnable
    public final void run() {
        int i = 0;
        while (true) {
            this.e.run();
            Runnable j = this.f.j();
            if (j != null) {
                try {
                    this.e = j;
                    i++;
                    if (i >= 16) {
                        be0 be0Var = this.f;
                        if (wl1.I(be0Var.h, be0Var)) {
                            be0 be0Var2 = this.f;
                            wl1.H(be0Var2.h, be0Var2, this);
                            return;
                        }
                    }
                }
            } else {
                return;
            }
        }
    }
}