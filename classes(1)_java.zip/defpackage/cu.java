package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cu  reason: default package */
public final class cu extends h90 implements i00 {
    public final /* synthetic */ int f;
    public final /* synthetic */ ju g;
    public final /* synthetic */ wu h;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ cu(ju juVar, wu wuVar, int i) {
        super(1);
        this.f = i;
        this.g = juVar;
        this.h = wuVar;
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0027, code lost:
        r7 = 0.0f;
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x0031, code lost:
        if (r9.a.c != null) goto L9;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x0072, code lost:
        if (r10.a.a != null) goto L41;
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x0074, code lost:
        r7 = 0.0f;
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x007e, code lost:
        if (r9.a.a != null) goto L41;
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0025, code lost:
        if (r10.a.c != null) goto L9;
     */
    @Override // defpackage.i00
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object i(Object obj) {
        yv yvVar;
        yv yvVar2;
        int i = this.f;
        zt ztVar = zt.g;
        zt ztVar2 = zt.f;
        zt ztVar3 = zt.e;
        float f = 1.0f;
        ju juVar = this.g;
        wu wuVar = this.h;
        switch (i) {
            case 0:
                ad1 ad1Var = (ad1) obj;
                if (ad1Var.a(ztVar3, ztVar2)) {
                    cv cvVar = juVar.a.a;
                    if (cvVar == null || (yvVar2 = cvVar.a) == null) {
                        return eu.b;
                    }
                    return yvVar2;
                } else if (ad1Var.a(ztVar2, ztVar)) {
                    cv cvVar2 = wuVar.a.a;
                    if (cvVar2 == null || (yvVar = cvVar2.a) == null) {
                        return eu.b;
                    }
                    return yvVar;
                } else {
                    return eu.b;
                }
            case 1:
                int ordinal = ((zt) obj).ordinal();
                if (ordinal == 0) {
                    break;
                } else {
                    if (ordinal != 1) {
                        if (ordinal != 2) {
                            od.k();
                            return null;
                        }
                        break;
                    }
                    return Float.valueOf(f);
                }
            case 2:
                ad1 ad1Var2 = (ad1) obj;
                if (ad1Var2.a(ztVar3, ztVar2)) {
                    l01 l01Var = juVar.a.c;
                    if (l01Var != null) {
                        return l01Var.b;
                    }
                    return eu.b;
                } else if (ad1Var2.a(ztVar2, ztVar)) {
                    l01 l01Var2 = wuVar.a.c;
                    if (l01Var2 != null) {
                        return l01Var2.b;
                    }
                    return eu.b;
                } else {
                    return eu.b;
                }
            default:
                int ordinal2 = ((zt) obj).ordinal();
                if (ordinal2 == 0) {
                    break;
                } else {
                    if (ordinal2 != 1) {
                        if (ordinal2 != 2) {
                            od.k();
                            return null;
                        }
                        break;
                    }
                    return Float.valueOf(f);
                }
        }
    }
}