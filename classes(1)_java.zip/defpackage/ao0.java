package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ao0  reason: default package */
public final class ao0 extends xo0 {
    public static final ao0 c = new xo0(0, 0, 3);

    @Override // defpackage.xo0
    public final void a(pg pgVar, m9 m9Var, a61 a61Var, uw0 uw0Var, yo0 yo0Var) {
        a61Var.j();
    }
}