package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cw  reason: default package */
public final class cw {
    public final float a;
    public final float b;
    public final long c;

    public cw(float f, float f2, long j) {
        this.a = f;
        this.b = f2;
        this.c = j;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof cw)) {
            return false;
        }
        cw cwVar = (cw) obj;
        if (Float.compare(this.a, cwVar.a) == 0 && Float.compare(this.b, cwVar.b) == 0 && this.c == cwVar.c) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        int z = fu0.z(this.b, Float.floatToIntBits(this.a) * 31, 31);
        long j = this.c;
        return z + ((int) (j ^ (j >>> 32)));
    }

    public final String toString() {
        return "FlingInfo(initialVelocity=" + this.a + ", distance=" + this.b + ", duration=" + this.c + ')';
    }
}