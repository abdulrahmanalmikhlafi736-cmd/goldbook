package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: d60  reason: default package */
public final /* synthetic */ class d60 implements i00 {
    public final /* synthetic */ int e;
    public final /* synthetic */ vk f;

    public /* synthetic */ d60(vk vkVar, int i) {
        this.e = i;
        this.f = vkVar;
    }

    @Override // defpackage.i00
    public final Object i(Object obj) {
        int i = this.e;
        vk vkVar = this.f;
        kd1 kd1Var = (kd1) obj;
        switch (i) {
            case 0:
                kd1Var.getClass();
                vk vkVar2 = (vk) kd1Var;
                dj1 dj1Var = vkVar.t;
                if (!k70.p(vkVar2.s, dj1Var)) {
                    vkVar2.s = dj1Var;
                    vkVar2.u.i(dj1Var);
                    vkVar2.t = dj1Var;
                    mc0.F(vkVar2, "androidx.compose.foundation.layout.ConsumedInsetsProvider", new d60(vkVar2, 0));
                }
                return jd1.f;
            default:
                kd1Var.getClass();
                vkVar.s = ((vk) kd1Var).t;
                return Boolean.FALSE;
        }
    }
}