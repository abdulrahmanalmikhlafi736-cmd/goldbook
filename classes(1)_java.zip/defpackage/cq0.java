package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cq0  reason: default package */
public final class cq0 {
    public final q6 a;
    public final int b;
    public final int c;

    public cq0(q6 q6Var, int i, int i2) {
        this.a = q6Var;
        this.b = i;
        this.c = i2;
    }

    public final boolean equals(Object obj) {
        if (this != obj) {
            if (obj instanceof cq0) {
                cq0 cq0Var = (cq0) obj;
                if (this.a == cq0Var.a && this.b == cq0Var.b && this.c == cq0Var.c) {
                    return true;
                }
            }
            return false;
        }
        return true;
    }

    public final int hashCode() {
        return (((this.a.hashCode() * 31) + this.b) * 31) + this.c;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("ParagraphIntrinsicInfo(intrinsics=");
        sb.append(this.a);
        sb.append(", startIndex=");
        sb.append(this.b);
        sb.append(", endIndex=");
        return fu0.G(sb, this.c, ')');
    }
}