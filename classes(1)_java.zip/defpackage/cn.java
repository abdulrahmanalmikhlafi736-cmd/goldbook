package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cn  reason: default package */
public final class cn extends u91 implements m00 {
    public final /* synthetic */ int i;
    public /* synthetic */ Object j;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ cn(int i, ml mlVar, int i2) {
        super(i, mlVar);
        this.i = i2;
    }

    @Override // defpackage.m00
    public final Object f(Object obj, Object obj2) {
        int i = this.i;
        we1 we1Var = we1.a;
        switch (i) {
            case 0:
                return ((cn) n((ml) obj2, (z71) obj)).p(we1Var);
            case 1:
                return ((cn) n((ml) obj2, (aw0) obj)).p(we1Var);
            default:
                return ((cn) n((ml) obj2, (i51) obj)).p(we1Var);
        }
    }

    @Override // defpackage.db
    public final ml n(ml mlVar, Object obj) {
        switch (this.i) {
            case 0:
                cn cnVar = new cn(2, mlVar, 0);
                cnVar.j = obj;
                return cnVar;
            case 1:
                cn cnVar2 = new cn(2, mlVar, 1);
                cnVar2.j = obj;
                return cnVar2;
            default:
                cn cnVar3 = new cn(2, mlVar, 2);
                cnVar3.j = obj;
                return cnVar3;
        }
    }

    @Override // defpackage.db
    public final Object p(Object obj) {
        boolean z = false;
        switch (this.i) {
            case 0:
                nb0.t(obj);
                return Boolean.valueOf(!(((z71) this.j) instanceof xv));
            case 1:
                nb0.t(obj);
                if (((aw0) this.j) == aw0.e) {
                    z = true;
                }
                return Boolean.valueOf(z);
            default:
                nb0.t(obj);
                if (((i51) this.j) != i51.e) {
                    z = true;
                }
                return Boolean.valueOf(z);
        }
    }
}