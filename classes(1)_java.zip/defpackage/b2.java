package defpackage;

import android.widget.FrameLayout;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: b2  reason: default package */
public final /* synthetic */ class b2 implements m00 {
    public final /* synthetic */ int e = 1;
    public final /* synthetic */ boolean f;
    public final /* synthetic */ i00 g;
    public final /* synthetic */ Object h;
    public final /* synthetic */ Object i;
    public final /* synthetic */ Object j;
    public final /* synthetic */ Object k;
    public final /* synthetic */ Object l;
    public final /* synthetic */ Object m;
    public final /* synthetic */ Object n;

    public /* synthetic */ b2(mi0 mi0Var, sc0 sc0Var, up0 up0Var, p9 p9Var, mb mbVar, jo joVar, boolean z, x5 x5Var, i00 i00Var, int i) {
        this.h = mi0Var;
        this.i = sc0Var;
        this.j = up0Var;
        this.k = p9Var;
        this.l = mbVar;
        this.m = joVar;
        this.f = z;
        this.n = x5Var;
        this.g = i00Var;
    }

    @Override // defpackage.m00
    public final Object f(Object obj, Object obj2) {
        int i = this.e;
        we1 we1Var = we1.a;
        Object obj3 = this.n;
        Object obj4 = this.m;
        Object obj5 = this.l;
        Object obj6 = this.k;
        Object obj7 = this.j;
        Object obj8 = this.i;
        Object obj9 = this.h;
        switch (i) {
            case 0:
                ((Integer) obj2).getClass();
                int s = wc0.s(385);
                zi1.b((wi1) obj9, (FrameLayout.LayoutParams) obj8, this.f, (ui1) obj7, this.g, (i00) obj6, (w1) obj4, (v1) obj3, (i00) obj5, (d10) obj, s);
                return we1Var;
            default:
                ((Integer) obj2).getClass();
                int s2 = wc0.s(24961);
                ua0.a((mi0) obj9, (sc0) obj8, (up0) obj7, (p9) obj6, (mb) obj5, (jo) obj4, this.f, (x5) obj3, this.g, (d10) obj, s2);
                return we1Var;
        }
    }

    public /* synthetic */ b2(wi1 wi1Var, FrameLayout.LayoutParams layoutParams, boolean z, ui1 ui1Var, i00 i00Var, i00 i00Var2, w1 w1Var, v1 v1Var, i00 i00Var3, int i) {
        this.h = wi1Var;
        this.i = layoutParams;
        this.f = z;
        this.j = ui1Var;
        this.g = i00Var;
        this.k = i00Var2;
        this.m = w1Var;
        this.n = v1Var;
        this.l = i00Var3;
    }
}