package defpackage;

import android.graphics.ColorSpace;
import android.os.Build;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.autofill.AutofillId;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;
import java.util.function.DoubleUnaryOperator;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: b9  reason: default package */
public abstract class b9 {
    public static final ColorSpace a(gh ghVar) {
        ColorSpace colorSpace;
        if (k70.p(ghVar, jh.e)) {
            return ColorSpace.get(ColorSpace.Named.SRGB);
        }
        if (k70.p(ghVar, jh.q)) {
            return ColorSpace.get(ColorSpace.Named.ACES);
        }
        if (k70.p(ghVar, jh.r)) {
            return ColorSpace.get(ColorSpace.Named.ACESCG);
        }
        if (k70.p(ghVar, jh.o)) {
            return ColorSpace.get(ColorSpace.Named.ADOBE_RGB);
        }
        if (k70.p(ghVar, jh.j)) {
            return ColorSpace.get(ColorSpace.Named.BT2020);
        }
        if (k70.p(ghVar, jh.i)) {
            return ColorSpace.get(ColorSpace.Named.BT709);
        }
        if (k70.p(ghVar, jh.t)) {
            return ColorSpace.get(ColorSpace.Named.CIE_LAB);
        }
        if (k70.p(ghVar, jh.s)) {
            return ColorSpace.get(ColorSpace.Named.CIE_XYZ);
        }
        if (k70.p(ghVar, jh.k)) {
            return ColorSpace.get(ColorSpace.Named.DCI_P3);
        }
        if (k70.p(ghVar, jh.l)) {
            return ColorSpace.get(ColorSpace.Named.DISPLAY_P3);
        }
        if (k70.p(ghVar, jh.g)) {
            return ColorSpace.get(ColorSpace.Named.EXTENDED_SRGB);
        }
        if (k70.p(ghVar, jh.h)) {
            return ColorSpace.get(ColorSpace.Named.LINEAR_EXTENDED_SRGB);
        }
        if (k70.p(ghVar, jh.f)) {
            return ColorSpace.get(ColorSpace.Named.LINEAR_SRGB);
        }
        if (k70.p(ghVar, jh.m)) {
            return ColorSpace.get(ColorSpace.Named.NTSC_1953);
        }
        if (k70.p(ghVar, jh.p)) {
            return ColorSpace.get(ColorSpace.Named.PRO_PHOTO_RGB);
        }
        if (k70.p(ghVar, jh.n)) {
            return ColorSpace.get(ColorSpace.Named.SMPTE_C);
        }
        ColorSpace.Rgb.TransferParameters transferParameters = null;
        if (Build.VERSION.SDK_INT >= 34) {
            if (k70.p(ghVar, jh.v)) {
                colorSpace = ColorSpace.get(ih.d());
            } else if (k70.p(ghVar, jh.w)) {
                colorSpace = ColorSpace.get(ih.f());
            } else {
                colorSpace = null;
            }
            if (colorSpace != null) {
                return colorSpace;
            }
        }
        if (ghVar instanceof ay0) {
            String str = ghVar.a;
            ay0 ay0Var = (ay0) ghVar;
            float[] a = ay0Var.d.a();
            vc1 vc1Var = ay0Var.g;
            if (vc1Var != null) {
                transferParameters = new ColorSpace.Rgb.TransferParameters(vc1Var.b, vc1Var.c, vc1Var.d, vc1Var.e, vc1Var.f, vc1Var.g, vc1Var.a);
            }
            float[] fArr = ay0Var.i;
            if (transferParameters != null) {
                ColorSpace.Rgb rgb = new ColorSpace.Rgb(str, ay0Var.h, a, transferParameters);
                if (Float.isNaN(fArr[0]) || Arrays.equals(rgb.getTransform(), fArr)) {
                    return rgb;
                }
                return new ColorSpace.Rgb(str, fArr, transferParameters);
            }
            float[] fArr2 = ay0Var.h;
            final zx0 zx0Var = ay0Var.l;
            DoubleUnaryOperator doubleUnaryOperator = new DoubleUnaryOperator() { // from class: hh
                @Override // java.util.function.DoubleUnaryOperator
                public final double applyAsDouble(double d) {
                    int i = r2;
                    i00 i00Var = zx0Var;
                    switch (i) {
                        case 0:
                            return ((Number) i00Var.i(Double.valueOf(d))).doubleValue();
                        default:
                            return ((Number) i00Var.i(Double.valueOf(d))).doubleValue();
                    }
                }
            };
            final zx0 zx0Var2 = ay0Var.o;
            return new ColorSpace.Rgb(str, fArr2, a, doubleUnaryOperator, new DoubleUnaryOperator() { // from class: hh
                @Override // java.util.function.DoubleUnaryOperator
                public final double applyAsDouble(double d) {
                    int i = r2;
                    i00 i00Var = zx0Var2;
                    switch (i) {
                        case 0:
                            return ((Number) i00Var.i(Double.valueOf(d))).doubleValue();
                        default:
                            return ((Number) i00Var.i(Double.valueOf(d))).doubleValue();
                    }
                }
            }, ay0Var.e, ay0Var.f);
        }
        return ColorSpace.get(ColorSpace.Named.SRGB);
    }

    public static AutofillId b(View view) {
        return view.getAutofillId();
    }

    public static float c(ViewConfiguration viewConfiguration) {
        return viewConfiguration.getScaledHorizontalScrollFactor();
    }

    public static float d(ViewConfiguration viewConfiguration) {
        return viewConfiguration.getScaledHorizontalScrollFactor();
    }

    public static float e(ViewConfiguration viewConfiguration) {
        return viewConfiguration.getScaledVerticalScrollFactor();
    }

    public static float f(ViewConfiguration viewConfiguration) {
        return viewConfiguration.getScaledVerticalScrollFactor();
    }

    public static boolean g(File file, File file2) {
        try {
            Files.move(file.toPath(), file2.toPath(), StandardCopyOption.REPLACE_EXISTING);
            return true;
        } catch (IOException unused) {
            return false;
        }
    }
}