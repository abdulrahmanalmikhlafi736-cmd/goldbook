package defpackage;

import java.util.ArrayList;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cb1  reason: default package */
public final class cb1 {
    public final bb1 a;
    public final ij0 b;
    public final long c;
    public final float d;
    public final float e;
    public final ArrayList f;

    public cb1(bb1 bb1Var, ij0 ij0Var, long j) {
        float c;
        ab1 ab1Var;
        this.a = bb1Var;
        this.b = ij0Var;
        this.c = j;
        ArrayList arrayList = (ArrayList) ij0Var.e;
        float f = 0.0f;
        if (arrayList.isEmpty()) {
            c = 0.0f;
        } else {
            c = ((bq0) arrayList.get(0)).a.d.c(0);
        }
        this.d = c;
        if (!arrayList.isEmpty()) {
            bq0 bq0Var = (bq0) tg.W(arrayList);
            f = bq0Var.a.d.c(ab1Var.f - 1) + bq0Var.f;
        }
        this.e = f;
        this.f = (ArrayList) ij0Var.d;
    }

    public final int a(int i) {
        int h;
        ij0 ij0Var = this.b;
        ArrayList arrayList = (ArrayList) ij0Var.e;
        if (i >= ((x8) ((pa) ij0Var.c).a).f.length()) {
            h = zi1.t(arrayList);
        } else if (i < 0) {
            h = 0;
        } else {
            h = dd0.h(i, arrayList);
        }
        bq0 bq0Var = (bq0) arrayList.get(h);
        m6 m6Var = bq0Var.a;
        return m6Var.d.e.getLineForOffset(bq0Var.a(i)) + bq0Var.d;
    }

    public final int b(float f) {
        char c;
        ArrayList arrayList = (ArrayList) this.b.e;
        int i = 0;
        if (f > 0.0f) {
            if (f >= ((bq0) tg.W(arrayList)).g) {
                i = arrayList.size() - 1;
            } else {
                int size = arrayList.size() - 1;
                int i2 = 0;
                while (true) {
                    if (i2 <= size) {
                        int i3 = (i2 + size) >>> 1;
                        bq0 bq0Var = (bq0) arrayList.get(i3);
                        if (bq0Var.f > f) {
                            c = 1;
                        } else if (bq0Var.g <= f) {
                            c = 65535;
                        } else {
                            c = 0;
                        }
                        if (c < 0) {
                            i2 = i3 + 1;
                        } else if (c > 0) {
                            size = i3 - 1;
                        } else {
                            i = i3;
                            break;
                        }
                    } else {
                        i = -(i2 + 1);
                        break;
                    }
                }
            }
        }
        bq0 bq0Var2 = (bq0) arrayList.get(i);
        int i4 = bq0Var2.c;
        int i5 = bq0Var2.d;
        if (i4 - bq0Var2.b == 0) {
            return i5;
        }
        m6 m6Var = bq0Var2.a;
        float f2 = f - bq0Var2.f;
        ab1 ab1Var = m6Var.d;
        return ab1Var.e.getLineForVertical(((int) f2) - ab1Var.g) + i5;
    }

    public final int c(int i) {
        ij0 ij0Var = this.b;
        ij0Var.b(i);
        ArrayList arrayList = (ArrayList) ij0Var.e;
        bq0 bq0Var = (bq0) arrayList.get(dd0.i(i, arrayList));
        return bq0Var.a.d.e.getLineStart(i - bq0Var.d) + bq0Var.b;
    }

    public final float d(int i) {
        ij0 ij0Var = this.b;
        ij0Var.b(i);
        ArrayList arrayList = (ArrayList) ij0Var.e;
        bq0 bq0Var = (bq0) arrayList.get(dd0.i(i, arrayList));
        return bq0Var.a.d.f(i - bq0Var.d) + bq0Var.f;
    }

    public final lx0 e(int i) {
        int h;
        ij0 ij0Var = this.b;
        x8 x8Var = (x8) ((pa) ij0Var.c).a;
        if (i < 0 || i > x8Var.f.length()) {
            StringBuilder H = fu0.H(i, "offset(", ") is out of bounds [0, ");
            H.append(x8Var.f.length());
            H.append(']');
            q50.a(H.toString());
        }
        int length = ((x8) ((pa) ij0Var.c).a).f.length();
        ArrayList arrayList = (ArrayList) ij0Var.e;
        if (i == length) {
            h = zi1.t(arrayList);
        } else {
            h = dd0.h(i, arrayList);
        }
        bq0 bq0Var = (bq0) arrayList.get(h);
        m6 m6Var = bq0Var.a;
        int a = bq0Var.a(i);
        ab1 ab1Var = m6Var.d;
        if (ab1Var.e.getParagraphDirection(ab1Var.e.getLineForOffset(a)) == 1) {
            return lx0.e;
        }
        return lx0.f;
    }

    public final boolean equals(Object obj) {
        if (this != obj) {
            if (obj instanceof cb1) {
                cb1 cb1Var = (cb1) obj;
                if (k70.p(this.a, cb1Var.a) && this.b == cb1Var.b && v60.a(this.c, cb1Var.c) && this.d == cb1Var.d && this.e == cb1Var.e && k70.p(this.f, cb1Var.f)) {
                    return true;
                }
            }
            return false;
        }
        return true;
    }

    public final int hashCode() {
        int hashCode = this.b.hashCode();
        long j = this.c;
        float f = this.d;
        return this.f.hashCode() + fu0.z(this.e, fu0.z(f, (((int) (j ^ (j >>> 32))) + ((hashCode + (this.a.hashCode() * 31)) * 31)) * 31, 31), 31);
    }

    public final String toString() {
        return "TextLayoutResult(layoutInput=" + this.a + ", multiParagraph=" + this.b + ", size=" + ((Object) v60.b(this.c)) + ", firstBaseline=" + this.d + ", lastBaseline=" + this.e + ", placeholderRects=" + this.f + ')';
    }
}