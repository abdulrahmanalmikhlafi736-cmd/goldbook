package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ex  reason: default package */
public abstract /* synthetic */ class ex {
    public static final /* synthetic */ int a = 0;

    static {
        jb0.y("kotlinx.coroutines.flow.defaultConcurrency", 16L, 1L, 2147483647L);
    }
}