package defpackage;

import java.util.ArrayList;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: db0  reason: default package */
public final class db0 extends li0 implements ds {
    public fb0 s;

    @Override // defpackage.ds
    public final void C(da0 da0Var) {
        ArrayList arrayList = this.s.h;
        if (arrayList.size() <= 0) {
            da0Var.c();
        } else {
            fu0.L(arrayList.get(0));
            throw null;
        }
    }

    @Override // defpackage.ds
    public final /* synthetic */ void Z() {
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if ((obj instanceof db0) && k70.p(this.s, ((db0) obj).s)) {
            return true;
        }
        return false;
    }

    @Override // defpackage.li0
    public final void h0() {
        this.s.getClass();
    }

    public final int hashCode() {
        return this.s.hashCode();
    }

    @Override // defpackage.li0
    public final void j0() {
        fb0 fb0Var = this.s;
        fb0Var.c();
        fb0Var.b = null;
    }

    public final String toString() {
        return "DisplayingDisappearingItemsNode(animator=" + this.s + ')';
    }
}