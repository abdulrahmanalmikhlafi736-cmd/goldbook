package defpackage;

import android.graphics.PathMeasure;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dk  reason: default package */
public final class dk extends h90 implements xz {
    public static final dk g = new dk(0, 0);
    public static final dk h = new dk(0, 1);
    public static final dk i = new dk(0, 2);
    public static final dk j = new dk(0, 3);
    public static final dk k = new dk(0, 4);
    public static final dk l = new dk(0, 5);
    public static final dk m = new dk(0, 6);
    public static final dk n = new dk(0, 7);
    public static final dk o = new dk(0, 8);
    public static final dk p = new dk(0, 9);
    public static final dk q = new dk(0, 10);
    public static final dk r = new dk(0, 11);
    public static final dk s = new dk(0, 12);
    public final /* synthetic */ int f;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ dk(int i2, int i3) {
        super(i2);
        this.f = i3;
    }

    @Override // defpackage.xz
    public final Object a() {
        switch (this.f) {
            case 0:
                return Boolean.FALSE;
            case 1:
            case 2:
                return null;
            case 3:
                fk.b("LocalTextToolbar");
                throw null;
            case gu0.LONG_FIELD_NUMBER /* 4 */:
                fk.b("LocalUriHandler");
                throw null;
            case gu0.STRING_FIELD_NUMBER /* 5 */:
                fk.b("LocalViewConfiguration");
                throw null;
            case gu0.STRING_SET_FIELD_NUMBER /* 6 */:
                fk.b("LocalWindowInfo");
                throw null;
            case gu0.DOUBLE_FIELD_NUMBER /* 7 */:
                return Boolean.TRUE;
            case 8:
                return Boolean.FALSE;
            case 9:
                return new ba0(3);
            case 10:
                return new s6(new PathMeasure());
            case 11:
                return null;
            default:
                return we1.a;
        }
    }
}