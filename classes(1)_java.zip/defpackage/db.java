package defpackage;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: db  reason: default package */
public abstract class db implements ml, dm, Serializable {
    public final ml e;

    public db(ml mlVar) {
        this.e = mlVar;
    }

    @Override // defpackage.dm
    public dm d() {
        ml mlVar = this.e;
        if (mlVar instanceof dm) {
            return (dm) mlVar;
        }
        return null;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // defpackage.ml
    public final void h(Object obj) {
        while (true) {
            db dbVar = this;
            ml mlVar = dbVar.e;
            mlVar.getClass();
            try {
                obj = dbVar.p(obj);
                if (obj == cm.e) {
                    return;
                }
            } catch (Throwable th) {
                obj = new px0(th);
            }
            dbVar.q();
            if (mlVar instanceof db) {
                this = mlVar;
            } else {
                mlVar.h(obj);
                return;
            }
        }
    }

    public ml n(ml mlVar, Object obj) {
        throw new UnsupportedOperationException("create(Any?;Continuation) has not been overridden");
    }

    public StackTraceElement o() {
        int i;
        String str;
        Method method;
        Object invoke;
        Method method2;
        Object invoke2;
        Object obj;
        Integer num;
        int i2;
        un unVar = (un) getClass().getAnnotation(un.class);
        String str2 = null;
        if (unVar == null || unVar.v() < 1) {
            return null;
        }
        int i3 = -1;
        try {
            Field declaredField = getClass().getDeclaredField("label");
            declaredField.setAccessible(true);
            Object obj2 = declaredField.get(this);
            if (obj2 instanceof Integer) {
                num = (Integer) obj2;
            } else {
                num = null;
            }
            if (num != null) {
                i2 = num.intValue();
            } else {
                i2 = 0;
            }
            i = i2 - 1;
        } catch (Exception unused) {
            i = -1;
        }
        if (i >= 0) {
            i3 = unVar.l()[i];
        }
        k9 k9Var = gh0.h;
        k9 k9Var2 = gh0.i;
        if (k9Var2 == null) {
            try {
                k9 k9Var3 = new k9(Class.class.getDeclaredMethod("getModule", null), getClass().getClassLoader().loadClass("java.lang.Module").getDeclaredMethod("getDescriptor", null), getClass().getClassLoader().loadClass("java.lang.module.ModuleDescriptor").getDeclaredMethod("name", null), 6);
                gh0.i = k9Var3;
                k9Var2 = k9Var3;
            } catch (Exception unused2) {
                gh0.i = k9Var;
                k9Var2 = k9Var;
            }
        }
        if (k9Var2 != k9Var && (method = (Method) k9Var2.f) != null && (invoke = method.invoke(getClass(), null)) != null && (method2 = (Method) k9Var2.g) != null && (invoke2 = method2.invoke(invoke, null)) != null) {
            Method method3 = (Method) k9Var2.h;
            if (method3 != null) {
                obj = method3.invoke(invoke2, null);
            } else {
                obj = null;
            }
            if (obj instanceof String) {
                str2 = obj;
            }
        }
        if (str2 == null) {
            str = unVar.c();
        } else {
            str = str2 + '/' + unVar.c();
        }
        return new StackTraceElement(str, unVar.m(), unVar.f(), i3);
    }

    public abstract Object p(Object obj);

    public void q() {
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("Continuation at ");
        Object o = o();
        if (o == null) {
            o = getClass().getName();
        }
        sb.append(o);
        return sb.toString();
    }
}