package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dl0  reason: default package */
public final class dl0 {
    public final int a;
    public final float b;
    public final float c;
    public final float d;
    public final long e;

    public dl0(int i, float f, float f2, float f3, long j) {
        this.a = i;
        this.b = f;
        this.c = f2;
        this.d = f3;
        this.e = j;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && dl0.class == obj.getClass()) {
            dl0 dl0Var = (dl0) obj;
            if (this.c == dl0Var.c && this.d == dl0Var.d && this.b == dl0Var.b && this.a == dl0Var.a && this.e == dl0Var.e) {
                return true;
            }
            return false;
        }
        return false;
    }

    public final int hashCode() {
        int z = fu0.z(this.d, Float.floatToIntBits(this.c) * 31, 31);
        long j = this.e;
        return ((fu0.z(this.b, z, 31) + this.a) * 31) + ((int) (j ^ (j >>> 32)));
    }

    public final String toString() {
        return "NavigationEvent(touchX=" + this.c + ", touchY=" + this.d + ", progress=" + this.b + ", swipeEdge=" + this.a + ", frameTimeMillis=" + this.e + ')';
    }
}