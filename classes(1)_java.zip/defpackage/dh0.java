package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dh0  reason: default package */
public final class dh0 {
    public final dh a;
    public final ke1 b;
    public final c51 c;
    public final yi0 d;

    public dh0(dh dhVar, ke1 ke1Var, c51 c51Var, yi0 yi0Var) {
        this.a = dhVar;
        this.b = ke1Var;
        this.c = c51Var;
        this.d = yi0Var;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || dh0.class != obj.getClass()) {
            return false;
        }
        dh0 dh0Var = (dh0) obj;
        if (k70.p(this.a, dh0Var.a) && k70.p(this.b, dh0Var.b) && k70.p(this.c, dh0Var.c) && k70.p(this.d, dh0Var.d)) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        int hashCode = this.b.hashCode();
        int hashCode2 = this.c.hashCode();
        return this.d.hashCode() + ((hashCode2 + ((hashCode + (this.a.hashCode() * 31)) * 31)) * 31);
    }

    public final String toString() {
        return "Values(colorScheme=" + this.a + ", typography=" + this.b + ", shapes=" + this.c + ", motionScheme=" + this.d + ')';
    }
}