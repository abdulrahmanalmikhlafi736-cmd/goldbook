package defpackage;

import java.util.concurrent.CancellationException;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: b80  reason: default package */
public final class b80 extends CancellationException {
    public final transient h80 e;

    public b80(String str, Throwable th, h80 h80Var) {
        super(str);
        this.e = h80Var;
        if (th != null) {
            initCause(th);
        }
    }

    public final boolean equals(Object obj) {
        if (obj != this) {
            if (obj instanceof b80) {
                b80 b80Var = (b80) obj;
                if (k70.p(b80Var.getMessage(), getMessage())) {
                    Object obj2 = b80Var.e;
                    if (obj2 == null) {
                        obj2 = mm0.f;
                    }
                    Object obj3 = this.e;
                    if (obj3 == null) {
                        obj3 = mm0.f;
                    }
                    if (!k70.p(obj2, obj3) || !k70.p(b80Var.getCause(), getCause())) {
                        return false;
                    }
                    return true;
                }
                return false;
            }
            return false;
        }
        return true;
    }

    @Override // java.lang.Throwable
    public final Throwable fillInStackTrace() {
        setStackTrace(new StackTraceElement[0]);
        return this;
    }

    public final int hashCode() {
        int i;
        String message = getMessage();
        message.getClass();
        int hashCode = message.hashCode() * 31;
        Object obj = this.e;
        if (obj == null) {
            obj = mm0.f;
        }
        int i2 = 0;
        if (obj != null) {
            i = obj.hashCode();
        } else {
            i = 0;
        }
        int i3 = (hashCode + i) * 31;
        Throwable cause = getCause();
        if (cause != null) {
            i2 = cause.hashCode();
        }
        return i3 + i2;
    }

    @Override // java.lang.Throwable
    public final String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append("; job=");
        Object obj = this.e;
        if (obj == null) {
            obj = mm0.f;
        }
        sb.append(obj);
        return sb.toString();
    }
}