package defpackage;

import android.view.View;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: d  reason: default package */
public final class d extends u91 implements m00 {
    public final /* synthetic */ int i;
    public int j;
    public Object k;
    public final /* synthetic */ Object l;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ d(Object obj, Object obj2, ml mlVar, int i) {
        super(2, mlVar);
        this.i = i;
        this.k = obj;
        this.l = obj2;
    }

    @Override // defpackage.m00
    public final Object f(Object obj, Object obj2) {
        int i = this.i;
        cm cmVar = cm.e;
        we1 we1Var = we1.a;
        switch (i) {
            case 0:
                return ((d) n((ml) obj2, (bm) obj)).p(we1Var);
            case 1:
                return ((d) n((ml) obj2, (bm) obj)).p(we1Var);
            case 2:
                return ((d) n((ml) obj2, (bm) obj)).p(we1Var);
            case 3:
                return ((d) n((ml) obj2, (bm) obj)).p(we1Var);
            case gu0.LONG_FIELD_NUMBER /* 4 */:
                return ((d) n((ml) obj2, (bm) obj)).p(we1Var);
            case gu0.STRING_FIELD_NUMBER /* 5 */:
                return ((d) n((ml) obj2, (bm) obj)).p(we1Var);
            case gu0.STRING_SET_FIELD_NUMBER /* 6 */:
                return ((d) n((ml) obj2, (zm) obj)).p(we1Var);
            case gu0.DOUBLE_FIELD_NUMBER /* 7 */:
                return ((d) n((ml) obj2, (bm) obj)).p(we1Var);
            case 8:
                return ((d) n((ml) obj2, (bm) obj)).p(we1Var);
            case 9:
                return ((d) n((ml) obj2, (qh0) obj)).p(we1Var);
            case 10:
                return ((d) n((ml) obj2, (bm) obj)).p(we1Var);
            case 11:
                return ((d) n((ml) obj2, (bm) obj)).p(we1Var);
            case 12:
                return ((d) n((ml) obj2, (bm) obj)).p(we1Var);
            case 13:
                return ((d) n((ml) obj2, (bm) obj)).p(we1Var);
            case 14:
                return ((d) n((ml) obj2, (bm) obj)).p(we1Var);
            case 15:
                return ((d) n((ml) obj2, (bm) obj)).p(we1Var);
            case 16:
                return ((d) n((ml) obj2, (bm) obj)).p(we1Var);
            case 17:
                return ((d) n((ml) obj2, (bm) obj)).p(we1Var);
            case 18:
                return ((d) n((ml) obj2, (bm) obj)).p(we1Var);
            case 19:
                return ((d) n((ml) obj2, (bm) obj)).p(we1Var);
            case 20:
                ((d) n((ml) obj2, (uw) obj)).p(we1Var);
                return cmVar;
            case 21:
                return ((d) n((ml) obj2, (bm) obj)).p(we1Var);
            case 22:
                return ((d) n((ml) obj2, obj)).p(we1Var);
            case 23:
                return ((d) n((ml) obj2, (bm) obj)).p(we1Var);
            case 24:
                return ((d) n((ml) obj2, (bm) obj)).p(we1Var);
            case 25:
                return ((d) n((ml) obj2, (bm) obj)).p(we1Var);
            default:
                ((d) n((ml) obj2, (bm) obj)).p(we1Var);
                return cmVar;
        }
    }

    @Override // defpackage.db
    public final ml n(ml mlVar, Object obj) {
        int i = this.i;
        Object obj2 = this.l;
        switch (i) {
            case 0:
                return new d((uj0) this.k, (m30) obj2, mlVar, 0);
            case 1:
                return new d((uj0) this.k, (n30) obj2, mlVar, 1);
            case 2:
                return new d((rc) this.k, (gw0) obj2, mlVar, 2);
            case 3:
                return new d((vc) this.k, (na) obj2, mlVar, 3);
            case gu0.LONG_FIELD_NUMBER /* 4 */:
                return new d((uj0) this.k, (z61) obj2, mlVar, 4);
            case gu0.STRING_FIELD_NUMBER /* 5 */:
                return new d((cj) this.k, (Runnable) obj2, mlVar, 5);
            case gu0.STRING_SET_FIELD_NUMBER /* 6 */:
                d dVar = new d((List) obj2, mlVar, 6);
                dVar.k = obj;
                return dVar;
            case gu0.DOUBLE_FIELD_NUMBER /* 7 */:
                return new d((tn) this.k, (qh0) obj2, mlVar, 7);
            case 8:
                return new d((m00) this.k, (qm) obj2, mlVar, 8);
            case 9:
                d dVar2 = new d((tn) obj2, mlVar, 9);
                dVar2.k = obj;
                return dVar2;
            case 10:
                return new d((nw) this.k, (kw) obj2, mlVar, 10);
            case 11:
                return new d((nw) this.k, (y60) obj2, mlVar, 11);
            case 12:
                d dVar3 = new d((ye) obj2, mlVar, 12);
                dVar3.k = obj;
                return dVar3;
            case 13:
                d dVar4 = new d((tp) obj2, mlVar, 13);
                dVar4.k = obj;
                return dVar4;
            case 14:
                return new d((y11) this.k, (m00) obj2, mlVar, 14);
            case 15:
                d dVar5 = new d((y6) obj2, mlVar, 15);
                dVar5.k = obj;
                return dVar5;
            case 16:
                return new d((or) this.k, (q11) obj2, mlVar, 16);
            case 17:
                return new d((t41) this.k, (String) obj2, mlVar, 17);
            case 18:
                return new d((p3) obj2, mlVar, 18);
            case 19:
                return new d((tw) this.k, (xu0) obj2, mlVar, 19);
            case 20:
                d dVar6 = new d((j91) obj2, mlVar, 20);
                dVar6.k = obj;
                return dVar6;
            case 21:
                return new d((rf) this.k, (o8) obj2, mlVar, 21);
            case 22:
                d dVar7 = new d((uw) obj2, mlVar, 22);
                dVar7.k = obj;
                return dVar7;
            case 23:
                return new d((wi1) this.k, (x7) obj2, mlVar, 23);
            case 24:
                return new d((ui1) this.k, (String) obj2, mlVar, 24);
            case 25:
                return new d((dw0) this.k, (View) obj2, mlVar, 25);
            default:
                return new d((b81) this.k, (ti0) obj2, mlVar, 26);
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:101:0x01ca, code lost:
        if (r1 != r11) goto L118;
     */
    /* JADX WARN: Code restructure failed: missing block: B:104:0x01d5, code lost:
        if (r0.f(r1, r15) == r11) goto L120;
     */
    /* JADX WARN: Code restructure failed: missing block: B:171:0x0328, code lost:
        if (defpackage.tp.a(r1, r2, (defpackage.aj0) r2, r4, r5, r15) != r11) goto L187;
     */
    /* JADX WARN: Code restructure failed: missing block: B:245:0x0452, code lost:
        if (r0 == r11) goto L291;
     */
    /* JADX WARN: Code restructure failed: missing block: B:264:0x0481, code lost:
        if (defpackage.tn.e(r0, r15) == r11) goto L291;
     */
    /* JADX WARN: Code restructure failed: missing block: B:267:0x0497, code lost:
        if (r0 == r11) goto L291;
     */
    /* JADX WARN: Code restructure failed: missing block: B:363:?, code lost:
        return r11;
     */
    /* JADX WARN: Code restructure failed: missing block: B:394:?, code lost:
        return r0;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v39, types: [uw, java.lang.Object] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:104:0x01d5 -> B:106:0x01d9). Please submit an issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:171:0x0328 -> B:165:0x02ed). Please submit an issue!!! */
    @Override // defpackage.db
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object p(Object obj) {
        Object b;
        Object m;
        bm bmVar;
        Object obj2;
        long j;
        Object obj3;
        d dVar;
        int i = this.i;
        a80 a80Var = null;
        float f = 1.0f;
        we1 we1Var = we1.a;
        Object obj4 = this.l;
        cm cmVar = cm.e;
        switch (i) {
            case 0:
                int i2 = this.j;
                if (i2 != 0) {
                    if (i2 == 1) {
                        nb0.t(obj);
                        return we1Var;
                    }
                    od.p("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                nb0.t(obj);
                this.j = 1;
                if (((uj0) this.k).a((m30) obj4, this) == cmVar) {
                    return cmVar;
                }
                return we1Var;
            case 1:
                int i3 = this.j;
                if (i3 != 0) {
                    if (i3 == 1) {
                        nb0.t(obj);
                        return we1Var;
                    }
                    od.p("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                nb0.t(obj);
                this.j = 1;
                if (((uj0) this.k).a((n30) obj4, this) == cmVar) {
                    return cmVar;
                }
                return we1Var;
            case 2:
                int i4 = this.j;
                if (i4 != 0) {
                    if (i4 == 1) {
                        nb0.t(obj);
                        return we1Var;
                    }
                    od.p("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                nb0.t(obj);
                f8 f8Var = new f8(1, (gw0) obj4);
                this.j = 1;
                if (vd1.g((rc) this.k, f8Var, this) == cmVar) {
                    return cmVar;
                }
                return we1Var;
            case 3:
                int i5 = this.j;
                if (i5 != 0) {
                    if (i5 == 1) {
                        nb0.t(obj);
                        return we1Var;
                    }
                    od.p("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                nb0.t(obj);
                this.j = 1;
                if (vd1.g((vc) this.k, (na) obj4, this) == cmVar) {
                    return cmVar;
                }
                return we1Var;
            case gu0.LONG_FIELD_NUMBER /* 4 */:
                int i6 = this.j;
                if (i6 != 0) {
                    if (i6 == 1) {
                        nb0.t(obj);
                        return we1Var;
                    }
                    od.p("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                nb0.t(obj);
                g51 g51Var = ((uj0) this.k).a;
                rd rdVar = new rd(0, (z61) obj4);
                this.j = 1;
                g51Var.getClass();
                g51.j(g51Var, rdVar, this);
                return cmVar;
            case gu0.STRING_FIELD_NUMBER /* 5 */:
                cj cjVar = (cj) this.k;
                int i7 = this.j;
                if (i7 != 0) {
                    if (i7 == 1) {
                        nb0.t(obj);
                    } else {
                        od.p("call to 'resume' before 'invoke' with coroutine");
                        return null;
                    }
                } else {
                    nb0.t(obj);
                    tw0 tw0Var = cjVar.f;
                    this.j = 1;
                    Object a = tw0Var.a(0.0f - tw0Var.c, this);
                    if (a != cmVar) {
                        a = we1Var;
                    }
                    if (a == cmVar) {
                        return cmVar;
                    }
                }
                cjVar.c.a.setValue(Boolean.FALSE);
                ((Runnable) obj4).run();
                return we1Var;
            case gu0.STRING_SET_FIELD_NUMBER /* 6 */:
                int i8 = this.j;
                if (i8 != 0) {
                    if (i8 == 1) {
                        nb0.t(obj);
                        return we1Var;
                    }
                    od.p("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                nb0.t(obj);
                List list = (List) obj4;
                this.j = 1;
                if (a5.f(list, (zm) this.k, this) == cmVar) {
                    return cmVar;
                }
                return we1Var;
            case gu0.DOUBLE_FIELD_NUMBER /* 7 */:
                qh0 qh0Var = (qh0) obj4;
                tn tnVar = (tn) this.k;
                int i9 = this.j;
                if (i9 != 0) {
                    if (i9 != 1) {
                        if (i9 != 2) {
                            if (i9 != 3) {
                                od.p("call to 'resume' before 'invoke' with coroutine");
                                return null;
                            }
                        } else {
                            nb0.t(obj);
                        }
                    }
                    nb0.t(obj);
                    return obj;
                }
                nb0.t(obj);
                z71 o = tnVar.k.o();
                if (o instanceof qm) {
                    m00 m00Var = qh0Var.a;
                    sl slVar = qh0Var.d;
                    this.j = 1;
                    b = tnVar.h().b(new qn(tnVar, slVar, m00Var, (ml) null), this);
                    break;
                } else if (!(o instanceof sv0) && !(o instanceof qe1)) {
                    if (!(o instanceof xv)) {
                        if (o instanceof am0) {
                            od.p("This is a bug in DataStore. Please file a bug at: https://issuetracker.google.com/issues/new?component=907884&template=1466542");
                            return null;
                        }
                        od.k();
                        return null;
                    }
                    throw ((xv) o).b;
                } else if (o == qh0Var.c) {
                    this.j = 2;
                    break;
                } else {
                    throw ((sv0) o).b;
                }
                return cmVar;
                m00 m00Var2 = qh0Var.a;
                sl slVar2 = qh0Var.d;
                this.j = 3;
                b = tnVar.h().b(new qn(tnVar, slVar2, m00Var2, (ml) null), this);
                break;
            case 8:
                int i10 = this.j;
                if (i10 != 0) {
                    if (i10 == 1) {
                        nb0.t(obj);
                        return obj;
                    }
                    od.p("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                nb0.t(obj);
                Object obj5 = ((qm) obj4).b;
                this.j = 1;
                Object f2 = ((m00) this.k).f(obj5, this);
                if (f2 == cmVar) {
                    return cmVar;
                }
                return f2;
            case 9:
                int i11 = this.j;
                if (i11 != 0) {
                    if (i11 == 1) {
                        nb0.t(obj);
                        return we1Var;
                    }
                    od.p("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                nb0.t(obj);
                tn tnVar2 = (tn) obj4;
                this.j = 1;
                if (tn.b(tnVar2, (qh0) this.k, this) == cmVar) {
                    return cmVar;
                }
                return we1Var;
            case 10:
                int i12 = this.j;
                if (i12 != 0) {
                    if (i12 == 1) {
                        nb0.t(obj);
                        return we1Var;
                    }
                    od.p("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                nb0.t(obj);
                nw nwVar = (nw) this.k;
                kw kwVar = (kw) obj4;
                float f3 = kwVar.a;
                float f4 = kwVar.b;
                float f5 = kwVar.d;
                float f6 = kwVar.c;
                this.j = 1;
                nwVar.a = f3;
                nwVar.b = f4;
                nwVar.c = f5;
                nwVar.d = f6;
                Object b2 = nwVar.b(this);
                if (b2 != cmVar) {
                    b2 = we1Var;
                }
                if (b2 == cmVar) {
                    return cmVar;
                }
                return we1Var;
            case 11:
                int i13 = this.j;
                if (i13 != 0) {
                    if (i13 == 1) {
                        nb0.t(obj);
                        return we1Var;
                    }
                    od.p("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                nb0.t(obj);
                this.j = 1;
                if (((nw) this.k).a((y60) obj4, this) == cmVar) {
                    return cmVar;
                }
                return we1Var;
            case 12:
                int i14 = this.j;
                try {
                    if (i14 != 0) {
                        if (i14 == 1) {
                            a80Var = (a80) this.k;
                            nb0.t(obj);
                            m = obj;
                        } else {
                            od.p("call to 'resume' before 'invoke' with coroutine");
                            return null;
                        }
                    } else {
                        nb0.t(obj);
                        a80Var = wl1.B((bm) this.k, null, new ao(2, null), 3);
                        this.k = a80Var;
                        this.j = 1;
                        m = ((ye) obj4).m(this);
                        if (m == cmVar) {
                            return cmVar;
                        }
                    }
                    return (aj0) m;
                } finally {
                    a80Var.a(null);
                }
            case 13:
                tp tpVar = (tp) obj4;
                int i15 = this.j;
                try {
                    if (i15 != 0) {
                        if (i15 != 1) {
                            if (i15 == 2) {
                                bmVar = (bm) this.k;
                                nb0.t(obj);
                            } else {
                                od.p("call to 'resume' before 'invoke' with coroutine");
                                return null;
                            }
                        } else {
                            bmVar = (bm) this.k;
                            nb0.t(obj);
                            obj2 = obj;
                            float q = ((jp) tpVar.e).q(6.0f);
                            float q2 = ((jp) tpVar.e).q(1.0f);
                            y11 y11Var = (y11) tpVar.b;
                            this.k = bmVar;
                            this.j = 2;
                            break;
                        }
                    } else {
                        nb0.t(obj);
                        bmVar = (bm) this.k;
                    }
                    if (j70.L(bmVar.f())) {
                        this.k = bmVar;
                        this.j = 1;
                        obj2 = ((id) tpVar.f).m(this);
                        if (obj2 == cmVar) {
                            return cmVar;
                        }
                        float q3 = ((jp) tpVar.e).q(6.0f);
                        float q22 = ((jp) tpVar.e).q(1.0f);
                        y11 y11Var2 = (y11) tpVar.b;
                        this.k = bmVar;
                        this.j = 2;
                    } else {
                        return we1Var;
                    }
                } finally {
                    tpVar.g = null;
                }
            case 14:
                int i16 = this.j;
                if (i16 != 0) {
                    if (i16 == 1) {
                        nb0.t(obj);
                        return we1Var;
                    }
                    od.p("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                nb0.t(obj);
                this.j = 1;
                if (((y11) this.k).f(tk0.f, (m00) obj4, this) == cmVar) {
                    return cmVar;
                }
                return we1Var;
            case 15:
                int i17 = this.j;
                if (i17 != 0) {
                    if (i17 == 1) {
                        nb0.t(obj);
                        return we1Var;
                    }
                    od.p("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                nb0.t(obj);
                y6 y6Var = (y6) obj4;
                g51 g51Var2 = y6Var.s.a;
                xq xqVar = new xq(3, y6Var, (bm) this.k);
                this.j = 1;
                g51Var2.getClass();
                g51.j(g51Var2, xqVar, this);
                return cmVar;
            case 16:
                int i18 = this.j;
                if (i18 != 0) {
                    if (i18 == 1) {
                        nb0.t(obj);
                        return we1Var;
                    }
                    od.p("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                nb0.t(obj);
                or orVar = (or) this.k;
                if (orVar.b) {
                    f = -1.0f;
                }
                y11 y11Var3 = ((q11) obj4).R;
                long floatToRawIntBits = Float.floatToRawIntBits(Float.intBitsToFloat((int) (orVar.a & 4294967295L)) * f);
                this.j = 1;
                if (y11Var3.b((Float.floatToRawIntBits(Float.intBitsToFloat((int) (j >> 32)) * f) << 32) | (floatToRawIntBits & 4294967295L), false, this) == cmVar) {
                    return cmVar;
                }
                return we1Var;
            case 17:
                int i19 = this.j;
                if (i19 != 0) {
                    if (i19 == 1) {
                        nb0.t(obj);
                        return we1Var;
                    }
                    od.p("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                nb0.t(obj);
                n41 n41Var = ((t41) this.k).c;
                this.j = 1;
                Object h = wa0.h(o41.a(n41Var.a), new dn((String) obj4, null, 5), this);
                if (h != cmVar) {
                    h = we1Var;
                }
                if (h == cmVar) {
                    return cmVar;
                }
                return we1Var;
            case 18:
                p3 p3Var = (p3) obj4;
                int i20 = this.j;
                if (i20 != 0) {
                    if (i20 != 1) {
                        if (i20 == 2) {
                            nb0.t(obj);
                            if (((AtomicInteger) ((pg0) p3Var.h).f).decrementAndGet() == 0) {
                                return we1Var;
                            }
                            j70.B(((bm) p3Var.e).f());
                            dVar = (d) p3Var.f;
                            this.k = dVar;
                            this.j = 1;
                            obj3 = ((id) p3Var.g).m(this);
                            break;
                        } else {
                            od.p("call to 'resume' before 'invoke' with coroutine");
                        }
                    } else {
                        dVar = (d) this.k;
                        nb0.t(obj);
                        obj3 = obj;
                        this.k = null;
                        this.j = 2;
                        break;
                    }
                } else {
                    nb0.t(obj);
                    if (((AtomicInteger) ((pg0) p3Var.h).f).get() <= 0) {
                        od.p("Check failed.");
                    }
                    j70.B(((bm) p3Var.e).f());
                    dVar = (d) p3Var.f;
                    this.k = dVar;
                    this.j = 1;
                    obj3 = ((id) p3Var.g).m(this);
                }
                return null;
            case 19:
                int i21 = this.j;
                if (i21 != 0) {
                    if (i21 == 1) {
                        nb0.t(obj);
                        return we1Var;
                    }
                    od.p("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                nb0.t(obj);
                w61 w61Var = new w61((xu0) obj4, 1);
                this.j = 1;
                if (((tw) this.k).b(w61Var, this) == cmVar) {
                    return cmVar;
                }
                return we1Var;
            case 20:
                int i22 = this.j;
                if (i22 != 0) {
                    if (i22 != 1) {
                        od.p("call to 'resume' before 'invoke' with coroutine");
                        return null;
                    }
                    nb0.t(obj);
                    throw new RuntimeException();
                }
                nb0.t(obj);
                xq xqVar2 = new xq(4, new Object(), (uw) this.k);
                this.j = 1;
                ((j91) obj4).b(xqVar2, this);
                return cmVar;
            case 21:
                int i23 = this.j;
                if (i23 != 0) {
                    if (i23 == 1) {
                        nb0.t(obj);
                        return we1Var;
                    }
                    od.p("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                nb0.t(obj);
                this.j = 1;
                if (c8.c((c8) ((rf) this.k).c, new Float(0.0f), (o8) obj4, this) == cmVar) {
                    return cmVar;
                }
                return we1Var;
            case 22:
                int i24 = this.j;
                if (i24 != 0) {
                    if (i24 == 1) {
                        nb0.t(obj);
                        return we1Var;
                    }
                    od.p("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                nb0.t(obj);
                Object obj6 = this.k;
                this.j = 1;
                if (((uw) obj4).k(obj6, this) == cmVar) {
                    return cmVar;
                }
                return we1Var;
            case 23:
                int i25 = this.j;
                if (i25 != 0) {
                    if (i25 == 1) {
                        nb0.t(obj);
                        return we1Var;
                    }
                    od.p("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                nb0.t(obj);
                cz0 C = mc0.C(new x1(22, (wi1) this.k));
                ?? obj7 = new Object();
                this.j = 1;
                if (C.b(obj7, this) == cmVar) {
                    return cmVar;
                }
                return we1Var;
            case 24:
                int i26 = this.j;
                if (i26 != 0) {
                    if (i26 == 1) {
                        nb0.t(obj);
                        return we1Var;
                    }
                    od.p("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                nb0.t(obj);
                g51 g51Var3 = ((ui1) this.k).c;
                oi1 oi1Var = new oi1((String) obj4);
                this.j = 1;
                if (g51Var3.k(oi1Var, this) == cmVar) {
                    return cmVar;
                }
                return we1Var;
            case 25:
                dw0 dw0Var = (dw0) this.k;
                View view = (View) obj4;
                int i27 = this.j;
                try {
                    if (i27 != 0) {
                        if (i27 == 1) {
                            nb0.t(obj);
                        } else {
                            od.p("call to 'resume' before 'invoke' with coroutine");
                            return null;
                        }
                    } else {
                        nb0.t(obj);
                        this.j = 1;
                        Object y = wl1.y(dw0Var.u, new cn(2, null, 1), this);
                        if (y != cmVar) {
                            y = we1Var;
                        }
                        if (y == cmVar) {
                            return cmVar;
                        }
                    }
                    if (cl1.b(view) == dw0Var) {
                        view.setTag(2131034155, null);
                        return we1Var;
                    }
                    return we1Var;
                } finally {
                    if (cl1.b(view) == dw0Var) {
                        view.setTag(2131034155, null);
                    }
                }
            default:
                int i28 = this.j;
                if (i28 != 0) {
                    if (i28 != 1) {
                        od.p("call to 'resume' before 'invoke' with coroutine");
                        return null;
                    }
                    nb0.t(obj);
                } else {
                    nb0.t(obj);
                    rd rdVar2 = new rd(4, (ti0) obj4);
                    this.j = 1;
                    if (((b81) this.k).b(rdVar2, this) == cmVar) {
                        return cmVar;
                    }
                }
                throw new RuntimeException();
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ d(Object obj, ml mlVar, int i) {
        super(2, mlVar);
        this.i = i;
        this.l = obj;
    }
}