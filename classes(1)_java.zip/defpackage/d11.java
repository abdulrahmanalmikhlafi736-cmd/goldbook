package defpackage;

/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: d11  reason: default package */
public final class d11 extends qi0 {
    public final r11 a;
    public final bp0 b;
    public final boolean c;
    public final jo d;
    public final uj0 e;
    public final boolean f;
    public final x5 g;

    public d11(x5 x5Var, jo joVar, uj0 uj0Var, bp0 bp0Var, r11 r11Var, boolean z, boolean z2) {
        this.a = r11Var;
        this.b = bp0Var;
        this.c = z;
        this.d = joVar;
        this.e = uj0Var;
        this.f = z2;
        this.g = x5Var;
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [li0, e11, dp] */
    @Override // defpackage.qi0
    public final li0 e() {
        ?? dpVar = new dp();
        dpVar.u = this.a;
        dpVar.v = this.b;
        dpVar.w = this.c;
        dpVar.x = this.d;
        dpVar.y = this.e;
        dpVar.z = this.f;
        dpVar.A = this.g;
        return dpVar;
    }

    public final boolean equals(Object obj) {
        if (this != obj) {
            if (obj != null && d11.class == obj.getClass()) {
                d11 d11Var = (d11) obj;
                if (k70.p(this.a, d11Var.a) && this.b == d11Var.b && this.c == d11Var.c && k70.p(this.d, d11Var.d) && k70.p(this.e, d11Var.e) && this.f == d11Var.f && k70.p(this.g, d11Var.g)) {
                    return true;
                }
                return false;
            }
            return false;
        }
        return true;
    }

    @Override // defpackage.qi0
    public final void f(li0 li0Var) {
        ((e11) li0Var).w0(this.g, this.d, this.e, this.b, this.a, this.f, this.c);
    }

    public final int hashCode() {
        int i;
        int i2;
        int i3;
        int hashCode = (this.b.hashCode() + (this.a.hashCode() * 31)) * 31;
        int i4 = 1237;
        if (this.c) {
            i = 1231;
        } else {
            i = 1237;
        }
        int i5 = (((hashCode + i) * 31) + 1237) * 31;
        int i6 = 0;
        jo joVar = this.d;
        if (joVar != null) {
            i2 = joVar.hashCode();
        } else {
            i2 = 0;
        }
        int i7 = (i5 + i2) * 31;
        uj0 uj0Var = this.e;
        if (uj0Var != null) {
            i3 = uj0Var.hashCode();
        } else {
            i3 = 0;
        }
        int i8 = (i7 + i3) * 961;
        if (this.f) {
            i4 = 1231;
        }
        int i9 = (i8 + i4) * 31;
        x5 x5Var = this.g;
        if (x5Var != null) {
            i6 = x5Var.hashCode();
        }
        return i9 + i6;
    }
}