package defpackage;

import android.view.Choreographer;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: a7  reason: default package */
public final class a7 extends u91 implements m00 {
    public final /* synthetic */ int i;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ a7(int i, ml mlVar, int i2) {
        super(i, mlVar);
        this.i = i2;
    }

    @Override // defpackage.m00
    public final Object f(Object obj, Object obj2) {
        int i = this.i;
        we1 we1Var = we1.a;
        switch (i) {
            case 0:
                return ((a7) n((ml) obj2, (bm) obj)).p(we1Var);
            default:
                ((a7) n((ml) obj2, (uw) obj)).p(we1Var);
                return we1Var;
        }
    }

    @Override // defpackage.db
    public final ml n(ml mlVar, Object obj) {
        switch (this.i) {
            case 0:
                return new a7(2, mlVar, 0);
            default:
                return new a7(2, mlVar, 1);
        }
    }

    @Override // defpackage.db
    public final Object p(Object obj) {
        switch (this.i) {
            case 0:
                nb0.t(obj);
                return Choreographer.getInstance();
            default:
                nb0.t(obj);
                return we1.a;
        }
    }
}