package defpackage;

import android.os.Build;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bn0  reason: default package */
public final class bn0 extends hl0 {
    public final OnBackInvokedDispatcher c;
    public final int d;
    public final OnBackInvokedCallback e;
    public boolean f;

    public bn0(OnBackInvokedDispatcher onBackInvokedDispatcher, int i) {
        OnBackInvokedCallback dn0Var;
        this.c = onBackInvokedDispatcher;
        this.d = i;
        if (Build.VERSION.SDK_INT == 33) {
            dn0Var = new OnBackInvokedCallback() { // from class: cn0
                public final void onBackInvoked() {
                    bn0.this.a();
                }
            };
        } else {
            dn0Var = new dn0(this);
        }
        this.e = dn0Var;
    }

    @Override // defpackage.hl0
    public final void b(boolean z) {
        OnBackInvokedCallback onBackInvokedCallback = this.e;
        if (z && !this.f) {
            this.c.registerOnBackInvokedCallback(this.d, onBackInvokedCallback);
            this.f = true;
        } else if (!z && this.f) {
            this.c.unregisterOnBackInvokedCallback(onBackInvokedCallback);
            this.f = false;
        }
    }
}