package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dj1  reason: default package */
public interface dj1 {
    int a(jp jpVar);

    int b(jp jpVar);

    int c(jp jpVar, o90 o90Var);

    int d(jp jpVar, o90 o90Var);
}