package defpackage;

import android.app.Activity;
import android.graphics.Rect;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dc  reason: default package */
public interface dc {
    public static final cc a = cc.a;

    Rect g(Activity activity);
}