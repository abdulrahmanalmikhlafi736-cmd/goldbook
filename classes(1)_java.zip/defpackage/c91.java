package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: c91  reason: default package */
public final class c91 extends h90 implements m00 {
    public final /* synthetic */ f91 f;
    public final /* synthetic */ mi0 g;
    public final /* synthetic */ m00 h;
    public final /* synthetic */ int i;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public c91(f91 f91Var, mi0 mi0Var, m00 m00Var, int i) {
        super(2);
        this.f = f91Var;
        this.g = mi0Var;
        this.h = m00Var;
        this.i = i;
    }

    @Override // defpackage.m00
    public final Object f(Object obj, Object obj2) {
        ((Number) obj2).intValue();
        int s = wc0.s(this.i | 1);
        vn.c(this.f, this.g, this.h, (d10) obj, s);
        return we1.a;
    }
}