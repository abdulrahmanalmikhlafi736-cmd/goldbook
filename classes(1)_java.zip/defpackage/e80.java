package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: e80  reason: default package */
public final class e80 extends ne {
    public final uh m;

    public e80(ml mlVar, uh uhVar) {
        super(1, mlVar);
        this.m = uhVar;
    }

    @Override // defpackage.ne
    public final String A() {
        return "AwaitContinuation";
    }

    @Override // defpackage.ne
    public final Throwable r(h80 h80Var) {
        Throwable c;
        uh uhVar = this.m;
        uhVar.getClass();
        Object obj = h80.e.get(uhVar);
        if ((obj instanceof g80) && (c = ((g80) obj).c()) != null) {
            return c;
        }
        if (obj instanceof xh) {
            return ((xh) obj).a;
        }
        return h80Var.o();
    }
}