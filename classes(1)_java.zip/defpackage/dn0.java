package defpackage;

import android.window.BackEvent;
import android.window.OnBackAnimationCallback;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dn0  reason: default package */
public final class dn0 implements OnBackAnimationCallback {
    public final /* synthetic */ bn0 a;

    public dn0(bn0 bn0Var) {
        this.a = bn0Var;
    }

    public final void onBackCancelled() {
        bn0 bn0Var = this.a;
        p3 p3Var = bn0Var.a;
        if (p3Var != null) {
            if (!bn0Var.b) {
                p3Var.g(bn0Var, null);
            }
            il0 il0Var = (il0) p3Var.f;
            il0Var.getClass();
            if (bn0Var.equals(il0Var.h) && -1 == il0Var.g) {
                fl0 fl0Var = il0Var.f;
                if (fl0Var == null) {
                    fl0Var = il0Var.c(-1);
                }
                il0Var.f = null;
                il0Var.g = 0;
                il0Var.h = null;
                if (fl0Var != null) {
                    fl0Var.a();
                }
                d81 d81Var = il0Var.a;
                d81Var.getClass();
                d81Var.i(null, jl0.b);
            }
            bn0Var.b = false;
            return;
        }
        od.p("This input is not added to any dispatcher.");
    }

    public final void onBackInvoked() {
        this.a.a();
    }

    public final void onBackProgressed(BackEvent backEvent) {
        backEvent.getClass();
        dl0 a = jb0.a(backEvent);
        bn0 bn0Var = this.a;
        p3 p3Var = bn0Var.a;
        if (p3Var != null) {
            if (bn0Var.b) {
                il0 il0Var = (il0) p3Var.f;
                il0Var.getClass();
                if (bn0Var.equals(il0Var.h) && -1 == il0Var.g) {
                    fl0 fl0Var = il0Var.f;
                    if (fl0Var == null) {
                        fl0Var = il0Var.c(-1);
                    }
                    if (fl0Var != null) {
                        fl0Var.c(a);
                    }
                    d81 d81Var = il0Var.a;
                    kl0 kl0Var = new kl0(a);
                    d81Var.getClass();
                    d81Var.i(null, kl0Var);
                    return;
                }
                return;
            }
            return;
        }
        od.p("This input is not added to any dispatcher.");
    }

    public final void onBackStarted(BackEvent backEvent) {
        backEvent.getClass();
        dl0 a = jb0.a(backEvent);
        bn0 bn0Var = this.a;
        p3 p3Var = bn0Var.a;
        if (p3Var != null) {
            if (!bn0Var.b) {
                p3Var.g(bn0Var, a);
                bn0Var.b = true;
                return;
            }
            return;
        }
        od.p("This input is not added to any dispatcher.");
    }
}