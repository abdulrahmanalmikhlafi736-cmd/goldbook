package defpackage;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: b01  reason: default package */
public final /* synthetic */ class b01 implements i00 {
    public final /* synthetic */ int e;

    public /* synthetic */ b01(int i) {
        this.e = i;
    }

    @Override // defpackage.i00
    public final Object i(Object obj) {
        Integer num;
        zg zgVar;
        xm0 xm0Var;
        String str;
        w8 w8Var;
        Float f;
        Float f2;
        hf0 hf0Var;
        String str2;
        ee0 ee0Var;
        ge0 ge0Var;
        z8 z8Var;
        Integer num2;
        Integer num3;
        String str3;
        w8 w8Var2;
        na1 na1Var;
        sa1 sa1Var;
        qb1 qb1Var;
        wa1 wa1Var;
        ss0 ss0Var;
        he0 he0Var;
        ce0 ce0Var;
        o30 o30Var;
        zg zgVar2;
        qb1 qb1Var2;
        pz pzVar;
        nz nzVar;
        oz ozVar;
        String str4;
        qb1 qb1Var3;
        fb fbVar;
        va1 va1Var;
        if0 if0Var;
        zg zgVar3;
        qa1 qa1Var;
        Boolean bool;
        fb1 fb1Var;
        int i = 0;
        Integer num4 = null;
        Boolean bool2 = null;
        r10 = null;
        ot otVar = null;
        r10 = null;
        w41 w41Var = null;
        r10 = null;
        gb1 gb1Var = null;
        String str5 = null;
        String str6 = null;
        String str7 = null;
        r10 = null;
        le0 le0Var = null;
        r10 = null;
        me0 me0Var = null;
        r10 = null;
        of1 of1Var = null;
        r10 = null;
        jg1 jg1Var = null;
        r10 = null;
        i71 i71Var = null;
        r10 = null;
        fq0 fq0Var = null;
        fe0 fe0Var = null;
        r10 = null;
        eb1 eb1Var = null;
        Float f3 = null;
        rb1 rb1Var = null;
        r10 = null;
        eb1 eb1Var2 = null;
        Float f4 = null;
        switch (this.e) {
            case 0:
                obj.getClass();
                List list = (List) obj;
                Object obj2 = list.get(0);
                if (obj2 != null) {
                    num = (Integer) obj2;
                } else {
                    num = null;
                }
                num.getClass();
                int intValue = num.intValue();
                Object obj3 = list.get(1);
                if (obj3 != null) {
                    num4 = (Integer) obj3;
                }
                num4.getClass();
                return new hb1(dd0.b(intValue, num4.intValue()));
            case 1:
                obj.getClass();
                List list2 = (List) obj;
                Object obj4 = list2.get(0);
                int i2 = zg.j;
                Boolean bool3 = Boolean.FALSE;
                k70.p(obj4, bool3);
                if (obj4 != null) {
                    if (k70.p(obj4, Boolean.FALSE)) {
                        zgVar = new zg(zg.i);
                    } else {
                        zgVar = new zg(wl1.d(((Integer) obj4).intValue()));
                    }
                } else {
                    zgVar = null;
                }
                zgVar.getClass();
                long j = zgVar.a;
                Object obj5 = list2.get(1);
                d01 d01Var = e01.x;
                k70.p(obj5, bool3);
                if (obj5 != null) {
                    xm0Var = (xm0) d01Var.f.i(obj5);
                } else {
                    xm0Var = null;
                }
                xm0Var.getClass();
                long j2 = xm0Var.a;
                Object obj6 = list2.get(2);
                if (obj6 != null) {
                    f4 = (Float) obj6;
                }
                f4.getClass();
                return new w41(j, j2, f4.floatValue());
            case 2:
                obj.getClass();
                return new na1(((Integer) obj).intValue());
            case 3:
                obj.getClass();
                List list3 = (List) obj;
                Object obj7 = list3.get(0);
                if (obj7 != null) {
                    str = (String) obj7;
                } else {
                    str = null;
                }
                str.getClass();
                Object obj8 = list3.get(1);
                al alVar = e01.i;
                if (!k70.p(obj8, Boolean.FALSE) && obj8 != null) {
                    eb1Var2 = (eb1) ((i00) alVar.g).i(obj8);
                }
                return new me0(str, eb1Var2);
            case gu0.LONG_FIELD_NUMBER /* 4 */:
                obj.getClass();
                return new sa1(((Integer) obj).intValue());
            case gu0.STRING_FIELD_NUMBER /* 5 */:
                obj.getClass();
                return new o30(((Integer) obj).intValue());
            case gu0.STRING_SET_FIELD_NUMBER /* 6 */:
                obj.getClass();
                List list4 = (List) obj;
                ArrayList arrayList = new ArrayList(list4.size());
                int size = list4.size();
                while (i < size) {
                    Object obj9 = list4.get(i);
                    al alVar2 = e01.b;
                    if (k70.p(obj9, Boolean.FALSE) || obj9 == null) {
                        w8Var = null;
                    } else {
                        w8Var = (w8) ((i00) alVar2.g).i(obj9);
                    }
                    w8Var.getClass();
                    arrayList.add(w8Var);
                    i++;
                }
                return arrayList;
            case gu0.DOUBLE_FIELD_NUMBER /* 7 */:
                obj.getClass();
                return new nz(((Integer) obj).intValue());
            case 8:
                obj.getClass();
                return new oz(((Integer) obj).intValue());
            case 9:
                Boolean bool4 = Boolean.FALSE;
                if (k70.p(obj, bool4)) {
                    return new qb1(qb1.c);
                }
                obj.getClass();
                List list5 = (List) obj;
                Object obj10 = list5.get(0);
                if (obj10 != null) {
                    f = (Float) obj10;
                } else {
                    f = null;
                }
                f.getClass();
                float floatValue = f.floatValue();
                Object obj11 = list5.get(1);
                d01 d01Var2 = e01.w;
                k70.p(obj11, bool4);
                if (obj11 != null) {
                    rb1Var = (rb1) d01Var2.f.i(obj11);
                }
                rb1Var.getClass();
                return new qb1(jb0.p(rb1Var.a, floatValue));
            case 10:
                if (k70.p(obj, 0)) {
                    return new rb1(8589934592L);
                }
                if (k70.p(obj, 1)) {
                    return new rb1(4294967296L);
                }
                return new rb1(0L);
            case 11:
                if (k70.p(obj, Boolean.FALSE)) {
                    return new xm0(9205357640488583168L);
                }
                obj.getClass();
                List list6 = (List) obj;
                Object obj12 = list6.get(0);
                if (obj12 != null) {
                    f2 = (Float) obj12;
                } else {
                    f2 = null;
                }
                f2.getClass();
                float floatValue2 = f2.floatValue();
                Object obj13 = list6.get(1);
                if (obj13 != null) {
                    f3 = (Float) obj13;
                }
                f3.getClass();
                return new xm0((Float.floatToRawIntBits(floatValue2) << 32) | (Float.floatToRawIntBits(f3.floatValue()) & 4294967295L));
            case 12:
                obj.getClass();
                List list7 = (List) obj;
                ArrayList arrayList2 = new ArrayList(list7.size());
                int size2 = list7.size();
                while (i < size2) {
                    Object obj14 = list7.get(i);
                    al alVar3 = e01.z;
                    if (k70.p(obj14, Boolean.FALSE) || obj14 == null) {
                        hf0Var = null;
                    } else {
                        hf0Var = (hf0) ((i00) alVar3.g).i(obj14);
                    }
                    hf0Var.getClass();
                    arrayList2.add(hf0Var);
                    i++;
                }
                return new if0(arrayList2);
            case 13:
                obj.getClass();
                String str8 = (String) obj;
                Locale forLanguageTag = Locale.forLanguageTag(str8);
                if (k70.p(forLanguageTag.toLanguageTag(), "und")) {
                    System.err.println("The language tag " + str8 + " is not well-formed. Locale is resolved to Undetermined. Note that underscore '_' is not a valid subtag delimiter and must be replaced with '-'.");
                }
                return new hf0(forLanguageTag);
            case 14:
                obj.getClass();
                List list8 = (List) obj;
                Object obj15 = list8.get(0);
                if (obj15 != null) {
                    str2 = (String) obj15;
                } else {
                    str2 = null;
                }
                str2.getClass();
                Object obj16 = list8.get(1);
                al alVar4 = e01.i;
                if (!k70.p(obj16, Boolean.FALSE) && obj16 != null) {
                    eb1Var = (eb1) ((i00) alVar4.g).i(obj16);
                }
                return new le0(str2, eb1Var);
            case 15:
                obj.getClass();
                List list9 = (List) obj;
                Object obj17 = list9.get(0);
                float f5 = ee0.b;
                d01 d01Var3 = e01.B;
                Boolean bool5 = Boolean.FALSE;
                k70.p(obj17, bool5);
                if (obj17 != null) {
                    ee0Var = (ee0) d01Var3.f.i(obj17);
                } else {
                    ee0Var = null;
                }
                ee0Var.getClass();
                float f6 = ee0Var.a;
                Object obj18 = list9.get(1);
                d01 d01Var4 = e01.C;
                k70.p(obj18, bool5);
                if (obj18 != null) {
                    ge0Var = (ge0) d01Var4.f.i(obj18);
                } else {
                    ge0Var = null;
                }
                ge0Var.getClass();
                int i3 = ge0Var.a;
                Object obj19 = list9.get(2);
                d01 d01Var5 = e01.D;
                k70.p(obj19, bool5);
                if (obj19 != null) {
                    fe0Var = (fe0) d01Var5.f.i(obj19);
                }
                fe0Var.getClass();
                return new he0(f6, i3, fe0Var.a);
            case 16:
                obj.getClass();
                float floatValue3 = ((Float) obj).floatValue();
                ee0.a(floatValue3);
                return new ee0(floatValue3);
            case 17:
                obj.getClass();
                return new ge0(((Integer) obj).intValue());
            case 18:
                obj.getClass();
                List list10 = (List) obj;
                Object obj20 = list10.get(0);
                if (obj20 != null) {
                    z8Var = (z8) obj20;
                } else {
                    z8Var = null;
                }
                z8Var.getClass();
                Object obj21 = list10.get(2);
                if (obj21 != null) {
                    num2 = (Integer) obj21;
                } else {
                    num2 = null;
                }
                num2.getClass();
                int intValue2 = num2.intValue();
                Object obj22 = list10.get(3);
                if (obj22 != null) {
                    num3 = (Integer) obj22;
                } else {
                    num3 = null;
                }
                num3.getClass();
                int intValue3 = num3.intValue();
                Object obj23 = list10.get(4);
                if (obj23 != null) {
                    str3 = (String) obj23;
                } else {
                    str3 = null;
                }
                str3.getClass();
                switch (z8Var.ordinal()) {
                    case 0:
                        Object obj24 = list10.get(1);
                        al alVar5 = e01.g;
                        if (!k70.p(obj24, Boolean.FALSE) && obj24 != null) {
                            fq0Var = (fq0) ((i00) alVar5.g).i(obj24);
                        }
                        fq0Var.getClass();
                        w8Var2 = new w8(fq0Var, intValue2, intValue3, str3);
                        break;
                    case 1:
                        Object obj25 = list10.get(1);
                        al alVar6 = e01.h;
                        if (!k70.p(obj25, Boolean.FALSE) && obj25 != null) {
                            i71Var = (i71) ((i00) alVar6.g).i(obj25);
                        }
                        i71Var.getClass();
                        w8Var2 = new w8(i71Var, intValue2, intValue3, str3);
                        break;
                    case 2:
                        Object obj26 = list10.get(1);
                        al alVar7 = e01.c;
                        if (!k70.p(obj26, Boolean.FALSE) && obj26 != null) {
                            jg1Var = (jg1) ((i00) alVar7.g).i(obj26);
                        }
                        jg1Var.getClass();
                        w8Var2 = new w8(jg1Var, intValue2, intValue3, str3);
                        break;
                    case 3:
                        Object obj27 = list10.get(1);
                        al alVar8 = e01.d;
                        if (!k70.p(obj27, Boolean.FALSE) && obj27 != null) {
                            of1Var = (of1) ((i00) alVar8.g).i(obj27);
                        }
                        of1Var.getClass();
                        w8Var2 = new w8(of1Var, intValue2, intValue3, str3);
                        break;
                    case gu0.LONG_FIELD_NUMBER /* 4 */:
                        Object obj28 = list10.get(1);
                        al alVar9 = e01.e;
                        if (!k70.p(obj28, Boolean.FALSE) && obj28 != null) {
                            me0Var = (me0) ((i00) alVar9.g).i(obj28);
                        }
                        me0Var.getClass();
                        w8Var2 = new w8(me0Var, intValue2, intValue3, str3);
                        break;
                    case gu0.STRING_FIELD_NUMBER /* 5 */:
                        Object obj29 = list10.get(1);
                        al alVar10 = e01.f;
                        if (!k70.p(obj29, Boolean.FALSE) && obj29 != null) {
                            le0Var = (le0) ((i00) alVar10.g).i(obj29);
                        }
                        le0Var.getClass();
                        w8Var2 = new w8(le0Var, intValue2, intValue3, str3);
                        break;
                    case gu0.STRING_SET_FIELD_NUMBER /* 6 */:
                        Object obj30 = list10.get(1);
                        if (obj30 != null) {
                            str7 = (String) obj30;
                        }
                        str7.getClass();
                        w8Var2 = new w8(new n81(str7), intValue2, intValue3, str3);
                        break;
                    default:
                        od.k();
                        return null;
                }
                return w8Var2;
            case 19:
                obj.getClass();
                return new fe0(((Integer) obj).intValue());
            case 20:
                if (obj != null) {
                    str6 = (String) obj;
                }
                str6.getClass();
                return new jg1(str6);
            case 21:
                if (obj != null) {
                    str5 = (String) obj;
                }
                str5.getClass();
                return new of1(str5);
            case 22:
                obj.getClass();
                List list11 = (List) obj;
                Object obj31 = list11.get(0);
                d01 d01Var6 = e01.q;
                Boolean bool6 = Boolean.FALSE;
                k70.p(obj31, bool6);
                if (obj31 != null) {
                    na1Var = (na1) d01Var6.f.i(obj31);
                } else {
                    na1Var = null;
                }
                na1Var.getClass();
                int i4 = na1Var.a;
                Object obj32 = list11.get(1);
                d01 d01Var7 = e01.r;
                k70.p(obj32, bool6);
                if (obj32 != null) {
                    sa1Var = (sa1) d01Var7.f.i(obj32);
                } else {
                    sa1Var = null;
                }
                sa1Var.getClass();
                int i5 = sa1Var.a;
                Object obj33 = list11.get(2);
                rb1[] rb1VarArr = qb1.b;
                d01 d01Var8 = e01.v;
                k70.p(obj33, bool6);
                if (obj33 != null) {
                    qb1Var = (qb1) d01Var8.f.i(obj33);
                } else {
                    qb1Var = null;
                }
                qb1Var.getClass();
                long j3 = qb1Var.a;
                Object obj34 = list11.get(3);
                wa1 wa1Var2 = wa1.c;
                al alVar11 = e01.l;
                if (k70.p(obj34, bool6) || obj34 == null) {
                    wa1Var = null;
                } else {
                    wa1Var = (wa1) ((i00) alVar11.g).i(obj34);
                }
                Object obj35 = list11.get(4);
                al alVar12 = vd1.m;
                if (k70.p(obj35, bool6) || obj35 == null) {
                    ss0Var = null;
                } else {
                    ss0Var = (ss0) ((i00) alVar12.g).i(obj35);
                }
                Object obj36 = list11.get(5);
                he0 he0Var2 = he0.d;
                al alVar13 = e01.A;
                if (k70.p(obj36, bool6) || obj36 == null) {
                    he0Var = null;
                } else {
                    he0Var = (he0) ((i00) alVar13.g).i(obj36);
                }
                Object obj37 = list11.get(6);
                al alVar14 = vd1.o;
                if (k70.p(obj37, bool6) || obj37 == null) {
                    ce0Var = null;
                } else {
                    ce0Var = (ce0) ((i00) alVar14.g).i(obj37);
                }
                ce0Var.getClass();
                int i6 = ce0Var.a;
                Object obj38 = list11.get(7);
                d01 d01Var9 = e01.s;
                k70.p(obj38, bool6);
                if (obj38 != null) {
                    o30Var = (o30) d01Var9.f.i(obj38);
                } else {
                    o30Var = null;
                }
                o30Var.getClass();
                int i7 = o30Var.a;
                Object obj39 = list11.get(8);
                al alVar15 = vd1.p;
                if (!k70.p(obj39, bool6) && obj39 != null) {
                    gb1Var = (gb1) ((i00) alVar15.g).i(obj39);
                }
                return new fq0(i4, i5, j3, wa1Var, ss0Var, he0Var, i6, i7, gb1Var);
            case 23:
                obj.getClass();
                List list12 = (List) obj;
                Object obj40 = list12.get(0);
                int i8 = zg.j;
                Boolean bool7 = Boolean.FALSE;
                k70.p(obj40, bool7);
                if (obj40 != null) {
                    if (obj40.equals(bool7)) {
                        zgVar2 = new zg(zg.i);
                    } else {
                        zgVar2 = new zg(wl1.d(((Integer) obj40).intValue()));
                    }
                } else {
                    zgVar2 = null;
                }
                zgVar2.getClass();
                long j4 = zgVar2.a;
                Object obj41 = list12.get(1);
                rb1[] rb1VarArr2 = qb1.b;
                i00 i00Var = e01.v.f;
                k70.p(obj41, bool7);
                if (obj41 != null) {
                    qb1Var2 = (qb1) i00Var.i(obj41);
                } else {
                    qb1Var2 = null;
                }
                qb1Var2.getClass();
                long j5 = qb1Var2.a;
                Object obj42 = list12.get(2);
                pz pzVar2 = pz.f;
                al alVar16 = e01.m;
                if (k70.p(obj42, bool7) || obj42 == null) {
                    pzVar = null;
                } else {
                    pzVar = (pz) ((i00) alVar16.g).i(obj42);
                }
                Object obj43 = list12.get(3);
                al alVar17 = e01.t;
                if (k70.p(obj43, bool7) || obj43 == null) {
                    nzVar = null;
                } else {
                    nzVar = (nz) ((i00) alVar17.g).i(obj43);
                }
                Object obj44 = list12.get(4);
                al alVar18 = e01.u;
                if (k70.p(obj44, bool7) || obj44 == null) {
                    ozVar = null;
                } else {
                    ozVar = (oz) ((i00) alVar18.g).i(obj44);
                }
                Object obj45 = list12.get(6);
                if (obj45 != null) {
                    str4 = (String) obj45;
                } else {
                    str4 = null;
                }
                Object obj46 = list12.get(7);
                k70.p(obj46, bool7);
                if (obj46 != null) {
                    qb1Var3 = (qb1) i00Var.i(obj46);
                } else {
                    qb1Var3 = null;
                }
                qb1Var3.getClass();
                long j6 = qb1Var3.a;
                Object obj47 = list12.get(8);
                al alVar19 = e01.n;
                if (k70.p(obj47, bool7) || obj47 == null) {
                    fbVar = null;
                } else {
                    fbVar = (fb) ((i00) alVar19.g).i(obj47);
                }
                Object obj48 = list12.get(9);
                al alVar20 = e01.k;
                if (k70.p(obj48, bool7) || obj48 == null) {
                    va1Var = null;
                } else {
                    va1Var = (va1) ((i00) alVar20.g).i(obj48);
                }
                Object obj49 = list12.get(10);
                if0 if0Var2 = if0.g;
                al alVar21 = e01.y;
                if (k70.p(obj49, bool7) || obj49 == null) {
                    if0Var = null;
                } else {
                    if0Var = (if0) ((i00) alVar21.g).i(obj49);
                }
                Object obj50 = list12.get(11);
                k70.p(obj50, bool7);
                if (obj50 != null) {
                    if (obj50.equals(bool7)) {
                        zgVar3 = new zg(zg.i);
                    } else {
                        zgVar3 = new zg(wl1.d(((Integer) obj50).intValue()));
                    }
                } else {
                    zgVar3 = null;
                }
                zgVar3.getClass();
                long j7 = zgVar3.a;
                Object obj51 = list12.get(12);
                al alVar22 = e01.j;
                if (k70.p(obj51, bool7) || obj51 == null) {
                    qa1Var = null;
                } else {
                    qa1Var = (qa1) ((i00) alVar22.g).i(obj51);
                }
                Object obj52 = list12.get(13);
                w41 w41Var2 = w41.d;
                al alVar23 = e01.o;
                if (!k70.p(obj52, bool7) && obj52 != null) {
                    w41Var = (w41) ((i00) alVar23.g).i(obj52);
                }
                return new i71(j4, j5, pzVar, nzVar, ozVar, (fa1) null, str4, j6, fbVar, va1Var, if0Var, j7, qa1Var, w41Var, 49184);
            case 24:
                obj.getClass();
                List list13 = (List) obj;
                Object obj53 = list13.get(0);
                if (obj53 != null) {
                    bool = (Boolean) obj53;
                } else {
                    bool = null;
                }
                bool.getClass();
                boolean booleanValue = bool.booleanValue();
                Object obj54 = list13.get(1);
                al alVar24 = vd1.n;
                if (!k70.p(obj54, Boolean.FALSE) && obj54 != null) {
                    otVar = (ot) ((i00) alVar24.g).i(obj54);
                }
                otVar.getClass();
                return new ss0(otVar.a, booleanValue);
            case 25:
                obj.getClass();
                return new ot(((Integer) obj).intValue());
            case 26:
                obj.getClass();
                return new ce0(((Integer) obj).intValue());
            case 27:
                obj.getClass();
                List list14 = (List) obj;
                Object obj55 = list14.get(0);
                al alVar25 = vd1.q;
                if (k70.p(obj55, Boolean.FALSE) || obj55 == null) {
                    fb1Var = null;
                } else {
                    fb1Var = (fb1) ((i00) alVar25.g).i(obj55);
                }
                fb1Var.getClass();
                int i9 = fb1Var.a;
                Object obj56 = list14.get(1);
                if (obj56 != null) {
                    bool2 = (Boolean) obj56;
                }
                bool2.getClass();
                return new gb1(i9, bool2.booleanValue());
            case 28:
                obj.getClass();
                return new fb1(((Integer) obj).intValue());
            default:
                return new c11(((Integer) obj).intValue());
        }
    }
}