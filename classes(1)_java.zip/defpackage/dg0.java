package defpackage;

import java.util.LinkedHashMap;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dg0  reason: default package */
public abstract class dg0 extends bg0 implements hh0 {
    public final gm0 s;
    public LinkedHashMap u;
    public nh0 w;
    public final zj0 x;
    public long t = 0;
    public final eg0 v = new eg0(this);

    public dg0(gm0 gm0Var) {
        this.s = gm0Var;
        zj0 zj0Var = sm0.a;
        this.x = new zj0();
    }

    public static final void n0(dg0 dg0Var, nh0 nh0Var) {
        LinkedHashMap linkedHashMap;
        if (nh0Var != null) {
            dg0Var.S((nh0Var.b() & 4294967295L) | (nh0Var.e() << 32));
        } else {
            dg0Var.S(0L);
        }
        if (!k70.p(dg0Var.w, nh0Var) && nh0Var != null && ((((linkedHashMap = dg0Var.u) != null && !linkedHashMap.isEmpty()) || !nh0Var.c().isEmpty()) && !k70.p(nh0Var.c(), dg0Var.u))) {
            hg0 hg0Var = dg0Var.s.s.K.q;
            hg0Var.getClass();
            hg0Var.u.f();
            LinkedHashMap linkedHashMap2 = dg0Var.u;
            if (linkedHashMap2 == null) {
                linkedHashMap2 = new LinkedHashMap();
                dg0Var.u = linkedHashMap2;
            }
            linkedHashMap2.clear();
            linkedHashMap2.putAll(nh0Var.c());
        }
        dg0Var.w = nh0Var;
    }

    @Override // defpackage.ks0
    public final void R(long j, float f, i00 i00Var) {
        p0(j);
        if (this.n) {
            return;
        }
        o0();
    }

    @Override // defpackage.jp
    public final float a() {
        return this.s.a();
    }

    @Override // defpackage.bg0
    public final bg0 a0() {
        gm0 gm0Var = this.s.t;
        if (gm0Var != null) {
            return gm0Var.w0();
        }
        return null;
    }

    @Override // defpackage.bg0
    public final n90 d0() {
        return this.v;
    }

    @Override // defpackage.bg0
    public final boolean e0() {
        if (this.w != null) {
            return true;
        }
        return false;
    }

    @Override // defpackage.bg0
    public final ba0 f0() {
        return this.s.s;
    }

    @Override // defpackage.jp
    public final float g() {
        return this.s.g();
    }

    @Override // defpackage.bg0
    public final nh0 g0() {
        nh0 nh0Var = this.w;
        if (nh0Var != null) {
            return nh0Var;
        }
        throw fu0.C("LookaheadDelegate has not been measured yet when measureResult is requested.");
    }

    @Override // defpackage.g70
    public final o90 getLayoutDirection() {
        return this.s.s.D;
    }

    @Override // defpackage.bg0
    public final bg0 h0() {
        gm0 gm0Var = this.s.u;
        if (gm0Var != null) {
            return gm0Var.w0();
        }
        return null;
    }

    @Override // defpackage.ks0, defpackage.hh0
    public final Object i() {
        return this.s.i();
    }

    @Override // defpackage.bg0
    public final long i0() {
        return this.t;
    }

    @Override // defpackage.bg0
    public final void m0() {
        R(this.t, 0.0f, null);
    }

    @Override // defpackage.bg0, defpackage.g70
    public final boolean n() {
        return true;
    }

    public void o0() {
        g0().a();
    }

    public final void p0(long j) {
        if (!n60.a(this.t, j)) {
            this.t = j;
            gm0 gm0Var = this.s;
            hg0 hg0Var = gm0Var.s.K.q;
            if (hg0Var != null) {
                hg0Var.Y();
            }
            bg0.k0(gm0Var);
        }
        if (!this.o) {
            Y(g0());
        }
    }

    public final long q0(dg0 dg0Var, boolean z) {
        long j = 0;
        while (!this.equals(dg0Var)) {
            if (!this.m || !z) {
                j = n60.c(j, this.t);
            }
            gm0 gm0Var = this.s.u;
            gm0Var.getClass();
            this = gm0Var.w0();
            this.getClass();
        }
        return j;
    }
}