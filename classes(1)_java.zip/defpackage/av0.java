package defpackage;

import android.util.Log;
import android.view.View;
import java.util.WeakHashMap;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: av0  reason: default package */
public class av0 implements bv0, k51, eg1 {
    public static av0 f;
    public final /* synthetic */ int e;

    public /* synthetic */ av0(int i) {
        this.e = i;
    }

    public static final void c(av0 av0Var) {
        d81 d81Var;
        cs0 cs0Var;
        int i;
        Object obj;
        cs0 cs0Var2;
        d81 d81Var2 = dw0.z;
        do {
            d81Var = dw0.z;
            cs0Var = (cs0) d81Var.getValue();
            rr0 rr0Var = cs0Var.g;
            oe0 oe0Var = (oe0) rr0Var.get(av0Var);
            if (oe0Var == null) {
                cs0Var2 = cs0Var;
            } else {
                Object obj2 = oe0Var.a;
                Object obj3 = oe0Var.b;
                od1 od1Var = rr0Var.e;
                if (av0Var != null) {
                    i = av0Var.hashCode();
                } else {
                    i = 0;
                }
                od1 v = od1Var.v(i, 0, av0Var);
                if (od1Var != v) {
                    if (v == null) {
                        rr0Var = rr0.g;
                    } else {
                        rr0Var = new rr0(v, rr0Var.f - 1);
                    }
                }
                e3 e3Var = e3.L;
                if (obj2 != e3Var) {
                    Object obj4 = rr0Var.get(obj2);
                    obj4.getClass();
                    rr0Var = rr0Var.a(obj2, new oe0(((oe0) obj4).a, obj3));
                }
                if (obj3 != e3Var) {
                    Object obj5 = rr0Var.get(obj3);
                    obj5.getClass();
                    rr0Var = rr0Var.a(obj3, new oe0(obj2, ((oe0) obj5).b));
                }
                if (obj2 != e3Var) {
                    obj = cs0Var.e;
                } else {
                    obj = obj3;
                }
                if (obj3 != e3Var) {
                    obj2 = cs0Var.f;
                }
                cs0Var2 = new cs0(obj, obj2, rr0Var);
            }
            if (cs0Var == cs0Var2) {
                return;
            }
        } while (!d81Var.i(cs0Var, cs0Var2));
    }

    public static final y7 l(String str, int i) {
        WeakHashMap weakHashMap = lk1.v;
        return new y7(str, i);
    }

    public static final int m(int i, long j) {
        int i2 = zi1.z;
        return ((int) (j >> (i * 15))) & 32767;
    }

    public static final uf1 n(String str, int i) {
        WeakHashMap weakHashMap = lk1.v;
        return new uf1(new g60(0, 0, 0, 0), str);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r2v9, types: [jh1] */
    public static pg0 o(kh1 kh1Var, ap apVar, int i) {
        im imVar;
        ap apVar2 = apVar;
        if ((i & 2) != 0) {
            if (kh1Var instanceof z20) {
                apVar2 = (jh1) ((ki) ((z20) kh1Var)).w.getValue();
            } else {
                apVar2 = ap.b;
            }
        }
        if (kh1Var instanceof z20) {
            imVar = ((ki) ((z20) kh1Var)).e();
        } else {
            imVar = hm.b;
        }
        apVar2.getClass();
        imVar.getClass();
        return new pg0(((ki) kh1Var).f(), apVar2, imVar);
    }

    public static lk1 p(d10 d10Var) {
        lk1 lk1Var;
        View view = (View) d10Var.j(c5.f);
        WeakHashMap weakHashMap = lk1.v;
        synchronized (weakHashMap) {
            try {
                Object obj = weakHashMap.get(view);
                if (obj == null) {
                    obj = new lk1(view);
                    weakHashMap.put(view, obj);
                }
                lk1Var = (lk1) obj;
            } catch (Throwable th) {
                throw th;
            }
        }
        boolean h = d10Var.h(lk1Var) | d10Var.h(view);
        Object L = d10Var.L();
        if (h || L == oj.a) {
            L = new c(29, lk1Var, view);
            d10Var.g0(L);
        }
        j70.b(lk1Var, (i00) L, d10Var);
        return lk1Var;
    }

    private final void r() {
    }

    private final void s(int i, Object obj) {
    }

    @Override // defpackage.cg1
    public /* synthetic */ boolean a() {
        return false;
    }

    @Override // defpackage.k51
    public tw b(j91 j91Var) {
        switch (this.e) {
            case 10:
                return new vj(9);
            default:
                return new cz0(0, new d(j91Var, null, 20));
        }
    }

    @Override // defpackage.eg1
    public int d() {
        return 0;
    }

    @Override // defpackage.bv0
    public void e() {
        switch (this.e) {
            case 0:
                return;
            default:
                Log.d("ProfileInstaller", "DIAGNOSTIC_PROFILE_IS_COMPRESSED");
                return;
        }
    }

    @Override // defpackage.cg1
    public u8 f(long j, u8 u8Var, u8 u8Var2, u8 u8Var3) {
        return u8Var3;
    }

    @Override // defpackage.bv0
    public void g(int i, Object obj) {
        String str;
        switch (this.e) {
            case 0:
                return;
            default:
                switch (i) {
                    case 1:
                        str = "RESULT_INSTALL_SUCCESS";
                        break;
                    case 2:
                        str = "RESULT_ALREADY_INSTALLED";
                        break;
                    case 3:
                        str = "RESULT_UNSUPPORTED_ART_VERSION";
                        break;
                    case gu0.LONG_FIELD_NUMBER /* 4 */:
                        str = "RESULT_NOT_WRITABLE";
                        break;
                    case gu0.STRING_FIELD_NUMBER /* 5 */:
                        str = "RESULT_DESIRED_FORMAT_UNSUPPORTED";
                        break;
                    case gu0.STRING_SET_FIELD_NUMBER /* 6 */:
                        str = "RESULT_BASELINE_PROFILE_NOT_FOUND";
                        break;
                    case gu0.DOUBLE_FIELD_NUMBER /* 7 */:
                        str = "RESULT_IO_EXCEPTION";
                        break;
                    case 8:
                        str = "RESULT_PARSE_EXCEPTION";
                        break;
                    case 9:
                    default:
                        str = "";
                        break;
                    case 10:
                        str = "RESULT_INSTALL_SKIP_FILE_SUCCESS";
                        break;
                    case 11:
                        str = "RESULT_DELETE_SKIP_FILE_SUCCESS";
                        break;
                }
                if (i != 6 && i != 7 && i != 8) {
                    Log.d("ProfileInstaller", str);
                    return;
                } else {
                    Log.e("ProfileInstaller", str, (Throwable) obj);
                    return;
                }
        }
    }

    @Override // defpackage.eg1
    public int h() {
        return 0;
    }

    @Override // defpackage.cg1
    public u8 i(long j, u8 u8Var, u8 u8Var2, u8 u8Var3) {
        if (j < 0) {
            return u8Var;
        }
        return u8Var2;
    }

    @Override // defpackage.cg1
    public u8 j(u8 u8Var, u8 u8Var2, u8 u8Var3) {
        return u8Var3;
    }

    @Override // defpackage.cg1
    public long k(u8 u8Var, u8 u8Var2, u8 u8Var3) {
        return 0L;
    }

    public boolean q(CharSequence charSequence) {
        return false;
    }

    public String toString() {
        switch (this.e) {
            case 10:
                return "SharingStarted.Eagerly";
            case 11:
                return "SharingStarted.Lazily";
            case 12:
            default:
                return super.toString();
            case 13:
                return "ReusedSlotId";
        }
    }
}