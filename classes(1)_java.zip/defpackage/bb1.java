package defpackage;

import java.util.List;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bb1  reason: default package */
public final class bb1 {
    public final x8 a;
    public final ob1 b;
    public final List c;
    public final int d;
    public final boolean e;
    public final int f;
    public final jp g;
    public final o90 h;
    public final yy i;
    public final long j;

    public bb1(x8 x8Var, ob1 ob1Var, List list, int i, boolean z, int i2, jp jpVar, o90 o90Var, yy yyVar, long j) {
        this.a = x8Var;
        this.b = ob1Var;
        this.c = list;
        this.d = i;
        this.e = z;
        this.f = i2;
        this.g = jpVar;
        this.h = o90Var;
        this.i = yyVar;
        this.j = j;
    }

    public final boolean equals(Object obj) {
        if (this != obj) {
            if (obj instanceof bb1) {
                bb1 bb1Var = (bb1) obj;
                if (k70.p(this.a, bb1Var.a) && k70.p(this.b, bb1Var.b) && this.c.equals(bb1Var.c) && this.d == bb1Var.d && this.e == bb1Var.e && this.f == bb1Var.f && k70.p(this.g, bb1Var.g) && this.h == bb1Var.h && k70.p(this.i, bb1Var.i) && sk.b(this.j, bb1Var.j)) {
                    return true;
                }
                return false;
            }
            return false;
        }
        return true;
    }

    public final int hashCode() {
        int i;
        int hashCode = (((this.c.hashCode() + fu0.B(this.b, this.a.hashCode() * 31, 31)) * 31) + this.d) * 31;
        if (this.e) {
            i = 1231;
        } else {
            i = 1237;
        }
        int hashCode2 = this.g.hashCode();
        int hashCode3 = this.h.hashCode();
        int hashCode4 = this.i.hashCode();
        long j = this.j;
        return ((int) (j ^ (j >>> 32))) + ((hashCode4 + ((hashCode3 + ((hashCode2 + ((((hashCode + i) * 31) + this.f) * 31)) * 31)) * 31)) * 31);
    }

    public final String toString() {
        String str;
        StringBuilder sb = new StringBuilder("TextLayoutInput(text=");
        sb.append((Object) this.a);
        sb.append(", style=");
        sb.append(this.b);
        sb.append(", placeholders=");
        sb.append(this.c);
        sb.append(", maxLines=");
        sb.append(this.d);
        sb.append(", softWrap=");
        sb.append(this.e);
        sb.append(", overflow=");
        int i = this.f;
        if (i == 1) {
            str = "Clip";
        } else if (i == 2) {
            str = "Ellipsis";
        } else if (i == 5) {
            str = "MiddleEllipsis";
        } else if (i == 3) {
            str = "Visible";
        } else if (i == 4) {
            str = "StartEllipsis";
        } else {
            str = "Invalid";
        }
        sb.append((Object) str);
        sb.append(", density=");
        sb.append(this.g);
        sb.append(", layoutDirection=");
        sb.append(this.h);
        sb.append(", fontFamilyResolver=");
        sb.append(this.i);
        sb.append(", constraints=");
        sb.append((Object) sk.k(this.j));
        sb.append(')');
        return sb.toString();
    }
}