package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ad0  reason: default package */
public final class ad0 implements tf1 {
    public final da1 a;

    public ad0(xz xzVar) {
        this.a = wa0.s(xzVar);
    }

    @Override // defpackage.tf1
    public final Object a(qr0 qr0Var) {
        return this.a.getValue();
    }
}