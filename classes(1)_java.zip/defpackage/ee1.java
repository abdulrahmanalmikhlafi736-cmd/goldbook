package defpackage;

import android.graphics.Typeface;
import android.graphics.fonts.Font;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;
import java.io.IOException;
import java.util.Objects;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ee1  reason: default package */
public final class ee1 extends de1 {
    @Override // defpackage.de1
    public final Font D(rz rzVar) {
        String str;
        Font a;
        Uri uri = rzVar.a;
        boolean equals = Objects.equals(uri.getScheme(), "systemfont");
        String str2 = rzVar.e;
        if (equals) {
            str = uri.getAuthority();
        } else {
            str = null;
        }
        if (str != null) {
            Typeface create = Typeface.create(str, 0);
            Typeface create2 = Typeface.create(Typeface.DEFAULT, 0);
            if (create == null || create.equals(create2)) {
                create = null;
            }
            if (create != null && (a = yd1.a(create)) != null) {
                if (TextUtils.isEmpty(str2)) {
                    return a;
                }
                try {
                    return new Font.Builder(a).setFontVariationSettings(str2).build();
                } catch (IOException unused) {
                    Log.e("TypefaceCompatApi31Impl", "Failed to clone Font instance. Fall back to provider font.");
                    return null;
                }
            }
        }
        return null;
    }
}