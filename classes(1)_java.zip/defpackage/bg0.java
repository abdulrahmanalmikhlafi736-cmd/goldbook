package defpackage;

import java.lang.ref.WeakReference;
import java.util.Map;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bg0  reason: default package */
public abstract class bg0 extends ks0 implements xi0, oh0 {
    public yf0 j;
    public i00 k;
    public ms0 l;
    public boolean m;
    public boolean n;
    public boolean o;
    public final cg0 p = new cg0(0, this);
    public wy0 q;
    public hk0 r;

    public static void k0(gm0 gm0Var) {
        ba0 ba0Var;
        ca0 ca0Var;
        gm0 gm0Var2 = gm0Var.t;
        ba0 ba0Var2 = gm0Var.s;
        if (gm0Var2 != null) {
            ba0Var = gm0Var2.s;
        } else {
            ba0Var = null;
        }
        if (!k70.p(ba0Var, ba0Var2)) {
            ba0Var2.K.p.A.f();
            return;
        }
        k3 s = ba0Var2.K.p.s();
        if (s != null && (ca0Var = ((lh0) s).A) != null) {
            ca0Var.f();
        }
    }

    @Override // defpackage.oh0
    public final nh0 E(int i, int i2, Map map, i00 i00Var, i00 i00Var2) {
        if ((i & (-16777216)) != 0 || ((-16777216) & i2) != 0) {
            p50.b("Size(" + i + " x " + i2 + ") is out of range. Each dimension must be between 0 and 16777215.");
        }
        return new ag0(i, i2, map, i00Var, i00Var2, this);
    }

    @Override // defpackage.jp
    public final /* synthetic */ int F(float f) {
        return fu0.k(f, this);
    }

    @Override // defpackage.jp
    public final /* synthetic */ long K(long j) {
        return fu0.p(j, this);
    }

    @Override // defpackage.jp
    public final /* synthetic */ float N(long j) {
        return fu0.o(j, this);
    }

    @Override // defpackage.oh0
    public final nh0 O(int i, int i2, Map map, i00 i00Var) {
        return E(i, i2, map, null, i00Var);
    }

    /* JADX WARN: Removed duplicated region for block: B:50:0x0114  */
    /* JADX WARN: Removed duplicated region for block: B:71:0x0168  */
    /* JADX WARN: Removed duplicated region for block: B:74:0x0175  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void U(ba0 ba0Var, j30 j30Var) {
        char c;
        long j;
        long j2;
        long j3;
        hk0 hk0Var;
        hk0 hk0Var2;
        Object g;
        long[] jArr;
        long[] jArr2;
        long j4;
        int i;
        char c2;
        long j5;
        long j6;
        int i2;
        int i3;
        int i4;
        hk0 hk0Var3 = this.r;
        char c3 = 7;
        long j7 = -9187201950435737472L;
        int i5 = 8;
        if (hk0Var3 != null) {
            Object[] objArr = hk0Var3.c;
            long[] jArr3 = hk0Var3.a;
            int length = jArr3.length - 2;
            if (length >= 0) {
                int i6 = 0;
                long j8 = 128;
                while (true) {
                    long j9 = jArr3[i6];
                    j2 = 255;
                    if ((((~j9) << c3) & j9 & j7) != j7) {
                        int i7 = 8 - ((~(i6 - length)) >>> 31);
                        int i8 = 0;
                        while (i8 < i7) {
                            if ((j9 & 255) < j8) {
                                c2 = c3;
                                ik0 ik0Var = (ik0) objArr[(i6 << 3) + i8];
                                j5 = j7;
                                Object[] objArr2 = ik0Var.b;
                                long[] jArr4 = ik0Var.a;
                                int length2 = jArr4.length - 2;
                                if (length2 >= 0) {
                                    j6 = j8;
                                    int i9 = 0;
                                    int i10 = i5;
                                    while (true) {
                                        int i11 = length2;
                                        long j10 = jArr4[i9];
                                        jArr2 = jArr3;
                                        j4 = j9;
                                        if ((((~j10) << c2) & j10 & j5) != j5) {
                                            int i12 = 8 - ((~(i9 - i11)) >>> 31);
                                            int i13 = 0;
                                            while (i13 < i12) {
                                                if ((j10 & 255) < j6) {
                                                    int i14 = (i9 << 3) + i13;
                                                    ba0 ba0Var2 = (ba0) ((qh1) objArr2[i14]).get();
                                                    i3 = i13;
                                                    if (ba0Var2 != null) {
                                                        boolean H = ba0Var2.H();
                                                        i4 = i8;
                                                        if (H) {
                                                        }
                                                    } else {
                                                        i4 = i8;
                                                    }
                                                    ik0Var.m(i14);
                                                } else {
                                                    i3 = i13;
                                                    i4 = i8;
                                                }
                                                j10 >>= i10;
                                                i13 = i3 + 1;
                                                i8 = i4;
                                            }
                                            i = i8;
                                            if (i12 != i10) {
                                                break;
                                            }
                                        } else {
                                            i = i8;
                                        }
                                        length2 = i11;
                                        if (i9 == length2) {
                                            break;
                                        }
                                        i9++;
                                        jArr3 = jArr2;
                                        j9 = j4;
                                        i8 = i;
                                        i10 = 8;
                                    }
                                } else {
                                    jArr2 = jArr3;
                                    j4 = j9;
                                    i = i8;
                                    j6 = j8;
                                }
                                i2 = 8;
                            } else {
                                jArr2 = jArr3;
                                j4 = j9;
                                i = i8;
                                c2 = c3;
                                j5 = j7;
                                j6 = j8;
                                i2 = i5;
                            }
                            i5 = i2;
                            j9 = j4 >> i2;
                            c3 = c2;
                            j7 = j5;
                            j8 = j6;
                            i8 = i + 1;
                            jArr3 = jArr2;
                        }
                        jArr = jArr3;
                        c = c3;
                        j = j7;
                        j3 = j8;
                        if (i7 != i5) {
                            break;
                        }
                    } else {
                        jArr = jArr3;
                        c = c3;
                        j = j7;
                        j3 = j8;
                    }
                    if (i6 == length) {
                        break;
                    }
                    i6++;
                    c3 = c;
                    j7 = j;
                    j8 = j3;
                    jArr3 = jArr;
                    i5 = 8;
                }
                hk0Var = this.r;
                if (hk0Var != null) {
                    long[] jArr5 = hk0Var.a;
                    int length3 = jArr5.length - 2;
                    if (length3 >= 0) {
                        int i15 = 0;
                        while (true) {
                            long j11 = jArr5[i15];
                            if ((((~j11) << c) & j11 & j) != j) {
                                int i16 = 8 - ((~(i15 - length3)) >>> 31);
                                for (int i17 = 0; i17 < i16; i17++) {
                                    if ((j11 & j2) < j3) {
                                        int i18 = (i15 << 3) + i17;
                                        j30 j30Var2 = (j30) hk0Var.b[i18];
                                        if (((ik0) hk0Var.c[i18]).g()) {
                                            hk0Var.l(i18);
                                        }
                                    }
                                    j11 >>= 8;
                                }
                                if (i16 != 8) {
                                    break;
                                }
                            }
                            if (i15 == length3) {
                                break;
                            }
                            i15++;
                        }
                    }
                }
                hk0Var2 = this.r;
                if (hk0Var2 == null) {
                    hk0Var2 = new hk0();
                    this.r = hk0Var2;
                }
                g = hk0Var2.g(j30Var);
                if (g == null) {
                    g = new ik0();
                    hk0Var2.m(j30Var, g);
                }
                ((ik0) g).k(new WeakReference(ba0Var));
            }
        }
        c = 7;
        j = -9187201950435737472L;
        j2 = 255;
        j3 = 128;
        hk0Var = this.r;
        if (hk0Var != null) {
        }
        hk0Var2 = this.r;
        if (hk0Var2 == null) {
        }
        g = hk0Var2.g(j30Var);
        if (g == null) {
        }
        ((ik0) g).k(new WeakReference(ba0Var));
    }

    @Override // defpackage.jp
    public final long V(float f) {
        return fu0.q(f / a(), this);
    }

    public abstract int W(f3 f3Var);

    public final void X(ms0 ms0Var, long j, long j2) {
        char c;
        long j3;
        long j4;
        long j5;
        ba0 ba0Var;
        int i;
        char c2;
        long j6;
        bg0 bg0Var;
        bg0 h0;
        ik0 ik0Var;
        op0 snapshotObserver;
        hk0 hk0Var = this.r;
        wy0 wy0Var = this.q;
        if (wy0Var == null) {
            wy0Var = new wy0();
            this.q = wy0Var;
        }
        wy0 wy0Var2 = wy0Var;
        lp0 lp0Var = f0().r;
        if (lp0Var != null && (snapshotObserver = ((n4) lp0Var).getSnapshotObserver()) != null) {
            snapshotObserver.a.b(ms0Var, i4.F, new zf0(this, j, j2, ms0Var));
        }
        boolean n = n();
        ik0 ik0Var2 = (ik0) wy0Var2.e;
        ik0 ik0Var3 = (ik0) wy0Var2.f;
        int i2 = wy0Var2.a;
        for (int i3 = 0; i3 < i2; i3++) {
            byte b = ((byte[]) wy0Var2.d)[i3];
            if (b == 3) {
                j30 j30Var = ((j30[]) wy0Var2.b)[i3];
                j30Var.getClass();
                ik0Var3.k(j30Var);
            } else if (b != 0 && hk0Var != null) {
                j30 j30Var2 = ((j30[]) wy0Var2.b)[i3];
                j30Var2.getClass();
                ik0 ik0Var4 = (ik0) hk0Var.k(j30Var2);
                if (ik0Var4 != null) {
                    ik0Var2.j(ik0Var4);
                }
            }
        }
        int i4 = wy0Var2.a;
        int i5 = 0;
        for (int i6 = 0; i6 < i4; i6++) {
            byte[] bArr = (byte[]) wy0Var2.d;
            if (bArr[i6] == 2) {
                i5++;
            } else if (i5 > 0) {
                j30[] j30VarArr = (j30[]) wy0Var2.b;
                j30VarArr[i6 - i5] = j30VarArr[i6];
            }
            bArr[i6] = 2;
        }
        int i7 = wy0Var2.a;
        for (int i8 = i7 - i5; i8 < i7; i8++) {
            ((j30[]) wy0Var2.b)[i8] = null;
        }
        wy0Var2.a -= i5;
        bg0 h02 = h0();
        Object[] objArr = ik0Var3.b;
        long[] jArr = ik0Var3.a;
        int length = jArr.length - 2;
        char c3 = 7;
        long j7 = -9187201950435737472L;
        int i9 = 8;
        if (length >= 0) {
            j4 = 128;
            int i10 = 0;
            while (true) {
                long j8 = jArr[i10];
                j5 = 255;
                if ((((~j8) << c3) & j8 & j7) != j7) {
                    int i11 = 8 - ((~(i10 - length)) >>> 31);
                    int i12 = 0;
                    while (i12 < i11) {
                        if ((j8 & 255) < 128) {
                            c2 = c3;
                            j30 j30Var3 = (j30) objArr[(i10 << 3) + i12];
                            j6 = j7;
                            if (h02 == null) {
                                bg0Var = this;
                            } else {
                                bg0Var = h02;
                            }
                            i = i9;
                            bg0 bg0Var2 = bg0Var;
                            while (true) {
                                wy0 wy0Var3 = bg0Var2.q;
                                if ((wy0Var3 == null || ba.f0((j30[]) wy0Var3.b, j30Var3) < 0) && (h0 = bg0Var2.h0()) != null) {
                                    bg0Var2 = h0;
                                }
                            }
                            hk0 hk0Var2 = bg0Var2.r;
                            if (hk0Var2 != null) {
                                ik0Var = (ik0) hk0Var2.k(j30Var3);
                            } else {
                                ik0Var = null;
                            }
                            if (ik0Var != null) {
                                bg0Var.l0(ik0Var);
                            }
                        } else {
                            i = i9;
                            c2 = c3;
                            j6 = j7;
                        }
                        j8 >>= i;
                        i12++;
                        c3 = c2;
                        j7 = j6;
                        i9 = i;
                    }
                    c = c3;
                    j3 = j7;
                    if (i11 != i9) {
                        break;
                    }
                } else {
                    c = c3;
                    j3 = j7;
                }
                if (i10 == length) {
                    break;
                }
                i10++;
                c3 = c;
                j7 = j3;
                i9 = 8;
            }
        } else {
            c = 7;
            j3 = -9187201950435737472L;
            j4 = 128;
            j5 = 255;
        }
        ik0Var3.b();
        Object[] objArr2 = ik0Var2.b;
        long[] jArr2 = ik0Var2.a;
        int length2 = jArr2.length - 2;
        if (length2 >= 0) {
            int i13 = 0;
            while (true) {
                long j9 = jArr2[i13];
                if ((((~j9) << c) & j9 & j3) != j3) {
                    int i14 = 8 - ((~(i13 - length2)) >>> 31);
                    for (int i15 = 0; i15 < i14; i15++) {
                        if ((j9 & j5) < j4 && (ba0Var = (ba0) ((qh1) objArr2[(i13 << 3) + i15]).get()) != null) {
                            if (n) {
                                ba0Var.S(false);
                            } else {
                                ba0Var.U(false);
                            }
                        }
                        j9 >>= 8;
                    }
                    if (i14 != 8) {
                        break;
                    }
                }
                if (i13 == length2) {
                    break;
                }
                i13++;
            }
        }
        ik0Var2.b();
    }

    public final void Y(nh0 nh0Var) {
        boolean z;
        long j;
        long j2;
        hk0 hk0Var = this.r;
        if (!this.o) {
            i00 d = nh0Var.d();
            boolean z2 = false;
            if (d == null) {
                if (hk0Var != null) {
                    Object[] objArr = hk0Var.c;
                    long[] jArr = hk0Var.a;
                    int length = jArr.length - 2;
                    if (length >= 0) {
                        int i = 0;
                        while (true) {
                            long j3 = jArr[i];
                            if ((((~j3) << 7) & j3 & (-9187201950435737472L)) != -9187201950435737472L) {
                                int i2 = 8 - ((~(i - length)) >>> 31);
                                for (int i3 = 0; i3 < i2; i3++) {
                                    if ((255 & j3) < 128) {
                                        l0((ik0) objArr[(i << 3) + i3]);
                                    }
                                    j3 >>= 8;
                                }
                                if (i2 != 8) {
                                    break;
                                }
                            }
                            if (i == length) {
                                break;
                            }
                            i++;
                        }
                    }
                    hk0Var.a();
                    return;
                }
                return;
            }
            if (this.k != d) {
                z = true;
            } else {
                z = false;
            }
            if (!z && j0().e) {
                n90 d0 = d0();
                long C = vd1.C(d0.d(0L));
                long A = d0.A();
                j2 = C;
                j = A;
                z = (n60.a(C, j0().f) && v60.a(A, j0().g)) ? true : true;
            } else {
                j = 0;
                j2 = 9223372034707292159L;
            }
            if (z) {
                ms0 ms0Var = this.l;
                if (ms0Var != null) {
                    ms0Var.e = nh0Var;
                } else {
                    ms0Var = new ms0(nh0Var, this);
                    this.l = ms0Var;
                }
                X(ms0Var, j2, j);
                this.k = nh0Var.d();
            }
        }
    }

    public final int Z(f3 f3Var) {
        int W;
        long j;
        if (!e0() || (W = W(f3Var)) == Integer.MIN_VALUE) {
            return Integer.MIN_VALUE;
        }
        boolean z = f3Var instanceof ng1;
        long j2 = this.i;
        if (z) {
            j = j2 >> 32;
        } else {
            j = 4294967295L & j2;
        }
        return W + ((int) j);
    }

    public abstract bg0 a0();

    @Override // defpackage.jp
    public final float b0(int i) {
        return i / a();
    }

    @Override // defpackage.jp
    public final float c0(float f) {
        return f / a();
    }

    public abstract n90 d0();

    public abstract boolean e0();

    public abstract ba0 f0();

    public abstract nh0 g0();

    public abstract bg0 h0();

    public abstract long i0();

    public final yf0 j0() {
        yf0 yf0Var = this.j;
        if (yf0Var == null) {
            yf0 yf0Var2 = new yf0(this);
            this.j = yf0Var2;
            return yf0Var2;
        }
        return yf0Var;
    }

    public final void l0(ik0 ik0Var) {
        ba0 ba0Var;
        Object[] objArr = ik0Var.b;
        long[] jArr = ik0Var.a;
        int length = jArr.length - 2;
        if (length >= 0) {
            int i = 0;
            while (true) {
                long j = jArr[i];
                if ((((~j) << 7) & j & (-9187201950435737472L)) != -9187201950435737472L) {
                    int i2 = 8 - ((~(i - length)) >>> 31);
                    for (int i3 = 0; i3 < i2; i3++) {
                        if ((255 & j) < 128 && (ba0Var = (ba0) ((qh1) objArr[(i << 3) + i3]).get()) != null) {
                            if (n()) {
                                ba0Var.S(false);
                            } else {
                                ba0Var.U(false);
                            }
                        }
                        j >>= 8;
                    }
                    if (i2 != 8) {
                        return;
                    }
                }
                if (i != length) {
                    i++;
                } else {
                    return;
                }
            }
        }
    }

    @Override // defpackage.xi0
    public final void m(boolean z) {
        ba0 ba0Var;
        x90 x90Var;
        bg0 h0 = h0();
        x90 x90Var2 = null;
        if (h0 != null) {
            ba0Var = h0.f0();
        } else {
            ba0Var = null;
        }
        if (k70.p(ba0Var, f0())) {
            this.m = z;
            return;
        }
        if (ba0Var != null) {
            x90Var = ba0Var.K.d;
        } else {
            x90Var = null;
        }
        if (x90Var != x90.g) {
            if (ba0Var != null) {
                x90Var2 = ba0Var.K.d;
            }
            if (x90Var2 != x90.h) {
                return;
            }
        }
        this.m = z;
    }

    public abstract void m0();

    @Override // defpackage.g70
    public boolean n() {
        return false;
    }

    @Override // defpackage.jp
    public final float q(float f) {
        return a() * f;
    }

    @Override // defpackage.jp
    public final /* synthetic */ float y(long j) {
        return fu0.m(j, this);
    }
}