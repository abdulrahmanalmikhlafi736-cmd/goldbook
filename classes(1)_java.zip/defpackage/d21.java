package defpackage;

import java.util.Iterator;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: d21  reason: default package */
public final class d21 implements r21, Iterable, w80 {
    public final hk0 e;
    public bh0 f;
    public boolean g;
    public boolean h;

    public d21() {
        long[] jArr = n01.a;
        this.e = new hk0();
    }

    @Override // defpackage.r21
    public final void a(q21 q21Var, Object obj) {
        boolean z = obj instanceof o0;
        hk0 hk0Var = this.e;
        if (z && hk0Var.c(q21Var)) {
            Object g = hk0Var.g(q21Var);
            g.getClass();
            o0 o0Var = (o0) g;
            o0 o0Var2 = (o0) obj;
            String str = o0Var2.a;
            if (str == null) {
                str = o0Var.a;
            }
            u00 u00Var = o0Var2.b;
            if (u00Var == null) {
                u00Var = o0Var.b;
            }
            hk0Var.m(q21Var, new o0(str, u00Var));
        } else {
            hk0Var.m(q21Var, obj);
        }
        q21Var.getClass();
    }

    public final d21 b() {
        d21 d21Var = new d21();
        d21Var.g = this.g;
        d21Var.h = this.h;
        hk0 hk0Var = d21Var.e;
        hk0Var.getClass();
        hk0 hk0Var2 = this.e;
        hk0Var2.getClass();
        Object[] objArr = hk0Var2.b;
        Object[] objArr2 = hk0Var2.c;
        long[] jArr = hk0Var2.a;
        int length = jArr.length - 2;
        if (length >= 0) {
            int i = 0;
            while (true) {
                long j = jArr[i];
                if ((((~j) << 7) & j & (-9187201950435737472L)) != -9187201950435737472L) {
                    int i2 = 8 - ((~(i - length)) >>> 31);
                    for (int i3 = 0; i3 < i2; i3++) {
                        if ((255 & j) < 128) {
                            int i4 = (i << 3) + i3;
                            hk0Var.m(objArr[i4], objArr2[i4]);
                        }
                        j >>= 8;
                    }
                    if (i2 != 8) {
                        break;
                    }
                }
                if (i == length) {
                    break;
                }
                i++;
            }
        }
        return d21Var;
    }

    public final Object c(q21 q21Var) {
        Object g = this.e.g(q21Var);
        if (g != null) {
            return g;
        }
        throw new IllegalStateException("Key not present: " + q21Var + " - consider getOrElse or getOrNull");
    }

    public final void e(d21 d21Var) {
        hk0 hk0Var = d21Var.e;
        Object[] objArr = hk0Var.b;
        Object[] objArr2 = hk0Var.c;
        long[] jArr = hk0Var.a;
        int length = jArr.length - 2;
        if (length >= 0) {
            int i = 0;
            while (true) {
                long j = jArr[i];
                if ((((~j) << 7) & j & (-9187201950435737472L)) != -9187201950435737472L) {
                    int i2 = 8 - ((~(i - length)) >>> 31);
                    for (int i3 = 0; i3 < i2; i3++) {
                        if ((255 & j) < 128) {
                            int i4 = (i << 3) + i3;
                            Object obj = objArr[i4];
                            Object obj2 = objArr2[i4];
                            q21 q21Var = (q21) obj;
                            hk0 hk0Var2 = this.e;
                            Object g = hk0Var2.g(q21Var);
                            q21Var.getClass();
                            Object f = q21Var.b.f(g, obj2);
                            if (f != null) {
                                hk0Var2.m(q21Var, f);
                            }
                        }
                        j >>= 8;
                    }
                    if (i2 != 8) {
                        return;
                    }
                }
                if (i != length) {
                    i++;
                } else {
                    return;
                }
            }
        }
    }

    public final boolean equals(Object obj) {
        if (this != obj) {
            if (obj instanceof d21) {
                d21 d21Var = (d21) obj;
                if (!k70.p(this.e, d21Var.e) || this.g != d21Var.g || this.h != d21Var.h) {
                    return false;
                }
                return true;
            }
            return false;
        }
        return true;
    }

    public final int hashCode() {
        int i;
        int hashCode = this.e.hashCode() * 31;
        int i2 = 1237;
        if (this.g) {
            i = 1231;
        } else {
            i = 1237;
        }
        int i3 = (hashCode + i) * 31;
        if (this.h) {
            i2 = 1231;
        }
        return i3 + i2;
    }

    @Override // java.lang.Iterable
    public final Iterator iterator() {
        bh0 bh0Var = this.f;
        if (bh0Var == null) {
            hk0 hk0Var = this.e;
            hk0Var.getClass();
            bh0 bh0Var2 = new bh0(hk0Var);
            this.f = bh0Var2;
            bh0Var = bh0Var2;
        }
        return ((lu) bh0Var.entrySet()).iterator();
    }

    public final String toString() {
        String str;
        StringBuilder sb = new StringBuilder();
        if (this.g) {
            sb.append("mergeDescendants=true");
            str = ", ";
        } else {
            str = "";
        }
        if (this.h) {
            sb.append(str);
            sb.append("isClearingSemantics=true");
            str = ", ";
        }
        hk0 hk0Var = this.e;
        Object[] objArr = hk0Var.b;
        Object[] objArr2 = hk0Var.c;
        long[] jArr = hk0Var.a;
        int length = jArr.length - 2;
        if (length >= 0) {
            int i = 0;
            while (true) {
                long j = jArr[i];
                if ((((~j) << 7) & j & (-9187201950435737472L)) != -9187201950435737472L) {
                    int i2 = 8 - ((~(i - length)) >>> 31);
                    for (int i3 = 0; i3 < i2; i3++) {
                        if ((255 & j) < 128) {
                            int i4 = (i << 3) + i3;
                            Object obj = objArr[i4];
                            Object obj2 = objArr2[i4];
                            sb.append(str);
                            sb.append(((q21) obj).a);
                            sb.append(" : ");
                            sb.append(obj2);
                            str = ", ";
                        }
                        j >>= 8;
                    }
                    if (i2 != 8) {
                        break;
                    }
                }
                if (i == length) {
                    break;
                }
                i++;
            }
        }
        return gh0.S(this) + "{ " + ((Object) sb) + " }";
    }
}