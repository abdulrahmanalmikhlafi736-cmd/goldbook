package defpackage;

import android.content.Context;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: d20  reason: default package */
public final /* synthetic */ class d20 implements m00 {
    public final /* synthetic */ int e = 1;
    public final /* synthetic */ Object f;
    public final /* synthetic */ Object g;
    public final /* synthetic */ Object h;
    public final /* synthetic */ Object i;
    public final /* synthetic */ Object j;

    public /* synthetic */ d20(ed1 ed1Var, bd1 bd1Var, Float f, Float f2, yv yvVar, int i) {
        this.f = ed1Var;
        this.g = bd1Var;
        this.h = f;
        this.i = f2;
        this.j = yvVar;
    }

    @Override // defpackage.m00
    public final Object f(Object obj, Object obj2) {
        boolean z;
        int i = this.e;
        we1 we1Var = we1.a;
        Object obj3 = this.j;
        Object obj4 = this.i;
        Object obj5 = this.h;
        Object obj6 = this.g;
        Object obj7 = this.f;
        switch (i) {
            case 0:
                String str = (String) obj7;
                mk0 mk0Var = (mk0) obj5;
                String str2 = (String) obj6;
                t41 t41Var = (t41) obj4;
                Context context = (Context) obj3;
                d10 d10Var = (d10) obj;
                int intValue = ((Integer) obj2).intValue();
                if ((intValue & 3) != 2) {
                    z = true;
                } else {
                    z = false;
                }
                if (d10Var.O(intValue & 1, z)) {
                    boolean p = k70.p(str, "messages");
                    nq0 nq0Var = oj.a;
                    if (p) {
                        d10Var.W(2052150207);
                        boolean f = d10Var.f(mk0Var);
                        Object L = d10Var.L();
                        if (f || L == nq0Var) {
                            L = new a20(mk0Var, 1);
                            d10Var.g0(L);
                        }
                        zh0.a((xz) L, d10Var, 0);
                        d10Var.p(false);
                    } else {
                        d10Var.W(2052154767);
                        boolean h = d10Var.h(context) | d10Var.f(mk0Var);
                        Object L2 = d10Var.L();
                        if (h || L2 == nq0Var) {
                            L2 = new e20(context, mk0Var, 0);
                            d10Var.g0(L2);
                        }
                        j70.d(str2, t41Var, (xz) L2, d10Var, 0);
                        d10Var.p(false);
                    }
                } else {
                    d10Var.R();
                }
                return we1Var;
            default:
                ((Integer) obj2).getClass();
                gd1.a((ed1) obj7, (bd1) obj6, (Float) obj5, (Float) obj4, (yv) obj3, (d10) obj, wc0.s(1));
                return we1Var;
        }
    }

    public /* synthetic */ d20(String str, mk0 mk0Var, String str2, t41 t41Var, Context context) {
        this.f = str;
        this.h = mk0Var;
        this.g = str2;
        this.i = t41Var;
        this.j = context;
    }
}