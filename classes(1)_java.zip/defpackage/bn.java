package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bn  reason: default package */
public final class bn extends u91 implements m00 {
    public final /* synthetic */ int i;
    public int j;
    public final /* synthetic */ tn k;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ bn(tn tnVar, ml mlVar, int i) {
        super(2, mlVar);
        this.i = i;
        this.k = tnVar;
    }

    @Override // defpackage.m00
    public final Object f(Object obj, Object obj2) {
        int i = this.i;
        we1 we1Var = we1.a;
        switch (i) {
            case 0:
                return ((bn) n((ml) obj2, (uw) obj)).p(we1Var);
            case 1:
                return ((bn) n((ml) obj2, (bm) obj)).p(we1Var);
            default:
                return ((bn) n((ml) obj2, (bm) obj)).p(we1Var);
        }
    }

    @Override // defpackage.db
    public final ml n(ml mlVar, Object obj) {
        int i = this.i;
        tn tnVar = this.k;
        switch (i) {
            case 0:
                return new bn(tnVar, mlVar, 0);
            case 1:
                return new bn(tnVar, mlVar, 1);
            default:
                return new bn(tnVar, mlVar, 2);
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:18:0x003f, code lost:
        if (defpackage.tn.e(r7, r9) == r6) goto L17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x0049, code lost:
        if (r10 == r6) goto L17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x007f, code lost:
        if (r10 == r6) goto L40;
     */
    /* JADX WARN: Code restructure failed: missing block: B:56:?, code lost:
        return r6;
     */
    @Override // defpackage.db
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object p(Object obj) {
        int i = this.i;
        we1 we1Var = we1.a;
        cm cmVar = cm.e;
        tn tnVar = this.k;
        switch (i) {
            case 0:
                int i2 = this.j;
                if (i2 != 0) {
                    if (i2 == 1) {
                        nb0.t(obj);
                        return we1Var;
                    }
                    od.p("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                nb0.t(obj);
                this.j = 1;
                if (tn.c(tnVar, this) == cmVar) {
                    return cmVar;
                }
                return we1Var;
            case 1:
                int i3 = this.j;
                if (i3 != 0) {
                    if (i3 != 1) {
                        if (i3 == 2) {
                            nb0.t(obj);
                            return we1Var;
                        }
                        od.p("call to 'resume' before 'invoke' with coroutine");
                        return null;
                    }
                    nb0.t(obj);
                } else {
                    nb0.t(obj);
                    p3 p3Var = tnVar.l;
                    this.j = 1;
                    Object e0 = ((uh) p3Var.f).e0(this);
                    if (e0 != cmVar) {
                        e0 = we1Var;
                        break;
                    }
                }
                tw o = wl1.o(tnVar.h().c, -1);
                rd rdVar = new rd(1, tnVar);
                this.j = 2;
                if (o.b(rdVar, this) != cmVar) {
                    return we1Var;
                }
                return cmVar;
            default:
                pg0 pg0Var = tnVar.k;
                int i4 = this.j;
                try {
                    if (i4 != 0) {
                        if (i4 != 1) {
                            if (i4 == 2) {
                                nb0.t(obj);
                                return (z71) obj;
                            }
                            od.p("call to 'resume' before 'invoke' with coroutine");
                            return null;
                        }
                        nb0.t(obj);
                    } else {
                        nb0.t(obj);
                        if (pg0Var.o() instanceof xv) {
                            return pg0Var.o();
                        }
                        this.j = 1;
                        break;
                    }
                    this.j = 2;
                    obj = tn.f(tnVar, false, this);
                    break;
                } catch (Throwable th) {
                    return new sv0(th, -1);
                }
        }
    }
}