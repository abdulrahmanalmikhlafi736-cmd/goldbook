package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: c8  reason: default package */
public final class c8 {
    public final ud1 a;
    public final Object b;
    public final p8 c;
    public final lq0 d;
    public final lq0 e;
    public final al0 f;
    public final u8 g;
    public final u8 h;
    public final u8 i;
    public final u8 j;

    public c8(Object obj, ud1 ud1Var, Float f, int i) {
        u8 u8Var;
        u8 u8Var2;
        f = (i & 4) != 0 ? null : f;
        this.a = ud1Var;
        p8 p8Var = new p8(ud1Var, obj, null, 60);
        this.c = p8Var;
        this.d = mc0.t(Boolean.FALSE);
        this.e = mc0.t(obj);
        this.f = new al0();
        new p71(1.0f, 1500.0f, f);
        u8 u8Var3 = p8Var.g;
        boolean z = u8Var3 instanceof q8;
        if (z) {
            u8Var = k70.e;
        } else if (u8Var3 instanceof r8) {
            u8Var = k70.f;
        } else if (u8Var3 instanceof s8) {
            u8Var = k70.g;
        } else {
            u8Var = k70.h;
        }
        this.g = u8Var;
        if (z) {
            u8Var2 = k70.a;
        } else if (u8Var3 instanceof r8) {
            u8Var2 = k70.b;
        } else if (u8Var3 instanceof s8) {
            u8Var2 = k70.c;
        } else {
            u8Var2 = k70.d;
        }
        this.h = u8Var2;
        this.i = u8Var;
        this.j = u8Var2;
    }

    public static final Object a(c8 c8Var, Object obj) {
        ud1 ud1Var = c8Var.a;
        u8 u8Var = c8Var.j;
        u8 u8Var2 = c8Var.i;
        if (!k70.p(u8Var2, c8Var.g) || !k70.p(u8Var, c8Var.h)) {
            u8 u8Var3 = (u8) ud1Var.a.i(obj);
            int b = u8Var3.b();
            boolean z = false;
            for (int i = 0; i < b; i++) {
                if (u8Var3.a(i) < u8Var2.a(i) || u8Var3.a(i) > u8Var.a(i)) {
                    u8Var3.e(sb0.g(u8Var3.a(i), u8Var2.a(i), u8Var.a(i)), i);
                    z = true;
                }
            }
            if (z) {
                return ud1Var.b.i(u8Var3);
            }
        }
        return obj;
    }

    public static final void b(c8 c8Var) {
        p8 p8Var = c8Var.c;
        p8Var.g.d();
        p8Var.h = Long.MIN_VALUE;
        c8Var.d.setValue(Boolean.FALSE);
    }

    public static Object c(c8 c8Var, Comparable comparable, o8 o8Var, nl nlVar) {
        Object i = c8Var.a.b.i(c8Var.c.g);
        Object d = c8Var.d();
        ud1 ud1Var = c8Var.a;
        return al0.a(c8Var.f, new a8(c8Var, i, new ja1(o8Var, ud1Var, d, comparable, (u8) ud1Var.a.i(i)), c8Var.c.h, null), nlVar);
    }

    public final Object d() {
        return this.c.f.getValue();
    }

    public final Object e(br brVar, nl nlVar) {
        Object a = al0.a(this.f, new b8(this, brVar, null), nlVar);
        if (a == cm.e) {
            return a;
        }
        return we1.a;
    }
}