package defpackage;

import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: b71  reason: default package */
public final class b71 {
    public final i00 a;
    public boolean c;
    public m2 h;
    public a71 i;
    public final AtomicReference b = new AtomicReference(null);
    public final hc d = new hc(16, this);
    public final l e = new l(25, this);
    public final qk0 f = new qk0(new a71[16]);
    public final Object g = new Object();
    public long j = -1;

    public b71(i00 i00Var) {
        this.a = i00Var;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final boolean a() {
        boolean z;
        Set set;
        Set set2;
        synchronized (this.g) {
            z = this.c;
        }
        if (z) {
            return false;
        }
        boolean z2 = false;
        while (true) {
            AtomicReference atomicReference = this.b;
            while (true) {
                Object obj = atomicReference.get();
                set = null;
                List list = null;
                List list2 = null;
                if (obj == null) {
                    break;
                }
                if (obj instanceof Set) {
                    set2 = (Set) obj;
                } else if (obj instanceof List) {
                    List list3 = (List) obj;
                    Set set3 = (Set) list3.get(0);
                    if (list3.size() == 2) {
                        list2 = list3.get(1);
                    } else if (list3.size() > 2) {
                        list2 = list3.subList(1, list3.size());
                    }
                    set2 = set3;
                    list = list2;
                } else {
                    qj.b("Unexpected notification");
                    throw new RuntimeException();
                }
                while (!atomicReference.compareAndSet(obj, list)) {
                    if (atomicReference.get() != obj) {
                        break;
                    }
                }
                set = set2;
                break;
            }
            if (set == null) {
                return z2;
            }
            synchronized (this.g) {
                qk0 qk0Var = this.f;
                Object[] objArr = qk0Var.e;
                int i = qk0Var.g;
                for (int i2 = 0; i2 < i; i2++) {
                    if (!((a71) objArr[i2]).a(set) && !z2) {
                        z2 = false;
                    } else {
                        z2 = true;
                    }
                }
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:141:0x01e9 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r3v12 */
    /* JADX WARN: Type inference failed for: r3v3 */
    /* JADX WARN: Type inference failed for: r3v6 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void b(Object obj, i00 i00Var, xz xzVar) {
        lk0 lk0Var;
        a71 a71Var;
        a71 a71Var2;
        a71 a71Var3;
        long j;
        b71 b71Var;
        g61 hd1Var;
        g61 j2;
        a71 a71Var4;
        int i;
        int i2;
        long j3;
        int i3;
        a71 a71Var5;
        boolean z;
        long j4 = kb0.j();
        synchronized (this.g) {
            qk0 qk0Var = this.f;
            Object[] objArr = qk0Var.e;
            int i4 = qk0Var.g;
            int i5 = 0;
            while (true) {
                lk0Var = null;
                if (i5 < i4) {
                    Object obj2 = objArr[i5];
                    if (((a71) obj2).a == i00Var) {
                        a71Var = obj2;
                        break;
                    }
                    i5++;
                } else {
                    a71Var = null;
                    break;
                }
            }
            a71Var2 = a71Var;
            if (a71Var2 == null) {
                i00Var.getClass();
                vd1.e(1, i00Var);
                a71Var2 = new a71(i00Var);
                qk0Var.b(a71Var2);
            }
            a71Var3 = this.i;
            j = this.j;
        }
        if (j != -1 && j != j4) {
            rt0.a("Detected multithreaded access to SnapshotStateObserver: previousThreadId=" + j + "), currentThread={id=" + j4 + ", name=" + Thread.currentThread().getName() + "}. Note that observation on multiple threads in layout/draw is not supported. Make sure your measure/layout/draw for each Owner (AndroidComposeView) is executed on the same thread.");
        }
        try {
            synchronized (this.g) {
                try {
                    this.i = a71Var2;
                    this.j = j4;
                } catch (Throwable th) {
                    th = th;
                    b71Var = j4;
                }
            }
            l lVar = this.e;
            Object obj3 = a71Var2.b;
            zj0 zj0Var = a71Var2.c;
            int i6 = a71Var2.d;
            a71Var2.b = obj;
            a71Var2.c = (zj0) a71Var2.f.g(obj);
            if (a71Var2.d == -1) {
                long g = n61.j().g();
                a71Var2.d = (int) (g ^ (g >>> 32));
            }
            c10 c10Var = a71Var2.i;
            qk0 i7 = mc0.i();
            try {
                i7.b(c10Var);
                if (lVar == null) {
                    xzVar.a();
                } else {
                    g61 g61Var = (g61) n61.b.p();
                    if (g61Var instanceof hd1) {
                        try {
                            if (((hd1) g61Var).t == kb0.j()) {
                                i00 i00Var2 = ((hd1) g61Var).r;
                                i00 i00Var3 = ((hd1) g61Var).s;
                                ((hd1) g61Var).r = n61.k(lVar, i00Var2, true);
                                ((hd1) g61Var).s = i00Var3;
                                xzVar.a();
                                ((hd1) g61Var).r = i00Var2;
                                ((hd1) g61Var).s = i00Var3;
                            }
                        } catch (Throwable th2) {
                            th = th2;
                            j4 = this;
                            i7.k(i7.g - 1);
                            throw th;
                        }
                    }
                    try {
                        try {
                            if (g61Var != null && !(g61Var instanceof lk0)) {
                                hd1Var = g61Var.u(lVar);
                                j2 = hd1Var.j();
                                xzVar.a();
                                g61.q(j2);
                                hd1Var.c();
                            }
                            xzVar.a();
                            g61.q(j2);
                            hd1Var.c();
                        } catch (Throwable th3) {
                            j4 = this;
                            try {
                                g61.q(j2);
                                throw th3;
                            } catch (Throwable th4) {
                                th = th4;
                                try {
                                    hd1Var.c();
                                    throw th;
                                } catch (Throwable th5) {
                                    th = th5;
                                    i7.k(i7.g - 1);
                                    throw th;
                                }
                            }
                        }
                        j2 = hd1Var.j();
                    } catch (Throwable th6) {
                        th = th6;
                        j4 = this;
                    }
                    if (g61Var instanceof lk0) {
                        lk0Var = (lk0) g61Var;
                    }
                    hd1Var = new hd1(lk0Var, lVar, null, true, false);
                }
                try {
                    i7.k(i7.g - 1);
                    Object obj4 = a71Var2.b;
                    obj4.getClass();
                    int i8 = a71Var2.d;
                    zj0 zj0Var2 = a71Var2.c;
                    if (zj0Var2 != null) {
                        long[] jArr = zj0Var2.a;
                        int length = jArr.length - 2;
                        if (length >= 0) {
                            boolean z2 = true;
                            int i9 = 0;
                            while (true) {
                                long j5 = jArr[i9];
                                boolean z3 = z2;
                                a71 a71Var6 = a71Var2;
                                if ((((~j5) << 7) & j5 & (-9187201950435737472L)) != -9187201950435737472L) {
                                    int i10 = 8 - ((~(i9 - length)) >>> 31);
                                    int i11 = 0;
                                    while (i11 < i10) {
                                        if ((j5 & 255) < 128) {
                                            j3 = j5;
                                            int i12 = (i9 << 3) + i11;
                                            Object obj5 = zj0Var2.b[i12];
                                            i3 = i11;
                                            if (zj0Var2.c[i12] != i8) {
                                                z = z3;
                                            } else {
                                                z = false;
                                            }
                                            if (z) {
                                                i2 = i8;
                                                a71Var5 = a71Var6;
                                                a71Var5.c(obj4, obj5);
                                            } else {
                                                i2 = i8;
                                                a71Var5 = a71Var6;
                                            }
                                            if (z) {
                                                zj0Var2.f(i12);
                                            }
                                        } else {
                                            i2 = i8;
                                            j3 = j5;
                                            i3 = i11;
                                            a71Var5 = a71Var6;
                                        }
                                        j5 = j3 >> 8;
                                        i11 = i3 + 1;
                                        a71Var6 = a71Var5;
                                        i8 = i2;
                                    }
                                    i = i8;
                                    a71Var4 = a71Var6;
                                    if (i10 != 8) {
                                        break;
                                    }
                                } else {
                                    i = i8;
                                    a71Var4 = a71Var6;
                                }
                                if (i9 == length) {
                                    break;
                                }
                                i9++;
                                z2 = z3;
                                a71Var2 = a71Var4;
                                i8 = i;
                            }
                            a71Var4.b = obj3;
                            a71Var4.c = zj0Var;
                            a71Var4.d = i6;
                            synchronized (this.g) {
                                this.i = a71Var3;
                                this.j = j;
                            }
                            return;
                        }
                    }
                    a71Var4 = a71Var2;
                    a71Var4.b = obj3;
                    a71Var4.c = zj0Var;
                    a71Var4.d = i6;
                    synchronized (this.g) {
                    }
                } catch (Throwable th7) {
                    th = th7;
                    b71Var = this;
                    synchronized (b71Var.g) {
                        b71Var.i = a71Var3;
                        b71Var.j = j;
                    }
                    throw th;
                }
            } catch (Throwable th8) {
                th = th8;
                j4 = this;
            }
        } catch (Throwable th9) {
            th = th9;
            b71Var = this;
        }
    }

    public final void c() {
        hc hcVar = this.d;
        n61.e(n61.a);
        synchronized (n61.c) {
            n61.h = tg.Y(n61.h, hcVar);
        }
        this.h = new m2(hcVar);
    }
}