package defpackage;

import android.graphics.Rect;
import android.view.WindowInsets;
import java.util.List;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ck1  reason: default package */
public final class ck1 extends bk1 {
    public ck1(hk1 hk1Var, WindowInsets windowInsets) {
        super(hk1Var, windowInsets);
    }

    @Override // defpackage.vj1, defpackage.dk1
    public List<Rect> f(int i) {
        List<Rect> boundingRects;
        boundingRects = this.c.getBoundingRects(gk1.a(i));
        return boundingRects;
    }

    @Override // defpackage.vj1, defpackage.dk1
    public List<Rect> g(int i) {
        List<Rect> boundingRectsIgnoringVisibility;
        boundingRectsIgnoringVisibility = this.c.getBoundingRectsIgnoringVisibility(gk1.a(i));
        return boundingRectsIgnoringVisibility;
    }

    @Override // defpackage.vj1, defpackage.dk1
    public void q() {
    }

    public ck1(hk1 hk1Var, ck1 ck1Var) {
        super(hk1Var, ck1Var);
    }
}