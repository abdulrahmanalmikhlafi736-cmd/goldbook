package defpackage;

import java.util.Map;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ag0  reason: default package */
public final class ag0 implements nh0 {
    public final /* synthetic */ int a;
    public final /* synthetic */ int b;
    public final /* synthetic */ Map c;
    public final /* synthetic */ i00 d;
    public final /* synthetic */ i00 e;
    public final /* synthetic */ bg0 f;

    public ag0(int i, int i2, Map map, i00 i00Var, i00 i00Var2, bg0 bg0Var) {
        this.a = i;
        this.b = i2;
        this.c = map;
        this.d = i00Var;
        this.e = i00Var2;
        this.f = bg0Var;
    }

    @Override // defpackage.nh0
    public final void a() {
        this.e.i(this.f.p);
    }

    @Override // defpackage.nh0
    public final int b() {
        return this.b;
    }

    @Override // defpackage.nh0
    public final Map c() {
        return this.c;
    }

    @Override // defpackage.nh0
    public final i00 d() {
        return this.d;
    }

    @Override // defpackage.nh0
    public final int e() {
        return this.a;
    }
}