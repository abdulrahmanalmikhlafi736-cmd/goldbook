package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dp  reason: default package */
public abstract class dp extends li0 {
    public final int s = hm0.e(this);
    public li0 t;

    @Override // defpackage.li0
    public final void f0() {
        super.f0();
        for (li0 li0Var = this.t; li0Var != null; li0Var = li0Var.j) {
            li0Var.q0(this.l);
            if (!li0Var.r) {
                li0Var.f0();
            }
        }
    }

    @Override // defpackage.li0
    public final void g0() {
        for (li0 li0Var = this.t; li0Var != null; li0Var = li0Var.j) {
            li0Var.g0();
        }
        super.g0();
    }

    @Override // defpackage.li0
    public final void m0() {
        super.m0();
        for (li0 li0Var = this.t; li0Var != null; li0Var = li0Var.j) {
            li0Var.m0();
        }
    }

    @Override // defpackage.li0
    public final void n0() {
        for (li0 li0Var = this.t; li0Var != null; li0Var = li0Var.j) {
            li0Var.n0();
        }
        super.n0();
    }

    @Override // defpackage.li0
    public final void o0() {
        super.o0();
        for (li0 li0Var = this.t; li0Var != null; li0Var = li0Var.j) {
            li0Var.o0();
        }
    }

    @Override // defpackage.li0
    public final void p0(li0 li0Var) {
        this.e = li0Var;
        for (li0 li0Var2 = this.t; li0Var2 != null; li0Var2 = li0Var2.j) {
            li0Var2.p0(li0Var);
        }
    }

    @Override // defpackage.li0
    public final void q0(gm0 gm0Var) {
        this.l = gm0Var;
        for (li0 li0Var = this.t; li0Var != null; li0Var = li0Var.j) {
            li0Var.q0(gm0Var);
        }
    }

    public final cp r0(cp cpVar) {
        li0 li0Var;
        li0 li0Var2;
        li0 li0Var3 = ((li0) cpVar).e;
        if (li0Var3 != cpVar) {
            if (cpVar instanceof li0) {
                li0Var = (li0) cpVar;
            } else {
                li0Var = null;
            }
            if (li0Var != null) {
                li0Var2 = li0Var.i;
            } else {
                li0Var2 = null;
            }
            if (li0Var3 != this.e || !k70.p(li0Var2, this)) {
                od.p("Cannot delegate to an already delegated node");
                return null;
            }
        } else {
            if (li0Var3.r) {
                p50.b("Cannot delegate to an already attached node");
            }
            li0Var3.p0(this.e);
            int i = this.g;
            int f = hm0.f(li0Var3);
            li0Var3.g = f;
            int i2 = this.g;
            int i3 = f & 2;
            if (i3 != 0 && (i2 & 2) != 0 && !(this instanceof t90)) {
                p50.b("Delegating to multiple LayoutModifierNodes without the delegating node implementing LayoutModifierNode itself is not allowed.\nDelegating Node: " + this + "\nDelegate Node: " + li0Var3);
            }
            li0Var3.j = this.t;
            this.t = li0Var3;
            li0Var3.i = this;
            t0(f | this.g, false);
            if (this.r) {
                if (i3 != 0 && (i & 2) == 0) {
                    em0 em0Var = k70.O(this).J;
                    this.e.q0(null);
                    em0Var.g();
                } else {
                    q0(this.l);
                }
                li0Var3.f0();
                li0Var3.n0();
                if (!li0Var3.r) {
                    p50.b("autoInvalidateInsertedNode called on unattached node");
                }
                hm0.a(li0Var3, -1, 1);
            }
        }
        return cpVar;
    }

    public final void s0(cp cpVar) {
        li0 li0Var = null;
        for (li0 li0Var2 = this.t; li0Var2 != null; li0Var2 = li0Var2.j) {
            if (li0Var2 == cpVar) {
                boolean z = li0Var2.r;
                if (z) {
                    zj0 zj0Var = hm0.a;
                    if (!z) {
                        p50.b("autoInvalidateRemovedNode called on unattached node");
                    }
                    hm0.a(li0Var2, -1, 2);
                    li0Var2.o0();
                    li0Var2.g0();
                }
                li0Var2.p0(li0Var2);
                li0Var2.h = 0;
                li0 li0Var3 = li0Var2.j;
                if (li0Var == null) {
                    this.t = li0Var3;
                } else {
                    li0Var.j = li0Var3;
                }
                li0Var2.j = null;
                li0Var2.i = null;
                int i = this.g;
                int f = hm0.f(this);
                t0(f, true);
                if (this.r && (i & 2) != 0 && (f & 2) == 0) {
                    em0 em0Var = k70.O(this).J;
                    this.e.q0(null);
                    em0Var.g();
                    return;
                }
                return;
            }
            li0Var = li0Var2;
        }
        od.l(cpVar, "Could not find delegate: ");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r2v1, types: [li0] */
    /* JADX WARN: Type inference failed for: r2v5 */
    public final void t0(int i, boolean z) {
        int i2;
        li0 li0Var;
        int i3 = this.g;
        this.g = i;
        if (i3 != i) {
            li0 li0Var2 = this.e;
            if (li0Var2 == this) {
                this.h = i;
            }
            boolean z2 = this.r;
            ?? r2 = this;
            if (z2) {
                while (r2 != 0) {
                    i |= r2.g;
                    r2.g = i;
                    if (r2 == li0Var2) {
                        break;
                    }
                    r2 = r2.i;
                }
                if (z && r2 == li0Var2) {
                    i = hm0.f(li0Var2);
                    li0Var2.g = i;
                }
                if (r2 != 0 && (li0Var = r2.j) != null) {
                    i2 = li0Var.h;
                } else {
                    i2 = 0;
                }
                int i4 = i | i2;
                for (li0 li0Var3 = r2; li0Var3 != null; li0Var3 = li0Var3.i) {
                    i4 |= li0Var3.g;
                    li0Var3.h = i4;
                }
            }
        }
    }
}