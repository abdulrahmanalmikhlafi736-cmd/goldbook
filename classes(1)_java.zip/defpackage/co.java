package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: co  reason: default package */
public final class co implements t40 {
    public static final co a = new Object();

    @Override // defpackage.t40
    public final cp a(uj0 uj0Var) {
        return new bo(uj0Var);
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        return false;
    }

    @Override // defpackage.t40
    public final int hashCode() {
        return -1;
    }
}