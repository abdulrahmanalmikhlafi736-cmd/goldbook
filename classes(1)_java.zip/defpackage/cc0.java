package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cc0  reason: default package */
public final class cc0 extends u91 implements m00 {
    public int i;
    public final /* synthetic */ dc0 j;
    public final /* synthetic */ int k;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public cc0(dc0 dc0Var, int i, ml mlVar) {
        super(2, mlVar);
        this.j = dc0Var;
        this.k = i;
    }

    @Override // defpackage.m00
    public final Object f(Object obj, Object obj2) {
        return ((cc0) n((ml) obj2, (bm) obj)).p(we1.a);
    }

    @Override // defpackage.db
    public final ml n(ml mlVar, Object obj) {
        return new cc0(this.j, this.k, mlVar);
    }

    @Override // defpackage.db
    public final Object p(Object obj) {
        int i = this.i;
        we1 we1Var = we1.a;
        if (i != 0) {
            if (i == 1) {
                nb0.t(obj);
                return we1Var;
            }
            od.p("call to 'resume' before 'invoke' with coroutine");
            return null;
        }
        nb0.t(obj);
        yb0 yb0Var = this.j.t;
        this.i = 1;
        sc0 sc0Var = yb0Var.b;
        al alVar = sc0.x;
        sc0Var.getClass();
        Object d = sc0Var.d(tk0.e, new ao(sc0Var, this.k, (ml) null), this);
        cm cmVar = cm.e;
        if (d != cmVar) {
            d = we1Var;
        }
        if (d != cmVar) {
            d = we1Var;
        }
        if (d == cmVar) {
            return cmVar;
        }
        return we1Var;
    }
}