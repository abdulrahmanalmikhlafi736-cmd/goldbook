package defpackage;

import java.util.ArrayList;
import java.util.List;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: c3  reason: default package */
public final /* synthetic */ class c3 implements m00 {
    public final /* synthetic */ int e;
    public final /* synthetic */ m00 f;

    public /* synthetic */ c3(int i, m00 m00Var) {
        this.e = i;
        this.f = m00Var;
    }

    @Override // defpackage.m00
    public final Object f(Object obj, Object obj2) {
        boolean z;
        boolean z2;
        mz0 mz0Var;
        boolean z3;
        boolean z4;
        int i = this.e;
        ji0 ji0Var = ji0.a;
        we1 we1Var = we1.a;
        m00 m00Var = this.f;
        switch (i) {
            case 0:
                d10 d10Var = (d10) obj;
                int intValue = ((Integer) obj2).intValue();
                if ((intValue & 3) != 2) {
                    z = true;
                } else {
                    z = false;
                }
                if (d10Var.O(intValue & 1, z)) {
                    mi0 b = ac.C(ji0Var, d3.b).b(new f30(e3.q));
                    mh0 d = ic.d(e3.f, false);
                    long j = d10Var.T;
                    int i2 = (int) ((j >>> 32) ^ j);
                    qr0 l = d10Var.l();
                    mi0 I = vn.I(d10Var, b);
                    ij.c.getClass();
                    dk dkVar = hj.b;
                    d10Var.Z();
                    if (d10Var.S) {
                        d10Var.k(dkVar);
                    } else {
                        d10Var.j0();
                    }
                    mc0.B(hj.f, d10Var, d);
                    mc0.B(hj.e, d10Var, l);
                    mc0.p(d10Var, Integer.valueOf(i2), hj.g);
                    mc0.w(d10Var, hj.h);
                    mc0.B(hj.d, d10Var, I);
                    m00Var.f(d10Var, 0);
                    d10Var.p(true);
                } else {
                    d10Var.R();
                }
                return we1Var;
            case 1:
                d10 d10Var2 = (d10) obj;
                int intValue2 = ((Integer) obj2).intValue();
                if ((intValue2 & 3) != 2) {
                    z2 = true;
                } else {
                    z2 = false;
                }
                if (d10Var2.O(intValue2 & 1, z2)) {
                    mi0 b2 = ac.C(new ra0(1.0f, false), d3.c).b(new f30(e3.q));
                    mh0 d2 = ic.d(e3.f, false);
                    long j2 = d10Var2.T;
                    int i3 = (int) ((j2 >>> 32) ^ j2);
                    qr0 l2 = d10Var2.l();
                    mi0 I2 = vn.I(d10Var2, b2);
                    ij.c.getClass();
                    dk dkVar2 = hj.b;
                    d10Var2.Z();
                    if (d10Var2.S) {
                        d10Var2.k(dkVar2);
                    } else {
                        d10Var2.j0();
                    }
                    mc0.B(hj.f, d10Var2, d2);
                    mc0.B(hj.e, d10Var2, l2);
                    mc0.p(d10Var2, Integer.valueOf(i3), hj.g);
                    mc0.w(d10Var2, hj.h);
                    mc0.B(hj.d, d10Var2, I2);
                    m00Var.f(d10Var2, 0);
                    d10Var2.p(true);
                } else {
                    d10Var2.R();
                }
                return we1Var;
            case 2:
                iz0 iz0Var = (iz0) obj;
                List list = (List) m00Var.f(iz0Var, obj2);
                int size = list.size();
                for (int i4 = 0; i4 < size; i4++) {
                    Object obj3 = list.get(i4);
                    if (obj3 != null && (mz0Var = iz0Var.f) != null && !mz0Var.d(obj3)) {
                        throw new IllegalArgumentException(("item at index " + i4 + " can't be saved: " + obj3).toString());
                    }
                }
                if (!list.isEmpty()) {
                    return new ArrayList(list);
                }
                return null;
            case 3:
                d10 d10Var3 = (d10) obj;
                int intValue3 = ((Integer) obj2).intValue();
                if ((intValue3 & 3) != 2) {
                    z3 = true;
                } else {
                    z3 = false;
                }
                if (d10Var3.O(intValue3 & 1, z3)) {
                    mh0 d3 = ic.d(e3.f, false);
                    long j3 = d10Var3.T;
                    int i5 = (int) ((j3 >>> 32) ^ j3);
                    qr0 l3 = d10Var3.l();
                    mi0 I3 = vn.I(d10Var3, ji0Var);
                    ij.c.getClass();
                    dk dkVar3 = hj.b;
                    d10Var3.Z();
                    if (d10Var3.S) {
                        d10Var3.k(dkVar3);
                    } else {
                        d10Var3.j0();
                    }
                    mc0.B(hj.f, d10Var3, d3);
                    mc0.B(hj.e, d10Var3, l3);
                    mc0.p(d10Var3, Integer.valueOf(i5), hj.g);
                    mc0.w(d10Var3, hj.h);
                    mc0.B(hj.d, d10Var3, I3);
                    m00Var.f(d10Var3, 0);
                    d10Var3.p(true);
                } else {
                    d10Var3.R();
                }
                return we1Var;
            default:
                d10 d10Var4 = (d10) obj;
                int intValue4 = ((Integer) obj2).intValue();
                if ((intValue4 & 3) != 2) {
                    z4 = true;
                } else {
                    z4 = false;
                }
                if (d10Var4.O(intValue4 & 1, z4)) {
                    mh0 d4 = ic.d(e3.f, false);
                    long j4 = d10Var4.T;
                    int i6 = (int) ((j4 >>> 32) ^ j4);
                    qr0 l4 = d10Var4.l();
                    mi0 I4 = vn.I(d10Var4, ji0Var);
                    ij.c.getClass();
                    dk dkVar4 = hj.b;
                    d10Var4.Z();
                    if (d10Var4.S) {
                        d10Var4.k(dkVar4);
                    } else {
                        d10Var4.j0();
                    }
                    mc0.B(hj.f, d10Var4, d4);
                    mc0.B(hj.e, d10Var4, l4);
                    mc0.p(d10Var4, Integer.valueOf(i6), hj.g);
                    mc0.w(d10Var4, hj.h);
                    mc0.B(hj.d, d10Var4, I4);
                    m00Var.f(d10Var4, 0);
                    d10Var4.p(true);
                } else {
                    d10Var4.R();
                }
                return we1Var;
        }
    }
}