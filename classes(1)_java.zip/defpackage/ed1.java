package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ed1  reason: default package */
public final class ed1 {
    public final al a;
    public final ed1 b;
    public final String c;
    public final lq0 d = mc0.t(c());
    public final lq0 e = mc0.t(new ad1(c(), c()));
    public final jq0 f = new jq0(0);
    public final jq0 g = new jq0(Long.MIN_VALUE);
    public final lq0 h;
    public final z61 i;
    public final z61 j;
    public final lq0 k;

    public ed1(al alVar, ed1 ed1Var, String str) {
        this.a = alVar;
        this.b = ed1Var;
        this.c = str;
        Boolean bool = Boolean.FALSE;
        this.h = mc0.t(bool);
        this.i = new z61();
        this.j = new z61();
        this.k = mc0.t(bool);
        mc0.j(new xc1(this, 1));
    }

    public final void a(Object obj, d10 d10Var, int i) {
        int i2;
        boolean z;
        boolean z2;
        int i3;
        boolean h;
        int i4;
        d10Var.X(-1493585151);
        if ((i & 6) == 0) {
            if ((i & 8) == 0) {
                h = d10Var.f(obj);
            } else {
                h = d10Var.h(obj);
            }
            if (h) {
                i4 = 4;
            } else {
                i4 = 2;
            }
            i2 = i4 | i;
        } else {
            i2 = i;
        }
        if ((i & 48) == 0) {
            if (d10Var.f(this)) {
                i3 = 32;
            } else {
                i3 = 16;
            }
            i2 |= i3;
        }
        boolean z3 = true;
        if ((i2 & 19) != 18) {
            z = true;
        } else {
            z = false;
        }
        if (d10Var.O(i2 & 1, z)) {
            if (!g()) {
                d10Var.W(466062241);
                k(obj);
                int i5 = i2 & 112;
                if (i5 == 32) {
                    z2 = true;
                } else {
                    z2 = false;
                }
                Object L = d10Var.L();
                nq0 nq0Var = oj.a;
                if (z2 || L == nq0Var) {
                    L = mc0.j(new xc1(this, 0));
                    d10Var.g0(L);
                }
                if (((Boolean) ((a81) L).getValue()).booleanValue()) {
                    d10Var.W(466470356);
                    Object L2 = d10Var.L();
                    if (L2 == nq0Var) {
                        L2 = j70.y(d10Var);
                        d10Var.g0(L2);
                    }
                    bm bmVar = (bm) L2;
                    boolean h2 = d10Var.h(bmVar);
                    if (i5 != 32) {
                        z3 = false;
                    }
                    boolean z4 = h2 | z3;
                    Object L3 = d10Var.L();
                    if (z4 || L3 == nq0Var) {
                        L3 = new c(24, bmVar, this);
                        d10Var.g0(L3);
                    }
                    j70.c(bmVar, this, (i00) L3, d10Var);
                    d10Var.p(false);
                } else {
                    d10Var.W(467712929);
                    d10Var.p(false);
                }
                d10Var.p(false);
            } else {
                d10Var.W(467722849);
                d10Var.p(false);
            }
        } else {
            d10Var.R();
        }
        xv0 r = d10Var.r();
        if (r != null) {
            r.d = new ni(i, 4, this, obj);
        }
    }

    public final long b() {
        z61 z61Var = this.i;
        int size = z61Var.size();
        long j = 0;
        for (int i = 0; i < size; i++) {
            j = Math.max(j, ((bd1) z61Var.get(i)).n.g());
        }
        z61 z61Var2 = this.j;
        int size2 = z61Var2.size();
        for (int i2 = 0; i2 < size2; i2++) {
            j = Math.max(j, ((ed1) z61Var2.get(i2)).b());
        }
        return j;
    }

    public final Object c() {
        return ((lq0) this.a.g).getValue();
    }

    public final boolean d() {
        z61 z61Var = this.i;
        int size = z61Var.size();
        for (int i = 0; i < size; i++) {
            ((bd1) z61Var.get(i)).getClass();
        }
        z61 z61Var2 = this.j;
        int size2 = z61Var2.size();
        for (int i2 = 0; i2 < size2; i2++) {
            if (((ed1) z61Var2.get(i2)).d()) {
                return true;
            }
        }
        return false;
    }

    public final long e() {
        ed1 ed1Var = this.b;
        if (ed1Var != null) {
            return ed1Var.e();
        }
        return this.f.g();
    }

    public final ad1 f() {
        return (ad1) this.e.getValue();
    }

    public final boolean g() {
        return ((Boolean) this.k.getValue()).booleanValue();
    }

    public final void h(long j, boolean z) {
        long j2;
        al alVar = this.a;
        lq0 lq0Var = (lq0) alVar.f;
        jq0 jq0Var = this.g;
        if (jq0Var.g() == Long.MIN_VALUE) {
            jq0Var.h(j);
            ((lq0) alVar.f).setValue(Boolean.TRUE);
        } else if (!((Boolean) lq0Var.getValue()).booleanValue()) {
            lq0Var.setValue(Boolean.TRUE);
        }
        this.h.setValue(Boolean.FALSE);
        z61 z61Var = this.i;
        int size = z61Var.size();
        boolean z2 = true;
        for (int i = 0; i < size; i++) {
            bd1 bd1Var = (bd1) z61Var.get(i);
            lq0 lq0Var2 = bd1Var.i;
            lq0 lq0Var3 = bd1Var.i;
            if (!((Boolean) lq0Var2.getValue()).booleanValue()) {
                if (z) {
                    j2 = bd1Var.a().c();
                } else {
                    j2 = j;
                }
                bd1Var.l.setValue(bd1Var.a().b(j2));
                bd1Var.m = bd1Var.a().f(j2);
                ja1 a = bd1Var.a();
                a.getClass();
                if (fu0.a(a, j2)) {
                    lq0Var3.setValue(Boolean.TRUE);
                }
            }
            if (!((Boolean) lq0Var3.getValue()).booleanValue()) {
                z2 = false;
            }
        }
        z61 z61Var2 = this.j;
        int size2 = z61Var2.size();
        for (int i2 = 0; i2 < size2; i2++) {
            ed1 ed1Var = (ed1) z61Var2.get(i2);
            if (!k70.p(ed1Var.d.getValue(), ed1Var.c())) {
                ed1Var.h(j, z);
            }
            if (!k70.p(ed1Var.d.getValue(), ed1Var.c())) {
                z2 = false;
            }
        }
        if (z2) {
            i();
        }
    }

    public final void i() {
        this.g.h(Long.MIN_VALUE);
        Object value = this.d.getValue();
        al alVar = this.a;
        ((lq0) alVar.g).setValue(value);
        if (this.b == null) {
            this.f.h(0L);
        }
        ((lq0) alVar.f).setValue(Boolean.FALSE);
        z61 z61Var = this.j;
        int size = z61Var.size();
        for (int i = 0; i < size; i++) {
            ((ed1) z61Var.get(i)).i();
        }
    }

    public final void j(Object obj, Object obj2) {
        this.g.h(Long.MIN_VALUE);
        al alVar = this.a;
        ((lq0) alVar.f).setValue(Boolean.FALSE);
        boolean g = g();
        lq0 lq0Var = this.d;
        if (!g || !k70.p(c(), obj) || !k70.p(lq0Var.getValue(), obj2)) {
            if (!k70.p(c(), obj)) {
                ((lq0) alVar.g).setValue(obj);
            }
            lq0Var.setValue(obj2);
            this.k.setValue(Boolean.TRUE);
            this.e.setValue(new ad1(obj, obj2));
        }
        z61 z61Var = this.j;
        int size = z61Var.size();
        for (int i = 0; i < size; i++) {
            ed1 ed1Var = (ed1) z61Var.get(i);
            ed1Var.getClass();
            if (ed1Var.g()) {
                ed1Var.j(ed1Var.c(), ed1Var.d.getValue());
            }
        }
        z61 z61Var2 = this.i;
        int size2 = z61Var2.size();
        for (int i2 = 0; i2 < size2; i2++) {
            ((bd1) z61Var2.get(i2)).c();
        }
    }

    public final void k(Object obj) {
        lq0 lq0Var = this.d;
        if (!k70.p(lq0Var.getValue(), obj)) {
            this.e.setValue(new ad1(lq0Var.getValue(), obj));
            if (!k70.p(c(), lq0Var.getValue())) {
                ((lq0) this.a.g).setValue(lq0Var.getValue());
            }
            lq0Var.setValue(obj);
            if (this.g.g() == Long.MIN_VALUE) {
                this.h.setValue(Boolean.TRUE);
            }
            z61 z61Var = this.i;
            int size = z61Var.size();
            for (int i = 0; i < size; i++) {
                ((bd1) z61Var.get(i)).j.h(-2.0f);
            }
        }
    }

    public final String toString() {
        z61 z61Var;
        String str = "Transition animation values: ";
        for (int i = 0; i < this.i.size(); i++) {
            str = str + ((bd1) z61Var.get(i)) + ", ";
        }
        return str;
    }
}