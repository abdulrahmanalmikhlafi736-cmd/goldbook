package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ac0  reason: default package */
public final /* synthetic */ class ac0 implements i00 {
    public final /* synthetic */ int e;
    public final /* synthetic */ dc0 f;

    public /* synthetic */ ac0(dc0 dc0Var, int i) {
        this.e = i;
        this.f = dc0Var;
    }

    @Override // defpackage.i00
    public final Object i(Object obj) {
        int i = this.e;
        dc0 dc0Var = this.f;
        switch (i) {
            case 0:
                hc0 hc0Var = (hc0) dc0Var.s.a();
                int c = hc0Var.c();
                int i2 = 0;
                while (true) {
                    if (i2 < c) {
                        if (!hc0Var.d(i2).equals(obj)) {
                            i2++;
                        }
                    } else {
                        i2 = -1;
                    }
                }
                return Integer.valueOf(i2);
            default:
                int intValue = ((Integer) obj).intValue();
                hc0 hc0Var2 = (hc0) dc0Var.s.a();
                if (intValue < 0 || intValue >= hc0Var2.c()) {
                    StringBuilder H = fu0.H(intValue, "Can't scroll to index ", ", it is out of bounds [0, ");
                    H.append(hc0Var2.c());
                    H.append(')');
                    s50.a(H.toString());
                }
                wl1.B(dc0Var.d0(), null, new cc0(dc0Var, intValue, null), 3);
                return Boolean.TRUE;
        }
    }
}