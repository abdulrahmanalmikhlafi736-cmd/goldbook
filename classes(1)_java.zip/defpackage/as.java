package defpackage;

/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: as  reason: default package */
public final class as extends qi0 {
    public final n7 a;

    public as(n7 n7Var) {
        this.a = n7Var;
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [li0, zr] */
    @Override // defpackage.qi0
    public final li0 e() {
        ?? li0Var = new li0();
        li0Var.s = this.a;
        return li0Var;
    }

    public final boolean equals(Object obj) {
        if (this != obj) {
            if (obj instanceof as) {
                if (this.a != ((as) obj).a) {
                    return false;
                }
                return true;
            }
            return false;
        }
        return true;
    }

    @Override // defpackage.qi0
    public final void f(li0 li0Var) {
        ((zr) li0Var).s = this.a;
    }

    public final int hashCode() {
        return this.a.hashCode();
    }
}