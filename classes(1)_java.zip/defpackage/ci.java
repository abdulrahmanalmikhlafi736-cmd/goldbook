package defpackage;

import android.view.View;
import android.view.Window;
import com.almekhlafi.goldbook.MainActivity;
import java.util.LinkedHashMap;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ci  reason: default package */
public final /* synthetic */ class ci implements qd0 {
    public final /* synthetic */ int e;
    public final /* synthetic */ Object f;

    public /* synthetic */ ci(int i, Object obj) {
        this.e = i;
        this.f = obj;
    }

    @Override // defpackage.qd0
    public final void h(sd0 sd0Var, id0 id0Var) {
        Window window;
        View peekDecorView;
        int i = this.e;
        Object obj = this.f;
        switch (i) {
            case 0:
                MainActivity mainActivity = (MainActivity) obj;
                if (id0Var == id0.ON_STOP && (window = mainActivity.getWindow()) != null && (peekDecorView = window.peekDecorView()) != null) {
                    peekDecorView.cancelPendingInputEvents();
                    return;
                }
                return;
            case 1:
                MainActivity mainActivity2 = (MainActivity) obj;
                if (id0Var == id0.ON_DESTROY) {
                    mainActivity2.f.b = null;
                    if (!mainActivity2.isChangingConfigurations()) {
                        LinkedHashMap linkedHashMap = mainActivity2.f().a;
                        for (fh1 fh1Var : linkedHashMap.values()) {
                            fh1Var.b();
                        }
                        linkedHashMap.clear();
                    }
                    gi giVar = mainActivity2.j;
                    MainActivity mainActivity3 = giVar.h;
                    mainActivity3.getWindow().getDecorView().removeCallbacks(giVar);
                    mainActivity3.getWindow().getDecorView().getViewTreeObserver().removeOnDrawListener(giVar);
                    return;
                }
                return;
            default:
                wz0 wz0Var = (wz0) obj;
                if (id0Var == id0.ON_START) {
                    wz0Var.h = true;
                    return;
                } else if (id0Var == id0.ON_STOP) {
                    wz0Var.h = false;
                    return;
                } else {
                    return;
                }
        }
    }
}