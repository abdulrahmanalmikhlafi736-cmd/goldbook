package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: br0  reason: default package */
public final class br0 extends jr0 {
    public final float c;

    public br0(float f) {
        super(3);
        this.c = f;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if ((obj instanceof br0) && Float.compare(this.c, ((br0) obj).c) == 0) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        return Float.floatToIntBits(this.c);
    }

    public final String toString() {
        return fu0.F(new StringBuilder("RelativeHorizontalTo(dx="), this.c, ')');
    }
}