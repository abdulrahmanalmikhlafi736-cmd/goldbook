package defpackage;

import android.graphics.Insets;
import android.view.WindowInsets;
import android.view.WindowInsetsAnimation;
import android.view.animation.Interpolator;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: c1 */
public abstract /* synthetic */ class c1 {
    public static /* bridge */ /* synthetic */ Insets e(WindowInsets windowInsets, int i) {
        return windowInsets.getInsetsIgnoringVisibility(i);
    }

    public static /* bridge */ /* synthetic */ WindowInsets g() {
        return WindowInsets.CONSUMED;
    }

    public static /* synthetic */ WindowInsetsAnimation.Bounds h(Insets insets, Insets insets2) {
        return new WindowInsetsAnimation.Bounds(insets, insets2);
    }

    public static /* synthetic */ WindowInsetsAnimation i(int i, Interpolator interpolator, long j) {
        return new WindowInsetsAnimation(i, interpolator, j);
    }

    public static /* bridge */ /* synthetic */ WindowInsetsAnimation j(Object obj) {
        return (WindowInsetsAnimation) obj;
    }

    public static /* synthetic */ void m() {
    }

    public static /* bridge */ /* synthetic */ boolean w(WindowInsets windowInsets, int i) {
        return windowInsets.isVisible(i);
    }

    public static /* bridge */ /* synthetic */ Insets y(WindowInsets windowInsets, int i) {
        return windowInsets.getInsets(i);
    }
}