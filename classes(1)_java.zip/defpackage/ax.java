package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ax  reason: default package */
public final class ax extends nl {
    public g8 h;
    public Object i;
    public /* synthetic */ Object j;
    public final /* synthetic */ g8 k;
    public int l;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public ax(g8 g8Var, ml mlVar) {
        super(mlVar);
        this.k = g8Var;
    }

    @Override // defpackage.db
    public final Object p(Object obj) {
        this.j = obj;
        this.l |= Integer.MIN_VALUE;
        return this.k.k(null, this);
    }
}