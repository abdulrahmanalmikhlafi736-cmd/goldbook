package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ca1  reason: default package */
public abstract class ca1 {
    public static final float a;
    public static final float b;
    public static final float c;
    public static final float d;
    public static final float e;
    public static final f61 f;

    /* JADX WARN: Type inference failed for: r0v2, types: [f61, java.lang.Object] */
    static {
        float f2 = j70.u;
        a = f2;
        b = j70.E;
        c = j70.B;
        float f3 = j70.y;
        d = f3;
        e = (f3 - f2) / 2.0f;
        f = new Object();
    }

    public static final void a(final boolean z, final i00 i00Var, mi0 mi0Var, boolean z2, z91 z91Var, d10 d10Var, final int i) {
        int i2;
        int i3;
        boolean z3;
        mi0 mi0Var2;
        final boolean z4;
        final z91 z91Var2;
        z91 z91Var3;
        int i4;
        int i5;
        boolean z5;
        boolean z6;
        mi0 mi0Var3;
        d10Var.X(-263339167);
        if (d10Var.g(z)) {
            i2 = 4;
        } else {
            i2 = 2;
        }
        int i6 = i | i2;
        if (d10Var.h(i00Var)) {
            i3 = 32;
        } else {
            i3 = 16;
        }
        int i7 = i6 | i3 | 1666048;
        if ((599187 & i7) != 599186) {
            z3 = true;
        } else {
            z3 = false;
        }
        if (d10Var.O(i7 & 1, z3)) {
            d10Var.T();
            if ((i & 1) != 0 && !d10Var.y()) {
                d10Var.R();
                i5 = i7 & (-458753);
                z5 = z2;
                z91Var3 = z91Var;
            } else {
                dh dhVar = ((dh0) d10Var.j(fh0.a)).a;
                z91Var3 = dhVar.Z;
                long j = dhVar.p;
                if (z91Var3 == null) {
                    long c2 = fh.c(dhVar, j70.t);
                    long c3 = fh.c(dhVar, j70.w);
                    long j2 = zg.h;
                    long c4 = fh.c(dhVar, j70.v);
                    long c5 = fh.c(dhVar, j70.D);
                    long c6 = fh.c(dhVar, j70.G);
                    long c7 = fh.c(dhVar, j70.C);
                    long c8 = fh.c(dhVar, j70.F);
                    i4 = -458753;
                    long q = wl1.q(zg.b(fh.c(dhVar, j70.f), j70.g), j);
                    long c9 = fh.c(dhVar, j70.j);
                    float f2 = j70.k;
                    z91 z91Var4 = new z91(c2, c3, j2, c4, c5, c6, c7, c8, q, wl1.q(zg.b(c9, f2), j), j2, wl1.q(zg.b(fh.c(dhVar, j70.h), j70.i), j), wl1.q(zg.b(fh.c(dhVar, j70.l), j70.m), j), wl1.q(zg.b(fh.c(dhVar, j70.p), f2), j), wl1.q(zg.b(fh.c(dhVar, j70.q), f2), j), wl1.q(zg.b(fh.c(dhVar, j70.n), j70.o), j));
                    dhVar.Z = z91Var4;
                    z91Var3 = z91Var4;
                } else {
                    i4 = -458753;
                }
                i5 = i7 & i4;
                z5 = true;
            }
            int i8 = i5;
            d10Var.q();
            d10Var.W(1768510810);
            Object L = d10Var.L();
            if (L == oj.a) {
                L = new uj0();
                d10Var.g0(L);
            }
            uj0 uj0Var = (uj0) L;
            d10Var.p(false);
            if (i00Var != null) {
                h30 h30Var = b70.a;
                mi0Var3 = vd1.I(fi0.a, z, uj0Var, z5, new iy0(2), i00Var);
                uj0Var = uj0Var;
                z6 = z5;
            } else {
                z6 = z5;
                mi0Var3 = ji0.a;
            }
            mi0Var2 = mi0Var;
            mi0 g = u51.g(mi0Var2.b(mi0Var3));
            float f3 = c;
            float f4 = d;
            z91 z91Var5 = z91Var3;
            b(g.b(new t51(f3, f4, f3, f4, false)), z, z6, z91Var5, uj0Var, d51.a(j70.r, d10Var), d10Var, ((i8 << 3) & 112) | 24960);
            z4 = z6;
            z91Var2 = z91Var5;
        } else {
            mi0Var2 = mi0Var;
            d10Var.R();
            z4 = z2;
            z91Var2 = z91Var;
        }
        xv0 r = d10Var.r();
        if (r != null) {
            final mi0 mi0Var4 = mi0Var2;
            r.d = new m00(z, i00Var, mi0Var4, z4, z91Var2, i) { // from class: aa1
                public final /* synthetic */ boolean e;
                public final /* synthetic */ i00 f;
                public final /* synthetic */ mi0 g;
                public final /* synthetic */ boolean h;
                public final /* synthetic */ z91 i;

                @Override // defpackage.m00
                public final Object f(Object obj, Object obj2) {
                    ((Integer) obj2).getClass();
                    int s = wc0.s(385);
                    ca1.a(this.e, this.f, this.g, this.h, this.i, (d10) obj, s);
                    return we1.a;
                }
            };
        }
    }

    public static final void b(final mi0 mi0Var, final boolean z, final boolean z2, final z91 z91Var, final uj0 uj0Var, final y41 y41Var, d10 d10Var, final int i) {
        int i2;
        boolean z3;
        char c2;
        long j;
        char c3;
        long j2;
        long j3;
        int i3;
        int i4;
        int i5;
        int i6;
        int i7;
        int i8;
        int i9;
        d10Var.X(-670917213);
        if ((i & 6) == 0) {
            if (d10Var.f(mi0Var)) {
                i9 = 4;
            } else {
                i9 = 2;
            }
            i2 = i9 | i;
        } else {
            i2 = i;
        }
        if ((i & 48) == 0) {
            if (d10Var.g(z)) {
                i8 = 32;
            } else {
                i8 = 16;
            }
            i2 |= i8;
        }
        if ((i & 384) == 0) {
            if (d10Var.g(z2)) {
                i7 = 256;
            } else {
                i7 = 128;
            }
            i2 |= i7;
        }
        if ((i & 3072) == 0) {
            if (d10Var.f(z91Var)) {
                i6 = 2048;
            } else {
                i6 = 1024;
            }
            i2 |= i6;
        }
        if ((i & 24576) == 0) {
            if (d10Var.h(null)) {
                i5 = 16384;
            } else {
                i5 = 8192;
            }
            i2 |= i5;
        }
        if ((196608 & i) == 0) {
            if (d10Var.f(uj0Var)) {
                i4 = 131072;
            } else {
                i4 = 65536;
            }
            i2 |= i4;
        }
        if ((1572864 & i) == 0) {
            if (d10Var.f(y41Var)) {
                i3 = 1048576;
            } else {
                i3 = 524288;
            }
            i2 |= i3;
        }
        if ((599187 & i2) != 599186) {
            z3 = true;
        } else {
            z3 = false;
        }
        if (d10Var.O(i2 & 1, z3)) {
            if (z2) {
                if (z) {
                    c2 = ' ';
                    j = z91Var.b;
                } else {
                    c2 = ' ';
                    j = z91Var.f;
                }
            } else {
                c2 = ' ';
                if (z) {
                    j = z91Var.j;
                } else {
                    j = z91Var.n;
                }
            }
            if (z2) {
                c3 = c2;
                if (z) {
                    j2 = z91Var.a;
                } else {
                    j2 = z91Var.e;
                }
            } else {
                c3 = c2;
                if (z) {
                    j2 = z91Var.i;
                } else {
                    j2 = z91Var.m;
                }
            }
            y41 a2 = d51.a(j70.A, d10Var);
            char c4 = c3;
            float f2 = j70.z;
            if (z2) {
                if (z) {
                    j3 = z91Var.c;
                } else {
                    j3 = z91Var.g;
                }
            } else if (z) {
                j3 = z91Var.k;
            } else {
                j3 = z91Var.o;
            }
            mi0 n = wl1.n(mi0Var.b(new zb(f2, new f71(j3), a2)), j, a2);
            mh0 d2 = ic.d(e3.f, false);
            long j4 = d10Var.T;
            int i10 = (int) (j4 ^ (j4 >>> c4));
            qr0 l = d10Var.l();
            mi0 I = vn.I(d10Var, n);
            ij.c.getClass();
            dk dkVar = hj.b;
            d10Var.Z();
            if (d10Var.S) {
                d10Var.k(dkVar);
            } else {
                d10Var.j0();
            }
            s7 s7Var = hj.f;
            mc0.B(s7Var, d10Var, d2);
            s7 s7Var2 = hj.e;
            mc0.B(s7Var2, d10Var, l);
            Integer valueOf = Integer.valueOf(i10);
            s7 s7Var3 = hj.g;
            mc0.p(d10Var, valueOf, s7Var3);
            i4 i4Var = hj.h;
            mc0.w(d10Var, i4Var);
            s7 s7Var4 = hj.d;
            mc0.B(s7Var4, d10Var, I);
            mi0 n2 = wl1.n(p40.a(fu0.l((qi0) e3.x.j(e3.i), new ec1(uj0Var, z, mc0.H(zi0.f, d10Var))), uj0Var, fy0.a(j70.x / 2.0f, 4)), j2, y41Var);
            mh0 d3 = ic.d(e3.j, false);
            long j5 = d10Var.T;
            int i11 = (int) (j5 ^ (j5 >>> c4));
            qr0 l2 = d10Var.l();
            mi0 I2 = vn.I(d10Var, n2);
            d10Var.Z();
            if (d10Var.S) {
                d10Var.k(dkVar);
            } else {
                d10Var.j0();
            }
            mc0.B(s7Var, d10Var, d3);
            mc0.B(s7Var2, d10Var, l2);
            mc0.p(d10Var, Integer.valueOf(i11), s7Var3);
            mc0.w(d10Var, i4Var);
            mc0.B(s7Var4, d10Var, I2);
            d10Var.W(1236071411);
            d10Var.p(false);
            d10Var.p(true);
            d10Var.p(true);
        } else {
            d10Var.R();
        }
        xv0 r = d10Var.r();
        if (r != null) {
            r.d = new m00() { // from class: ba1
                @Override // defpackage.m00
                public final Object f(Object obj, Object obj2) {
                    ((Integer) obj2).getClass();
                    ca1.b(mi0.this, z, z2, z91Var, uj0Var, y41Var, (d10) obj, wc0.s(i | 1));
                    return we1.a;
                }
            };
        }
    }
}