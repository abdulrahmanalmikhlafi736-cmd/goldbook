package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: e8  reason: default package */
public final class e8 extends h90 implements m00 {
    public final /* synthetic */ ed1 f;
    public final /* synthetic */ i00 g;
    public final /* synthetic */ mi0 h;
    public final /* synthetic */ ju i;
    public final /* synthetic */ wu j;
    public final /* synthetic */ m00 k;
    public final /* synthetic */ pi l;
    public final /* synthetic */ int m;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public e8(ed1 ed1Var, i00 i00Var, mi0 mi0Var, ju juVar, wu wuVar, m00 m00Var, pi piVar, int i) {
        super(2);
        this.f = ed1Var;
        this.g = i00Var;
        this.h = mi0Var;
        this.i = juVar;
        this.j = wuVar;
        this.k = m00Var;
        this.l = piVar;
        this.m = i;
    }

    @Override // defpackage.m00
    public final Object f(Object obj, Object obj2) {
        ((Number) obj2).intValue();
        gh0.a(this.f, this.g, this.h, this.i, this.j, this.k, this.l, (d10) obj, wc0.s(this.m | 1));
        return we1.a;
    }
}