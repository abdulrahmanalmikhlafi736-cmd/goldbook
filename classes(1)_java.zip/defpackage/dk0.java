package defpackage;

import java.util.Collection;
import java.util.Iterator;
import java.util.Set;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dk0  reason: default package */
public final class dk0 implements y80, Set, w80 {
    public final bk0 e;
    public final bk0 f;

    public dk0(bk0 bk0Var) {
        bk0Var.getClass();
        this.e = bk0Var;
        this.f = bk0Var;
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean add(Object obj) {
        return this.f.a(obj);
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean addAll(Collection collection) {
        collection.getClass();
        bk0 bk0Var = this.f;
        bk0Var.getClass();
        int i = bk0Var.g;
        for (Object obj : collection) {
            int d = bk0Var.d(obj);
            bk0Var.b[d] = obj;
            long[] jArr = bk0Var.c;
            int i2 = bk0Var.d;
            jArr[d] = (i2 & 2147483647L) | 4611686016279904256L;
            if (i2 != Integer.MAX_VALUE) {
                jArr[i2] = ((2147483647L & d) << 31) | (jArr[i2] & (-4611686016279904257L));
            }
            bk0Var.d = d;
            if (bk0Var.e == Integer.MAX_VALUE) {
                bk0Var.e = d;
            }
        }
        if (i != bk0Var.g) {
            return true;
        }
        return false;
    }

    @Override // java.util.Set, java.util.Collection
    public final void clear() {
        this.f.b();
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean contains(Object obj) {
        return this.e.c(obj);
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean containsAll(Collection collection) {
        collection.getClass();
        for (Object obj : collection) {
            if (!this.e.c(obj)) {
                return false;
            }
        }
        return true;
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && dk0.class == obj.getClass()) {
            return k70.p(this.e, ((dk0) obj).e);
        }
        return false;
    }

    @Override // java.util.Set, java.util.Collection
    public final int hashCode() {
        return this.e.hashCode();
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean isEmpty() {
        if (this.e.g == 0) {
            return true;
        }
        return false;
    }

    @Override // java.util.Set, java.util.Collection, java.lang.Iterable
    public final Iterator iterator() {
        return new m10(this);
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean remove(Object obj) {
        return this.f.g(obj);
    }

    /* JADX WARN: Code restructure failed: missing block: B:17:0x0084, code lost:
        r18 = r4;
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x008d, code lost:
        if (((r9 & ((~r9) << 6)) & (-9187201950435737472L)) == 0) goto L24;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x008f, code lost:
        r15 = -1;
     */
    @Override // java.util.Set, java.util.Collection
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean removeAll(Collection collection) {
        int i;
        int i2;
        int i3;
        collection.getClass();
        bk0 bk0Var = this.f;
        bk0Var.getClass();
        int i4 = bk0Var.g;
        Iterator it = collection.iterator();
        while (true) {
            int i5 = 1;
            int i6 = 0;
            if (!it.hasNext()) {
                break;
            }
            Object next = it.next();
            if (next != null) {
                i = next.hashCode();
            } else {
                i = 0;
            }
            int i7 = i * (-862048943);
            int i8 = i7 ^ (i7 << 16);
            int i9 = i8 & 127;
            int i10 = bk0Var.f;
            int i11 = (i8 >>> 7) & i10;
            while (true) {
                long[] jArr = bk0Var.a;
                int i12 = i11 >> 3;
                int i13 = (i11 & 7) << 3;
                long j = ((jArr[i12 + i5] << (64 - i13)) & ((-i13) >> 63)) | (jArr[i12] >>> i13);
                long j2 = (i9 * 72340172838076673L) ^ j;
                long j3 = (~j2) & (j2 - 72340172838076673L) & (-9187201950435737472L);
                while (true) {
                    if (j3 == 0) {
                        break;
                    }
                    i3 = ((Long.numberOfTrailingZeros(j3) >> 3) + i11) & i10;
                    int i14 = i5;
                    if (k70.p(bk0Var.b[i3], next)) {
                        break;
                    }
                    j3 &= j3 - 1;
                    i5 = i14;
                }
                i6 += 8;
                i11 = (i11 + i6) & i10;
                i5 = i2;
            }
            if (i3 >= 0) {
                bk0Var.h(i3);
            }
        }
        if (i4 != bk0Var.g) {
            return true;
        }
        return false;
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean retainAll(Collection collection) {
        collection.getClass();
        return this.f.i(collection);
    }

    @Override // java.util.Set, java.util.Collection
    public final int size() {
        return this.e.g;
    }

    @Override // java.util.Set, java.util.Collection
    public final Object[] toArray(Object[] objArr) {
        objArr.getClass();
        return vd1.H(this, objArr);
    }

    public final String toString() {
        return this.e.toString();
    }

    @Override // java.util.Set, java.util.Collection
    public final Object[] toArray() {
        return vd1.G(this);
    }
}