package defpackage;

import java.util.AbstractMap;
import java.util.AbstractSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: c61  reason: default package */
public final class c61 extends AbstractMap {
    public static final /* synthetic */ int j = 0;
    public List e;
    public Map f;
    public boolean g;
    public volatile u9 h;
    public Map i;

    /* JADX WARN: Type inference failed for: r0v0, types: [java.util.AbstractMap, c61] */
    public static c61 f() {
        ?? abstractMap = new AbstractMap();
        abstractMap.e = Collections.EMPTY_LIST;
        Map map = Collections.EMPTY_MAP;
        abstractMap.f = map;
        abstractMap.i = map;
        return abstractMap;
    }

    public final int a(Comparable comparable) {
        int i;
        int size = this.e.size();
        int i2 = size - 1;
        if (i2 >= 0) {
            int compareTo = comparable.compareTo(((d61) this.e.get(i2)).e);
            if (compareTo > 0) {
                i = size + 1;
                return -i;
            } else if (compareTo == 0) {
                return i2;
            }
        }
        int i3 = 0;
        while (i3 <= i2) {
            int i4 = (i3 + i2) / 2;
            int compareTo2 = comparable.compareTo(((d61) this.e.get(i4)).e);
            if (compareTo2 < 0) {
                i2 = i4 - 1;
            } else if (compareTo2 > 0) {
                i3 = i4 + 1;
            } else {
                return i4;
            }
        }
        i = i3 + 1;
        return -i;
    }

    public final void b() {
        if (!this.g) {
            return;
        }
        throw new UnsupportedOperationException();
    }

    public final Map.Entry c(int i) {
        return (Map.Entry) this.e.get(i);
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final void clear() {
        b();
        if (!this.e.isEmpty()) {
            this.e.clear();
        }
        if (!this.f.isEmpty()) {
            this.f.clear();
        }
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final boolean containsKey(Object obj) {
        Comparable comparable = (Comparable) obj;
        if (a(comparable) < 0 && !this.f.containsKey(comparable)) {
            return false;
        }
        return true;
    }

    public final Set d() {
        Set entrySet;
        if (this.f.isEmpty()) {
            entrySet = Collections.EMPTY_SET;
        } else {
            entrySet = this.f.entrySet();
        }
        return entrySet;
    }

    public final SortedMap e() {
        b();
        if (this.f.isEmpty() && !(this.f instanceof TreeMap)) {
            TreeMap treeMap = new TreeMap();
            this.f = treeMap;
            this.i = treeMap.descendingMap();
        }
        return (SortedMap) this.f;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final Set entrySet() {
        if (this.h == null) {
            this.h = new u9(1, this);
        }
        return this.h;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final boolean equals(Object obj) {
        if (this != obj) {
            if (!(obj instanceof c61)) {
                return super.equals(obj);
            }
            c61 c61Var = (c61) obj;
            int size = size();
            if (size == c61Var.size()) {
                int size2 = this.e.size();
                if (size2 != c61Var.e.size()) {
                    return ((AbstractSet) entrySet()).equals(c61Var.entrySet());
                }
                for (int i = 0; i < size2; i++) {
                    if (c(i).equals(c61Var.c(i))) {
                    }
                }
                if (size2 != size) {
                    return this.f.equals(c61Var.f);
                }
                return true;
            }
            return false;
        }
        return true;
    }

    @Override // java.util.AbstractMap, java.util.Map
    /* renamed from: g */
    public final Object put(Comparable comparable, Object obj) {
        b();
        int a = a(comparable);
        if (a >= 0) {
            return ((d61) this.e.get(a)).setValue(obj);
        }
        b();
        if (this.e.isEmpty() && !(this.e instanceof ArrayList)) {
            this.e = new ArrayList(16);
        }
        int i = -(a + 1);
        if (i >= 16) {
            return e().put(comparable, obj);
        }
        if (this.e.size() == 16) {
            d61 d61Var = (d61) this.e.remove(15);
            e().put(d61Var.e, d61Var.f);
        }
        this.e.add(i, new d61(this, comparable, obj));
        return null;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final Object get(Object obj) {
        Comparable comparable = (Comparable) obj;
        int a = a(comparable);
        if (a >= 0) {
            return ((d61) this.e.get(a)).f;
        }
        return this.f.get(comparable);
    }

    public final Object h(int i) {
        b();
        Object obj = ((d61) this.e.remove(i)).f;
        if (!this.f.isEmpty()) {
            Iterator it = e().entrySet().iterator();
            List list = this.e;
            Map.Entry entry = (Map.Entry) it.next();
            list.add(new d61(this, (Comparable) entry.getKey(), entry.getValue()));
            it.remove();
        }
        return obj;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final int hashCode() {
        int size = this.e.size();
        int i = 0;
        for (int i2 = 0; i2 < size; i2++) {
            i += ((d61) this.e.get(i2)).hashCode();
        }
        if (this.f.size() > 0) {
            return this.f.hashCode() + i;
        }
        return i;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final Object remove(Object obj) {
        b();
        Comparable comparable = (Comparable) obj;
        int a = a(comparable);
        if (a >= 0) {
            return h(a);
        }
        if (this.f.isEmpty()) {
            return null;
        }
        return this.f.remove(comparable);
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final int size() {
        return this.f.size() + this.e.size();
    }
}