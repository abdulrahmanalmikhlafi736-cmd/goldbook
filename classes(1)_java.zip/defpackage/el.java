package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: el  reason: default package */
public final class el extends u91 implements m00 {
    public int i;
    public /* synthetic */ Object j;
    public final /* synthetic */ mf1 k;
    public final /* synthetic */ gl l;
    public final /* synthetic */ yc m;
    public final /* synthetic */ long n;
    public final /* synthetic */ a80 o;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public el(mf1 mf1Var, gl glVar, yc ycVar, long j, a80 a80Var, ml mlVar) {
        super(2, mlVar);
        this.k = mf1Var;
        this.l = glVar;
        this.m = ycVar;
        this.n = j;
        this.o = a80Var;
    }

    @Override // defpackage.m00
    public final Object f(Object obj, Object obj2) {
        return ((el) n((ml) obj2, (w11) obj)).p(we1.a);
    }

    @Override // defpackage.db
    public final ml n(ml mlVar, Object obj) {
        el elVar = new el(this.k, this.l, this.m, this.n, this.o, mlVar);
        elVar.j = obj;
        return elVar;
    }

    @Override // defpackage.db
    public final Object p(Object obj) {
        int i = this.i;
        if (i != 0) {
            if (i == 1) {
                nb0.t(obj);
            } else {
                od.p("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
        } else {
            nb0.t(obj);
            long j = this.n;
            gl glVar = this.l;
            yc ycVar = this.m;
            float r0 = gl.r0(glVar, ycVar, j);
            mf1 mf1Var = this.k;
            mf1Var.e = r0;
            z7 z7Var = new z7(glVar, mf1Var, this.o, (w11) this.j);
            na naVar = new na(glVar, mf1Var, ycVar, 2);
            this.i = 1;
            Object a = mf1Var.a(z7Var, naVar, this);
            cm cmVar = cm.e;
            if (a == cmVar) {
                return cmVar;
            }
        }
        return we1.a;
    }
}