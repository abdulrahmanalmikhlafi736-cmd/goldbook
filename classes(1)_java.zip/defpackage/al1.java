package defpackage;

import android.content.ContentResolver;
import android.content.Context;
import android.net.Uri;
import android.provider.Settings;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: al1  reason: default package */
public final class al1 extends u91 implements m00 {
    public hd i;
    public int j;
    public /* synthetic */ Object k;
    public final /* synthetic */ ContentResolver l;
    public final /* synthetic */ Uri m;
    public final /* synthetic */ bl1 n;
    public final /* synthetic */ id o;
    public final /* synthetic */ Context p;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public al1(ContentResolver contentResolver, Uri uri, bl1 bl1Var, id idVar, Context context, ml mlVar) {
        super(2, mlVar);
        this.l = contentResolver;
        this.m = uri;
        this.n = bl1Var;
        this.o = idVar;
        this.p = context;
    }

    @Override // defpackage.m00
    public final Object f(Object obj, Object obj2) {
        return ((al1) n((ml) obj2, (uw) obj)).p(we1.a);
    }

    @Override // defpackage.db
    public final ml n(ml mlVar, Object obj) {
        al1 al1Var = new al1(this.l, this.m, this.n, this.o, this.p, mlVar);
        al1Var.k = obj;
        return al1Var;
    }

    /* JADX WARN: Code restructure failed: missing block: B:25:0x007c, code lost:
        if (r6.k(r7, r10) == r5) goto L12;
     */
    /* JADX WARN: Removed duplicated region for block: B:20:0x004f  */
    /* JADX WARN: Removed duplicated region for block: B:21:0x0050  */
    /* JADX WARN: Removed duplicated region for block: B:24:0x005c A[Catch: all -> 0x001c, TRY_LEAVE, TryCatch #0 {all -> 0x001c, blocks: (B:7:0x0016, B:18:0x0043, B:22:0x0054, B:24:0x005c, B:14:0x002b, B:17:0x003c), top: B:31:0x000a }] */
    /* JADX WARN: Removed duplicated region for block: B:27:0x007f  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:25:0x007c -> B:8:0x0019). Please submit an issue!!! */
    @Override // defpackage.db
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object p(Object obj) {
        uw uwVar;
        hd hdVar;
        uw uwVar2;
        hd hdVar2;
        Object b;
        int i = this.j;
        bl1 bl1Var = this.n;
        ContentResolver contentResolver = this.l;
        cm cmVar = cm.e;
        try {
            if (i != 0) {
                if (i != 1) {
                    if (i == 2) {
                        hdVar2 = this.i;
                        uwVar2 = (uw) this.k;
                        nb0.t(obj);
                        uwVar = uwVar2;
                        hdVar = hdVar2;
                        this.k = uwVar;
                        this.i = hdVar;
                        this.j = 1;
                        b = hdVar.b(this);
                        if (b == cmVar) {
                            hd hdVar3 = hdVar;
                            uwVar2 = uwVar;
                            obj = b;
                            hdVar2 = hdVar3;
                            if (!((Boolean) obj).booleanValue()) {
                                hdVar2.c();
                                Float f = new Float(Settings.Global.getFloat(this.p.getContentResolver(), "animator_duration_scale", 1.0f));
                                this.k = uwVar2;
                                this.i = hdVar2;
                                this.j = 2;
                            } else {
                                contentResolver.unregisterContentObserver(bl1Var);
                                return we1.a;
                            }
                        } else {
                            return cmVar;
                        }
                    } else {
                        od.p("call to 'resume' before 'invoke' with coroutine");
                        return null;
                    }
                } else {
                    hdVar2 = this.i;
                    uwVar2 = (uw) this.k;
                    nb0.t(obj);
                    if (!((Boolean) obj).booleanValue()) {
                    }
                }
            } else {
                nb0.t(obj);
                uwVar = (uw) this.k;
                contentResolver.registerContentObserver(this.m, false, bl1Var);
                hdVar = new hd(this.o);
                this.k = uwVar;
                this.i = hdVar;
                this.j = 1;
                b = hdVar.b(this);
                if (b == cmVar) {
                }
            }
        } catch (Throwable th) {
            contentResolver.unregisterContentObserver(bl1Var);
            throw th;
        }
    }
}