package defpackage;

/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bg  reason: default package */
public final class bg extends qi0 {
    public final uj0 a;
    public final t40 b;
    public final boolean c;
    public final boolean d;
    public final iy0 e;
    public final xz f;

    public bg(uj0 uj0Var, t40 t40Var, boolean z, boolean z2, iy0 iy0Var, xz xzVar) {
        this.a = uj0Var;
        this.b = t40Var;
        this.c = z;
        this.d = z2;
        this.e = iy0Var;
        this.f = xzVar;
    }

    @Override // defpackage.qi0
    public final li0 e() {
        return new dg(this.a, this.b, this.c, this.d, this.e, this.f);
    }

    public final boolean equals(Object obj) {
        if (this != obj) {
            if (obj != null && bg.class == obj.getClass()) {
                bg bgVar = (bg) obj;
                if (!k70.p(this.a, bgVar.a) || !k70.p(this.b, bgVar.b) || this.c != bgVar.c || this.d != bgVar.d || !k70.p(this.e, bgVar.e) || this.f != bgVar.f) {
                    return false;
                }
                return true;
            }
            return false;
        }
        return true;
    }

    @Override // defpackage.qi0
    public final void f(li0 li0Var) {
        ((dg) li0Var).z0(this.a, this.b, this.c, this.d, this.e, this.f);
    }

    public final int hashCode() {
        int i;
        int i2;
        int i3;
        int i4 = 0;
        uj0 uj0Var = this.a;
        if (uj0Var != null) {
            i = uj0Var.hashCode();
        } else {
            i = 0;
        }
        int i5 = i * 31;
        t40 t40Var = this.b;
        if (t40Var != null) {
            i2 = t40Var.hashCode();
        } else {
            i2 = 0;
        }
        int i6 = (i5 + i2) * 31;
        int i7 = 1237;
        if (this.c) {
            i3 = 1231;
        } else {
            i3 = 1237;
        }
        int i8 = (i6 + i3) * 31;
        if (this.d) {
            i7 = 1231;
        }
        int i9 = (i8 + i7) * 961;
        iy0 iy0Var = this.e;
        if (iy0Var != null) {
            i4 = iy0Var.a;
        }
        return this.f.hashCode() + ((i9 + i4) * 31);
    }
}