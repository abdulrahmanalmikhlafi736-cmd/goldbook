package defpackage;

import android.window.OnBackInvokedDispatcher;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bi  reason: default package */
public final /* synthetic */ class bi implements qd0 {
    public final /* synthetic */ jn0 e;
    public final /* synthetic */ ki f;

    public /* synthetic */ bi(jn0 jn0Var, ki kiVar) {
        this.e = jn0Var;
        this.f = kiVar;
    }

    @Override // defpackage.qd0
    public final void h(sd0 sd0Var, id0 id0Var) {
        OnBackInvokedDispatcher onBackInvokedDispatcher;
        if (id0Var == id0.ON_CREATE) {
            onBackInvokedDispatcher = this.f.getOnBackInvokedDispatcher();
            onBackInvokedDispatcher.getClass();
            this.e.b(onBackInvokedDispatcher);
        }
    }
}