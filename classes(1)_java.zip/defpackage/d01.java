package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: d01  reason: default package */
public final class d01 implements a01 {
    public final /* synthetic */ m00 e;
    public final /* synthetic */ i00 f;

    public d01(m00 m00Var, i00 i00Var) {
        this.e = m00Var;
        this.f = i00Var;
    }

    @Override // defpackage.a01
    public final Object e(Object obj) {
        return this.f.i(obj);
    }

    @Override // defpackage.a01
    public final Object j(iz0 iz0Var, Object obj) {
        return this.e.f(iz0Var, obj);
    }
}