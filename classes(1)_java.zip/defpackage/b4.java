package defpackage;

import android.graphics.Rect;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: b4  reason: default package */
public final class b4 extends li0 implements qc, g21, f90, t90, kd1 {
    public final j3 s = new j3(2, this);
    public final /* synthetic */ n4 t;

    public b4(n4 n4Var) {
        this.t = n4Var;
    }

    @Override // defpackage.t90
    public final /* synthetic */ int G(bg0 bg0Var, hh0 hh0Var, int i) {
        return fu0.i(this, bg0Var, hh0Var, i);
    }

    @Override // defpackage.f90
    public final boolean I(KeyEvent keyEvent) {
        ux uxVar;
        int i;
        boolean z;
        int[] iArr = ay.a;
        long b = ac.b(keyEvent.getKeyCode());
        boolean z2 = true;
        int i2 = 2;
        if (d90.a(b, d90.b)) {
            uxVar = new ux(2);
        } else if (d90.a(b, d90.c)) {
            uxVar = new ux(1);
        } else if (d90.a(b, d90.i)) {
            if (keyEvent.isShiftPressed()) {
                i = 2;
            } else {
                i = 1;
            }
            uxVar = new ux(i);
        } else if (d90.a(b, d90.g)) {
            uxVar = new ux(4);
        } else if (d90.a(b, d90.f)) {
            uxVar = new ux(3);
        } else if (!d90.a(b, d90.d) && !d90.a(b, d90.m)) {
            if (!d90.a(b, d90.e) && !d90.a(b, d90.n)) {
                if (!d90.a(b, d90.h) && !d90.a(b, d90.k) && !d90.a(b, d90.o)) {
                    if (!d90.a(b, d90.a) && !d90.a(b, d90.l)) {
                        uxVar = null;
                    } else {
                        uxVar = new ux(8);
                    }
                } else {
                    uxVar = new ux(7);
                }
            } else {
                uxVar = new ux(6);
            }
        } else {
            uxVar = new ux(5);
        }
        if (uxVar != null) {
            int i3 = uxVar.a;
            if (a5.v(keyEvent) == 2) {
                n4 n4Var = this.t;
                ry f = ((hy) n4Var.getFocusOwner()).f();
                if (f == null || !f.s || !n4Var.z(i3)) {
                    Boolean e = ((hy) n4Var.getFocusOwner()).e(i3, n4Var.getEmbeddedViewFocusRect(), new j3(1, uxVar));
                    if (e != null) {
                        z = e.booleanValue();
                    } else {
                        z = true;
                    }
                    if (!z) {
                        if (i3 != 1 && i3 != 2) {
                            z2 = false;
                        }
                        if (z2) {
                            Integer c = ay.c(i3);
                            if (c != null) {
                                i2 = c.intValue();
                            }
                            FocusFinder focusFinder = FocusFinder.getInstance();
                            View rootView = n4Var.getRootView();
                            rootView.getClass();
                            View findNextFocus = focusFinder.findNextFocus((ViewGroup) rootView, n4Var.getView(), i2);
                            if (findNextFocus == null || findNextFocus.equals(n4Var)) {
                                return ((hy) n4Var.getFocusOwner()).g(i3);
                            }
                        }
                    }
                }
                return true;
            }
        }
        return false;
    }

    @Override // defpackage.g21
    public final void Q(r21 r21Var) {
    }

    @Override // defpackage.g21
    public final /* synthetic */ boolean S() {
        return false;
    }

    @Override // defpackage.g21
    public final /* synthetic */ boolean T() {
        return false;
    }

    @Override // defpackage.t90
    public final nh0 U(oh0 oh0Var, hh0 hh0Var, long j) {
        ks0 e = hh0Var.e(j);
        return oh0Var.E(e.e, e.f, vt.e, this.s, new a4(e, 0));
    }

    @Override // defpackage.qc
    public final Object W(gm0 gm0Var, g4 g4Var, u91 u91Var) {
        gw0 gw0Var;
        long B = gm0Var.B(0L);
        gw0 gw0Var2 = (gw0) g4Var.a();
        if (gw0Var2 != null) {
            gw0Var = gw0Var2.e(B);
        } else {
            gw0Var = null;
        }
        if (gw0Var != null) {
            this.t.requestRectangleOnScreen(new Rect((int) gw0Var.a, (int) gw0Var.b, (int) gw0Var.c, (int) gw0Var.d), false);
        }
        return we1.a;
    }

    @Override // defpackage.t90
    public final /* synthetic */ int d(bg0 bg0Var, hh0 hh0Var, int i) {
        return fu0.d(this, bg0Var, hh0Var, i);
    }

    @Override // defpackage.g21
    public final /* synthetic */ boolean e() {
        return true;
    }

    @Override // defpackage.t90
    public final /* synthetic */ int h(bg0 bg0Var, hh0 hh0Var, int i) {
        return fu0.b(this, bg0Var, hh0Var, i);
    }

    @Override // defpackage.kd1
    public final Object j() {
        return "androidx.compose.ui.layout.WindowInsetsRulers";
    }

    @Override // defpackage.t90
    public final /* synthetic */ int t(bg0 bg0Var, hh0 hh0Var, int i) {
        return fu0.g(this, bg0Var, hh0Var, i);
    }
}