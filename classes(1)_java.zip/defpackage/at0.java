package defpackage;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: at0  reason: default package */
public final class at0 {
    public static final at0 e;
    public static final at0 f;
    public static final at0 g;
    public static final /* synthetic */ at0[] h;

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0, types: [java.lang.Enum, at0] */
    /* JADX WARN: Type inference failed for: r1v1, types: [java.lang.Enum, at0] */
    /* JADX WARN: Type inference failed for: r3v1, types: [java.lang.Enum, at0] */
    static {
        ?? r0 = new Enum("Initial", 0);
        e = r0;
        ?? r1 = new Enum("Main", 1);
        f = r1;
        ?? r3 = new Enum("Final", 2);
        g = r3;
        h = new at0[]{r0, r1, r3};
    }

    public static at0 valueOf(String str) {
        return (at0) Enum.valueOf(at0.class, str);
    }

    public static at0[] values() {
        return (at0[]) h.clone();
    }
}