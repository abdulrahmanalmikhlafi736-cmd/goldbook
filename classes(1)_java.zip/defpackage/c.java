package defpackage;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.net.Uri;
import android.view.View;
import android.widget.Toast;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CancellationException;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: c  reason: default package */
public final /* synthetic */ class c implements i00 {
    public final /* synthetic */ int e;
    public final /* synthetic */ Object f;
    public final /* synthetic */ Object g;

    public /* synthetic */ c(int i, Object obj, Object obj2) {
        this.e = i;
        this.f = obj;
        this.g = obj2;
    }

    @Override // defpackage.i00
    public final Object i(Object obj) {
        Object px0Var;
        float f;
        long a;
        boolean z = false;
        switch (this.e) {
            case 0:
                Throwable th = (Throwable) obj;
                ((uj0) this.f).b((nu0) this.g);
                return we1.a;
            case 1:
                la laVar = (la) this.f;
                ma maVar = (ma) this.g;
                rw0 rw0Var = (rw0) obj;
                we1 we1Var = we1.a;
                bc1 bc1Var = laVar.s;
                if (bc1Var != null) {
                    bc1Var.b();
                }
                laVar.s = null;
                uh uhVar = maVar.b;
                if (uhVar != null) {
                    uhVar.R(we1Var);
                }
                maVar.b = null;
                return we1Var;
            case 2:
                ta taVar = (ta) this.f;
                ui uiVar = (ui) this.g;
                rq rqVar = (rq) obj;
                p3 p3Var = taVar.a;
                if (p3Var != null) {
                    p3.b(p3Var, uiVar.b);
                } else {
                    jn0 jn0Var = taVar.b;
                    if (jn0Var != null) {
                        sa saVar = uiVar.a;
                        saVar.getClass();
                        en0 en0Var = new en0(saVar, new fn0(saVar, null));
                        saVar.a.add(en0Var);
                        p3.b(jn0Var.a(), en0Var);
                    } else {
                        od.p("Unreachable");
                        return null;
                    }
                }
                return new za(0, taVar, uiVar);
            case 3:
                da0 da0Var = (da0) obj;
                da0Var.c();
                fu0.w(da0Var, (r6) this.f, (zi1) this.g, 0.0f, null, 60);
                return we1.a;
            case gu0.LONG_FIELD_NUMBER /* 4 */:
                da0 da0Var2 = (da0) obj;
                da0Var2.c();
                fu0.w(da0Var2, ((dp0) this.f).b, (zi1) this.g, 0.0f, null, 60);
                return we1.a;
            case gu0.STRING_FIELD_NUMBER /* 5 */:
                Throwable th2 = (Throwable) obj;
                ((sc) this.f).a.j((dl) this.g);
                return we1.a;
            case gu0.STRING_SET_FIELD_NUMBER /* 6 */:
                jw0 jw0Var = (jw0) this.g;
                z = (jw0Var.e || ((o10) obj).A((v40) this.f)) ? true : true;
                jw0Var.e = z;
                return Boolean.valueOf(!z);
            case gu0.DOUBLE_FIELD_NUMBER /* 7 */:
                jw0 jw0Var2 = (jw0) this.g;
                z = (jw0Var2.e || ((o10) obj).c((dt0) this.f)) ? true : true;
                jw0Var2.e = z;
                return Boolean.valueOf(!z);
            case 8:
                Throwable th3 = (Throwable) obj;
                ((uj0) this.f).b((y60) this.g);
                return we1.a;
            case 9:
                ((im) obj).getClass();
                return new lg0((Resources) this.f, (t41) this.g);
            case 10:
                lg0 lg0Var = (lg0) this.f;
                int intValue = ((Integer) obj).intValue();
                if (!((Boolean) ((mk0) this.g).getValue()).booleanValue()) {
                    lg0Var.b.setValue(new zg(wl1.d(intValue)));
                }
                return we1.a;
            case 11:
                Context context = (Context) this.f;
                Resources resources = (Resources) this.g;
                String str = (String) obj;
                we1 we1Var2 = we1.a;
                str.getClass();
                try {
                    context.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(str)));
                    px0Var = we1Var2;
                } catch (Throwable th4) {
                    px0Var = new px0(th4);
                }
                if (qx0.a(px0Var) != null) {
                    Toast.makeText(context, resources.getString(2131361937), 0).show();
                }
                return we1Var2;
            case 12:
                Throwable th5 = (Throwable) obj;
                ((w20) this.f).g.removeCallbacks((e5) this.g);
                return we1.a;
            case 13:
                j50 j50Var = (j50) this.f;
                h50 h50Var = (h50) this.g;
                rq rqVar2 = (rq) obj;
                j50Var.a.b(h50Var);
                j50Var.b.setValue(Boolean.TRUE);
                return new za(1, j50Var, h50Var);
            case 14:
                vc0 vc0Var = (vc0) this.f;
                Object obj2 = this.g;
                rq rqVar3 = (rq) obj;
                vc0Var.g.i(obj2);
                return new za(2, vc0Var, obj2);
            case 15:
                return new vc0((mz0) this.f, (Map) obj, (jz0) this.g);
            case 16:
                nj0 nj0Var = (nj0) this.g;
                if (((Set) this.f).contains(obj)) {
                    hk0 hk0Var = nj0Var.b;
                    ik0 ik0Var = nj0Var.d;
                    Object g = hk0Var.g(obj);
                    if (g != null) {
                        if (g instanceof ik0) {
                            ik0 ik0Var2 = (ik0) g;
                            Object[] objArr = ik0Var2.b;
                            long[] jArr = ik0Var2.a;
                            int length = jArr.length - 2;
                            if (length >= 0) {
                                int i = 0;
                                while (true) {
                                    long j = jArr[i];
                                    if ((((~j) << 7) & j & (-9187201950435737472L)) != -9187201950435737472L) {
                                        int i2 = 8 - ((~(i - length)) >>> 31);
                                        for (int i3 = 0; i3 < i2; i3++) {
                                            if ((255 & j) < 128) {
                                                ik0Var.a((z21) objArr[(i << 3) + i3]);
                                            }
                                            j >>= 8;
                                        }
                                        if (i2 != 8) {
                                        }
                                    }
                                    if (i != length) {
                                        i++;
                                    }
                                }
                            }
                        } else {
                            ik0Var.a((z21) g);
                        }
                    }
                }
                return we1.a;
            case 17:
                ((nj0) this.f).c.add(new kj0(obj, (z21) this.g));
                return we1.a;
            case 18:
                rp0 rp0Var = (rp0) this.f;
                ks0 ks0Var = (ks0) this.g;
                js0 js0Var = (js0) obj;
                boolean z2 = rp0Var.w;
                float f2 = rp0Var.s;
                if (z2) {
                    js0Var.getClass();
                    js0.j(js0Var, ks0Var, fu0.k(f2, js0Var), fu0.k(rp0Var.t, js0Var));
                } else {
                    js0Var.getClass();
                    js0.h(js0Var, ks0Var, fu0.k(f2, js0Var), fu0.k(rp0Var.t, js0Var));
                }
                return we1.a;
            case 19:
                ik0 ik0Var3 = (ik0) this.g;
                ((yj) this.f).z(obj);
                if (ik0Var3 != null) {
                    ik0Var3.a(obj);
                }
                return we1.a;
            case 20:
                dw0 dw0Var = (dw0) this.f;
                Throwable th6 = (Throwable) this.g;
                Throwable th7 = (Throwable) obj;
                synchronized (dw0Var.c) {
                    if (th6 != null) {
                        if (th7 != null) {
                            try {
                                if (th7 instanceof CancellationException) {
                                    th7 = null;
                                }
                                if (th7 != null) {
                                    ac.i(th6, th7);
                                }
                            } catch (Throwable th8) {
                                throw th8;
                            }
                        }
                    } else {
                        th6 = null;
                    }
                    dw0Var.e = th6;
                    d81 d81Var = dw0Var.u;
                    aw0 aw0Var = aw0.e;
                    d81Var.getClass();
                    d81Var.i(null, aw0Var);
                }
                return we1.a;
            case 21:
                ((sk0) this.f).a.setValue(new uu((dj1) this.g, (dj1) obj));
                return we1.a;
            case 22:
                w11 w11Var = (w11) this.f;
                y11 y11Var = (y11) this.g;
                mr mrVar = (mr) obj;
                if (mrVar.b) {
                    f = -1.0f;
                } else {
                    f = 1.0f;
                }
                long j2 = mrVar.a;
                if (y11Var.d == bp0.f) {
                    a = xm0.a(1, j2);
                } else {
                    a = xm0.a(2, j2);
                }
                w11Var.a(1, xm0.g(a, f));
                return we1.a;
            case 23:
                fc0 fc0Var = (fc0) obj;
                fc0Var.getClass();
                List list = ub1.d;
                int size = list.size();
                cd cdVar = new cd(3, list);
                pi piVar = new pi(802480018, true, new r31(list, (String) this.f, (i00) this.g));
                i6 i6Var = fc0Var.a;
                al alVar = new al(9, cdVar, piVar);
                i6Var.getClass();
                if (size < 0) {
                    s50.a("size should be >=0");
                }
                if (size != 0) {
                    f70 f70Var = new f70(i6Var.b, size, alVar);
                    i6Var.b += size;
                    ((qk0) i6Var.c).b(f70Var);
                }
                return we1.a;
            case 24:
                rq rqVar4 = (rq) obj;
                wl1.B((bm) this.f, null, new f81((ed1) this.g, null), 1);
                return new dd1(0);
            case 25:
                ed1 ed1Var = (ed1) this.f;
                ed1 ed1Var2 = (ed1) this.g;
                rq rqVar5 = (rq) obj;
                ed1Var.j.add(ed1Var2);
                return new za(4, ed1Var, ed1Var2);
            case 26:
                rq rqVar6 = (rq) obj;
                return new za(5, (ed1) this.f, (zc1) this.g);
            case 27:
                ed1 ed1Var3 = (ed1) this.f;
                bd1 bd1Var = (bd1) this.g;
                rq rqVar7 = (rq) obj;
                ed1Var3.i.add(bd1Var);
                return new za(6, ed1Var3, bd1Var);
            case 28:
                mf1 mf1Var = (mf1) this.f;
                ((Long) obj).getClass();
                float f3 = mf1Var.e;
                mf1Var.e = 0.0f;
                ((i00) this.g).i(Float.valueOf(f3));
                return we1.a;
            default:
                lk1 lk1Var = (lk1) this.f;
                View view = (View) this.g;
                rq rqVar8 = (rq) obj;
                f60 f60Var = lk1Var.u;
                if (lk1Var.t == 0) {
                    int i4 = vg1.a;
                    qg1.b(view, f60Var);
                    if (view.isAttachedToWindow()) {
                        view.requestApplyInsets();
                    }
                    view.addOnAttachStateChangeListener(f60Var);
                    vg1.b(view, f60Var);
                }
                lk1Var.t++;
                return new za(7, lk1Var, view);
        }
    }
}