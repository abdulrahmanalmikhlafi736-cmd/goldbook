package defpackage;

import android.os.Bundle;
import android.os.Parcelable;
import com.almekhlafi.goldbook.MainActivity;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: di  reason: default package */
public final /* synthetic */ class di implements vz0 {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;

    public /* synthetic */ di(int i, Object obj) {
        this.a = i;
        this.b = obj;
    }

    @Override // defpackage.vz0
    public final Bundle a() {
        ArrayList<? extends Parcelable> arrayList;
        Map map;
        zp0[] zp0VarArr;
        int i = this.a;
        Object obj = this.b;
        switch (i) {
            case 0:
                Bundle bundle = new Bundle();
                ii iiVar = ((MainActivity) obj).l;
                iiVar.getClass();
                LinkedHashMap linkedHashMap = iiVar.b;
                bundle.putIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS", new ArrayList<>(linkedHashMap.values()));
                bundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS", new ArrayList<>(linkedHashMap.keySet()));
                bundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS", new ArrayList<>(iiVar.d));
                bundle.putBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT", new Bundle(iiVar.g));
                return bundle;
            case 1:
                Map e = ((nz0) obj).e();
                Bundle bundle2 = new Bundle();
                for (Map.Entry entry : e.entrySet()) {
                    String str = (String) entry.getKey();
                    List list = (List) entry.getValue();
                    if (list instanceof ArrayList) {
                        arrayList = (ArrayList) list;
                    } else {
                        arrayList = new ArrayList<>(list);
                    }
                    bundle2.putParcelableArrayList(str, arrayList);
                }
                return bundle2;
            default:
                pa paVar = (pa) obj;
                LinkedHashMap linkedHashMap2 = (LinkedHashMap) paVar.d;
                linkedHashMap2.getClass();
                int size = linkedHashMap2.size();
                Map map2 = vt.e;
                if (size != 0) {
                    if (size != 1) {
                        map = new LinkedHashMap(linkedHashMap2);
                    } else {
                        Map.Entry entry2 = (Map.Entry) linkedHashMap2.entrySet().iterator().next();
                        map = Collections.singletonMap(entry2.getKey(), entry2.getValue());
                        map.getClass();
                    }
                } else {
                    map = map2;
                }
                for (Map.Entry entry3 : map.entrySet()) {
                    paVar.j(((d81) entry3.getValue()).getValue(), (String) entry3.getKey());
                }
                LinkedHashMap linkedHashMap3 = (LinkedHashMap) paVar.b;
                linkedHashMap3.getClass();
                int size2 = linkedHashMap3.size();
                if (size2 != 0) {
                    if (size2 != 1) {
                        map2 = new LinkedHashMap(linkedHashMap3);
                    } else {
                        Map.Entry entry4 = (Map.Entry) linkedHashMap3.entrySet().iterator().next();
                        map2 = Collections.singletonMap(entry4.getKey(), entry4.getValue());
                        map2.getClass();
                    }
                }
                for (Map.Entry entry5 : map2.entrySet()) {
                    paVar.j(((vz0) entry5.getValue()).a(), (String) entry5.getKey());
                }
                LinkedHashMap linkedHashMap4 = (LinkedHashMap) paVar.a;
                if (linkedHashMap4.isEmpty()) {
                    zp0VarArr = new zp0[0];
                } else {
                    ArrayList arrayList2 = new ArrayList(linkedHashMap4.size());
                    for (Map.Entry entry6 : linkedHashMap4.entrySet()) {
                        arrayList2.add(new zp0((String) entry6.getKey(), entry6.getValue()));
                    }
                    zp0VarArr = (zp0[]) arrayList2.toArray(new zp0[0]);
                }
                return a5.j((zp0[]) Arrays.copyOf(zp0VarArr, zp0VarArr.length));
        }
    }
}