package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dp0  reason: default package */
public final class dp0 extends jb0 {
    public final r6 b;

    public dp0(r6 r6Var) {
        this.b = r6Var;
    }

    @Override // defpackage.jb0
    public final gw0 k() {
        return this.b.a();
    }
}