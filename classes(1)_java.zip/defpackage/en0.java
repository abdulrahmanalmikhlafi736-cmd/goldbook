package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: en0  reason: default package */
public final class en0 extends fl0 {
    public final sa d;
    public boolean e;

    public en0(sa saVar, fn0 fn0Var) {
        boolean z = saVar.b;
        this.a = fn0Var;
        this.b = z;
        this.d = saVar;
        this.e = true;
    }

    @Override // defpackage.fl0
    public final void a() {
        switch (this.d.d) {
            case 0:
            default:
                return;
        }
    }

    @Override // defpackage.fl0
    public final void b() {
        sa saVar = this.d;
        switch (saVar.d) {
            case 0:
                ((ui) saVar.e).c.a();
                return;
            default:
                ((l5) saVar.e).i(saVar);
                return;
        }
    }

    @Override // defpackage.fl0
    public final void c(dl0 dl0Var) {
        new qa(dl0Var);
        switch (this.d.d) {
            case 0:
            default:
                return;
        }
    }

    @Override // defpackage.fl0
    public final void d(dl0 dl0Var) {
        dl0Var.getClass();
        new qa(dl0Var);
        switch (this.d.d) {
            case 0:
            default:
                return;
        }
    }

    public final void g(boolean z) {
        boolean z2;
        this.e = z;
        if (z && this.d.b) {
            z2 = true;
        } else {
            z2 = false;
        }
        f(z2);
    }
}