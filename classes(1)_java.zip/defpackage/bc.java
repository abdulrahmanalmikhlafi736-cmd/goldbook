package defpackage;

import android.graphics.Rect;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bc  reason: default package */
public final class bc {
    public final int a;
    public final int b;
    public final int c;
    public final int d;

    static {
        new bc(0, 0, 0, 0);
    }

    public bc(int i, int i2, int i3, int i4) {
        this.a = i;
        this.b = i2;
        this.c = i3;
        this.d = i4;
        if (i <= i3) {
            if (i2 <= i4) {
                return;
            }
            throw new IllegalArgumentException(fu0.D(i2, i4, "top must be less than or equal to bottom, top: ", ", bottom: ").toString());
        }
        throw new IllegalArgumentException(fu0.D(i, i3, "Left must be less than or equal to right, left: ", ", right: ").toString());
    }

    public final boolean equals(Object obj) {
        Class<?> cls;
        if (this == obj) {
            return true;
        }
        if (obj != null) {
            cls = obj.getClass();
        } else {
            cls = null;
        }
        if (!bc.class.equals(cls)) {
            return false;
        }
        obj.getClass();
        bc bcVar = (bc) obj;
        if (this.a == bcVar.a && this.b == bcVar.b && this.c == bcVar.c && this.d == bcVar.d) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        return (((((this.a * 31) + this.b) * 31) + this.c) * 31) + this.d;
    }

    public final String toString() {
        return bc.class.getSimpleName() + " { [" + this.a + ',' + this.b + ',' + this.c + ',' + this.d + "] }";
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public bc(Rect rect) {
        this(rect.left, rect.top, rect.right, rect.bottom);
        rect.getClass();
    }
}