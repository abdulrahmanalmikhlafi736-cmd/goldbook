package defpackage;

import java.io.Serializable;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: da1  reason: default package */
public final class da1 implements ta0, Serializable {
    public xz e;
    public volatile Object f;
    public final Object g;

    public da1(xz xzVar) {
        xzVar.getClass();
        this.e = xzVar;
        this.f = nq0.k;
        this.g = this;
    }

    @Override // defpackage.ta0
    public final Object getValue() {
        Object obj;
        Object obj2 = this.f;
        nq0 nq0Var = nq0.k;
        if (obj2 != nq0Var) {
            return obj2;
        }
        synchronized (this.g) {
            obj = this.f;
            if (obj == nq0Var) {
                xz xzVar = this.e;
                xzVar.getClass();
                obj = xzVar.a();
                this.f = obj;
                this.e = null;
            }
        }
        return obj;
    }

    public final String toString() {
        if (this.f != nq0.k) {
            return String.valueOf(getValue());
        }
        return "Lazy value not initialized yet.";
    }
}