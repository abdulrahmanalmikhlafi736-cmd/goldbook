package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dx  reason: default package */
public final class dx extends u91 implements n00 {
    public int i;
    public /* synthetic */ uw j;
    public /* synthetic */ Object k;
    public final /* synthetic */ aj l;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public dx(aj ajVar, ml mlVar) {
        super(3, mlVar);
        this.l = ajVar;
    }

    @Override // defpackage.n00
    public final Object c(Object obj, Object obj2, Object obj3) {
        dx dxVar = new dx(this.l, (ml) obj3);
        dxVar.j = (uw) obj;
        dxVar.k = obj2;
        return dxVar.p(we1.a);
    }

    /* JADX WARN: Code restructure failed: missing block: B:11:0x002e, code lost:
        if (r6 == r4) goto L14;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x0039, code lost:
        if (r0.k(r6, r5) == r4) goto L14;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x003b, code lost:
        return r4;
     */
    @Override // defpackage.db
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object p(Object obj) {
        uw uwVar;
        int i = this.i;
        cm cmVar = cm.e;
        if (i != 0) {
            if (i != 1) {
                if (i == 2) {
                    nb0.t(obj);
                    return we1.a;
                }
                od.p("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            uwVar = this.j;
            nb0.t(obj);
        } else {
            nb0.t(obj);
            uwVar = this.j;
            Object obj2 = this.k;
            this.j = uwVar;
            this.i = 1;
            obj = this.l.f(obj2, this);
        }
        this.j = null;
        this.i = 2;
    }
}