package defpackage;

import android.view.WindowInsets;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ek1  reason: default package */
public abstract /* synthetic */ class ek1 {
    public static /* bridge */ /* synthetic */ int a() {
        return WindowInsets.Type.statusBars();
    }

    public static /* bridge */ /* synthetic */ int f() {
        return WindowInsets.Type.navigationBars();
    }

    public static /* bridge */ /* synthetic */ int h() {
        return WindowInsets.Type.captionBar();
    }

    public static /* bridge */ /* synthetic */ int j() {
        return WindowInsets.Type.systemGestures();
    }

    public static /* bridge */ /* synthetic */ int l() {
        return WindowInsets.Type.mandatorySystemGestures();
    }

    public static /* bridge */ /* synthetic */ int n() {
        return WindowInsets.Type.tappableElement();
    }

    public static /* bridge */ /* synthetic */ int o() {
        return WindowInsets.Type.displayCutout();
    }
}