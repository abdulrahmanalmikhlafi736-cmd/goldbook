package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cg  reason: default package */
public final class cg implements n00 {
    public final /* synthetic */ t40 e;
    public final /* synthetic */ boolean f;
    public final /* synthetic */ iy0 g;
    public final /* synthetic */ xz h;

    public cg(t40 t40Var, boolean z, iy0 iy0Var, xz xzVar) {
        this.e = t40Var;
        this.f = z;
        this.g = iy0Var;
        this.h = xzVar;
    }

    @Override // defpackage.n00
    public final Object c(Object obj, Object obj2, Object obj3) {
        mi0 mi0Var = (mi0) obj;
        d10 d10Var = (d10) obj2;
        ((Number) obj3).intValue();
        d10Var.W(-1525724089);
        Object L = d10Var.L();
        if (L == oj.a) {
            L = new uj0();
            d10Var.g0(L);
        }
        uj0 uj0Var = (uj0) L;
        mi0 b = p40.a(ji0.a, uj0Var, this.e).b(new bg(uj0Var, null, false, this.f, this.g, this.h));
        d10Var.p(false);
        return b;
    }
}