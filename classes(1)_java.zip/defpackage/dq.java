package defpackage;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dq  reason: default package */
public final class dq {
    public static final dq e;
    public static final dq f;
    public static final dq g;
    public static final /* synthetic */ dq[] h;

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0, types: [java.lang.Enum, dq] */
    /* JADX WARN: Type inference failed for: r1v1, types: [java.lang.Enum, dq] */
    /* JADX WARN: Type inference failed for: r3v1, types: [java.lang.Enum, dq] */
    static {
        ?? r0 = new Enum("Vertical", 0);
        e = r0;
        ?? r1 = new Enum("Horizontal", 1);
        f = r1;
        ?? r3 = new Enum("Both", 2);
        g = r3;
        h = new dq[]{r0, r1, r3};
    }

    public static dq valueOf(String str) {
        return (dq) Enum.valueOf(dq.class, str);
    }

    public static dq[] values() {
        return (dq[]) h.clone();
    }
}