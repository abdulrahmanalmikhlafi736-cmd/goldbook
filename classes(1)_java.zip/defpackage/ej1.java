package defpackage;

import android.animation.ValueAnimator;
import android.os.Build;
import android.view.View;
import android.view.animation.PathInterpolator;
import java.util.Collections;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ej1  reason: default package */
public final class ej1 implements ValueAnimator.AnimatorUpdateListener {
    public final /* synthetic */ mj1 a;
    public final /* synthetic */ hk1 b;
    public final /* synthetic */ hk1 c;
    public final /* synthetic */ int d;
    public final /* synthetic */ View e;

    public ej1(mj1 mj1Var, hk1 hk1Var, hk1 hk1Var2, int i, View view) {
        this.a = mj1Var;
        this.b = hk1Var;
        this.c = hk1Var2;
        this.d = i;
        this.e = view;
    }

    @Override // android.animation.ValueAnimator.AnimatorUpdateListener
    public final void onAnimationUpdate(ValueAnimator valueAnimator) {
        uj1 nj1Var;
        float animatedFraction = valueAnimator.getAnimatedFraction();
        mj1 mj1Var = this.a;
        lj1 lj1Var = mj1Var.a;
        lj1Var.e(animatedFraction);
        float c = lj1Var.c();
        PathInterpolator pathInterpolator = ij1.e;
        int i = Build.VERSION.SDK_INT;
        hk1 hk1Var = this.b;
        if (i >= 36) {
            nj1Var = new tj1(hk1Var);
        } else if (i >= 35) {
            nj1Var = new sj1(hk1Var);
        } else if (i >= 34) {
            nj1Var = new rj1(hk1Var);
        } else if (i >= 31) {
            nj1Var = new qj1(hk1Var);
        } else if (i >= 30) {
            nj1Var = new pj1(hk1Var);
        } else if (i >= 29) {
            nj1Var = new oj1(hk1Var);
        } else {
            nj1Var = new nj1(hk1Var);
        }
        for (int i2 = 1; i2 <= 512; i2 <<= 1) {
            int i3 = this.d & i2;
            dk1 dk1Var = hk1Var.a;
            if (i3 == 0) {
                nj1Var.d(i2, dk1Var.i(i2));
            } else {
                c60 i4 = dk1Var.i(i2);
                c60 i5 = this.c.a.i(i2);
                float f = 1.0f - c;
                nj1Var.d(i2, hk1.a(i4, (int) (((i4.a - i5.a) * f) + 0.5d), (int) (((i4.b - i5.b) * f) + 0.5d), (int) (((i4.c - i5.c) * f) + 0.5d), (int) (((i4.d - i5.d) * f) + 0.5d)));
            }
        }
        ij1.h(this.e, nj1Var.b(), Collections.singletonList(mj1Var));
    }
}