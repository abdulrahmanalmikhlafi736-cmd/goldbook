package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: b11  reason: default package */
public final /* synthetic */ class b11 implements xz {
    public final /* synthetic */ int e;
    public final /* synthetic */ c11 f;

    public /* synthetic */ b11(c11 c11Var, int i) {
        this.e = i;
        this.f = c11Var;
    }

    @Override // defpackage.xz
    public final Object a() {
        int i = this.e;
        boolean z = true;
        c11 c11Var = this.f;
        switch (i) {
            case 0:
                if (c11Var.a.g() >= c11Var.e.g()) {
                    z = false;
                }
                return Boolean.valueOf(z);
            case 1:
                if (c11Var.a.g() <= 0) {
                    z = false;
                }
                return Boolean.valueOf(z);
            default:
                if (c11Var.e.g() != 0 && c11Var.a.g() >= c11Var.e.g()) {
                    z = false;
                }
                return Boolean.valueOf(z);
        }
    }
}