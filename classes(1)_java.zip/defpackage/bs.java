package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bs  reason: default package */
public final class bs {
    public h6 a;
    public t3 b;
    public long c = 0;
    public int d = 0;
    public final te e = new te();
}