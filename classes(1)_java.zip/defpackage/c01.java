package defpackage;

import java.util.ArrayList;
import java.util.List;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: c01  reason: default package */
public final /* synthetic */ class c01 implements m00 {
    public final /* synthetic */ int e;

    public /* synthetic */ c01(int i) {
        this.e = i;
    }

    @Override // defpackage.m00
    public final Object f(Object obj, Object obj2) {
        boolean a;
        boolean b;
        z8 z8Var;
        Object a2;
        int i;
        Integer num = null;
        switch (this.e) {
            case 0:
                iz0 iz0Var = (iz0) obj;
                w41 w41Var = (w41) obj2;
                return zi1.m(e01.a(new zg(w41Var.a), e01.p, iz0Var), e01.a(new xm0(w41Var.b), e01.x, iz0Var), Float.valueOf(w41Var.c));
            case 1:
                iz0 iz0Var2 = (iz0) obj;
                return Integer.valueOf(((na1) obj2).a);
            case 2:
                iz0 iz0Var3 = (iz0) obj;
                return Integer.valueOf(((sa1) obj2).a);
            case 3:
                iz0 iz0Var4 = (iz0) obj;
                return Integer.valueOf(((o30) obj2).a);
            case gu0.LONG_FIELD_NUMBER /* 4 */:
                iz0 iz0Var5 = (iz0) obj;
                return Integer.valueOf(((nz) obj2).a);
            case gu0.STRING_FIELD_NUMBER /* 5 */:
                iz0 iz0Var6 = (iz0) obj;
                return Integer.valueOf(((oz) obj2).a);
            case gu0.STRING_SET_FIELD_NUMBER /* 6 */:
                iz0 iz0Var7 = (iz0) obj;
                qb1 qb1Var = (qb1) obj2;
                long j = qb1.c;
                if (qb1Var == null) {
                    a = false;
                } else {
                    a = qb1.a(qb1Var.a, j);
                }
                if (a) {
                    return Boolean.FALSE;
                }
                return zi1.m(Float.valueOf(qb1.c(qb1Var.a)), e01.a(new rb1(qb1.b(qb1Var.a)), e01.w, iz0Var7));
            case gu0.DOUBLE_FIELD_NUMBER /* 7 */:
                le0 le0Var = (le0) obj2;
                return zi1.m(le0Var.a, e01.a(le0Var.b, e01.i, (iz0) obj));
            case 8:
                iz0 iz0Var8 = (iz0) obj;
                long j2 = ((rb1) obj2).a;
                if (rb1.a(j2, 8589934592L)) {
                    return 0;
                }
                if (rb1.a(j2, 4294967296L)) {
                    return 1;
                }
                return Boolean.FALSE;
            case 9:
                iz0 iz0Var9 = (iz0) obj;
                xm0 xm0Var = (xm0) obj2;
                if (xm0Var == null) {
                    b = false;
                } else {
                    b = xm0.b(xm0Var.a, 9205357640488583168L);
                }
                if (b) {
                    return Boolean.FALSE;
                }
                return zi1.m(Float.valueOf(Float.intBitsToFloat((int) (xm0Var.a >> 32))), Float.valueOf(Float.intBitsToFloat((int) (xm0Var.a & 4294967295L))));
            case 10:
                iz0 iz0Var10 = (iz0) obj;
                w8 w8Var = (w8) obj2;
                Object obj3 = w8Var.a;
                if (obj3 instanceof fq0) {
                    z8Var = z8.e;
                } else if (obj3 instanceof i71) {
                    z8Var = z8.f;
                } else if (obj3 instanceof jg1) {
                    z8Var = z8.g;
                } else if (obj3 instanceof of1) {
                    z8Var = z8.h;
                } else if (obj3 instanceof me0) {
                    z8Var = z8.i;
                } else if (obj3 instanceof le0) {
                    z8Var = z8.j;
                } else if (obj3 instanceof n81) {
                    z8Var = z8.k;
                } else {
                    throw new UnsupportedOperationException();
                }
                switch (z8Var.ordinal()) {
                    case 0:
                        obj3.getClass();
                        a2 = e01.a((fq0) obj3, e01.g, iz0Var10);
                        break;
                    case 1:
                        obj3.getClass();
                        a2 = e01.a((i71) obj3, e01.h, iz0Var10);
                        break;
                    case 2:
                        obj3.getClass();
                        a2 = e01.a((jg1) obj3, e01.c, iz0Var10);
                        break;
                    case 3:
                        obj3.getClass();
                        a2 = e01.a((of1) obj3, e01.d, iz0Var10);
                        break;
                    case gu0.LONG_FIELD_NUMBER /* 4 */:
                        obj3.getClass();
                        a2 = e01.a((me0) obj3, e01.e, iz0Var10);
                        break;
                    case gu0.STRING_FIELD_NUMBER /* 5 */:
                        obj3.getClass();
                        a2 = e01.a((le0) obj3, e01.f, iz0Var10);
                        break;
                    case gu0.STRING_SET_FIELD_NUMBER /* 6 */:
                        obj3.getClass();
                        a2 = ((n81) obj3).a;
                        break;
                    default:
                        od.k();
                        return null;
                }
                return zi1.m(z8Var, a2, Integer.valueOf(w8Var.b), Integer.valueOf(w8Var.c), w8Var.d);
            case 11:
                iz0 iz0Var11 = (iz0) obj;
                List list = ((if0) obj2).e;
                ArrayList arrayList = new ArrayList(list.size());
                int size = list.size();
                for (int i2 = 0; i2 < size; i2++) {
                    arrayList.add(e01.a((hf0) list.get(i2), e01.z, iz0Var11));
                }
                return arrayList;
            case 12:
                iz0 iz0Var12 = (iz0) obj;
                return ((hf0) obj2).a.toLanguageTag();
            case 13:
                iz0 iz0Var13 = (iz0) obj;
                he0 he0Var = (he0) obj2;
                return zi1.m(e01.a(new ee0(he0Var.a), e01.B, iz0Var13), e01.a(new ge0(he0Var.b), e01.C, iz0Var13), e01.a(new fe0(he0Var.c), e01.D, iz0Var13));
            case 14:
                iz0 iz0Var14 = (iz0) obj;
                return Float.valueOf(((ee0) obj2).a);
            case 15:
                iz0 iz0Var15 = (iz0) obj;
                return Integer.valueOf(((ge0) obj2).a);
            case 16:
                iz0 iz0Var16 = (iz0) obj;
                return Integer.valueOf(((fe0) obj2).a);
            case 17:
                iz0 iz0Var17 = (iz0) obj;
                return ((jg1) obj2).a;
            case 18:
                iz0 iz0Var18 = (iz0) obj;
                fq0 fq0Var = (fq0) obj2;
                Object a3 = e01.a(new na1(fq0Var.a), e01.q, iz0Var18);
                Object a4 = e01.a(new sa1(fq0Var.b), e01.r, iz0Var18);
                Object a5 = e01.a(new qb1(fq0Var.c), e01.v, iz0Var18);
                wa1 wa1Var = fq0Var.d;
                wa1 wa1Var2 = wa1.c;
                Object a6 = e01.a(wa1Var, e01.l, iz0Var18);
                Object a7 = e01.a(fq0Var.e, vd1.m, iz0Var18);
                he0 he0Var2 = fq0Var.f;
                he0 he0Var3 = he0.d;
                return zi1.m(a3, a4, a5, a6, a7, e01.a(he0Var2, e01.A, iz0Var18), e01.a(new ce0(fq0Var.g), vd1.o, iz0Var18), e01.a(new o30(fq0Var.h), e01.s, iz0Var18), e01.a(fq0Var.i, vd1.p, iz0Var18));
            case 19:
                iz0 iz0Var19 = (iz0) obj;
                return ((of1) obj2).a;
            case 20:
                iz0 iz0Var20 = (iz0) obj;
                i71 i71Var = (i71) obj2;
                zg zgVar = new zg(i71Var.a.b());
                d01 d01Var = e01.p;
                Object a8 = e01.a(zgVar, d01Var, iz0Var20);
                qb1 qb1Var2 = new qb1(i71Var.b);
                d01 d01Var2 = e01.v;
                Object a9 = e01.a(qb1Var2, d01Var2, iz0Var20);
                pz pzVar = i71Var.c;
                pz pzVar2 = pz.f;
                Object a10 = e01.a(pzVar, e01.m, iz0Var20);
                Object a11 = e01.a(i71Var.d, e01.t, iz0Var20);
                Object a12 = e01.a(i71Var.e, e01.u, iz0Var20);
                String str = i71Var.g;
                Object a13 = e01.a(new qb1(i71Var.h), d01Var2, iz0Var20);
                Object a14 = e01.a(i71Var.i, e01.n, iz0Var20);
                Object a15 = e01.a(i71Var.j, e01.k, iz0Var20);
                if0 if0Var = i71Var.k;
                if0 if0Var2 = if0.g;
                Object a16 = e01.a(if0Var, e01.y, iz0Var20);
                Object a17 = e01.a(new zg(i71Var.l), d01Var, iz0Var20);
                Object a18 = e01.a(i71Var.m, e01.j, iz0Var20);
                w41 w41Var2 = i71Var.n;
                w41 w41Var3 = w41.d;
                return zi1.m(a8, a9, a10, a11, a12, -1, str, a13, a14, a15, a16, a17, a18, e01.a(w41Var2, e01.o, iz0Var20));
            case 21:
                iz0 iz0Var21 = (iz0) obj;
                eb1 eb1Var = (eb1) obj2;
                i71 i71Var2 = eb1Var.a;
                al alVar = e01.h;
                return zi1.m(e01.a(i71Var2, alVar, iz0Var21), e01.a(eb1Var.b, alVar, iz0Var21), e01.a(eb1Var.c, alVar, iz0Var21), e01.a(eb1Var.d, alVar, iz0Var21));
            case 22:
                ss0 ss0Var = (ss0) obj2;
                Boolean valueOf = Boolean.valueOf(ss0Var.a);
                al alVar2 = e01.a;
                return zi1.m(valueOf, e01.a(new ot(ss0Var.b), vd1.n, (iz0) obj));
            case 23:
                iz0 iz0Var22 = (iz0) obj;
                return Integer.valueOf(((ot) obj2).a);
            case 24:
                iz0 iz0Var23 = (iz0) obj;
                return Integer.valueOf(((ce0) obj2).a);
            case 25:
                gb1 gb1Var = (gb1) obj2;
                return zi1.m(e01.a(new fb1(gb1Var.a), vd1.q, (iz0) obj), Boolean.valueOf(gb1Var.b));
            case 26:
                iz0 iz0Var24 = (iz0) obj;
                return Integer.valueOf(((fb1) obj2).a);
            case 27:
                iz0 iz0Var25 = (iz0) obj;
                return Integer.valueOf(((c11) obj2).a.g());
            case 28:
                ql qlVar = (ql) obj2;
                if (!(qlVar instanceof uc1)) {
                    return obj;
                }
                if (obj instanceof Integer) {
                    num = (Integer) obj;
                }
                if (num != null) {
                    i = num.intValue();
                } else {
                    i = 1;
                }
                if (i == 0) {
                    return qlVar;
                }
                return Integer.valueOf(i + 1);
            default:
                uc1 uc1Var = (uc1) obj;
                ql qlVar2 = (ql) obj2;
                if (!(qlVar2 instanceof uc1)) {
                    return null;
                }
                return (uc1) qlVar2;
        }
    }
}