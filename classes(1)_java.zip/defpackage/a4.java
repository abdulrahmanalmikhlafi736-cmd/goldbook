package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: a4  reason: default package */
public final class a4 extends h90 implements i00 {
    public final /* synthetic */ int f;
    public final /* synthetic */ ks0 g;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ a4(ks0 ks0Var, int i) {
        super(1);
        this.f = i;
        this.g = ks0Var;
    }

    @Override // defpackage.i00
    public final Object i(Object obj) {
        int i = this.f;
        we1 we1Var = we1.a;
        ks0 ks0Var = this.g;
        switch (i) {
            case 0:
                js0.h((js0) obj, ks0Var, 0, 0);
                return we1Var;
            case 1:
                js0.h((js0) obj, ks0Var, 0, 0);
                return we1Var;
            case 2:
                js0.h((js0) obj, ks0Var, 0, 0);
                return we1Var;
            case 3:
                js0.h((js0) obj, ks0Var, 0, 0);
                return we1Var;
            case gu0.LONG_FIELD_NUMBER /* 4 */:
                js0.j((js0) obj, ks0Var, 0, 0);
                return we1Var;
            default:
                js0.l((js0) obj, ks0Var, 0, 0);
                return we1Var;
        }
    }
}