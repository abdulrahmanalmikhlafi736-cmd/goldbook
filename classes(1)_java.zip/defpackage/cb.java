package defpackage;

import android.os.SystemClock;
import android.view.MotionEvent;
import java.util.List;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cb  reason: default package */
public final class cb extends li0 implements t90, ds, g21, gt0, oi0, mq0, l90, q10, ky, mp0, nd {
    public ki0 s;

    @Override // defpackage.ds
    public final void C(da0 da0Var) {
        ki0 ki0Var = this.s;
        ki0Var.getClass();
        q40 q40Var = (q40) ki0Var;
        throw null;
    }

    @Override // defpackage.t90
    public final int G(bg0 bg0Var, hh0 hh0Var, int i) {
        this.s.getClass();
        throw new ClassCastException();
    }

    @Override // defpackage.ky
    public final void H(iy iyVar) {
        ki0 ki0Var = this.s;
        p50.b("applyFocusProperties called on wrong node");
        ki0Var.getClass();
        throw new ClassCastException();
    }

    @Override // defpackage.gt0
    public final boolean J() {
        ki0 ki0Var = this.s;
        ki0Var.getClass();
        ((jt0) ki0Var).d.getClass();
        return true;
    }

    @Override // defpackage.gt0
    public final void L() {
        R();
    }

    @Override // defpackage.g21
    public final void Q(r21 r21Var) {
        ki0 ki0Var = this.s;
        ki0Var.getClass();
        d21 c = ((e21) ki0Var).c();
        r21Var.getClass();
        d21 d21Var = (d21) r21Var;
        hk0 hk0Var = d21Var.e;
        if (c.g) {
            d21Var.g = true;
        }
        if (c.h) {
            d21Var.h = true;
        }
        hk0 hk0Var2 = c.e;
        Object[] objArr = hk0Var2.b;
        Object[] objArr2 = hk0Var2.c;
        long[] jArr = hk0Var2.a;
        int length = jArr.length - 2;
        if (length >= 0) {
            int i = 0;
            while (true) {
                long j = jArr[i];
                if ((((~j) << 7) & j & (-9187201950435737472L)) != -9187201950435737472L) {
                    int i2 = 8 - ((~(i - length)) >>> 31);
                    for (int i3 = 0; i3 < i2; i3++) {
                        if ((255 & j) < 128) {
                            int i4 = (i << 3) + i3;
                            Object obj = objArr[i4];
                            Object obj2 = objArr2[i4];
                            q21 q21Var = (q21) obj;
                            if (!hk0Var.b(q21Var)) {
                                hk0Var.m(q21Var, obj2);
                            } else if (obj2 instanceof o0) {
                                Object g = hk0Var.g(q21Var);
                                g.getClass();
                                o0 o0Var = (o0) g;
                                String str = o0Var.a;
                                if (str == null) {
                                    str = ((o0) obj2).a;
                                }
                                u00 u00Var = o0Var.b;
                                if (u00Var == null) {
                                    u00Var = ((o0) obj2).b;
                                }
                                hk0Var.m(q21Var, new o0(str, u00Var));
                            }
                        }
                        j >>= 8;
                    }
                    if (i2 != 8) {
                        return;
                    }
                }
                if (i != length) {
                    i++;
                } else {
                    return;
                }
            }
        }
    }

    @Override // defpackage.gt0
    public final void R() {
        ki0 ki0Var = this.s;
        ki0Var.getClass();
        p3 p3Var = ((jt0) ki0Var).d;
        it0 it0Var = (it0) p3Var.f;
        jt0 jt0Var = (jt0) p3Var.h;
        if (it0Var == it0.f) {
            long uptimeMillis = SystemClock.uptimeMillis();
            MotionEvent obtain = MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0);
            obtain.setSource(0);
            ((l7) jt0Var.e()).i(obtain);
            obtain.recycle();
            p3Var.f = it0.e;
            jt0Var.c = false;
            p3Var.g = null;
        }
    }

    @Override // defpackage.g21
    public final /* synthetic */ boolean S() {
        return false;
    }

    @Override // defpackage.g21
    public final /* synthetic */ boolean T() {
        return false;
    }

    @Override // defpackage.t90
    public final nh0 U(oh0 oh0Var, hh0 hh0Var, long j) {
        this.s.getClass();
        throw new ClassCastException();
    }

    @Override // defpackage.mq0
    public final Object Y(Object obj) {
        this.s.getClass();
        throw new ClassCastException();
    }

    @Override // defpackage.ds
    public final void Z() {
        a5.x(this);
    }

    @Override // defpackage.nd
    public final jp a() {
        return k70.O(this).C;
    }

    @Override // defpackage.gt0
    public final void a0() {
        ki0 ki0Var = this.s;
        ki0Var.getClass();
        ((jt0) ki0Var).d.getClass();
    }

    @Override // defpackage.nd
    public final long b() {
        return wl1.M(k70.M(this, 128).g);
    }

    @Override // defpackage.t90
    public final int d(bg0 bg0Var, hh0 hh0Var, int i) {
        this.s.getClass();
        throw new ClassCastException();
    }

    @Override // defpackage.g21
    public final /* synthetic */ boolean e() {
        return true;
    }

    @Override // defpackage.oi0
    public final e3 f() {
        return e3.K;
    }

    @Override // defpackage.nd
    public final o90 getLayoutDirection() {
        return k70.O(this).D;
    }

    @Override // defpackage.t90
    public final int h(bg0 bg0Var, hh0 hh0Var, int i) {
        this.s.getClass();
        throw new ClassCastException();
    }

    @Override // defpackage.li0
    public final void h0() {
        r0(true);
    }

    @Override // defpackage.l90
    public final void i(n90 n90Var) {
    }

    @Override // defpackage.li0
    public final void i0() {
        if (this.s instanceof jt0) {
            R();
        }
    }

    @Override // defpackage.li0
    public final void j0() {
        if (!this.r) {
            p50.b("unInitializeModifier called on unattached node");
        }
        if ((this.g & 8) != 0) {
            ((n4) k70.P(this)).E();
        }
    }

    @Override // defpackage.gt0
    public final long l() {
        return zi1.y;
    }

    @Override // defpackage.ph0
    public final void m(long j) {
    }

    @Override // defpackage.q10
    public final void o(gm0 gm0Var) {
        this.s.getClass();
        throw new ClassCastException();
    }

    @Override // defpackage.mp0
    public final boolean r() {
        return this.r;
    }

    public final void r0(boolean z) {
        if (!this.r) {
            p50.b("initializeModifier called on unattached node");
        }
        ki0 ki0Var = this.s;
        if ((this.g & 4) != 0 && !z) {
            k70.M(this, 2).F0();
        }
        if ((this.g & 2) != 0) {
            ha1 ha1Var = k70.O(this).J.e;
            ha1Var.getClass();
            if (ha1Var.s) {
                gm0 gm0Var = this.l;
                gm0Var.getClass();
                ((v90) gm0Var).W0(this);
                kp0 kp0Var = gm0Var.P;
                if (kp0Var != null) {
                    ((l20) kp0Var).c();
                }
            }
            if (!z) {
                k70.M(this, 2).F0();
                k70.O(this).E();
            }
        }
        if (ki0Var instanceof qc0) {
            ((qc0) ki0Var).a.k = k70.O(this);
        }
        int i = this.g;
        if ((i & 16) != 0 && (ki0Var instanceof jt0)) {
            ((jt0) ki0Var).d.e = this.l;
        }
        if ((i & 8) != 0) {
            ((n4) k70.P(this)).E();
        }
    }

    public final void s0() {
        ki0 ki0Var = this.s;
        p50.b("onFocusEvent called on wrong node");
        ki0Var.getClass();
        throw new ClassCastException();
    }

    @Override // defpackage.t90
    public final int t(bg0 bg0Var, hh0 hh0Var, int i) {
        this.s.getClass();
        throw new ClassCastException();
    }

    public final String toString() {
        return this.s.toString();
    }

    /* JADX WARN: Removed duplicated region for block: B:23:0x0050  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x007d  */
    /* JADX WARN: Removed duplicated region for block: B:65:0x00c5  */
    /* JADX WARN: Removed duplicated region for block: B:88:0x0122 A[ORIG_RETURN, RETURN] */
    @Override // defpackage.gt0
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void x(zs0 zs0Var, at0 at0Var, long j) {
        boolean z;
        boolean z2;
        boolean z3;
        it0 it0Var;
        it0 it0Var2;
        at0 at0Var2;
        boolean z4;
        ki0 ki0Var = this.s;
        ki0Var.getClass();
        p3 p3Var = ((jt0) ki0Var).d;
        jt0 jt0Var = (jt0) p3Var.h;
        List list = zs0Var.a;
        int size = list.size();
        for (int i = 0; i < size; i++) {
            dt0 dt0Var = (dt0) list.get(i);
            if (nb0.g(dt0Var) || nb0.h(dt0Var)) {
                z = false;
                break;
            }
        }
        z = true;
        if (z) {
            int size2 = list.size();
            for (int i2 = 0; i2 < size2; i2++) {
                if (!((dt0) list.get(i2)).b()) {
                }
            }
            z2 = true;
            if (!jt0Var.c) {
                int size3 = list.size();
                int i3 = 0;
                while (true) {
                    if (i3 < size3) {
                        dt0 dt0Var2 = (dt0) list.get(i3);
                        if (nb0.g(dt0Var2) || nb0.h(dt0Var2)) {
                            break;
                        }
                        i3++;
                    } else if (!z2) {
                        z3 = false;
                    }
                }
            }
            z3 = true;
            it0Var = (it0) p3Var.f;
            it0Var2 = it0.g;
            at0Var2 = at0.g;
            if (it0Var != it0Var2) {
                if (at0Var == at0.e && z3) {
                    p3Var.g = zs0Var;
                    if (z && !jt0Var.c) {
                        z4 = false;
                    } else {
                        z4 = true;
                    }
                    p3Var.l(zs0Var, z4);
                }
                if (at0Var == at0.f && z && zs0Var == ((zs0) p3Var.g) && jt0Var.c) {
                    int size4 = list.size();
                    for (int i4 = 0; i4 < size4; i4++) {
                        ((dt0) list.get(i4)).a();
                    }
                }
                if (at0Var == at0Var2 && !z3 && zs0Var != ((zs0) p3Var.g)) {
                    p3Var.l(zs0Var, true);
                }
            }
            if (at0Var != at0Var2) {
                int size5 = list.size();
                int i5 = 0;
                while (true) {
                    if (i5 < size5) {
                        if (!nb0.h((dt0) list.get(i5))) {
                            break;
                        }
                        i5++;
                    } else {
                        p3Var.f = it0.e;
                        ((jt0) p3Var.h).c = false;
                        p3Var.g = null;
                        break;
                    }
                }
                if (zs0Var == ((zs0) p3Var.g) && z) {
                    int size6 = list.size();
                    int i6 = 0;
                    while (true) {
                        if (i6 >= size6) {
                            break;
                        } else if (((dt0) list.get(i6)).b()) {
                            if (!jt0Var.c) {
                                p3Var.q(zs0Var);
                                return;
                            }
                        } else {
                            i6++;
                        }
                    }
                    int size7 = list.size();
                    for (int i7 = 0; i7 < size7; i7++) {
                        ((dt0) list.get(i7)).a();
                    }
                    return;
                }
                return;
            }
            return;
        }
        z2 = false;
        if (!jt0Var.c) {
        }
        z3 = true;
        it0Var = (it0) p3Var.f;
        it0Var2 = it0.g;
        at0Var2 = at0.g;
        if (it0Var != it0Var2) {
        }
        if (at0Var != at0Var2) {
        }
    }
}