package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: d51  reason: default package */
public abstract class d51 {
    static {
        new ad0(new hp0(11));
    }

    public static final y41 a(a51 a51Var, d10 d10Var) {
        c51 c51Var = ((dh0) d10Var.j(fh0.a)).c;
        switch (a51Var.ordinal()) {
            case 0:
                return c51Var.h;
            case 1:
                return c51Var.e;
            case 2:
                return c51Var.g;
            case 3:
                return b(c51Var.e);
            case gu0.LONG_FIELD_NUMBER /* 4 */:
                return c51Var.a;
            case gu0.STRING_FIELD_NUMBER /* 5 */:
                return b(c51Var.a);
            case gu0.STRING_SET_FIELD_NUMBER /* 6 */:
                return py0.a;
            case gu0.DOUBLE_FIELD_NUMBER /* 7 */:
                return c51Var.d;
            case 8:
                oy0 oy0Var = c51Var.d;
                cr crVar = z41.i;
                return oy0.b(oy0Var, crVar, null, null, crVar, 6);
            case 9:
                return c51Var.f;
            case 10:
                oy0 oy0Var2 = c51Var.d;
                cr crVar2 = z41.i;
                return oy0.b(oy0Var2, null, crVar2, crVar2, null, 9);
            case 11:
                return b(c51Var.d);
            case 12:
                return c51Var.c;
            case 13:
                return vn.j;
            case 14:
                return c51Var.b;
            default:
                od.k();
                return null;
        }
    }

    public static oy0 b(oy0 oy0Var) {
        cr crVar = z41.i;
        return oy0.b(oy0Var, null, null, crVar, crVar, 3);
    }
}