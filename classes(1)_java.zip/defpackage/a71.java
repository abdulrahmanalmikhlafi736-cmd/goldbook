package defpackage;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: a71  reason: default package */
public final class a71 {
    public final i00 a;
    public Object b;
    public zj0 c;
    public boolean j;
    public int k;
    public int d = -1;
    public final hk0 e = mc0.h();
    public final hk0 f = new hk0();
    public final ik0 g = new ik0();
    public final qk0 h = new qk0(new sp[16]);
    public final c10 i = new c10(1, this);
    public final hk0 l = mc0.h();
    public final HashMap m = new HashMap();

    public a71(i00 i00Var) {
        this.a = i00Var;
    }

    /* JADX WARN: Code restructure failed: missing block: B:16:0x0064, code lost:
        if (((defpackage.i81) r15).e(2) == false) goto L153;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:261:0x053c  */
    /* JADX WARN: Type inference failed for: r6v44 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean a(Set set) {
        char c;
        long j;
        boolean z;
        Iterator it;
        Object obj;
        int i;
        Object g;
        boolean z2;
        Object[] objArr;
        Iterator it2;
        Object obj2;
        hk0 hk0Var;
        int i2;
        Object[] objArr2;
        long j2;
        boolean z3;
        long[] jArr;
        int i3;
        int i4;
        Object[] objArr3;
        int i5;
        qk0 qk0Var;
        sp spVar;
        int i6;
        int i7;
        qk0 qk0Var2;
        sp spVar2;
        zj0 zj0Var;
        long[] jArr2;
        nq0 nq0Var;
        Object[] objArr4;
        hk0 hk0Var2;
        HashMap hashMap;
        long[] jArr3;
        nq0 nq0Var2;
        Object[] objArr5;
        hk0 hk0Var3;
        HashMap hashMap2;
        int i8;
        int i9;
        int i10;
        long j3;
        HashMap hashMap3;
        Object[] objArr6;
        hk0 hk0Var4;
        HashMap hashMap4;
        int i11;
        int i12;
        long j4;
        int i13;
        long[] jArr4;
        long[] jArr5;
        nq0 nq0Var3 = nq0.j;
        boolean z4 = set instanceof p01;
        qk0 qk0Var3 = this.h;
        hk0 hk0Var5 = this.l;
        HashMap hashMap5 = this.m;
        hk0 hk0Var6 = this.e;
        ik0 ik0Var = this.g;
        if (z4) {
            ik0 ik0Var2 = ((p01) set).e;
            Object[] objArr7 = ik0Var2.b;
            long[] jArr6 = ik0Var2.a;
            c = 7;
            int length = jArr6.length - 2;
            if (length >= 0) {
                int i14 = 0;
                z = false;
                j = -9187201950435737472L;
                while (true) {
                    int i15 = 8;
                    long j5 = jArr6[i14];
                    int i16 = i14;
                    if ((((~j5) << 7) & j5 & (-9187201950435737472L)) != -9187201950435737472L) {
                        int i17 = 8 - ((~(i16 - length)) >>> 31);
                        int i18 = 0;
                        while (i18 < i17) {
                            if ((j5 & 255) < 128) {
                                Object obj3 = objArr7[(i16 << 3) + i18];
                                jArr3 = jArr6;
                                if (obj3 instanceof i81) {
                                    nq0Var2 = nq0Var3;
                                } else {
                                    nq0Var2 = nq0Var3;
                                }
                                if (!this.j && hk0Var5.c(obj3)) {
                                    this.j = true;
                                    try {
                                        Object g2 = hk0Var5.g(obj3);
                                        if (g2 != null) {
                                            if (g2 instanceof ik0) {
                                                ik0 ik0Var3 = (ik0) g2;
                                                Object[] objArr8 = ik0Var3.b;
                                                long[] jArr7 = ik0Var3.a;
                                                int length2 = jArr7.length - 2;
                                                if (length2 >= 0) {
                                                    i10 = i18;
                                                    boolean z5 = z;
                                                    int i19 = 0;
                                                    while (true) {
                                                        long j6 = jArr7[i19];
                                                        j3 = j5;
                                                        if ((((~j6) << 7) & j6 & (-9187201950435737472L)) != -9187201950435737472L) {
                                                            int i20 = 8 - ((~(i19 - length2)) >>> 31);
                                                            int i21 = 0;
                                                            while (i21 < i20) {
                                                                if ((j6 & 255) < 128) {
                                                                    objArr6 = objArr7;
                                                                    sp spVar3 = (sp) objArr8[(i19 << 3) + i21];
                                                                    spVar3.getClass();
                                                                    j4 = j6;
                                                                    Object obj4 = hashMap5.get(spVar3);
                                                                    t61 t61Var = spVar3.g;
                                                                    if (t61Var == null) {
                                                                        t61Var = nq0Var2;
                                                                    }
                                                                    i13 = i21;
                                                                    if (!t61Var.c(spVar3.h().f, obj4)) {
                                                                        Object g3 = hk0Var6.g(spVar3);
                                                                        if (g3 != null) {
                                                                            if (g3 instanceof ik0) {
                                                                                ik0 ik0Var4 = (ik0) g3;
                                                                                Object[] objArr9 = ik0Var4.b;
                                                                                long[] jArr8 = ik0Var4.a;
                                                                                int length3 = jArr8.length - 2;
                                                                                if (length3 >= 0) {
                                                                                    i11 = length;
                                                                                    i12 = i17;
                                                                                    int i22 = 0;
                                                                                    while (true) {
                                                                                        long j7 = jArr8[i22];
                                                                                        hk0Var4 = hk0Var5;
                                                                                        hashMap4 = hashMap5;
                                                                                        if ((((~j7) << 7) & j7 & (-9187201950435737472L)) != -9187201950435737472L) {
                                                                                            int i23 = 8 - ((~(i22 - length3)) >>> 31);
                                                                                            int i24 = 0;
                                                                                            while (i24 < i23) {
                                                                                                if ((j7 & 255) < 128) {
                                                                                                    jArr5 = jArr8;
                                                                                                    ik0Var.a(objArr9[(i22 << 3) + i24]);
                                                                                                    z5 = true;
                                                                                                } else {
                                                                                                    jArr5 = jArr8;
                                                                                                }
                                                                                                j7 >>= i15;
                                                                                                i24++;
                                                                                                jArr8 = jArr5;
                                                                                            }
                                                                                            jArr4 = jArr8;
                                                                                            if (i23 != i15) {
                                                                                                break;
                                                                                            }
                                                                                        } else {
                                                                                            jArr4 = jArr8;
                                                                                        }
                                                                                        if (i22 == length3) {
                                                                                            break;
                                                                                        }
                                                                                        i22++;
                                                                                        hk0Var5 = hk0Var4;
                                                                                        hashMap5 = hashMap4;
                                                                                        jArr8 = jArr4;
                                                                                        i15 = 8;
                                                                                    }
                                                                                }
                                                                            } else {
                                                                                hk0Var4 = hk0Var5;
                                                                                hashMap4 = hashMap5;
                                                                                i11 = length;
                                                                                i12 = i17;
                                                                                ik0Var.a(g3);
                                                                                z5 = true;
                                                                            }
                                                                        }
                                                                        hk0Var4 = hk0Var5;
                                                                        hashMap4 = hashMap5;
                                                                        i11 = length;
                                                                        i12 = i17;
                                                                    } else {
                                                                        hk0Var4 = hk0Var5;
                                                                        hashMap4 = hashMap5;
                                                                        i11 = length;
                                                                        i12 = i17;
                                                                        qk0Var3.b(spVar3);
                                                                    }
                                                                } else {
                                                                    objArr6 = objArr7;
                                                                    hk0Var4 = hk0Var5;
                                                                    hashMap4 = hashMap5;
                                                                    i11 = length;
                                                                    i12 = i17;
                                                                    j4 = j6;
                                                                    i13 = i21;
                                                                }
                                                                j6 = j4 >> 8;
                                                                i21 = i13 + 1;
                                                                i15 = 8;
                                                                objArr7 = objArr6;
                                                                length = i11;
                                                                i17 = i12;
                                                                hk0Var5 = hk0Var4;
                                                                hashMap5 = hashMap4;
                                                            }
                                                            objArr5 = objArr7;
                                                            hk0Var3 = hk0Var5;
                                                            hashMap3 = hashMap5;
                                                            i8 = length;
                                                            i9 = i17;
                                                            if (i20 != i15) {
                                                                break;
                                                            }
                                                        } else {
                                                            objArr5 = objArr7;
                                                            hk0Var3 = hk0Var5;
                                                            hashMap3 = hashMap5;
                                                            i8 = length;
                                                            i9 = i17;
                                                        }
                                                        if (i19 == length2) {
                                                            break;
                                                        }
                                                        i19++;
                                                        j5 = j3;
                                                        objArr7 = objArr5;
                                                        length = i8;
                                                        i17 = i9;
                                                        hk0Var5 = hk0Var3;
                                                        hashMap5 = hashMap3;
                                                        i15 = 8;
                                                    }
                                                    z = z5;
                                                } else {
                                                    objArr5 = objArr7;
                                                    hk0Var3 = hk0Var5;
                                                    hashMap3 = hashMap5;
                                                    i8 = length;
                                                    i9 = i17;
                                                    i10 = i18;
                                                    j3 = j5;
                                                }
                                                hashMap2 = hashMap3;
                                            } else {
                                                objArr5 = objArr7;
                                                hk0Var3 = hk0Var5;
                                                i8 = length;
                                                i9 = i17;
                                                i10 = i18;
                                                j3 = j5;
                                                sp spVar4 = (sp) g2;
                                                hashMap2 = hashMap5;
                                                Object obj5 = hashMap2.get(spVar4);
                                                t61 t61Var2 = spVar4.g;
                                                if (t61Var2 == null) {
                                                    t61Var2 = nq0Var2;
                                                }
                                                if (!t61Var2.c(spVar4.h().f, obj5)) {
                                                    Object g4 = hk0Var6.g(spVar4);
                                                    if (g4 != null) {
                                                        if (g4 instanceof ik0) {
                                                            ik0 ik0Var5 = (ik0) g4;
                                                            Object[] objArr10 = ik0Var5.b;
                                                            long[] jArr9 = ik0Var5.a;
                                                            int length4 = jArr9.length - 2;
                                                            if (length4 >= 0) {
                                                                int i25 = 0;
                                                                while (true) {
                                                                    long j8 = jArr9[i25];
                                                                    if ((((~j8) << 7) & j8 & (-9187201950435737472L)) != -9187201950435737472L) {
                                                                        int i26 = 8 - ((~(i25 - length4)) >>> 31);
                                                                        for (int i27 = 0; i27 < i26; i27++) {
                                                                            if ((j8 & 255) < 128) {
                                                                                ik0Var.a(objArr10[(i25 << 3) + i27]);
                                                                                z = true;
                                                                            }
                                                                            j8 >>= 8;
                                                                        }
                                                                        if (i26 != 8) {
                                                                            break;
                                                                        }
                                                                    }
                                                                    if (i25 == length4) {
                                                                        break;
                                                                    }
                                                                    i25++;
                                                                }
                                                            }
                                                        } else {
                                                            ik0Var.a(g4);
                                                            z = true;
                                                        }
                                                    }
                                                } else {
                                                    qk0Var3.b(spVar4);
                                                }
                                            }
                                        } else {
                                            objArr5 = objArr7;
                                            hk0Var3 = hk0Var5;
                                            hashMap2 = hashMap5;
                                            i8 = length;
                                            i9 = i17;
                                            i10 = i18;
                                            j3 = j5;
                                        }
                                        this.j = false;
                                    } finally {
                                    }
                                } else {
                                    objArr5 = objArr7;
                                    hk0Var3 = hk0Var5;
                                    hashMap2 = hashMap5;
                                    i8 = length;
                                    i9 = i17;
                                    i10 = i18;
                                    j3 = j5;
                                }
                                Object g5 = hk0Var6.g(obj3);
                                if (g5 != null) {
                                    if (g5 instanceof ik0) {
                                        ik0 ik0Var6 = (ik0) g5;
                                        Object[] objArr11 = ik0Var6.b;
                                        long[] jArr10 = ik0Var6.a;
                                        int length5 = jArr10.length - 2;
                                        if (length5 >= 0) {
                                            int i28 = 0;
                                            while (true) {
                                                long j9 = jArr10[i28];
                                                if ((((~j9) << 7) & j9 & (-9187201950435737472L)) != -9187201950435737472L) {
                                                    int i29 = 8 - ((~(i28 - length5)) >>> 31);
                                                    long j10 = j9;
                                                    for (int i30 = 0; i30 < i29; i30++) {
                                                        if ((j10 & 255) < 128) {
                                                            ik0Var.a(objArr11[(i28 << 3) + i30]);
                                                            z = true;
                                                        }
                                                        j10 >>= 8;
                                                    }
                                                    if (i29 != 8) {
                                                        break;
                                                    }
                                                }
                                                if (i28 == length5) {
                                                    break;
                                                }
                                                i28++;
                                            }
                                        }
                                    } else {
                                        ik0Var.a(g5);
                                        z = true;
                                    }
                                }
                                i18 = i10 + 1;
                                i15 = 8;
                                jArr6 = jArr3;
                                objArr7 = objArr5;
                                length = i8;
                                i17 = i9;
                                j5 = j3 >> 8;
                                hk0Var5 = hk0Var3;
                                hashMap5 = hashMap2;
                                nq0Var3 = nq0Var2;
                            } else {
                                jArr3 = jArr6;
                                nq0Var2 = nq0Var3;
                            }
                            objArr5 = objArr7;
                            hk0Var3 = hk0Var5;
                            hashMap2 = hashMap5;
                            i8 = length;
                            i9 = i17;
                            i10 = i18;
                            j3 = j5;
                            i18 = i10 + 1;
                            i15 = 8;
                            jArr6 = jArr3;
                            objArr7 = objArr5;
                            length = i8;
                            i17 = i9;
                            j5 = j3 >> 8;
                            hk0Var5 = hk0Var3;
                            hashMap5 = hashMap2;
                            nq0Var3 = nq0Var2;
                        }
                        jArr2 = jArr6;
                        nq0Var = nq0Var3;
                        objArr4 = objArr7;
                        hk0Var2 = hk0Var5;
                        hashMap = hashMap5;
                        int i31 = length;
                        if (i17 != i15) {
                            break;
                        }
                        length = i31;
                    } else {
                        jArr2 = jArr6;
                        nq0Var = nq0Var3;
                        objArr4 = objArr7;
                        hk0Var2 = hk0Var5;
                        hashMap = hashMap5;
                    }
                    if (i16 == length) {
                        break;
                    }
                    i14 = i16 + 1;
                    hashMap5 = hashMap;
                    jArr6 = jArr2;
                    nq0Var3 = nq0Var;
                    objArr7 = objArr4;
                    hk0Var5 = hk0Var2;
                }
            } else {
                j = -9187201950435737472L;
                z = false;
            }
        } else {
            hk0 hk0Var7 = hk0Var5;
            c = 7;
            j = -9187201950435737472L;
            Iterator it3 = set.iterator();
            boolean z6 = false;
            while (it3.hasNext()) {
                Object next = it3.next();
                if ((next instanceof i81) && !((i81) next).e(2)) {
                    it = it3;
                } else {
                    if (!this.j) {
                        hk0 hk0Var8 = hk0Var7;
                        if (hk0Var8.c(next)) {
                            this.j = true;
                            try {
                                Object g6 = hk0Var8.g(next);
                                if (g6 != null) {
                                    if (g6 instanceof ik0) {
                                        ik0 ik0Var7 = (ik0) g6;
                                        Object[] objArr12 = ik0Var7.b;
                                        long[] jArr11 = ik0Var7.a;
                                        int length6 = jArr11.length - 2;
                                        if (length6 >= 0) {
                                            boolean z7 = z6;
                                            int i32 = 0;
                                            while (true) {
                                                long j11 = jArr11[i32];
                                                long[] jArr12 = jArr11;
                                                if ((((~j11) << 7) & j11 & (-9187201950435737472L)) != -9187201950435737472L) {
                                                    int i33 = 8 - ((~(i32 - length6)) >>> 31);
                                                    int i34 = 0;
                                                    while (i34 < i33) {
                                                        if ((j11 & 255) < 128) {
                                                            it2 = it3;
                                                            sp spVar5 = (sp) objArr12[(i32 << 3) + i34];
                                                            spVar5.getClass();
                                                            hk0Var = hk0Var8;
                                                            Object obj6 = hashMap5.get(spVar5);
                                                            i2 = i34;
                                                            t61 t61Var3 = spVar5.g;
                                                            if (t61Var3 == null) {
                                                                t61Var3 = nq0Var3;
                                                            }
                                                            objArr2 = objArr12;
                                                            if (!t61Var3.c(spVar5.h().f, obj6)) {
                                                                Object g7 = hk0Var6.g(spVar5);
                                                                if (g7 != null) {
                                                                    if (g7 instanceof ik0) {
                                                                        ik0 ik0Var8 = (ik0) g7;
                                                                        Object[] objArr13 = ik0Var8.b;
                                                                        long[] jArr13 = ik0Var8.a;
                                                                        int length7 = jArr13.length - 2;
                                                                        if (length7 >= 0) {
                                                                            j2 = j11;
                                                                            int i35 = 0;
                                                                            boolean z8 = z7;
                                                                            while (true) {
                                                                                long j12 = jArr13[i35];
                                                                                obj2 = next;
                                                                                Object[] objArr14 = objArr13;
                                                                                if ((((~j12) << 7) & j12 & (-9187201950435737472L)) != -9187201950435737472L) {
                                                                                    int i36 = 8 - ((~(i35 - length7)) >>> 31);
                                                                                    int i37 = 0;
                                                                                    while (i37 < i36) {
                                                                                        if ((j12 & 255) < 128) {
                                                                                            ik0Var.a(objArr14[(i35 << 3) + i37]);
                                                                                            z8 = true;
                                                                                        }
                                                                                        j12 >>= 8;
                                                                                        i37++;
                                                                                        jArr13 = jArr13;
                                                                                    }
                                                                                    jArr = jArr13;
                                                                                    if (i36 != 8) {
                                                                                        z3 = z8;
                                                                                        break;
                                                                                    }
                                                                                } else {
                                                                                    jArr = jArr13;
                                                                                }
                                                                                if (i35 != length7) {
                                                                                    i35++;
                                                                                    next = obj2;
                                                                                    objArr13 = objArr14;
                                                                                    jArr13 = jArr;
                                                                                } else {
                                                                                    z7 = z8;
                                                                                    break;
                                                                                }
                                                                            }
                                                                            z3 = z7;
                                                                        }
                                                                    } else {
                                                                        obj2 = next;
                                                                        j2 = j11;
                                                                        ik0Var.a(g7);
                                                                        z3 = true;
                                                                    }
                                                                    z7 = z3;
                                                                }
                                                                obj2 = next;
                                                                j2 = j11;
                                                                z3 = z7;
                                                                z7 = z3;
                                                            } else {
                                                                obj2 = next;
                                                                j2 = j11;
                                                                qk0Var3.b(spVar5);
                                                            }
                                                        } else {
                                                            it2 = it3;
                                                            obj2 = next;
                                                            hk0Var = hk0Var8;
                                                            i2 = i34;
                                                            objArr2 = objArr12;
                                                            j2 = j11;
                                                        }
                                                        i34 = i2 + 1;
                                                        it3 = it2;
                                                        j11 = j2 >> 8;
                                                        objArr12 = objArr2;
                                                        next = obj2;
                                                        hk0Var8 = hk0Var;
                                                    }
                                                    it = it3;
                                                    obj = next;
                                                    hk0Var7 = hk0Var8;
                                                    objArr = objArr12;
                                                    if (i33 != 8) {
                                                        break;
                                                    }
                                                } else {
                                                    it = it3;
                                                    obj = next;
                                                    hk0Var7 = hk0Var8;
                                                    objArr = objArr12;
                                                }
                                                if (i32 == length6) {
                                                    break;
                                                }
                                                i32++;
                                                it3 = it;
                                                jArr11 = jArr12;
                                                objArr12 = objArr;
                                                next = obj;
                                                hk0Var8 = hk0Var7;
                                            }
                                            z6 = z7;
                                        }
                                    } else {
                                        it = it3;
                                        obj = next;
                                        hk0Var7 = hk0Var8;
                                        sp spVar6 = (sp) g6;
                                        Object obj7 = hashMap5.get(spVar6);
                                        t61 t61Var4 = spVar6.g;
                                        if (t61Var4 == null) {
                                            t61Var4 = nq0Var3;
                                        }
                                        if (!t61Var4.c(spVar6.h().f, obj7)) {
                                            Object g8 = hk0Var6.g(spVar6);
                                            if (g8 != null) {
                                                if (g8 instanceof ik0) {
                                                    ik0 ik0Var9 = (ik0) g8;
                                                    Object[] objArr15 = ik0Var9.b;
                                                    long[] jArr14 = ik0Var9.a;
                                                    int length8 = jArr14.length - 2;
                                                    if (length8 >= 0) {
                                                        boolean z9 = z6;
                                                        int i38 = 0;
                                                        while (true) {
                                                            long j13 = jArr14[i38];
                                                            if ((((~j13) << 7) & j13 & (-9187201950435737472L)) != -9187201950435737472L) {
                                                                int i39 = 8 - ((~(i38 - length8)) >>> 31);
                                                                long j14 = j13;
                                                                for (int i40 = 0; i40 < i39; i40++) {
                                                                    if ((j14 & 255) < 128) {
                                                                        ik0Var.a(objArr15[(i38 << 3) + i40]);
                                                                        z9 = true;
                                                                    }
                                                                    j14 >>= 8;
                                                                }
                                                                if (i39 != 8) {
                                                                    z2 = z9;
                                                                    break;
                                                                }
                                                            }
                                                            if (i38 != length8) {
                                                                i38++;
                                                            } else {
                                                                z6 = z9;
                                                                break;
                                                            }
                                                        }
                                                    }
                                                } else {
                                                    ik0Var.a(g8);
                                                    z2 = true;
                                                }
                                                z6 = z2;
                                            }
                                            z2 = z6;
                                            z6 = z2;
                                        } else {
                                            qk0Var3.b(spVar6);
                                        }
                                    }
                                    i = 0;
                                    this.j = false;
                                    boolean z10 = z6;
                                    g = hk0Var6.g(obj);
                                    if (g != null) {
                                        if (g instanceof ik0) {
                                            ik0 ik0Var10 = (ik0) g;
                                            Object[] objArr16 = ik0Var10.b;
                                            long[] jArr15 = ik0Var10.a;
                                            int length9 = jArr15.length - 2;
                                            if (length9 >= 0) {
                                                int i41 = i;
                                                while (true) {
                                                    long j15 = jArr15[i41];
                                                    if ((((~j15) << 7) & j15 & (-9187201950435737472L)) != -9187201950435737472L) {
                                                        int i42 = 8 - ((~(i41 - length9)) >>> 31);
                                                        long j16 = j15;
                                                        for (int i43 = i; i43 < i42; i43++) {
                                                            if ((j16 & 255) < 128) {
                                                                ik0Var.a(objArr16[(i41 << 3) + i43]);
                                                                z10 = true;
                                                            }
                                                            j16 >>= 8;
                                                        }
                                                        if (i42 != 8) {
                                                            break;
                                                        }
                                                    }
                                                    if (i41 == length9) {
                                                        break;
                                                    }
                                                    i41++;
                                                }
                                            }
                                        } else {
                                            ik0Var.a(g);
                                            z10 = true;
                                        }
                                    }
                                    z6 = z10;
                                }
                                it = it3;
                                obj = next;
                                hk0Var7 = hk0Var8;
                                i = 0;
                                this.j = false;
                                boolean z102 = z6;
                                g = hk0Var6.g(obj);
                                if (g != null) {
                                }
                                z6 = z102;
                            } finally {
                            }
                        } else {
                            hk0Var7 = hk0Var8;
                        }
                    }
                    it = it3;
                    obj = next;
                    i = 0;
                    boolean z1022 = z6;
                    g = hk0Var6.g(obj);
                    if (g != null) {
                    }
                    z6 = z1022;
                }
                it3 = it;
            }
            z = z6;
        }
        int i44 = 0;
        if (!this.j && (i3 = qk0Var3.g) != 0) {
            Object[] objArr17 = qk0Var3.e;
            int i45 = 0;
            while (i45 < i3) {
                sp spVar7 = (sp) objArr17[i45];
                long g9 = n61.j().g();
                int i46 = (int) (g9 ^ (g9 >>> 32));
                Object g10 = hk0Var6.g(spVar7);
                if (g10 != null) {
                    boolean z11 = g10 instanceof ik0;
                    hk0 hk0Var9 = this.f;
                    if (z11) {
                        ik0 ik0Var11 = (ik0) g10;
                        Object[] objArr18 = ik0Var11.b;
                        long[] jArr16 = ik0Var11.a;
                        int length10 = jArr16.length - 2;
                        if (length10 >= 0) {
                            int i47 = i44;
                            sp spVar8 = spVar7;
                            while (true) {
                                long j17 = jArr16[i47];
                                objArr3 = objArr17;
                                i5 = i45;
                                if ((((~j17) << c) & j17 & j) != j) {
                                    int i48 = 8 - ((~(i47 - length10)) >>> 31);
                                    int i49 = 0;
                                    while (i49 < i48) {
                                        if ((j17 & 255) < 128) {
                                            i6 = i3;
                                            Object obj8 = objArr18[(i47 << 3) + i49];
                                            zj0 zj0Var2 = (zj0) hk0Var9.g(obj8);
                                            i7 = i49;
                                            if (zj0Var2 == null) {
                                                zj0Var = new zj0();
                                                hk0Var9.m(obj8, zj0Var);
                                            } else {
                                                zj0Var = zj0Var2;
                                            }
                                            qk0Var2 = qk0Var3;
                                            spVar2 = spVar8;
                                            b(spVar2, i46, obj8, zj0Var);
                                        } else {
                                            i6 = i3;
                                            i7 = i49;
                                            qk0Var2 = qk0Var3;
                                            spVar2 = spVar8;
                                        }
                                        j17 >>= 8;
                                        i49 = i7 + 1;
                                        spVar8 = spVar2;
                                        qk0Var3 = qk0Var2;
                                        i3 = i6;
                                    }
                                    i4 = i3;
                                    qk0Var = qk0Var3;
                                    spVar = spVar8;
                                    if (i48 != 8) {
                                        break;
                                    }
                                } else {
                                    i4 = i3;
                                    qk0Var = qk0Var3;
                                    spVar = spVar8;
                                }
                                if (i47 != length10) {
                                    i47++;
                                    spVar8 = spVar;
                                    objArr17 = objArr3;
                                    i45 = i5;
                                    qk0Var3 = qk0Var;
                                    i3 = i4;
                                }
                            }
                        } else {
                            i4 = i3;
                            objArr3 = objArr17;
                            i5 = i45;
                            qk0Var = qk0Var3;
                        }
                    } else {
                        i4 = i3;
                        objArr3 = objArr17;
                        i5 = i45;
                        qk0Var = qk0Var3;
                        zj0 zj0Var3 = (zj0) hk0Var9.g(g10);
                        if (zj0Var3 == null) {
                            zj0Var3 = new zj0();
                            hk0Var9.m(g10, zj0Var3);
                        }
                        b(spVar7, i46, g10, zj0Var3);
                    }
                } else {
                    i4 = i3;
                    objArr3 = objArr17;
                    i5 = i45;
                    qk0Var = qk0Var3;
                }
                i45 = i5 + 1;
                objArr17 = objArr3;
                qk0Var3 = qk0Var;
                i3 = i4;
                i44 = 0;
            }
            qk0Var3.g();
        }
        return z;
    }

    public final void b(Object obj, int i, Object obj2, zj0 zj0Var) {
        int i2;
        if (this.k <= 0) {
            int c = zj0Var.c(obj);
            if (c < 0) {
                c = ~c;
                i2 = -1;
            } else {
                i2 = zj0Var.c[c];
            }
            zj0Var.b[c] = obj;
            zj0Var.c[c] = i;
            if ((obj instanceof sp) && i2 != i) {
                rp h = ((sp) obj).h();
                this.m.put(obj, h.f);
                zj0 zj0Var2 = h.e;
                hk0 hk0Var = this.l;
                mc0.z(hk0Var, obj);
                Object[] objArr = zj0Var2.b;
                long[] jArr = zj0Var2.a;
                int length = jArr.length - 2;
                if (length >= 0) {
                    int i3 = 0;
                    while (true) {
                        long j = jArr[i3];
                        if ((((~j) << 7) & j & (-9187201950435737472L)) != -9187201950435737472L) {
                            int i4 = 8 - ((~(i3 - length)) >>> 31);
                            for (int i5 = 0; i5 < i4; i5++) {
                                if ((j & 255) < 128) {
                                    h81 h81Var = (h81) objArr[(i3 << 3) + i5];
                                    if (h81Var instanceof i81) {
                                        ((i81) h81Var).f(2);
                                    }
                                    mc0.d(hk0Var, h81Var, obj);
                                }
                                j >>= 8;
                            }
                            if (i4 != 8) {
                                break;
                            }
                        }
                        if (i3 == length) {
                            break;
                        }
                        i3++;
                    }
                }
            }
            if (i2 == -1) {
                if (obj instanceof i81) {
                    ((i81) obj).f(2);
                }
                mc0.d(this.e, obj, obj2);
            }
        }
    }

    public final void c(Object obj, Object obj2) {
        hk0 hk0Var = this.e;
        mc0.y(hk0Var, obj2, obj);
        if ((obj2 instanceof sp) && !hk0Var.c(obj2)) {
            mc0.z(this.l, obj2);
            this.m.remove(obj2);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:31:0x00b0  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void d() {
        long[] jArr;
        long[] jArr2;
        long j;
        char c;
        long j2;
        int i;
        boolean z;
        long j3;
        hk0 hk0Var = this.f;
        long[] jArr3 = hk0Var.a;
        int length = jArr3.length - 2;
        if (length >= 0) {
            int i2 = 0;
            while (true) {
                long j4 = jArr3[i2];
                char c2 = 7;
                long j5 = -9187201950435737472L;
                if ((((~j4) << 7) & j4 & (-9187201950435737472L)) != -9187201950435737472L) {
                    int i3 = 8;
                    int i4 = 8 - ((~(i2 - length)) >>> 31);
                    int i5 = 0;
                    while (i5 < i4) {
                        if ((j4 & 255) < 128) {
                            int i6 = (i2 << 3) + i5;
                            c = c2;
                            Object obj = hk0Var.b[i6];
                            j2 = j5;
                            zj0 zj0Var = (zj0) hk0Var.c[i6];
                            obj.getClass();
                            boolean r = ((mp0) obj).r();
                            if (!r) {
                                Object[] objArr = zj0Var.b;
                                int[] iArr = zj0Var.c;
                                long[] jArr4 = zj0Var.a;
                                int i7 = i3;
                                int length2 = jArr4.length - 2;
                                if (length2 >= 0) {
                                    jArr2 = jArr3;
                                    j = j4;
                                    int i8 = 0;
                                    while (true) {
                                        long j6 = jArr4[i8];
                                        long[] jArr5 = jArr4;
                                        z = r;
                                        if ((((~j6) << c) & j6 & j2) != j2) {
                                            int i9 = 8 - ((~(i8 - length2)) >>> 31);
                                            for (int i10 = 0; i10 < i9; i10++) {
                                                if ((j6 & 255) < 128) {
                                                    int i11 = (i8 << 3) + i10;
                                                    j3 = j6;
                                                    Object obj2 = objArr[i11];
                                                    int i12 = iArr[i11];
                                                    c(obj, obj2);
                                                } else {
                                                    j3 = j6;
                                                }
                                                j6 = j3 >> i7;
                                            }
                                            if (i9 != i7) {
                                                break;
                                            }
                                        }
                                        if (i8 == length2) {
                                            break;
                                        }
                                        i8++;
                                        r = z;
                                        jArr4 = jArr5;
                                        i7 = 8;
                                    }
                                    if (!z) {
                                        hk0Var.l(i6);
                                    }
                                    i = 8;
                                }
                            }
                            jArr2 = jArr3;
                            j = j4;
                            z = r;
                            if (!z) {
                            }
                            i = 8;
                        } else {
                            jArr2 = jArr3;
                            j = j4;
                            c = c2;
                            j2 = j5;
                            i = i3;
                        }
                        i5++;
                        i3 = i;
                        j4 = j >> i;
                        c2 = c;
                        j5 = j2;
                        jArr3 = jArr2;
                    }
                    jArr = jArr3;
                    if (i4 != i3) {
                        return;
                    }
                } else {
                    jArr = jArr3;
                }
                if (i2 != length) {
                    i2++;
                    jArr3 = jArr;
                } else {
                    return;
                }
            }
        }
    }
}