package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: e91  reason: default package */
public final class e91 extends h90 implements m00 {
    public final /* synthetic */ int f;
    public final /* synthetic */ f91 g;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ e91(f91 f91Var, int i) {
        super(2);
        this.f = i;
        this.g = f91Var;
    }

    @Override // defpackage.m00
    public final Object f(Object obj, Object obj2) {
        int i = this.f;
        we1 we1Var = we1.a;
        f91 f91Var = this.g;
        switch (i) {
            case 0:
                ba0 ba0Var = (ba0) obj;
                f91Var.a().f = (sj) obj2;
                return we1Var;
            case 1:
                pa0 a = f91Var.a();
                ((ba0) obj).c0(new la0(a, (m00) obj2, a.t));
                return we1Var;
            default:
                ba0 ba0Var2 = (ba0) obj;
                f91 f91Var2 = (f91) obj2;
                i91 i91Var = f91Var.a;
                pa0 pa0Var = ba0Var2.L;
                if (pa0Var == null) {
                    pa0Var = new pa0(ba0Var2, i91Var);
                    ba0Var2.L = pa0Var;
                }
                f91Var.b = pa0Var;
                f91Var.a().h();
                pa0 a2 = f91Var.a();
                if (a2.g != i91Var) {
                    a2.g = i91Var;
                    a2.i(false);
                    ba0.V(a2.e, false, 7);
                }
                return we1Var;
        }
    }
}