package defpackage;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: du0  reason: default package */
public final class du0 extends l10 {
    private static final du0 DEFAULT_INSTANCE;
    private static volatile oq0 PARSER = null;
    public static final int STRINGS_FIELD_NUMBER = 1;
    private c70 strings_ = kv0.h;

    static {
        du0 du0Var = new du0();
        DEFAULT_INSTANCE = du0Var;
        l10.j(du0.class, du0Var);
    }

    public static void l(du0 du0Var, Iterable iterable) {
        int i;
        c70 c70Var = du0Var.strings_;
        if (!((kv0) c70Var).e) {
            kv0 kv0Var = (kv0) c70Var;
            int i2 = kv0Var.g;
            if (i2 == 0) {
                i = 10;
            } else {
                i = i2 * 2;
            }
            du0Var.strings_ = kv0Var.c(i);
        }
        c70 c70Var2 = du0Var.strings_;
        Charset charset = d70.a;
        if (iterable instanceof yc0) {
            List d = ((yc0) iterable).d();
            if (c70Var2 == null) {
                ((kv0) c70Var2).getClass();
                Iterator it = d.iterator();
                if (it.hasNext()) {
                    Object next = it.next();
                    next.getClass();
                    if (!(next instanceof zd)) {
                        if (next instanceof byte[]) {
                            byte[] bArr = (byte[]) next;
                            zd.c(bArr, 0, bArr.length);
                            throw null;
                        }
                        String str = (String) next;
                        throw null;
                    }
                    throw null;
                }
                return;
            }
            od.d();
        } else if (iterable instanceof su0) {
            ((kv0) c70Var2).addAll((Collection) iterable);
        } else {
            if ((c70Var2 instanceof ArrayList) && (iterable instanceof Collection)) {
                ((ArrayList) c70Var2).ensureCapacity(((Collection) iterable).size() + ((kv0) c70Var2).g);
            }
            kv0 kv0Var2 = (kv0) c70Var2;
            int i3 = kv0Var2.g;
            for (Object obj : iterable) {
                if (obj == null) {
                    String str2 = "Element at index " + (kv0Var2.g - i3) + " is null.";
                    for (int i4 = kv0Var2.g - 1; i4 >= i3; i4--) {
                        kv0Var2.remove(i4);
                    }
                    throw new NullPointerException(str2);
                }
                kv0Var2.add(obj);
            }
        }
    }

    public static du0 m() {
        return DEFAULT_INSTANCE;
    }

    public static cu0 o() {
        return (cu0) ((j10) DEFAULT_INSTANCE.c(5));
    }

    /* JADX WARN: Type inference failed for: r2v12, types: [java.lang.Object, oq0] */
    @Override // defpackage.l10
    public final Object c(int i) {
        oq0 oq0Var;
        switch (fu0.N(i)) {
            case 0:
                return (byte) 1;
            case 1:
                return null;
            case 2:
                return new rv0(DEFAULT_INSTANCE, "\u0001\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0000\u0001\u001a", new Object[]{"strings_"});
            case 3:
                return new du0();
            case gu0.LONG_FIELD_NUMBER /* 4 */:
                return new j10(DEFAULT_INSTANCE);
            case gu0.STRING_FIELD_NUMBER /* 5 */:
                return DEFAULT_INSTANCE;
            case gu0.STRING_SET_FIELD_NUMBER /* 6 */:
                oq0 oq0Var2 = PARSER;
                if (oq0Var2 == null) {
                    synchronized (du0.class) {
                        try {
                            oq0 oq0Var3 = PARSER;
                            oq0Var = oq0Var3;
                            if (oq0Var3 == null) {
                                ?? obj = new Object();
                                PARSER = obj;
                                oq0Var = obj;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                    }
                    return oq0Var;
                }
                return oq0Var2;
            default:
                throw new UnsupportedOperationException();
        }
    }

    public final c70 n() {
        return this.strings_;
    }
}