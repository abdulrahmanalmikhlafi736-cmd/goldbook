package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: du  reason: default package */
public final class du extends h90 implements i00 {
    public final /* synthetic */ boolean f;
    public final /* synthetic */ xz g;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public du(boolean z, xz xzVar) {
        super(1);
        this.f = z;
        this.g = xzVar;
    }

    @Override // defpackage.i00
    public final Object i(Object obj) {
        boolean z;
        sx0 sx0Var = (sx0) obj;
        if (!this.f && ((Boolean) this.g.a()).booleanValue()) {
            z = true;
        } else {
            z = false;
        }
        if (sx0Var.o != z) {
            sx0Var.e |= 16384;
            sx0Var.o = z;
        }
        return we1.a;
    }
}