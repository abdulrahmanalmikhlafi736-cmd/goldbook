package defpackage;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: em  reason: default package */
public final class em {
    public static final em e;
    public static final em f;
    public static final em g;
    public static final em h;
    public static final /* synthetic */ em[] i;

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0, types: [java.lang.Enum, em] */
    /* JADX WARN: Type inference failed for: r1v1, types: [java.lang.Enum, em] */
    /* JADX WARN: Type inference failed for: r3v1, types: [java.lang.Enum, em] */
    /* JADX WARN: Type inference failed for: r5v1, types: [java.lang.Enum, em] */
    static {
        ?? r0 = new Enum("DEFAULT", 0);
        e = r0;
        ?? r1 = new Enum("LAZY", 1);
        f = r1;
        ?? r3 = new Enum("ATOMIC", 2);
        g = r3;
        ?? r5 = new Enum("UNDISPATCHED", 3);
        h = r5;
        i = new em[]{r0, r1, r3, r5};
    }

    public static em valueOf(String str) {
        return (em) Enum.valueOf(em.class, str);
    }

    public static em[] values() {
        return (em[]) i.clone();
    }
}