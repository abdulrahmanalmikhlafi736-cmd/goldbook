package defpackage;

import java.util.HashMap;
import java.util.Map;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ca0  reason: default package */
public final class ca0 {
    public final k3 a;
    public boolean c;
    public boolean d;
    public boolean e;
    public k3 f;
    public final /* synthetic */ int h;
    public boolean b = true;
    public final HashMap g = new HashMap();

    public ca0(k3 k3Var, int i) {
        this.h = i;
        this.a = k3Var;
    }

    public static final void a(ca0 ca0Var, f3 f3Var, int i, gm0 gm0Var) {
        float intBitsToFloat;
        float f;
        HashMap hashMap = ca0Var.g;
        float f2 = i;
        long floatToRawIntBits = Float.floatToRawIntBits(f2) << 32;
        long floatToRawIntBits2 = Float.floatToRawIntBits(f2) & 4294967295L;
        while (true) {
            long j = floatToRawIntBits | floatToRawIntBits2;
            do {
                switch (ca0Var.h) {
                    case 0:
                        kp0 kp0Var = gm0Var.P;
                        if (kp0Var != null) {
                            l20 l20Var = (l20) kp0Var;
                            float[] b = l20Var.b();
                            if (!l20Var.w) {
                                j = dd0.o(b, j);
                            }
                        }
                        j = vd1.z(j, gm0Var.D);
                        break;
                    default:
                        dg0 w0 = gm0Var.w0();
                        w0.getClass();
                        long j2 = w0.t;
                        j = xm0.f((Float.floatToRawIntBits((int) (j2 & 4294967295L)) & 4294967295L) | (Float.floatToRawIntBits((int) (j2 >> 32)) << 32), j);
                        break;
                }
                gm0Var = gm0Var.u;
                gm0Var.getClass();
                if (gm0Var.equals(ca0Var.a.o())) {
                    if (f3Var instanceof h30) {
                        intBitsToFloat = Float.intBitsToFloat((int) (j & 4294967295L));
                    } else {
                        intBitsToFloat = Float.intBitsToFloat((int) (j >> 32));
                    }
                    int round = Math.round(intBitsToFloat);
                    if (hashMap.containsKey(f3Var)) {
                        int intValue = ((Number) ch0.x(f3Var, hashMap)).intValue();
                        h30 h30Var = i3.a;
                        round = ((Number) f3Var.a.f(Integer.valueOf(intValue), Integer.valueOf(round))).intValue();
                    }
                    hashMap.put(f3Var, Integer.valueOf(round));
                    return;
                }
            } while (!ca0Var.b(gm0Var).containsKey(f3Var));
            long floatToRawIntBits3 = Float.floatToRawIntBits(ca0Var.c(gm0Var, f3Var));
            floatToRawIntBits = Float.floatToRawIntBits(f) << 32;
            floatToRawIntBits2 = floatToRawIntBits3 & 4294967295L;
        }
    }

    public final Map b(gm0 gm0Var) {
        switch (this.h) {
            case 0:
                return gm0Var.g0().c();
            default:
                dg0 w0 = gm0Var.w0();
                w0.getClass();
                return w0.g0().c();
        }
    }

    public final int c(gm0 gm0Var, f3 f3Var) {
        switch (this.h) {
            case 0:
                return gm0Var.Z(f3Var);
            default:
                dg0 w0 = gm0Var.w0();
                w0.getClass();
                return w0.Z(f3Var);
        }
    }

    public final boolean d() {
        if (!this.c && !this.d && !this.e) {
            return false;
        }
        return true;
    }

    public final boolean e() {
        h();
        if (this.f != null) {
            return true;
        }
        return false;
    }

    public final void f() {
        this.b = true;
        k3 k3Var = this.a;
        k3 s = k3Var.s();
        if (s == null) {
            return;
        }
        if (this.c) {
            s.requestLayout();
        }
        if (this.d) {
            k3Var.H();
        }
        if (this.e) {
            k3Var.requestLayout();
        }
        s.c().f();
    }

    public final void g() {
        HashMap hashMap = this.g;
        hashMap.clear();
        j3 j3Var = new j3(0, this);
        k3 k3Var = this.a;
        k3Var.l(j3Var);
        hashMap.putAll(b(k3Var.o()));
        this.b = false;
    }

    public final void h() {
        ca0 c;
        ca0 c2;
        boolean d = d();
        k3 k3Var = this.a;
        if (!d) {
            k3 s = k3Var.s();
            if (s != null) {
                k3Var = s.c().f;
                if (k3Var == null || !k3Var.c().d()) {
                    k3 k3Var2 = this.f;
                    if (k3Var2 != null && !k3Var2.c().d()) {
                        k3 s2 = k3Var2.s();
                        if (s2 != null && (c2 = s2.c()) != null) {
                            c2.h();
                        }
                        k3 s3 = k3Var2.s();
                        if (s3 != null && (c = s3.c()) != null) {
                            k3Var = c.f;
                        } else {
                            k3Var = null;
                        }
                    } else {
                        return;
                    }
                }
            } else {
                return;
            }
        }
        this.f = k3Var;
    }
}