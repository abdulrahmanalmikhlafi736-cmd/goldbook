package defpackage;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BlendMode;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.Region;
import android.os.Build;
import android.os.Trace;
import android.view.Display;
import android.view.RoundedCorner;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import java.lang.ref.WeakReference;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ConcurrentModificationException;
import java.util.List;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ac  reason: default package */
public abstract class ac {
    public static y30 E;
    public static final int[] a = {16842755, 16843041, 16843093, 16843097, 16843551, 16843754, 16843771, 16843778, 16843779};
    public static final int[] b = {16842755, 16843189, 16843190, 16843556, 16843557, 16843558, 16843866, 16843867};
    public static final int[] c = {16842755, 16843780, 16843781, 16843782, 16843783, 16843784, 16843785, 16843786, 16843787, 16843788, 16843789, 16843979, 16843980, 16844062};
    public static final int[] d = {16842755, 16843781};
    public static final float[][] e = {new float[]{0.401288f, 0.650173f, -0.051461f}, new float[]{-0.250268f, 1.204414f, 0.045854f}, new float[]{-0.002079f, 0.048952f, 0.953127f}};
    public static final float[][] f = {new float[]{1.8620678f, -1.0112547f, 0.14918678f}, new float[]{0.38752654f, 0.62144744f, -0.00897398f}, new float[]{-0.0158415f, -0.03412294f, 1.0499644f}};
    public static final float[] g = {95.047f, 100.0f, 108.883f};
    public static final float[][] h = {new float[]{0.41233894f, 0.35762063f, 0.18051042f}, new float[]{0.2126f, 0.7152f, 0.0722f}, new float[]{0.01932141f, 0.11916382f, 0.9503448f}};
    public static final pi i = new pi(-1837983555, false, new o9(8));
    public static final pi j = new pi(1116374984, false, new o9(9));
    public static final pi k = new pi(812517449, false, new o9(10));
    public static final mp l = new mp(1.0f, 1.0f);
    public static final eh m = eh.j;
    public static final eh n = eh.g;
    public static final float o = 0.1f;
    public static final eh p = eh.h;
    public static final float q = 0.38f;
    public static final float r = 1.0f;
    public static final eh s = eh.e;
    public static final byte[] t = {48, 49, 53, 0};
    public static final byte[] u = {48, 49, 48, 0};
    public static final byte[] v = {48, 48, 57, 0};
    public static final byte[] w = {48, 48, 53, 0};
    public static final byte[] x = {48, 48, 49, 0};
    public static final byte[] y = {48, 48, 49, 0};
    public static final byte[] z = {48, 48, 50, 0};
    public static final gw0 A = new gw0(0.0f, 0.0f, 10.0f, 10.0f);
    public static final mt B = new mt("NONE", 1);
    public static final mt C = new mt("PENDING", 1);
    public static final zv D = new Object();

    public static final mi0 A(ec0 ec0Var, sc scVar, bp0 bp0Var) {
        return new ya0(ec0Var, scVar, bp0Var);
    }

    public static float B(int i2) {
        float pow;
        float f2 = i2 / 255.0f;
        if (f2 <= 0.04045f) {
            pow = f2 / 12.92f;
        } else {
            pow = (float) Math.pow((f2 + 0.055f) / 1.055f, 2.4000000953674316d);
        }
        return pow * 100.0f;
    }

    public static final mi0 C(mi0 mi0Var, sp0 sp0Var) {
        return mi0Var.b(new tp0(sp0Var));
    }

    public static final mi0 D(mi0 mi0Var, float f2) {
        return mi0Var.b(new qp0(f2, f2, f2, f2));
    }

    public static final mi0 E(mi0 mi0Var, float f2, float f3) {
        return mi0Var.b(new qp0(f2, f3, f2, f3));
    }

    public static mi0 F(mi0 mi0Var, float f2, int i2) {
        float f3 = 0.0f;
        if ((i2 & 1) != 0) {
            f2 = 0.0f;
        }
        if ((i2 & 2) == 0) {
            f3 = 16.0f;
        }
        return E(mi0Var, f2, f3);
    }

    public static mi0 G(mi0 mi0Var, float f2, float f3, float f4, float f5, int i2) {
        if ((i2 & 1) != 0) {
            f2 = 0.0f;
        }
        if ((i2 & 2) != 0) {
            f3 = 0.0f;
        }
        if ((i2 & 4) != 0) {
            f4 = 0.0f;
        }
        if ((i2 & 8) != 0) {
            f5 = 0.0f;
        }
        return mi0Var.b(new qp0(f2, f3, f4, f5));
    }

    public static final BlendMode H(int i2) {
        if (i2 == 0) {
            return b1.a();
        }
        if (i2 == 1) {
            return b1.p();
        }
        if (i2 == 2) {
            return b1.j();
        }
        if (i2 == 3) {
            return b1.i();
        }
        if (i2 == 4) {
            return b1.k();
        }
        if (i2 == 5) {
            return b1.l();
        }
        if (i2 == 6) {
            return b1.m();
        }
        if (i2 == 7) {
            return b1.n();
        }
        if (i2 == 8) {
            return b1.o();
        }
        if (i2 == 9) {
            return b1.r();
        }
        if (i2 == 10) {
            return b1.g();
        }
        if (i2 == 11) {
            return b1.s();
        }
        if (i2 == 12) {
            return b1.t();
        }
        if (i2 == 13) {
            return b1.u();
        }
        if (i2 == 14) {
            return b1.v();
        }
        if (i2 == 15) {
            return s3.b();
        }
        if (i2 == 16) {
            return s3.w();
        }
        if (i2 == 17) {
            return s3.A();
        }
        if (i2 == 18) {
            return s3.C();
        }
        if (i2 == 19) {
            return b1.d();
        }
        if (i2 == 20) {
            return b1.w();
        }
        if (i2 == 21) {
            return b1.y();
        }
        if (i2 == 22) {
            return b1.z();
        }
        if (i2 == 23) {
            return b1.A();
        }
        if (i2 == 24) {
            return b1.B();
        }
        if (i2 == 25) {
            return b1.C();
        }
        if (i2 == 26) {
            return b1.D();
        }
        if (i2 == 27) {
            return b1.f();
        }
        if (i2 == 28) {
            return b1.h();
        }
        return b1.i();
    }

    public static final Bitmap.Config I(int i2) {
        Bitmap.Config config;
        Bitmap.Config config2;
        if (i2 == 0) {
            return Bitmap.Config.ARGB_8888;
        }
        if (i2 == 1) {
            return Bitmap.Config.ALPHA_8;
        }
        if (i2 == 2) {
            return Bitmap.Config.RGB_565;
        }
        int i3 = Build.VERSION.SDK_INT;
        if (i3 >= 26 && i2 == 3) {
            config2 = Bitmap.Config.RGBA_F16;
            return config2;
        } else if (i3 >= 26 && i2 == 4) {
            config = Bitmap.Config.HARDWARE;
            return config;
        } else {
            return Bitmap.Config.ARGB_8888;
        }
    }

    public static final PorterDuff.Mode J(int i2) {
        if (i2 == 0) {
            return PorterDuff.Mode.CLEAR;
        }
        if (i2 == 1) {
            return PorterDuff.Mode.SRC;
        }
        if (i2 == 2) {
            return PorterDuff.Mode.DST;
        }
        if (i2 == 3) {
            return PorterDuff.Mode.SRC_OVER;
        }
        if (i2 == 4) {
            return PorterDuff.Mode.DST_OVER;
        }
        if (i2 == 5) {
            return PorterDuff.Mode.SRC_IN;
        }
        if (i2 == 6) {
            return PorterDuff.Mode.DST_IN;
        }
        if (i2 == 7) {
            return PorterDuff.Mode.SRC_OUT;
        }
        if (i2 == 8) {
            return PorterDuff.Mode.DST_OUT;
        }
        if (i2 == 9) {
            return PorterDuff.Mode.SRC_ATOP;
        }
        if (i2 == 10) {
            return PorterDuff.Mode.DST_ATOP;
        }
        if (i2 == 11) {
            return PorterDuff.Mode.XOR;
        }
        if (i2 == 12) {
            return PorterDuff.Mode.ADD;
        }
        if (i2 == 14) {
            return PorterDuff.Mode.SCREEN;
        }
        if (i2 == 15) {
            return PorterDuff.Mode.OVERLAY;
        }
        if (i2 == 16) {
            return PorterDuff.Mode.DARKEN;
        }
        if (i2 == 17) {
            return PorterDuff.Mode.LIGHTEN;
        }
        if (i2 == 13) {
            return PorterDuff.Mode.MULTIPLY;
        }
        return PorterDuff.Mode.SRC_OVER;
    }

    public static String K(long j2) {
        int i2 = (int) (j2 >> 32);
        int i3 = (int) (j2 & 4294967295L);
        if (Float.intBitsToFloat(i2) == Float.intBitsToFloat(i3)) {
            return "CornerRadius.circular(" + vn.U(Float.intBitsToFloat(i2)) + ')';
        }
        return "CornerRadius.elliptical(" + vn.U(Float.intBitsToFloat(i2)) + ", " + vn.U(Float.intBitsToFloat(i3)) + ')';
    }

    public static Object L(m00 m00Var, Object obj, ml mlVar) {
        Object nlVar;
        m00Var.getClass();
        sl e2 = mlVar.e();
        if (e2 == st.e) {
            nlVar = new nx0(mlVar);
        } else {
            nlVar = new nl(mlVar, e2);
        }
        vd1.e(2, m00Var);
        return m00Var.f(obj, nlVar);
    }

    public static final int M(float f2, float[] fArr, int i2) {
        float f3 = 0.0f;
        if (f2 >= 0.0f) {
            f3 = f2;
        }
        if (f3 > 1.0f) {
            f3 = 1.0f;
        }
        if (Math.abs(f3 - f2) > 1.05E-6f) {
            f3 = Float.NaN;
        }
        fArr[i2] = f3;
        return !Float.isNaN(f3) ? 1 : 0;
    }

    public static float N() {
        return ((float) Math.pow(0.5689655172413793d, 3.0d)) * 100.0f;
    }

    public static final void a(final wp0 wp0Var, final mi0 mi0Var, nb nbVar, vj vjVar, float f2, d10 d10Var, final int i2) {
        int i3;
        boolean z2;
        d10Var.X(1142754848);
        if (d10Var.h(wp0Var)) {
            i3 = 4;
        } else {
            i3 = 2;
        }
        int i4 = i3 | i2 | 1797120;
        if ((599187 & i4) != 599186) {
            z2 = true;
        } else {
            z2 = false;
        }
        if (d10Var.O(i4 & 1, z2)) {
            nbVar = e3.j;
            d10Var.W(1899381698);
            d10Var.p(false);
            f2 = 1.0f;
            mi0 N = vn.N(k70.G(mi0Var.b(ji0.a), 0.0f, null, true, 520191), wp0Var, 1.0f, null, 2);
            Object L = d10Var.L();
            if (L == oj.a) {
                L = p5.f;
                d10Var.g0(L);
            }
            mh0 mh0Var = (mh0) L;
            long j2 = d10Var.T;
            int i5 = (int) (j2 ^ (j2 >>> 32));
            mi0 I = vn.I(d10Var, N);
            qr0 l2 = d10Var.l();
            ij.c.getClass();
            dk dkVar = hj.b;
            d10Var.Z();
            if (d10Var.S) {
                d10Var.k(dkVar);
            } else {
                d10Var.j0();
            }
            mc0.B(hj.f, d10Var, mh0Var);
            mc0.B(hj.e, d10Var, l2);
            mc0.w(d10Var, hj.h);
            mc0.B(hj.d, d10Var, I);
            mc0.p(d10Var, Integer.valueOf(i5), hj.g);
            d10Var.p(true);
            vjVar = hl.a;
        } else {
            d10Var.R();
        }
        final nb nbVar2 = nbVar;
        final vj vjVar2 = vjVar;
        final float f3 = f2;
        xv0 r2 = d10Var.r();
        if (r2 != null) {
            r2.d = new m00(mi0Var, nbVar2, vjVar2, f3, i2) { // from class: v30
                public final /* synthetic */ mi0 f;
                public final /* synthetic */ nb g;
                public final /* synthetic */ vj h;
                public final /* synthetic */ float i;

                @Override // defpackage.m00
                public final Object f(Object obj, Object obj2) {
                    ((Integer) obj2).getClass();
                    int s2 = wc0.s(441);
                    ac.a(wp0.this, this.f, this.g, this.h, this.i, (d10) obj, s2);
                    return we1.a;
                }
            };
        }
    }

    public static final long b(int i2) {
        long j2 = i2 << 32;
        int i3 = d90.p;
        return j2;
    }

    public static final d81 c(Object obj) {
        if (obj == null) {
            obj = wl1.k;
        }
        return new d81(obj);
    }

    public static up0 d(int i2) {
        float f2;
        if ((i2 & 1) != 0) {
            f2 = 0.0f;
        } else {
            f2 = 14.0f;
        }
        return new up0(f2, 0.0f, f2, 0.0f);
    }

    public static final up0 e(float f2, float f3, float f4, float f5) {
        return new up0(f2, f3, f4, f5);
    }

    public static up0 f(float f2) {
        return new up0(0.0f, 0.0f, 0.0f, f2);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v12 */
    /* JADX WARN: Type inference failed for: r1v13 */
    /* JADX WARN: Type inference failed for: r1v15, types: [android.view.View] */
    public static final View g(o oVar) {
        WeakReference weakReference;
        mj mjVar;
        ?? r1;
        if (oVar.isAttachedToWindow()) {
            int min = Math.min(o(oVar, 2131034229), o(oVar, 2131034232));
            o oVar2 = oVar;
            int i2 = 0;
            o oVar3 = oVar2;
            while (oVar != null) {
                if (i2 == min) {
                    if (!(oVar.getParent() instanceof ViewGroup)) {
                        return oVar2;
                    }
                } else {
                    Object tag = oVar.getTag(2131034154);
                    if (tag instanceof WeakReference) {
                        weakReference = (WeakReference) tag;
                    } else {
                        weakReference = null;
                    }
                    if (weakReference != null) {
                        mjVar = (mj) weakReference.get();
                    } else {
                        mjVar = null;
                    }
                    if (mjVar == null) {
                        i2++;
                        ViewParent j2 = dd0.j(oVar);
                        if (j2 instanceof View) {
                            r1 = (View) j2;
                        } else {
                            r1 = 0;
                        }
                        o oVar4 = oVar2;
                        oVar2 = oVar;
                        oVar = r1;
                        oVar3 = oVar4;
                    }
                }
                return oVar;
            }
            return oVar3;
        }
        return oVar;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:10:0x001f  */
    /* JADX WARN: Removed duplicated region for block: B:18:0x0030  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final Object h(dc1 dc1Var, en enVar, Throwable th, nl nlVar) {
        ww wwVar;
        int i2;
        try {
            if (nlVar instanceof ww) {
                ww wwVar2 = (ww) nlVar;
                int i3 = wwVar2.j;
                if ((i3 & Integer.MIN_VALUE) != 0) {
                    wwVar2.j = i3 - Integer.MIN_VALUE;
                    wwVar = wwVar2;
                    Object obj = wwVar.i;
                    i2 = wwVar.j;
                    if (i2 == 0) {
                        if (i2 == 1) {
                            th = wwVar.h;
                            nb0.t(obj);
                        } else {
                            od.p("call to 'resume' before 'invoke' with coroutine");
                            return null;
                        }
                    } else {
                        nb0.t(obj);
                        wwVar.h = th;
                        wwVar.j = 1;
                        Object c2 = enVar.c(dc1Var, th, wwVar);
                        Object obj2 = cm.e;
                        if (c2 == obj2) {
                            return obj2;
                        }
                    }
                    return we1.a;
                }
            }
            if (i2 == 0) {
            }
            return we1.a;
        } catch (Throwable th2) {
            if (th != null && th != th2) {
                i(th2, th);
            }
            throw th2;
        }
        wwVar = new nl(nlVar);
        Object obj3 = wwVar.i;
        i2 = wwVar.j;
    }

    public static void i(Throwable th, Throwable th2) {
        boolean z2;
        th.getClass();
        th2.getClass();
        if (th != th2) {
            Integer num = x70.a;
            if (num != null && num.intValue() < 19) {
                z2 = false;
            } else {
                z2 = true;
            }
            if (z2) {
                th.addSuppressed(th2);
                return;
            }
            Method method = os0.a;
            if (method != null) {
                method.invoke(th, th2);
            }
        }
    }

    public static final y00 j(y00 y00Var) {
        if (y00Var == null) {
            y00Var = null;
        }
        if (y00Var != null) {
            return y00Var;
        }
        qj.b("Inconsistent composition");
        throw new RuntimeException();
    }

    public static Object k(Class cls, InvocationHandler invocationHandler) {
        if (invocationHandler == null) {
            return null;
        }
        return cls.cast(Proxy.newProxyInstance(ac.class.getClassLoader(), new Class[]{cls}, invocationHandler));
    }

    public static final void l(long j2, bp0 bp0Var) {
        if (bp0Var == bp0.e) {
            if (sk.g(j2) == Integer.MAX_VALUE) {
                s50.c("Vertically scrollable component was measured with an infinity maximum height constraints, which is disallowed. One of the common reasons is nesting layouts like LazyColumn and Column(Modifier.verticalScroll()). If you want to add a header before the list of items please add a header as a separate item() before the main items() inside the LazyColumn scope. There could be other reasons for this to happen: your ComposeView was added into a LinearLayout with some weight, you applied Modifier.wrapContentSize(unbounded = true) or wrote a custom layout. Please try to remove the source of infinite constraints in the hierarchy above the scrolling container.");
            }
        } else if (sk.h(j2) != Integer.MAX_VALUE) {
        } else {
            s50.c("Horizontally scrollable component was measured with an infinity maximum width constraints, which is disallowed. One of the common reasons is nesting layouts like LazyRow and Row(Modifier.horizontalScroll()). If you want to add a header before the list of items please add a header as a separate item() before the main items() inside the LazyRow scope. There could be other reasons for this to happen: your ComposeView was added into a LinearLayout with some weight, you applied Modifier.wrapContentSize(unbounded = true) or wrote a custom layout. Please try to remove the source of infinite constraints in the hierarchy above the scrolling container.");
        }
    }

    public static ml m(ml mlVar, ml mlVar2, m00 m00Var) {
        m00Var.getClass();
        if (m00Var instanceof db) {
            return ((db) m00Var).n(mlVar2, mlVar);
        }
        sl e2 = mlVar2.e();
        if (e2 == st.e) {
            return new l70(mlVar2, mlVar, m00Var);
        }
        return new m70(mlVar2, e2, m00Var, mlVar);
    }

    public static final boolean n(long j2, long j3) {
        if (j2 == j3) {
            return true;
        }
        return false;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r5v0, types: [o] */
    /* JADX WARN: Type inference failed for: r5v1, types: [android.view.View] */
    /* JADX WARN: Type inference failed for: r5v3, types: [android.view.View] */
    /* JADX WARN: Type inference failed for: r5v4 */
    /* JADX WARN: Type inference failed for: r5v5 */
    public static final int o(o oVar, int i2) {
        int i3 = 0;
        int i4 = Integer.MAX_VALUE;
        Object obj = null;
        while (oVar != 0) {
            Object tag = oVar.getTag(i2);
            if (tag != null) {
                if (obj == null) {
                    obj = tag;
                } else if (!tag.equals(obj)) {
                    break;
                }
                i4 = i3;
            }
            i3++;
            ViewParent j2 = dd0.j(oVar);
            if (j2 instanceof View) {
                oVar = (View) j2;
            } else {
                oVar = 0;
            }
        }
        return i4;
    }

    public static final sj0 p(l21 l21Var, i00 i00Var) {
        Trace.beginSection("getAllUncoveredSemanticsNodesToIntObjectMap");
        try {
            i21 a2 = l21Var.a();
            ba0 ba0Var = a2.c;
            if (ba0Var.I() && ba0Var.H()) {
                gw0 g2 = a2.g();
                sj0 sj0Var = new sj0(48);
                cz0 cz0Var = new cz0(1);
                cz0Var.n(zi1.F(g2));
                s(i00Var, sj0Var, new cz0(1), cz0Var, a2, a2);
                return sj0Var;
            }
            sj0 sj0Var2 = m60.a;
            sj0Var2.getClass();
            return sj0Var2;
        } finally {
            Trace.endSection();
        }
    }

    public static final void q(sj0 sj0Var, i21 i21Var, i21 i21Var2) {
        gw0 gw0Var;
        ba0 ba0Var;
        i21 l2 = i21Var2.l();
        if (l2 != null && (ba0Var = l2.c) != null && ba0Var.I()) {
            gw0Var = l2.g();
        } else {
            gw0Var = A;
        }
        int i2 = i21Var2.f;
        if (i2 == i21Var.f) {
            i2 = -1;
        }
        sj0Var.h(i2, new k21(i21Var2, zi1.F(gw0Var)));
    }

    public static final void r(i00 i00Var, sj0 sj0Var, cz0 cz0Var, cz0 cz0Var2, i21 i21Var, i21 i21Var2) {
        gw0 h2;
        cz0 cz0Var3 = cz0Var;
        Region region = (Region) cz0Var3.f;
        cz0 cz0Var4 = cz0Var2;
        Region region2 = (Region) cz0Var4.f;
        ba0 ba0Var = i21Var2.c;
        ba0 ba0Var2 = i21Var2.c;
        if (ba0Var.I() && ba0Var2.H() && !region2.isEmpty()) {
            g21 f2 = i21Var2.f();
            if (f2 == null) {
                v50 v50Var = ba0Var2.J.c;
                h2 = k70.D(v50Var).z(v50Var, false);
            } else {
                h2 = jb0.h(((li0) f2).e, false, false);
            }
            r60 F = zi1.F(h2);
            cz0Var3.n(F);
            if (region.op(region2, Region.Op.INTERSECT)) {
                int i2 = i21Var2.f;
                if (i2 == i21Var.f) {
                    i2 = -1;
                }
                Rect bounds = region.getBounds();
                sj0Var.h(i2, new k21(i21Var2, new r60(bounds.left, bounds.top, bounds.right, bounds.bottom)));
                List j2 = i21.j(4, i21Var2);
                int size = j2.size() - 1;
                while (-1 < size) {
                    if (!((Boolean) i00Var.i(j2.get(size))).booleanValue()) {
                        r(i00Var, sj0Var, cz0Var3, cz0Var4, i21Var, (i21) j2.get(size));
                    }
                    size--;
                    cz0Var3 = cz0Var;
                    cz0Var4 = cz0Var2;
                }
                if (z(i21Var2)) {
                    region2.op(F.a, F.b, F.c, F.d, Region.Op.DIFFERENCE);
                }
            }
        } else if (i21Var2.o()) {
            q(sj0Var, i21Var, i21Var2);
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:40:0x00ae, code lost:
        if (r12 != null) goto L38;
     */
    /* JADX WARN: Removed duplicated region for block: B:102:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:57:0x00e9  */
    /* JADX WARN: Removed duplicated region for block: B:60:0x00ef  */
    /* JADX WARN: Removed duplicated region for block: B:72:0x014f  */
    /* JADX WARN: Removed duplicated region for block: B:82:0x018d  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final void s(i00 i00Var, sj0 sj0Var, cz0 cz0Var, cz0 cz0Var2, i21 i21Var, i21 i21Var2) {
        boolean z2;
        boolean z3;
        gw0 h2;
        gm0 gm0Var;
        boolean z4;
        i00 i00Var2 = i00Var;
        i21 i21Var3 = i21Var;
        int i2 = i21Var3.f;
        Region region = (Region) cz0Var.f;
        cz0 cz0Var3 = cz0Var2;
        Region region2 = (Region) cz0Var3.f;
        ba0 ba0Var = i21Var2.c;
        ba0 ba0Var2 = i21Var2.c;
        int i3 = i21Var2.f;
        if (ba0Var.I() && ba0Var2.H()) {
            z2 = false;
        } else {
            z2 = true;
        }
        if (!region2.isEmpty() || i3 == i2) {
            if (!z2 || i21Var2.o()) {
                r60 F = zi1.F(i21Var2.m());
                cz0Var.n(F);
                if (i3 == i2) {
                    i3 = -1;
                }
                if (region.op(region2, Region.Op.INTERSECT)) {
                    Rect bounds = region.getBounds();
                    sj0Var.h(i3, new k21(i21Var2, new r60(bounds.left, bounds.top, bounds.right, bounds.bottom)));
                    List j2 = i21.j(4, i21Var2);
                    if (i21Var2.d.g) {
                        i21 l2 = i21Var2.l();
                        while (true) {
                            gm0Var = null;
                            gm0Var = null;
                            if (l2 != null) {
                                hk0 hk0Var = l2.d.e;
                                if (hk0Var.c(n21.w) || hk0Var.c(n21.v)) {
                                    break;
                                }
                                l2 = l2.l();
                            } else {
                                l2 = null;
                                break;
                            }
                        }
                        if (l2 != null) {
                            n90 d2 = i21Var2.d();
                            if (d2 != null) {
                                if (!d2.y0().r) {
                                    d2 = null;
                                }
                            }
                            d2 = null;
                            gm0 d3 = l2.d();
                            if (d3 != null) {
                                if (!d3.y0().r) {
                                    d3 = null;
                                }
                                if (d3 != null) {
                                    gm0Var = d3;
                                }
                            }
                            if (d2 != null && gm0Var != null) {
                                gw0 z5 = gm0Var.z(d2, false);
                                z4 = !z5.equals(z5.c(ua0.d(0L, wl1.M(gm0Var.g))));
                                if (z4) {
                                    z3 = true;
                                    if (!z3) {
                                        cz0 cz0Var4 = new cz0(1);
                                        g21 f2 = i21Var2.f();
                                        if (f2 == null) {
                                            v50 v50Var = ba0Var2.J.c;
                                            h2 = k70.D(v50Var).z(v50Var, false);
                                        } else {
                                            h2 = jb0.h(((li0) f2).e, false, false);
                                        }
                                        cz0Var4.n(zi1.F(h2));
                                        int size = j2.size() - 1;
                                        while (-1 < size) {
                                            if (!((Boolean) i00Var2.i(j2.get(size))).booleanValue()) {
                                                r(i00Var2, sj0Var, new cz0(1), cz0Var4, i21Var3, (i21) j2.get(size));
                                            }
                                            size--;
                                            i21Var3 = i21Var;
                                        }
                                    } else {
                                        int size2 = j2.size() - 1;
                                        while (-1 < size2) {
                                            if (!((Boolean) i00Var2.i(j2.get(size2))).booleanValue()) {
                                                s(i00Var2, sj0Var, cz0Var, cz0Var3, i21Var, (i21) j2.get(size2));
                                            }
                                            size2--;
                                            i00Var2 = i00Var;
                                            cz0Var3 = cz0Var2;
                                        }
                                    }
                                    if (!z(i21Var2)) {
                                        region2.op(F.a, F.b, F.c, F.d, Region.Op.DIFFERENCE);
                                        return;
                                    }
                                    return;
                                }
                            }
                        }
                        z4 = false;
                        if (z4) {
                        }
                    }
                    z3 = false;
                    if (!z3) {
                    }
                    if (!z(i21Var2)) {
                    }
                } else if (i21Var2.o()) {
                    q(sj0Var, i21Var3, i21Var2);
                } else if (i3 == -1) {
                    Rect bounds2 = region.getBounds();
                    sj0Var.h(i3, new k21(i21Var2, new r60(bounds2.left, bounds2.top, bounds2.right, bounds2.bottom)));
                }
            }
        }
    }

    public static long t(Context context, int i2) {
        return wl1.d(context.getResources().getColor(i2, context.getTheme()));
    }

    public static ny0 u(Display display, int i2) {
        RoundedCorner g2;
        int i3;
        if (Build.VERSION.SDK_INT < 31 || (g2 = x3.g(display, i2)) == null) {
            return null;
        }
        int c2 = x3.c(g2);
        if (c2 != 0) {
            i3 = 1;
            if (c2 != 1) {
                i3 = 2;
                if (c2 != 2) {
                    i3 = 3;
                    if (c2 != 3) {
                        od.m(fu0.E("Invalid position: ", c2));
                        return null;
                    }
                }
            }
        } else {
            i3 = 0;
        }
        return new ny0(i3, x3.y(g2), x3.d(g2));
    }

    public static final int v(aa aaVar, Object obj, int i2) {
        int i3 = aaVar.g;
        if (i3 == 0) {
            return -1;
        }
        try {
            int r2 = k70.r(aaVar.e, i3, i2);
            if (r2 < 0 || k70.p(obj, aaVar.f[r2])) {
                return r2;
            }
            int i4 = r2 + 1;
            while (i4 < i3 && aaVar.e[i4] == i2) {
                if (k70.p(obj, aaVar.f[i4])) {
                    return i4;
                }
                i4++;
            }
            for (int i5 = r2 - 1; i5 >= 0 && aaVar.e[i5] == i2; i5--) {
                if (k70.p(obj, aaVar.f[i5])) {
                    return i5;
                }
            }
            return ~i4;
        } catch (IndexOutOfBoundsException unused) {
            throw new ConcurrentModificationException();
        }
    }

    public static int w(float f2) {
        float f3;
        boolean z2;
        float f4;
        if (f2 < 1.0f) {
            return -16777216;
        }
        if (f2 > 99.0f) {
            return -1;
        }
        float f5 = (f2 + 16.0f) / 116.0f;
        if (f2 > 8.0f) {
            f3 = f5 * f5 * f5;
        } else {
            f3 = f2 / 903.2963f;
        }
        float f6 = f5 * f5 * f5;
        if (f6 > 0.008856452f) {
            z2 = true;
        } else {
            z2 = false;
        }
        if (z2) {
            f4 = f6;
        } else {
            f4 = ((f5 * 116.0f) - 16.0f) / 903.2963f;
        }
        if (!z2) {
            f6 = ((f5 * 116.0f) - 16.0f) / 903.2963f;
        }
        float[] fArr = g;
        return mh.a(f4 * fArr[0], f3 * fArr[1], f6 * fArr[2]);
    }

    public static ml x(ml mlVar) {
        nl nlVar;
        ml mlVar2;
        mlVar.getClass();
        if (mlVar instanceof nl) {
            nlVar = (nl) mlVar;
        } else {
            nlVar = null;
        }
        if (nlVar != null && (mlVar = nlVar.g) == null) {
            ul ulVar = (ul) nlVar.e().k(e3.B);
            if (ulVar != null) {
                mlVar2 = new gq(ulVar, nlVar);
            } else {
                mlVar2 = nlVar;
            }
            nlVar.g = mlVar2;
            return mlVar2;
        }
        return mlVar;
    }

    public static final boolean y(i21 i21Var) {
        boolean z2;
        gm0 d2 = i21Var.d();
        hk0 hk0Var = i21Var.d.e;
        if (d2 != null) {
            z2 = d2.G0();
        } else {
            z2 = false;
        }
        if (!z2 && !hk0Var.c(n21.q) && !hk0Var.c(n21.p)) {
            return false;
        }
        return true;
    }

    public static final boolean z(i21 i21Var) {
        if (!y(i21Var)) {
            d21 d21Var = i21Var.d;
            if (!d21Var.g) {
                hk0 hk0Var = d21Var.e;
                Object[] objArr = hk0Var.b;
                Object[] objArr2 = hk0Var.c;
                long[] jArr = hk0Var.a;
                int length = jArr.length - 2;
                if (length >= 0) {
                    int i2 = 0;
                    while (true) {
                        long j2 = jArr[i2];
                        if ((((~j2) << 7) & j2 & (-9187201950435737472L)) != -9187201950435737472L) {
                            int i3 = 8 - ((~(i2 - length)) >>> 31);
                            for (int i4 = 0; i4 < i3; i4++) {
                                if ((255 & j2) < 128) {
                                    int i5 = (i2 << 3) + i4;
                                    Object obj = objArr[i5];
                                    Object obj2 = objArr2[i5];
                                    if (((q21) obj).c) {
                                        return true;
                                    }
                                }
                                j2 >>= 8;
                            }
                            if (i3 != 8) {
                                break;
                            }
                        }
                        if (i2 == length) {
                            break;
                        }
                        i2++;
                    }
                }
            } else {
                return true;
            }
        }
        return false;
    }
}