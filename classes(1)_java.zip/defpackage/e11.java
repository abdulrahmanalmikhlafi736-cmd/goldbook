package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: e11  reason: default package */
public final class e11 extends dp implements ak, vm0 {
    public x5 A;
    public q11 B;
    public cp C;
    public y5 D;
    public x5 E;
    public boolean F;
    public r11 u;
    public bp0 v;
    public boolean w;
    public jo x;
    public uj0 y;
    public boolean z;

    @Override // defpackage.li0
    public final boolean e0() {
        return false;
    }

    @Override // defpackage.li0
    public final void h0() {
        x5 x5Var;
        this.F = v0();
        u0();
        if (this.B == null) {
            r11 r11Var = this.u;
            if (this.z) {
                x5Var = this.E;
            } else {
                x5Var = this.A;
            }
            x5 x5Var2 = x5Var;
            q11 q11Var = new q11(x5Var2, this.x, this.y, this.v, r11Var, this.w, this.F);
            r0(q11Var);
            this.B = q11Var;
        }
    }

    @Override // defpackage.li0
    public final void j0() {
        cp cpVar = this.C;
        if (cpVar != null) {
            s0(cpVar);
        }
    }

    @Override // defpackage.li0
    public final void k0() {
        x5 x5Var;
        boolean v0 = v0();
        if (this.F != v0) {
            this.F = v0;
            r11 r11Var = this.u;
            bp0 bp0Var = this.v;
            boolean z = this.z;
            if (z) {
                x5Var = this.E;
            } else {
                x5Var = this.A;
            }
            x5 x5Var2 = x5Var;
            w0(x5Var2, this.x, this.y, bp0Var, r11Var, z, this.w);
        }
    }

    public final void u0() {
        x5 x5Var;
        cp cpVar = this.C;
        if (cpVar == null) {
            if (this.z) {
                sb0.r(this, new x1(14, this));
            }
            if (this.z) {
                x5Var = this.E;
            } else {
                x5Var = this.A;
            }
            if (x5Var != null) {
                dp dpVar = x5Var.i;
                if (!dpVar.e.r) {
                    r0(dpVar);
                    this.C = dpVar;
                }
            }
        } else if (!((li0) cpVar).e.r) {
            r0(cpVar);
        }
    }

    public final boolean v0() {
        o90 o90Var;
        if (this.r) {
            o90Var = k70.O(this).D;
        } else {
            o90Var = o90.e;
        }
        bp0 bp0Var = this.v;
        if (o90Var == o90.f && bp0Var != bp0.e) {
            return false;
        }
        return true;
    }

    public final void w0(x5 x5Var, jo joVar, uj0 uj0Var, bp0 bp0Var, r11 r11Var, boolean z, boolean z2) {
        boolean z3;
        x5 x5Var2;
        this.u = r11Var;
        this.v = bp0Var;
        boolean z4 = true;
        if (this.z != z) {
            this.z = z;
            z3 = true;
        } else {
            z3 = false;
        }
        if (!k70.p(this.A, x5Var)) {
            this.A = x5Var;
        } else {
            z4 = false;
        }
        if (z3 || (z4 && !z)) {
            cp cpVar = this.C;
            if (cpVar != null) {
                s0(cpVar);
            }
            this.C = null;
            u0();
        }
        this.w = z2;
        this.x = joVar;
        this.y = uj0Var;
        boolean v0 = v0();
        this.F = v0;
        q11 q11Var = this.B;
        if (q11Var != null) {
            if (this.z) {
                x5Var2 = this.E;
            } else {
                x5Var2 = this.A;
            }
            q11Var.I0(x5Var2, joVar, uj0Var, bp0Var, r11Var, z2, v0);
        }
    }

    @Override // defpackage.vm0
    public final void z() {
        x5 x5Var;
        y5 y5Var = (y5) j70.z(this, jp0.a);
        if (!k70.p(y5Var, this.D)) {
            this.D = y5Var;
            this.E = null;
            cp cpVar = this.C;
            if (cpVar != null) {
                s0(cpVar);
            }
            this.C = null;
            u0();
            q11 q11Var = this.B;
            if (q11Var != null) {
                r11 r11Var = this.u;
                bp0 bp0Var = this.v;
                if (this.z) {
                    x5Var = this.E;
                } else {
                    x5Var = this.A;
                }
                x5 x5Var2 = x5Var;
                q11Var.I0(x5Var2, this.x, this.y, bp0Var, r11Var, this.w, this.F);
            }
        }
    }
}