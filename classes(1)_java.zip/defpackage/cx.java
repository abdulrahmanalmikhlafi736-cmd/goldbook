package defpackage;

/* renamed from: cx  reason: default package */
public final class cx extends nl {
    public xq h;
    public /* synthetic */ Object i;
    public int j;
    public final /* synthetic */ xq k;
    public Object l;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public cx(xq xqVar, ml mlVar) {
        super(mlVar);
        this.k = xqVar;
    }

    @Override // defpackage.db
    public final Object p(Object obj) {
        this.i = obj;
        this.j |= Integer.MIN_VALUE;
        return this.k.k(null, this);
    }
}