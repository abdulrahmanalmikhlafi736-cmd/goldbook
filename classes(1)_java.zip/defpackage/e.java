package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: e  reason: default package */
public final /* synthetic */ class e extends w00 implements i00 {
    public final /* synthetic */ int l;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ e(int i, Object obj, Class cls, String str, String str2, int i2, int i3, int i4) {
        super(i, obj, cls, str, str2, i2, i3);
        this.l = i4;
    }

    @Override // defpackage.i00
    public final Object i(Object obj) {
        Object[] objArr;
        Object[] objArr2;
        int i;
        int i2 = this.l;
        we1 we1Var = we1.a;
        Object obj2 = this.f;
        switch (i2) {
            case 0:
                boolean booleanValue = ((Boolean) obj).booleanValue();
                dg dgVar = (dg) obj2;
                wj0 wj0Var = dgVar.G;
                if (booleanValue) {
                    dgVar.y0();
                } else {
                    if (dgVar.u != null) {
                        Object[] objArr3 = wj0Var.c;
                        long[] jArr = wj0Var.a;
                        int length = jArr.length - 2;
                        if (length >= 0) {
                            int i3 = 0;
                            while (true) {
                                long j = jArr[i3];
                                if ((((~j) << 7) & j & (-9187201950435737472L)) != -9187201950435737472L) {
                                    int i4 = 8;
                                    int i5 = 8 - ((~(i3 - length)) >>> 31);
                                    int i6 = 0;
                                    while (i6 < i5) {
                                        if ((255 & j) < 128) {
                                            i = i4;
                                            objArr2 = objArr3;
                                            wl1.B(dgVar.d0(), null, new j(dgVar, (ou0) objArr3[(i3 << 3) + i6], null, 0), 3);
                                        } else {
                                            objArr2 = objArr3;
                                            i = i4;
                                        }
                                        j >>= i;
                                        i6++;
                                        i4 = i;
                                        objArr3 = objArr2;
                                    }
                                    objArr = objArr3;
                                    if (i5 != i4) {
                                    }
                                } else {
                                    objArr = objArr3;
                                }
                                if (i3 != length) {
                                    i3++;
                                    objArr3 = objArr;
                                }
                            }
                        }
                        ou0 ou0Var = dgVar.I;
                        if (ou0Var != null) {
                            wl1.B(dgVar.d0(), null, new j(dgVar, ou0Var, null, 1), 3);
                        }
                    }
                    wj0Var.a();
                    dgVar.I = null;
                }
                return we1Var;
            default:
                ((d80) obj2).l((Throwable) obj);
                return we1Var;
        }
    }
}