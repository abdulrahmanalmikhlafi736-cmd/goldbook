package defpackage;

import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Build;
import android.os.Trace;
import android.text.BoringLayout;
import android.text.Layout;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.StaticLayout;
import android.text.TextDirectionHeuristic;
import android.text.TextPaint;
import android.text.TextUtils;
import java.util.NoSuchElementException;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ab1  reason: default package */
public final class ab1 {
    public final TextPaint a;
    public final TextUtils.TruncateAt b;
    public final boolean c;
    public final boolean d;
    public final Layout e;
    public final int f;
    public final int g;
    public final int h;
    public final float i;
    public final float j;
    public final boolean k;
    public final Paint.FontMetricsInt l;
    public final int m;
    public final ie0[] n;
    public final Rect o = new Rect();
    public pa p;

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:105:0x01b8  */
    /* JADX WARN: Removed duplicated region for block: B:106:0x01c1  */
    /* JADX WARN: Removed duplicated region for block: B:122:0x0213  */
    /* JADX WARN: Removed duplicated region for block: B:124:0x021f  */
    /* JADX WARN: Removed duplicated region for block: B:125:0x0221  */
    /* JADX WARN: Removed duplicated region for block: B:127:0x0226  */
    /* JADX WARN: Removed duplicated region for block: B:128:0x0228  */
    /* JADX WARN: Removed duplicated region for block: B:131:0x0231  */
    /* JADX WARN: Removed duplicated region for block: B:144:0x0260  */
    /* JADX WARN: Removed duplicated region for block: B:147:0x028d A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:164:0x031f  */
    /* JADX WARN: Removed duplicated region for block: B:165:0x032e  */
    /* JADX WARN: Removed duplicated region for block: B:61:0x0149  */
    /* JADX WARN: Removed duplicated region for block: B:76:0x0165  */
    /* JADX WARN: Removed duplicated region for block: B:88:0x017b A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:92:0x018f  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public ab1(CharSequence charSequence, float f, TextPaint textPaint, int i, TextUtils.TruncateAt truncateAt, int i2, boolean z, int i3, int i4, int i5, int i6, int i7, int i8, r90 r90Var) {
        Layout.Alignment alignment;
        int i9;
        TextDirectionHeuristic textDirectionHeuristic;
        Layout layout;
        ie0[] ie0VarArr;
        int i10;
        int i11;
        int i12;
        int i13;
        char c;
        long j;
        int i14;
        int i15;
        long a;
        int i16;
        boolean isFallbackLineSpacingEnabled;
        boolean isFallbackLineSpacingEnabled2;
        long j2;
        int i17;
        Layout layout2;
        int i18;
        Paint.FontMetricsInt fontMetricsInt;
        int i19;
        Layout boringLayout;
        this.a = textPaint;
        this.b = truncateAt;
        this.c = z;
        int length = charSequence.length();
        TextDirectionHeuristic b = db1.b(i2);
        Layout.Alignment alignment2 = oa1.a;
        if (i == 0) {
            alignment = Layout.Alignment.ALIGN_NORMAL;
        } else if (i == 1) {
            alignment = Layout.Alignment.ALIGN_OPPOSITE;
        } else if (i == 2) {
            alignment = Layout.Alignment.ALIGN_CENTER;
        } else if (i == 3) {
            alignment = oa1.a;
        } else if (i != 4) {
            alignment = Layout.Alignment.ALIGN_NORMAL;
        } else {
            alignment = oa1.b;
        }
        boolean z2 = (charSequence instanceof Spanned) && ((Spanned) charSequence).nextSpanTransition(-1, length, gb.class) < length;
        Trace.beginSection("TextLayout:initLayout");
        try {
            BoringLayout.Metrics a2 = r90Var.a();
            double d = f;
            int ceil = (int) Math.ceil(d);
            if (a2 != null && r90Var.c() <= f && !z2) {
                this.k = true;
                if (ceil < 0) {
                    q50.a("negative width");
                }
                if (ceil < 0) {
                    q50.a("negative ellipsized width");
                }
                if (Build.VERSION.SDK_INT >= 33) {
                    boringLayout = e1.e(charSequence, textPaint, ceil, alignment, a2, z, truncateAt, ceil);
                } else {
                    boringLayout = new BoringLayout(charSequence, textPaint, ceil, alignment, 1.0f, 0.0f, a2, z, truncateAt, ceil);
                }
                i9 = i3;
                textDirectionHeuristic = b;
                layout = boringLayout;
            } else {
                this.k = false;
                i9 = i3;
                textDirectionHeuristic = b;
                layout = sb0.j(charSequence, textPaint, ceil, charSequence.length(), textDirectionHeuristic, alignment, i9, truncateAt, (int) Math.ceil(d), i8, z, i4, i5, i6, i7);
            }
            this.e = layout;
            Trace.endSection();
            int min = Math.min(layout.getLineCount(), i9);
            this.f = min;
            int i20 = min - 1;
            this.d = min >= i9 && (layout.getEllipsisCount(i20) > 0 || layout.getLineEnd(i20) != charSequence.length());
            if (layout.getText() instanceof Spanned) {
                CharSequence text = layout.getText();
                text.getClass();
                if (kb0.q((Spanned) text, ie0.class) || layout.getText().length() <= 0) {
                    CharSequence text2 = layout.getText();
                    text2.getClass();
                    i10 = 0;
                    ie0VarArr = (ie0[]) ((Spanned) text2).getSpans(0, layout.getText().length(), ie0.class);
                    this.n = ie0VarArr;
                    if (ie0VarArr != null) {
                        ie0 ie0Var = ie0VarArr.length == 0 ? null : ie0VarArr[i10];
                        if (ie0Var != null) {
                            if (ie0Var.g) {
                                i11 = 2;
                                if (ie0Var.j == 2) {
                                    i19 = 1;
                                    i12 = i19;
                                    if (ie0VarArr != null) {
                                        ie0 ie0Var2 = ie0VarArr.length == 0 ? null : ie0VarArr[i10];
                                        if (ie0Var2 != null && ie0Var2.h && ie0Var2.j == i11) {
                                            i13 = 1;
                                            if (i12 == 0 && i13 != 0) {
                                                a = db1.b;
                                                c = ' ';
                                                j = 4294967295L;
                                                i14 = 1;
                                                i15 = 33;
                                            } else {
                                                long j3 = db1.b;
                                                if (z) {
                                                    c = ' ';
                                                    j = 4294967295L;
                                                    i14 = 1;
                                                    i15 = 33;
                                                } else if (this.k) {
                                                    BoringLayout boringLayout2 = (BoringLayout) layout;
                                                    i15 = 33;
                                                    if (Build.VERSION.SDK_INT >= 33) {
                                                        isFallbackLineSpacingEnabled2 = boringLayout2.isFallbackLineSpacingEnabled();
                                                        i16 = isFallbackLineSpacingEnabled2;
                                                        if (i16 != 0) {
                                                            c = ' ';
                                                            j = 4294967295L;
                                                            i14 = 1;
                                                        } else {
                                                            TextPaint paint = layout.getPaint();
                                                            CharSequence text3 = layout.getText();
                                                            c = ' ';
                                                            Rect n = sb0.n(paint, text3, layout.getLineStart(i10), layout.getLineEnd(i10));
                                                            int lineAscent = layout.getLineAscent(i10);
                                                            j = 4294967295L;
                                                            int i21 = n.top;
                                                            int topPadding = i21 < lineAscent ? lineAscent - i21 : layout.getTopPadding();
                                                            i14 = 1;
                                                            n = min != 1 ? sb0.n(paint, text3, layout.getLineStart(i20), layout.getLineEnd(i20)) : n;
                                                            int lineDescent = layout.getLineDescent(i20);
                                                            int i22 = n.bottom;
                                                            int bottomPadding = i22 > lineDescent ? i22 - lineDescent : layout.getBottomPadding();
                                                            if (topPadding != 0 || bottomPadding != 0) {
                                                                j3 = db1.a(topPadding, bottomPadding);
                                                            }
                                                        }
                                                    }
                                                    i16 = i10;
                                                    if (i16 != 0) {
                                                    }
                                                } else {
                                                    i15 = 33;
                                                    StaticLayout staticLayout = (StaticLayout) layout;
                                                    int i23 = Build.VERSION.SDK_INT;
                                                    if (i23 >= 33) {
                                                        isFallbackLineSpacingEnabled = staticLayout.isFallbackLineSpacingEnabled();
                                                        i16 = isFallbackLineSpacingEnabled;
                                                    } else {
                                                        if (i23 >= 28) {
                                                            i16 = 1;
                                                        }
                                                        i16 = i10;
                                                    }
                                                    if (i16 != 0) {
                                                    }
                                                }
                                                a = db1.a(i12 != 0 ? i10 : (int) (j3 >> c), i13 != 0 ? i10 : (int) (j3 & j));
                                            }
                                            if (ie0VarArr != null) {
                                                int length2 = ie0VarArr.length;
                                                int i24 = i10;
                                                int i25 = i24;
                                                for (int i26 = i25; i26 < length2; i26++) {
                                                    ie0 ie0Var3 = ie0VarArr[i26];
                                                    int i27 = ie0Var3.o;
                                                    i24 = i27 < 0 ? Math.max(i24, Math.abs(i27)) : i24;
                                                    int i28 = ie0Var3.p;
                                                    if (i28 < 0) {
                                                        i25 = Math.max(i24, Math.abs(i28));
                                                    }
                                                }
                                                if (i24 == 0 && i25 == 0) {
                                                    j2 = db1.b;
                                                } else {
                                                    j2 = db1.a(i24, i25);
                                                }
                                            } else {
                                                j2 = db1.b;
                                            }
                                            this.g = Math.max((int) (a >> c), (int) (j2 >> c));
                                            this.h = Math.max((int) (a & j), (int) (j2 & j));
                                            TextPaint textPaint2 = this.a;
                                            ie0[] ie0VarArr2 = this.n;
                                            i17 = this.f - i14;
                                            layout2 = this.e;
                                            if (layout2.getLineStart(i17) == layout2.getLineEnd(i17) || ie0VarArr2 == null || ie0VarArr2.length == 0) {
                                                i18 = i10;
                                                fontMetricsInt = null;
                                            } else {
                                                SpannableString spannableString = new SpannableString("\u200b");
                                                if (ie0VarArr2.length != 0) {
                                                    ie0 ie0Var4 = ie0VarArr2[i10];
                                                    spannableString.setSpan(new ie0(ie0Var4.e, spannableString.length(), (i17 == 0 || !ie0Var4.h) ? ie0Var4.h : i10, ie0Var4.h, ie0Var4.i, ie0Var4.j), i10, spannableString.length(), i15);
                                                    i18 = i10;
                                                    StaticLayout j4 = sb0.j(spannableString, textPaint2, Integer.MAX_VALUE, spannableString.length(), textDirectionHeuristic, m90.a, Integer.MAX_VALUE, null, Integer.MAX_VALUE, 0, this.c, 0, 0, 0, 0);
                                                    fontMetricsInt = new Paint.FontMetricsInt();
                                                    fontMetricsInt.ascent = j4.getLineAscent(i18);
                                                    fontMetricsInt.descent = j4.getLineDescent(i18);
                                                    fontMetricsInt.top = j4.getLineTop(i18);
                                                    fontMetricsInt.bottom = j4.getLineBottom(i18);
                                                } else {
                                                    throw new NoSuchElementException("Array is empty.");
                                                }
                                            }
                                            this.m = fontMetricsInt != null ? fontMetricsInt.bottom - ((int) (d(i20) - f(i20))) : i18;
                                            this.l = fontMetricsInt;
                                            Layout layout3 = this.e;
                                            this.i = vn.w(layout3, i20, layout3.getPaint());
                                            Layout layout4 = this.e;
                                            this.j = vn.x(layout4, i20, layout4.getPaint());
                                        }
                                    }
                                    i13 = i10;
                                    if (i12 == 0) {
                                    }
                                    long j32 = db1.b;
                                    if (z) {
                                    }
                                    a = db1.a(i12 != 0 ? i10 : (int) (j32 >> c), i13 != 0 ? i10 : (int) (j32 & j));
                                    if (ie0VarArr != null) {
                                    }
                                    this.g = Math.max((int) (a >> c), (int) (j2 >> c));
                                    this.h = Math.max((int) (a & j), (int) (j2 & j));
                                    TextPaint textPaint22 = this.a;
                                    ie0[] ie0VarArr22 = this.n;
                                    i17 = this.f - i14;
                                    layout2 = this.e;
                                    if (layout2.getLineStart(i17) == layout2.getLineEnd(i17)) {
                                    }
                                    i18 = i10;
                                    fontMetricsInt = null;
                                    this.m = fontMetricsInt != null ? fontMetricsInt.bottom - ((int) (d(i20) - f(i20))) : i18;
                                    this.l = fontMetricsInt;
                                    Layout layout32 = this.e;
                                    this.i = vn.w(layout32, i20, layout32.getPaint());
                                    Layout layout42 = this.e;
                                    this.j = vn.x(layout42, i20, layout42.getPaint());
                                }
                            } else {
                                i11 = 2;
                            }
                            i19 = i10;
                            i12 = i19;
                            if (ie0VarArr != null) {
                            }
                            i13 = i10;
                            if (i12 == 0) {
                            }
                            long j322 = db1.b;
                            if (z) {
                            }
                            a = db1.a(i12 != 0 ? i10 : (int) (j322 >> c), i13 != 0 ? i10 : (int) (j322 & j));
                            if (ie0VarArr != null) {
                            }
                            this.g = Math.max((int) (a >> c), (int) (j2 >> c));
                            this.h = Math.max((int) (a & j), (int) (j2 & j));
                            TextPaint textPaint222 = this.a;
                            ie0[] ie0VarArr222 = this.n;
                            i17 = this.f - i14;
                            layout2 = this.e;
                            if (layout2.getLineStart(i17) == layout2.getLineEnd(i17)) {
                            }
                            i18 = i10;
                            fontMetricsInt = null;
                            this.m = fontMetricsInt != null ? fontMetricsInt.bottom - ((int) (d(i20) - f(i20))) : i18;
                            this.l = fontMetricsInt;
                            Layout layout322 = this.e;
                            this.i = vn.w(layout322, i20, layout322.getPaint());
                            Layout layout422 = this.e;
                            this.j = vn.x(layout422, i20, layout422.getPaint());
                        }
                    }
                    i11 = 2;
                    i12 = i10;
                    if (ie0VarArr != null) {
                    }
                    i13 = i10;
                    if (i12 == 0) {
                    }
                    long j3222 = db1.b;
                    if (z) {
                    }
                    a = db1.a(i12 != 0 ? i10 : (int) (j3222 >> c), i13 != 0 ? i10 : (int) (j3222 & j));
                    if (ie0VarArr != null) {
                    }
                    this.g = Math.max((int) (a >> c), (int) (j2 >> c));
                    this.h = Math.max((int) (a & j), (int) (j2 & j));
                    TextPaint textPaint2222 = this.a;
                    ie0[] ie0VarArr2222 = this.n;
                    i17 = this.f - i14;
                    layout2 = this.e;
                    if (layout2.getLineStart(i17) == layout2.getLineEnd(i17)) {
                    }
                    i18 = i10;
                    fontMetricsInt = null;
                    this.m = fontMetricsInt != null ? fontMetricsInt.bottom - ((int) (d(i20) - f(i20))) : i18;
                    this.l = fontMetricsInt;
                    Layout layout3222 = this.e;
                    this.i = vn.w(layout3222, i20, layout3222.getPaint());
                    Layout layout4222 = this.e;
                    this.j = vn.x(layout4222, i20, layout4222.getPaint());
                }
            }
            ie0VarArr = null;
            i10 = 0;
            this.n = ie0VarArr;
            if (ie0VarArr != null) {
            }
            i11 = 2;
            i12 = i10;
            if (ie0VarArr != null) {
            }
            i13 = i10;
            if (i12 == 0) {
            }
            long j32222 = db1.b;
            if (z) {
            }
            a = db1.a(i12 != 0 ? i10 : (int) (j32222 >> c), i13 != 0 ? i10 : (int) (j32222 & j));
            if (ie0VarArr != null) {
            }
            this.g = Math.max((int) (a >> c), (int) (j2 >> c));
            this.h = Math.max((int) (a & j), (int) (j2 & j));
            TextPaint textPaint22222 = this.a;
            ie0[] ie0VarArr22222 = this.n;
            i17 = this.f - i14;
            layout2 = this.e;
            if (layout2.getLineStart(i17) == layout2.getLineEnd(i17)) {
            }
            i18 = i10;
            fontMetricsInt = null;
            this.m = fontMetricsInt != null ? fontMetricsInt.bottom - ((int) (d(i20) - f(i20))) : i18;
            this.l = fontMetricsInt;
            Layout layout32222 = this.e;
            this.i = vn.w(layout32222, i20, layout32222.getPaint());
            Layout layout42222 = this.e;
            this.j = vn.x(layout42222, i20, layout42222.getPaint());
        } catch (Throwable th) {
            Trace.endSection();
            throw th;
        }
    }

    public final int a() {
        int height;
        boolean z = this.d;
        Layout layout = this.e;
        if (z) {
            height = layout.getLineBottom(this.f - 1);
        } else {
            height = layout.getHeight();
        }
        return height + this.g + this.h + this.m;
    }

    public final pa b() {
        pa paVar = this.p;
        if (paVar == null) {
            pa paVar2 = new pa(this.e);
            this.p = paVar2;
            return paVar2;
        }
        return paVar;
    }

    public final float c(int i) {
        float lineBaseline;
        Paint.FontMetricsInt fontMetricsInt;
        float f = this.g;
        if (i == this.f - 1 && (fontMetricsInt = this.l) != null) {
            lineBaseline = f(i) - fontMetricsInt.ascent;
        } else {
            lineBaseline = this.e.getLineBaseline(i);
        }
        return f + lineBaseline;
    }

    public final float d(int i) {
        int i2;
        Paint.FontMetricsInt fontMetricsInt;
        int i3 = this.f;
        int i4 = i3 - 1;
        Layout layout = this.e;
        if (i == i4 && (fontMetricsInt = this.l) != null) {
            return layout.getLineBottom(i - 1) + fontMetricsInt.bottom;
        }
        float lineBottom = this.g + layout.getLineBottom(i);
        if (i == i3 - 1) {
            i2 = this.h;
        } else {
            i2 = 0;
        }
        return lineBottom + i2;
    }

    public final int e(int i) {
        ThreadLocal threadLocal = db1.a;
        Layout layout = this.e;
        if (layout.getEllipsisCount(i) > 0 && this.b == TextUtils.TruncateAt.END) {
            return layout.getText().length();
        }
        return layout.getLineEnd(i);
    }

    public final float f(int i) {
        int i2;
        float lineTop = this.e.getLineTop(i);
        if (i == 0) {
            i2 = 0;
        } else {
            i2 = this.g;
        }
        return lineTop + i2;
    }

    public final float g(int i, boolean z) {
        float f;
        float h = b().h(i, true, z);
        if (this.e.getLineForOffset(i) == this.f - 1) {
            f = this.i + this.j;
        } else {
            f = 0.0f;
        }
        return f + h;
    }

    public final float h(int i, boolean z) {
        float f;
        float h = b().h(i, false, z);
        if (this.e.getLineForOffset(i) == this.f - 1) {
            f = this.i + this.j;
        } else {
            f = 0.0f;
        }
        return f + h;
    }
}