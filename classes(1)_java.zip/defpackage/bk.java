package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bk  reason: default package */
public final class bk {
    public static final /* synthetic */ bk a = new Object();
    public static final qr0 b = qr0.h;
}