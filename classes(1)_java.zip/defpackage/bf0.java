package defpackage;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bf0  reason: default package */
public abstract class bf0 {
    public static final lv0 a;

    /* JADX WARN: Code restructure failed: missing block: B:11:0x002b, code lost:
        r1 = r1.invoke(null, null);
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0031, code lost:
        if ((r1 instanceof defpackage.lv0) == false) goto L9;
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x0033, code lost:
        r1 = (defpackage.lv0) r1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0024, code lost:
        r1 = null;
     */
    static {
        Object px0Var;
        Object obj = null;
        try {
            ClassLoader classLoader = sd0.class.getClassLoader();
            classLoader.getClass();
            Method method = classLoader.loadClass("androidx.compose.ui.platform.AndroidCompositionLocals_androidKt").getMethod("getLocalLifecycleOwner", null);
            Annotation[] annotations = method.getAnnotations();
            int length = annotations.length;
            int i = 0;
            while (true) {
                if (i >= length) {
                    break;
                } else if (annotations[i] instanceof op) {
                    break;
                } else {
                    i++;
                }
            }
        } catch (Throwable th) {
            px0Var = new px0(th);
        }
        if (!(px0Var instanceof px0)) {
            obj = px0Var;
        }
        lv0 lv0Var = (lv0) obj;
        if (lv0Var == null) {
            lv0Var = new lv0(new i2(19));
        }
        a = lv0Var;
    }
}