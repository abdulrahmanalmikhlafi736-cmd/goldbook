package defpackage;

import java.io.FileNotFoundException;
import java.io.IOException;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bq  reason: default package */
public final class bq extends IOException {
    public final String e;

    public bq(FileNotFoundException fileNotFoundException) {
        super(fileNotFoundException);
        this.e = "Encountered a [" + fileNotFoundException.getMessage() + "]. If you are trying to use DataStore during direct boot, this exception likely indicates that your DataStore file is not located in the Device Encrypted Storage and therefore is not available for write access during direct boot mode. DataStore to be used during direct boot must be initialized using `DataStoreFactory.createInDeviceProtectedStorage()`.";
    }

    @Override // java.lang.Throwable
    public final String getMessage() {
        return this.e;
    }
}