package defpackage;

import android.graphics.Canvas;
import android.graphics.Outline;
import android.view.View;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dh1  reason: default package */
public final class dh1 extends View {
    public static final zp o = new zp(1);
    public final cs e;
    public final ue f;
    public final te g;
    public boolean h;
    public Outline i;
    public boolean j;
    public jp k;
    public o90 l;
    public i00 m;
    public i20 n;

    public dh1(cs csVar, ue ueVar, te teVar) {
        super(csVar.getContext());
        this.e = csVar;
        this.f = ueVar;
        this.g = teVar;
        setOutlineProvider(o);
        this.j = true;
        this.k = ac.l;
        this.l = o90.e;
        k20.a.getClass();
        this.m = i4.E;
        setWillNotDraw(false);
        setClipBounds(null);
    }

    @Override // android.view.View
    public final void dispatchDraw(Canvas canvas) {
        ue ueVar = this.f;
        t3 t3Var = ueVar.a;
        Canvas canvas2 = t3Var.a;
        t3Var.a = canvas;
        jp jpVar = this.k;
        o90 o90Var = this.l;
        long floatToRawIntBits = (Float.floatToRawIntBits(getHeight()) & 4294967295L) | (Float.floatToRawIntBits(getWidth()) << 32);
        i20 i20Var = this.n;
        i00 i00Var = this.m;
        te teVar = this.g;
        k9 k9Var = teVar.f;
        se seVar = ((te) k9Var.h).e;
        jp jpVar2 = seVar.a;
        o90 o90Var2 = seVar.b;
        re q = k9Var.q();
        k9 k9Var2 = teVar.f;
        long t = k9Var2.t();
        i20 i20Var2 = (i20) k9Var2.g;
        k9Var2.C(jpVar);
        k9Var2.D(o90Var);
        k9Var2.B(t3Var);
        k9Var2.E(floatToRawIntBits);
        k9Var2.g = i20Var;
        t3Var.i();
        try {
            i00Var.i(teVar);
            t3Var.g();
            k9Var2.C(jpVar2);
            k9Var2.D(o90Var2);
            k9Var2.B(q);
            k9Var2.E(t);
            k9Var2.g = i20Var2;
            ueVar.a.a = canvas2;
            this.h = false;
        } catch (Throwable th) {
            t3Var.g();
            k9Var2.C(jpVar2);
            k9Var2.D(o90Var2);
            k9Var2.B(q);
            k9Var2.E(t);
            k9Var2.g = i20Var2;
            throw th;
        }
    }

    @Override // android.view.View
    public final void forceLayout() {
    }

    public final boolean getCanUseCompositingLayer$ui_graphics() {
        return this.j;
    }

    public final ue getCanvasHolder() {
        return this.f;
    }

    public final View getOwnerView() {
        return this.e;
    }

    @Override // android.view.View
    public final boolean hasOverlappingRendering() {
        return this.j;
    }

    @Override // android.view.View
    public final void invalidate() {
        if (!this.h) {
            this.h = true;
            super.invalidate();
        }
    }

    @Override // android.view.View
    public final void onLayout(boolean z, int i, int i2, int i3, int i4) {
    }

    public final void setCanUseCompositingLayer$ui_graphics(boolean z) {
        if (this.j != z) {
            this.j = z;
            invalidate();
        }
    }

    public final void setInvalidated(boolean z) {
        this.h = z;
    }
}