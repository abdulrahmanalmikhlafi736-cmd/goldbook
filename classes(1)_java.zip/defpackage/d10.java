package defpackage;

import android.os.Trace;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: d10  reason: default package */
public final class d10 {
    public int A;
    public int B;
    public boolean C;
    public final c10 D;
    public final ArrayList E;
    public boolean F;
    public w51 G;
    public x51 H;
    public a61 I;
    public boolean J;
    public qr0 K;
    public ve L;
    public final pj M;
    public y00 N;
    public bw O;
    public l51 P;
    public final wj Q;
    public final sl R;
    public boolean S;
    public long T;
    public e10 U;
    public final k9 a;
    public final sj b;
    public final x51 c;
    public final kk0 d;
    public final ve e;
    public final ve f;
    public final pg0 g;
    public final yj h;
    public g10 j;
    public int k;
    public int l;
    public int m;
    public int[] o;
    public qj0 p;
    public boolean q;
    public boolean r;
    public sj0 v;
    public boolean w;
    public boolean y;
    public final ArrayList i = new ArrayList();
    public final w60 n = new w60();
    public final ArrayList s = new ArrayList();
    public final w60 t = new w60();
    public qr0 u = qr0.h;
    public final w60 x = new w60();
    public int z = -1;

    public d10(k9 k9Var, sj sjVar, x51 x51Var, kk0 kk0Var, ve veVar, ve veVar2, pg0 pg0Var, yj yjVar) {
        boolean z;
        this.a = k9Var;
        this.b = sjVar;
        this.c = x51Var;
        this.d = kk0Var;
        this.e = veVar;
        this.f = veVar2;
        this.g = pg0Var;
        this.h = yjVar;
        if (!sjVar.f() && !sjVar.d()) {
            z = false;
        } else {
            z = true;
        }
        this.C = z;
        this.D = new c10(0, this);
        this.E = new ArrayList();
        w51 c = x51Var.c();
        c.c();
        this.G = c;
        x51 x51Var2 = new x51();
        if (sjVar.f()) {
            x51Var2.b();
        }
        if (sjVar.d()) {
            x51Var2.o = new sj0();
        }
        this.H = x51Var2;
        a61 e = x51Var2.e();
        e.e(true);
        this.I = e;
        this.M = new pj(this, veVar);
        w51 c2 = this.H.c();
        try {
            y00 a = c2.a(0);
            c2.c();
            this.N = a;
            this.O = new bw();
            this.Q = new wj(this);
            sl j = sjVar.j();
            sl z2 = z();
            this.R = j.i(z2 == null ? st.e : z2);
        } catch (Throwable th) {
            c2.c();
            throw th;
        }
    }

    public static final int N(d10 d10Var, int i, boolean z, int i2) {
        int i3;
        boolean z2;
        int i4;
        xw0 xw0Var;
        Object obj;
        long[] jArr;
        int i5;
        long[] jArr2;
        int i6;
        int i7;
        w51 w51Var;
        w51 w51Var2 = d10Var.G;
        int i8 = 0;
        if (w51Var2.j(i)) {
            int i9 = w51Var2.i(i);
            Object p = w51Var2.p(w51Var2.b, i);
            if (i9 == 206 && k70.p(p, qj.e)) {
                Object h = w51Var2.h(i, 0);
                a10 a10Var = null;
                if (h instanceof xw0) {
                    xw0Var = (xw0) h;
                } else {
                    xw0Var = null;
                }
                if (xw0Var != null) {
                    obj = xw0Var.a;
                } else {
                    obj = null;
                }
                if (obj instanceof a10) {
                    a10Var = (a10) obj;
                }
                if (a10Var != null) {
                    ik0 ik0Var = a10Var.e.e;
                    Object[] objArr = ik0Var.b;
                    long[] jArr3 = ik0Var.a;
                    int length = jArr3.length - 2;
                    if (length >= 0) {
                        int i10 = 0;
                        while (true) {
                            long j = jArr3[i10];
                            if ((((~j) << 7) & j & (-9187201950435737472L)) != -9187201950435737472L) {
                                int i11 = 8;
                                int i12 = 8 - ((~(i10 - length)) >>> 31);
                                int i13 = i8;
                                while (i13 < i12) {
                                    if ((255 & j) < 128) {
                                        d10 d10Var2 = (d10) objArr[(i10 << 3) + i13];
                                        x51 x51Var = d10Var2.c;
                                        if (x51Var.f > 0 && (x51Var.e[1] & 67108864) != 0) {
                                            yj yjVar = d10Var2.h;
                                            synchronized (yjVar.h) {
                                                yjVar.p();
                                                i7 = i11;
                                                hk0 hk0Var = yjVar.r;
                                                yjVar.r = mc0.h();
                                                yjVar.z.c0(hk0Var);
                                            }
                                            ve veVar = new ve();
                                            d10Var2.L = veVar;
                                            w51 c = d10Var2.c.c();
                                            try {
                                                d10Var2.G = c;
                                                pj pjVar = d10Var2.M;
                                                ve veVar2 = pjVar.b;
                                                try {
                                                    pjVar.b = veVar;
                                                    d10Var2.M(0);
                                                    pj pjVar2 = d10Var2.M;
                                                    pjVar2.b();
                                                    jArr2 = jArr3;
                                                    try {
                                                        if (pjVar2.c) {
                                                            w51Var = c;
                                                            try {
                                                                pjVar2.b.F.C(qo0.c);
                                                                if (pjVar2.c) {
                                                                    pjVar2.d(false);
                                                                    pjVar2.d(false);
                                                                    pjVar2.b.F.C(ao0.c);
                                                                    i6 = 0;
                                                                    pjVar2.c = false;
                                                                    pjVar.b = veVar2;
                                                                    w51Var.c();
                                                                }
                                                            } catch (Throwable th) {
                                                                th = th;
                                                                pjVar.b = veVar2;
                                                                throw th;
                                                            }
                                                        } else {
                                                            w51Var = c;
                                                        }
                                                        pjVar.b = veVar2;
                                                        w51Var.c();
                                                    } catch (Throwable th2) {
                                                        th = th2;
                                                        w51Var.c();
                                                        throw th;
                                                    }
                                                    i6 = 0;
                                                } catch (Throwable th3) {
                                                    th = th3;
                                                    w51Var = c;
                                                }
                                            } catch (Throwable th4) {
                                                th = th4;
                                                w51Var = c;
                                            }
                                        } else {
                                            jArr2 = jArr3;
                                            i6 = i8;
                                            i7 = i11;
                                        }
                                        d10Var.b.r(d10Var2.h);
                                    } else {
                                        jArr2 = jArr3;
                                        i6 = i8;
                                        i7 = i11;
                                    }
                                    j >>= i7;
                                    i13++;
                                    i11 = i7;
                                    i8 = i6;
                                    jArr3 = jArr2;
                                }
                                jArr = jArr3;
                                i5 = i8;
                                if (i12 != i11) {
                                    break;
                                }
                            } else {
                                jArr = jArr3;
                                i5 = i8;
                            }
                            if (i10 == length) {
                                break;
                            }
                            i10++;
                            i8 = i5;
                            jArr3 = jArr;
                        }
                    }
                }
                return w51Var2.o(i);
            }
            i3 = 1;
            if (!w51Var2.l(i)) {
                return w51Var2.o(i);
            }
        } else {
            i3 = 1;
            if (w51Var2.d(i)) {
                int i14 = w51Var2.b[(i * 5) + 3] + i;
                int i15 = 0;
                for (int i16 = i + 1; i16 < i14; i16 += w51Var2.b[(i16 * 5) + 3]) {
                    boolean l = w51Var2.l(i16);
                    if (l) {
                        d10Var.M.c();
                        pj pjVar3 = d10Var.M;
                        Object n = w51Var2.n(i16);
                        pjVar3.c();
                        pjVar3.h.add(n);
                    }
                    if (!l && !z) {
                        z2 = false;
                    } else {
                        z2 = true;
                    }
                    if (l) {
                        i4 = 0;
                    } else {
                        i4 = i2 + i15;
                    }
                    i15 += N(d10Var, i16, z2, i4);
                    if (l) {
                        d10Var.M.c();
                        d10Var.M.a();
                    }
                }
                if (!w51Var2.l(i)) {
                    return i15;
                }
            } else if (!w51Var2.l(i)) {
                return w51Var2.o(i);
            }
        }
        return i3;
    }

    public final boolean A() {
        xv0 x;
        if (!this.S && !this.y && !this.w && (x = x()) != null && (x.b & 8) == 0) {
            return true;
        }
        return false;
    }

    public final void B(ArrayList arrayList) {
        d10 d10Var = this;
        ve veVar = d10Var.f;
        pj pjVar = d10Var.M;
        ve veVar2 = pjVar.b;
        try {
            pjVar.b = veVar;
            veVar.F.C(oo0.c);
            int size = arrayList.size();
            int i = 0;
            while (i < size) {
                zp0 zp0Var = (zp0) arrayList.get(i);
                gj0 gj0Var = (gj0) zp0Var.e;
                gj0 gj0Var2 = (gj0) zp0Var.f;
                gj0Var.getClass();
                y00 j = ac.j(null);
                x51 d = z51.d(null);
                int a = d.a(j);
                s60 s60Var = new s60();
                pjVar.b();
                zo0 zo0Var = pjVar.b.F;
                zo0Var.C(xn0.c);
                dd0.w(zo0Var, 0, s60Var, 1, j);
                if (d == d10Var.H) {
                    if (!d10Var.I.w) {
                        qj.a("Check failed");
                    }
                    d10Var.v();
                }
                w51 c = d.c();
                c.r(a);
                pjVar.f = a;
                ve veVar3 = new ve();
                d10Var.G(null, null, null, ut.e, new na(d10Var, veVar3, c, gj0Var));
                ve veVar4 = pjVar.b;
                veVar4.getClass();
                if (!veVar3.F.B()) {
                    zo0 zo0Var2 = veVar4.F;
                    zo0Var2.C(tn0.c);
                    dd0.w(zo0Var2, 0, veVar3, 1, s60Var);
                }
                c.c();
                pjVar.b.F.C(qo0.c);
                i++;
                d10Var = this;
            }
            pjVar.b();
            pjVar.b.F.C(bo0.c);
            pjVar.f = 0;
            pjVar.b = veVar2;
        } catch (Throwable th) {
            pjVar.b = veVar2;
            throw th;
        }
    }

    public final void C(qr0 qr0Var, Object obj) {
        boolean z;
        S(126665345, 0, null, null);
        D();
        h0(obj);
        long j = this.T;
        try {
            this.T = 126665345L;
            if (this.S) {
                a61.z(this.I);
            }
            if (this.S || k70.p(this.G.f(), qr0Var)) {
                z = false;
            } else {
                z = true;
            }
            if (z) {
                J(qr0Var);
            }
            S(202, 0, qj.c, qr0Var);
            this.K = null;
            boolean z2 = this.w;
            this.w = z;
            vn.D(this, new pi(-59194059, true, new hc(3, obj)));
            this.w = z2;
        } finally {
        }
    }

    public final Object D() {
        boolean z = this.S;
        nq0 nq0Var = oj.a;
        if (z) {
            if (this.r) {
                qj.a("A call to createNode(), emitNode() or useNode() expected");
                return nq0Var;
            }
        } else {
            Object m = this.G.m();
            if (!this.y || (m instanceof tx0)) {
                return m;
            }
        }
        return nq0Var;
    }

    public final List E() {
        yj yjVar;
        sj sjVar = this.b;
        rj h = sjVar.h();
        if (fu0.M(h)) {
            yjVar = (yj) h;
        } else {
            yjVar = null;
        }
        if (yjVar != null) {
            x51 x51Var = yjVar.j;
            w51 c = z51.d(x51Var).c();
            try {
                Integer w = wl1.w(c, sjVar, 0, c.c);
                if (w != null) {
                    c = z51.d(x51Var).c();
                    try {
                        ArrayList O = wl1.O(c, w.intValue(), 0);
                        c.c();
                        return tg.Z(O, yjVar.z.E());
                    } finally {
                    }
                }
            } finally {
            }
        }
        return ut.e;
    }

    public final int F(int i) {
        int q = this.G.q(i) + 1;
        int i2 = 0;
        while (q < i) {
            if (!this.G.k(q)) {
                i2++;
            }
            q += this.G.b[(q * 5) + 3];
        }
        return i2;
    }

    /* JADX WARN: Code restructure failed: missing block: B:27:0x0053, code lost:
        if (r10 == null) goto L29;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object G(yj yjVar, yj yjVar2, Integer num, List list, xz xzVar) {
        Object a;
        int i;
        boolean z = this.F;
        int i2 = this.k;
        try {
            this.F = true;
            this.k = 0;
            int size = list.size();
            for (int i3 = 0; i3 < size; i3++) {
                zp0 zp0Var = (zp0) list.get(i3);
                xv0 xv0Var = (xv0) zp0Var.e;
                Object obj = zp0Var.f;
                if (obj != null) {
                    b0(xv0Var, obj);
                } else {
                    b0(xv0Var, null);
                }
            }
            if (yjVar != null) {
                if (num != null) {
                    i = num.intValue();
                } else {
                    i = -1;
                }
                if (yjVar2 != null && yjVar2 != yjVar && i >= 0) {
                    yjVar.v = yjVar2;
                    yjVar.w = i;
                    a = xzVar.a();
                    yjVar.v = null;
                    yjVar.w = 0;
                } else {
                    a = xzVar.a();
                }
            }
            a = xzVar.a();
            this.F = z;
            this.k = i2;
            return a;
        } catch (Throwable th) {
            this.F = z;
            this.k = i2;
            throw th;
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:8:0x003b, code lost:
        if (r4.b < r6) goto L8;
     */
    /* JADX WARN: Finally extract failed */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:128:0x0290  */
    /* JADX WARN: Removed duplicated region for block: B:162:0x0327  */
    /* JADX WARN: Removed duplicated region for block: B:165:0x0330  */
    /* JADX WARN: Removed duplicated region for block: B:168:0x033e  */
    /* JADX WARN: Removed duplicated region for block: B:61:0x0139  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void H() {
        u70 u70Var;
        int i;
        int i2;
        int i3;
        int i4;
        int i5;
        boolean z;
        int i6;
        long j;
        boolean z2;
        zj0 zj0Var;
        long j2;
        int s;
        int i7;
        int i8;
        int i9;
        int i10;
        Object b;
        int F;
        int i0;
        nq0 nq0Var = nq0.j;
        boolean z3 = this.F;
        this.F = true;
        w51 w51Var = this.G;
        int i11 = w51Var.i;
        int i12 = (i11 * 5) + 3;
        int i13 = w51Var.b[i12] + i11;
        int i14 = this.k;
        long j3 = this.T;
        int i15 = this.l;
        int i16 = this.m;
        int i17 = w51Var.g;
        ArrayList arrayList = this.s;
        int s2 = vn.s(i17, arrayList);
        if (s2 < 0) {
            s2 = -(s2 + 1);
        }
        if (s2 < arrayList.size()) {
            u70Var = (u70) arrayList.get(s2);
        }
        u70Var = null;
        int i18 = 1;
        int i19 = i11;
        int i20 = 0;
        while (u70Var != null) {
            xv0 xv0Var = u70Var.a;
            int i21 = u70Var.b;
            nq0 nq0Var2 = nq0Var;
            int s3 = vn.s(i21, arrayList);
            if (s3 >= 0) {
                u70 u70Var2 = (u70) arrayList.remove(s3);
            }
            Object obj = u70Var.c;
            if (obj == null) {
                xv0Var.getClass();
                i3 = i13;
                i = i12;
                i2 = i14;
            } else {
                int i22 = 8;
                hk0 hk0Var = xv0Var.g;
                if (hk0Var == null) {
                    i3 = i13;
                    i = i12;
                    i2 = i14;
                } else {
                    i = i12;
                    if (obj instanceof sp) {
                        sp spVar = (sp) obj;
                        t61 t61Var = spVar.g;
                        if (t61Var == null) {
                            t61Var = nq0Var2;
                        }
                        i2 = i14;
                        i3 = i13;
                        i4 = i15;
                        i5 = i16;
                        z = !t61Var.c(spVar.h().f, hk0Var.g(spVar));
                    } else {
                        i2 = i14;
                        if (obj instanceof ik0) {
                            ik0 ik0Var = (ik0) obj;
                            if (ik0Var.h()) {
                                Object[] objArr = ik0Var.b;
                                long[] jArr = ik0Var.a;
                                int length = jArr.length - 2;
                                if (length >= 0) {
                                    i4 = i15;
                                    i5 = i16;
                                    int i23 = 0;
                                    while (true) {
                                        long j4 = jArr[i23];
                                        i3 = i13;
                                        Object[] objArr2 = objArr;
                                        if ((((~j4) << 7) & j4 & (-9187201950435737472L)) != -9187201950435737472L) {
                                            int i24 = 8 - ((~(i23 - length)) >>> 31);
                                            int i25 = 0;
                                            while (i25 < i24) {
                                                if ((j4 & 255) < 128) {
                                                    i6 = i25;
                                                    Object obj2 = objArr2[(i23 << 3) + i25];
                                                    j = j4;
                                                    if (!(obj2 instanceof sp)) {
                                                        break;
                                                    }
                                                    sp spVar2 = (sp) obj2;
                                                    t61 t61Var2 = spVar2.g;
                                                    if (t61Var2 == null) {
                                                        t61Var2 = nq0Var2;
                                                    }
                                                    if (!t61Var2.c(spVar2.h().f, hk0Var.g(spVar2))) {
                                                        break;
                                                    }
                                                } else {
                                                    i6 = i25;
                                                    j = j4;
                                                }
                                                j4 = j >> i22;
                                                i25 = i6 + 1;
                                            }
                                            if (i24 != i22) {
                                                break;
                                            }
                                        }
                                        if (i23 == length) {
                                            break;
                                        }
                                        i23++;
                                        i13 = i3;
                                        objArr = objArr2;
                                        i22 = 8;
                                    }
                                    z = false;
                                }
                            }
                            i3 = i13;
                            i4 = i15;
                            i5 = i16;
                            z = false;
                        } else {
                            i3 = i13;
                        }
                    }
                    if (!z) {
                        this.G.r(i21);
                        int i26 = this.G.g;
                        K(i19, i26, i11);
                        int q = this.G.q(i26);
                        while (q != i11 && !this.G.l(q)) {
                            q = this.G.q(q);
                        }
                        if (this.G.l(q)) {
                            i7 = 0;
                        } else {
                            i7 = i2;
                        }
                        if (q != i26) {
                            int i02 = (i0(q) - this.G.o(i26)) + i7;
                            while (i7 < i02 && q != i21) {
                                q++;
                                while (q < i21) {
                                    w51 w51Var2 = this.G;
                                    int i27 = w51Var2.b[(q * 5) + 3] + q;
                                    if (i21 >= i27) {
                                        if (w51Var2.l(q)) {
                                            i0 = i18;
                                        } else {
                                            i0 = i0(q);
                                        }
                                        i7 += i0;
                                        q = i27;
                                    }
                                }
                                break;
                            }
                        }
                        this.k = i7;
                        this.m = F(i26);
                        int q2 = this.G.q(i26);
                        long j5 = 0;
                        int i28 = 3;
                        int i29 = 0;
                        while (true) {
                            if (q2 < 0) {
                                break;
                            } else if (q2 == i11) {
                                j5 ^= Long.rotateLeft(j3, i29);
                                break;
                            } else {
                                w51 w51Var3 = this.G;
                                boolean k = w51Var3.k(q2);
                                int[] iArr = w51Var3.b;
                                if (k) {
                                    Object p = w51Var3.p(iArr, q2);
                                    if (p != null) {
                                        if (p instanceof Enum) {
                                            i10 = ((Enum) p).ordinal();
                                        } else {
                                            i10 = p.hashCode();
                                        }
                                        i8 = i26;
                                    } else {
                                        i8 = i26;
                                        i10 = 0;
                                    }
                                } else {
                                    int i30 = w51Var3.i(q2);
                                    i8 = i26;
                                    if (i30 == 207 && (b = w51Var3.b(iArr, q2)) != null && !b.equals(oj.a)) {
                                        i10 = b.hashCode();
                                    } else {
                                        i10 = i30;
                                    }
                                }
                                if (i10 == 126665345) {
                                    j5 ^= Long.rotateLeft(i10, i29);
                                    break;
                                }
                                if (this.G.k(q2)) {
                                    F = 0;
                                } else {
                                    F = F(q2);
                                }
                                j5 = (j5 ^ Long.rotateLeft(i10, i28)) ^ Long.rotateLeft(F, i29);
                                i28 = (i28 + 6) % 64;
                                i29 = (i29 + 6) % 64;
                                q2 = this.G.q(q2);
                                i26 = i8;
                            }
                        }
                        i8 = i26;
                        this.T = j5;
                        this.K = null;
                        m00 m00Var = xv0Var.d;
                        if (m00Var != null) {
                            m00Var.f(this, Integer.valueOf(i18));
                            this.K = null;
                            w51 w51Var4 = this.G;
                            int i31 = w51Var4.b[i] + i11;
                            int i32 = w51Var4.g;
                            if (i32 >= i11 && i32 <= i31) {
                                i9 = i18;
                            } else {
                                i9 = 0;
                            }
                            if (i9 == 0) {
                                qj.a("Index " + i11 + " is not a parent of " + i32);
                            }
                            w51Var4.i = i11;
                            w51Var4.h = i31;
                            w51Var4.l = 0;
                            w51Var4.m = 0;
                            z2 = z3;
                            i19 = i8;
                            i20 = i18;
                        } else {
                            od.p("Invalid restart scope");
                            return;
                        }
                    } else {
                        ArrayList arrayList2 = this.E;
                        arrayList2.add(xv0Var);
                        this.g.k();
                        yj yjVar = xv0Var.a;
                        if (yjVar != null && (zj0Var = xv0Var.f) != null) {
                            xv0Var.d(i18);
                            try {
                                Object[] objArr3 = zj0Var.b;
                                int[] iArr2 = zj0Var.c;
                                long[] jArr2 = zj0Var.a;
                                int length2 = jArr2.length - 2;
                                z2 = z3;
                                if (length2 >= 0) {
                                    int i33 = 0;
                                    while (true) {
                                        long j6 = jArr2[i33];
                                        long[] jArr3 = jArr2;
                                        Object[] objArr4 = objArr3;
                                        if ((((~j6) << 7) & j6 & (-9187201950435737472L)) != -9187201950435737472L) {
                                            int i34 = 8 - ((~(i33 - length2)) >>> 31);
                                            int i35 = 0;
                                            while (i35 < i34) {
                                                if ((j6 & 255) < 128) {
                                                    int i36 = (i33 << 3) + i35;
                                                    j2 = j6;
                                                    Object obj3 = objArr4[i36];
                                                    int i37 = iArr2[i36];
                                                    yjVar.y(obj3);
                                                } else {
                                                    j2 = j6;
                                                }
                                                i35++;
                                                j6 = j2 >> 8;
                                            }
                                            if (i34 != 8) {
                                                break;
                                            }
                                        }
                                        if (i33 == length2) {
                                            break;
                                        }
                                        i33++;
                                        objArr3 = objArr4;
                                        jArr2 = jArr3;
                                    }
                                }
                                xv0Var.d(false);
                            } catch (Throwable th) {
                                xv0Var.d(false);
                                throw th;
                            }
                        } else {
                            z2 = z3;
                        }
                        i18 = 1;
                        arrayList2.remove(arrayList2.size() - 1);
                    }
                    s = vn.s(this.G.g, arrayList);
                    if (s < 0) {
                        s = -(s + 1);
                    }
                    if (s >= arrayList.size()) {
                        u70 u70Var3 = (u70) arrayList.get(s);
                        i13 = i3;
                        if (u70Var3.b < i13) {
                            u70Var = u70Var3;
                            z3 = z2;
                            nq0Var = nq0Var2;
                            i12 = i;
                            i14 = i2;
                            i15 = i4;
                            i16 = i5;
                        }
                    } else {
                        i13 = i3;
                    }
                    u70Var = null;
                    z3 = z2;
                    nq0Var = nq0Var2;
                    i12 = i;
                    i14 = i2;
                    i15 = i4;
                    i16 = i5;
                }
            }
            i4 = i15;
            i5 = i16;
            z = i18;
            if (!z) {
            }
            s = vn.s(this.G.g, arrayList);
            if (s < 0) {
            }
            if (s >= arrayList.size()) {
            }
            u70Var = null;
            z3 = z2;
            nq0Var = nq0Var2;
            i12 = i;
            i14 = i2;
            i15 = i4;
            i16 = i5;
        }
        boolean z4 = z3;
        int i38 = i14;
        int i39 = i15;
        int i40 = i16;
        if (i20 != 0) {
            K(i19, i11, i11);
            this.G.t();
            int i03 = i0(i11);
            this.k = i38 + i03;
            this.l = i39 + i03;
            this.m = i40;
        } else {
            Q();
        }
        this.T = j3;
        this.F = z4;
    }

    public final void I() {
        int i;
        M(this.G.g);
        pj pjVar = this.M;
        pjVar.d(false);
        w60 w60Var = pjVar.d;
        d10 d10Var = pjVar.a;
        w51 w51Var = d10Var.G;
        if (w51Var.c > 0 && w60Var.a(-2) != (i = w51Var.i)) {
            if (!pjVar.c && pjVar.e) {
                pjVar.d(false);
                pjVar.b.F.C(eo0.c);
                pjVar.c = true;
            }
            if (i > 0) {
                y00 a = w51Var.a(i);
                w60Var.c(i);
                pjVar.d(false);
                zo0 zo0Var = pjVar.b.F;
                zo0Var.C(do0.c);
                dd0.v(zo0Var, 0, a);
                pjVar.c = true;
            }
        }
        pjVar.b.F.C(mo0.c);
        int i2 = pjVar.f;
        w51 w51Var2 = d10Var.G;
        pjVar.f = w51Var2.b[(w51Var2.g * 5) + 3] + i2;
    }

    public final void J(qr0 qr0Var) {
        sj0 sj0Var = this.v;
        if (sj0Var == null) {
            sj0Var = new sj0();
            this.v = sj0Var;
        }
        sj0Var.h(this.G.g, qr0Var);
    }

    /* JADX WARN: Removed duplicated region for block: B:38:0x0075  */
    /* JADX WARN: Removed duplicated region for block: B:52:0x007a A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void K(int i, int i2, int i3) {
        w51 w51Var = this.G;
        if (i != i2) {
            if (i != i3 && i2 != i3) {
                if (w51Var.q(i) == i2) {
                    i3 = i2;
                } else if (w51Var.q(i2) != i) {
                    if (w51Var.q(i) == w51Var.q(i2)) {
                        i3 = w51Var.q(i);
                    } else {
                        int i4 = i;
                        int i5 = 0;
                        while (i4 > 0 && i4 != i3) {
                            i4 = w51Var.q(i4);
                            i5++;
                        }
                        int i6 = i2;
                        int i7 = 0;
                        while (i6 > 0 && i6 != i3) {
                            i6 = w51Var.q(i6);
                            i7++;
                        }
                        int i8 = i5 - i7;
                        int i9 = i;
                        for (int i10 = 0; i10 < i8; i10++) {
                            i9 = w51Var.q(i9);
                        }
                        int i11 = i7 - i5;
                        int i12 = i2;
                        for (int i13 = 0; i13 < i11; i13++) {
                            i12 = w51Var.q(i12);
                        }
                        i3 = i9;
                        for (int i14 = i12; i3 != i14; i14 = w51Var.q(i14)) {
                            i3 = w51Var.q(i3);
                        }
                    }
                }
            }
            while (i > 0 && i != i3) {
                if (!w51Var.l(i)) {
                    this.M.a();
                }
                i = w51Var.q(i);
            }
            o(i2, i3);
        }
        i3 = i;
        while (i > 0) {
            if (!w51Var.l(i)) {
            }
            i = w51Var.q(i);
        }
        o(i2, i3);
    }

    public final Object L() {
        boolean z = this.S;
        nq0 nq0Var = oj.a;
        if (z) {
            if (this.r) {
                qj.a("A call to createNode(), emitNode() or useNode() expected");
                return nq0Var;
            }
        } else {
            Object m = this.G.m();
            if (!this.y || (m instanceof tx0)) {
                if (m instanceof xw0) {
                    return ((xw0) m).a;
                }
                return m;
            }
        }
        return nq0Var;
    }

    public final void M(int i) {
        boolean l = this.G.l(i);
        pj pjVar = this.M;
        if (l) {
            pjVar.c();
            Object n = this.G.n(i);
            pjVar.c();
            pjVar.h.add(n);
        }
        N(this, i, l, 0);
        pjVar.c();
        if (l) {
            pjVar.a();
        }
    }

    public final boolean O(int i, boolean z) {
        xv0 x;
        int i2;
        if ((i & 1) == 0 && (this.S || this.y)) {
            l51 l51Var = this.P;
            if (l51Var != null && (x = x()) != null && l51Var.a()) {
                int i3 = x.b;
                if ((i3 & 512) != 0) {
                    return true;
                }
                int i4 = i3 | 1;
                x.b = i4;
                if (this.y) {
                    i2 = i3 | 129;
                } else {
                    i2 = i4 & (-129);
                }
                x.b = i2 | 256;
                zo0 zo0Var = this.M.b.F;
                zo0Var.C(lo0.c);
                dd0.v(zo0Var, 0, x);
                this.b.q(x);
                return false;
            }
        } else if (!z && A()) {
            return false;
        }
        return true;
    }

    /* JADX WARN: Removed duplicated region for block: B:27:0x0091  */
    /* JADX WARN: Removed duplicated region for block: B:30:0x009d  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x00cd  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void P() {
        Object obj;
        int hashCode;
        long rotateLeft;
        if (this.s.isEmpty()) {
            this.l = this.G.s() + this.l;
            return;
        }
        w51 w51Var = this.G;
        int g = w51Var.g();
        int[] iArr = w51Var.b;
        int i = w51Var.g;
        if (i < w51Var.h) {
            obj = w51Var.p(iArr, i);
        } else {
            obj = null;
        }
        Object f = w51Var.f();
        int i2 = this.m;
        nq0 nq0Var = oj.a;
        if (obj == null) {
            if (f != null && g == 207 && !f.equals(nq0Var)) {
                this.T = Long.rotateLeft(Long.rotateLeft(this.T, 3) ^ f.hashCode(), 3) ^ i2;
                boolean z = true;
                if ((iArr[(w51Var.g * 5) + 1] & 1073741824) == 0) {
                    z = false;
                }
                V(null, z);
                H();
                w51Var.e();
                if (obj != null) {
                    if (f != null && g == 207 && !f.equals(nq0Var)) {
                        this.T = Long.rotateRight(Long.rotateRight(this.T ^ i2, 3) ^ f.hashCode(), 3);
                        return;
                    }
                    this.T = Long.rotateRight(g ^ Long.rotateRight(this.T ^ i2, 3), 3);
                    return;
                } else if (obj instanceof Enum) {
                    this.T = Long.rotateRight(Long.rotateRight(this.T, 3) ^ ((Enum) obj).ordinal(), 3);
                    return;
                } else {
                    this.T = Long.rotateRight(Long.rotateRight(this.T, 3) ^ obj.hashCode(), 3);
                    return;
                }
            }
            rotateLeft = Long.rotateLeft(Long.rotateLeft(this.T, 3) ^ g, 3) ^ i2;
        } else {
            if (obj instanceof Enum) {
                hashCode = ((Enum) obj).ordinal();
            } else {
                hashCode = obj.hashCode();
            }
            rotateLeft = Long.rotateLeft(Long.rotateLeft(this.T, 3) ^ hashCode, 3);
        }
        this.T = rotateLeft;
        boolean z2 = true;
        if ((iArr[(w51Var.g * 5) + 1] & 1073741824) == 0) {
        }
        V(null, z2);
        H();
        w51Var.e();
        if (obj != null) {
        }
    }

    public final void Q() {
        int i;
        w51 w51Var = this.G;
        int i2 = w51Var.i;
        if (i2 >= 0) {
            i = w51Var.b[(i2 * 5) + 1] & 67108863;
        } else {
            i = 0;
        }
        this.l = i;
        w51Var.t();
    }

    public final void R() {
        if (this.l != 0) {
            qj.a("No nodes can be emitted before calling skipAndEndGroup");
        }
        if (!this.S) {
            xv0 x = x();
            if (x != null) {
                int i = x.b;
                if ((i & 128) == 0) {
                    x.b = i | 16;
                }
            }
            if (this.s.isEmpty()) {
                Q();
            } else {
                H();
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:22:0x0071  */
    /* JADX WARN: Removed duplicated region for block: B:25:0x0079  */
    /* JADX WARN: Removed duplicated region for block: B:26:0x007b  */
    /* JADX WARN: Removed duplicated region for block: B:29:0x0082  */
    /* JADX WARN: Removed duplicated region for block: B:44:0x00c4  */
    /* JADX WARN: Removed duplicated region for block: B:77:0x014c  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void S(int i, int i2, Object obj, Object obj2) {
        int hashCode;
        long rotateLeft;
        boolean z;
        boolean z2;
        boolean z3;
        g10 g10Var;
        g10 g10Var2;
        Object valueOf;
        int i3;
        Object obj3;
        int i4;
        int i5;
        int i6;
        int i7;
        Object[] objArr;
        Object[] objArr2;
        int i8;
        int i9;
        int i10;
        boolean z4;
        int i11;
        Object obj4;
        Object obj5 = obj;
        if (this.r) {
            qj.a("A call to createNode(), emitNode() or useNode() expected");
        }
        int i12 = this.m;
        Object obj6 = oj.a;
        if (obj5 == null) {
            if (obj2 != null && i == 207 && !obj2.equals(obj6)) {
                this.T = Long.rotateLeft(Long.rotateLeft(this.T, 3) ^ obj2.hashCode(), 3) ^ i12;
                if (obj5 == null) {
                    this.m++;
                }
                if (i2 == 0) {
                    z = true;
                } else {
                    z = false;
                }
                if (!this.S) {
                    this.G.k++;
                    a61 a61Var = this.I;
                    int i13 = a61Var.t;
                    if (z) {
                        a61Var.Q(i, obj6, true, obj6);
                    } else if (obj2 != null) {
                        if (obj5 == null) {
                            obj5 = obj6;
                        }
                        a61Var.Q(i, obj5, false, obj2);
                    } else {
                        if (obj5 == null) {
                            obj5 = obj6;
                        }
                        a61Var.Q(i, obj5, false, obj6);
                    }
                    g10 g10Var3 = this.j;
                    if (g10Var3 != null) {
                        int i14 = (-2) - i13;
                        e90 e90Var = new e90(-1, i, i14, -1);
                        g10Var3.e.h(i14, new t20(-1, this.k - g10Var3.b, 0));
                        g10Var3.d.add(e90Var);
                    }
                    u(z, null);
                    return;
                }
                if (i2 == 1 && this.y) {
                    z2 = true;
                } else {
                    z2 = false;
                }
                if (this.j == null) {
                    int g = this.G.g();
                    if (!z2 && g == i) {
                        w51 w51Var = this.G;
                        int i15 = w51Var.g;
                        if (i15 < w51Var.h) {
                            obj4 = w51Var.p(w51Var.b, i15);
                        } else {
                            obj4 = null;
                        }
                        if (k70.p(obj5, obj4)) {
                            V(obj2, z);
                        }
                    }
                    w51 w51Var2 = this.G;
                    int[] iArr = w51Var2.b;
                    ArrayList arrayList = new ArrayList();
                    if (w51Var2.k <= 0) {
                        int i16 = w51Var2.g;
                        while (i16 < w51Var2.h) {
                            int i17 = i16 * 5;
                            int i18 = iArr[i17];
                            Object p = w51Var2.p(iArr, i16);
                            int i19 = iArr[i17 + 1];
                            if ((i19 & 1073741824) != 0) {
                                z4 = z2;
                                i11 = 1;
                            } else {
                                z4 = z2;
                                i11 = i19 & 67108863;
                            }
                            arrayList.add(new e90(p, i18, i16, i11));
                            i16 += iArr[i17 + 3];
                            z2 = z4;
                        }
                    }
                    z3 = z2;
                    this.j = new g10(this.k, arrayList);
                    g10Var = this.j;
                    if (g10Var != null) {
                        ArrayList arrayList2 = g10Var.d;
                        sj0 sj0Var = g10Var.e;
                        int i20 = g10Var.b;
                        if (obj5 != null) {
                            valueOf = new i80(Integer.valueOf(i), obj5);
                        } else {
                            valueOf = Integer.valueOf(i);
                        }
                        hk0 hk0Var = ((oj0) g10Var.f.getValue()).a;
                        Object g2 = hk0Var.g(valueOf);
                        if (g2 == null) {
                            g2 = null;
                        } else if (g2 instanceof ak0) {
                            ak0 ak0Var = (ak0) g2;
                            Object k = ak0Var.k(0);
                            if (ak0Var.h()) {
                                hk0Var.k(valueOf);
                            }
                            if (ak0Var.b == 1) {
                                hk0Var.m(valueOf, ak0Var.e());
                            }
                            g2 = k;
                        } else {
                            hk0Var.k(valueOf);
                        }
                        e90 e90Var2 = (e90) g2;
                        if (!z3 && e90Var2 != null) {
                            int i21 = e90Var2.c;
                            arrayList2.add(e90Var2);
                            t20 t20Var = (t20) sj0Var.b(i21);
                            if (t20Var != null) {
                                i5 = t20Var.b;
                            } else {
                                i5 = -1;
                            }
                            this.k = i5 + i20;
                            t20 t20Var2 = (t20) sj0Var.b(i21);
                            if (t20Var2 != null) {
                                i6 = t20Var2.a;
                            } else {
                                i6 = -1;
                            }
                            int i22 = g10Var.c;
                            int i23 = i6 - i22;
                            int i24 = 8;
                            if (i6 > i22) {
                                Object[] objArr3 = sj0Var.c;
                                long[] jArr = sj0Var.a;
                                int length = jArr.length - 2;
                                if (length >= 0) {
                                    int i25 = 0;
                                    while (true) {
                                        long j = jArr[i25];
                                        if ((((~j) << 7) & j & (-9187201950435737472L)) != -9187201950435737472L) {
                                            int i26 = 8 - ((~(i25 - length)) >>> 31);
                                            int i27 = 0;
                                            while (i27 < i26) {
                                                if ((j & 255) < 128) {
                                                    i10 = i24;
                                                    t20 t20Var3 = (t20) objArr3[(i25 << 3) + i27];
                                                    i9 = i23;
                                                    int i28 = t20Var3.a;
                                                    if (i28 == i6) {
                                                        t20Var3.a = i22;
                                                    } else if (i22 <= i28 && i28 < i6) {
                                                        t20Var3.a = i28 + 1;
                                                    }
                                                } else {
                                                    i9 = i23;
                                                    i10 = i24;
                                                }
                                                j >>= i10;
                                                i27++;
                                                i23 = i9;
                                                i24 = i10;
                                            }
                                            i7 = i23;
                                            if (i26 != i24) {
                                                break;
                                            }
                                        } else {
                                            i7 = i23;
                                        }
                                        if (i25 == length) {
                                            break;
                                        }
                                        i25++;
                                        i23 = i7;
                                        i24 = 8;
                                    }
                                } else {
                                    i7 = i23;
                                }
                            } else {
                                i7 = i23;
                                if (i22 > i6) {
                                    Object[] objArr4 = sj0Var.c;
                                    long[] jArr2 = sj0Var.a;
                                    int length2 = jArr2.length - 2;
                                    if (length2 >= 0) {
                                        int i29 = 0;
                                        while (true) {
                                            long j2 = jArr2[i29];
                                            if ((((~j2) << 7) & j2 & (-9187201950435737472L)) != -9187201950435737472L) {
                                                int i30 = 8 - ((~(i29 - length2)) >>> 31);
                                                int i31 = 0;
                                                while (i31 < i30) {
                                                    if ((j2 & 255) < 128) {
                                                        t20 t20Var4 = (t20) objArr4[(i29 << 3) + i31];
                                                        int i32 = t20Var4.a;
                                                        if (i32 == i6) {
                                                            t20Var4.a = i22;
                                                        } else {
                                                            objArr2 = objArr4;
                                                            if (i6 + 1 <= i32 && i32 < i22) {
                                                                t20Var4.a = i32 - 1;
                                                            }
                                                            j2 >>= 8;
                                                            i31++;
                                                            objArr4 = objArr2;
                                                        }
                                                    }
                                                    objArr2 = objArr4;
                                                    j2 >>= 8;
                                                    i31++;
                                                    objArr4 = objArr2;
                                                }
                                                objArr = objArr4;
                                                if (i30 != 8) {
                                                    break;
                                                }
                                            } else {
                                                objArr = objArr4;
                                            }
                                            if (i29 == length2) {
                                                break;
                                            }
                                            i29++;
                                            objArr4 = objArr;
                                        }
                                    }
                                }
                            }
                            pj pjVar = this.M;
                            int i33 = pjVar.f;
                            d10 d10Var = pjVar.a;
                            pjVar.f = (i21 - d10Var.G.g) + i33;
                            this.G.r(i21);
                            if (i7 > 0) {
                                pjVar.d(false);
                                w60 w60Var = pjVar.d;
                                w51 w51Var3 = d10Var.G;
                                if (w51Var3.c > 0 && w60Var.a(-2) != (i8 = w51Var3.i)) {
                                    if (!pjVar.c && pjVar.e) {
                                        pjVar.d(false);
                                        pjVar.b.F.C(eo0.c);
                                        pjVar.c = true;
                                    }
                                    if (i8 > 0) {
                                        y00 a = w51Var3.a(i8);
                                        w60Var.c(i8);
                                        pjVar.d(false);
                                        zo0 zo0Var = pjVar.b.F;
                                        zo0Var.C(do0.c);
                                        dd0.v(zo0Var, 0, a);
                                        pjVar.c = true;
                                    }
                                }
                                zo0 zo0Var2 = pjVar.b.F;
                                zo0Var2.C(io0.c);
                                zo0Var2.d[zo0Var2.e - zo0Var2.b[zo0Var2.c - 1].a] = i7;
                            }
                            V(obj2, z);
                        } else {
                            this.G.k++;
                            this.S = true;
                            this.K = null;
                            if (this.I.w) {
                                a61 e = this.H.e();
                                this.I = e;
                                e.M();
                                this.J = false;
                                this.K = null;
                            }
                            this.I.d();
                            a61 a61Var2 = this.I;
                            int i34 = a61Var2.t;
                            if (z) {
                                a61Var2.Q(i, obj6, true, obj6);
                                i3 = 0;
                            } else if (obj2 != null) {
                                if (obj != null) {
                                    obj6 = obj;
                                }
                                i3 = 0;
                                a61Var2.Q(i, obj6, false, obj2);
                            } else {
                                i3 = 0;
                                if (obj == null) {
                                    obj3 = obj6;
                                } else {
                                    obj3 = obj;
                                }
                                a61Var2.Q(i, obj3, false, obj6);
                            }
                            this.N = this.I.b(i34);
                            int i35 = (-2) - i34;
                            e90 e90Var3 = new e90(-1, i, i35, -1);
                            sj0Var.h(i35, new t20(-1, this.k - i20, i3));
                            arrayList2.add(e90Var3);
                            ArrayList arrayList3 = new ArrayList();
                            if (z) {
                                i4 = i3;
                            } else {
                                i4 = this.k;
                            }
                            g10Var2 = new g10(i4, arrayList3);
                            u(z, g10Var2);
                            return;
                        }
                    }
                    g10Var2 = null;
                    u(z, g10Var2);
                    return;
                }
                z3 = z2;
                g10Var = this.j;
                if (g10Var != null) {
                }
                g10Var2 = null;
                u(z, g10Var2);
                return;
            }
            rotateLeft = Long.rotateLeft(Long.rotateLeft(this.T, 3) ^ i, 3) ^ i12;
        } else {
            if (obj5 instanceof Enum) {
                hashCode = ((Enum) obj5).ordinal();
            } else {
                hashCode = obj5.hashCode();
            }
            rotateLeft = Long.rotateLeft(Long.rotateLeft(this.T, 3) ^ hashCode, 3);
        }
        this.T = rotateLeft;
        if (obj5 == null) {
        }
        if (i2 == 0) {
        }
        if (!this.S) {
        }
    }

    public final void T() {
        S(-127, 0, null, null);
    }

    public final void U(int i, qn0 qn0Var) {
        S(i, 0, qn0Var, null);
    }

    public final void V(Object obj, boolean z) {
        if (z) {
            w51 w51Var = this.G;
            if (w51Var.k <= 0) {
                if ((w51Var.b[(w51Var.g * 5) + 1] & 1073741824) == 0) {
                    rt0.a("Expected a node group");
                }
                w51Var.u();
                return;
            }
            return;
        }
        if (obj != null && this.G.f() != obj) {
            pj pjVar = this.M;
            pjVar.getClass();
            pjVar.d(false);
            zo0 zo0Var = pjVar.b.F;
            zo0Var.C(to0.c);
            dd0.v(zo0Var, 0, obj);
        }
        this.G.u();
    }

    public final void W(int i) {
        int i2;
        int i3;
        if (this.j != null) {
            S(i, 0, null, null);
            return;
        }
        if (this.r) {
            qj.a("A call to createNode(), emitNode() or useNode() expected");
        }
        this.T = Long.rotateLeft(Long.rotateLeft(this.T, 3) ^ i, 3) ^ this.m;
        this.m++;
        w51 w51Var = this.G;
        boolean z = this.S;
        nq0 nq0Var = oj.a;
        if (z) {
            w51Var.k++;
            this.I.Q(i, nq0Var, false, nq0Var);
            u(false, null);
        } else if (w51Var.g() == i && ((i3 = w51Var.g) >= w51Var.h || (w51Var.b[(i3 * 5) + 1] & 536870912) == 0)) {
            w51Var.u();
            u(false, null);
        } else {
            if (w51Var.k <= 0 && (i2 = w51Var.g) != w51Var.h) {
                int i4 = this.k;
                I();
                this.M.e(i4, w51Var.s());
                vn.f(this.s, i2, w51Var.g);
            }
            w51Var.k++;
            this.S = true;
            this.K = null;
            if (this.I.w) {
                a61 e = this.H.e();
                this.I = e;
                e.M();
                this.J = false;
                this.K = null;
            }
            a61 a61Var = this.I;
            a61Var.d();
            int i5 = a61Var.t;
            a61Var.Q(i, nq0Var, false, nq0Var);
            this.N = a61Var.b(i5);
            u(false, null);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:28:0x0073  */
    /* JADX WARN: Removed duplicated region for block: B:29:0x0076  */
    /* JADX WARN: Removed duplicated region for block: B:32:0x0090  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final d10 X(int i) {
        u70 u70Var;
        xv0 xv0Var;
        boolean z;
        int i2;
        int i3;
        boolean z2;
        W(i);
        boolean z3 = this.S;
        pg0 pg0Var = this.g;
        ArrayList arrayList = this.E;
        yj yjVar = this.h;
        if (z3) {
            xv0 xv0Var2 = new xv0(yjVar);
            arrayList.add(xv0Var2);
            h0(xv0Var2);
            xv0Var2.e = this.B;
            xv0Var2.b &= -17;
            pg0Var.k();
            return this;
        }
        int i4 = this.G.i;
        ArrayList arrayList2 = this.s;
        int s = vn.s(i4, arrayList2);
        if (s >= 0) {
            u70Var = (u70) arrayList2.remove(s);
        } else {
            u70Var = null;
        }
        Object m = this.G.m();
        if (k70.p(m, oj.a)) {
            xv0Var = new xv0(yjVar);
            h0(xv0Var);
        } else {
            m.getClass();
            xv0Var = (xv0) m;
        }
        if (u70Var == null) {
            int i5 = xv0Var.b;
            if ((i5 & 64) != 0) {
                z2 = true;
            } else {
                z2 = false;
            }
            if (z2) {
                xv0Var.b = i5 & (-65);
            }
            if (!z2) {
                z = false;
                int i6 = xv0Var.b;
                if (!z) {
                    i2 = i6 | 8;
                } else {
                    i2 = i6 & (-9);
                }
                xv0Var.b = i2;
                arrayList.add(xv0Var);
                xv0Var.e = this.B;
                xv0Var.b &= -17;
                pg0Var.k();
                i3 = xv0Var.b;
                if ((i3 & 256) != 0) {
                    xv0Var.b = (i3 & (-257)) | 512;
                    zo0 zo0Var = this.M.b.F;
                    zo0Var.C(ro0.c);
                    dd0.v(zo0Var, 0, xv0Var);
                    if (!this.y) {
                        int i7 = xv0Var.b;
                        if ((i7 & 128) != 0) {
                            this.y = true;
                            xv0Var.b = i7 | 1024;
                        }
                    }
                }
                return this;
            }
        }
        z = true;
        int i62 = xv0Var.b;
        if (!z) {
        }
        xv0Var.b = i2;
        arrayList.add(xv0Var);
        xv0Var.e = this.B;
        xv0Var.b &= -17;
        pg0Var.k();
        i3 = xv0Var.b;
        if ((i3 & 256) != 0) {
        }
        return this;
    }

    public final void Y(Object obj) {
        if (!this.S && this.G.g() == 207 && !k70.p(this.G.f(), obj) && this.z < 0) {
            this.z = this.G.g;
            this.y = true;
        }
        S(207, 0, null, obj);
    }

    public final void Z() {
        S(125, 2, null, null);
        this.r = true;
    }

    public final void a() {
        i();
        this.i.clear();
        this.n.b = 0;
        this.t.b = 0;
        this.x.b = 0;
        this.v = null;
        bw bwVar = this.O;
        bwVar.c.z();
        bwVar.b.z();
        this.T = 0L;
        this.A = 0;
        this.r = false;
        this.S = false;
        this.y = false;
        this.F = false;
        this.z = -1;
        w51 w51Var = this.G;
        if (!w51Var.f) {
            w51Var.c();
        }
        if (!this.I.w) {
            v();
        }
    }

    public final void a0() {
        this.m = 0;
        this.G = this.c.c();
        S(100, 0, null, null);
        sj sjVar = this.b;
        sjVar.t();
        qr0 i = sjVar.i();
        this.x.c(this.w ? 1 : 0);
        this.w = f(i);
        this.K = null;
        if (!this.q) {
            this.q = sjVar.e();
        }
        if (!this.C) {
            this.C = sjVar.f();
        }
        if (this.C) {
            k81 k81Var = xj.a;
            k81Var.getClass();
            i = i.b(k81Var, new l81(z()));
        }
        this.u = i;
        Set set = (Set) gh0.L(i, h60.a);
        if (set != null) {
            set.add(w());
            sjVar.o(set);
        }
        long g = sjVar.g();
        S((int) (g ^ (g >>> 32)), 0, null, null);
    }

    public final void b(m00 m00Var, Object obj) {
        if (this.S) {
            zo0 zo0Var = this.O.b;
            zo0Var.C(uo0.c);
            dd0.v(zo0Var, 0, obj);
            m00Var.getClass();
            vd1.e(2, m00Var);
            dd0.v(zo0Var, 1, m00Var);
            return;
        }
        pj pjVar = this.M;
        pjVar.b();
        zo0 zo0Var2 = pjVar.b.F;
        zo0Var2.C(uo0.c);
        m00Var.getClass();
        vd1.e(2, m00Var);
        dd0.w(zo0Var2, 0, obj, 1, m00Var);
    }

    public final boolean b0(xv0 xv0Var, Object obj) {
        y00 y00Var = xv0Var.c;
        if (y00Var != null) {
            int a = this.G.a.a(ac.j(y00Var));
            if (this.F && a >= this.G.g) {
                ArrayList arrayList = this.s;
                int s = vn.s(a, arrayList);
                if (s < 0) {
                    int i = -(s + 1);
                    if (!(obj instanceof sp)) {
                        obj = null;
                    }
                    arrayList.add(i, new u70(xv0Var, a, obj));
                    return true;
                }
                u70 u70Var = (u70) arrayList.get(s);
                if (obj instanceof sp) {
                    Object obj2 = u70Var.c;
                    if (obj2 == null) {
                        u70Var.c = obj;
                        return true;
                    } else if (obj2 instanceof ik0) {
                        ((ik0) obj2).a(obj);
                        return true;
                    } else {
                        ik0 ik0Var = o01.a;
                        ik0 ik0Var2 = new ik0(2);
                        ik0Var2.k(obj2);
                        ik0Var2.k(obj);
                        u70Var.c = ik0Var2;
                        return true;
                    }
                }
                u70Var.c = null;
                return true;
            }
            return false;
        }
        return false;
    }

    public final boolean c(float f) {
        Object D = D();
        if ((D instanceof Float) && f == ((Number) D).floatValue()) {
            return false;
        }
        h0(Float.valueOf(f));
        return true;
    }

    public final void c0(hk0 hk0Var) {
        y00 y00Var;
        ArrayList arrayList = this.s;
        for (int t = zi1.t(arrayList); -1 < t; t--) {
            u70 u70Var = (u70) arrayList.get(t);
            y00 y00Var2 = u70Var.a.c;
            if (y00Var2 != null) {
                y00Var = ac.j(y00Var2);
            } else {
                y00Var = null;
            }
            if (y00Var != null && y00Var.a()) {
                int i = u70Var.b;
                int i2 = y00Var.a;
                if (i != i2) {
                    u70Var.b = i2;
                }
            } else {
                arrayList.remove(t);
            }
        }
        Object[] objArr = hk0Var.b;
        Object[] objArr2 = hk0Var.c;
        long[] jArr = hk0Var.a;
        int length = jArr.length - 2;
        if (length >= 0) {
            int i3 = 0;
            while (true) {
                long j = jArr[i3];
                if ((((~j) << 7) & j & (-9187201950435737472L)) != -9187201950435737472L) {
                    int i4 = 8 - ((~(i3 - length)) >>> 31);
                    for (int i5 = 0; i5 < i4; i5++) {
                        if ((255 & j) < 128) {
                            int i6 = (i3 << 3) + i5;
                            Object obj = objArr[i6];
                            Object obj2 = objArr2[i6];
                            obj.getClass();
                            xv0 xv0Var = (xv0) obj;
                            y00 y00Var3 = xv0Var.c;
                            if (y00Var3 != null) {
                                int i7 = ac.j(y00Var3).a;
                                if (obj2 == nq0.i) {
                                    obj2 = null;
                                }
                                arrayList.add(new u70(xv0Var, i7, obj2));
                            }
                        }
                        j >>= 8;
                    }
                    if (i4 != 8) {
                        break;
                    }
                }
                if (i3 == length) {
                    break;
                }
                i3++;
            }
        }
        xg.N(arrayList, vn.h);
    }

    public final boolean d(int i) {
        Object D = D();
        if ((D instanceof Integer) && i == ((Number) D).intValue()) {
            return false;
        }
        h0(Integer.valueOf(i));
        return true;
    }

    public final void d0(int i, int i2) {
        if (i0(i) != i2) {
            if (i < 0) {
                qj0 qj0Var = this.p;
                if (qj0Var == null) {
                    qj0Var = new qj0();
                    this.p = qj0Var;
                }
                qj0Var.f(i, i2);
                return;
            }
            int[] iArr = this.o;
            if (iArr == null) {
                int i3 = this.G.c;
                int[] iArr2 = new int[i3];
                Arrays.fill(iArr2, 0, i3, -1);
                this.o = iArr2;
                iArr = iArr2;
            }
            iArr[i] = i2;
        }
    }

    public final boolean e(long j) {
        Object D = D();
        if ((D instanceof Long) && j == ((Number) D).longValue()) {
            return false;
        }
        h0(Long.valueOf(j));
        return true;
    }

    public final void e0(int i, int i2) {
        int i0 = i0(i);
        if (i0 != i2) {
            int i3 = i2 - i0;
            ArrayList arrayList = this.i;
            int size = arrayList.size() - 1;
            while (i != -1) {
                int i02 = i0(i) + i3;
                d0(i, i02);
                int i4 = size;
                while (true) {
                    if (-1 < i4) {
                        g10 g10Var = (g10) arrayList.get(i4);
                        if (g10Var != null && g10Var.a(i, i02)) {
                            size = i4 - 1;
                            break;
                        }
                        i4--;
                    } else {
                        break;
                    }
                }
                w51 w51Var = this.G;
                if (i < 0) {
                    i = w51Var.i;
                } else if (!w51Var.l(i)) {
                    i = this.G.q(i);
                } else {
                    return;
                }
            }
        }
    }

    public final boolean f(Object obj) {
        if (!k70.p(D(), obj)) {
            h0(obj);
            return true;
        }
        return false;
    }

    public final qr0 f0(qr0 qr0Var, qr0 qr0Var2) {
        qr0Var.getClass();
        pr0 pr0Var = new pr0(qr0Var);
        pr0Var.putAll(qr0Var2);
        qr0 b = pr0Var.b();
        U(204, qj.d);
        D();
        h0(b);
        D();
        h0(qr0Var2);
        p(false);
        return b;
    }

    public final boolean g(boolean z) {
        Object D = D();
        if ((D instanceof Boolean) && z == ((Boolean) D).booleanValue()) {
            return false;
        }
        h0(Boolean.valueOf(z));
        return true;
    }

    public final void g0(Object obj) {
        if (obj instanceof ww0) {
            xw0 xw0Var = new xw0((ww0) obj, this.m - 1);
            if (this.S) {
                zo0 zo0Var = this.M.b.F;
                zo0Var.C(ko0.c);
                dd0.v(zo0Var, 0, xw0Var);
            }
            this.d.add(obj);
            obj = xw0Var;
        }
        h0(obj);
    }

    public final boolean h(Object obj) {
        if (D() != obj) {
            h0(obj);
            return true;
        }
        return false;
    }

    public final void h0(Object obj) {
        if (this.S) {
            a61 a61Var = this.I;
            if (a61Var.n > 0 && a61Var.i != a61Var.k) {
                sj0 sj0Var = a61Var.s;
                if (sj0Var == null) {
                    sj0Var = new sj0();
                }
                a61Var.s = sj0Var;
                int i = a61Var.v;
                Object b = sj0Var.b(i);
                if (b == null) {
                    b = new ak0();
                    sj0Var.h(i, b);
                }
                ((ak0) b).a(obj);
                return;
            }
            a61Var.F(obj);
            return;
        }
        w51 w51Var = this.G;
        boolean z = w51Var.n;
        pj pjVar = this.M;
        if (z) {
            int b2 = (w51Var.l - z51.b(w51Var.b, w51Var.i)) - 1;
            if (pjVar.a.G.i - pjVar.f < 0) {
                w51 w51Var2 = this.G;
                y00 a = w51Var2.a(w51Var2.i);
                zo0 zo0Var = pjVar.b.F;
                zo0Var.C(fo0.f);
                dd0.w(zo0Var, 0, obj, 1, a);
                zo0Var.d[zo0Var.e - zo0Var.b[zo0Var.c - 1].a] = b2;
                return;
            }
            pjVar.d(true);
            zo0 zo0Var2 = pjVar.b.F;
            zo0Var2.C(fo0.g);
            dd0.v(zo0Var2, 0, obj);
            zo0Var2.d[zo0Var2.e - zo0Var2.b[zo0Var2.c - 1].a] = b2;
            return;
        }
        y00 a2 = w51Var.a(w51Var.i);
        zo0 zo0Var3 = pjVar.b.F;
        zo0Var3.C(sn0.c);
        dd0.w(zo0Var3, 0, a2, 1, obj);
    }

    public final void i() {
        this.j = null;
        this.k = 0;
        this.l = 0;
        this.T = 0L;
        this.r = false;
        pj pjVar = this.M;
        pjVar.c = false;
        pjVar.d.b = 0;
        pjVar.f = 0;
        pjVar.e = true;
        pjVar.g = 0;
        pjVar.h.clear();
        pjVar.i = -1;
        pjVar.j = -1;
        pjVar.k = -1;
        pjVar.l = 0;
        this.E.clear();
        this.o = null;
        this.p = null;
    }

    public final int i0(int i) {
        int i2;
        if (i < 0) {
            qj0 qj0Var = this.p;
            if (qj0Var == null || qj0Var.c(i) < 0) {
                return 0;
            }
            int c = qj0Var.c(i);
            if (c >= 0) {
                return qj0Var.c[c];
            }
            throw new NoSuchElementException(fu0.E("Cannot find value for key ", i));
        }
        int[] iArr = this.o;
        if (iArr != null && (i2 = iArr[i]) >= 0) {
            return i2;
        }
        return this.G.o(i);
    }

    public final Object j(lv0 lv0Var) {
        return gh0.L(l(), lv0Var);
    }

    public final void j0() {
        if (!this.r) {
            qj.a("A call to createNode(), emitNode() or useNode() expected was not expected");
        }
        this.r = false;
        if (this.S) {
            qj.a("useNode() called while inserting");
        }
        w51 w51Var = this.G;
        Object n = w51Var.n(w51Var.i);
        pj pjVar = this.M;
        pjVar.c();
        pjVar.h.add(n);
        if (this.y && (n instanceof wi)) {
            pjVar.b();
            pjVar.b.F.C(wo0.c);
        }
    }

    public final void k(xz xzVar) {
        if (!this.r) {
            qj.a("A call to createNode(), emitNode() or useNode() expected was not expected");
        }
        this.r = false;
        if (!this.S) {
            qj.a("createNode() can only be called when inserting");
        }
        w60 w60Var = this.n;
        int i = w60Var.a[w60Var.b - 1];
        a61 a61Var = this.I;
        y00 b = a61Var.b(a61Var.v);
        this.l++;
        bw bwVar = this.O;
        zo0 zo0Var = bwVar.b;
        zo0Var.C(fo0.d);
        dd0.v(zo0Var, 0, xzVar);
        zo0Var.d[zo0Var.e - zo0Var.b[zo0Var.c - 1].a] = i;
        dd0.v(zo0Var, 1, b);
        zo0 zo0Var2 = bwVar.c;
        zo0Var2.C(fo0.e);
        zo0Var2.d[zo0Var2.e - zo0Var2.b[zo0Var2.c - 1].a] = i;
        dd0.v(zo0Var2, 0, b);
    }

    public final qr0 l() {
        qr0 qr0Var;
        qr0 qr0Var2 = this.K;
        if (qr0Var2 != null) {
            return qr0Var2;
        }
        int i = this.G.i;
        boolean z = this.S;
        qn0 qn0Var = qj.c;
        if (z && this.J) {
            int i2 = this.I.v;
            while (i2 > 0) {
                if (this.I.s(i2) == 202 && k70.p(this.I.t(i2), qn0Var)) {
                    Object q = this.I.q(i2);
                    q.getClass();
                    qr0 qr0Var3 = (qr0) q;
                    this.K = qr0Var3;
                    return qr0Var3;
                }
                a61 a61Var = this.I;
                i2 = a61Var.E(a61Var.b, i2);
            }
        }
        if (this.G.c > 0) {
            while (i > 0) {
                if (this.G.i(i) == 202) {
                    w51 w51Var = this.G;
                    if (k70.p(w51Var.p(w51Var.b, i), qn0Var)) {
                        sj0 sj0Var = this.v;
                        if (sj0Var == null || (qr0Var = (qr0) sj0Var.b(i)) == null) {
                            w51 w51Var2 = this.G;
                            Object b = w51Var2.b(w51Var2.b, i);
                            b.getClass();
                            qr0Var = (qr0) b;
                        }
                        this.K = qr0Var;
                        return qr0Var;
                    }
                }
                i = this.G.q(i);
            }
        }
        qr0 qr0Var4 = this.u;
        this.K = qr0Var4;
        return qr0Var4;
    }

    public final ej m() {
        Collection collection;
        Object obj;
        if (!this.b.k()) {
            return null;
        }
        qe0 qe0Var = new qe0(10);
        a61 a61Var = this.I;
        qe0Var.addAll(wl1.p(a61Var, null, a61Var.t, null));
        w51 w51Var = this.G;
        boolean z = w51Var.f;
        int[] iArr = w51Var.b;
        if (!z && w51Var.c != 0) {
            tv0 tv0Var = new tv0(w51Var);
            int i = w51Var.i;
            Object valueOf = Integer.valueOf(w51Var.l - z51.b(iArr, i));
            while (i >= 0) {
                if (w51Var.k(i)) {
                    obj = w51Var.p(iArr, i);
                } else {
                    obj = oj.a;
                }
                tv0Var.f(w51Var.i(i), obj, w51Var.a.g(i), valueOf);
                valueOf = w51Var.a(i);
                i = w51Var.q(i);
            }
            collection = (ArrayList) tv0Var.a;
        } else {
            collection = ut.e;
        }
        qe0Var.addAll(collection);
        qe0Var.addAll(E());
        return new ej(zi1.o(qe0Var), this.C);
    }

    public final void n(hk0 hk0Var, m00 m00Var) {
        ArrayList arrayList = this.s;
        if (this.F) {
            qj.a("Reentrant composition is not supported");
        }
        this.g.k();
        Trace.beginSection("Compose:recompose");
        try {
            long g = n61.j().g();
            this.B = (int) (g ^ (g >>> 32));
            this.v = null;
            c0(hk0Var);
            this.k = 0;
            this.F = true;
            a0();
            Object D = D();
            if (D != m00Var && m00Var != null) {
                h0(m00Var);
            }
            c10 c10Var = this.D;
            qk0 i = mc0.i();
            i.b(c10Var);
            qn0 qn0Var = qj.a;
            if (m00Var != null) {
                U(200, qn0Var);
                vn.D(this, m00Var);
                p(false);
            } else if (this.w && D != null && !D.equals(oj.a)) {
                U(200, qn0Var);
                vd1.e(2, D);
                vn.D(this, (m00) D);
                p(false);
            } else {
                P();
            }
            i.k(i.g - 1);
            t();
            this.F = false;
            arrayList.clear();
            if (!this.I.w) {
                qj.a("Check failed");
            }
            v();
        } finally {
            Trace.endSection();
        }
    }

    public final void o(int i, int i2) {
        if (i > 0 && i != i2) {
            o(this.G.q(i), i2);
            if (this.G.l(i)) {
                Object n = this.G.n(i);
                pj pjVar = this.M;
                pjVar.c();
                pjVar.h.add(n);
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:153:0x03a9  */
    /* JADX WARN: Removed duplicated region for block: B:176:0x042f  */
    /* JADX WARN: Removed duplicated region for block: B:220:0x05b2  */
    /* JADX WARN: Type inference failed for: r3v19 */
    /* JADX WARN: Type inference failed for: r3v29, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r3v32 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void p(boolean z) {
        int hashCode;
        long rotateRight;
        w60 w60Var;
        ArrayList arrayList;
        int i;
        boolean z2;
        int i2;
        w51 w51Var;
        ArrayList arrayList2;
        g10 g10Var;
        w51 w51Var2;
        ?? r3;
        int i3;
        int i4;
        int i5;
        int i6;
        int i7;
        w60 w60Var2;
        int i8;
        int i9;
        int i10;
        ArrayList arrayList3;
        ik0 ik0Var;
        int i11;
        int i12;
        ArrayList arrayList4;
        ArrayList arrayList5;
        HashSet hashSet;
        int i13;
        g10 g10Var2;
        int i14;
        int i15;
        int i16;
        int i17;
        Object[] objArr;
        long[] jArr;
        int i18;
        Object[] objArr2;
        long[] jArr2;
        int i19;
        Object[] objArr3;
        long[] jArr3;
        int i20;
        Object[] objArr4;
        long[] jArr4;
        int hashCode2;
        long rotateRight2;
        w60 w60Var3 = this.n;
        int i21 = w60Var3.a[w60Var3.b - 2] - 1;
        boolean z3 = this.S;
        nq0 nq0Var = oj.a;
        if (z3) {
            a61 a61Var = this.I;
            int i22 = a61Var.v;
            int s = a61Var.s(i22);
            Object t = this.I.t(i22);
            Object q = this.I.q(i22);
            if (t == null) {
                if (q != null && s == 207 && !q.equals(nq0Var)) {
                    this.T = Long.rotateRight(Long.rotateRight(this.T ^ i21, 3) ^ q.hashCode(), 3);
                } else {
                    rotateRight2 = Long.rotateRight(Long.rotateRight(this.T ^ i21, 3) ^ s, 3);
                }
            } else {
                if (t instanceof Enum) {
                    hashCode2 = ((Enum) t).ordinal();
                } else {
                    hashCode2 = t.hashCode();
                }
                rotateRight2 = Long.rotateRight(Long.rotateRight(this.T, 3) ^ hashCode2, 3);
            }
            this.T = rotateRight2;
        } else {
            w51 w51Var3 = this.G;
            int i23 = w51Var3.i;
            int i24 = w51Var3.i(i23);
            w51 w51Var4 = this.G;
            Object p = w51Var4.p(w51Var4.b, i23);
            w51 w51Var5 = this.G;
            Object b = w51Var5.b(w51Var5.b, i23);
            if (p == null) {
                if (b != null && i24 == 207 && !b.equals(nq0Var)) {
                    this.T = Long.rotateRight(Long.rotateRight(this.T ^ i21, 3) ^ b.hashCode(), 3);
                } else {
                    rotateRight = Long.rotateRight(Long.rotateRight(this.T ^ i21, 3) ^ i24, 3);
                }
            } else {
                if (p instanceof Enum) {
                    hashCode = ((Enum) p).ordinal();
                } else {
                    hashCode = p.hashCode();
                }
                rotateRight = Long.rotateRight(Long.rotateRight(this.T, 3) ^ hashCode, 3);
            }
            this.T = rotateRight;
        }
        int i25 = this.l;
        g10 g10Var3 = this.j;
        ArrayList arrayList6 = this.s;
        pj pjVar = this.M;
        if (g10Var3 != null) {
            sj0 sj0Var = g10Var3.e;
            int i26 = g10Var3.b;
            ArrayList arrayList7 = g10Var3.a;
            if (arrayList7.size() > 0) {
                ArrayList arrayList8 = g10Var3.d;
                HashSet hashSet2 = new HashSet(arrayList8.size());
                int size = arrayList8.size();
                for (int i27 = 0; i27 < size; i27++) {
                    hashSet2.add(arrayList8.get(i27));
                }
                i = -1;
                ik0 ik0Var2 = o01.a;
                ik0 ik0Var3 = new ik0();
                int size2 = arrayList8.size();
                int size3 = arrayList7.size();
                int i28 = 0;
                int i29 = 0;
                int i30 = 0;
                while (i28 < size3) {
                    e90 e90Var = (e90) arrayList7.get(i28);
                    if (!hashSet2.contains(e90Var)) {
                        w60Var2 = w60Var3;
                        t20 t20Var = (t20) sj0Var.b(e90Var.c);
                        if (t20Var != null) {
                            i8 = t20Var.b;
                        } else {
                            i8 = -1;
                        }
                        int i31 = e90Var.c;
                        i9 = i28;
                        pjVar.e(i8 + i26, e90Var.d);
                        g10Var3.a(i31, 0);
                        pjVar.f = (i31 - pjVar.a.G.g) + pjVar.f;
                        this.G.r(i31);
                        I();
                        this.G.s();
                        vn.f(arrayList6, i31, this.G.b[(i31 * 5) + 3] + i31);
                    } else {
                        w60Var2 = w60Var3;
                        i9 = i28;
                        if (!ik0Var3.c(e90Var)) {
                            int i32 = i29;
                            if (i32 < size2) {
                                e90 e90Var2 = (e90) arrayList8.get(i32);
                                if (e90Var2 != e90Var) {
                                    t20 t20Var2 = (t20) sj0Var.b(e90Var2.c);
                                    if (t20Var2 != null) {
                                        i16 = t20Var2.b;
                                    } else {
                                        i16 = -1;
                                    }
                                    ik0Var3.a(e90Var2);
                                    i10 = i32;
                                    i13 = i30;
                                    g10Var2 = g10Var3;
                                    if (i16 != i13) {
                                        t20 t20Var3 = (t20) sj0Var.b(e90Var2.c);
                                        if (t20Var3 != null) {
                                            i17 = t20Var3.c;
                                        } else {
                                            i17 = e90Var2.d;
                                        }
                                        ik0Var = ik0Var3;
                                        int i33 = i16 + i26;
                                        i11 = size2;
                                        int i34 = i13 + i26;
                                        if (i17 > 0) {
                                            i12 = i26;
                                            int i35 = pjVar.l;
                                            if (i35 > 0) {
                                                arrayList4 = arrayList7;
                                                if (pjVar.j == i33 - i35 && pjVar.k == i34 - i35) {
                                                    pjVar.l = i35 + i17;
                                                }
                                            } else {
                                                arrayList4 = arrayList7;
                                            }
                                            pjVar.c();
                                            pjVar.j = i33;
                                            pjVar.k = i34;
                                            pjVar.l = i17;
                                        } else {
                                            i12 = i26;
                                            arrayList4 = arrayList7;
                                            pjVar.getClass();
                                        }
                                        if (i16 > i13) {
                                            Object[] objArr5 = sj0Var.c;
                                            long[] jArr5 = sj0Var.a;
                                            int length = jArr5.length - 2;
                                            if (length >= 0) {
                                                arrayList5 = arrayList8;
                                                hashSet = hashSet2;
                                                int i36 = 0;
                                                while (true) {
                                                    long j = jArr5[i36];
                                                    int i37 = i17;
                                                    arrayList3 = arrayList6;
                                                    if ((((~j) << 7) & j & (-9187201950435737472L)) != -9187201950435737472L) {
                                                        int i38 = 8 - ((~(i36 - length)) >>> 31);
                                                        int i39 = 0;
                                                        while (i39 < i38) {
                                                            if ((j & 255) < 128) {
                                                                i20 = i39;
                                                                t20 t20Var4 = (t20) objArr5[(i36 << 3) + i39];
                                                                objArr4 = objArr5;
                                                                int i40 = t20Var4.b;
                                                                jArr4 = jArr5;
                                                                if (i16 <= i40 && i40 < i16 + i37) {
                                                                    t20Var4.b = (i40 - i16) + i13;
                                                                } else if (i13 <= i40 && i40 < i16) {
                                                                    t20Var4.b = i40 + i37;
                                                                }
                                                            } else {
                                                                i20 = i39;
                                                                objArr4 = objArr5;
                                                                jArr4 = jArr5;
                                                            }
                                                            j >>= 8;
                                                            i39 = i20 + 1;
                                                            objArr5 = objArr4;
                                                            jArr5 = jArr4;
                                                        }
                                                        objArr3 = objArr5;
                                                        jArr3 = jArr5;
                                                        if (i38 != 8) {
                                                            break;
                                                        }
                                                    } else {
                                                        objArr3 = objArr5;
                                                        jArr3 = jArr5;
                                                    }
                                                    if (i36 == length) {
                                                        break;
                                                    }
                                                    i36++;
                                                    arrayList6 = arrayList3;
                                                    i17 = i37;
                                                    objArr5 = objArr3;
                                                    jArr5 = jArr3;
                                                }
                                            } else {
                                                arrayList3 = arrayList6;
                                            }
                                        } else {
                                            int i41 = i17;
                                            arrayList3 = arrayList6;
                                            arrayList5 = arrayList8;
                                            hashSet = hashSet2;
                                            if (i13 > i16) {
                                                Object[] objArr6 = sj0Var.c;
                                                long[] jArr6 = sj0Var.a;
                                                int length2 = jArr6.length - 2;
                                                if (length2 >= 0) {
                                                    int i42 = 0;
                                                    while (true) {
                                                        long j2 = jArr6[i42];
                                                        if ((((~j2) << 7) & j2 & (-9187201950435737472L)) != -9187201950435737472L) {
                                                            int i43 = 8 - ((~(i42 - length2)) >>> 31);
                                                            int i44 = 0;
                                                            while (i44 < i43) {
                                                                if ((j2 & 255) < 128) {
                                                                    objArr2 = objArr6;
                                                                    t20 t20Var5 = (t20) objArr6[(i42 << 3) + i44];
                                                                    jArr2 = jArr6;
                                                                    int i45 = t20Var5.b;
                                                                    i19 = i16;
                                                                    if (i16 <= i45 && i45 < i19 + i41) {
                                                                        t20Var5.b = (i45 - i19) + i13;
                                                                    } else if (i19 + 1 <= i45 && i45 < i13) {
                                                                        t20Var5.b = i45 - i41;
                                                                    }
                                                                } else {
                                                                    objArr2 = objArr6;
                                                                    jArr2 = jArr6;
                                                                    i19 = i16;
                                                                }
                                                                j2 >>= 8;
                                                                i44++;
                                                                jArr6 = jArr2;
                                                                objArr6 = objArr2;
                                                                i16 = i19;
                                                            }
                                                            objArr = objArr6;
                                                            jArr = jArr6;
                                                            i18 = i16;
                                                            if (i43 != 8) {
                                                                break;
                                                            }
                                                        } else {
                                                            objArr = objArr6;
                                                            jArr = jArr6;
                                                            i18 = i16;
                                                        }
                                                        if (i42 == length2) {
                                                            break;
                                                        }
                                                        i42++;
                                                        jArr6 = jArr;
                                                        objArr6 = objArr;
                                                        i16 = i18;
                                                    }
                                                }
                                            }
                                        }
                                        i14 = i9;
                                    } else {
                                        arrayList3 = arrayList6;
                                        ik0Var = ik0Var3;
                                        i11 = size2;
                                        i12 = i26;
                                        arrayList4 = arrayList7;
                                    }
                                    arrayList5 = arrayList8;
                                    hashSet = hashSet2;
                                    i14 = i9;
                                } else {
                                    i10 = i32;
                                    arrayList3 = arrayList6;
                                    ik0Var = ik0Var3;
                                    i11 = size2;
                                    i12 = i26;
                                    arrayList4 = arrayList7;
                                    arrayList5 = arrayList8;
                                    hashSet = hashSet2;
                                    i13 = i30;
                                    g10Var2 = g10Var3;
                                    i14 = i9 + 1;
                                }
                                i29 = i10 + 1;
                                t20 t20Var6 = (t20) sj0Var.b(e90Var2.c);
                                if (t20Var6 != null) {
                                    i15 = t20Var6.c;
                                } else {
                                    i15 = e90Var2.d;
                                }
                                int i46 = i13 + i15;
                                i28 = i14;
                                g10Var3 = g10Var2;
                                ik0Var3 = ik0Var;
                                size2 = i11;
                                i26 = i12;
                                arrayList7 = arrayList4;
                                arrayList8 = arrayList5;
                                hashSet2 = hashSet;
                                arrayList6 = arrayList3;
                                i30 = i46;
                                w60Var3 = w60Var2;
                            } else {
                                i29 = i32;
                                w60Var3 = w60Var2;
                                i28 = i9;
                            }
                        }
                    }
                    i28 = i9 + 1;
                    w60Var3 = w60Var2;
                }
                w60Var = w60Var3;
                arrayList = arrayList6;
                pjVar.c();
                if (arrayList7.size() > 0) {
                    w51 w51Var6 = this.G;
                    pjVar.f = (w51Var6.h - pjVar.a.G.g) + pjVar.f;
                    w51Var6.t();
                }
                z2 = this.S;
                if (!z2) {
                    w51 w51Var7 = this.G;
                    int i47 = w51Var7.m - w51Var7.l;
                    if (i47 > 0) {
                        if (i47 > 0) {
                            pjVar.d(false);
                            w60 w60Var4 = pjVar.d;
                            w51 w51Var8 = pjVar.a.G;
                            if (w51Var8.c > 0 && w60Var4.a(-2) != (i7 = w51Var8.i)) {
                                if (!pjVar.c && pjVar.e) {
                                    pjVar.d(false);
                                    pjVar.b.F.C(eo0.c);
                                    pjVar.c = true;
                                }
                                if (i7 > 0) {
                                    y00 a = w51Var8.a(i7);
                                    w60Var4.c(i7);
                                    pjVar.d(false);
                                    zo0 zo0Var = pjVar.b.F;
                                    zo0Var.C(do0.c);
                                    dd0.v(zo0Var, 0, a);
                                    pjVar.c = true;
                                }
                            }
                            zo0 zo0Var2 = pjVar.b.F;
                            zo0Var2.C(so0.c);
                            zo0Var2.d[zo0Var2.e - zo0Var2.b[zo0Var2.c - 1].a] = i47;
                        } else {
                            pjVar.getClass();
                        }
                    }
                }
                i2 = this.k;
                while (true) {
                    w51Var = this.G;
                    if (w51Var.k > 0 && (i6 = w51Var.g) != w51Var.h) {
                        I();
                        pjVar.e(i2, this.G.s());
                        vn.f(arrayList, i6, this.G.g);
                    }
                }
                if (!z2) {
                    if (z) {
                        bw bwVar = this.O;
                        zo0 zo0Var3 = bwVar.c;
                        if (zo0Var3.c == 0) {
                            qj.a("Cannot end node insertion, there are no pending operations that can be realized.");
                        }
                        zo0 zo0Var4 = bwVar.b;
                        xo0[] xo0VarArr = zo0Var3.b;
                        int i48 = zo0Var3.c - 1;
                        zo0Var3.c = i48;
                        xo0 xo0Var = xo0VarArr[i48];
                        xo0VarArr[i48] = null;
                        zo0Var4.C(xo0Var);
                        Object[] objArr7 = zo0Var3.f;
                        Object[] objArr8 = zo0Var4.f;
                        int i49 = zo0Var4.g;
                        int i50 = xo0Var.b;
                        int i51 = zo0Var3.g;
                        int i52 = i51 - i50;
                        System.arraycopy(objArr7, i52, objArr8, i49 - i50, i51 - i52);
                        Object[] objArr9 = zo0Var3.f;
                        int i53 = zo0Var3.g;
                        Arrays.fill(objArr9, i53 - i50, i53, (Object) null);
                        int[] iArr = zo0Var3.d;
                        int[] iArr2 = zo0Var4.d;
                        int i54 = zo0Var4.e;
                        int i55 = xo0Var.a;
                        int i56 = zo0Var3.e;
                        ba.W(iArr, iArr2, i54 - i55, i56 - i55, i56);
                        zo0Var3.g -= i50;
                        zo0Var3.e -= i55;
                        i25 = 1;
                    }
                    if (this.G.k <= 0) {
                        rt0.a("Unbalanced begin/end empty");
                    }
                    w51Var2.k--;
                    a61 a61Var2 = this.I;
                    int i57 = a61Var2.v;
                    a61Var2.j();
                    if (this.G.k <= 0) {
                        int i58 = (-2) - i57;
                        this.I.k();
                        this.I.e(true);
                        y00 y00Var = this.N;
                        boolean B = this.O.b.B();
                        x51 x51Var = this.H;
                        if (B) {
                            pjVar.b();
                            pjVar.d(false);
                            w60 w60Var5 = pjVar.d;
                            w51 w51Var9 = pjVar.a.G;
                            if (w51Var9.c > 0 && w60Var5.a(-2) != (i5 = w51Var9.i)) {
                                if (!pjVar.c && pjVar.e) {
                                    pjVar.d(false);
                                    pjVar.b.F.C(eo0.c);
                                    pjVar.c = true;
                                }
                                if (i5 > 0) {
                                    y00 a2 = w51Var9.a(i5);
                                    w60Var5.c(i5);
                                    pjVar.d(false);
                                    zo0 zo0Var5 = pjVar.b.F;
                                    zo0Var5.C(do0.c);
                                    dd0.v(zo0Var5, 0, a2);
                                    i4 = 1;
                                    pjVar.c = true;
                                    pjVar.c();
                                    zo0 zo0Var6 = pjVar.b.F;
                                    zo0Var6.C(go0.c);
                                    dd0.w(zo0Var6, 0, y00Var, i4, x51Var);
                                    r3 = 0;
                                }
                            }
                            i4 = 1;
                            pjVar.c();
                            zo0 zo0Var62 = pjVar.b.F;
                            zo0Var62.C(go0.c);
                            dd0.w(zo0Var62, 0, y00Var, i4, x51Var);
                            r3 = 0;
                        } else {
                            bw bwVar2 = this.O;
                            pjVar.b();
                            pjVar.d(false);
                            w60 w60Var6 = pjVar.d;
                            w51 w51Var10 = pjVar.a.G;
                            if (w51Var10.c > 0 && w60Var6.a(-2) != (i3 = w51Var10.i)) {
                                if (!pjVar.c && pjVar.e) {
                                    pjVar.d(false);
                                    pjVar.b.F.C(eo0.c);
                                    pjVar.c = true;
                                }
                                if (i3 > 0) {
                                    y00 a3 = w51Var10.a(i3);
                                    w60Var6.c(i3);
                                    pjVar.d(false);
                                    zo0 zo0Var7 = pjVar.b.F;
                                    zo0Var7.C(do0.c);
                                    dd0.v(zo0Var7, 0, a3);
                                    pjVar.c = true;
                                }
                            }
                            pjVar.c();
                            zo0 zo0Var8 = pjVar.b.F;
                            zo0Var8.C(ho0.c);
                            int i59 = zo0Var8.g - zo0Var8.b[zo0Var8.c - 1].b;
                            Object[] objArr10 = zo0Var8.f;
                            objArr10[i59] = y00Var;
                            objArr10[i59 + 1] = x51Var;
                            objArr10[i59 + 2] = bwVar2;
                            this.O = new bw();
                            r3 = 0;
                        }
                        this.S = r3;
                        if (this.c.f != 0) {
                            d0(i58, r3);
                            e0(i58, i25);
                        }
                    }
                } else {
                    if (z) {
                        pjVar.a();
                    }
                    int i60 = pjVar.a.G.i;
                    w60 w60Var7 = pjVar.d;
                    int i61 = i;
                    if (w60Var7.a(i61) > i60) {
                        qj.a("Missed recording an endGroup");
                    }
                    if (w60Var7.a(i61) == i60) {
                        pjVar.d(false);
                        w60Var7.b();
                        pjVar.b.F.C(ao0.c);
                    }
                    int i62 = this.G.i;
                    if (i25 != i0(i62)) {
                        e0(i62, i25);
                    }
                    if (z) {
                        i25 = 1;
                    }
                    this.G.e();
                    pjVar.c();
                }
                g10Var = (g10) this.i.remove(arrayList2.size() - 1);
                if (g10Var != null && !z2) {
                    g10Var.c++;
                }
                this.j = g10Var;
                this.k = w60Var.b() + i25;
                this.m = w60Var.b();
                this.l = w60Var.b() + i25;
            }
        }
        w60Var = w60Var3;
        arrayList = arrayList6;
        i = -1;
        z2 = this.S;
        if (!z2) {
        }
        i2 = this.k;
        while (true) {
            w51Var = this.G;
            if (w51Var.k > 0) {
                break;
            }
            I();
            pjVar.e(i2, this.G.s());
            vn.f(arrayList, i6, this.G.g);
        }
        if (!z2) {
        }
        g10Var = (g10) this.i.remove(arrayList2.size() - 1);
        if (g10Var != null) {
            g10Var.c++;
        }
        this.j = g10Var;
        this.k = w60Var.b() + i25;
        this.m = w60Var.b();
        this.l = w60Var.b() + i25;
    }

    public final void q() {
        p(false);
        xv0 x = x();
        if (x != null) {
            int i = x.b;
            if ((i & 1) != 0) {
                x.b = i | 2;
            }
        }
    }

    public final xv0 r() {
        xv0 xv0Var;
        xv0 xv0Var2;
        y00 a;
        wv0 wv0Var;
        ArrayList arrayList = this.E;
        if (!arrayList.isEmpty()) {
            xv0Var = (xv0) arrayList.remove(arrayList.size() - 1);
        } else {
            xv0Var = null;
        }
        if (xv0Var != null) {
            xv0Var.b &= -9;
            this.g.k();
            int i = this.B;
            zj0 zj0Var = xv0Var.f;
            if (zj0Var != null && (xv0Var.b & 16) == 0) {
                Object[] objArr = zj0Var.b;
                int[] iArr = zj0Var.c;
                long[] jArr = zj0Var.a;
                int length = jArr.length - 2;
                if (length >= 0) {
                    int i2 = 0;
                    loop0: while (true) {
                        long j = jArr[i2];
                        if ((((~j) << 7) & j & (-9187201950435737472L)) != -9187201950435737472L) {
                            int i3 = 8 - ((~(i2 - length)) >>> 31);
                            for (int i4 = 0; i4 < i3; i4++) {
                                if ((j & 255) < 128) {
                                    int i5 = (i2 << 3) + i4;
                                    Object obj = objArr[i5];
                                    if (iArr[i5] != i) {
                                        wv0Var = new wv0(i, 0, xv0Var, zj0Var);
                                        break loop0;
                                    }
                                }
                                j >>= 8;
                            }
                            if (i3 != 8) {
                                break;
                            }
                        }
                        if (i2 == length) {
                            break;
                        }
                        i2++;
                    }
                }
            }
            wv0Var = null;
            pj pjVar = this.M;
            if (wv0Var != null) {
                zo0 zo0Var = pjVar.b.F;
                zo0Var.C(zn0.c);
                dd0.w(zo0Var, 0, wv0Var, 1, this.h);
            }
            int i6 = xv0Var.b;
            if ((i6 & 512) != 0) {
                xv0Var.b = i6 & (-513);
                zo0 zo0Var2 = pjVar.b.F;
                zo0Var2.C(co0.c);
                dd0.v(zo0Var2, 0, xv0Var);
                int i7 = xv0Var.b;
                xv0Var.b = i7 & (-129);
                if ((i7 & 1024) != 0) {
                    xv0Var.b = i7 & (-1153);
                    this.y = false;
                }
            }
        }
        if (xv0Var != null) {
            int i8 = xv0Var.b;
            if ((i8 & 16) == 0 && ((i8 & 1) != 0 || this.q)) {
                if (xv0Var.c == null) {
                    if (this.S) {
                        a61 a61Var = this.I;
                        a = a61Var.b(a61Var.v);
                    } else {
                        w51 w51Var = this.G;
                        a = w51Var.a(w51Var.i);
                    }
                    xv0Var.c = a;
                }
                xv0Var.b &= -5;
                xv0Var2 = xv0Var;
                p(false);
                return xv0Var2;
            }
        }
        xv0Var2 = null;
        p(false);
        return xv0Var2;
    }

    public final void s() {
        if (this.F || this.z != 100) {
            rt0.a("Cannot disable reuse from root if it was caused by other groups");
        }
        this.z = -1;
        this.y = false;
    }

    public final void t() {
        boolean z = false;
        p(false);
        this.b.c();
        p(false);
        pj pjVar = this.M;
        if (pjVar.c) {
            pjVar.d(false);
            pjVar.d(false);
            pjVar.b.F.C(ao0.c);
            pjVar.c = false;
        }
        pjVar.b();
        if (pjVar.d.b != 0) {
            qj.a("Missed recording an endGroup()");
        }
        if (!this.i.isEmpty()) {
            qj.a("Start/end imbalance");
        }
        i();
        this.G.c();
        if (this.x.b() != 0) {
            z = true;
        }
        this.w = z;
    }

    public final void u(boolean z, g10 g10Var) {
        this.i.add(this.j);
        this.j = g10Var;
        int i = this.l;
        w60 w60Var = this.n;
        w60Var.c(i);
        w60Var.c(this.m);
        w60Var.c(this.k);
        if (z) {
            this.k = 0;
        }
        this.l = 0;
        this.m = 0;
    }

    public final void v() {
        x51 x51Var = new x51();
        if (this.C) {
            x51Var.b();
        }
        if (this.b.d()) {
            x51Var.o = new sj0();
        }
        this.H = x51Var;
        a61 e = x51Var.e();
        e.e(true);
        this.I = e;
    }

    public final uj w() {
        e10 e10Var = this.U;
        if (e10Var == null) {
            e10 e10Var2 = new e10(this.h);
            this.U = e10Var2;
            return e10Var2;
        }
        return e10Var;
    }

    public final xv0 x() {
        if (this.A == 0) {
            ArrayList arrayList = this.E;
            if (!arrayList.isEmpty()) {
                return (xv0) arrayList.get(arrayList.size() - 1);
            }
            return null;
        }
        return null;
    }

    public final boolean y() {
        if (A() && !this.w) {
            xv0 x = x();
            if (x == null || (x.b & 4) == 0) {
                return false;
            }
            return true;
        }
        return true;
    }

    public final wj z() {
        if (this.b.k()) {
            return this.Q;
        }
        return null;
    }
}