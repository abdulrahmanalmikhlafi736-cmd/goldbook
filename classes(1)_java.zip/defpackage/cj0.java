package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cj0  reason: default package */
public final class cj0 extends u91 implements m00 {
    public jw0 i;
    public jw0 j;
    public int k;
    public int l;
    public /* synthetic */ Object m;
    public final /* synthetic */ kw0 n;
    public final /* synthetic */ nw0 o;
    public final /* synthetic */ nw0 p;
    public final /* synthetic */ float q;
    public final /* synthetic */ tp r;
    public final /* synthetic */ float s;
    public final /* synthetic */ y11 t;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public cj0(kw0 kw0Var, nw0 nw0Var, nw0 nw0Var2, float f, tp tpVar, float f2, y11 y11Var, ml mlVar) {
        super(2, mlVar);
        this.n = kw0Var;
        this.o = nw0Var;
        this.p = nw0Var2;
        this.q = f;
        this.r = tpVar;
        this.s = f2;
        this.t = y11Var;
    }

    @Override // defpackage.m00
    public final Object f(Object obj, Object obj2) {
        return ((cj0) n((ml) obj2, (w11) obj)).p(we1.a);
    }

    @Override // defpackage.db
    public final ml n(ml mlVar, Object obj) {
        cj0 cj0Var = new cj0(this.n, this.o, this.p, this.q, this.r, this.s, this.t, mlVar);
        cj0Var.m = obj;
        return cj0Var;
    }

    /* JADX WARN: Removed duplicated region for block: B:15:0x0073  */
    /* JADX WARN: Removed duplicated region for block: B:32:0x014f  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x0188  */
    /* JADX WARN: Removed duplicated region for block: B:45:0x01b4 A[RETURN] */
    /* JADX WARN: Type inference failed for: r8v7, types: [kw0, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r9v0, types: [jw0, java.lang.Object] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:35:0x0175 -> B:36:0x0176). Please submit an issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:39:0x0188 -> B:38:0x0184). Please submit an issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:44:0x01a9 -> B:37:0x017e). Please submit an issue!!! */
    @Override // defpackage.db
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object p(Object obj) {
        w11 w11Var;
        jw0 jw0Var;
        char c;
        cm cmVar;
        int i;
        int i2;
        jw0 jw0Var2;
        w11 w11Var2;
        nw0 nw0Var;
        Object obj2;
        kw0 kw0Var;
        nw0 nw0Var2;
        cm cmVar2;
        int i3;
        boolean z;
        cj0 cj0Var = this;
        int i4 = cj0Var.l;
        nw0 nw0Var3 = cj0Var.p;
        kw0 kw0Var2 = cj0Var.n;
        char c2 = 3;
        int i5 = 2;
        int i6 = 1;
        nw0 nw0Var4 = cj0Var.o;
        cm cmVar3 = cm.e;
        if (i4 != 0) {
            if (i4 != 1) {
                if (i4 != 2) {
                    if (i4 == 3) {
                        jw0 jw0Var3 = cj0Var.j;
                        jw0Var2 = cj0Var.i;
                        nb0.t(obj);
                        jw0Var = jw0Var3;
                        c = 3;
                        i = 1;
                        cmVar = cmVar3;
                        w11Var2 = (w11) cj0Var.m;
                        Object b = obj;
                        i2 = 2;
                        nw0Var = nw0Var4;
                        jw0Var.e = ((Boolean) b).booleanValue();
                        nw0Var4 = nw0Var;
                        w11Var = w11Var2;
                        jw0Var = jw0Var2;
                        i5 = i2;
                        i6 = i;
                        cmVar3 = cmVar;
                        c2 = c;
                        z = jw0Var.e;
                        we1 we1Var = we1.a;
                        if (!z) {
                            jw0Var.e = false;
                            float floatValue = kw0Var2.e - ((Number) ((p8) nw0Var4.e).f.getValue()).floatValue();
                            boolean z2 = ((aj0) nw0Var3.e).c;
                            tp tpVar = cj0Var.r;
                            if (!z2) {
                                float abs = Math.abs(floatValue);
                                float f = cj0Var.q;
                                if (abs >= f) {
                                    float signum = Math.signum(floatValue) * f;
                                    tpVar.c(w11Var, signum);
                                    p8 p8Var = (p8) nw0Var4.e;
                                    p8 r = wl1.r(p8Var, ((Number) p8Var.f.getValue()).floatValue() + signum);
                                    nw0Var4.e = r;
                                    int P = gh0.P(Math.abs(kw0Var2.e - ((Number) r.f.getValue()).floatValue()) / cj0Var.s);
                                    if (P > 100) {
                                        P = 100;
                                    }
                                    p8 p8Var2 = (p8) nw0Var4.e;
                                    float f2 = kw0Var2.e;
                                    int i7 = P;
                                    tp tpVar2 = cj0Var.r;
                                    cmVar2 = cmVar3;
                                    kw0Var = kw0Var2;
                                    nw0Var2 = nw0Var3;
                                    l2 l2Var = new l2(tpVar2, nw0Var2, kw0Var, cj0Var.t, jw0Var, 1);
                                    cj0Var.m = w11Var;
                                    cj0Var.i = jw0Var;
                                    cj0Var.j = null;
                                    cj0Var.k = i7;
                                    cj0Var.l = i5;
                                    tpVar2.getClass();
                                    ?? obj3 = new Object();
                                    obj3.e = ((Number) p8Var2.f.getValue()).floatValue();
                                    Float f3 = new Float(f2);
                                    td1 I = zi1.I(i7, ls.b, i5);
                                    w11 w11Var3 = w11Var;
                                    ho hoVar = new ho(obj3, tpVar2, w11Var3, l2Var, 3);
                                    w11Var2 = w11Var3;
                                    Object c3 = wa0.c(p8Var2, f3, I, hoVar, cj0Var);
                                    if (c3 != cmVar2) {
                                        c3 = we1Var;
                                    }
                                    if (c3 == cmVar2) {
                                        return cmVar2;
                                    }
                                    i3 = i7;
                                    if (jw0Var.e) {
                                        cj0Var.m = w11Var2;
                                        cj0Var.i = jw0Var;
                                        cj0Var.j = jw0Var;
                                        cj0Var.l = 3;
                                        c = 3;
                                        cmVar = cmVar2;
                                        i = 1;
                                        nw0 nw0Var5 = nw0Var2;
                                        i2 = i5;
                                        nw0Var = nw0Var4;
                                        nw0Var3 = nw0Var5;
                                        kw0Var2 = kw0Var;
                                        b = tp.b(cj0Var.r, nw0Var3, kw0Var2, cj0Var.t, nw0Var, 50 - i3, cj0Var);
                                        if (b != cmVar) {
                                            jw0Var2 = jw0Var;
                                            jw0Var.e = ((Boolean) b).booleanValue();
                                            nw0Var4 = nw0Var;
                                            w11Var = w11Var2;
                                            jw0Var = jw0Var2;
                                            i5 = i2;
                                            i6 = i;
                                            cmVar3 = cmVar;
                                            c2 = c;
                                            z = jw0Var.e;
                                            we1 we1Var2 = we1.a;
                                            if (!z) {
                                                return we1Var2;
                                            }
                                        } else {
                                            return cmVar;
                                        }
                                    } else {
                                        nw0Var3 = nw0Var2;
                                        c = 3;
                                        w11Var = w11Var2;
                                        kw0Var2 = kw0Var;
                                        i6 = 1;
                                        cmVar3 = cmVar2;
                                        c2 = c;
                                        z = jw0Var.e;
                                        we1 we1Var22 = we1.a;
                                        if (!z) {
                                        }
                                    }
                                }
                            }
                            c = c2;
                            i2 = i5;
                            i = i6;
                            nw0Var = nw0Var4;
                            cmVar = cmVar3;
                            w11Var2 = w11Var;
                            tpVar.c(w11Var2, floatValue);
                            cj0Var.m = w11Var2;
                            cj0Var.i = jw0Var;
                            cj0Var.j = jw0Var;
                            cj0Var.l = i;
                            obj2 = tp.b(cj0Var.r, nw0Var3, kw0Var2, cj0Var.t, nw0Var, 50L, cj0Var);
                            if (obj2 == cmVar) {
                                return cmVar;
                            }
                            jw0Var2 = jw0Var;
                            jw0Var.e = ((Boolean) obj2).booleanValue();
                            cj0Var = this;
                            nw0Var4 = nw0Var;
                            w11Var = w11Var2;
                            jw0Var = jw0Var2;
                            i5 = i2;
                            i6 = i;
                            cmVar3 = cmVar;
                            c2 = c;
                            z = jw0Var.e;
                            we1 we1Var222 = we1.a;
                            if (!z) {
                            }
                        }
                    } else {
                        od.p("call to 'resume' before 'invoke' with coroutine");
                        return null;
                    }
                } else {
                    i3 = cj0Var.k;
                    jw0 jw0Var4 = cj0Var.i;
                    nb0.t(obj);
                    kw0Var = kw0Var2;
                    cmVar2 = cmVar3;
                    jw0Var = jw0Var4;
                    w11Var2 = (w11) cj0Var.m;
                    nw0Var2 = nw0Var3;
                    if (jw0Var.e) {
                    }
                }
            } else {
                jw0 jw0Var5 = cj0Var.j;
                jw0Var2 = cj0Var.i;
                nb0.t(obj);
                jw0Var = jw0Var5;
                c = 3;
                i = 1;
                cmVar = cmVar3;
                w11Var2 = (w11) cj0Var.m;
                obj2 = obj;
                i2 = 2;
                nw0Var = nw0Var4;
                jw0Var.e = ((Boolean) obj2).booleanValue();
                cj0Var = this;
                nw0Var4 = nw0Var;
                w11Var = w11Var2;
                jw0Var = jw0Var2;
                i5 = i2;
                i6 = i;
                cmVar3 = cmVar;
                c2 = c;
                z = jw0Var.e;
                we1 we1Var2222 = we1.a;
                if (!z) {
                }
            }
        } else {
            nb0.t(obj);
            w11Var = (w11) cj0Var.m;
            ?? obj4 = new Object();
            obj4.e = true;
            jw0Var = obj4;
            z = jw0Var.e;
            we1 we1Var22222 = we1.a;
            if (!z) {
            }
        }
    }
}