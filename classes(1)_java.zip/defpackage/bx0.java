package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bx0  reason: default package */
public final class bx0 {
    public final of0 a;

    public bx0(of0 of0Var) {
        this.a = of0Var;
    }

    public final String toString() {
        return "Removed[" + this.a + ']';
    }
}