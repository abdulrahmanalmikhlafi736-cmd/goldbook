package defpackage;

import android.graphics.Region;
import android.os.Build;
import android.view.View;
import java.util.ArrayList;
import java.util.Arrays;
import org.chromium.support_lib_boundary.StaticsBoundaryInterface;
import org.chromium.support_lib_boundary.WebSettingsBoundaryInterface;
import org.chromium.support_lib_boundary.WebViewProviderFactoryBoundaryInterface;
import org.chromium.support_lib_boundary.WebkitToCompatConverterBoundaryInterface;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cz0  reason: default package */
public class cz0 implements tw, cg1, vi1 {
    public final /* synthetic */ int e;
    public Object f;

    public cz0(long[] jArr) {
        vj0 vj0Var;
        this.e = 3;
        if (jArr != null) {
            long[] copyOf = Arrays.copyOf(jArr, jArr.length);
            vj0Var = new vj0(copyOf.length);
            int i = vj0Var.b;
            if (i >= 0) {
                if (copyOf.length != 0) {
                    int length = copyOf.length + i;
                    long[] jArr2 = vj0Var.a;
                    if (jArr2.length < length) {
                        vj0Var.a = Arrays.copyOf(jArr2, Math.max(length, (jArr2.length * 3) / 2));
                    }
                    long[] jArr3 = vj0Var.a;
                    int i2 = vj0Var.b;
                    if (i != i2) {
                        ba.X(jArr3, jArr3, copyOf.length + i, i, i2);
                    }
                    ba.X(copyOf, jArr3, i, 0, copyOf.length);
                    vj0Var.b += copyOf.length;
                }
            } else {
                od.f("");
                throw null;
            }
        } else {
            vj0Var = new vj0();
        }
        this.f = vj0Var;
    }

    @Override // defpackage.cg1
    public boolean a() {
        ((p3) this.f).getClass();
        return false;
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0021  */
    /* JADX WARN: Removed duplicated region for block: B:18:0x0032  */
    @Override // defpackage.tw
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public Object b(uw uwVar, ml mlVar) {
        r rVar;
        int i;
        yy0 yy0Var;
        if (mlVar instanceof r) {
            rVar = (r) mlVar;
            int i2 = rVar.k;
            if ((i2 & Integer.MIN_VALUE) != 0) {
                rVar.k = i2 - Integer.MIN_VALUE;
                Object obj = rVar.i;
                i = rVar.k;
                we1 we1Var = we1.a;
                if (i == 0) {
                    if (i == 1) {
                        yy0Var = rVar.h;
                        try {
                            nb0.t(obj);
                        } catch (Throwable th) {
                            th = th;
                            yy0Var.q();
                            throw th;
                        }
                    } else {
                        od.p("call to 'resume' before 'invoke' with coroutine");
                        return null;
                    }
                } else {
                    nb0.t(obj);
                    sl slVar = rVar.f;
                    slVar.getClass();
                    yy0 yy0Var2 = new yy0(uwVar, slVar);
                    try {
                        rVar.h = yy0Var2;
                        rVar.k = 1;
                        try {
                            Object f = ((m00) this.f).f(yy0Var2, rVar);
                            cm cmVar = cm.e;
                            if (f != cmVar) {
                                f = we1Var;
                            }
                            if (f == cmVar) {
                                return cmVar;
                            }
                            yy0Var = yy0Var2;
                        } catch (Throwable th2) {
                            th = th2;
                            yy0Var = yy0Var2;
                            yy0Var.q();
                            throw th;
                        }
                    } catch (Throwable th3) {
                        th = th3;
                    }
                }
                yy0Var.q();
                return we1Var;
            }
        }
        rVar = new r(this, mlVar);
        Object obj2 = rVar.i;
        i = rVar.k;
        we1 we1Var2 = we1.a;
        if (i == 0) {
        }
        yy0Var.q();
        return we1Var2;
    }

    @Override // defpackage.vi1
    public String[] e() {
        return ((WebViewProviderFactoryBoundaryInterface) this.f).getSupportedFeatures();
    }

    @Override // defpackage.cg1
    public u8 f(long j, u8 u8Var, u8 u8Var2, u8 u8Var3) {
        return ((p3) this.f).f(j, u8Var, u8Var2, u8Var3);
    }

    public long g(long j) {
        zo zoVar = (zo) this.f;
        zoVar.getClass();
        if (gg1.b(j) <= 0.0f || gg1.c(j) <= 0.0f) {
            p50.b("maximumVelocity should be a positive value. You specified=" + ((Object) gg1.f(j)));
        }
        return kb0.c(zoVar.a.b(gg1.b(j)), zoVar.b.b(gg1.c(j)));
    }

    @Override // defpackage.vi1
    public StaticsBoundaryInterface getStatics() {
        return (StaticsBoundaryInterface) ac.k(StaticsBoundaryInterface.class, ((WebViewProviderFactoryBoundaryInterface) this.f).getStatics());
    }

    @Override // defpackage.vi1
    public WebkitToCompatConverterBoundaryInterface getWebkitToCompatConverter() {
        return (WebkitToCompatConverterBoundaryInterface) ac.k(WebkitToCompatConverterBoundaryInterface.class, ((WebViewProviderFactoryBoundaryInterface) this.f).getWebkitToCompatConverter());
    }

    @Override // defpackage.cg1
    public u8 i(long j, u8 u8Var, u8 u8Var2, u8 u8Var3) {
        return ((p3) this.f).i(j, u8Var, u8Var2, u8Var3);
    }

    @Override // defpackage.cg1
    public u8 j(u8 u8Var, u8 u8Var2, u8 u8Var3) {
        return ((p3) this.f).j(u8Var, u8Var2, u8Var3);
    }

    @Override // defpackage.cg1
    public long k(u8 u8Var, u8 u8Var2, u8 u8Var3) {
        return ((p3) this.f).k(u8Var, u8Var2, u8Var3);
    }

    public hw l(int i) {
        switch (this.e) {
            case gu0.DOUBLE_FIELD_NUMBER /* 7 */:
                return ((iw[]) this.f)[i];
            case 8:
                return (iw) this.f;
            default:
                return (hw) this.f;
        }
    }

    public Object m(ye yeVar, xz xzVar) {
        r51 r51Var;
        z21 z21Var;
        int i;
        if (((fj) this.f) == null) {
            rt0.b("Called runAndWatch on a manager that has been disposed of");
        }
        fj fjVar = (fj) this.f;
        if ((fjVar instanceof r51) && (z21Var = (r51Var = (r51) fjVar).f) != null && !z21Var.equals(yeVar)) {
            nj0 nj0Var = new nj0();
            z21 z21Var2 = r51Var.f;
            if (z21Var2 == null) {
                rt0.b("promote must only be called when a manager is managing subscriptions for one channel and needs to start managing them for a second");
            }
            ik0 ik0Var = r51Var.d;
            ArrayList arrayList = nj0Var.c;
            if (ik0Var == null) {
                Object obj = r51Var.b;
                obj.getClass();
                arrayList.add(new kj0(obj, z21Var2));
            } else {
                Object[] objArr = ik0Var.b;
                long[] jArr = ik0Var.a;
                int length = jArr.length - 2;
                if (length >= 0) {
                    int i2 = 0;
                    while (true) {
                        long j = jArr[i2];
                        if ((((~j) << 7) & j & (-9187201950435737472L)) != -9187201950435737472L) {
                            int i3 = 8;
                            int i4 = 8 - ((~(i2 - length)) >>> 31);
                            int i5 = 0;
                            while (i5 < i4) {
                                if ((j & 255) < 128) {
                                    i = i3;
                                    arrayList.add(new kj0(objArr[(i2 << 3) + i5], z21Var2));
                                } else {
                                    i = i3;
                                }
                                j >>= i;
                                i5++;
                                i3 = i;
                            }
                            if (i4 != i3) {
                                break;
                            }
                        }
                        if (i2 == length) {
                            break;
                        }
                        i2++;
                    }
                }
            }
            nj0Var.d();
            r51Var.e();
            this.f = nj0Var;
        }
        fj fjVar2 = (fj) this.f;
        fjVar2.getClass();
        g61 u = n61.j().u(fjVar2.g(yeVar));
        fjVar2.c(yeVar);
        try {
            g61 j2 = u.j();
            Object a = xzVar.a();
            g61.q(j2);
            u.c();
            fjVar2.d();
            return a;
        } catch (Throwable th) {
            u.c();
            throw th;
        }
    }

    public void n(r60 r60Var) {
        ((Region) this.f).set(r60Var.a, r60Var.b, r60Var.c, r60Var.d);
    }

    public void o(int i) {
        ((WebSettingsBoundaryInterface) this.f).setForceDark(i);
    }

    public void p() {
        ((WebSettingsBoundaryInterface) this.f).setForceDarkBehavior(1);
    }

    public /* synthetic */ cz0(int i, boolean z) {
        this.e = i;
    }

    public cz0(int i) {
        this.e = i;
        switch (i) {
            case 11:
                this.f = new zo();
                return;
            default:
                this.f = new Region();
                return;
        }
    }

    public cz0(jp jpVar) {
        this.e = 5;
        this.f = new dw(n71.a, jpVar);
    }

    /* JADX WARN: Type inference failed for: r0v3, types: [x50, java.lang.Object, e71] */
    public cz0(View view) {
        this.e = 4;
        if (Build.VERSION.SDK_INT >= 30) {
            ?? x50Var = new x50(view, 1);
            x50Var.b = view;
            this.f = x50Var;
            return;
        }
        this.f = new x50(view, 1);
    }

    public /* synthetic */ cz0(int i, Object obj) {
        this.e = i;
        this.f = obj;
    }

    public cz0(float f, float f2, u8 u8Var) {
        cz0 cz0Var;
        this.e = 10;
        int i = dg1.a;
        if (u8Var != null) {
            cz0Var = new cz0(u8Var, f, f2);
        } else {
            cz0Var = new cz0(f, f2);
        }
        this.f = new p3(cz0Var);
    }

    public cz0(u8 u8Var, float f, float f2) {
        this.e = 7;
        int b = u8Var.b();
        iw[] iwVarArr = new iw[b];
        for (int i = 0; i < b; i++) {
            iwVarArr[i] = new iw(f, f2, u8Var.a(i));
        }
        this.f = iwVarArr;
    }

    public cz0(float f, float f2) {
        this.e = 8;
        this.f = new iw(f, f2, 0.01f);
    }
}