package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: eb1  reason: default package */
public final class eb1 {
    public final i71 a;
    public final i71 b;
    public final i71 c;
    public final i71 d;

    public eb1(i71 i71Var, i71 i71Var2, i71 i71Var3, i71 i71Var4) {
        this.a = i71Var;
        this.b = i71Var2;
        this.c = i71Var3;
        this.d = i71Var4;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || !(obj instanceof eb1)) {
            return false;
        }
        eb1 eb1Var = (eb1) obj;
        if (k70.p(this.a, eb1Var.a) && k70.p(this.b, eb1Var.b) && k70.p(this.c, eb1Var.c) && k70.p(this.d, eb1Var.d)) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        int i;
        int i2;
        int i3;
        int i4 = 0;
        i71 i71Var = this.a;
        if (i71Var != null) {
            i = i71Var.hashCode();
        } else {
            i = 0;
        }
        int i5 = i * 31;
        i71 i71Var2 = this.b;
        if (i71Var2 != null) {
            i2 = i71Var2.hashCode();
        } else {
            i2 = 0;
        }
        int i6 = (i5 + i2) * 31;
        i71 i71Var3 = this.c;
        if (i71Var3 != null) {
            i3 = i71Var3.hashCode();
        } else {
            i3 = 0;
        }
        int i7 = (i6 + i3) * 31;
        i71 i71Var4 = this.d;
        if (i71Var4 != null) {
            i4 = i71Var4.hashCode();
        }
        return i7 + i4;
    }
}