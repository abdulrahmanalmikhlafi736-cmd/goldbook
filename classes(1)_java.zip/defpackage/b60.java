package defpackage;

import android.graphics.Insets;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RenderNode;
import android.view.MotionEvent;
import android.view.WindowInsets;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: b60  reason: default package */
public abstract /* synthetic */ class b60 {
    public static /* bridge */ /* synthetic */ int c(Insets insets) {
        return insets.right;
    }

    public static /* synthetic */ RenderNode g() {
        return new RenderNode("AndroidEdgeEffectOverscrollEffect");
    }

    public static /* synthetic */ WindowInsets.Builder h() {
        return new WindowInsets.Builder();
    }

    public static /* synthetic */ WindowInsets.Builder i(WindowInsets windowInsets) {
        return new WindowInsets.Builder(windowInsets);
    }

    public static /* bridge */ /* synthetic */ void o(Paint paint, CharSequence charSequence, int i, int i2, Rect rect) {
        paint.getTextBounds(charSequence, i, i2, rect);
    }

    public static /* bridge */ /* synthetic */ int u(Insets insets) {
        return insets.bottom;
    }

    public static /* bridge */ /* synthetic */ int v(MotionEvent motionEvent) {
        return motionEvent.getClassification();
    }
}