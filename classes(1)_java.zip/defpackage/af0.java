package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: af0  reason: default package */
public abstract class af0 {
    public static final gk a = new gk(new i2(18));
}