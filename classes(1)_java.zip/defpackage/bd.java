package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bd  reason: default package */
public final class bd extends oa {
    public ne a;
    public i00 b;

    @Override // defpackage.oa
    public final void a() {
        this.b = null;
        this.a = null;
    }

    @Override // defpackage.oa
    public final void b(Throwable th) {
        ne neVar = this.a;
        if (neVar != null) {
            neVar.h(nb0.j(th));
        }
    }
}