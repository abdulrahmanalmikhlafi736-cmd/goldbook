package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cf  reason: default package */
public final class cf extends u91 implements m00 {
    public final /* synthetic */ int i = 0;
    public int j;
    public /* synthetic */ Object k;
    public final /* synthetic */ ff l;
    public final /* synthetic */ uw m;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public cf(ff ffVar, uw uwVar, Object obj, ml mlVar) {
        super(2, mlVar);
        this.l = ffVar;
        this.m = uwVar;
        this.k = obj;
    }

    @Override // defpackage.m00
    public final Object f(Object obj, Object obj2) {
        int i = this.i;
        we1 we1Var = we1.a;
        bm bmVar = (bm) obj;
        ml mlVar = (ml) obj2;
        switch (i) {
            case 0:
                return ((cf) n(mlVar, bmVar)).p(we1Var);
            default:
                return ((cf) n(mlVar, bmVar)).p(we1Var);
        }
    }

    @Override // defpackage.db
    public final ml n(ml mlVar, Object obj) {
        int i = this.i;
        uw uwVar = this.m;
        ff ffVar = this.l;
        switch (i) {
            case 0:
                return new cf(ffVar, uwVar, this.k, mlVar);
            default:
                cf cfVar = new cf(ffVar, uwVar, mlVar);
                cfVar.k = obj;
                return cfVar;
        }
    }

    /* JADX WARN: Type inference failed for: r7v0, types: [java.lang.Object, java.io.Serializable] */
    @Override // defpackage.db
    public final Object p(Object obj) {
        int i = this.i;
        we1 we1Var = we1.a;
        cm cmVar = cm.e;
        switch (i) {
            case 0:
                int i2 = this.j;
                if (i2 != 0) {
                    if (i2 == 1) {
                        nb0.t(obj);
                        return we1Var;
                    }
                    od.p("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                nb0.t(obj);
                n00 n00Var = this.l.i;
                Object obj2 = this.k;
                this.j = 1;
                if (n00Var.c(this.m, obj2, this) == cmVar) {
                    return cmVar;
                }
                return we1Var;
            default:
                int i3 = this.j;
                if (i3 != 0) {
                    if (i3 == 1) {
                        nb0.t(obj);
                        return we1Var;
                    }
                    od.p("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                nb0.t(obj);
                bm bmVar = (bm) this.k;
                ?? obj3 = new Object();
                ff ffVar = this.l;
                tw twVar = ffVar.h;
                ef efVar = new ef(obj3, bmVar, ffVar, this.m, 0);
                this.j = 1;
                if (twVar.b(efVar, this) == cmVar) {
                    return cmVar;
                }
                return we1Var;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public cf(ff ffVar, uw uwVar, ml mlVar) {
        super(2, mlVar);
        this.l = ffVar;
        this.m = uwVar;
    }
}