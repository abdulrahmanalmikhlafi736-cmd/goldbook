package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bb  reason: default package */
public final class bb extends li0 implements ds, vm0, g21 {
    public long s;
    public y41 t;
    public long u;
    public o90 v;
    public jb0 w;
    public y41 x;
    public jb0 y;

    @Override // defpackage.ds
    public final void C(da0 da0Var) {
        jb0 jb0Var;
        da0 da0Var2;
        r6 r6Var;
        float intBitsToFloat;
        da0 da0Var3 = da0Var;
        te teVar = da0Var3.e;
        if (this.t == vn.j) {
            if (!zg.c(this.s, zg.i)) {
                fu0.x(da0Var, this.s, 0L, 126);
                da0Var3 = da0Var;
            }
        } else {
            tv tvVar = tv.F;
            if (s51.a(teVar.f.t(), this.u) && da0Var3.getLayoutDirection() == this.v && k70.p(this.x, this.t)) {
                jb0Var = this.w;
                jb0Var.getClass();
            } else {
                sb0.r(this, new va(1, this, da0Var3));
                jb0Var = this.y;
                this.y = null;
            }
            this.w = jb0Var;
            this.u = teVar.f.t();
            this.v = da0Var3.getLayoutDirection();
            this.x = this.t;
            jb0Var.getClass();
            if (!zg.c(this.s, zg.i)) {
                long j = this.s;
                if (jb0Var instanceof ep0) {
                    gw0 gw0Var = ((ep0) jb0Var).b;
                    float f = gw0Var.a;
                    float f2 = gw0Var.b;
                    long floatToRawIntBits = (Float.floatToRawIntBits(f2) & 4294967295L) | (Float.floatToRawIntBits(f) << 32);
                    float f3 = gw0Var.c - gw0Var.a;
                    float f4 = gw0Var.d - gw0Var.b;
                    da0Var2 = da0Var;
                    da0Var2.k(j, floatToRawIntBits, (4294967295L & Float.floatToRawIntBits(f4)) | (Float.floatToRawIntBits(f3) << 32), tvVar, 3);
                } else {
                    da0Var2 = da0Var3;
                    if (jb0Var instanceof fp0) {
                        fp0 fp0Var = (fp0) jb0Var;
                        r6Var = fp0Var.c;
                        if (r6Var == null) {
                            my0 my0Var = fp0Var.b;
                            float f5 = my0Var.b;
                            float f6 = my0Var.a;
                            long floatToRawIntBits2 = (Float.floatToRawIntBits(f6) << 32) | (Float.floatToRawIntBits(f5) & 4294967295L);
                            long floatToRawIntBits3 = (Float.floatToRawIntBits(my0Var.d - f5) & 4294967295L) | (Float.floatToRawIntBits(my0Var.c - f6) << 32);
                            long floatToRawIntBits4 = (Float.floatToRawIntBits(intBitsToFloat) & 4294967295L) | (Float.floatToRawIntBits(Float.intBitsToFloat((int) (my0Var.h >> 32))) << 32);
                            int i = (int) (floatToRawIntBits2 >> 32);
                            int i2 = (int) (floatToRawIntBits2 & 4294967295L);
                            teVar.e.c.h(Float.intBitsToFloat(i), Float.intBitsToFloat(i2), Float.intBitsToFloat((int) (floatToRawIntBits3 >> 32)) + Float.intBitsToFloat(i), Float.intBitsToFloat((int) (floatToRawIntBits3 & 4294967295L)) + Float.intBitsToFloat(i2), Float.intBitsToFloat((int) (floatToRawIntBits4 >> 32)), Float.intBitsToFloat((int) (floatToRawIntBits4 & 4294967295L)), te.c(teVar, j, tvVar, 3));
                        }
                    } else if (jb0Var instanceof dp0) {
                        r6Var = ((dp0) jb0Var).b;
                    } else {
                        od.k();
                        return;
                    }
                    da0Var2.e(r6Var, j, tvVar);
                }
                da0Var2.c();
            }
        }
        da0Var2 = da0Var3;
        da0Var2.c();
    }

    @Override // defpackage.g21
    public final void Q(r21 r21Var) {
        p21.b(r21Var, this.t);
    }

    @Override // defpackage.g21
    public final /* synthetic */ boolean S() {
        return false;
    }

    @Override // defpackage.g21
    public final /* synthetic */ boolean T() {
        return false;
    }

    @Override // defpackage.ds
    public final /* synthetic */ void Z() {
    }

    @Override // defpackage.g21
    public final boolean e() {
        return false;
    }

    @Override // defpackage.vm0
    public final void z() {
        this.u = 9205357640488583168L;
        this.v = null;
        this.w = null;
        this.x = null;
        a5.x(this);
    }
}