package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bf  reason: default package */
public final class bf extends af {
    @Override // defpackage.af
    public final af a(sl slVar, int i, gd gdVar) {
        return new af(this.h, slVar, i, gdVar);
    }

    @Override // defpackage.af
    public final tw d() {
        return this.h;
    }

    @Override // defpackage.af
    public final Object e(uw uwVar, ml mlVar) {
        Object b = this.h.b(uwVar, mlVar);
        if (b == cm.e) {
            return b;
        }
        return we1.a;
    }
}