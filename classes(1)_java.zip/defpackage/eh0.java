package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: eh0  reason: default package */
public final /* synthetic */ class eh0 implements m00 {
    public final /* synthetic */ int e;
    public final /* synthetic */ ke1 f;
    public final /* synthetic */ pi g;

    public /* synthetic */ eh0(ke1 ke1Var, pi piVar, int i) {
        this.e = i;
        this.f = ke1Var;
        this.g = piVar;
    }

    @Override // defpackage.m00
    public final Object f(Object obj, Object obj2) {
        boolean z;
        int i = this.e;
        we1 we1Var = we1.a;
        boolean z2 = false;
        pi piVar = this.g;
        ke1 ke1Var = this.f;
        d10 d10Var = (d10) obj;
        int intValue = ((Integer) obj2).intValue();
        switch (i) {
            case 0:
                if ((intValue & 3) != 2) {
                    z2 = true;
                }
                if (d10Var.O(intValue & 1, z2)) {
                    qt0.a(vd1.A(-241536773, new eh0(ke1Var, piVar, 1), d10Var), d10Var, 6);
                } else {
                    d10Var.R();
                }
                return we1Var;
            default:
                if ((intValue & 3) != 2) {
                    z = true;
                } else {
                    z = false;
                }
                if (d10Var.O(intValue & 1, z)) {
                    za1.a(ke1Var.j, piVar, d10Var, 0);
                } else {
                    d10Var.R();
                }
                return we1Var;
        }
    }
}