package defpackage;

import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.CancellationSignal;
import android.view.ScrollCaptureCallback;
import android.view.ScrollCaptureSession;
import android.view.Surface;
import java.util.function.Consumer;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cj  reason: default package */
public final class cj implements ScrollCaptureCallback {
    public final i21 a;
    public final r60 b;
    public final bd0 c;
    public final n4 d;
    public final ll e;
    public final tw0 f;

    public cj(i21 i21Var, r60 r60Var, ll llVar, bd0 bd0Var, n4 n4Var) {
        this.a = i21Var;
        this.b = r60Var;
        this.c = bd0Var;
        this.d = n4Var;
        this.e = new ll(llVar.e.i(eq.f));
        this.f = new tw0(r60Var.d - r60Var.b, new gc1(this, null));
    }

    /* JADX WARN: Code restructure failed: missing block: B:31:0x008f, code lost:
        if (r9 == r4) goto L30;
     */
    /* JADX WARN: Removed duplicated region for block: B:10:0x0022  */
    /* JADX WARN: Removed duplicated region for block: B:16:0x0052  */
    /* JADX WARN: Removed duplicated region for block: B:36:0x00ae  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x00d7  */
    /* JADX WARN: Removed duplicated region for block: B:41:0x00da  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final Object a(cj cjVar, ScrollCaptureSession scrollCaptureSession, r60 r60Var, nl nlVar) {
        bj bjVar;
        int i;
        cm cmVar;
        int i2;
        int i3;
        i4 i4Var;
        sl slVar;
        ScrollCaptureSession scrollCaptureSession2;
        int i4;
        r60 r60Var2;
        int i5;
        int h;
        int h2;
        Surface surface;
        Surface surface2;
        Surface surface3;
        if (nlVar instanceof bj) {
            bjVar = (bj) nlVar;
            int i6 = bjVar.n;
            if ((i6 & Integer.MIN_VALUE) != 0) {
                bjVar.n = i6 - Integer.MIN_VALUE;
                Object obj = bjVar.l;
                i = bjVar.n;
                cmVar = cm.e;
                if (i == 0) {
                    if (i != 1) {
                        if (i == 2) {
                            i4 = bjVar.k;
                            i5 = bjVar.j;
                            r60Var2 = bjVar.i;
                            scrollCaptureSession2 = x3.h(bjVar.h);
                            nb0.t(obj);
                            tw0 tw0Var = cjVar.f;
                            h = sb0.h(i5 - gh0.P(tw0Var.c), 0, tw0Var.a);
                            tw0 tw0Var2 = cjVar.f;
                            h2 = sb0.h(i4 - gh0.P(tw0Var2.c), 0, tw0Var2.a);
                            int i7 = r60Var2.a;
                            int i8 = r60Var2.c;
                            if (h == h2) {
                                surface = scrollCaptureSession2.getSurface();
                                Canvas lockHardwareCanvas = surface.lockHardwareCanvas();
                                try {
                                    lockHardwareCanvas.save();
                                    lockHardwareCanvas.translate(-i7, -h);
                                    r60 r60Var3 = cjVar.b;
                                    lockHardwareCanvas.translate(-r60Var3.a, -r60Var3.b);
                                    cjVar.d.getRootView().draw(lockHardwareCanvas);
                                    surface3 = scrollCaptureSession2.getSurface();
                                    surface3.unlockCanvasAndPost(lockHardwareCanvas);
                                    int P = gh0.P(cjVar.f.c);
                                    return new r60(i7, h + P, i8, h2 + P);
                                } catch (Throwable th) {
                                    surface2 = scrollCaptureSession2.getSurface();
                                    surface2.unlockCanvasAndPost(lockHardwareCanvas);
                                    throw th;
                                }
                            }
                            return r60.e;
                        }
                        od.p("call to 'resume' before 'invoke' with coroutine");
                        return null;
                    }
                    int i9 = bjVar.k;
                    int i10 = bjVar.j;
                    r60 r60Var4 = bjVar.i;
                    ScrollCaptureSession h3 = x3.h(bjVar.h);
                    nb0.t(obj);
                    i2 = i10;
                    r60Var = r60Var4;
                    i3 = i9;
                    scrollCaptureSession = h3;
                } else {
                    nb0.t(obj);
                    i2 = r60Var.b;
                    i3 = r60Var.d;
                    tw0 tw0Var3 = cjVar.f;
                    bjVar.h = scrollCaptureSession;
                    bjVar.i = r60Var;
                    bjVar.j = i2;
                    bjVar.k = i3;
                    bjVar.n = 1;
                    int i11 = tw0Var3.a;
                    if (i2 <= i3) {
                        int i12 = i3 - i2;
                        if (i12 <= i11) {
                            float f = tw0Var3.c;
                            int i13 = (i2 > f ? 1 : (i2 == f ? 0 : -1));
                            Object obj2 = we1.a;
                            if (i13 < 0 || i3 > i11 + f) {
                                Object a = tw0Var3.a((((i12 / 2) + i2) - (i11 / 2)) - f, bjVar);
                                if (a != cmVar) {
                                    a = obj2;
                                }
                                if (a == cmVar) {
                                    obj2 = a;
                                }
                            }
                        } else {
                            throw new IllegalArgumentException(fu0.D(i12, i11, "Expected range (", ") to be ≤ viewportSize=").toString());
                        }
                    } else {
                        throw new IllegalArgumentException(fu0.D(i2, i3, "Expected min=", " ≤ max=").toString());
                    }
                }
                i4Var = i4.s;
                bjVar.h = scrollCaptureSession;
                bjVar.i = r60Var;
                bjVar.j = i2;
                bjVar.k = i3;
                bjVar.n = 2;
                slVar = bjVar.f;
                slVar.getClass();
                if (sb0.o(slVar).c(i4Var, bjVar) != cmVar) {
                    scrollCaptureSession2 = scrollCaptureSession;
                    i4 = i3;
                    r60Var2 = r60Var;
                    i5 = i2;
                    tw0 tw0Var4 = cjVar.f;
                    h = sb0.h(i5 - gh0.P(tw0Var4.c), 0, tw0Var4.a);
                    tw0 tw0Var22 = cjVar.f;
                    h2 = sb0.h(i4 - gh0.P(tw0Var22.c), 0, tw0Var22.a);
                    int i72 = r60Var2.a;
                    int i82 = r60Var2.c;
                    if (h == h2) {
                    }
                }
                return cmVar;
            }
        }
        bjVar = new bj(cjVar, nlVar);
        Object obj3 = bjVar.l;
        i = bjVar.n;
        cmVar = cm.e;
        if (i == 0) {
        }
        i4Var = i4.s;
        bjVar.h = scrollCaptureSession;
        bjVar.i = r60Var;
        bjVar.j = i2;
        bjVar.k = i3;
        bjVar.n = 2;
        slVar = bjVar.f;
        slVar.getClass();
        if (sb0.o(slVar).c(i4Var, bjVar) != cmVar) {
        }
        return cmVar;
    }

    public final void onScrollCaptureEnd(Runnable runnable) {
        wl1.B(this.e, mm0.f, new d(this, runnable, null, 5), 2);
    }

    public final void onScrollCaptureImageRequest(ScrollCaptureSession scrollCaptureSession, CancellationSignal cancellationSignal, Rect rect, Consumer consumer) {
        final s71 B = wl1.B(this.e, null, new aj(this, scrollCaptureSession, rect, consumer, null, 0), 3);
        B.r(new j3(8, cancellationSignal));
        cancellationSignal.setOnCancelListener(new CancellationSignal.OnCancelListener() { // from class: dj
            @Override // android.os.CancellationSignal.OnCancelListener
            public final void onCancel() {
                s71.this.a(null);
            }
        });
    }

    public final void onScrollCaptureSearch(CancellationSignal cancellationSignal, Consumer consumer) {
        consumer.accept(dd0.x(this.b));
    }

    public final void onScrollCaptureStart(ScrollCaptureSession scrollCaptureSession, CancellationSignal cancellationSignal, Runnable runnable) {
        this.f.c = 0.0f;
        this.c.a.setValue(Boolean.TRUE);
        runnable.run();
    }
}