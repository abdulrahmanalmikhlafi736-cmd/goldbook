package defpackage;

/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: au  reason: default package */
public final class au extends qi0 {
    public final ed1 a;
    public final zc1 b;
    public final zc1 c;
    public final ju d;
    public final wu e;
    public final xz f;
    public final bu g;

    public au(ed1 ed1Var, zc1 zc1Var, zc1 zc1Var2, ju juVar, wu wuVar, xz xzVar, bu buVar) {
        this.a = ed1Var;
        this.b = zc1Var;
        this.c = zc1Var2;
        this.d = juVar;
        this.e = wuVar;
        this.f = xzVar;
        this.g = buVar;
    }

    @Override // defpackage.qi0
    public final li0 e() {
        return new iu(this.a, this.b, this.c, this.d, this.e, this.f, this.g);
    }

    public final boolean equals(Object obj) {
        if (obj instanceof au) {
            au auVar = (au) obj;
            if (auVar.a == this.a && k70.p(auVar.b, this.b) && k70.p(auVar.c, this.c) && auVar.d.equals(this.d) && k70.p(auVar.e, this.e) && auVar.f == this.f && k70.p(auVar.g, this.g)) {
                return true;
            }
            return false;
        }
        return false;
    }

    @Override // defpackage.qi0
    public final void f(li0 li0Var) {
        iu iuVar = (iu) li0Var;
        iuVar.s = this.a;
        iuVar.t = this.b;
        iuVar.u = this.c;
        iuVar.v = this.d;
        iuVar.w = this.e;
        iuVar.x = this.f;
        iuVar.y = this.g;
    }

    public final int hashCode() {
        int i;
        int hashCode = this.a.hashCode() * 31;
        int i2 = 0;
        zc1 zc1Var = this.b;
        if (zc1Var != null) {
            i = zc1Var.hashCode();
        } else {
            i = 0;
        }
        int i3 = (hashCode + i) * 31;
        zc1 zc1Var2 = this.c;
        if (zc1Var2 != null) {
            i2 = zc1Var2.hashCode();
        }
        int hashCode2 = this.d.a.hashCode();
        int hashCode3 = this.e.a.hashCode();
        return this.g.hashCode() + ((this.f.hashCode() + ((hashCode3 + ((hashCode2 + ((i3 + i2) * 961)) * 31)) * 31)) * 31);
    }
}