package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bu  reason: default package */
public final /* synthetic */ class bu {
    public final /* synthetic */ zc1 a;
    public final /* synthetic */ zc1 b;
    public final /* synthetic */ ed1 c;
    public final /* synthetic */ ju d;
    public final /* synthetic */ wu e;
    public final /* synthetic */ zc1 f;

    public /* synthetic */ bu(zc1 zc1Var, zc1 zc1Var2, ed1 ed1Var, ju juVar, wu wuVar, zc1 zc1Var3) {
        this.a = zc1Var;
        this.b = zc1Var2;
        this.c = ed1Var;
        this.d = juVar;
        this.e = wuVar;
        this.f = zc1Var3;
    }
}