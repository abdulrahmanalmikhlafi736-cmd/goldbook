package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: az  reason: default package */
public abstract class az {
    public static final al a = new al(23);

    static {
        new nq0();
    }
}