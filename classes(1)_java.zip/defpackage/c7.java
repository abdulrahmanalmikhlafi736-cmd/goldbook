package defpackage;

import android.view.Choreographer;
import java.util.ArrayList;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: c7  reason: default package */
public final class c7 implements Choreographer.FrameCallback, Runnable {
    public final /* synthetic */ d7 e;

    public c7(d7 d7Var) {
        this.e = d7Var;
    }

    @Override // android.view.Choreographer.FrameCallback
    public final void doFrame(long j) {
        this.e.h.removeCallbacks(this);
        d7.j(this.e);
        d7 d7Var = this.e;
        synchronized (d7Var.i) {
            if (!d7Var.n) {
                return;
            }
            d7Var.n = false;
            ArrayList arrayList = d7Var.k;
            d7Var.k = d7Var.l;
            d7Var.l = arrayList;
            int size = arrayList.size();
            for (int i = 0; i < size; i++) {
                ((Choreographer.FrameCallback) arrayList.get(i)).doFrame(j);
            }
            arrayList.clear();
        }
    }

    @Override // java.lang.Runnable
    public final void run() {
        d7.j(this.e);
        d7 d7Var = this.e;
        synchronized (d7Var.i) {
            if (d7Var.k.isEmpty()) {
                d7Var.g.removeFrameCallback(this);
                d7Var.n = false;
            }
        }
    }
}