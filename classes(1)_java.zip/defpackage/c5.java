package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: c5  reason: default package */
public abstract class c5 {
    public static final gk a = new gk(b5.g);
    public static final k81 b = new lv0(b5.h);
    public static final gk c = new gk(i4.i);
    public static final k81 d = new lv0(b5.i);
    public static final k81 e = new lv0(b5.j);
    public static final k81 f = new lv0(b5.k);

    public static final void a(String str) {
        throw new IllegalStateException(("CompositionLocal " + str + " not present").toString());
    }
}