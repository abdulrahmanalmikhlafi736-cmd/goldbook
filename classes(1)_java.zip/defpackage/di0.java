package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: di0  reason: default package */
public final class di0 {
    public static di0 h;
    public final o90 a;
    public final ob1 b;
    public final mp c;
    public final yy d;
    public final ob1 e;
    public float f = Float.NaN;
    public float g = Float.NaN;

    public di0(o90 o90Var, ob1 ob1Var, mp mpVar, yy yyVar) {
        this.a = o90Var;
        this.b = ob1Var;
        this.c = mpVar;
        this.d = yyVar;
        this.e = wa0.v(ob1Var, o90Var);
    }
}