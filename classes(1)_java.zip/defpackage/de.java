package defpackage;

import android.graphics.Matrix;
import android.view.View;
import android.view.ViewParent;
import java.util.ArrayList;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: de  reason: default package */
public final class de implements ce {
    public final int[] a;
    public final float[] b;

    public de(ArrayList arrayList, ArrayList arrayList2) {
        int size = arrayList.size();
        this.a = new int[size];
        this.b = new float[size];
        for (int i = 0; i < size; i++) {
            this.a[i] = ((Integer) arrayList.get(i)).intValue();
            this.b[i] = ((Float) arrayList2.get(i)).floatValue();
        }
    }

    @Override // defpackage.ce
    public void a(View view, float[] fArr) {
        dd0.t(fArr);
        b(view, fArr);
    }

    public void b(View view, float[] fArr) {
        ViewParent parent = view.getParent();
        boolean z = parent instanceof View;
        float[] fArr2 = this.b;
        if (z) {
            b((View) parent, fArr);
            dd0.t(fArr2);
            dd0.y(fArr2, -view.getScrollX(), -view.getScrollY());
            a5.C(fArr, fArr2);
            dd0.t(fArr2);
            dd0.y(fArr2, view.getLeft(), view.getTop());
            a5.C(fArr, fArr2);
        } else {
            int[] iArr = this.a;
            view.getLocationInWindow(iArr);
            dd0.t(fArr2);
            dd0.y(fArr2, -view.getScrollX(), -view.getScrollY());
            a5.C(fArr, fArr2);
            dd0.t(fArr2);
            dd0.y(fArr2, iArr[0], iArr[1]);
            a5.C(fArr, fArr2);
        }
        Matrix matrix = view.getMatrix();
        if (!matrix.isIdentity()) {
            vn.Q(fArr2, matrix);
            a5.C(fArr, fArr2);
        }
    }

    public de(int i, int i2) {
        this.a = new int[]{i, i2};
        this.b = new float[]{0.0f, 1.0f};
    }

    public de(int i, int i2, int i3) {
        this.a = new int[]{i, i2, i3};
        this.b = new float[]{0.0f, 0.5f, 1.0f};
    }

    public de(float[] fArr) {
        this.b = fArr;
        this.a = new int[2];
    }
}