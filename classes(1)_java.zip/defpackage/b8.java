package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: b8  reason: default package */
public final class b8 extends u91 implements i00 {
    public final /* synthetic */ c8 i;
    public final /* synthetic */ br j;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public b8(c8 c8Var, br brVar, ml mlVar) {
        super(1, mlVar);
        this.i = c8Var;
        this.j = brVar;
    }

    @Override // defpackage.i00
    public final Object i(Object obj) {
        b8 b8Var = new b8(this.i, this.j, (ml) obj);
        we1 we1Var = we1.a;
        b8Var.p(we1Var);
        return we1Var;
    }

    @Override // defpackage.db
    public final Object p(Object obj) {
        nb0.t(obj);
        c8 c8Var = this.i;
        c8.b(c8Var);
        Object a = c8.a(c8Var, this.j);
        c8Var.c.f.setValue(a);
        c8Var.e.setValue(a);
        return we1.a;
    }
}