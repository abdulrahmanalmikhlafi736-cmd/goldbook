package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: e90  reason: default package */
public final class e90 {
    public final int a;
    public final Object b;
    public final int c;
    public final int d;

    public e90(Object obj, int i, int i2, int i3) {
        this.a = i;
        this.b = obj;
        this.c = i2;
        this.d = i3;
    }
}