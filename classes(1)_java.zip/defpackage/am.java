package defpackage;

import java.io.Closeable;
import java.lang.Thread;
import java.util.ArrayList;
import java.util.concurrent.Executor;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicLongFieldUpdater;
import java.util.concurrent.locks.LockSupport;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: am */
public final class am implements Executor, Closeable {
    public static final /* synthetic */ AtomicLongFieldUpdater l = AtomicLongFieldUpdater.newUpdater(am.class, "parkedWorkersStack$volatile");
    public static final /* synthetic */ AtomicLongFieldUpdater m = AtomicLongFieldUpdater.newUpdater(am.class, "controlState$volatile");
    public static final /* synthetic */ AtomicIntegerFieldUpdater n = AtomicIntegerFieldUpdater.newUpdater(am.class, "_isTerminated$volatile");
    public static final mt o = new mt("NOT_IN_STACK", 1);
    private volatile /* synthetic */ int _isTerminated$volatile;
    private volatile /* synthetic */ long controlState$volatile;
    public final int e;
    public final int f;
    public final long g;
    public final String h;
    public final r10 i;
    public final r10 j;
    public final jx0 k;
    private volatile /* synthetic */ long parkedWorkersStack$volatile;

    /* JADX WARN: Type inference failed for: r4v3, types: [r10, pf0] */
    /* JADX WARN: Type inference failed for: r4v4, types: [r10, pf0] */
    public am(int i, int i2, long j, String str) {
        this.e = i;
        this.f = i2;
        this.g = j;
        this.h = str;
        if (i >= 1) {
            if (i2 >= i) {
                if (i2 <= 2097150) {
                    if (j > 0) {
                        this.i = new pf0();
                        this.j = new pf0();
                        this.k = new jx0((i + 1) * 2);
                        this.controlState$volatile = i << 42;
                        return;
                    }
                    throw new IllegalArgumentException(("Idle worker keep alive time " + j + " must be positive").toString());
                }
                od.g("Max pool size ", i2, " should not exceed maximal supported number of threads 2097150");
                throw null;
            }
            throw new IllegalArgumentException(fu0.D(i2, i, "Max pool size ", " should be greater than or equals to core pool size ").toString());
        }
        od.g("Core pool size ", i, " should be at least 1");
        throw null;
    }

    public static /* synthetic */ void c(am amVar, Runnable runnable, int i) {
        boolean z;
        if ((i & 4) != 0) {
            z = false;
        } else {
            z = true;
        }
        amVar.b(runnable, false, z);
    }

    public final int a() {
        boolean z;
        synchronized (this.k) {
            try {
                if (n.get(this) == 1) {
                    z = true;
                } else {
                    z = false;
                }
                if (z) {
                    return -1;
                }
                AtomicLongFieldUpdater atomicLongFieldUpdater = m;
                long j = atomicLongFieldUpdater.get(this);
                int i = (int) (j & 2097151);
                int i2 = i - ((int) ((j & 4398044413952L) >> 21));
                if (i2 < 0) {
                    i2 = 0;
                }
                if (i2 >= this.e) {
                    return 0;
                }
                if (i >= this.f) {
                    return 0;
                }
                int i3 = ((int) (atomicLongFieldUpdater.get(this) & 2097151)) + 1;
                if (i3 > 0 && this.k.b(i3) == null) {
                    yl ylVar = new yl(this, i3);
                    this.k.c(i3, ylVar);
                    if (i3 == ((int) (2097151 & atomicLongFieldUpdater.incrementAndGet(this)))) {
                        int i4 = i2 + 1;
                        ylVar.start();
                        return i4;
                    }
                    throw new IllegalArgumentException("Failed requirement.");
                }
                throw new IllegalArgumentException("Failed requirement.");
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void b(Runnable runnable, boolean z, boolean z2) {
        ka1 la1Var;
        long j;
        yl ylVar;
        boolean a;
        zl zlVar;
        ma1.f.getClass();
        long nanoTime = System.nanoTime();
        if (runnable instanceof ka1) {
            la1Var = (ka1) runnable;
            la1Var.e = nanoTime;
            la1Var.f = z;
        } else {
            la1Var = new la1(runnable, nanoTime, z);
        }
        boolean z3 = la1Var.f;
        AtomicLongFieldUpdater atomicLongFieldUpdater = m;
        if (z3) {
            j = atomicLongFieldUpdater.addAndGet(this, 2097152L);
        } else {
            j = 0;
        }
        Thread currentThread = Thread.currentThread();
        if (currentThread instanceof yl) {
            ylVar = (yl) currentThread;
        } else {
            ylVar = null;
        }
        if (ylVar == null || ylVar.l != this) {
            ylVar = null;
        }
        if (ylVar != null && (zlVar = ylVar.g) != zl.i && (la1Var.f || zlVar != zl.f)) {
            ylVar.k = true;
            kl1 kl1Var = ylVar.e;
            if (z2) {
                la1Var = kl1Var.a(la1Var);
            } else {
                kl1Var.getClass();
                ka1 ka1Var = (ka1) kl1.b.getAndSet(kl1Var, la1Var);
                if (ka1Var == null) {
                    la1Var = null;
                } else {
                    la1Var = kl1Var.a(ka1Var);
                }
            }
        }
        if (la1Var != null) {
            if (la1Var.f) {
                a = this.j.a(la1Var);
            } else {
                a = this.i.a(la1Var);
            }
            if (!a) {
                throw new RejectedExecutionException(this.h + " was terminated");
            }
        }
        if (z3) {
            if (!f() && !e(j)) {
                f();
            }
        } else if (f() || e(atomicLongFieldUpdater.get(this))) {
        } else {
            f();
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:102:0x0083, code lost:
        if (r1 == null) goto L48;
     */
    @Override // java.io.Closeable, java.lang.AutoCloseable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void close() {
        yl ylVar;
        int i;
        ka1 ka1Var;
        if (!n.compareAndSet(this, 0, 1)) {
            return;
        }
        Thread currentThread = Thread.currentThread();
        if (currentThread instanceof yl) {
            ylVar = (yl) currentThread;
        } else {
            ylVar = null;
        }
        if (ylVar == null || ylVar.l != this) {
            ylVar = null;
        }
        synchronized (this.k) {
            i = (int) (m.get(this) & 2097151);
        }
        if (1 <= i) {
            int i2 = 1;
            while (true) {
                Object b = this.k.b(i2);
                b.getClass();
                yl ylVar2 = (yl) b;
                if (ylVar2 != ylVar) {
                    while (ylVar2.getState() != Thread.State.TERMINATED) {
                        LockSupport.unpark(ylVar2);
                        ylVar2.join(10000L);
                    }
                    kl1 kl1Var = ylVar2.e;
                    r10 r10Var = this.j;
                    kl1Var.getClass();
                    ka1 ka1Var2 = (ka1) kl1.b.getAndSet(kl1Var, null);
                    if (ka1Var2 != null) {
                        r10Var.a(ka1Var2);
                    }
                    while (true) {
                        ka1 b2 = kl1Var.b();
                        if (b2 == null) {
                            break;
                        }
                        r10Var.a(b2);
                    }
                }
                if (i2 == i) {
                    break;
                }
                i2++;
            }
        }
        this.j.b();
        this.i.b();
        while (true) {
            if (ylVar != null) {
                ka1Var = ylVar.a(true);
            }
            ka1Var = (ka1) this.i.d();
            if (ka1Var == null && (ka1Var = (ka1) this.j.d()) == null) {
                break;
            }
            try {
                ka1Var.run();
            } catch (Throwable th) {
                Thread currentThread2 = Thread.currentThread();
                currentThread2.getUncaughtExceptionHandler().uncaughtException(currentThread2, th);
            }
        }
        if (ylVar != null) {
            ylVar.h(zl.i);
        }
        l.set(this, 0L);
        m.set(this, 0L);
    }

    public final void d(yl ylVar, int i, int i2) {
        while (true) {
            long j = l.get(this);
            int i3 = (int) (2097151 & j);
            long j2 = (2097152 + j) & (-2097152);
            if (i3 == i) {
                if (i2 == 0) {
                    Object c = ylVar.c();
                    while (true) {
                        if (c == o) {
                            i3 = -1;
                            break;
                        } else if (c == null) {
                            i3 = 0;
                            break;
                        } else {
                            yl ylVar2 = (yl) c;
                            int b = ylVar2.b();
                            if (b != 0) {
                                i3 = b;
                                break;
                            }
                            c = ylVar2.c();
                        }
                    }
                } else {
                    i3 = i2;
                }
            }
            if (i3 >= 0) {
                am amVar = this;
                if (l.compareAndSet(amVar, j, i3 | j2)) {
                    return;
                }
                this = amVar;
            }
        }
    }

    public final boolean e(long j) {
        int i = ((int) (2097151 & j)) - ((int) ((j & 4398044413952L) >> 21));
        if (i < 0) {
            i = 0;
        }
        int i2 = this.e;
        if (i < i2) {
            int a = a();
            if (a == 1 && i2 > 1) {
                a();
            }
            if (a > 0) {
                return true;
            }
        }
        return false;
    }

    @Override // java.util.concurrent.Executor
    public final void execute(Runnable runnable) {
        c(this, runnable, 6);
    }

    public final boolean f() {
        am amVar;
        mt mtVar;
        int i;
        while (true) {
            long j = l.get(this);
            yl ylVar = (yl) this.k.b((int) (2097151 & j));
            if (ylVar == null) {
                ylVar = null;
                amVar = this;
            } else {
                long j2 = (2097152 + j) & (-2097152);
                Object c = ylVar.c();
                while (true) {
                    mtVar = o;
                    if (c == mtVar) {
                        i = -1;
                        break;
                    } else if (c == null) {
                        i = 0;
                        break;
                    } else {
                        yl ylVar2 = (yl) c;
                        i = ylVar2.b();
                        if (i != 0) {
                            break;
                        }
                        c = ylVar2.c();
                        j = j;
                    }
                }
                if (i >= 0) {
                    am amVar2 = this;
                    boolean compareAndSet = l.compareAndSet(amVar2, j, i | j2);
                    amVar = amVar2;
                    if (compareAndSet) {
                        ylVar.g(mtVar);
                    }
                    this = amVar;
                } else {
                    continue;
                }
            }
            if (ylVar == null) {
                return false;
            }
            if (yl.m.compareAndSet(ylVar, -1, 0)) {
                LockSupport.unpark(ylVar);
                return true;
            }
            this = amVar;
        }
    }

    public final String toString() {
        int i;
        ArrayList arrayList = new ArrayList();
        jx0 jx0Var = this.k;
        int a = jx0Var.a();
        int i2 = 0;
        int i3 = 0;
        int i4 = 0;
        int i5 = 0;
        int i6 = 0;
        for (int i7 = 1; i7 < a; i7++) {
            yl ylVar = (yl) jx0Var.b(i7);
            if (ylVar != null) {
                kl1 kl1Var = ylVar.e;
                kl1Var.getClass();
                if (kl1.b.get(kl1Var) != null) {
                    i = (kl1.c.get(kl1Var) - kl1.d.get(kl1Var)) + 1;
                } else {
                    i = kl1.c.get(kl1Var) - kl1.d.get(kl1Var);
                }
                int ordinal = ylVar.g.ordinal();
                if (ordinal != 0) {
                    if (ordinal != 1) {
                        if (ordinal != 2) {
                            if (ordinal != 3) {
                                if (ordinal == 4) {
                                    i6++;
                                } else {
                                    od.k();
                                    return null;
                                }
                            } else {
                                i5++;
                                if (i > 0) {
                                    StringBuilder sb = new StringBuilder();
                                    sb.append(i);
                                    sb.append('d');
                                    arrayList.add(sb.toString());
                                }
                            }
                        } else {
                            i4++;
                        }
                    } else {
                        i3++;
                        StringBuilder sb2 = new StringBuilder();
                        sb2.append(i);
                        sb2.append('b');
                        arrayList.add(sb2.toString());
                    }
                } else {
                    i2++;
                    StringBuilder sb3 = new StringBuilder();
                    sb3.append(i);
                    sb3.append('c');
                    arrayList.add(sb3.toString());
                }
            }
        }
        long j = m.get(this);
        StringBuilder sb4 = new StringBuilder();
        sb4.append(this.h);
        sb4.append('@');
        sb4.append(vn.y(this));
        sb4.append("[Pool Size {core = ");
        int i8 = this.e;
        sb4.append(i8);
        sb4.append(", max = ");
        sb4.append(this.f);
        sb4.append("}, Worker States {CPU = ");
        sb4.append(i2);
        sb4.append(", blocking = ");
        sb4.append(i3);
        sb4.append(", parked = ");
        sb4.append(i4);
        sb4.append(", dormant = ");
        sb4.append(i5);
        sb4.append(", terminated = ");
        sb4.append(i6);
        sb4.append("}, running workers queues = ");
        sb4.append(arrayList);
        sb4.append(", global CPU queue size = ");
        sb4.append(this.i.c());
        sb4.append(", global blocking queue size = ");
        sb4.append(this.j.c());
        sb4.append(", Control State {created workers= ");
        sb4.append((int) (2097151 & j));
        sb4.append(", blocking tasks = ");
        sb4.append((int) ((4398044413952L & j) >> 21));
        sb4.append(", CPUs acquired = ");
        sb4.append(i8 - ((int) ((j & 9223367638808264704L) >> 42)));
        sb4.append("}]");
        return sb4.toString();
    }
}