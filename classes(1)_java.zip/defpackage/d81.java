package defpackage;

import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: d81  reason: default package */
public final class d81 extends m0 implements tw, x00, b81, uw {
    public static final /* synthetic */ AtomicReferenceFieldUpdater j = AtomicReferenceFieldUpdater.newUpdater(d81.class, Object.class, "_state$volatile");
    private volatile /* synthetic */ Object _state$volatile;
    public int i;

    public d81(Object obj) {
        this._state$volatile = obj;
    }

    /* JADX WARN: Code restructure failed: missing block: B:39:0x0090, code lost:
        r1 = r1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x0094, code lost:
        if (r13.equals(r15) != false) goto L26;
     */
    /* JADX WARN: Code restructure failed: missing block: B:62:0x00f4, code lost:
        if (r15 == r2) goto L40;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:10:0x0024  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x005f  */
    /* JADX WARN: Removed duplicated region for block: B:33:0x0082 A[Catch: all -> 0x0038, TryCatch #0 {all -> 0x0038, blocks: (B:14:0x0034, B:31:0x007a, B:33:0x0082, B:36:0x0089, B:37:0x008d, B:39:0x0090, B:49:0x00b1, B:52:0x00c1, B:53:0x00dd, B:59:0x00ed, B:56:0x00e4, B:58:0x00ea, B:41:0x0096, B:45:0x009d, B:21:0x004b), top: B:66:0x0022 }] */
    /* JADX WARN: Removed duplicated region for block: B:43:0x009a  */
    /* JADX WARN: Removed duplicated region for block: B:44:0x009c  */
    /* JADX WARN: Removed duplicated region for block: B:47:0x00af  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x00b0  */
    /* JADX WARN: Removed duplicated region for block: B:51:0x00c0  */
    /* JADX WARN: Removed duplicated region for block: B:52:0x00c1 A[Catch: all -> 0x0038, TryCatch #0 {all -> 0x0038, blocks: (B:14:0x0034, B:31:0x007a, B:33:0x0082, B:36:0x0089, B:37:0x008d, B:39:0x0090, B:49:0x00b1, B:52:0x00c1, B:53:0x00dd, B:59:0x00ed, B:56:0x00e4, B:58:0x00ea, B:41:0x0096, B:45:0x009d, B:21:0x004b), top: B:66:0x0022 }] */
    /* JADX WARN: Type inference failed for: r1v0, types: [int] */
    /* JADX WARN: Type inference failed for: r1v1 */
    /* JADX WARN: Type inference failed for: r1v10, types: [e81] */
    /* JADX WARN: Type inference failed for: r1v2, types: [n0] */
    /* JADX WARN: Type inference failed for: r1v4 */
    /* JADX WARN: Type inference failed for: r1v5 */
    /* JADX WARN: Type inference failed for: r1v7, types: [e81] */
    /* JADX WARN: Type inference failed for: r8v1, types: [m0] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:51:0x00c0 -> B:31:0x007a). Please submit an issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:62:0x00f4 -> B:31:0x007a). Please submit an issue!!! */
    @Override // defpackage.tw
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final Object b(uw uwVar, ml mlVar) {
        c81 c81Var;
        e81 e81Var;
        cm cmVar;
        d81 d81Var;
        uw uwVar2;
        a80 a80Var;
        Object obj;
        Object andSet;
        Object obj2;
        Object obj3;
        try {
            if (mlVar instanceof c81) {
                c81Var = (c81) mlVar;
                int i = c81Var.o;
                if ((i & Integer.MIN_VALUE) != 0) {
                    c81Var.o = i - Integer.MIN_VALUE;
                    Object obj4 = c81Var.m;
                    e81Var = c81Var.o;
                    cmVar = cm.e;
                    if (e81Var == 0) {
                        if (e81Var != 1) {
                            if (e81Var != 2) {
                                if (e81Var == 3) {
                                    obj = c81Var.l;
                                    a80Var = c81Var.k;
                                    e81Var = c81Var.j;
                                    uwVar2 = c81Var.i;
                                    d81Var = c81Var.h;
                                    nb0.t(obj4);
                                    obj2 = j.get(d81Var);
                                    if (a80Var != null && !a80Var.b()) {
                                        throw a80Var.o();
                                    }
                                    if (obj2 == wl1.k) {
                                        obj3 = null;
                                    } else {
                                        obj3 = obj2;
                                    }
                                    c81Var.h = d81Var;
                                    c81Var.i = uwVar2;
                                    c81Var.j = e81Var;
                                    c81Var.k = a80Var;
                                    c81Var.l = obj2;
                                    c81Var.o = 2;
                                    if (uwVar2.k(obj3, c81Var) != cmVar) {
                                        obj = obj2;
                                        e81Var = e81Var;
                                        AtomicReference atomicReference = e81Var.a;
                                        mt mtVar = ac.B;
                                        andSet = atomicReference.getAndSet(mtVar);
                                        andSet.getClass();
                                        if (andSet == ac.C) {
                                            c81Var.h = d81Var;
                                            c81Var.i = uwVar2;
                                            c81Var.j = e81Var;
                                            c81Var.k = a80Var;
                                            c81Var.l = obj;
                                            c81Var.o = 3;
                                            Object obj5 = we1.a;
                                            ne neVar = new ne(1, ac.x(c81Var));
                                            neVar.t();
                                            AtomicReference atomicReference2 = e81Var.a;
                                            while (true) {
                                                if (!atomicReference2.compareAndSet(mtVar, neVar)) {
                                                    if (atomicReference2.get() != mtVar) {
                                                        neVar.h(obj5);
                                                        break;
                                                    }
                                                } else {
                                                    break;
                                                }
                                            }
                                            Object s = neVar.s();
                                            if (s == cmVar) {
                                                obj5 = s;
                                            }
                                        }
                                        obj2 = j.get(d81Var);
                                        if (a80Var != null) {
                                            throw a80Var.o();
                                        }
                                        if (obj2 == wl1.k) {
                                        }
                                        c81Var.h = d81Var;
                                        c81Var.i = uwVar2;
                                        c81Var.j = e81Var;
                                        c81Var.k = a80Var;
                                        c81Var.l = obj2;
                                        c81Var.o = 2;
                                        if (uwVar2.k(obj3, c81Var) != cmVar) {
                                        }
                                    } else {
                                        return cmVar;
                                    }
                                } else {
                                    od.p("call to 'resume' before 'invoke' with coroutine");
                                    return null;
                                }
                            } else {
                                obj = c81Var.l;
                                a80Var = c81Var.k;
                                e81 e81Var2 = c81Var.j;
                                uwVar2 = c81Var.i;
                                d81Var = c81Var.h;
                                nb0.t(obj4);
                                e81Var = e81Var2;
                                AtomicReference atomicReference3 = e81Var.a;
                                mt mtVar2 = ac.B;
                                andSet = atomicReference3.getAndSet(mtVar2);
                                andSet.getClass();
                                if (andSet == ac.C) {
                                }
                                obj2 = j.get(d81Var);
                                if (a80Var != null) {
                                }
                                if (obj2 == wl1.k) {
                                }
                                c81Var.h = d81Var;
                                c81Var.i = uwVar2;
                                c81Var.j = e81Var;
                                c81Var.k = a80Var;
                                c81Var.l = obj2;
                                c81Var.o = 2;
                                if (uwVar2.k(obj3, c81Var) != cmVar) {
                                }
                            }
                        } else {
                            e81Var = c81Var.j;
                            uwVar = c81Var.i;
                            this = c81Var.h;
                            try {
                                nb0.t(obj4);
                            } catch (Throwable th) {
                                d81Var = this;
                                th = th;
                                d81Var.f(e81Var);
                                throw th;
                            }
                        }
                    } else {
                        nb0.t(obj4);
                        e81Var = (e81) a();
                    }
                    sl slVar = c81Var.f;
                    slVar.getClass();
                    d81Var = this;
                    uwVar2 = uwVar;
                    a80Var = (a80) slVar.k(e3.S);
                    obj = null;
                    obj2 = j.get(d81Var);
                    if (a80Var != null) {
                    }
                    if (obj2 == wl1.k) {
                    }
                    c81Var.h = d81Var;
                    c81Var.i = uwVar2;
                    c81Var.j = e81Var;
                    c81Var.k = a80Var;
                    c81Var.l = obj2;
                    c81Var.o = 2;
                    if (uwVar2.k(obj3, c81Var) != cmVar) {
                    }
                }
            }
            if (e81Var == 0) {
            }
            sl slVar2 = c81Var.f;
            slVar2.getClass();
            d81Var = this;
            uwVar2 = uwVar;
            a80Var = (a80) slVar2.k(e3.S);
            obj = null;
            obj2 = j.get(d81Var);
            if (a80Var != null) {
            }
            if (obj2 == wl1.k) {
            }
            c81Var.h = d81Var;
            c81Var.i = uwVar2;
            c81Var.j = e81Var;
            c81Var.k = a80Var;
            c81Var.l = obj2;
            c81Var.o = 2;
            if (uwVar2.k(obj3, c81Var) != cmVar) {
            }
        } catch (Throwable th2) {
            th = th2;
        }
        c81Var = new c81(this, mlVar);
        Object obj42 = c81Var.m;
        e81Var = c81Var.o;
        cmVar = cm.e;
    }

    @Override // defpackage.x00
    public final tw c(sl slVar, int i, gd gdVar) {
        if ((((i >= 0 && i < 2) || i == -2) && gdVar == gd.f) || ((i == 0 || i == -3) && gdVar == gd.e)) {
            return this;
        }
        return new af(this, slVar, i, gdVar);
    }

    @Override // defpackage.m0
    public final n0 d() {
        return new e81();
    }

    @Override // defpackage.m0
    public final n0[] e() {
        return new e81[2];
    }

    @Override // defpackage.b81
    public final Object getValue() {
        mt mtVar = wl1.k;
        Object obj = j.get(this);
        if (obj == mtVar) {
            return null;
        }
        return obj;
    }

    public final void h(Object obj) {
        if (obj == null) {
            obj = wl1.k;
        }
        i(null, obj);
    }

    public final boolean i(Object obj, Object obj2) {
        int i;
        n0[] n0VarArr;
        mt mtVar;
        synchronized (this) {
            AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = j;
            Object obj3 = atomicReferenceFieldUpdater.get(this);
            if (obj != null && !k70.p(obj3, obj)) {
                return false;
            }
            if (k70.p(obj3, obj2)) {
                return true;
            }
            atomicReferenceFieldUpdater.set(this, obj2);
            int i2 = this.i;
            if ((i2 & 1) == 0) {
                int i3 = i2 + 1;
                this.i = i3;
                n0[] n0VarArr2 = this.e;
                while (true) {
                    e81[] e81VarArr = (e81[]) n0VarArr2;
                    if (e81VarArr != null) {
                        for (e81 e81Var : e81VarArr) {
                            if (e81Var != null) {
                                AtomicReference atomicReference = e81Var.a;
                                while (true) {
                                    Object obj4 = atomicReference.get();
                                    if (obj4 != null && obj4 != (mtVar = ac.C)) {
                                        mt mtVar2 = ac.B;
                                        if (obj4 == mtVar2) {
                                            while (!atomicReference.compareAndSet(obj4, mtVar)) {
                                                if (atomicReference.get() != obj4) {
                                                    break;
                                                }
                                            }
                                        } else {
                                            while (!atomicReference.compareAndSet(obj4, mtVar2)) {
                                                if (atomicReference.get() != obj4) {
                                                    break;
                                                }
                                            }
                                            ((ne) obj4).h(we1.a);
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    synchronized (this) {
                        i = this.i;
                        if (i == i3) {
                            this.i = i3 + 1;
                            return true;
                        }
                        n0VarArr = this.e;
                    }
                    n0VarArr2 = n0VarArr;
                    i3 = i;
                }
            } else {
                this.i = i2 + 2;
                return true;
            }
        }
    }

    @Override // defpackage.uw
    public final Object k(Object obj, ml mlVar) {
        h(obj);
        return we1.a;
    }
}