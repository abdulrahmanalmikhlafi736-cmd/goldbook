package defpackage;

import android.view.KeyEvent;
import android.view.ViewGroup;
import android.view.ViewParent;
import java.util.ArrayList;
import java.util.List;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dg  reason: default package */
public class dg extends dp implements gt0, f90, g21, kd1, ak, vm0, d50, o10 {
    public static final nq0 P = new nq0(10);
    public final vy A;
    public t40 B;
    public p10 C;
    public cp D;
    public ou0 E;
    public m30 F;
    public final wj0 G;
    public long H;
    public ou0 I;
    public uj0 J;
    public boolean K;
    public s71 L;
    public final nq0 M;
    public dt0 N;
    public v40 O;
    public uj0 u;
    public t40 v;
    public boolean w;
    public iy0 x;
    public boolean y;
    public xz z;

    public dg(uj0 uj0Var, t40 t40Var, boolean z, boolean z2, iy0 iy0Var, xz xzVar) {
        boolean z3;
        this.u = uj0Var;
        this.v = t40Var;
        this.w = z;
        this.x = iy0Var;
        this.y = z2;
        this.z = xzVar;
        this.A = new vy(uj0Var, new e(1, this, dg.class, "onFocusChange", "onFocusChange(Z)V", 0, 0, 0));
        int i = vf0.a;
        this.G = new wj0(6);
        this.H = 0L;
        uj0 uj0Var2 = this.u;
        this.J = uj0Var2;
        if (uj0Var2 == null) {
            z3 = true;
        } else {
            z3 = false;
        }
        this.K = z3;
        this.M = P;
    }

    @Override // defpackage.o10
    public final /* synthetic */ boolean A(v40 v40Var) {
        return false;
    }

    /* JADX WARN: Code restructure failed: missing block: B:31:0x00cc, code lost:
        if (((r7 & ((~r7) << 6)) & r14) == 0) goto L46;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x00ce, code lost:
        r16 = -1;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r17v1, types: [boolean] */
    /* JADX WARN: Type inference failed for: r1v7, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r2v6 */
    @Override // defpackage.f90
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final boolean I(KeyEvent keyEvent) {
        ?? r17;
        int i;
        ou0 ou0Var;
        y0();
        long b = ac.b(keyEvent.getKeyCode());
        boolean z = this.y;
        wj0 wj0Var = this.G;
        int i2 = 1;
        if (z && a5.v(keyEvent) == 2 && gh0.D(keyEvent)) {
            if (!wj0Var.b(b)) {
                ou0 ou0Var2 = new ou0(this.H);
                wj0Var.f(b, ou0Var2);
                if (this.u == null) {
                    return true;
                }
                wl1.B(d0(), null, new j(this, ou0Var2, null, 2), 3);
                return true;
            }
        } else if (this.y && a5.v(keyEvent) == 1 && gh0.D(keyEvent)) {
            int i3 = ((int) ((b >>> 32) ^ b)) * (-862048943);
            int i4 = i3 ^ (i3 << 16);
            int i5 = i4 & 127;
            int i6 = wj0Var.d;
            int i7 = (i4 >>> 7) & i6;
            int i8 = 0;
            loop0: while (true) {
                long[] jArr = wj0Var.a;
                int i9 = i7 >> 3;
                int i10 = (i7 & 7) << 3;
                r17 = i2;
                long j = (((-i10) >> 63) & (jArr[i9 + i2] << (64 - i10))) | (jArr[i9] >>> i10);
                long j2 = (i5 * 72340172838076673L) ^ j;
                long j3 = -9187201950435737472L;
                long j4 = (~j2) & (j2 - 72340172838076673L) & (-9187201950435737472L);
                while (true) {
                    if (j4 == 0) {
                        break;
                    }
                    i = (i7 + (Long.numberOfTrailingZeros(j4) >> 3)) & i6;
                    long j5 = j3;
                    if (wj0Var.b[i] == b) {
                        break loop0;
                    }
                    j4 &= j4 - 1;
                    j3 = j5;
                }
                i8 += 8;
                i7 = (i7 + i8) & i6;
                i2 = r17 == true ? 1 : 0;
            }
            if (i >= 0) {
                wj0Var.e--;
                long[] jArr2 = wj0Var.a;
                int i11 = wj0Var.d;
                int i12 = i >> 3;
                int i13 = (i & 7) << 3;
                long j6 = (jArr2[i12] & (~(255 << i13))) | (254 << i13);
                jArr2[i12] = j6;
                jArr2[(((i - 7) & i11) + (i11 & 7)) >> 3] = j6;
                ?? r1 = wj0Var.c;
                ?? r2 = r1[i];
                r1[i] = 0;
                ou0Var = r2;
            } else {
                ou0Var = null;
            }
            ou0 ou0Var3 = ou0Var;
            if (ou0Var3 != null) {
                if (this.u != null) {
                    wl1.B(d0(), null, new j(this, ou0Var3, null, 3), 3);
                }
                this.z.a();
            }
            if (ou0Var3 == null) {
                return false;
            }
            return r17;
        }
        return false;
    }

    @Override // defpackage.gt0
    public final /* synthetic */ boolean J() {
        return false;
    }

    @Override // defpackage.gt0
    public final void L() {
        R();
    }

    @Override // defpackage.g21
    public final void Q(r21 r21Var) {
        iy0 iy0Var = this.x;
        if (iy0Var != null) {
            p21.a(r21Var, iy0Var.a);
        }
        b bVar = new b(this, 1);
        a90[] a90VarArr = p21.a;
        r21Var.a(c21.b, new o0(null, bVar));
        if (this.y) {
            this.A.Q(r21Var);
        } else {
            r21Var.a(n21.j, we1.a);
        }
        u0(r21Var);
    }

    @Override // defpackage.gt0
    public final void R() {
        m30 m30Var;
        uj0 uj0Var = this.u;
        if (uj0Var != null && (m30Var = this.F) != null) {
            uj0Var.b(new n30(m30Var));
        }
        this.F = null;
        v0(false);
    }

    @Override // defpackage.g21
    public final /* synthetic */ boolean S() {
        return false;
    }

    @Override // defpackage.g21
    public final boolean T() {
        return true;
    }

    @Override // defpackage.gt0
    public final /* synthetic */ void a0() {
    }

    @Override // defpackage.o10
    public final /* synthetic */ boolean c(dt0 dt0Var) {
        return false;
    }

    @Override // defpackage.g21
    public final /* synthetic */ boolean e() {
        return true;
    }

    @Override // defpackage.li0
    public final boolean e0() {
        return false;
    }

    @Override // defpackage.li0
    public final void h0() {
        z();
        if (!this.K) {
            y0();
        }
        if (this.y) {
            r0(this.A);
        }
    }

    @Override // defpackage.li0
    public final void i0() {
        R();
    }

    @Override // defpackage.kd1
    public final Object j() {
        return this.M;
    }

    @Override // defpackage.li0
    public final void j0() {
        w0();
        if (this.J == null) {
            this.u = null;
        }
        cp cpVar = this.D;
        if (cpVar != null) {
            s0(cpVar);
        }
        this.D = null;
        p10 p10Var = this.C;
        if (p10Var != null) {
            s0(p10Var);
        }
        this.C = null;
    }

    @Override // defpackage.gt0
    public final long l() {
        return zi1.y;
    }

    @Override // defpackage.d50
    public final void s() {
        v0(true);
    }

    public void u0(r21 r21Var) {
    }

    /* JADX WARN: Type inference failed for: r11v10, types: [jw0, java.lang.Object] */
    @Override // defpackage.d50
    public final void v(i6 i6Var, at0 at0Var) {
        boolean z;
        uj0 uj0Var;
        ArrayList arrayList = (ArrayList) i6Var.c;
        y0();
        if (this.y && this.C == null) {
            p10 p10Var = new p10(this);
            r0(p10Var);
            this.C = p10Var;
        }
        if (at0Var == at0.f) {
            if (this.O == null) {
                int size = arrayList.size();
                for (int i = 0; i < size; i++) {
                    if (k70.v((v40) arrayList.get(i))) {
                        v40 v40Var = (v40) arrayList.get(0);
                        v40Var.i = true;
                        this.O = v40Var;
                        if (this.y && (uj0Var = this.u) != null) {
                            ou0 ou0Var = new ou0(v40Var.c);
                            ?? obj = new Object();
                            mc0.E(this, p10.t, new a2(new c(6, v40Var, obj), 1));
                            if (!obj.e) {
                                int i2 = eg.b;
                                ViewParent parent = gh0.N(this).getParent();
                                while (parent != null && (parent instanceof ViewGroup)) {
                                    ViewGroup viewGroup = (ViewGroup) parent;
                                    if (!viewGroup.shouldDelayChildPressedState()) {
                                        parent = viewGroup.getParent();
                                    }
                                }
                                this.I = ou0Var;
                                wl1.B(d0(), null, new h(uj0Var, ou0Var, null, 1), 3);
                                return;
                            }
                            this.L = wl1.B(d0(), null, new i(uj0Var, ou0Var, this, null, 0), 3);
                            return;
                        }
                        return;
                    }
                }
                return;
            }
            int size2 = arrayList.size();
            for (int i3 = 0; i3 < size2; i3++) {
                v40 v40Var2 = (v40) arrayList.get(i3);
                if (v40Var2.i || !v40Var2.h || v40Var2.d) {
                    float b = ((yg1) j70.z(this, fk.t)).b();
                    int size3 = arrayList.size();
                    for (int i4 = 0; i4 < size3; i4++) {
                        v40 v40Var3 = (v40) arrayList.get(i4);
                        long j = v40Var3.c;
                        v40 v40Var4 = this.O;
                        v40Var4.getClass();
                        if (Math.abs(xm0.c(xm0.e(j, v40Var4.c))) > b) {
                            z = true;
                        } else {
                            z = false;
                        }
                        if (v40Var3.i || z) {
                            v0(true);
                            return;
                        }
                    }
                    return;
                }
            }
            ((v40) arrayList.get(0)).i = true;
            if (this.y) {
                v40 v40Var5 = this.O;
                v40Var5.getClass();
                x0(v40Var5.c, true);
                this.z.a();
            }
            this.O = null;
        } else if (at0Var == at0.g && this.O != null) {
            int size4 = arrayList.size();
            for (int i5 = 0; i5 < size4; i5++) {
                v40 v40Var6 = (v40) arrayList.get(i5);
                if (v40Var6.i && v40Var6 != this.O) {
                    v0(true);
                    return;
                }
            }
        }
    }

    public final void v0(boolean z) {
        ou0 ou0Var;
        sq sqVar;
        if (z) {
            this.O = null;
        } else {
            this.N = null;
        }
        uj0 uj0Var = this.u;
        if (uj0Var != null) {
            s71 s71Var = this.L;
            if (s71Var != null && s71Var.b()) {
                s71 s71Var2 = this.L;
                if (s71Var2 != null) {
                    s71Var2.a(null);
                }
            } else {
                if (z) {
                    ou0Var = this.I;
                } else {
                    ou0Var = this.E;
                }
                if (ou0Var != null) {
                    nu0 nu0Var = new nu0(ou0Var);
                    a80 a80Var = (a80) ((ll) d0()).e.k(e3.S);
                    if (a80Var != null) {
                        sqVar = a80Var.r(new c(0, uj0Var, nu0Var));
                    } else {
                        sqVar = null;
                    }
                    wl1.B(d0(), null, new f(uj0Var, nu0Var, sqVar, null, 0), 3);
                }
            }
            if (z) {
                this.I = null;
            } else {
                this.E = null;
            }
        }
    }

    public final void w0() {
        uj0 uj0Var = this.u;
        wj0 wj0Var = this.G;
        if (uj0Var != null) {
            ou0 ou0Var = this.E;
            if (ou0Var != null) {
                uj0Var.b(new nu0(ou0Var));
            }
            ou0 ou0Var2 = this.I;
            if (ou0Var2 != null) {
                uj0Var.b(new nu0(ou0Var2));
            }
            m30 m30Var = this.F;
            if (m30Var != null) {
                uj0Var.b(new n30(m30Var));
            }
            Object[] objArr = wj0Var.c;
            long[] jArr = wj0Var.a;
            int length = jArr.length - 2;
            if (length >= 0) {
                int i = 0;
                while (true) {
                    long j = jArr[i];
                    if ((((~j) << 7) & j & (-9187201950435737472L)) != -9187201950435737472L) {
                        int i2 = 8 - ((~(i - length)) >>> 31);
                        for (int i3 = 0; i3 < i2; i3++) {
                            if ((255 & j) < 128) {
                                uj0Var.b(new nu0((ou0) objArr[(i << 3) + i3]));
                            }
                            j >>= 8;
                        }
                        if (i2 != 8) {
                            break;
                        }
                    }
                    if (i == length) {
                        break;
                    }
                    i++;
                }
            }
        }
        this.E = null;
        this.I = null;
        this.F = null;
        wj0Var.a();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r12v3 */
    /* JADX WARN: Type inference failed for: r12v4, types: [int] */
    /* JADX WARN: Type inference failed for: r17v0, types: [li0, dg, ak, dp, cp, o10] */
    /* JADX WARN: Type inference failed for: r4v24, types: [jw0, java.lang.Object] */
    @Override // defpackage.gt0
    public final void x(zs0 zs0Var, at0 at0Var, long j) {
        int i;
        boolean z;
        int i2;
        boolean z2;
        boolean z3;
        boolean z4;
        boolean z5;
        uj0 uj0Var;
        char c = ' ';
        long j2 = 4294967295L;
        long j3 = ((j >> 33) << 32) | (((j << 32) >> 33) & 4294967295L);
        this.H = (Float.floatToRawIntBits((int) (j3 & 4294967295L)) & 4294967295L) | (Float.floatToRawIntBits((int) (j3 >> 32)) << 32);
        y0();
        boolean z6 = this.y;
        at0 at0Var2 = at0.f;
        int i3 = 1;
        boolean z7 = false;
        if (z6) {
            if (this.C == null) {
                p10 p10Var = new p10(this);
                r0(p10Var);
                this.C = p10Var;
            }
            if (at0Var == at0Var2) {
                int i4 = zs0Var.c;
                if (i4 == 4) {
                    wl1.B(d0(), null, new k(this, null, 0), 3);
                } else if (i4 == 5) {
                    wl1.B(d0(), null, new k(this, null, 1), 3);
                }
            }
        }
        if (at0Var == at0Var2) {
            if (this.N == null) {
                if (kb0.r(zs0Var, true)) {
                    dt0 dt0Var = (dt0) zs0Var.a.get(0);
                    dt0Var.a();
                    this.N = dt0Var;
                    if (this.y && (uj0Var = this.u) != null) {
                        ou0 ou0Var = new ou0(dt0Var.c);
                        ?? obj = new Object();
                        mc0.E(this, p10.t, new a2(new c(7, dt0Var, obj), 1));
                        if (!obj.e) {
                            int i5 = eg.b;
                            ViewParent parent = gh0.N(this).getParent();
                            while (parent != null && (parent instanceof ViewGroup)) {
                                ViewGroup viewGroup = (ViewGroup) parent;
                                if (!viewGroup.shouldDelayChildPressedState()) {
                                    parent = viewGroup.getParent();
                                }
                            }
                            this.E = ou0Var;
                            wl1.B(d0(), null, new h(uj0Var, ou0Var, null, 2), 3);
                            return;
                        }
                        this.L = wl1.B(d0(), null, new i(uj0Var, ou0Var, this, null, 1), 3);
                        return;
                    }
                    return;
                }
                return;
            }
            List list = zs0Var.a;
            int size = list.size();
            int i6 = 0;
            while (i6 < size) {
                dt0 dt0Var2 = (dt0) list.get(i6);
                if (!dt0Var2.b() && dt0Var2.h && !dt0Var2.d) {
                    i = i3;
                } else {
                    i = 0;
                }
                if (i == 0) {
                    long K = k70.O(this).C.K(((yg1) j70.z(this, fk.t)).c());
                    long floatToRawIntBits = (Float.floatToRawIntBits(Math.max(0.0f, Float.intBitsToFloat((int) (K & j2)) - ((int) (j & j2))) / 2.0f) & j2) | (Float.floatToRawIntBits(Math.max(0.0f, Float.intBitsToFloat((int) (K >> c)) - ((int) (j >> c))) / 2.0f) << c);
                    int size2 = list.size();
                    int i7 = 0;
                    while (i7 < size2) {
                        dt0 dt0Var3 = (dt0) list.get(i7);
                        if (!dt0Var3.b()) {
                            if (dt0Var3.i == i3) {
                                i2 = i3;
                            } else {
                                i2 = z7;
                            }
                            long j4 = dt0Var3.c;
                            char c2 = c;
                            float intBitsToFloat = Float.intBitsToFloat((int) (j4 >> c2));
                            float intBitsToFloat2 = Float.intBitsToFloat((int) (j4 & j2));
                            float f = (float) i2;
                            float intBitsToFloat3 = Float.intBitsToFloat((int) (floatToRawIntBits >> c2)) * f;
                            long j5 = j2;
                            float f2 = ((int) (j >> c2)) + intBitsToFloat3;
                            float intBitsToFloat4 = Float.intBitsToFloat((int) (floatToRawIntBits & j5)) * f;
                            float f3 = ((int) (j & j5)) + intBitsToFloat4;
                            if (intBitsToFloat < (-intBitsToFloat3)) {
                                z2 = true;
                            } else {
                                z2 = false;
                            }
                            if (intBitsToFloat > f2) {
                                z3 = true;
                            } else {
                                z3 = false;
                            }
                            boolean z8 = z3 | z2;
                            if (intBitsToFloat2 < (-intBitsToFloat4)) {
                                z4 = true;
                            } else {
                                z4 = false;
                            }
                            boolean z9 = z8 | z4;
                            if (intBitsToFloat2 > f3) {
                                z5 = true;
                            } else {
                                z5 = false;
                            }
                            if (z9 | z5) {
                                z = false;
                            } else {
                                i7++;
                                j2 = j5;
                                c = ' ';
                                i3 = 1;
                                z7 = false;
                            }
                        } else {
                            z = z7;
                        }
                        v0(z);
                        return;
                    }
                    return;
                }
                i6++;
                j2 = j2;
                c = ' ';
                i3 = 1;
            }
            ((dt0) list.get(0)).a();
            if (this.y) {
                dt0 dt0Var4 = this.N;
                dt0Var4.getClass();
                x0(dt0Var4.c, false);
                this.z.a();
            }
            this.N = null;
        } else if (at0Var == at0.g && this.N != null) {
            List list2 = zs0Var.a;
            int size3 = list2.size();
            for (int i8 = 0; i8 < size3; i8++) {
                dt0 dt0Var5 = (dt0) list2.get(i8);
                if (dt0Var5.b() && dt0Var5 != this.N) {
                    v0(false);
                    return;
                }
            }
        }
    }

    public final void x0(long j, boolean z) {
        ou0 ou0Var;
        uj0 uj0Var = this.u;
        if (uj0Var != null) {
            s71 s71Var = this.L;
            if (s71Var != null && s71Var.b()) {
                s71Var.a(null);
                wl1.B(d0(), null, new g(s71Var, j, uj0Var, null, 0), 3);
            } else {
                if (z) {
                    ou0Var = this.I;
                } else {
                    ou0Var = this.E;
                }
                if (ou0Var != null) {
                    wl1.B(d0(), null, new h(ou0Var, uj0Var, null), 3);
                }
            }
            if (z) {
                this.I = null;
            } else {
                this.E = null;
            }
        }
    }

    public final void y0() {
        t40 t40Var;
        if (this.D == null) {
            if (this.w) {
                t40Var = this.B;
            } else {
                t40Var = this.v;
            }
            if (t40Var != null) {
                if (this.u == null) {
                    this.u = new uj0();
                }
                this.A.v0(this.u);
                uj0 uj0Var = this.u;
                uj0Var.getClass();
                cp a = t40Var.a(uj0Var);
                r0(a);
                this.D = a;
            }
        }
    }

    @Override // defpackage.vm0
    public final void z() {
        if (this.w) {
            sb0.r(this, new b(this, 0));
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:34:0x0065, code lost:
        if (r3.D == null) goto L32;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void z0(uj0 uj0Var, t40 t40Var, boolean z, boolean z2, iy0 iy0Var, xz xzVar) {
        boolean z3;
        boolean z4;
        cp cpVar;
        boolean z5 = true;
        boolean z6 = false;
        if (!k70.p(this.J, uj0Var)) {
            w0();
            this.J = uj0Var;
            this.u = uj0Var;
            z3 = true;
        } else {
            z3 = false;
        }
        if (!k70.p(this.v, t40Var)) {
            this.v = t40Var;
            z3 = true;
        }
        if (this.w != z) {
            this.w = z;
            if (z) {
                z();
            }
            z3 = true;
        }
        boolean z7 = this.y;
        vy vyVar = this.A;
        if (z7 != z2) {
            if (z2) {
                r0(vyVar);
            } else {
                s0(vyVar);
                w0();
            }
            jb0.n(this);
            this.y = z2;
        }
        if (!k70.p(this.x, iy0Var)) {
            this.x = iy0Var;
            jb0.n(this);
        }
        this.z = xzVar;
        boolean z8 = this.K;
        uj0 uj0Var2 = this.J;
        if (uj0Var2 == null) {
            z4 = true;
        } else {
            z4 = false;
        }
        if (z8 != z4) {
            if (uj0Var2 == null) {
                z6 = true;
            }
            this.K = z6;
            if (!z6) {
            }
        }
        z5 = z3;
        if (z5 && ((cpVar = this.D) != null || !this.K)) {
            if (cpVar != null) {
                s0(cpVar);
            }
            this.D = null;
            y0();
        }
        vyVar.v0(this.u);
    }
}