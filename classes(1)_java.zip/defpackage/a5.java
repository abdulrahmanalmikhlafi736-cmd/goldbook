package defpackage;

import android.graphics.Bitmap;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcelable;
import android.util.DisplayMetrics;
import android.util.Size;
import android.util.SizeF;
import android.util.SparseArray;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewParent;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.Serializable;
import java.lang.reflect.Method;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.CancellationException;
import java.util.zip.DataFormatException;
import java.util.zip.Deflater;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.Inflater;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: a5  reason: default package */
public abstract class a5 {
    public static final ml[] a = new ml[0];
    public static final a51 b = a51.f;
    public static final pi c = new pi(856539202, false, new ri(1));
    public static final pi d = new pi(1201367364, false, new ri(2));
    public static final pi e = new pi(-454738871, false, new o9(6));
    public static final pi f = new pi(-282324790, false, new o9(7));
    public static final Class[] g = {Serializable.class, Parcelable.class, String.class, SparseArray.class, Binder.class, Size.class, SizeF.class};
    public static final float[] h = {1.0f, 10.0f, 100.0f, 1000.0f, 10000.0f, 100000.0f, 1000000.0f, 1.0E7f, 1.0E8f, 1.0E9f, 1.0E10f};
    public static final long[] i = {-6499023860262858360L, -3512093806901185046L, -9112587656954322510L, -6779048552765515233L, -3862124672529506138L, -215969822234494768L, -7052510166537641086L, -4203951689744663454L, -643253593753441413L, -7319562523736982739L, -4537767136243840520L, -1060522901877412746L, -7580355841314464822L, -4863758783215693124L, -1468012460592228501L, -7835036815511224669L, -5182110000961642932L, -1865951482774665761L, -8083748704375247957L, -5492999862041672042L, -2254563809124702148L, -8326631408344020699L, -5796603242002637969L, -2634068034075909558L, -8563821548938525330L, -6093090917745768758L, -3004677628754823043L, -8795452545612846258L, -6382629663588669919L, -3366601061058449494L, -9021654690802612790L, -6665382345075878084L, -3720041912917459700L, -38366372719436721L, -6941508010590729807L, -4065198994811024355L, -469812725086392539L, -7211161980820077193L, -4402266457597708587L, -891147053569747830L, -7474495936122174250L, -4731433901725329908L, -1302606358729274481L, -7731658001846878407L, -5052886483881210105L, -1704422086424124727L, -7982792831656159810L, -5366805021142811859L, -2096820258001126919L, -8228041688891786181L, -5673366092687344822L, -2480021597431793123L, -8467542526035952558L, -5972742139117552794L, -2854241655469553088L, -8701430062309552536L, -6265101559459552766L, -3219690930897053053L, -8929835859451740015L, -6550608805887287114L, -3576574988931720989L, -9152888395723407474L, -6829424476226871438L, -3925094576856201394L, -294682202642863838L, -7101705404292871755L, -4265445736938701790L, -720121152745989333L, -7367604748107325189L, -4597819916706768583L, -1135588877456072824L, -7627272076051127371L, -4922404076636521310L, -1541319077368263733L, -7880853450996246689L, -5239380795317920458L, -1937539975720012668L, -8128491512466089774L, -5548928372155224313L, -2324474446766642487L, -8370325556870233411L, -5851220927660403859L, -2702340141148116920L, -8606491615858654931L, -6146428501395930760L, -3071349608317525546L, -8837122532839535322L, -6434717147622031249L, -3431710416100151157L, -9062348037703676329L, -6716249028702207507L, -3783625267450371480L, -117845565885576446L, -6991182506319567135L, -4127292114472071014L, -547429124662700864L, -7259672230555269896L, -4462904269766699466L, -966944318780986428L, -7521869226879198374L, -4790650515171610063L, -1376627125537124675L, -7777920981101784778L, -5110715207949843068L, -1776707991509915931L, -8027971522334779313L, -5423278384491086237L, -2167411962186469893L, -8272161504007625539L, -5728515861582144020L, -2548958808550292121L, -8510628282985014432L, -6026599335303880135L, -2921563150702462265L, -8743505996830120772L, -6317696477610263061L, -3285434578585440922L, -8970925639256982432L, -6601971030643840136L, -3640777769877412266L, -9193015133814464522L, -6879582898840692749L, -3987792605123478032L, -373054737976959636L, -7150688238876681629L, -4326674280168464132L, -796656831783192261L, -7415439547505577019L, -4657613415954583370L, -1210330751515841308L, -7673985747338482674L, -4980796165745715438L, -1614309188754756393L, -7926472270612804602L, -5296404319838617848L, -2008819381370884406L, -8173041140997884610L, -5604615407819967859L, -2394083241347571919L, -8413831053483314306L, -5905602798426754978L, -2770317479606055818L, -8648977452394866743L, -6199535797066195524L, -3137733727905356501L, -8878612607581929669L, -6486579741050024183L, -3496538657885142324L, -9102865688819295809L, -6766896092596731857L, -3846934097318526917L, -196981603220770742L, -7040642529654063570L, -4189117143640191558L, -624710411122851544L, -7307973034592864071L, -4523280274813692185L, -1042414325089727327L, -7569037980822161435L, -4849611457600313890L, -1450328303573004458L, -7823984217374209643L, -5168294253290374149L, -1848681798185579782L, -8072955151507069220L, -5479507920956448621L, -2237698882768172872L, -8316090829371189901L, -5783427518286599473L, -2617598379430861437L, -8553528014785370254L, -6080224000054324913L, -2988593981640518238L, -8785400266166405755L, -6370064314280619289L, -3350894374423386208L, -9011838011655698236L, -6653111496142234891L, -3704703351750405709L, -19193171260619233L, -6929524759678968877L, -4050219931171323192L, -451088895536766085L, -7199459587351560659L, -4387638465762062920L, -872862063775190746L, -7463067817500576073L, -4717148753448332187L, -1284749923383027329L, -7720497729755473937L, -5038936143766954517L, -1686984161281305242L, -7971894128441897632L, -5353181642124984136L, -2079791034228842266L, -8217398424034108273L, -5660062011615247437L, -2463391496091671392L, -8457148712698376476L, -5959749872445582691L, -2838001322129590460L, -8691279853972075893L, -6252413799037706963L, -3203831230369745799L, -8919923546622172981L, -6538218414850328322L, -3561087000135522498L, -9143208402725783417L, -6817324484979841368L, -3909969587797413806L, -275775966319379353L, -7089889006590693952L, -4250675239810979535L, -701658031336336515L, -7356065297226292178L, -4583395603105477319L, -1117558485454458744L, -7616003081050118571L, -4908317832885260310L, -1523711272679187483L, -7869848573065574033L, -5225624697904579637L, -1920344853953336643L, -8117744561361917258L, -5535494683275008668L, -2307682335666372931L, -8359830487432564938L, -5838102090863318269L, -2685941595151759932L, -8596242524610931813L, -6133617137336276863L, -3055335403242958174L, -8827113654667930715L, -6422206049907525490L, -3416071543957018958L, -9052573742614218705L, -6704031159840385477L, -3768352931373093942L, -98755145788979524L, -6979250993759194058L, -4112377723771604669L, -528786136287117932L, -7248020362820530564L, -4448339435098275301L, -948738275445456222L, -7510490449794491995L, -4776427043815727089L, -1358847786342270957L, -7766808894105001205L, -5096825099203863602L, -1759345355577441598L, -8017119874876982855L, -5409713825168840664L, -2150456263033662926L, -8261564192037121185L, -5715269221619013577L, -2532400508596379068L, -8500279345513818773L, -6013663163464885563L, -2905392935903719049L, -8733399612580906262L, -6305063497298744923L, -3269643353196043250L, -8961056123388608887L, -6589634135808373205L, -3625356651333078602L, -9183376934724255983L, -6867535149977932074L, -3972732919045027189L, -354230130378896082L, -7138922859127891907L, -4311967555482476980L, -778273425925708321L, -7403949918844649557L, -4643251380128424042L, -1192378206733142148L, -7662765406849295699L, -4966770740134231719L, -1596777406740401745L, -7915514906853832947L, -5282707615139903279L, -1991698500497491195L, -8162340590452013853L, -5591239719637629412L, -2377363631119648861L, -8403381297090862394L, -5892540602936190089L, -2753989735242849707L, -8638772612167862923L, -6186779746782440750L, -3121788665050663033L, -8868646943297746252L, -6474122660694794911L, -3480967307441105734L, -9093133594791772940L, -6754730975062328271L, -3831727700400522434L, -177973607073265139L, -7028762532061872568L, -4174267146649952806L, -606147914885053103L, -7296371474444240046L, -4508778324627912153L, -1024286887357502287L, -7557708332239520786L, -4835449396872013078L, -1432625727662628443L, -7812920107430224633L, -5154464115860392887L, -1831394126398103205L, -8062150356639896359L, -5466001927372482545L, -2220816390788215277L, -8305539271883716405L, -5770238071427257602L, -2601111570856684098L, -8543223759426509417L, -6067343680855748868L, -2972493582642298180L, -8775337516792518219L, -6357485877563259869L, -3335171328526686933L, -9002011107970261189L, -6640827866535438582L, -3689348814741910324L, Long.MIN_VALUE, -6917529027641081856L, -4035225266123964416L, -432345564227567616L, -7187745005283311616L, -4372995238176751616L, -854558029293551616L, -7451627795949551616L, -4702848726509551616L, -1266874889709551616L, -7709325833709551616L, -5024971273709551616L, -1669528073709551616L, -7960984073709551616L, -5339544073709551616L, -2062744073709551616L, -8206744073709551616L, -5646744073709551616L, -2446744073709551616L, -8446744073709551616L, -5946744073709551616L, -2821744073709551616L, -8681119073709551616L, -6239712823709551616L, -3187955011209551616L, -8910000909647051616L, -6525815118631426616L, -3545582879861895366L, -9133518327554766460L, -6805211891016070171L, -3894828845342699810L, -256850038250986858L, -7078060301547948643L, -4235889358507547899L, -683175679707046970L, -7344513827457986212L, -4568956265895094861L, -1099509313941480672L, -7604722348854507276L, -4894216917640746191L, -1506085128623544835L, -7858832233030797378L, -5211854272861108819L, -1903131822648998119L, -8106986416796705681L, -5522047002568494197L, -2290872734783229842L, -8349324486880600507L, -5824969590173362730L, -2669525969289315508L, -8585982758446904049L, -6120792429631242157L, -3039304518611664792L, -8817094351773372351L, -6409681921289327535L, -3400416383184271515L, -9042789267131251553L, -6691800565486676537L, -3753064688430957767L, -79644842111309304L, -6967307053960650171L, -4097447799023424810L, -510123730351893109L, -7236356359111015049L, -4433759430461380907L, -930513269649338230L, -7499099821171918250L, -4762188758037509908L, -1341049929119499481L, -7755685233340769032L, -5082920523248573386L, -1741964635633328828L, -8006256924911912374L, -5396135137712502563L, -2133482903713240300L, -8250955842461857044L, -5702008784649933400L, -2515824962385028846L, -8489919629131724885L, -6000713517987268202L, -2889205879056697349L, -8723282702051517699L, -6292417359137009220L, -3253835680493873621L, -8951176327949752869L, -6577284391509803182L, -3609919470959866074L, -9173728696990998152L, -6855474852811359786L, -3957657547586811828L, -335385916056126881L, -7127145225176161157L, -4297245513042813542L, -759870872876129024L, -7392448323188662496L, -4628874385558440216L, -1174406963520662366L, -7651533379841495835L, -4952730706374481889L, -1579227364540714458L, -7904546130479028392L, -5268996644671397586L, -1974559787411859078L, -8151628894773493780L, -5577850100039479321L, -2360626606621961247L, -8392920656779807636L, -5879464802547371641L, -2737644984756826647L, -8628557143114098510L, -6174010410465235234L, -3105826994654156138L, -8858670899299929442L, -6461652605697523899L, -3465379738694516970L, -9083391364325154962L, -6742553186979055799L, -3816505465296431844L, -158945813193151901L, -7016870160886801794L, -4159401682681114339L, -587566084924005019L, -7284757830718584993L, -4494261269970843337L, -1006140569036166268L, -7546366883288685774L, -4821272585683469313L, -1414904713676948737L, -7801844473689174817L, -5140619573684080617L, -1814088448677712867L, -8051334308064652398L, -5452481866653427593L, -2203916314889396588L, -8294976724446954723L, -5757034887131305500L, -2584607590486743971L, -8532908771695296838L, -6054449946191733143L, -2956376414312278525L, -8765264286586255934L, -6344894339805432014L, -3319431906329402113L, -8992173969096958177L, -6628531442943809817L, -3673978285252374367L, -9213765455923815836L, -6905520801477381891L, -4020214983419339459L, -413582710846786420L, -7176018221920323369L, -4358336758973016307L, -836234930288882479L, -7440175859071633406L, -4688533805412153853L, -1248981238337804412L, -7698142301602209614L, -5010991858575374113L, -1652053804791829737L, -7950062655635975442L, -5325892301117581398L, -2045679357969588844L, -8196078626372074883L, -5633412264537705700L, -2430079312244744221L, -8436328597794046994L, -5933724728815170839L, -2805469892591575644L, -8670947710510816634L, -6226998619711132888L, -3172062256211528206L, -8900067937773286985L, -6513398903789220827L, -3530062611309138130L, -9123818159709293187L, -6793086681209228580L, -3879672333084147821L, -237904397927796872L, -7066219276345954901L, -4221088077005055722L, -664674077828931749L, -7332950326284164199L, -4554501889427817345L, -1081441343357383777L, -7593429867239446717L, -4880101315621920492L, -1488440626100012711L, -7847804418953589800L, -5198069505264599346L, -1885900863153361279L, -8096217067111932656L, -5508585315462527915L, -2274045625900771990L, -8338807543829064350L, -5811823411358942533L, -2653093245771290262L, -8575712306248138270L, -6107954364382784934L, -3023256937051093263L, -8807064613298015146L, -6397144748195131028L, -3384744916816525881L, -9032994600651410532L, -6679557232386875260L, -3737760522056206171L, -60514634142869810L, -6955350673980375487L, -4082502324048081455L, -491441886632713915L, -7224680206786528053L, -4419164240055772162L, -912269281642327298L, -7487697328667536418L, -4747935642407032618L, -1323233534581402868L, -7744549986754458649L, -5069001465015685407L, -1724565812842218855L, -7995382660667468640L, -5382542307406947896L, -2116491865831296966L, -8240336443785642460L, -5688734536304665171L, -2499232151953443560L, -8479549122611984081L, -5987750384837592197L, -2873001962619602342L, -8713155254278333320L, -6279758049420528746L, -3238011543348273028L, -8941286242233752499L, -6564921784364802720L, -3594466212028615495L, -9164070410158966541L, -6843401994271320272L, -3942566474411762436L, -316522074587315140L, -7115355324258153819L, -4282508136895304370L, -741449152691742558L, -7380934748073420955L, -4614482416664388289L, -1156417002403097458L, -7640289654143017767L, -4938676049251384305L, -1561659043136842477L, -7893565929601608404L, -5255271393574622601L, -1957403223540890347L, -8140906042354138323L, -5564446534515285000L, -2343872149716718346L, -8382449121214030822L, -5866375383090150624L, -2721283210435300376L, -8618331034163144591L, -6161227774276542835L, -3089848699418290639L, -8848684464777513506L, -6449169562544503978L, -3449775934753242068L, -9073638986861858149L, -6730362715149934782L, -3801267375510030573L, -139898200960150313L, -7004965403241175802L, -4144520735624081848L, -568964901102714406L, -7273132090830278360L, -4479729095110460046L, -987975350460687153L, -7535013621679011327L, -4807081008671376254L, -1397165242411832414L, -7790757304148477115L, -5126760611758208489L, -1796764746270372707L, -8040506994060064798L, -5438947724147693094L, -2186998636757228463L, -8284403175614349646L, -5743817951090549153L, -2568086420435798537L, -8522583040413455942L, -6041542782089432023L, -2940242459184402125L, -8755180564631333184L, -6332289687361778576L, -3303676090774835316L, -8982326584375353929L, -6616222212041804507L, -3658591746624867729L, -9204148869281624187L, -6893500068174642330L, -4005189066790915008L, -394800315061255856L, -7164279224554366766L, -4343663012265570553L, -817892746904575288L, -7428711994456441411L, -4674203974643163860L, -1231068949876566920L, -7686947121313936181L, -4996997883215032323L, -1634561335591402499L, -7939129862385708418L, -5312226309554747619L, -2028596868516046619L, -8185402070463610993L};
    public static final byte[] j = {112, 114, 111, 0};
    public static final byte[] k = {112, 114, 109, 0};
    public static final f11 l = new f11(0);
    public static final g11 m = new Object();
    public static final eq n = new eq(1);
    public static final h11 o = new Object();
    public static final Object p = new Object();
    public static final av0 q = new av0(14);

    /* JADX WARN: Removed duplicated region for block: B:153:0x024a  */
    /* JADX WARN: Removed duplicated region for block: B:157:0x0258  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final long A(int i2, int i3, String str) {
        boolean z;
        char c2;
        int i4;
        long j2;
        char c3;
        char c4;
        int i5;
        int i6;
        int i7;
        int i8;
        int i9;
        long j3;
        char c5;
        long j4;
        int floatToRawIntBits;
        float f2;
        float f3;
        int i10;
        int i11;
        char c6;
        char c7;
        int i12;
        long j5;
        long floatToRawIntBits2;
        int i13;
        char c8;
        int i14;
        int floatToRawIntBits3;
        long j6 = 4294967295L;
        if (i2 == i3) {
            j5 = i2 << 32;
            floatToRawIntBits3 = Float.floatToRawIntBits(Float.NaN);
        } else {
            char charAt = str.charAt(i2);
            if (charAt == '-') {
                z = true;
            } else {
                z = false;
            }
            if (z) {
                i4 = i2 + 1;
                if (i4 == i3) {
                    j5 = i4 << 32;
                    floatToRawIntBits3 = Float.floatToRawIntBits(Float.NaN);
                } else {
                    c2 = str.charAt(i4);
                    if (((char) (c2 - '0')) >= '\n' && c2 != '.') {
                        j5 = i4 << 32;
                        floatToRawIntBits3 = Float.floatToRawIntBits(Float.NaN);
                    }
                }
            } else {
                c2 = charAt;
                i4 = i2;
            }
            int length = str.length();
            long j7 = 0;
            int i15 = i4;
            long j8 = 0;
            while (true) {
                if (i15 != i3) {
                    j2 = j6;
                    int i16 = c2 - '0';
                    if (((char) i16) >= '\n') {
                        break;
                    }
                    j8 = (j8 * 10) + i16;
                    i15++;
                    if (i15 < length) {
                        c2 = str.charAt(i15);
                    } else {
                        c2 = 0;
                    }
                    j6 = j2;
                } else {
                    j2 = j6;
                    break;
                }
            }
            int i17 = i15 - i4;
            char c9 = '0';
            if (i15 != i3 && c2 == '.') {
                int i18 = i15 + 1;
                c3 = ' ';
                i5 = i18;
                while (true) {
                    c4 = 1;
                    if (i3 - i5 >= 4) {
                        i13 = i18;
                        long charAt2 = str.charAt(i5) | (str.charAt(i5 + 1) << 16) | (str.charAt(i5 + 2) << 32) | (str.charAt(i5 + 3) << 48);
                        long j9 = charAt2 - 13511005043687472L;
                        if ((((charAt2 + 19703549022044230L) | j9) & (-35747867511423104L)) != 0) {
                            i14 = -1;
                        } else {
                            i14 = (int) ((j9 * 281475406208040961L) >>> 48);
                        }
                        if (i14 < 0) {
                            break;
                        }
                        j8 = (j8 * 10000) + i14;
                        i5 += 4;
                        i18 = i13;
                    } else {
                        i13 = i18;
                        break;
                    }
                }
                if (i5 < length) {
                    c8 = str.charAt(i5);
                } else {
                    c8 = 0;
                }
                loop2: while (true) {
                    c2 = c8;
                    while (i5 != i3) {
                        int i19 = c2 - '0';
                        if (((char) i19) >= '\n') {
                            break loop2;
                        }
                        j8 = (j8 * 10) + i19;
                        i5++;
                        if (i5 < length) {
                            break;
                        }
                        c2 = 0;
                    }
                    c8 = str.charAt(i5);
                }
                i7 = i13 - i5;
                i17 -= i7;
                i6 = i13;
            } else {
                c3 = ' ';
                c4 = 1;
                i5 = i15;
                i6 = i5;
                i7 = 0;
            }
            if (i17 == 0) {
                j5 = i5 << c3;
                floatToRawIntBits2 = Float.floatToRawIntBits(Float.NaN) & j2;
                return j5 | floatToRawIntBits2;
            }
            if ((c2 | ' ') == 101) {
                i8 = i5 + 1;
                if (i8 < length) {
                    c6 = str.charAt(i8);
                } else {
                    c6 = 0;
                }
                if (c6 == '-') {
                    c7 = c4;
                } else {
                    c7 = 0;
                }
                if (c7 != 0 || c6 == '+') {
                    i8 = i5 + 2;
                }
                char charAt3 = str.charAt(i8);
                i9 = 0;
                while (true) {
                    if (i8 != i3) {
                        int i20 = charAt3 - c9;
                        i12 = i7;
                        if (((char) i20) >= '\n') {
                            break;
                        }
                        if (i9 < 1024) {
                            i9 = (i9 * 10) + i20;
                        }
                        i8++;
                        if (i8 < length) {
                            charAt3 = str.charAt(i8);
                        } else {
                            charAt3 = 0;
                        }
                        i7 = i12;
                        c9 = '0';
                    } else {
                        i12 = i7;
                        break;
                    }
                }
                if (c7 != 0) {
                    i9 = -i9;
                }
                i7 = i12 + i9;
            } else {
                i8 = i5;
                i9 = 0;
            }
            int i21 = 19;
            if (i17 > 19) {
                char charAt4 = str.charAt(i4);
                int i22 = i4;
                while (true) {
                    if (i8 != i3) {
                        if (charAt4 != '0' && charAt4 != '.') {
                            i10 = 19;
                            break;
                        }
                        if (charAt4 == '0') {
                            i17--;
                        }
                        i22++;
                        if (i22 < length) {
                            charAt4 = str.charAt(i22);
                        } else {
                            charAt4 = 0;
                        }
                        i21 = 19;
                    } else {
                        i10 = i21;
                        break;
                    }
                }
                if (i17 > i10) {
                    char charAt5 = str.charAt(i4);
                    long j10 = 0;
                    while (true) {
                        i11 = i4;
                        if (i4 == i15 || Long.compare(j10 ^ Long.MIN_VALUE, -8223372036854775808L) >= 0) {
                            break;
                        }
                        j10 = (j10 * 10) + (charAt5 - '0');
                        i4 = i11 + 1;
                        if (i4 < length) {
                            charAt5 = str.charAt(i4);
                        } else {
                            charAt5 = 0;
                        }
                    }
                    if (Long.compare(j10 ^ Long.MIN_VALUE, -8223372036854775808L) >= 0) {
                        i7 = (i15 - i11) + i9;
                    } else {
                        char charAt6 = str.charAt(i6);
                        int i23 = i6;
                        while (i23 != i5 && Long.compare(j10 ^ Long.MIN_VALUE, -8223372036854775808L) < 0) {
                            j10 = (j10 * 10) + (charAt6 - '0');
                            i23++;
                            if (i23 < length) {
                                charAt6 = str.charAt(i23);
                            } else {
                                charAt6 = 0;
                            }
                        }
                        i7 = (i6 - i23) + i9;
                    }
                    j3 = j10;
                    c5 = c4;
                    if (-10 > i7 && i7 < 11 && c5 == 0 && Long.compare(j3 ^ Long.MIN_VALUE, -9223372036837998592L) <= 0) {
                        float f4 = (float) j3;
                        float[] fArr = h;
                        if (i7 < 0) {
                            f3 = f4 / fArr[-i7];
                        } else {
                            f3 = f4 * fArr[i7];
                        }
                        if (z) {
                            f3 = -f3;
                        }
                        j4 = i8 << c3;
                        floatToRawIntBits = Float.floatToRawIntBits(f3);
                    } else if (j3 != 0) {
                        if (z) {
                            f2 = -0.0f;
                        } else {
                            f2 = 0.0f;
                        }
                        j4 = i8 << c3;
                        floatToRawIntBits = Float.floatToRawIntBits(f2);
                    } else if (-126 <= i7 && i7 < 128) {
                        long j11 = i[i7 + 325];
                        int numberOfLeadingZeros = Long.numberOfLeadingZeros(j3);
                        long j12 = j3 << numberOfLeadingZeros;
                        long j13 = j12 & j2;
                        long j14 = j12 >>> c3;
                        long j15 = j11 & j2;
                        long j16 = j11 >>> c3;
                        long j17 = j14 * j16;
                        long j18 = j16 * j13;
                        long j19 = j17 + ((((j14 * j15) + ((j13 * j15) >>> c3)) + (j18 & j2)) >>> c3) + (j18 >>> c3);
                        int i24 = (int) (j19 >>> 63);
                        long j20 = j19 >>> (i24 + 9);
                        int i25 = numberOfLeadingZeros + (i24 ^ 1);
                        long j21 = j19 & 511;
                        if (j21 != 511 && (j21 != 0 || (3 & j20) != 1)) {
                            long j22 = (j20 + 1) >>> c4;
                            if (j22 >= 9007199254740992L) {
                                i25--;
                                j22 = 4503599627370496L;
                            }
                            long j23 = j22 & (-4503599627370497L);
                            long j24 = (((i7 * 217706) >> 16) + 1087) - i25;
                            if (j24 >= 1 && j24 <= 2046) {
                                long j25 = (j24 << 52) | j23;
                                if (z) {
                                    j7 = Long.MIN_VALUE;
                                }
                                j4 = i8 << c3;
                                floatToRawIntBits = Float.floatToRawIntBits((float) Double.longBitsToDouble(j25 | j7));
                            } else {
                                j4 = i8 << c3;
                                floatToRawIntBits = Float.floatToRawIntBits(Float.parseFloat(str.substring(i2, i8)));
                            }
                        } else {
                            j4 = i8 << c3;
                            floatToRawIntBits = Float.floatToRawIntBits(Float.parseFloat(str.substring(i2, i8)));
                        }
                    } else {
                        j4 = i8 << c3;
                        floatToRawIntBits = Float.floatToRawIntBits(Float.parseFloat(str.substring(i2, i8)));
                    }
                    return j4 | (floatToRawIntBits & j2);
                }
            }
            j3 = j8;
            c5 = 0;
            if (-10 > i7) {
            }
            if (j3 != 0) {
            }
            return j4 | (floatToRawIntBits & j2);
        }
        floatToRawIntBits2 = floatToRawIntBits3 & 4294967295L;
        return j5 | floatToRawIntBits2;
    }

    public static final mi0 B(mi0 mi0Var, k7 k7Var) {
        return mi0Var.b(new ln0(k7Var));
    }

    public static final void C(float[] fArr, float[] fArr2) {
        float p2 = p(fArr2, 0, fArr, 0);
        float p3 = p(fArr2, 0, fArr, 1);
        float p4 = p(fArr2, 0, fArr, 2);
        float p5 = p(fArr2, 0, fArr, 3);
        float p6 = p(fArr2, 1, fArr, 0);
        float p7 = p(fArr2, 1, fArr, 1);
        float p8 = p(fArr2, 1, fArr, 2);
        float p9 = p(fArr2, 1, fArr, 3);
        float p10 = p(fArr2, 2, fArr, 0);
        float p11 = p(fArr2, 2, fArr, 1);
        float p12 = p(fArr2, 2, fArr, 2);
        float p13 = p(fArr2, 2, fArr, 3);
        float p14 = p(fArr2, 3, fArr, 0);
        float p15 = p(fArr2, 3, fArr, 1);
        float p16 = p(fArr2, 3, fArr, 2);
        float p17 = p(fArr2, 3, fArr, 3);
        fArr[0] = p2;
        fArr[1] = p3;
        fArr[2] = p4;
        fArr[3] = p5;
        fArr[4] = p6;
        fArr[5] = p7;
        fArr[6] = p8;
        fArr[7] = p9;
        fArr[8] = p10;
        fArr[9] = p11;
        fArr[10] = p12;
        fArr[11] = p13;
        fArr[12] = p14;
        fArr[13] = p15;
        fArr[14] = p16;
        fArr[15] = p17;
    }

    public static byte[] D(InputStream inputStream, int i2) {
        byte[] bArr = new byte[i2];
        int i3 = 0;
        while (i3 < i2) {
            int read = inputStream.read(bArr, i3, i2 - i3);
            if (read >= 0) {
                i3 += read;
            } else {
                od.p(fu0.E("Not enough bytes to read: ", i2));
                return null;
            }
        }
        return bArr;
    }

    public static int[] E(ByteArrayInputStream byteArrayInputStream, int i2) {
        int[] iArr = new int[i2];
        int i3 = 0;
        for (int i4 = 0; i4 < i2; i4++) {
            i3 += (int) K(byteArrayInputStream, 2);
            iArr[i4] = i3;
        }
        return iArr;
    }

    /* JADX WARN: Code restructure failed: missing block: B:24:0x005d, code lost:
        if (r0.finished() == false) goto L30;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x0062, code lost:
        return r1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x006a, code lost:
        throw new java.lang.IllegalStateException("Inflater did not finish");
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static byte[] F(FileInputStream fileInputStream, int i2, int i3) {
        Inflater inflater = new Inflater();
        try {
            byte[] bArr = new byte[i3];
            byte[] bArr2 = new byte[2048];
            int i4 = 0;
            int i5 = 0;
            while (!inflater.finished() && !inflater.needsDictionary() && i4 < i2) {
                int read = fileInputStream.read(bArr2);
                if (read >= 0) {
                    inflater.setInput(bArr2, 0, read);
                    try {
                        i5 += inflater.inflate(bArr, i5, i3 - i5);
                        i4 += read;
                    } catch (DataFormatException e2) {
                        throw new IllegalStateException(e2.getMessage());
                    }
                } else {
                    throw new IllegalStateException("Invalid zip data. Stream ended after $totalBytesRead bytes. Expected " + i2 + " bytes");
                }
            }
            throw new IllegalStateException("Didn't read enough bytes during decompression. expected=" + i2 + " actual=" + i4);
        } finally {
            inflater.end();
        }
    }

    public static up[] G(FileInputStream fileInputStream, byte[] bArr, byte[] bArr2, up[] upVarArr) {
        byte[] bArr3 = ac.y;
        if (Arrays.equals(bArr, bArr3)) {
            if (!Arrays.equals(ac.t, bArr2)) {
                if (Arrays.equals(bArr, bArr3)) {
                    int K = (int) K(fileInputStream, 1);
                    byte[] F = F(fileInputStream, (int) K(fileInputStream, 4), (int) K(fileInputStream, 4));
                    if (fileInputStream.read() <= 0) {
                        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(F);
                        try {
                            up[] H = H(byteArrayInputStream, K, upVarArr);
                            byteArrayInputStream.close();
                            return H;
                        } catch (Throwable th) {
                            try {
                                byteArrayInputStream.close();
                            } catch (Throwable th2) {
                                th.addSuppressed(th2);
                            }
                            throw th;
                        }
                    }
                    od.p("Content found after the end of file");
                    return null;
                }
                od.p("Unsupported meta version");
                return null;
            }
            od.p("Requires new Baseline Profile Metadata. Please rebuild the APK with Android Gradle Plugin 7.2 Canary 7 or higher");
            return null;
        } else if (Arrays.equals(bArr, ac.z)) {
            int K2 = (int) K(fileInputStream, 2);
            byte[] F2 = F(fileInputStream, (int) K(fileInputStream, 4), (int) K(fileInputStream, 4));
            if (fileInputStream.read() <= 0) {
                ByteArrayInputStream byteArrayInputStream2 = new ByteArrayInputStream(F2);
                try {
                    up[] I = I(byteArrayInputStream2, bArr2, K2, upVarArr);
                    byteArrayInputStream2.close();
                    return I;
                } catch (Throwable th3) {
                    try {
                        byteArrayInputStream2.close();
                    } catch (Throwable th4) {
                        th3.addSuppressed(th4);
                    }
                    throw th3;
                }
            }
            od.p("Content found after the end of file");
            return null;
        } else {
            od.p("Unsupported meta version");
            return null;
        }
    }

    public static up[] H(ByteArrayInputStream byteArrayInputStream, int i2, up[] upVarArr) {
        if (byteArrayInputStream.available() == 0) {
            return new up[0];
        }
        if (i2 == upVarArr.length) {
            String[] strArr = new String[i2];
            int[] iArr = new int[i2];
            for (int i3 = 0; i3 < i2; i3++) {
                iArr[i3] = (int) K(byteArrayInputStream, 2);
                strArr[i3] = new String(D(byteArrayInputStream, (int) K(byteArrayInputStream, 2)), StandardCharsets.UTF_8);
            }
            for (int i4 = 0; i4 < i2; i4++) {
                up upVar = upVarArr[i4];
                if (upVar.b.equals(strArr[i4])) {
                    int i5 = iArr[i4];
                    upVar.e = i5;
                    upVar.h = E(byteArrayInputStream, i5);
                } else {
                    od.p("Order of dexfiles in metadata did not match baseline");
                    return null;
                }
            }
            return upVarArr;
        }
        od.p("Mismatched number of dex files found in metadata");
        return null;
    }

    public static up[] I(ByteArrayInputStream byteArrayInputStream, byte[] bArr, int i2, up[] upVarArr) {
        String str;
        up upVar;
        if (byteArrayInputStream.available() == 0) {
            return new up[0];
        }
        if (i2 == upVarArr.length) {
            for (int i3 = 0; i3 < i2; i3++) {
                K(byteArrayInputStream, 2);
                String str2 = new String(D(byteArrayInputStream, (int) K(byteArrayInputStream, 2)), StandardCharsets.UTF_8);
                long K = K(byteArrayInputStream, 4);
                int K2 = (int) K(byteArrayInputStream, 2);
                if (upVarArr.length > 0) {
                    int indexOf = str2.indexOf("!");
                    if (indexOf < 0) {
                        indexOf = str2.indexOf(":");
                    }
                    if (indexOf > 0) {
                        str = str2.substring(indexOf + 1);
                    } else {
                        str = str2;
                    }
                    for (int i4 = 0; i4 < upVarArr.length; i4++) {
                        if (upVarArr[i4].b.equals(str)) {
                            upVar = upVarArr[i4];
                            break;
                        }
                    }
                }
                upVar = null;
                if (upVar != null) {
                    upVar.d = K;
                    int[] E = E(byteArrayInputStream, K2);
                    if (Arrays.equals(bArr, ac.x)) {
                        upVar.e = K2;
                        upVar.h = E;
                    }
                } else {
                    od.p("Missing profile key: ".concat(str2));
                    return null;
                }
            }
            return upVarArr;
        }
        od.p("Mismatched number of dex files found in metadata");
        return null;
    }

    public static up[] J(FileInputStream fileInputStream, byte[] bArr, String str) {
        if (Arrays.equals(bArr, ac.u)) {
            int K = (int) K(fileInputStream, 1);
            byte[] F = F(fileInputStream, (int) K(fileInputStream, 4), (int) K(fileInputStream, 4));
            if (fileInputStream.read() <= 0) {
                ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(F);
                try {
                    up[] L = L(byteArrayInputStream, str, K);
                    byteArrayInputStream.close();
                    return L;
                } catch (Throwable th) {
                    try {
                        byteArrayInputStream.close();
                    } catch (Throwable th2) {
                        th.addSuppressed(th2);
                    }
                    throw th;
                }
            }
            od.p("Content found after the end of file");
            return null;
        }
        od.p("Unsupported version");
        return null;
    }

    public static long K(InputStream inputStream, int i2) {
        byte[] D = D(inputStream, i2);
        long j2 = 0;
        for (int i3 = 0; i3 < i2; i3++) {
            j2 += (D[i3] & 255) << (i3 * 8);
        }
        return j2;
    }

    public static up[] L(ByteArrayInputStream byteArrayInputStream, String str, int i2) {
        int i3;
        int i4 = 0;
        if (byteArrayInputStream.available() == 0) {
            return new up[0];
        }
        up[] upVarArr = new up[i2];
        for (int i5 = 0; i5 < i2; i5++) {
            int K = (int) K(byteArrayInputStream, 2);
            upVarArr[i5] = new up(str, new String(D(byteArrayInputStream, (int) K(byteArrayInputStream, 2)), StandardCharsets.UTF_8), K(byteArrayInputStream, 4), K, (int) K(byteArrayInputStream, 4), (int) K(byteArrayInputStream, 4), new int[K], new TreeMap());
        }
        int i6 = 0;
        while (i6 < i2) {
            up upVar = upVarArr[i6];
            int available = byteArrayInputStream.available();
            int i7 = upVar.f;
            int i8 = upVar.g;
            TreeMap treeMap = upVar.i;
            int i9 = available - i7;
            int i10 = i4;
            while (byteArrayInputStream.available() > i9) {
                i10 += (int) K(byteArrayInputStream, 2);
                treeMap.put(Integer.valueOf(i10), 1);
                int K2 = (int) K(byteArrayInputStream, 2);
                while (K2 > 0) {
                    K(byteArrayInputStream, 2);
                    int K3 = (int) K(byteArrayInputStream, 1);
                    if (K3 != 6 && K3 != 7) {
                        while (K3 > 0) {
                            K(byteArrayInputStream, 1);
                            int i11 = i4;
                            int i12 = i6;
                            for (int K4 = (int) K(byteArrayInputStream, 1); K4 > 0; K4--) {
                                K(byteArrayInputStream, 2);
                            }
                            K3--;
                            i4 = i11;
                            i6 = i12;
                        }
                    }
                    K2--;
                    i4 = i4;
                    i6 = i6;
                }
            }
            int i13 = i4;
            int i14 = i6;
            if (byteArrayInputStream.available() == i9) {
                upVar.h = E(byteArrayInputStream, upVar.e);
                BitSet valueOf = BitSet.valueOf(D(byteArrayInputStream, (((i8 * 2) + 7) & (-8)) / 8));
                for (int i15 = i13; i15 < i8; i15++) {
                    if (valueOf.get(i15)) {
                        i3 = 2;
                    } else {
                        i3 = i13;
                    }
                    if (valueOf.get(i15 + i8)) {
                        i3 |= 4;
                    }
                    if (i3 != 0) {
                        Integer num = (Integer) treeMap.get(Integer.valueOf(i15));
                        if (num == null) {
                            num = Integer.valueOf(i13);
                        }
                        treeMap.put(Integer.valueOf(i15), Integer.valueOf(i3 | num.intValue()));
                    }
                }
                i6 = i14 + 1;
                i4 = i13;
            } else {
                od.p("Read too much data during profile line parse");
                return null;
            }
        }
        return upVarArr;
    }

    public static final void M(ne neVar, ml mlVar, boolean z) {
        Object g2;
        te1 te1Var;
        Object obj = ne.k.get(neVar);
        Throwable f2 = neVar.f(obj);
        if (f2 != null) {
            g2 = new px0(f2);
        } else {
            g2 = neVar.g(obj);
        }
        if (z) {
            mlVar.getClass();
            gq gqVar = (gq) mlVar;
            nl nlVar = gqVar.i;
            Object obj2 = gqVar.k;
            sl e2 = nlVar.e();
            Object X = gh0.X(e2, obj2);
            if (X != gh0.m) {
                te1Var = j70.P(nlVar, e2, X);
            } else {
                te1Var = null;
            }
            try {
                nlVar.h(g2);
                if (te1Var != null && !te1Var.i0()) {
                    return;
                }
                gh0.O(e2, X);
                return;
            } catch (Throwable th) {
                if (te1Var == null || te1Var.i0()) {
                    gh0.O(e2, X);
                }
                throw th;
            }
        }
        mlVar.h(g2);
    }

    /* JADX WARN: Type inference failed for: r5v4, types: [nw0, java.lang.Object] */
    public static final Object N(ry ryVar, int i2, i00 i00Var) {
        int i3;
        int i4;
        Object obj;
        ry ryVar2;
        bb0 v0;
        int max;
        long g2;
        int size;
        int i5;
        em0 em0Var;
        if (!ryVar.e.r) {
            p50.b("visitAncestors called on an unattached node");
        }
        li0 li0Var = ryVar.e.i;
        ba0 O = k70.O(ryVar);
        loop0: while (true) {
            i3 = 0;
            i4 = 1;
            obj = null;
            if (O != null) {
                if ((O.J.f.h & 1024) != 0) {
                    while (li0Var != null) {
                        if ((li0Var.g & 1024) != 0) {
                            ryVar2 = li0Var;
                            qk0 qk0Var = null;
                            while (ryVar2 != null) {
                                if (ryVar2 instanceof ry) {
                                    break loop0;
                                }
                                if ((ryVar2.g & 1024) != 0 && (ryVar2 instanceof dp)) {
                                    int i6 = 0;
                                    for (li0 li0Var2 = ((dp) ryVar2).t; li0Var2 != null; li0Var2 = li0Var2.j) {
                                        if ((li0Var2.g & 1024) != 0) {
                                            i6++;
                                            if (i6 == 1) {
                                                ryVar2 = li0Var2;
                                            } else {
                                                if (qk0Var == null) {
                                                    qk0Var = new qk0(new li0[16]);
                                                }
                                                if (ryVar2 != null) {
                                                    qk0Var.b(ryVar2);
                                                    ryVar2 = null;
                                                }
                                                qk0Var.b(li0Var2);
                                            }
                                        }
                                    }
                                    if (i6 == 1) {
                                    }
                                }
                                ryVar2 = k70.m(qk0Var);
                            }
                            continue;
                        }
                        li0Var = li0Var.i;
                    }
                }
                O = O.v();
                if (O != null && (em0Var = O.J) != null) {
                    li0Var = em0Var.e;
                } else {
                    li0Var = null;
                }
            } else {
                ryVar2 = null;
                break;
            }
        }
        ry ryVar3 = ryVar2;
        if ((ryVar3 == null || !k70.p(ryVar3.v0(), ryVar.v0())) && (v0 = ryVar.v0()) != null) {
            int i7 = 5;
            if (i2 != 5) {
                i7 = 6;
                if (i2 != 6) {
                    i7 = 3;
                    if (i2 != 3) {
                        i7 = 4;
                        if (i2 != 4) {
                            if (i2 == 1) {
                                i7 = 2;
                            } else if (i2 == 2) {
                                i7 = 1;
                            } else {
                                od.p("Unsupported direction for beyond bounds layout");
                            }
                        }
                    }
                }
            }
            if (v0.s.a.g().n > 0 && !v0.s.a.g().k.isEmpty() && v0.r) {
                boolean s0 = v0.s0(i7);
                ec0 ec0Var = v0.s;
                if (s0) {
                    max = Math.min(ec0Var.a.g().n - 1, ((oc0) tg.W(ec0Var.a.g().k)).a);
                } else {
                    max = Math.max(0, ((iq0) ec0Var.a.e.b).g());
                }
                ?? obj2 = new Object();
                sc scVar = v0.t;
                scVar.getClass();
                xa0 xa0Var = new xa0(max, max);
                scVar.a.b(xa0Var);
                obj2.e = xa0Var;
                sc0 sc0Var = v0.s.a;
                if (sc0Var.g().k.isEmpty()) {
                    i4 = 0;
                } else {
                    nc0 g3 = sc0Var.g();
                    if (g3.o == bp0.e) {
                        g2 = g3.g() & 4294967295L;
                    } else {
                        g2 = g3.g() >> 32;
                    }
                    int i8 = (int) g2;
                    nc0 g4 = sc0Var.g();
                    List list = g4.k;
                    if (list.isEmpty()) {
                        size = 0;
                    } else {
                        int size2 = list.size();
                        int i9 = 0;
                        for (int i10 = 0; i10 < size2; i10++) {
                            i9 += ((oc0) list.get(i10)).j;
                        }
                        size = (i9 / list.size()) + g4.q;
                    }
                    if (size != 0 && (i5 = i8 / size) >= 1) {
                        i4 = i5;
                    }
                }
                int i11 = i4 * 2;
                int i12 = v0.s.a.g().n;
                if (i11 > i12) {
                    i11 = i12;
                }
                while (obj == null && v0.r0((xa0) obj2.e, i7) && i3 < i11) {
                    xa0 xa0Var2 = (xa0) obj2.e;
                    int i13 = xa0Var2.a;
                    int i14 = xa0Var2.b;
                    if (v0.s0(i7)) {
                        i14++;
                    } else {
                        i13--;
                    }
                    sc scVar2 = v0.t;
                    scVar2.getClass();
                    xa0 xa0Var3 = new xa0(i13, i14);
                    scVar2.a.b(xa0Var3);
                    v0.t.a.j((xa0) obj2.e);
                    obj2.e = xa0Var3;
                    i3++;
                    k70.O(v0).k();
                    obj = i00Var.i(new ab0(v0, obj2, i7));
                }
                v0.t.a.j((xa0) obj2.e);
                k70.O(v0).k();
                return obj;
            }
            return i00Var.i(bb0.v);
        }
        return null;
    }

    /* JADX WARN: Finally extract failed */
    public static boolean O(ByteArrayOutputStream byteArrayOutputStream, byte[] bArr, up[] upVarArr) {
        int i2;
        long j2;
        int length;
        byte[] bArr2 = ac.x;
        byte[] bArr3 = ac.w;
        byte[] bArr4 = ac.t;
        int i3 = 0;
        if (Arrays.equals(bArr, bArr4)) {
            ArrayList arrayList = new ArrayList(3);
            ArrayList arrayList2 = new ArrayList(3);
            ByteArrayOutputStream byteArrayOutputStream2 = new ByteArrayOutputStream();
            try {
                V(byteArrayOutputStream2, upVarArr.length);
                int i4 = 2;
                int i5 = 2;
                for (up upVar : upVarArr) {
                    U(byteArrayOutputStream2, upVar.c, 4);
                    U(byteArrayOutputStream2, upVar.d, 4);
                    U(byteArrayOutputStream2, upVar.g, 4);
                    String s = s(bArr4, upVar.a, upVar.b);
                    Charset charset = StandardCharsets.UTF_8;
                    int length2 = s.getBytes(charset).length;
                    V(byteArrayOutputStream2, length2);
                    i5 = i5 + 14 + length2;
                    byteArrayOutputStream2.write(s.getBytes(charset));
                }
                byte[] byteArray = byteArrayOutputStream2.toByteArray();
                if (i5 == byteArray.length) {
                    sl1 sl1Var = new sl1(1, byteArray, false);
                    byteArrayOutputStream2.close();
                    arrayList.add(sl1Var);
                    ByteArrayOutputStream byteArrayOutputStream3 = new ByteArrayOutputStream();
                    int i6 = 0;
                    int i7 = 0;
                    while (i6 < upVarArr.length) {
                        try {
                            up upVar2 = upVarArr[i6];
                            V(byteArrayOutputStream3, i6);
                            V(byteArrayOutputStream3, upVar2.e);
                            i7 = i7 + 4 + (upVar2.e * i4);
                            int[] iArr = upVar2.h;
                            int length3 = iArr.length;
                            int i8 = i3;
                            while (i3 < length3) {
                                int i9 = iArr[i3];
                                V(byteArrayOutputStream3, i9 - i8);
                                i3++;
                                i4 = i4;
                                i8 = i9;
                            }
                            i6++;
                            i3 = 0;
                        } catch (Throwable th) {
                            throw th;
                        }
                    }
                    int i10 = i4;
                    byte[] byteArray2 = byteArrayOutputStream3.toByteArray();
                    if (i7 == byteArray2.length) {
                        sl1 sl1Var2 = new sl1(3, byteArray2, true);
                        byteArrayOutputStream3.close();
                        arrayList.add(sl1Var2);
                        byteArrayOutputStream3 = new ByteArrayOutputStream();
                        int i11 = 0;
                        for (int i12 = 0; i12 < upVarArr.length; i12++) {
                            try {
                                up upVar3 = upVarArr[i12];
                                int i13 = 0;
                                for (Map.Entry entry : upVar3.i.entrySet()) {
                                    i13 |= ((Integer) entry.getValue()).intValue();
                                }
                                ByteArrayOutputStream byteArrayOutputStream4 = new ByteArrayOutputStream();
                                S(byteArrayOutputStream4, i13, upVar3);
                                byte[] byteArray3 = byteArrayOutputStream4.toByteArray();
                                byteArrayOutputStream4.close();
                                ByteArrayOutputStream byteArrayOutputStream5 = new ByteArrayOutputStream();
                                T(byteArrayOutputStream5, upVar3);
                                byte[] byteArray4 = byteArrayOutputStream5.toByteArray();
                                byteArrayOutputStream5.close();
                                V(byteArrayOutputStream3, i12);
                                int length4 = byteArray3.length + 2 + byteArray4.length;
                                int i14 = i11 + 6;
                                U(byteArrayOutputStream3, length4, 4);
                                V(byteArrayOutputStream3, i13);
                                byteArrayOutputStream3.write(byteArray3);
                                byteArrayOutputStream3.write(byteArray4);
                                i11 = i14 + length4;
                            } finally {
                                try {
                                    byteArrayOutputStream3.close();
                                } catch (Throwable th2) {
                                    th.addSuppressed(th2);
                                }
                            }
                        }
                        byte[] byteArray5 = byteArrayOutputStream3.toByteArray();
                        if (i11 == byteArray5.length) {
                            sl1 sl1Var3 = new sl1(4, byteArray5, true);
                            byteArrayOutputStream3.close();
                            arrayList.add(sl1Var3);
                            long size = 12 + (arrayList.size() * 16);
                            U(byteArrayOutputStream, arrayList.size(), 4);
                            int i15 = 0;
                            while (i15 < arrayList.size()) {
                                sl1 sl1Var4 = (sl1) arrayList.get(i15);
                                int i16 = sl1Var4.a;
                                byte[] bArr5 = sl1Var4.b;
                                if (i16 != 1) {
                                    i2 = i10;
                                    if (i16 != i2) {
                                        if (i16 != 3) {
                                            if (i16 != 4) {
                                                if (i16 == 5) {
                                                    j2 = 4;
                                                } else {
                                                    throw null;
                                                }
                                            } else {
                                                j2 = 3;
                                            }
                                        } else {
                                            j2 = 2;
                                        }
                                    } else {
                                        j2 = 1;
                                    }
                                } else {
                                    i2 = i10;
                                    j2 = 0;
                                }
                                U(byteArrayOutputStream, j2, 4);
                                U(byteArrayOutputStream, size, 4);
                                if (sl1Var4.c) {
                                    long length5 = bArr5.length;
                                    byte[] m2 = m(bArr5);
                                    arrayList2.add(m2);
                                    U(byteArrayOutputStream, m2.length, 4);
                                    U(byteArrayOutputStream, length5, 4);
                                    length = m2.length;
                                } else {
                                    arrayList2.add(bArr5);
                                    U(byteArrayOutputStream, bArr5.length, 4);
                                    U(byteArrayOutputStream, 0L, 4);
                                    length = bArr5.length;
                                }
                                size += length;
                                i15++;
                                i10 = i2;
                            }
                            for (int i17 = 0; i17 < arrayList2.size(); i17++) {
                                byteArrayOutputStream.write((byte[]) arrayList2.get(i17));
                            }
                            return true;
                        }
                        throw new IllegalStateException("Expected size " + i11 + ", does not match actual size " + byteArray5.length);
                    }
                    throw new IllegalStateException("Expected size " + i7 + ", does not match actual size " + byteArray2.length);
                }
                throw new IllegalStateException("Expected size " + i5 + ", does not match actual size " + byteArray.length);
            } catch (Throwable th3) {
                try {
                    byteArrayOutputStream2.close();
                } catch (Throwable th4) {
                    th3.addSuppressed(th4);
                }
                throw th3;
            }
        }
        byte[] bArr6 = ac.u;
        if (Arrays.equals(bArr, bArr6)) {
            byte[] o2 = o(upVarArr, bArr6);
            U(byteArrayOutputStream, upVarArr.length, 1);
            U(byteArrayOutputStream, o2.length, 4);
            byte[] m3 = m(o2);
            U(byteArrayOutputStream, m3.length, 4);
            byteArrayOutputStream.write(m3);
            return true;
        } else if (Arrays.equals(bArr, bArr3)) {
            U(byteArrayOutputStream, upVarArr.length, 1);
            for (up upVar4 : upVarArr) {
                String s2 = s(bArr3, upVar4.a, upVar4.b);
                Charset charset2 = StandardCharsets.UTF_8;
                V(byteArrayOutputStream, s2.getBytes(charset2).length);
                V(byteArrayOutputStream, upVar4.h.length);
                U(byteArrayOutputStream, upVar4.i.size() * 4, 4);
                U(byteArrayOutputStream, upVar4.c, 4);
                byteArrayOutputStream.write(s2.getBytes(charset2));
                for (Integer num : upVar4.i.keySet()) {
                    V(byteArrayOutputStream, num.intValue());
                    V(byteArrayOutputStream, 0);
                }
                for (int i18 : upVar4.h) {
                    V(byteArrayOutputStream, i18);
                }
            }
            return true;
        } else {
            byte[] bArr7 = ac.v;
            if (Arrays.equals(bArr, bArr7)) {
                byte[] o3 = o(upVarArr, bArr7);
                U(byteArrayOutputStream, upVarArr.length, 1);
                U(byteArrayOutputStream, o3.length, 4);
                byte[] m4 = m(o3);
                U(byteArrayOutputStream, m4.length, 4);
                byteArrayOutputStream.write(m4);
                return true;
            } else if (Arrays.equals(bArr, bArr2)) {
                V(byteArrayOutputStream, upVarArr.length);
                for (up upVar5 : upVarArr) {
                    String str = upVar5.a;
                    TreeMap treeMap = upVar5.i;
                    String s3 = s(bArr2, str, upVar5.b);
                    Charset charset3 = StandardCharsets.UTF_8;
                    V(byteArrayOutputStream, s3.getBytes(charset3).length);
                    V(byteArrayOutputStream, treeMap.size());
                    V(byteArrayOutputStream, upVar5.h.length);
                    U(byteArrayOutputStream, upVar5.c, 4);
                    byteArrayOutputStream.write(s3.getBytes(charset3));
                    for (Integer num2 : treeMap.keySet()) {
                        V(byteArrayOutputStream, num2.intValue());
                    }
                    for (int i19 : upVar5.h) {
                        V(byteArrayOutputStream, i19);
                    }
                }
                return true;
            } else {
                return false;
            }
        }
    }

    public static final boolean P(Throwable th, xz xzVar) {
        List asList;
        Object invoke;
        th.getClass();
        Integer num = x70.a;
        vp vpVar = null;
        if (num != null && num.intValue() < 19) {
            Method method = os0.b;
            if (method != null && (invoke = method.invoke(th, null)) != null) {
                asList = Arrays.asList((Throwable[]) invoke);
                asList.getClass();
            } else {
                asList = ut.e;
            }
        } else {
            Throwable[] suppressed = th.getSuppressed();
            suppressed.getClass();
            asList = Arrays.asList(suppressed);
            asList.getClass();
        }
        int size = asList.size();
        boolean z = false;
        for (int i2 = 0; i2 < size; i2++) {
            if (((Throwable) asList.get(i2)) instanceof vp) {
                return false;
            }
        }
        try {
            ej ejVar = (ej) xzVar.a();
            if (ejVar != null) {
                boolean z2 = ejVar.b;
                List list = ejVar.a;
                if (z2) {
                    int size2 = list.size();
                    for (int i3 = 0; i3 < size2; i3++) {
                        ((gj) list.get(i3)).getClass();
                    }
                } else if (!list.isEmpty()) {
                    z = true;
                }
            }
            if (z) {
                ejVar.getClass();
                vpVar = new vp(ejVar);
            }
        } catch (Throwable th2) {
            vpVar = th2;
        }
        if (vpVar != null) {
            ac.i(th, vpVar);
        }
        return z;
    }

    public static void Q(ByteArrayOutputStream byteArrayOutputStream, up upVar) {
        T(byteArrayOutputStream, upVar);
        int i2 = upVar.g;
        int[] iArr = upVar.h;
        int length = iArr.length;
        int i3 = 0;
        int i4 = 0;
        while (i3 < length) {
            int i5 = iArr[i3];
            V(byteArrayOutputStream, i5 - i4);
            i3++;
            i4 = i5;
        }
        byte[] bArr = new byte[(((i2 * 2) + 7) & (-8)) / 8];
        for (Map.Entry entry : upVar.i.entrySet()) {
            int intValue = ((Integer) entry.getKey()).intValue();
            int intValue2 = ((Integer) entry.getValue()).intValue();
            if ((intValue2 & 2) != 0) {
                int i6 = intValue / 8;
                bArr[i6] = (byte) (bArr[i6] | (1 << (intValue % 8)));
            }
            if ((intValue2 & 4) != 0) {
                int i7 = intValue + i2;
                int i8 = i7 / 8;
                bArr[i8] = (byte) ((1 << (i7 % 8)) | bArr[i8]);
            }
        }
        byteArrayOutputStream.write(bArr);
    }

    public static void R(ByteArrayOutputStream byteArrayOutputStream, up upVar, String str) {
        Charset charset = StandardCharsets.UTF_8;
        V(byteArrayOutputStream, str.getBytes(charset).length);
        V(byteArrayOutputStream, upVar.e);
        U(byteArrayOutputStream, upVar.f, 4);
        U(byteArrayOutputStream, upVar.c, 4);
        U(byteArrayOutputStream, upVar.g, 4);
        byteArrayOutputStream.write(str.getBytes(charset));
    }

    public static void S(ByteArrayOutputStream byteArrayOutputStream, int i2, up upVar) {
        int i3 = upVar.g;
        byte[] bArr = new byte[(((Integer.bitCount(i2 & (-2)) * i3) + 7) & (-8)) / 8];
        for (Map.Entry entry : upVar.i.entrySet()) {
            int intValue = ((Integer) entry.getKey()).intValue();
            int intValue2 = ((Integer) entry.getValue()).intValue();
            int i4 = 0;
            for (int i5 = 1; i5 <= 4; i5 <<= 1) {
                if (i5 != 1 && (i5 & i2) != 0) {
                    if ((i5 & intValue2) == i5) {
                        int i6 = (i4 * i3) + intValue;
                        int i7 = i6 / 8;
                        bArr[i7] = (byte) ((1 << (i6 % 8)) | bArr[i7]);
                    }
                    i4++;
                }
            }
        }
        byteArrayOutputStream.write(bArr);
    }

    public static void T(ByteArrayOutputStream byteArrayOutputStream, up upVar) {
        int i2 = 0;
        for (Map.Entry entry : upVar.i.entrySet()) {
            int intValue = ((Integer) entry.getKey()).intValue();
            if ((((Integer) entry.getValue()).intValue() & 1) != 0) {
                V(byteArrayOutputStream, intValue - i2);
                V(byteArrayOutputStream, 0);
                i2 = intValue;
            }
        }
    }

    public static void U(ByteArrayOutputStream byteArrayOutputStream, long j2, int i2) {
        byte[] bArr = new byte[i2];
        for (int i3 = 0; i3 < i2; i3++) {
            bArr[i3] = (byte) ((j2 >> (i3 * 8)) & 255);
        }
        byteArrayOutputStream.write(bArr);
    }

    public static void V(ByteArrayOutputStream byteArrayOutputStream, int i2) {
        U(byteArrayOutputStream, i2, 2);
    }

    public static final void a(final xz xzVar, final pi piVar, mi0 mi0Var, final m00 m00Var, final m00 m00Var2, final m00 m00Var3, y41 y41Var, long j2, long j3, long j4, long j5, yp ypVar, d10 d10Var, final int i2) {
        final mi0 mi0Var2;
        final y41 y41Var2;
        final long j6;
        final long j7;
        final long j8;
        final long j9;
        final yp ypVar2;
        int i3;
        y41 y41Var3;
        ji0 ji0Var;
        long j10;
        long j11;
        long j12;
        long j13;
        yp ypVar3;
        d10Var.X(94478519);
        int i4 = i2 | (d10Var.h(xzVar) ? 4 : 2) | 306209152;
        if (d10Var.O(i4 & 1, (306783379 & i4) != 306783378)) {
            d10Var.T();
            if ((i2 & 1) != 0 && !d10Var.y()) {
                d10Var.R();
                i3 = i4 & (-2143289345);
                ji0Var = mi0Var;
                y41Var3 = y41Var;
                j13 = j2;
                j12 = j3;
                j11 = j4;
                j10 = j5;
                ypVar3 = ypVar;
            } else {
                y41 a2 = d51.a(zi1.i, d10Var);
                long d2 = fh.d(zi1.h, d10Var);
                long d3 = fh.d(zi1.n, d10Var);
                i3 = i4 & (-2143289345);
                long d4 = fh.d(zi1.j, d10Var);
                long d5 = fh.d(zi1.l, d10Var);
                yp ypVar4 = new yp(7);
                y41Var3 = a2;
                ji0Var = ji0.a;
                j10 = d5;
                j11 = d4;
                j12 = d3;
                j13 = d2;
                ypVar3 = ypVar4;
            }
            d10Var.q();
            d3.c(xzVar, piVar, ji0Var, m00Var, m00Var2, m00Var3, y41Var3, j13, j12, j11, j10, ypVar3, d10Var, i3 & 2147483646, 3456);
            mi0Var2 = ji0Var;
            j9 = j10;
            ypVar2 = ypVar3;
            j8 = j11;
            j7 = j12;
            y41Var2 = y41Var3;
            j6 = j13;
        } else {
            d10Var.R();
            mi0Var2 = mi0Var;
            y41Var2 = y41Var;
            j6 = j2;
            j7 = j3;
            j8 = j4;
            j9 = j5;
            ypVar2 = ypVar;
        }
        xv0 r = d10Var.r();
        if (r != null) {
            r.d = new m00(piVar, mi0Var2, m00Var, m00Var2, m00Var3, y41Var2, j6, j7, j8, j9, ypVar2, i2) { // from class: o3
                public final /* synthetic */ pi f;
                public final /* synthetic */ mi0 g;
                public final /* synthetic */ m00 h;
                public final /* synthetic */ m00 i;
                public final /* synthetic */ m00 j;
                public final /* synthetic */ y41 k;
                public final /* synthetic */ long l;
                public final /* synthetic */ long m;
                public final /* synthetic */ long n;
                public final /* synthetic */ long o;
                public final /* synthetic */ yp p;

                @Override // defpackage.m00
                public final Object f(Object obj, Object obj2) {
                    ((Integer) obj2).getClass();
                    int s = wc0.s(1772593);
                    a5.a(xz.this, this.f, this.g, this.h, this.i, this.j, this.k, this.l, this.m, this.n, this.o, this.p, (d10) obj, s);
                    return we1.a;
                }
            };
        }
    }

    public static final j5 b(String str) {
        Set singleton = Collections.singleton(str);
        singleton.getClass();
        return new j5(singleton);
    }

    public static h6 c(int i2, int i3, int i4) {
        Bitmap createBitmap;
        ay0 ay0Var = jh.e;
        Bitmap.Config I = ac.I(i4);
        if (Build.VERSION.SDK_INT >= 26) {
            createBitmap = Bitmap.createBitmap((DisplayMetrics) null, i2, i3, ac.I(i4), true, b9.a(ay0Var));
        } else {
            createBitmap = Bitmap.createBitmap((DisplayMetrics) null, i2, i3, I);
            createBitmap.setHasAlpha(true);
        }
        return new h6(createBitmap);
    }

    public static final int d(int i2, qk0 qk0Var) {
        int i3 = qk0Var.g - 1;
        int i4 = 0;
        while (i4 < i3) {
            int i5 = ((i3 - i4) / 2) + i4;
            Object[] objArr = qk0Var.e;
            int i6 = ((f70) objArr[i5]).a;
            if (i6 != i2) {
                if (i6 < i2) {
                    i4 = i5 + 1;
                    if (i2 < ((f70) objArr[i4]).a) {
                    }
                } else {
                    i3 = i5 - 1;
                }
            }
            return i5;
        }
        return i4;
    }

    public static final boolean e(View view, View view2) {
        if (!view2.equals(view)) {
            for (ViewParent parent = view2.getParent(); parent != null; parent = parent.getParent()) {
                if (parent == view) {
                    return true;
                }
            }
            return false;
        }
        return false;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:10:0x0023  */
    /* JADX WARN: Removed duplicated region for block: B:20:0x0041  */
    /* JADX WARN: Removed duplicated region for block: B:27:0x0069  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x008f  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x0092  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:33:0x0080 -> B:25:0x0063). Please submit an issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:34:0x0083 -> B:25:0x0063). Please submit an issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final Object f(List list, zm zmVar, nl nlVar) {
        rm rmVar;
        int i2;
        List list2;
        Iterator it;
        nw0 nw0Var;
        Throwable th;
        if (nlVar instanceof rm) {
            rm rmVar2 = (rm) nlVar;
            int i3 = rmVar2.k;
            if ((i3 & Integer.MIN_VALUE) != 0) {
                rmVar2.k = i3 - Integer.MIN_VALUE;
                rmVar = rmVar2;
                Object obj = rmVar.j;
                i2 = rmVar.k;
                Object obj2 = cm.e;
                if (i2 == 0) {
                    if (i2 != 1) {
                        if (i2 == 2) {
                            it = rmVar.i;
                            nw0Var = (nw0) rmVar.h;
                            try {
                                nb0.t(obj);
                                nw0Var = nw0Var;
                            } catch (Throwable th2) {
                                Object obj3 = nw0Var.e;
                                if (obj3 == null) {
                                    nw0Var.e = th2;
                                    nw0Var = nw0Var;
                                } else {
                                    ac.i((Throwable) obj3, th2);
                                    nw0Var = nw0Var;
                                }
                            }
                            while (it.hasNext()) {
                                i00 i00Var = (i00) it.next();
                                rmVar.h = nw0Var;
                                rmVar.i = it;
                                rmVar.k = 2;
                                if (i00Var.i(rmVar) == obj2) {
                                    return obj2;
                                }
                            }
                            th = (Throwable) nw0Var.e;
                            if (th == null) {
                                return we1.a;
                            }
                            throw th;
                        }
                        od.p("call to 'resume' before 'invoke' with coroutine");
                        return null;
                    }
                    list2 = (List) rmVar.h;
                    nb0.t(obj);
                } else {
                    nb0.t(obj);
                    ArrayList arrayList = new ArrayList();
                    tm tmVar = new tm(list, arrayList, null);
                    rmVar.h = arrayList;
                    rmVar.k = 1;
                    if (zmVar.a(tmVar, rmVar) != obj2) {
                        list2 = arrayList;
                    } else {
                        return obj2;
                    }
                }
                Object obj4 = new Object();
                it = list2.iterator();
                nw0Var = obj4;
                while (it.hasNext()) {
                }
                th = (Throwable) nw0Var.e;
                if (th == null) {
                }
            }
        }
        rmVar = new nl(nlVar);
        Object obj5 = rmVar.j;
        i2 = rmVar.k;
        Object obj22 = cm.e;
        if (i2 == 0) {
        }
        Object obj42 = new Object();
        it = list2.iterator();
        nw0Var = obj42;
        while (it.hasNext()) {
        }
        th = (Throwable) nw0Var.e;
        if (th == null) {
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:10:0x001f  */
    /* JADX WARN: Removed duplicated region for block: B:14:0x0032  */
    /* JADX WARN: Type inference failed for: r7v0, types: [kw0, java.lang.Object] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final Object g(y11 y11Var, long j2, nl nlVar) {
        i11 i11Var;
        int i2;
        y11 y11Var2;
        kw0 kw0Var;
        if (nlVar instanceof i11) {
            i11 i11Var2 = (i11) nlVar;
            int i3 = i11Var2.k;
            if ((i3 & Integer.MIN_VALUE) != 0) {
                i11Var2.k = i3 - Integer.MIN_VALUE;
                i11Var = i11Var2;
                Object obj = i11Var.j;
                i2 = i11Var.k;
                if (i2 == 0) {
                    if (i2 == 1) {
                        kw0 kw0Var2 = i11Var.i;
                        y11 y11Var3 = i11Var.h;
                        nb0.t(obj);
                        kw0Var = kw0Var2;
                        y11Var2 = y11Var3;
                    } else {
                        od.p("call to 'resume' before 'invoke' with coroutine");
                        return null;
                    }
                } else {
                    nb0.t(obj);
                    ?? obj2 = new Object();
                    g gVar = new g(y11Var, j2, obj2, null, 1);
                    i11Var.h = y11Var;
                    i11Var.i = obj2;
                    i11Var.k = 1;
                    Object f2 = y11Var.f(tk0.e, gVar, i11Var);
                    cm cmVar = cm.e;
                    if (f2 == cmVar) {
                        return cmVar;
                    }
                    y11Var2 = y11Var;
                    kw0Var = obj2;
                }
                return new xm0(y11Var2.h(kw0Var.e));
            }
        }
        i11Var = new nl(nlVar);
        Object obj3 = i11Var.j;
        i2 = i11Var.k;
        if (i2 == 0) {
        }
        return new xm0(y11Var2.h(kw0Var.e));
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:10:0x0020  */
    /* JADX WARN: Removed duplicated region for block: B:14:0x0034  */
    /* JADX WARN: Removed duplicated region for block: B:20:0x005c A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:23:0x0068  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:19:0x005a -> B:21:0x005d). Please submit an issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final Object h(x91 x91Var, at0 at0Var, db dbVar) {
        sz szVar;
        int i2;
        cm cmVar;
        int size;
        int i3;
        if (dbVar instanceof sz) {
            sz szVar2 = (sz) dbVar;
            int i4 = szVar2.k;
            if ((i4 & Integer.MIN_VALUE) != 0) {
                szVar2.k = i4 - Integer.MIN_VALUE;
                szVar = szVar2;
                Object obj = szVar.j;
                i2 = szVar.k;
                if (i2 == 0) {
                    if (i2 == 1) {
                        at0 at0Var2 = szVar.i;
                        x91 x91Var2 = szVar.h;
                        nb0.t(obj);
                        at0Var = at0Var2;
                        x91Var = x91Var2;
                        List list = ((zs0) obj).a;
                        size = list.size();
                        i3 = 0;
                        while (i3 < size) {
                            if (((dt0) list.get(i3)).d) {
                                szVar.h = x91Var;
                                szVar.i = at0Var;
                                szVar.k = 1;
                                obj = x91Var.c(at0Var, szVar);
                                cmVar = cm.e;
                                if (obj == cmVar) {
                                    return cmVar;
                                }
                                List list2 = ((zs0) obj).a;
                                size = list2.size();
                                i3 = 0;
                                while (i3 < size) {
                                }
                            } else {
                                i3++;
                            }
                        }
                        return we1.a;
                    }
                    od.p("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                nb0.t(obj);
                List list3 = x91Var.j.w.a;
                int size2 = list3.size();
                for (int i5 = 0; i5 < size2; i5++) {
                    if (((dt0) list3.get(i5)).d) {
                        szVar.h = x91Var;
                        szVar.i = at0Var;
                        szVar.k = 1;
                        obj = x91Var.c(at0Var, szVar);
                        cmVar = cm.e;
                        if (obj == cmVar) {
                        }
                        List list22 = ((zs0) obj).a;
                        size = list22.size();
                        i3 = 0;
                        while (i3 < size) {
                        }
                        return we1.a;
                    }
                }
                return we1.a;
            }
        }
        szVar = new nl(dbVar);
        Object obj2 = szVar.j;
        i2 = szVar.k;
        if (i2 == 0) {
        }
    }

    public static final Object i(ht0 ht0Var, m00 m00Var, ml mlVar) {
        cm cmVar;
        we1 we1Var;
        tz tzVar = new tz(mlVar.e(), m00Var, null);
        y91 y91Var = (y91) ht0Var;
        y91Var.getClass();
        ne neVar = new ne(1, ac.x(mlVar));
        neVar.t();
        x91 x91Var = new x91(y91Var, neVar);
        synchronized (y91Var.y) {
            y91Var.x.b(x91Var);
            ml x = ac.x(ac.m(x91Var, x91Var, tzVar));
            cmVar = cm.e;
            bz0 bz0Var = new bz0(x);
            we1Var = we1.a;
            bz0Var.h(we1Var);
        }
        neVar.v(new j3(24, x91Var));
        Object s = neVar.s();
        if (s == cmVar) {
            return s;
        }
        return we1Var;
    }

    public static final Bundle j(zp0... zp0VarArr) {
        Bundle bundle = new Bundle(zp0VarArr.length);
        for (zp0 zp0Var : zp0VarArr) {
            String str = (String) zp0Var.e;
            Object obj = zp0Var.f;
            if (obj == null) {
                bundle.putString(str, null);
            } else if (obj instanceof Boolean) {
                bundle.putBoolean(str, ((Boolean) obj).booleanValue());
            } else if (obj instanceof Byte) {
                bundle.putByte(str, ((Number) obj).byteValue());
            } else if (obj instanceof Character) {
                bundle.putChar(str, ((Character) obj).charValue());
            } else if (obj instanceof Double) {
                bundle.putDouble(str, ((Number) obj).doubleValue());
            } else if (obj instanceof Float) {
                bundle.putFloat(str, ((Number) obj).floatValue());
            } else if (obj instanceof Integer) {
                bundle.putInt(str, ((Number) obj).intValue());
            } else if (obj instanceof Long) {
                bundle.putLong(str, ((Number) obj).longValue());
            } else if (obj instanceof Short) {
                bundle.putShort(str, ((Number) obj).shortValue());
            } else if (obj instanceof Bundle) {
                bundle.putBundle(str, (Bundle) obj);
            } else if (obj instanceof CharSequence) {
                bundle.putCharSequence(str, (CharSequence) obj);
            } else if (obj instanceof Parcelable) {
                bundle.putParcelable(str, (Parcelable) obj);
            } else if (obj instanceof boolean[]) {
                bundle.putBooleanArray(str, (boolean[]) obj);
            } else if (obj instanceof byte[]) {
                bundle.putByteArray(str, (byte[]) obj);
            } else if (obj instanceof char[]) {
                bundle.putCharArray(str, (char[]) obj);
            } else if (obj instanceof double[]) {
                bundle.putDoubleArray(str, (double[]) obj);
            } else if (obj instanceof float[]) {
                bundle.putFloatArray(str, (float[]) obj);
            } else if (obj instanceof int[]) {
                bundle.putIntArray(str, (int[]) obj);
            } else if (obj instanceof long[]) {
                bundle.putLongArray(str, (long[]) obj);
            } else if (obj instanceof short[]) {
                bundle.putShortArray(str, (short[]) obj);
            } else if (obj instanceof Object[]) {
                Class<?> componentType = obj.getClass().getComponentType();
                componentType.getClass();
                if (Parcelable.class.isAssignableFrom(componentType)) {
                    bundle.putParcelableArray(str, (Parcelable[]) obj);
                } else if (String.class.isAssignableFrom(componentType)) {
                    bundle.putStringArray(str, (String[]) obj);
                } else if (CharSequence.class.isAssignableFrom(componentType)) {
                    bundle.putCharSequenceArray(str, (CharSequence[]) obj);
                } else if (Serializable.class.isAssignableFrom(componentType)) {
                    bundle.putSerializable(str, (Serializable) obj);
                } else {
                    od.i("Illegal value array type ", componentType.getCanonicalName(), " for key \"", str, 34);
                    return null;
                }
            } else if (obj instanceof Serializable) {
                bundle.putSerializable(str, (Serializable) obj);
            } else if (obj instanceof IBinder) {
                bundle.putBinder(str, (IBinder) obj);
            } else if (obj instanceof Size) {
                bundle.putSize(str, (Size) obj);
            } else if (obj instanceof SizeF) {
                bundle.putSizeF(str, (SizeF) obj);
            } else {
                od.i("Illegal value type ", obj.getClass().getCanonicalName(), " for key \"", str, 34);
                return null;
            }
        }
        return bundle;
    }

    public static final boolean k(Object obj) {
        if (obj instanceof r61) {
            r61 r61Var = (r61) obj;
            if (r61Var.d() == e3.X || r61Var.d() == nq0.j || r61Var.d() == nq0.h) {
                Object value = r61Var.getValue();
                if (value != null) {
                    return k(value);
                }
                return true;
            }
        } else if (!(obj instanceof u00) || !(obj instanceof Serializable)) {
            for (int i2 = 0; i2 < 7; i2++) {
                if (g[i2].isInstance(obj)) {
                    return true;
                }
            }
        }
        return false;
    }

    public static void l(int i2) {
        if (2 <= i2 && i2 < 37) {
            return;
        }
        StringBuilder H = fu0.H(i2, "radix ", " was not in valid range ");
        H.append(new o60(2, 36, 1));
        throw new IllegalArgumentException(H.toString());
    }

    public static byte[] m(byte[] bArr) {
        Deflater deflater = new Deflater(1);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        try {
            DeflaterOutputStream deflaterOutputStream = new DeflaterOutputStream(byteArrayOutputStream, deflater);
            deflaterOutputStream.write(bArr);
            deflaterOutputStream.close();
            deflater.end();
            return byteArrayOutputStream.toByteArray();
        } catch (Throwable th) {
            deflater.end();
            throw th;
        }
    }

    public static final u8 n(u8 u8Var) {
        u8 c2 = u8Var.c();
        int b2 = c2.b();
        for (int i2 = 0; i2 < b2; i2++) {
            c2.e(u8Var.a(i2), i2);
        }
        return c2;
    }

    public static byte[] o(up[] upVarArr, byte[] bArr) {
        int i2 = 0;
        int i3 = 0;
        for (up upVar : upVarArr) {
            i3 += ((((upVar.g * 2) + 7) & (-8)) / 8) + (upVar.e * 2) + s(bArr, upVar.a, upVar.b).getBytes(StandardCharsets.UTF_8).length + 16 + upVar.f;
        }
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(i3);
        if (Arrays.equals(bArr, ac.v)) {
            int length = upVarArr.length;
            while (i2 < length) {
                up upVar2 = upVarArr[i2];
                R(byteArrayOutputStream, upVar2, s(bArr, upVar2.a, upVar2.b));
                Q(byteArrayOutputStream, upVar2);
                i2++;
            }
        } else {
            for (up upVar3 : upVarArr) {
                R(byteArrayOutputStream, upVar3, s(bArr, upVar3.a, upVar3.b));
            }
            int length2 = upVarArr.length;
            while (i2 < length2) {
                Q(byteArrayOutputStream, upVarArr[i2]);
                i2++;
            }
        }
        if (byteArrayOutputStream.size() == i3) {
            return byteArrayOutputStream.toByteArray();
        }
        throw new IllegalStateException("The bytes saved do not match expectation. actual=" + byteArrayOutputStream.size() + " expected=" + i3);
    }

    public static final float p(float[] fArr, int i2, float[] fArr2, int i3) {
        int i4 = i2 * 4;
        float f2 = (fArr[i4 + 1] * fArr2[4 + i3]) + (fArr[i4] * fArr2[i3]);
        return (fArr[i4 + 3] * fArr2[12 + i3]) + (fArr[i4 + 2] * fArr2[8 + i3]) + f2;
    }

    /* JADX WARN: Code restructure failed: missing block: B:32:0x0083, code lost:
        if (r1.k(r10, r0) == r5) goto L17;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:10:0x0023  */
    /* JADX WARN: Removed duplicated region for block: B:22:0x0049  */
    /* JADX WARN: Removed duplicated region for block: B:27:0x0064  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x0065  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x0071 A[Catch: all -> 0x0035, TRY_LEAVE, TryCatch #0 {all -> 0x0035, blocks: (B:13:0x002f, B:25:0x0054, B:29:0x0069, B:31:0x0071, B:20:0x0045, B:24:0x0050), top: B:50:0x0021 }] */
    /* JADX WARN: Removed duplicated region for block: B:34:0x0086  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:32:0x0083 -> B:14:0x0032). Please submit an issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static final Object q(uw uwVar, ye yeVar, boolean z, nl nlVar) {
        vw vwVar;
        int i2;
        CancellationException cancellationException;
        hd it;
        hd hdVar;
        uw uwVar2;
        Object b2;
        try {
            if (nlVar instanceof vw) {
                vw vwVar2 = (vw) nlVar;
                int i3 = vwVar2.m;
                if ((i3 & Integer.MIN_VALUE) != 0) {
                    vwVar2.m = i3 - Integer.MIN_VALUE;
                    vwVar = vwVar2;
                    Object obj = vwVar.l;
                    i2 = vwVar.m;
                    cancellationException = null;
                    cm cmVar = cm.e;
                    if (i2 == 0) {
                        if (i2 != 1) {
                            if (i2 == 2) {
                                z = vwVar.k;
                                hdVar = vwVar.j;
                                yeVar = vwVar.i;
                                uwVar2 = vwVar.h;
                                nb0.t(obj);
                                it = hdVar;
                                uwVar = uwVar2;
                                vwVar.h = uwVar;
                                vwVar.i = yeVar;
                                vwVar.j = it;
                                vwVar.k = z;
                                vwVar.m = 1;
                                b2 = it.b(vwVar);
                                if (b2 == cmVar) {
                                    uwVar2 = uwVar;
                                    hdVar = it;
                                    obj = b2;
                                    if (!((Boolean) obj).booleanValue()) {
                                        Object c2 = hdVar.c();
                                        vwVar.h = uwVar2;
                                        vwVar.i = yeVar;
                                        vwVar.j = hdVar;
                                        vwVar.k = z;
                                        vwVar.m = 2;
                                    } else {
                                        if (z) {
                                            yeVar.a(null);
                                        }
                                        return we1.a;
                                    }
                                } else {
                                    return cmVar;
                                }
                            } else {
                                od.p("call to 'resume' before 'invoke' with coroutine");
                                return null;
                            }
                        } else {
                            z = vwVar.k;
                            hdVar = vwVar.j;
                            yeVar = vwVar.i;
                            uwVar2 = vwVar.h;
                            nb0.t(obj);
                            if (!((Boolean) obj).booleanValue()) {
                            }
                        }
                    } else {
                        nb0.t(obj);
                        if (!(uwVar instanceof dc1)) {
                            it = yeVar.iterator();
                            vwVar.h = uwVar;
                            vwVar.i = yeVar;
                            vwVar.j = it;
                            vwVar.k = z;
                            vwVar.m = 1;
                            b2 = it.b(vwVar);
                            if (b2 == cmVar) {
                            }
                        } else {
                            throw ((dc1) uwVar).e;
                        }
                    }
                }
            }
            if (i2 == 0) {
            }
        } catch (Throwable th) {
            try {
                throw th;
            } catch (Throwable th2) {
                if (z) {
                    if (th instanceof CancellationException) {
                        cancellationException = th;
                    }
                    if (cancellationException == null) {
                        cancellationException = new CancellationException("Channel was consumed, consumer had failed");
                        cancellationException.initCause(th);
                    }
                    yeVar.a(cancellationException);
                }
                throw th2;
            }
        }
        vwVar = new nl(nlVar);
        Object obj2 = vwVar.l;
        i2 = vwVar.m;
        cancellationException = null;
        cm cmVar2 = cm.e;
    }

    public static final boolean r(long j2, long j3) {
        if (j2 == j3) {
            return true;
        }
        return false;
    }

    public static String s(byte[] bArr, String str, String str2) {
        Object obj;
        byte[] bArr2 = ac.w;
        byte[] bArr3 = ac.x;
        String str3 = "!";
        if (!Arrays.equals(bArr, bArr3) && !Arrays.equals(bArr, bArr2)) {
            obj = "!";
        } else {
            obj = ":";
        }
        if (str.length() <= 0) {
            if ("!".equals(obj)) {
                return str2.replace(":", "!");
            }
            if (":".equals(obj)) {
                return str2.replace("!", ":");
            }
        } else if (str2.equals("classes.dex")) {
            return str;
        } else {
            if (!str2.contains("!") && !str2.contains(":")) {
                if (!str2.endsWith(".apk")) {
                    StringBuilder sb = new StringBuilder();
                    sb.append(str);
                    sb.append((Arrays.equals(bArr, bArr3) || Arrays.equals(bArr, bArr2)) ? ":" : ":");
                    sb.append(str2);
                    return sb.toString();
                }
            } else if ("!".equals(obj)) {
                return str2.replace(":", "!");
            } else {
                if (":".equals(obj)) {
                    return str2.replace("!", ":");
                }
            }
        }
        return str2;
    }

    public static final int t(pz pzVar, int i2) {
        boolean z;
        boolean z2;
        if (k70.y(pzVar.e, pz.f.e) >= 0) {
            z = true;
        } else {
            z = false;
        }
        if (i2 == 1) {
            z2 = true;
        } else {
            z2 = false;
        }
        if (z2 && z) {
            return 3;
        }
        if (z) {
            return 1;
        }
        if (!z2) {
            return 0;
        }
        return 2;
    }

    public static final String[] u(jl jlVar) {
        jlVar.getClass();
        return (String[]) ((j5) jlVar).b.toArray(new String[0]);
    }

    public static final int v(KeyEvent keyEvent) {
        int action = keyEvent.getAction();
        if (action != 0) {
            if (action == 1) {
                return 1;
            }
            return 0;
        }
        return 2;
    }

    public static final ig w(fh1 fh1Var) {
        ig igVar;
        w20 w20Var;
        fh1Var.getClass();
        synchronized (q) {
            igVar = (ig) fh1Var.c("androidx.lifecycle.viewmodel.internal.ViewModelCoroutineScope.JOB_KEY");
            if (igVar == null) {
                st stVar = st.e;
                try {
                    uo uoVar = kq.a;
                    w20Var = kg0.a.j;
                } catch (IllegalStateException | qm0 unused) {
                }
                ig igVar2 = new ig(w20Var.i(ua0.e()));
                fh1Var.a("androidx.lifecycle.viewmodel.internal.ViewModelCoroutineScope.JOB_KEY", igVar2);
                igVar = igVar2;
            }
        }
        return igVar;
    }

    public static final void x(ds dsVar) {
        if (((li0) dsVar).e.r) {
            k70.M(dsVar, 1).F0();
        }
    }

    public static boolean y(char c2) {
        if (!Character.isWhitespace(c2) && !Character.isSpaceChar(c2)) {
            return false;
        }
        return true;
    }

    public static final mi0 z(n00 n00Var) {
        return new p90(n00Var);
    }
}