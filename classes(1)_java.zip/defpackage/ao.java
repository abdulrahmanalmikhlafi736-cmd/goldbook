package defpackage;

import androidx.compose.ui.input.pointer.PointerInputEventHandler;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ao  reason: default package */
public final class ao extends u91 implements m00 {
    public final /* synthetic */ int i;
    public int j;
    public /* synthetic */ Object k;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public ao(sc0 sc0Var, int i, ml mlVar) {
        super(2, mlVar);
        this.i = 4;
        this.k = sc0Var;
        this.j = i;
    }

    @Override // defpackage.m00
    public final Object f(Object obj, Object obj2) {
        int i = this.i;
        we1 we1Var = we1.a;
        switch (i) {
            case 0:
                return ((ao) n((ml) obj2, (bm) obj)).p(we1Var);
            case 1:
                return ((ao) n((ml) obj2, (bm) obj)).p(we1Var);
            case 2:
                return ((ao) n((ml) obj2, (bm) obj)).p(we1Var);
            case 3:
                return ((ao) n((ml) obj2, (bm) obj)).p(we1Var);
            case gu0.LONG_FIELD_NUMBER /* 4 */:
                ((ao) n((ml) obj2, (a11) obj)).p(we1Var);
                return we1Var;
            case gu0.STRING_FIELD_NUMBER /* 5 */:
                return ((ao) n((ml) obj2, (bm) obj)).p(we1Var);
            case gu0.STRING_SET_FIELD_NUMBER /* 6 */:
                return ((ao) n((ml) obj2, (bm) obj)).p(we1Var);
            case gu0.DOUBLE_FIELD_NUMBER /* 7 */:
                return ((ao) n((ml) obj2, (bm) obj)).p(we1Var);
            case 8:
                return ((ao) n((ml) obj2, (bm) obj)).p(we1Var);
            default:
                return ((ao) n((ml) obj2, (bm) obj)).p(we1Var);
        }
    }

    @Override // defpackage.db
    public final ml n(ml mlVar, Object obj) {
        switch (this.i) {
            case 0:
                return new ao((bo) this.k, mlVar, 0);
            case 1:
                return new ao((vy) this.k, mlVar, 1);
            case 2:
                return new ao((mk0) this.k, mlVar, 2);
            case 3:
                return new ao((al) this.k, mlVar, 3);
            case gu0.LONG_FIELD_NUMBER /* 4 */:
                return new ao((sc0) this.k, this.j, mlVar);
            case gu0.STRING_FIELD_NUMBER /* 5 */:
                ao aoVar = new ao(2, mlVar);
                aoVar.k = obj;
                return aoVar;
            case gu0.STRING_SET_FIELD_NUMBER /* 6 */:
                return new ao((tp) this.k, mlVar, 6);
            case gu0.DOUBLE_FIELD_NUMBER /* 7 */:
                return new ao((t41) this.k, mlVar, 7);
            case 8:
                return new ao((y91) this.k, mlVar, 8);
            default:
                return new ao((hc1) this.k, mlVar, 9);
        }
    }

    /* JADX WARN: Type inference failed for: r7v0, types: [java.lang.Object, java.io.Serializable] */
    @Override // defpackage.db
    public final Object p(Object obj) {
        bm bmVar;
        int i = this.i;
        we1 we1Var = we1.a;
        cm cmVar = cm.e;
        switch (i) {
            case 0:
                int i2 = this.j;
                if (i2 != 0) {
                    if (i2 == 1) {
                        nb0.t(obj);
                        return we1Var;
                    }
                    od.p("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                nb0.t(obj);
                ?? obj2 = new Object();
                Object obj3 = new Object();
                Object obj4 = new Object();
                bo boVar = (bo) this.k;
                g51 g51Var = boVar.s.a;
                ef efVar = new ef(obj2, obj3, obj4, boVar, 1);
                this.j = 1;
                g51Var.getClass();
                g51.j(g51Var, efVar, this);
                return cmVar;
            case 1:
                int i3 = this.j;
                if (i3 != 0) {
                    if (i3 == 1) {
                        nb0.t(obj);
                        return we1Var;
                    }
                    od.p("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                nb0.t(obj);
                this.j = 1;
                if (vd1.g((vy) this.k, null, this) == cmVar) {
                    return cmVar;
                }
                return we1Var;
            case 2:
                mk0 mk0Var = (mk0) this.k;
                int i4 = this.j;
                if (i4 != 0) {
                    if (i4 == 1) {
                        nb0.t(obj);
                    } else {
                        od.p("call to 'resume' before 'invoke' with coroutine");
                        return null;
                    }
                } else {
                    nb0.t(obj);
                    if (((Boolean) mk0Var.getValue()).booleanValue()) {
                        this.j = 1;
                        if (j70.A(1500L, this) == cmVar) {
                            return cmVar;
                        }
                    } else {
                        return we1Var;
                    }
                }
                mk0Var.setValue(Boolean.FALSE);
                return we1Var;
            case 3:
                int i5 = this.j;
                if (i5 != 0) {
                    if (i5 == 1) {
                        nb0.t(obj);
                        return we1Var;
                    }
                    od.p("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                nb0.t(obj);
                Float f = new Float(0.0f);
                p71 G = zi1.G(0.0f, 400.0f, new Float(0.5f), 1);
                this.j = 1;
                if (wa0.c((p8) ((al) this.k).g, f, G, new f11(3), this) == cmVar) {
                    return cmVar;
                }
                return we1Var;
            case gu0.LONG_FIELD_NUMBER /* 4 */:
                nb0.t(obj);
                sc0 sc0Var = (sc0) this.k;
                int i6 = this.j;
                rf rfVar = sc0Var.e;
                if (((iq0) rfVar.b).g() != i6 || ((iq0) rfVar.c).g() != 0) {
                    fb0 fb0Var = sc0Var.n;
                    fb0Var.c();
                    fb0Var.b = null;
                }
                rfVar.b(i6, 0);
                rfVar.d = null;
                ba0 ba0Var = sc0Var.k;
                if (ba0Var != null) {
                    ba0Var.k();
                }
                return we1Var;
            case gu0.STRING_FIELD_NUMBER /* 5 */:
                int i7 = this.j;
                if (i7 != 0) {
                    if (i7 == 1) {
                        bmVar = (bm) this.k;
                        nb0.t(obj);
                    } else {
                        od.p("call to 'resume' before 'invoke' with coroutine");
                        return null;
                    }
                } else {
                    nb0.t(obj);
                    bmVar = (bm) this.k;
                }
                while (j70.L(bmVar.f())) {
                    z1 z1Var = new z1(15);
                    this.k = bmVar;
                    this.j = 1;
                    sl slVar = this.f;
                    slVar.getClass();
                    if (sb0.o(slVar).c(z1Var, this) == cmVar) {
                        return cmVar;
                    }
                }
                return we1Var;
            case gu0.STRING_SET_FIELD_NUMBER /* 6 */:
                int i8 = this.j;
                if (i8 != 0) {
                    if (i8 == 1) {
                        nb0.t(obj);
                        return obj;
                    }
                    od.p("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                nb0.t(obj);
                this.j = 1;
                Object i9 = vd1.i(new d((id) ((tp) this.k).f, null, 12), this);
                if (i9 == cmVar) {
                    return cmVar;
                }
                return i9;
            case gu0.DOUBLE_FIELD_NUMBER /* 7 */:
                int i10 = this.j;
                if (i10 != 0) {
                    if (i10 == 1) {
                        nb0.t(obj);
                        return obj;
                    }
                    od.p("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                nb0.t(obj);
                tw twVar = ((t41) this.k).c.b;
                this.j = 1;
                Object x = wl1.x(twVar, this);
                if (x == cmVar) {
                    return cmVar;
                }
                return x;
            case 8:
                y91 y91Var = (y91) this.k;
                int i11 = this.j;
                if (i11 != 0) {
                    if (i11 == 1 || i11 == 2) {
                        nb0.t(obj);
                        return we1Var;
                    }
                    od.p("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                nb0.t(obj);
                PointerInputEventHandler pointerInputEventHandler = y91Var.u;
                this.j = 2;
                if (pointerInputEventHandler.invoke(y91Var, this) == cmVar) {
                    return cmVar;
                }
                return we1Var;
            default:
                int i12 = this.j;
                if (i12 != 0) {
                    if (i12 == 1) {
                        nb0.t(obj);
                        return we1Var;
                    }
                    od.p("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                nb0.t(obj);
                Object obj5 = new Object();
                hc1 hc1Var = (hc1) this.k;
                g51 g51Var2 = hc1Var.s.a;
                xq xqVar = new xq(5, obj5, hc1Var);
                this.j = 1;
                g51Var2.getClass();
                g51.j(g51Var2, xqVar, this);
                return cmVar;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ ao(int i, ml mlVar) {
        super(i, mlVar);
        this.i = 5;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ ao(Object obj, ml mlVar, int i) {
        super(2, mlVar);
        this.i = i;
        this.k = obj;
    }
}