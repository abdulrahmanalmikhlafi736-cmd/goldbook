package defpackage;

import java.util.Iterator;
import java.util.Map;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: e61  reason: default package */
public final class e61 implements Iterator {
    public int e = -1;
    public boolean f;
    public Iterator g;
    public final /* synthetic */ c61 h;

    public e61(c61 c61Var) {
        this.h = c61Var;
    }

    public final Iterator a() {
        if (this.g == null) {
            this.g = this.h.f.entrySet().iterator();
        }
        return this.g;
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        int i = this.e + 1;
        c61 c61Var = this.h;
        if (i < c61Var.e.size() || (!c61Var.f.isEmpty() && a().hasNext())) {
            return true;
        }
        return false;
    }

    @Override // java.util.Iterator
    public final Object next() {
        this.f = true;
        int i = this.e + 1;
        this.e = i;
        c61 c61Var = this.h;
        if (i < c61Var.e.size()) {
            return (Map.Entry) c61Var.e.get(this.e);
        }
        return (Map.Entry) a().next();
    }

    @Override // java.util.Iterator
    public final void remove() {
        if (this.f) {
            this.f = false;
            int i = c61.j;
            c61 c61Var = this.h;
            c61Var.b();
            if (this.e < c61Var.e.size()) {
                int i2 = this.e;
                this.e = i2 - 1;
                c61Var.h(i2);
                return;
            }
            a().remove();
            return;
        }
        od.p("remove() was called before next()");
    }
}