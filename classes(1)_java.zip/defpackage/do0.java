package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: do0  reason: default package */
public final class do0 extends xo0 {
    public static final do0 c = new xo0(0, 1, 1);

    @Override // defpackage.xo0
    public final void a(pg pgVar, m9 m9Var, a61 a61Var, uw0 uw0Var, yo0 yo0Var) {
        y00 y00Var = (y00) pgVar.c(0);
        y00Var.getClass();
        a61Var.l(a61Var.c(y00Var));
    }
}