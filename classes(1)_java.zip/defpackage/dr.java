package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dr  reason: default package */
public final class dr {
    public final long a;

    public /* synthetic */ dr(long j) {
        this.a = j;
    }

    public final boolean equals(Object obj) {
        if (obj instanceof dr) {
            if (this.a != ((dr) obj).a) {
                return false;
            }
            return true;
        }
        return false;
    }

    public final int hashCode() {
        long j = this.a;
        return (int) (j ^ (j >>> 32));
    }

    public final String toString() {
        long j = this.a;
        if (j != 9205357640488583168L) {
            return "(" + ((Object) br.c(Float.intBitsToFloat((int) (j >> 32)))) + ", " + ((Object) br.c(Float.intBitsToFloat((int) (4294967295L & j)))) + ')';
        }
        return "DpOffset.Unspecified";
    }
}