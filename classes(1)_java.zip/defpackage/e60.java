package defpackage;

import android.graphics.Rect;
import android.os.Build;
import android.view.View;
import android.view.ViewParent;
import java.util.Collections;
import java.util.List;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: e60  reason: default package */
public final class e60 extends og implements Runnable, an0, View.OnAttachStateChangeListener {
    public boolean g;
    public int h;
    public hk1 i;
    public final hk0 j;
    public final iq0 k;
    public final ak0 l;
    public final z61 m;

    public e60() {
        super(1);
        hk0 hk0Var = new hk0(9);
        nk1.a.getClass();
        hk0Var.m(mk1.b, new dl1("caption bar"));
        hk0Var.m(mk1.c, new dl1("display cutout"));
        hk0Var.m(mk1.d, new dl1("ime"));
        hk0Var.m(mk1.e, new dl1("mandatory system gestures"));
        hk0Var.m(mk1.f, new dl1("navigation bars"));
        hk0Var.m(mk1.g, new dl1("status bars"));
        hk0Var.m(mk1.h, new dl1("system gestures"));
        hk0Var.m(mk1.i, new dl1("tappable element"));
        hk0Var.m(mk1.j, new dl1("waterfall"));
        this.j = hk0Var;
        this.k = new iq0(0);
        this.l = new ak0(4);
        this.m = new z61();
    }

    public final void E(hk1 hk1Var) {
        char c;
        char c2;
        boolean z;
        char c3;
        boolean z2;
        boolean z3;
        long j;
        List list;
        boolean z4;
        long[] jArr;
        int[] iArr;
        Object[] objArr;
        long[] jArr2;
        int[] iArr2;
        Object[] objArr2;
        long j2;
        int i;
        sj0 sj0Var = pk1.a;
        int[] iArr3 = sj0Var.b;
        Object[] objArr3 = sj0Var.c;
        long[] jArr3 = sj0Var.a;
        int length = jArr3.length - 2;
        if (length >= 0) {
            int i2 = 0;
            z2 = false;
            z3 = false;
            c = 16;
            c2 = ' ';
            while (true) {
                long j3 = jArr3[i2];
                z = true;
                if ((((~j3) << 7) & j3 & (-9187201950435737472L)) != -9187201950435737472L) {
                    int i3 = 8;
                    int i4 = 8 - ((~(i2 - length)) >>> 31);
                    int i5 = 0;
                    c3 = '0';
                    while (i5 < i4) {
                        if ((j3 & 255) < 128) {
                            int i6 = (i2 << 3) + i5;
                            int i7 = iArr3[i6];
                            nk1 nk1Var = (nk1) objArr3[i6];
                            c60 i8 = hk1Var.a.i(i7);
                            jArr2 = jArr3;
                            iArr2 = iArr3;
                            long j4 = (i8.a << 48) | (i8.b << 32) | (i8.c << 16) | i8.d;
                            Object g = this.j.g(nk1Var);
                            g.getClass();
                            dl1 dl1Var = (dl1) g;
                            j2 = j3;
                            if (!wa0.i(j4, dl1Var.h)) {
                                dl1Var.h = j4;
                                z2 = true;
                                if (!wa0.i(j4, 0L)) {
                                    z3 = true;
                                }
                            }
                            if (i7 != 8) {
                                c60 j5 = hk1Var.a.j(i7);
                                objArr2 = objArr3;
                                long j6 = (j5.b << 32) | (j5.a << 48) | (j5.c << 16) | j5.d;
                                if (!wa0.i(dl1Var.i, j6)) {
                                    dl1Var.i = j6;
                                    z2 = true;
                                    if (!wa0.i(j6, 0L)) {
                                        z3 = true;
                                    }
                                }
                            } else {
                                objArr2 = objArr3;
                            }
                            dl1Var.a.setValue(Boolean.valueOf(hk1Var.a.u(i7)));
                            i = 8;
                        } else {
                            jArr2 = jArr3;
                            iArr2 = iArr3;
                            objArr2 = objArr3;
                            j2 = j3;
                            i = i3;
                        }
                        j3 = j2 >> i;
                        i5++;
                        i3 = i;
                        objArr3 = objArr2;
                        jArr3 = jArr2;
                        iArr3 = iArr2;
                    }
                    jArr = jArr3;
                    iArr = iArr3;
                    objArr = objArr3;
                    if (i4 != i3) {
                        break;
                    }
                } else {
                    jArr = jArr3;
                    iArr = iArr3;
                    objArr = objArr3;
                    c3 = '0';
                }
                if (i2 == length) {
                    break;
                }
                i2++;
                objArr3 = objArr;
                jArr3 = jArr;
                iArr3 = iArr;
            }
        } else {
            c = 16;
            c2 = ' ';
            z = true;
            c3 = '0';
            z2 = false;
            z3 = false;
        }
        mq h = hk1Var.a.h();
        if (h == null) {
            j = 0;
        } else {
            c60 a = h.a();
            j = (a.a << c3) | (a.b << c2) | (a.c << c) | a.d;
        }
        hk0 hk0Var = this.j;
        nk1.a.getClass();
        Object g2 = hk0Var.g(mk1.j);
        g2.getClass();
        dl1 dl1Var2 = (dl1) g2;
        dl1Var2.a.setValue(Boolean.valueOf(!wa0.i(j, 0L)));
        if (!wa0.i(dl1Var2.h, j)) {
            dl1Var2.h = j;
            dl1Var2.i = j;
            z2 = z;
            if (!wa0.i(j, 0L)) {
                z3 = z2;
            }
        }
        if (h == null) {
            ak0 ak0Var = this.l;
            if (ak0Var.b > 0) {
                ak0Var.d();
                this.m.clear();
                z2 = z;
            }
        } else {
            if (Build.VERSION.SDK_INT >= 28) {
                list = lq.b(h.a);
            } else {
                list = Collections.EMPTY_LIST;
            }
            int size = list.size();
            ak0 ak0Var2 = this.l;
            if (size < ak0Var2.b) {
                ak0Var2.l(list.size(), this.l.b);
                this.m.e(list.size(), this.m.size());
                z2 = z;
            } else {
                int size2 = list.size() - this.l.b;
                int i9 = 0;
                while (i9 < size2) {
                    ak0 ak0Var3 = this.l;
                    ak0Var3.a(mc0.t(list.get(ak0Var3.b)));
                    this.m.add(new w50("display cutout rect " + this.l.b));
                    i9++;
                    z2 = z;
                }
            }
            int size3 = list.size();
            for (int i10 = 0; i10 < size3; i10++) {
                Rect rect = (Rect) list.get(i10);
                mk0 mk0Var = (mk0) this.l.f(i10);
                if (!k70.p(mk0Var.getValue(), rect)) {
                    mk0Var.setValue(rect);
                    z2 = z;
                }
            }
            if (!list.isEmpty()) {
                z3 = z;
            }
        }
        if ((z3 || this.k.g() != 0) && z2) {
            iq0 iq0Var = this.k;
            iq0Var.h(iq0Var.g() + 1);
            synchronized (n61.c) {
                ik0 ik0Var = n61.j.h;
                if (ik0Var != null) {
                    boolean z5 = z;
                    if (ik0Var.h() == z5) {
                        z4 = z5;
                    }
                }
                z4 = false;
            }
            if (z4) {
                n61.a();
            }
        }
    }

    @Override // defpackage.an0
    public final hk1 b(View view, hk1 hk1Var) {
        if (this.g) {
            this.i = hk1Var;
            if (Build.VERSION.SDK_INT == 30) {
                view.post(this);
                return hk1Var;
            }
        } else if (this.h == 0) {
            E(hk1Var);
        }
        return hk1Var;
    }

    @Override // defpackage.og
    public final void e(mj1 mj1Var) {
        boolean z = false;
        this.g = false;
        int d = mj1Var.a.d();
        this.h &= ~d;
        this.i = null;
        nk1 nk1Var = (nk1) pk1.a.b(d);
        if (nk1Var != null) {
            Object g = this.j.g(nk1Var);
            g.getClass();
            dl1 dl1Var = (dl1) g;
            dl1Var.c.h(0.0f);
            dl1Var.e.h(1.0f);
            dl1Var.d.h(0L);
            dl1Var.c.h(0.0f);
            dl1Var.b.setValue(Boolean.FALSE);
            dl1Var.j = -1L;
            dl1Var.k = -1L;
            iq0 iq0Var = this.k;
            iq0Var.h(iq0Var.g() + 1);
            synchronized (n61.c) {
                ik0 ik0Var = n61.j.h;
                if (ik0Var != null) {
                    if (ik0Var.h()) {
                        z = true;
                    }
                }
            }
            if (z) {
                n61.a();
            }
        }
    }

    @Override // defpackage.og
    public final void f(mj1 mj1Var) {
        this.g = true;
    }

    @Override // defpackage.og
    public final hk1 g(hk1 hk1Var, List list) {
        int size = list.size();
        for (int i = 0; i < size; i++) {
            mj1 mj1Var = (mj1) list.get(i);
            nk1 nk1Var = (nk1) pk1.a.b(mj1Var.a.d());
            if (nk1Var != null) {
                Object g = this.j.g(nk1Var);
                g.getClass();
                dl1 dl1Var = (dl1) g;
                if (((Boolean) dl1Var.b.getValue()).booleanValue()) {
                    lj1 lj1Var = mj1Var.a;
                    dl1Var.c.h(lj1Var.c());
                    dl1Var.e.h(lj1Var.a());
                    dl1Var.d.h(lj1Var.b());
                }
            }
        }
        E(hk1Var);
        return hk1Var;
    }

    @Override // defpackage.og
    public final al h(mj1 mj1Var, al alVar) {
        hk1 hk1Var = this.i;
        boolean z = false;
        this.g = false;
        this.i = null;
        if (mj1Var.a.b() > 0 && hk1Var != null) {
            int d = mj1Var.a.d();
            this.h |= d;
            nk1 nk1Var = (nk1) pk1.a.b(d);
            if (nk1Var != null) {
                Object g = this.j.g(nk1Var);
                g.getClass();
                dl1 dl1Var = (dl1) g;
                c60 i = hk1Var.a.i(d);
                long j = (i.a << 48) | (i.b << 32) | (i.c << 16) | i.d;
                long j2 = dl1Var.h;
                if (!wa0.i(j, j2)) {
                    dl1Var.j = j2;
                    dl1Var.k = j;
                    dl1Var.b.setValue(Boolean.TRUE);
                    lj1 lj1Var = mj1Var.a;
                    dl1Var.c.h(lj1Var.c());
                    dl1Var.e.h(lj1Var.a());
                    dl1Var.d.h(lj1Var.b());
                    iq0 iq0Var = this.k;
                    iq0Var.h(iq0Var.g() + 1);
                    synchronized (n61.c) {
                        ik0 ik0Var = n61.j.h;
                        if (ik0Var != null) {
                            if (ik0Var.h()) {
                                z = true;
                            }
                        }
                    }
                    if (z) {
                        n61.a();
                        return alVar;
                    }
                }
            }
        }
        return alVar;
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public final void onViewAttachedToWindow(View view) {
        View view2;
        ViewParent parent = view.getParent();
        if (parent instanceof View) {
            view2 = (View) parent;
        } else {
            view2 = null;
        }
        if (view2 != null) {
            view = view2;
        }
        int i = vg1.a;
        qg1.b(view, this);
        vg1.b(view, this);
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public final void onViewDetachedFromWindow(View view) {
        View view2;
        ViewParent parent = view.getParent();
        if (parent instanceof View) {
            view2 = (View) parent;
        } else {
            view2 = null;
        }
        if (view2 != null) {
            view = view2;
        }
        int i = vg1.a;
        qg1.b(view, null);
        vg1.b(view, null);
    }

    @Override // java.lang.Runnable
    public final void run() {
        if (this.g) {
            this.h = 0;
            this.g = false;
            hk1 hk1Var = this.i;
            if (hk1Var != null) {
                E(hk1Var);
                this.i = null;
            }
        }
    }
}