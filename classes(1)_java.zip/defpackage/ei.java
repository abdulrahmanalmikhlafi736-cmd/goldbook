package defpackage;

import android.content.Context;
import android.os.Bundle;
import com.almekhlafi.goldbook.MainActivity;
import java.util.ArrayList;
import java.util.LinkedHashMap;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ei  reason: default package */
public final /* synthetic */ class ei {
    public final /* synthetic */ MainActivity a;

    public /* synthetic */ ei(MainActivity mainActivity) {
        this.a = mainActivity;
    }

    public final void a(Context context) {
        context.getClass();
        MainActivity mainActivity = this.a;
        Bundle k = ((al) mainActivity.h.g).k("android:support:activity-result");
        if (k != null) {
            ii iiVar = mainActivity.l;
            LinkedHashMap linkedHashMap = iiVar.b;
            LinkedHashMap linkedHashMap2 = iiVar.a;
            Bundle bundle = iiVar.g;
            ArrayList<Integer> integerArrayList = k.getIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS");
            ArrayList<String> stringArrayList = k.getStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS");
            if (stringArrayList != null && integerArrayList != null) {
                ArrayList<String> stringArrayList2 = k.getStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS");
                if (stringArrayList2 != null) {
                    iiVar.d.addAll(stringArrayList2);
                }
                Bundle bundle2 = k.getBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT");
                if (bundle2 != null) {
                    bundle.putAll(bundle2);
                }
                int size = stringArrayList.size();
                for (int i = 0; i < size; i++) {
                    String str = stringArrayList.get(i);
                    if (linkedHashMap.containsKey(str)) {
                        Integer num = (Integer) linkedHashMap.remove(str);
                        if (!bundle.containsKey(str)) {
                            vd1.d(linkedHashMap2).remove(num);
                        }
                    }
                    Integer num2 = integerArrayList.get(i);
                    num2.getClass();
                    int intValue = num2.intValue();
                    String str2 = stringArrayList.get(i);
                    str2.getClass();
                    String str3 = str2;
                    linkedHashMap2.put(Integer.valueOf(intValue), str3);
                    iiVar.b.put(str3, Integer.valueOf(intValue));
                }
            }
        }
    }
}