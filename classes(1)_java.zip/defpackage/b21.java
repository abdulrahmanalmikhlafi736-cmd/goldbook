package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: b21  reason: default package */
public abstract class b21 {
    public static final gk a = new gk(new hp0(7));
}