package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: bv  reason: default package */
public final class bv {
    public final int a;
    public final int b;

    public bv(int i, int i2) {
        this.a = i;
        this.b = i2;
    }
}