package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: c10  reason: default package */
public final class c10 {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;

    public /* synthetic */ c10(int i, Object obj) {
        this.a = i;
        this.b = obj;
    }

    public final void a() {
        int i = this.a;
        Object obj = this.b;
        switch (i) {
            case 0:
                d10 d10Var = (d10) obj;
                d10Var.A--;
                return;
            default:
                a71 a71Var = (a71) obj;
                a71Var.k--;
                return;
        }
    }

    public final void b() {
        int i = this.a;
        Object obj = this.b;
        switch (i) {
            case 0:
                ((d10) obj).A++;
                return;
            default:
                ((a71) obj).k++;
                return;
        }
    }
}