package defpackage;

import android.view.RenderNode;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: dx0  reason: default package */
public abstract class dx0 {
    public static void a(RenderNode renderNode) {
        renderNode.discardDisplayList();
    }
}