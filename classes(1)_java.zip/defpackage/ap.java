package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ap  reason: default package */
public class ap implements jh1 {
    public static final ap b = new ap(0);
    public static ap c;
    public final /* synthetic */ int a;

    public /* synthetic */ ap(int i) {
        this.a = i;
    }

    @Override // defpackage.jh1
    public fh1 a(Class cls) {
        switch (this.a) {
            case 0:
                throw new UnsupportedOperationException("`Factory.create(String, CreationExtras)` is not implemented. You may need to override the method and provide a custom implementation. Note that using `Factory.create(String)` is not supported and considered an error.");
            case 1:
                throw new UnsupportedOperationException("`Factory.create(String, CreationExtras)` is not implemented. You may need to override the method and provide a custom implementation. Note that using `Factory.create(String)` is not supported and considered an error.");
            default:
                return zi1.r(cls);
        }
    }

    @Override // defpackage.jh1
    public fh1 b(Class cls, pj0 pj0Var) {
        switch (this.a) {
            case 0:
                a(cls);
                throw null;
            case 1:
                a(cls);
                throw null;
            default:
                return a(cls);
        }
    }

    @Override // defpackage.jh1
    public final fh1 c(wf wfVar, pj0 pj0Var) {
        switch (this.a) {
            case 0:
                Class cls = wfVar.a;
                cls.getClass();
                return zi1.r(cls);
            case 1:
                return new tz0();
            default:
                Class cls2 = wfVar.a;
                cls2.getClass();
                return b(cls2, pj0Var);
        }
    }
}