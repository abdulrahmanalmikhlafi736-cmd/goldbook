package defpackage;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: c0  reason: default package */
public abstract class c0 extends v {
    public abstract c0 b(int i, Object obj);

    public abstract c0 c(Object obj);

    @Override // defpackage.m, java.util.Collection
    public final boolean contains(Object obj) {
        if (indexOf(obj) != -1) {
            return true;
        }
        return false;
    }

    @Override // defpackage.m, java.util.Collection, java.util.List
    public final boolean containsAll(Collection collection) {
        Collection<Object> collection2 = collection;
        if ((collection2 instanceof Collection) && collection2.isEmpty()) {
            return true;
        }
        for (Object obj : collection2) {
            if (!contains(obj)) {
                return false;
            }
        }
        return true;
    }

    public c0 e(Collection collection) {
        es0 f = f();
        f.addAll(collection);
        return f.c();
    }

    public abstract es0 f();

    public abstract c0 g(b0 b0Var);

    public abstract c0 h(int i);

    public abstract c0 i(int i, Object obj);

    @Override // defpackage.v, java.util.Collection, java.lang.Iterable, java.util.List
    public final Iterator iterator() {
        return listIterator(0);
    }

    @Override // defpackage.v, java.util.List
    public final ListIterator listIterator() {
        return listIterator(0);
    }

    @Override // defpackage.v, java.util.List
    public final List subList(int i, int i2) {
        return new j40(this, i, i2);
    }
}