package defpackage;

/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: cb0  reason: default package */
public final class cb0 extends qi0 {
    public final fb0 a;

    public cb0(fb0 fb0Var) {
        this.a = fb0Var;
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [li0, db0] */
    @Override // defpackage.qi0
    public final li0 e() {
        ?? li0Var = new li0();
        li0Var.s = this.a;
        return li0Var;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if ((obj instanceof cb0) && this.a == ((cb0) obj).a) {
            return true;
        }
        return false;
    }

    @Override // defpackage.qi0
    public final void f(li0 li0Var) {
        db0 db0Var = (db0) li0Var;
        fb0 fb0Var = db0Var.s;
        fb0 fb0Var2 = this.a;
        if (!k70.p(fb0Var, fb0Var2) && db0Var.e.r) {
            fb0 fb0Var3 = db0Var.s;
            fb0Var3.c();
            fb0Var3.b = null;
            db0Var.s = fb0Var2;
        }
    }

    public final int hashCode() {
        return this.a.hashCode();
    }

    public final String toString() {
        return "DisplayingDisappearingItemsElement(animator=" + this.a + ')';
    }
}