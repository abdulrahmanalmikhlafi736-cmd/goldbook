package defpackage;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: eh  reason: default package */
public final class eh {
    public static final eh e;
    public static final eh f;
    public static final eh g;
    public static final eh h;
    public static final eh i;
    public static final eh j;
    public static final eh k;
    public static final eh l;
    public static final eh m;
    public static final eh n;
    public static final eh o;
    public static final /* synthetic */ eh[] p;
    /* JADX INFO: Fake field, exist only in values array */
    eh EF0;

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13, types: [eh, java.lang.Enum] */
    /* JADX WARN: Type inference failed for: r0v17, types: [eh, java.lang.Enum] */
    /* JADX WARN: Type inference failed for: r0v21, types: [eh, java.lang.Enum] */
    /* JADX WARN: Type inference failed for: r0v25, types: [eh, java.lang.Enum] */
    /* JADX WARN: Type inference failed for: r1v10, types: [eh, java.lang.Enum] */
    /* JADX WARN: Type inference failed for: r1v12, types: [eh, java.lang.Enum] */
    /* JADX WARN: Type inference failed for: r1v24, types: [eh, java.lang.Enum] */
    /* JADX WARN: Type inference failed for: r1v4, types: [eh, java.lang.Enum] */
    /* JADX WARN: Type inference failed for: r2v3, types: [eh, java.lang.Enum] */
    /* JADX WARN: Type inference failed for: r2v6, types: [eh, java.lang.Enum] */
    /* JADX WARN: Type inference failed for: r4v3, types: [eh, java.lang.Enum] */
    static {
        Enum r0 = new Enum("Background", 0);
        Enum r1 = new Enum("Error", 1);
        Enum r3 = new Enum("ErrorContainer", 2);
        Enum r5 = new Enum("InverseOnSurface", 3);
        Enum r7 = new Enum("InversePrimary", 4);
        Enum r9 = new Enum("InverseSurface", 5);
        Enum r11 = new Enum("OnBackground", 6);
        Enum r13 = new Enum("OnError", 7);
        Enum r15 = new Enum("OnErrorContainer", 8);
        ?? r2 = new Enum("OnPrimary", 9);
        e = r2;
        ?? r4 = new Enum("OnPrimaryContainer", 10);
        f = r4;
        Enum r6 = new Enum("OnPrimaryFixed", 11);
        Enum r8 = new Enum("OnPrimaryFixedVariant", 12);
        Enum r10 = new Enum("OnSecondary", 13);
        Enum r12 = new Enum("OnSecondaryContainer", 14);
        Enum r14 = new Enum("OnSecondaryFixed", 15);
        Enum r02 = new Enum("OnSecondaryFixedVariant", 16);
        ?? r16 = new Enum("OnSurface", 17);
        g = r16;
        ?? r22 = new Enum("OnSurfaceVariant", 18);
        h = r22;
        Enum r03 = new Enum("OnTertiary", 19);
        Enum r17 = new Enum("OnTertiaryContainer", 20);
        Enum r23 = new Enum("OnTertiaryFixed", 21);
        Enum r04 = new Enum("OnTertiaryFixedVariant", 22);
        ?? r18 = new Enum("Outline", 23);
        i = r18;
        Enum r05 = new Enum("OutlineVariant", 24);
        ?? r19 = new Enum("Primary", 25);
        j = r19;
        ?? r06 = new Enum("PrimaryContainer", 26);
        k = r06;
        Enum r110 = new Enum("PrimaryFixed", 27);
        Enum r07 = new Enum("PrimaryFixedDim", 28);
        Enum r111 = new Enum("Scrim", 29);
        ?? r08 = new Enum("Secondary", 30);
        l = r08;
        Enum r112 = new Enum("SecondaryContainer", 31);
        Enum r09 = new Enum("SecondaryFixed", 32);
        Enum r113 = new Enum("SecondaryFixedDim", 33);
        ?? r010 = new Enum("Surface", 34);
        m = r010;
        Enum r114 = new Enum("SurfaceBright", 35);
        Enum r011 = new Enum("SurfaceContainer", 36);
        ?? r115 = new Enum("SurfaceContainerHigh", 37);
        n = r115;
        ?? r012 = new Enum("SurfaceContainerHighest", 38);
        o = r012;
        p = new eh[]{r0, r1, r3, r5, r7, r9, r11, r13, r15, r2, r4, r6, r8, r10, r12, r14, r02, r16, r22, r03, r17, r23, r04, r18, r05, r19, r06, r110, r07, r111, r08, r112, r09, r113, r010, r114, r011, r115, r012, new Enum("SurfaceContainerLow", 39), new Enum("SurfaceContainerLowest", 40), new Enum("SurfaceDim", 41), new Enum("SurfaceTint", 42), new Enum("SurfaceVariant", 43), new Enum("Tertiary", 44), new Enum("TertiaryContainer", 45), new Enum("TertiaryFixed", 46), new Enum("TertiaryFixedDim", 47)};
    }

    public static eh valueOf(String str) {
        return (eh) Enum.valueOf(eh.class, str);
    }

    public static eh[] values() {
        return (eh[]) p.clone();
    }
}