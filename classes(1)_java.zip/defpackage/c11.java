package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: c11  reason: default package */
public final class c11 implements r11 {
    public static final al j = new al(21, new c01(27), new b01(29));
    public final iq0 a;
    public float f;
    public final iq0 b = new iq0(0);
    public final iq0 c = new iq0(0);
    public final uj0 d = new uj0();
    public final iq0 e = new iq0(Integer.MAX_VALUE);
    public final wo g = new wo(new l(20, this));
    public final sp h = mc0.j(new b11(this, 0));
    public final sp i = mc0.j(new b11(this, 1));

    public c11(int i) {
        this.a = new iq0(i);
    }

    @Override // defpackage.r11
    public final boolean a() {
        return ((Boolean) this.i.getValue()).booleanValue();
    }

    @Override // defpackage.r11
    public final boolean b() {
        return this.g.b();
    }

    @Override // defpackage.r11
    public final boolean c() {
        return ((Boolean) this.h.getValue()).booleanValue();
    }

    @Override // defpackage.r11
    public final Object d(tk0 tk0Var, m00 m00Var, nl nlVar) {
        Object d = this.g.d(tk0Var, m00Var, nlVar);
        if (d == cm.e) {
            return d;
        }
        return we1.a;
    }

    @Override // defpackage.r11
    public final float e(float f) {
        return this.g.e(f);
    }
}