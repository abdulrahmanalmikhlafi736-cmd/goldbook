package defpackage;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
/* renamed from: ae  reason: default package */
public final class ae extends li0 implements vm0, nd, ds {
    public final be s;
    public boolean t;
    public final l u;

    public ae(be beVar, l lVar) {
        this.s = beVar;
        this.u = lVar;
        beVar.e = this;
    }

    @Override // defpackage.ds
    public final void C(da0 da0Var) {
        boolean z = this.t;
        be beVar = this.s;
        if (!z) {
            beVar.f = null;
            sb0.r(this, new g4(3, this, beVar));
            if (beVar.f != null) {
                this.t = true;
            } else {
                throw fu0.C("DrawResult not defined, did you forget to call onDraw?");
            }
        }
        pg0 pg0Var = beVar.f;
        pg0Var.getClass();
        ((i00) pg0Var.f).i(da0Var);
    }

    @Override // defpackage.ds
    public final void Z() {
        r0();
    }

    @Override // defpackage.nd
    public final jp a() {
        return k70.O(this).C;
    }

    @Override // defpackage.nd
    public final long b() {
        return wl1.M(k70.M(this, 4).g);
    }

    @Override // defpackage.nd
    public final o90 getLayoutDirection() {
        return k70.O(this).D;
    }

    @Override // defpackage.li0
    public final void i0() {
        r0();
    }

    @Override // defpackage.li0
    public final void j0() {
    }

    @Override // defpackage.li0
    public final void k0() {
        r0();
    }

    @Override // defpackage.li0
    public final void l0() {
        r0();
    }

    public final void r0() {
        this.t = false;
        this.s.f = null;
        a5.x(this);
    }

    @Override // defpackage.vm0
    public final void z() {
        r0();
    }
}