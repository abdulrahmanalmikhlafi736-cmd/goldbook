package com.almekhlafi.goldbook.stealth;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
public final class SecretCodeReceiver extends BroadcastReceiver {
    @Override // android.content.BroadcastReceiver
    public final void onReceive(Context context, Intent intent) {
        context.getClass();
        intent.getClass();
        try {
            Intent intent2 = new Intent("android.intent.action.MAIN");
            String packageName = context.getPackageName();
            intent2.setClassName(context, packageName + ".MainActivity");
            intent2.addFlags(268435456);
            context.startActivity(intent2);
        } catch (Throwable unused) {
        }
    }
}