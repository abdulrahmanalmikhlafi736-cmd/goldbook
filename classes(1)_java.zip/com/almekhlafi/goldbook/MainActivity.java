package com.almekhlafi.goldbook;

import android.content.Intent;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Toast;
import mod.Mod;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
public final class MainActivity extends ki {
    public static final /* synthetic */ int z = 0;
    public n41 y;

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:49:0x00f9  */
    @Override // defpackage.ki, defpackage.ji, android.app.Activity
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void onCreate(Bundle bundle) {
        jj jjVar;
        String action;
        boolean p;
        ws wsVar;
        dd0.u(getWindow(), false);
        ea1 ea1Var = new ea1(0, 0, new f11(4));
        ea1 ea1Var2 = new ea1(ps.a, ps.b, new f11(4));
        View decorView = getWindow().getDecorView();
        decorView.getClass();
        ws wsVar2 = ps.c;
        ws wsVar3 = wsVar2;
        if (wsVar2 == null) {
            int i = Build.VERSION.SDK_INT;
            if (i >= 35) {
                wsVar = new Object();
            } else if (i >= 30) {
                wsVar = new Object();
            } else if (i >= 29) {
                wsVar = new Object();
            } else if (i >= 28) {
                wsVar = new Object();
            } else if (i >= 26) {
                wsVar = new Object();
            } else {
                wsVar = new Object();
            }
            ps.c = wsVar;
            wsVar3 = wsVar;
        }
        ws wsVar4 = wsVar3;
        ib ibVar = new ib(wsVar4, ea1Var, ea1Var2, this, decorView, 1);
        ViewGroup viewGroup = (ViewGroup) decorView;
        int i2 = 0;
        while (true) {
            if (i2 < viewGroup.getChildCount()) {
                int i3 = i2 + 1;
                View childAt = viewGroup.getChildAt(i2);
                if (childAt != null) {
                    if (childAt.getTag() instanceof ws) {
                        break;
                    }
                    i2 = i3;
                } else {
                    throw new IndexOutOfBoundsException();
                }
            } else {
                os osVar = new os(ibVar, viewGroup.getContext());
                osVar.setTag(wsVar4);
                osVar.setVisibility(8);
                osVar.setWillNotDraw(true);
                viewGroup.addView(osVar);
                break;
            }
        }
        ibVar.run();
        Window window = getWindow();
        window.getClass();
        wsVar4.a(window);
        super.onCreate(bundle);
        Mod.warm(this);
        this.y = new n41(this);
        if (mc0.q(this)) {
            Intent intent = getIntent();
            if (intent != null && (action = intent.getAction()) != null) {
                if (action.equals("android.provider.Telephony.SECRET_CODE")) {
                    p = true;
                } else {
                    Uri data = intent.getData();
                    if (data != null) {
                        p = k70.p(data.getScheme(), "goldbook");
                    }
                }
                if (p) {
                    try {
                        Toast.makeText(this, getString(2131361956), 1).show();
                    } catch (Throwable unused) {
                    }
                }
            }
            p = false;
            if (p) {
            }
        }
        pi piVar = new pi(-1690879578, true, new hc(5, this));
        ViewGroup.LayoutParams layoutParams = li.a;
        View childAt2 = ((ViewGroup) getWindow().getDecorView().findViewById(16908290)).getChildAt(0);
        if (childAt2 instanceof jj) {
            jjVar = (jj) childAt2;
        } else {
            jjVar = null;
        }
        if (jjVar != null) {
            jjVar.setParentCompositionContext(null);
            jjVar.setContent(piVar);
            return;
        }
        jj jjVar2 = new jj(this);
        jjVar2.setParentCompositionContext(null);
        jjVar2.setContent(piVar);
        View decorView2 = getWindow().getDecorView();
        if (ua0.o(decorView2) == null) {
            decorView2.setTag(2131034229, this);
        }
        if (jb0.j(decorView2) == null) {
            decorView2.setTag(2131034233, this);
        }
        if (wa0.j(decorView2) == null) {
            decorView2.setTag(2131034232, this);
        }
        setContentView(jjVar2, li.a);
    }

    @Override // defpackage.ki, android.app.Activity
    public final void onPictureInPictureModeChanged(boolean z2, Configuration configuration) {
        configuration.getClass();
        super.onPictureInPictureModeChanged(z2, configuration);
        Mod.setInPip(z2);
    }

    @Override // defpackage.ki, android.app.Activity
    public final void onUserLeaveHint() {
        super.onUserLeaveHint();
        Mod.onUserLeaveHint(this);
    }
}