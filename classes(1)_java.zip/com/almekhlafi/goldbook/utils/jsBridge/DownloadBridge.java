package com.almekhlafi.goldbook.utils.jsBridge;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.widget.Toast;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
public final class DownloadBridge {
    public static final int $stable = 8;
    private final Context context;

    public DownloadBridge(Context context) {
        context.getClass();
        this.context = context;
    }

    @JavascriptInterface
    public final void downloadBase64File(String str, String str2) {
        Object px0Var;
        sd1 sd1Var;
        sd1 sd1Var2;
        Uri uri;
        str.getClass();
        str2.getClass();
        try {
        } catch (Throwable th) {
            px0Var = new px0(th);
        }
        if (!q81.z(str, ",")) {
            Context context = this.context;
            Toast.makeText(context, context.getString(2131361833), 0).show();
            return;
        }
        byte[] decode = Base64.decode((String) q81.H(str, new String[]{","}).get(1), 0);
        boolean startsWith = str2.startsWith("image/");
        boolean startsWith2 = str2.startsWith("video/");
        String str3 = "bin";
        if (startsWith) {
            Bitmap decodeByteArray = BitmapFactory.decodeByteArray(decode, 0, decode.length);
            if (decodeByteArray != null) {
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                decodeByteArray.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
                sd1Var2 = new sd1(byteArrayOutputStream.toByteArray(), "image/png", "png");
            } else {
                String extensionFromMimeType = MimeTypeMap.getSingleton().getExtensionFromMimeType(str2);
                if (extensionFromMimeType != null) {
                    str3 = extensionFromMimeType;
                }
                sd1Var = new sd1(decode, str2, str3);
                sd1Var2 = sd1Var;
            }
        } else if (startsWith2) {
            String extensionFromMimeType2 = MimeTypeMap.getSingleton().getExtensionFromMimeType(str2);
            if (extensionFromMimeType2 == null) {
                extensionFromMimeType2 = "mp4";
            }
            sd1Var2 = new sd1(decode, str2, extensionFromMimeType2);
        } else {
            String extensionFromMimeType3 = MimeTypeMap.getSingleton().getExtensionFromMimeType(str2);
            if (extensionFromMimeType3 != null) {
                str3 = extensionFromMimeType3;
            }
            sd1Var = new sd1(decode, str2, str3);
            sd1Var2 = sd1Var;
        }
        byte[] bArr = (byte[]) sd1Var2.e;
        String str4 = (String) sd1Var2.f;
        String str5 = sd1Var2.g;
        String str6 = System.currentTimeMillis() + "." + str5;
        int i = Build.VERSION.SDK_INT;
        px0Var = we1.a;
        if (i >= 29) {
            ContentValues contentValues = new ContentValues();
            contentValues.put("_display_name", str6);
            contentValues.put("mime_type", str4);
            contentValues.put("relative_path", Environment.DIRECTORY_DOWNLOADS);
            contentValues.put("is_pending", (Integer) 1);
            ContentResolver contentResolver = this.context.getContentResolver();
            uri = MediaStore.Downloads.EXTERNAL_CONTENT_URI;
            Uri insert = contentResolver.insert(uri, contentValues);
            if (insert != null) {
                OutputStream openOutputStream = contentResolver.openOutputStream(insert);
                if (openOutputStream != null) {
                    openOutputStream.write(bArr);
                    openOutputStream.close();
                }
                contentValues.clear();
                contentValues.put("is_pending", (Integer) 0);
                contentResolver.update(insert, contentValues, null, null);
                Context context2 = this.context;
                Toast.makeText(context2, context2.getString(2131361948), 0).show();
            } else {
                px0Var = null;
            }
        } else {
            FileOutputStream fileOutputStream = new FileOutputStream(new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), str6));
            fileOutputStream.write(bArr);
            fileOutputStream.close();
            Context context3 = this.context;
            Toast.makeText(context3, context3.getString(2131361948), 0).show();
        }
        if (qx0.a(px0Var) != null) {
            Context context4 = this.context;
            Toast.makeText(context4, context4.getString(2131361841), 0).show();
        }
    }
}