package com.almekhlafi.goldbook.utils.jsBridge;

import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
public final class NavigateFB {
    public static final int $stable = 0;
    private final xz onNavigate;

    public NavigateFB(xz xzVar) {
        xzVar.getClass();
        this.onNavigate = xzVar;
    }

    public static /* synthetic */ void a(NavigateFB navigateFB) {
        onNavigateFB$lambda$0(navigateFB);
    }

    public static final void onNavigateFB$lambda$0(NavigateFB navigateFB) {
        navigateFB.onNavigate.a();
    }

    @JavascriptInterface
    public final void onNavigateFB() {
        new Handler(Looper.getMainLooper()).post(new o4(6, this));
    }
}