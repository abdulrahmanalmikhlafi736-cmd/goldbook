package com.almekhlafi.goldbook.utils.jsBridge;

import android.graphics.Color;
import android.webkit.JavascriptInterface;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
public final class ThemeChange {
    public static final int $stable = 0;
    private final i00 setThemeColor;

    public ThemeChange(i00 i00Var) {
        i00Var.getClass();
        this.setThemeColor = i00Var;
    }

    @JavascriptInterface
    public final void onThemeColorChanged(String str) {
        if (str != null && !q81.E(str)) {
            try {
                this.setThemeColor.i(Integer.valueOf(Color.parseColor(str)));
            } catch (Throwable unused) {
            }
        }
    }
}