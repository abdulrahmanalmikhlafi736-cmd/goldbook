package com.almekhlafi.goldbook.utils.jsBridge;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
public final class ClipboardBridge {
    public static final int $stable = 8;
    private final Context context;

    public ClipboardBridge(Context context) {
        context.getClass();
        this.context = context;
    }

    @JavascriptInterface
    public final void copyImageToClipboard(String str, String str2) {
        Object px0Var;
        str.getClass();
        str2.getClass();
        try {
        } catch (Throwable th) {
            px0Var = new px0(th);
        }
        if (!q81.z(str, ",")) {
            Context context = this.context;
            Toast.makeText(context, context.getString(2131361824), 0).show();
            return;
        }
        byte[] decode = Base64.decode((String) q81.H(str, new String[]{","}).get(1), 0);
        Bitmap decodeByteArray = BitmapFactory.decodeByteArray(decode, 0, decode.length);
        Context context2 = this.context;
        if (decodeByteArray == null) {
            Toast.makeText(context2, context2.getString(2131361825), 0).show();
            return;
        }
        Object systemService = context2.getSystemService("clipboard");
        systemService.getClass();
        ClipboardManager clipboardManager = (ClipboardManager) systemService;
        if (Build.VERSION.SDK_INT >= 24) {
            File file = new File(this.context.getCacheDir(), "clipboard_images");
            if (!file.exists()) {
                file.mkdirs();
            }
            File[] listFiles = file.listFiles();
            if (listFiles != null) {
                for (File file2 : listFiles) {
                    if (System.currentTimeMillis() - file2.lastModified() > 3600000) {
                        file2.delete();
                    }
                }
            }
            File file3 = new File(file, "clipboard_" + System.currentTimeMillis() + ".png");
            FileOutputStream fileOutputStream = new FileOutputStream(file3);
            decodeByteArray.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream);
            fileOutputStream.close();
            Context context3 = this.context;
            Uri d = FileProvider.d(context3, context3.getPackageName() + ".fileprovider", file3);
            d.getClass();
            clipboardManager.setPrimaryClip(ClipData.newUri(this.context.getContentResolver(), "Image", d));
            Context context4 = this.context;
            Toast.makeText(context4, context4.getString(2131361853), 0).show();
        } else {
            Context context5 = this.context;
            Toast.makeText(context5, context5.getString(2131361821), 0).show();
        }
        px0Var = we1.a;
        if (qx0.a(px0Var) != null) {
            Context context6 = this.context;
            Toast.makeText(context6, context6.getString(2131361840), 0).show();
        }
    }

    @JavascriptInterface
    public final void copyText(String str) {
        Object px0Var;
        int i;
        if (str != null && !q81.E(str)) {
            try {
                Object systemService = this.context.getSystemService("clipboard");
                systemService.getClass();
                ClipboardManager clipboardManager = (ClipboardManager) systemService;
                int length = str.length() - 1;
                int i2 = 0;
                boolean z = false;
                while (i2 <= length) {
                    if (!z) {
                        i = i2;
                    } else {
                        i = length;
                    }
                    boolean y = a5.y(str.charAt(i));
                    if (!z) {
                        if (!y) {
                            z = true;
                        } else {
                            i2++;
                        }
                    } else if (!y) {
                        break;
                    } else {
                        length--;
                    }
                }
                clipboardManager.setPrimaryClip(ClipData.newPlainText("GoldBook", str.subSequence(i2, length + 1).toString()));
                Context context = this.context;
                Toast.makeText(context, context.getString(2131361964), 0).show();
                px0Var = we1.a;
            } catch (Throwable th) {
                px0Var = new px0(th);
            }
            if (qx0.a(px0Var) != null) {
                Context context2 = this.context;
                Toast.makeText(context2, context2.getString(2131361839), 0).show();
                return;
            }
            return;
        }
        Context context3 = this.context;
        Toast.makeText(context3, context3.getString(2131361935), 0).show();
    }
}