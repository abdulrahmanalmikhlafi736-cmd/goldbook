package com.almekhlafi.goldbook.utils.jsBridge;

import android.webkit.JavascriptInterface;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
public final class MaterialYouBridge {
    public static final int $stable = 8;
    private final sb1 colors;

    public MaterialYouBridge(sb1 sb1Var) {
        sb1Var.getClass();
        this.colors = sb1Var;
    }

    private final String colorToRgb(int i) {
        return "{\"r\":" + ((i >> 16) & 255) + ",\"g\":" + ((i >> 8) & 255) + ",\"b\":" + (i & 255) + "}";
    }

    private final String colorToRgbString(int i) {
        return "rgb(" + ((i >> 16) & 255) + ", " + ((i >> 8) & 255) + ", " + (i & 255) + ")";
    }

    @JavascriptInterface
    public final String getMaterialYouOnPrimaryRgb() {
        return colorToRgb(this.colors.b);
    }

    @JavascriptInterface
    public final String getMaterialYouOnPrimaryRgbString() {
        return colorToRgbString(this.colors.b);
    }

    @JavascriptInterface
    public final String getMaterialYouPrimaryRgb() {
        return colorToRgb(this.colors.a);
    }

    @JavascriptInterface
    public final String getMaterialYouPrimaryRgbString() {
        return colorToRgbString(this.colors.a);
    }
}