package androidx.lifecycle;

import android.app.Application;
import android.content.Context;
import android.os.Handler;
import java.util.HashSet;
import java.util.List;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
public final class ProcessLifecycleInitializer implements l50 {
    @Override // defpackage.l50
    public final List a() {
        return ut.e;
    }

    @Override // defpackage.l50
    public final Object b(Context context) {
        context.getClass();
        k9 s = k9.s(context);
        s.getClass();
        if (((HashSet) s.g).contains(ProcessLifecycleInitializer.class)) {
            if (!md0.a.getAndSet(true)) {
                Context applicationContext = context.getApplicationContext();
                applicationContext.getClass();
                ((Application) applicationContext).registerActivityLifecycleCallbacks(new ld0());
            }
            wu0 wu0Var = wu0.m;
            wu0Var.getClass();
            wu0Var.i = new Handler();
            wu0Var.j.d(id0.ON_CREATE);
            Context applicationContext2 = context.getApplicationContext();
            applicationContext2.getClass();
            ((Application) applicationContext2).registerActivityLifecycleCallbacks(new vu0(wu0Var));
            return wu0Var;
        }
        od.p("ProcessLifecycleInitializer cannot be initialized lazily.\n               Please ensure that you have:\n               <meta-data\n                   android:name='androidx.lifecycle.ProcessLifecycleInitializer'\n                   android:value='androidx.startup' />\n               under InitializationProvider in your AndroidManifest.xml");
        return null;
    }
}