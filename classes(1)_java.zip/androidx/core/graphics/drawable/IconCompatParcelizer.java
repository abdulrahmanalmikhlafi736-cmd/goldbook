package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.os.Parcel;
import android.os.Parcelable;
import java.nio.charset.Charset;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
public class IconCompatParcelizer {
    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    public static IconCompat read(kg1 kg1Var) {
        IconCompat iconCompat = new IconCompat();
        int i = iconCompat.a;
        if (kg1Var.e(1)) {
            i = ((lg1) kg1Var).e.readInt();
        }
        iconCompat.a = i;
        byte[] bArr = iconCompat.c;
        if (kg1Var.e(2)) {
            Parcel parcel = ((lg1) kg1Var).e;
            int readInt = parcel.readInt();
            if (readInt < 0) {
                bArr = null;
            } else {
                byte[] bArr2 = new byte[readInt];
                parcel.readByteArray(bArr2);
                bArr = bArr2;
            }
        }
        iconCompat.c = bArr;
        iconCompat.d = kg1Var.f(iconCompat.d, 3);
        int i2 = iconCompat.e;
        if (kg1Var.e(4)) {
            i2 = ((lg1) kg1Var).e.readInt();
        }
        iconCompat.e = i2;
        int i3 = iconCompat.f;
        if (kg1Var.e(5)) {
            i3 = ((lg1) kg1Var).e.readInt();
        }
        iconCompat.f = i3;
        iconCompat.g = (ColorStateList) kg1Var.f(iconCompat.g, 6);
        String str = iconCompat.i;
        if (kg1Var.e(7)) {
            str = ((lg1) kg1Var).e.readString();
        }
        iconCompat.i = str;
        String str2 = iconCompat.j;
        if (kg1Var.e(8)) {
            str2 = ((lg1) kg1Var).e.readString();
        }
        iconCompat.j = str2;
        iconCompat.h = PorterDuff.Mode.valueOf(iconCompat.i);
        switch (iconCompat.a) {
            case -1:
                Parcelable parcelable = iconCompat.d;
                if (parcelable != null) {
                    iconCompat.b = parcelable;
                    return iconCompat;
                }
                od.m("Invalid icon");
                return null;
            case 1:
            case gu0.STRING_FIELD_NUMBER /* 5 */:
                Parcelable parcelable2 = iconCompat.d;
                if (parcelable2 != null) {
                    iconCompat.b = parcelable2;
                    return iconCompat;
                }
                byte[] bArr3 = iconCompat.c;
                iconCompat.b = bArr3;
                iconCompat.a = 3;
                iconCompat.e = 0;
                iconCompat.f = bArr3.length;
                return iconCompat;
            case 2:
            case gu0.LONG_FIELD_NUMBER /* 4 */:
            case gu0.STRING_SET_FIELD_NUMBER /* 6 */:
                String str3 = new String(iconCompat.c, Charset.forName("UTF-16"));
                iconCompat.b = str3;
                if (iconCompat.a == 2 && iconCompat.j == null) {
                    iconCompat.j = str3.split(":", -1)[0];
                    break;
                }
                break;
            case 3:
                iconCompat.b = iconCompat.c;
                return iconCompat;
        }
        return iconCompat;
    }

    public static void write(IconCompat iconCompat, kg1 kg1Var) {
        kg1Var.getClass();
        iconCompat.i = iconCompat.h.name();
        switch (iconCompat.a) {
            case -1:
                iconCompat.d = (Parcelable) iconCompat.b;
                break;
            case 1:
            case gu0.STRING_FIELD_NUMBER /* 5 */:
                iconCompat.d = (Parcelable) iconCompat.b;
                break;
            case 2:
                iconCompat.c = ((String) iconCompat.b).getBytes(Charset.forName("UTF-16"));
                break;
            case 3:
                iconCompat.c = (byte[]) iconCompat.b;
                break;
            case gu0.LONG_FIELD_NUMBER /* 4 */:
            case gu0.STRING_SET_FIELD_NUMBER /* 6 */:
                iconCompat.c = iconCompat.b.toString().getBytes(Charset.forName("UTF-16"));
                break;
        }
        int i = iconCompat.a;
        if (-1 != i) {
            kg1Var.h(1);
            ((lg1) kg1Var).e.writeInt(i);
        }
        byte[] bArr = iconCompat.c;
        if (bArr != null) {
            kg1Var.h(2);
            Parcel parcel = ((lg1) kg1Var).e;
            parcel.writeInt(bArr.length);
            parcel.writeByteArray(bArr);
        }
        Parcelable parcelable = iconCompat.d;
        if (parcelable != null) {
            kg1Var.h(3);
            ((lg1) kg1Var).e.writeParcelable(parcelable, 0);
        }
        int i2 = iconCompat.e;
        if (i2 != 0) {
            kg1Var.h(4);
            ((lg1) kg1Var).e.writeInt(i2);
        }
        int i3 = iconCompat.f;
        if (i3 != 0) {
            kg1Var.h(5);
            ((lg1) kg1Var).e.writeInt(i3);
        }
        ColorStateList colorStateList = iconCompat.g;
        if (colorStateList != null) {
            kg1Var.h(6);
            ((lg1) kg1Var).e.writeParcelable(colorStateList, 0);
        }
        String str = iconCompat.i;
        if (str != null) {
            kg1Var.h(7);
            ((lg1) kg1Var).e.writeString(str);
        }
        String str2 = iconCompat.j;
        if (str2 != null) {
            kg1Var.h(8);
            ((lg1) kg1Var).e.writeString(str2);
        }
    }
}