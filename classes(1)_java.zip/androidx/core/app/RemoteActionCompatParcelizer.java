package androidx.core.app;

import android.app.PendingIntent;
import android.os.Parcel;
import android.text.TextUtils;
import androidx.core.graphics.drawable.IconCompat;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
public class RemoteActionCompatParcelizer {
    public static RemoteActionCompat read(kg1 kg1Var) {
        RemoteActionCompat remoteActionCompat = new RemoteActionCompat();
        mg1 mg1Var = remoteActionCompat.a;
        boolean z = true;
        if (kg1Var.e(1)) {
            mg1Var = kg1Var.g();
        }
        remoteActionCompat.a = (IconCompat) mg1Var;
        CharSequence charSequence = remoteActionCompat.b;
        if (kg1Var.e(2)) {
            charSequence = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(((lg1) kg1Var).e);
        }
        remoteActionCompat.b = charSequence;
        CharSequence charSequence2 = remoteActionCompat.c;
        if (kg1Var.e(3)) {
            charSequence2 = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(((lg1) kg1Var).e);
        }
        remoteActionCompat.c = charSequence2;
        remoteActionCompat.d = (PendingIntent) kg1Var.f(remoteActionCompat.d, 4);
        boolean z2 = remoteActionCompat.e;
        if (kg1Var.e(5)) {
            if (((lg1) kg1Var).e.readInt() != 0) {
                z2 = true;
            } else {
                z2 = false;
            }
        }
        remoteActionCompat.e = z2;
        boolean z3 = remoteActionCompat.f;
        if (!kg1Var.e(6)) {
            z = z3;
        } else if (((lg1) kg1Var).e.readInt() == 0) {
            z = false;
        }
        remoteActionCompat.f = z;
        return remoteActionCompat;
    }

    public static void write(RemoteActionCompat remoteActionCompat, kg1 kg1Var) {
        kg1Var.getClass();
        IconCompat iconCompat = remoteActionCompat.a;
        kg1Var.h(1);
        kg1Var.i(iconCompat);
        CharSequence charSequence = remoteActionCompat.b;
        kg1Var.h(2);
        Parcel parcel = ((lg1) kg1Var).e;
        TextUtils.writeToParcel(charSequence, parcel, 0);
        CharSequence charSequence2 = remoteActionCompat.c;
        kg1Var.h(3);
        TextUtils.writeToParcel(charSequence2, parcel, 0);
        PendingIntent pendingIntent = remoteActionCompat.d;
        kg1Var.h(4);
        parcel.writeParcelable(pendingIntent, 0);
        boolean z = remoteActionCompat.e;
        kg1Var.h(5);
        parcel.writeInt(z ? 1 : 0);
        boolean z2 = remoteActionCompat.f;
        kg1Var.h(6);
        parcel.writeInt(z2 ? 1 : 0);
    }
}