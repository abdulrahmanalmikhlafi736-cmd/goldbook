package android.support.v4.app;

import androidx.core.app.RemoteActionCompat;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
public final class RemoteActionCompatParcelizer extends androidx.core.app.RemoteActionCompatParcelizer {
    public static RemoteActionCompat read(kg1 kg1Var) {
        return androidx.core.app.RemoteActionCompatParcelizer.read(kg1Var);
    }

    public static void write(RemoteActionCompat remoteActionCompat, kg1 kg1Var) {
        androidx.core.app.RemoteActionCompatParcelizer.write(remoteActionCompat, kg1Var);
    }
}