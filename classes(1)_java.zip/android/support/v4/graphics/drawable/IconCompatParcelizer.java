package android.support.v4.graphics.drawable;

import androidx.core.graphics.drawable.IconCompat;

/* compiled from: r8-map-id-559f6dc2d613f2ef88f8068545cbbb4c2f79f831074e685adfb7a269ac51992a */
public final class IconCompatParcelizer extends androidx.core.graphics.drawable.IconCompatParcelizer {
    public static IconCompat read(kg1 kg1Var) {
        return androidx.core.graphics.drawable.IconCompatParcelizer.read(kg1Var);
    }

    public static void write(IconCompat iconCompat, kg1 kg1Var) {
        androidx.core.graphics.drawable.IconCompatParcelizer.write(iconCompat, kg1Var);
    }
}