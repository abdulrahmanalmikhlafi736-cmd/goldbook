# FPRO — مصدر التطبيق المصغر / البناء 18

الإصدار 0.0.1، versionCode 18، الحزمة com.almekhlafi.FPRO.
المطور: عبدالرحمن المخلافي. GPL-3.0.

هذه حزمة مصدر التطبيق فقط: Kotlin وCompose وWebView وJavaScript والموارد وGradle Wrapper.
لا تحتوي الأرشيفات القديمة أو DEX/JAR القديمة أو ملفات المرجع أو الاختبارات.
ملف gradle-wrapper.jar مطلوب للبناء وليس أرشيف تطبيق قديمًا.
تم استبعاد وحدة device-tests من settings.gradle.kts فقط؛ مصدر التطبيق وإعداد compact دون تغيير.

## البناء المصغر
افتح المجلد في Android Studio، مع JDK 17 وSDK 35.
اضبط Android SDK ثم نفذ:

```sh
chmod +x gradlew
./gradlew :app:assembleCompact
```

على Windows: gradlew.bat :app:assembleCompact
الناتج: app/build/outputs/apk/compact/app-compact.apk
هذا هو مسار البناء المصغر الذي كان APK الخاص به نحو 1 ميجابايت؛ حجم المصدر مختلف.
البناء يحتاج الإنترنت لتنزيل اعتماديات Gradle وAndroid، وهي غير مرفقة.
التوقيع بمفتاح تطوير البيئة وليس مفتاح متجر؛ قد يلزم حذف النسخة المثبتة إذا اختلف التوقيع، ما يمسح جلسة التطبيق.

## حدود البناء 18
مسار الهاشتاجات محفوظ. معالجة Canvas للحلقات تجريبية ولم تثبت على حساب المستخدم.
نجحت الاختبارات السابقة على API29 debug وAPI35 debug/compact؛ فشل شرط فتح التطبيق في API36 compact وسببه غير محسوم.
مرجع Compose: https://developer.android.com/develop/ui/compose/documentation?hl=ar
